$(document).ready(function() {
    $('#summernote').trumbowyg({    
    });
    $('#latestupdates').trumbowyg({
    });
});
$(function(){
    $(".sort-div-campaign-doc").sortable();
    $(".sort-campaign-gallery").sortable();
});

$("#thummb_image").on('click', function(event){
    $('#p_image').click();
})
p_image.onchange = evt => {
  const [file] = p_image.files
  if (file) {
    thummb_image.src = URL.createObjectURL(file)
  }
}
let gallery_image_index=1;
$(".add-gallery-image").on('click', function(event){
	var file = '<input type="hidden" name="gallery_image_index[]" value="'+gallery_image_index+'"><input type="file" name="gallery_image'+gallery_image_index+'" id="gallery_image'+gallery_image_index+'" onchange="gallery_image_show('+gallery_image_index+')" class="d-none" accept="image/png, image/jpg, image/jpeg">';
    var html = '<li class="ui-state-default ui-sortable-handle gallery-image-li'+gallery_image_index+'">'+file+'<img src="'+BASE_URL+'assets/uploads/campaign/gallery/default.jpg" class="gallery-image" id="gallery_image_show'+gallery_image_index+'" onclick="push_gallery_image('+gallery_image_index+')"><i class="fa fa-trash delete-image" onclick="delete_gallery_image('+gallery_image_index+')"></i></li>';
    $('.sort-campaign-gallery').append(html);
    gallery_image_index++;
});
function push_gallery_image(row){
	$('#gallery_image'+row).click();
}
function gallery_image_show(row){
	var file = $('#gallery_image'+row).prop("files")[0];
	var imagen = URL.createObjectURL(file);
	$('#gallery_image_show'+row).attr('src',imagen);
}
function delete_gallery_image(row){
	$('.gallery-image-li'+row).remove();
}

let document_index=1;
$(".add-more-documents").on('click', function(event){
	var file = '<input type="hidden" name="document_index[]" value="'+document_index+'"><input type="file" name="document_image'+document_index+'" id="document_image'+document_index+'" onchange="document_image_show('+document_index+')" class="d-none" accept="image/png, image/jpg, image/jpeg">';
	var html = '<li class="ui-state-default ui-sortable-handle document-image-li'+document_index+'">'+file+'<img src="'+BASE_URL+'assets/uploads/campaign/document/default.jpg" class="document-image" id="document_image_show'+document_index+'" onclick="push_document_image('+document_index+')"><i class="fa fa-trash document-remove" onclick="delete_document_image('+document_index+')"></i></li>';
	$('.campaign-document').append(html);
    document_index++;
});

function push_document_image(row){
	$('#document_image'+row).click();
}
function document_image_show(row){
	var file_doc = $('#document_image'+row).prop("files")[0];
	var imagen_doc = URL.createObjectURL(file_doc);
	$('#document_image_show'+row).attr('src',imagen_doc);
}
function delete_document_image(row){
	$('.document-image-li'+row).remove();
}
$("#beneficiary_image").on('click', function(event){
    $('#beneficiary_image_file').click();
})
beneficiary_image_file.onchange = evt => {
  const [file] = beneficiary_image_file.files
  if (file) {
    beneficiary_image.src = URL.createObjectURL(file)
  }
}
function get_state(data){
    $('select[name="p_beneficiary_state"]').html('');
    $('select[name="p_beneficiary_city"]').html('');
    $.ajax({
        type:'GET',
        url:BASE_URL+'ajax-get-state',
        data:{'data':data},
        dataType:'json',
        success:function(res){
            if(res.status==1){
                var lists = res.lists;
                var option = '<option value="">-State-</option>';
                $.each(lists, function (key, val) {
                    option +='<option value="'+val.state_id+'">'+val.state_name+'</option>';
                });
            }else{
                var option = '<option value="">-State-</option>';
            }
            $('select[name="p_beneficiary_state"]').html(option);
        }
    });
}
function get_city(data){
    $('select[name="p_beneficiary_city"]').html('');
    $.ajax({
        type:'GET',
        url:BASE_URL+'ajax-get-city',
        data:{'data':data},
        dataType:'json',
        success:function(res){
            if(res.status==1){
                var lists = res.lists;
                var option = '<option value="">-City-</option>';
                $.each(lists, function (key, val) {
                    option +='<option value="'+val.city_id+'">'+val.city_name+'</option>';
                });
            }else{
                var option = '<option value="">-City-</option>';
            }
            $('select[name="p_beneficiary_city"]').html(option);
        }
    });
}

$("form[name='add-campaign-form']").validate({
    rules: {
        p_name: {
            required: true,
        },
        p_short_description: {
            required: true,
        },
        p_amount: {
            required: true,
            number: true,
        },
        p_FK_cat_id: {
            required: true,
        },
        p_beneficiary_name: {
            required: true,
        },
        p_beneficiary_relation: {
            required: true,
        },
        p_beneficiary_country: {
            required: true,
        },
        p_beneficiary_state: {
            required: true,
        },
        p_beneficiary_city: {
            required: true,
        },
    },
    messages: {},
    submitHandler: function(form) {
    	if (confirm("Are you sure publish this campaign?")) {
	        form.submit();
	    }
	    return false;
    }
});