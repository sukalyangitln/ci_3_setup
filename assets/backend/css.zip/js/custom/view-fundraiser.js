$('#wallet_transaction_table').DataTable( {
    responsive: true
});
function get_wallet_txn_details(data){
    $.ajax({
        type:'GET',
        url:BASE_URL+'admin/wallet-transaction-details',
        data:{'data':data}, 
        success:function(res){
            $('.transaction-details-modal .transaction-details-table tbody').html(res);
            $('.transaction-details-modal').modal('show');
        }                   
    });
}

$(".profile-image-edit").on('click', function(event){
    $('#ul_thumbnail').click();
})
$("#ul_thumbnail").on('change', function(){
   upload_profile_image();
})
function upload_profile_image(){
	$('.profile-image-upload-loader').fadeIn(0);
	var file_data = $('#ul_thumbnail').prop('files')[0];
	var form_data = new FormData();
	form_data.append('file', file_data);
	form_data.append('ul_id', $('input[name="ul_id"]').val());
	$.ajax({
		url: BASE_URL+'admin/fundraiser/update-profile-image',
		dataType: 'json',
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,
		type: 'post',
		success: function(res) {
			$('.profile-image-upload-loader').fadeOut(0);
			if(res.status==1){
				$('#image_profile_image_edit').attr('src',BASE_URL+res.img);
				toastr.success(res.msg, 'Success');
			}else{
				toastr.error(res.msg, 'Failed');
			}
		}
	});
}
function campaign_status(data){
    if($('#ul_campaign').prop('checked')==true){var status = 'Y';}else{var status = 'N';}
    $.ajax({
        type:'GET',
        url:BASE_URL+'admin/fundraiser/campaign-status',
        data:{'data':data,'status':status},
        success:function(res){
            toastr.success('Campaign status update successful!', 'Success');
        }
    });
}
$("form[name='fundraiser-update-profile']").validate({
    rules: {
        ul_phone: {
            required: true,
            number: true,
        },
        ul_email: {
            required: true,
            email: true
        },
        ul_country: {
            required: true,
        },
        ul_pincode: {
            required: true,
        },
        ul_address: {
            required: true,
        }
    },
    messages: {},
    submitHandler: function(form) {
    	if (confirm("Are you sure update profile?")) {
	        form.submit();
	    }
	    return false;
    }
});

$("form[name='fundraiser-bank-account']").validate({
    rules: {
        bank_name: {
            required: true,
        },
        bank_acc_no: {
            required: true,
            number:true,
        },
        bank_acc_branch_code: {
            required: true,
        },
        bank_acc_holder_name: {
            required: true,
        },
        bank_acc_phone: {
            required: true,
        }
    },
    messages: {},
    submitHandler: function(form) {
    	if (confirm("Are you sure update bank account?")) {
	        form.submit();
	    }
	    return false;
    }
});
kyc_document_file.onchange = evt => {
  const [file] = kyc_document_file.files
  if (file) {
    kyc_document_image.src = URL.createObjectURL(file)
  }
}
kyc_logo.onchange = evt => {
  const [file] = kyc_logo.files
  if (file) {
    image_kyc_logo.src = URL.createObjectURL(file)
  }
}
$("form[name='fundraiser-kyc-commercial']").validate({
    rules: {
        kyc_document_id: {
            required: true,
        },
        comdtls_name: {
            required: true,
        },
        comdtls_FK_country_id: {
            required: true,
        },
        comdtls_phone: {
            required: true,
            number:true,
        },
        comdtls_email: {
            required: true,
            email:true,
        },kyc_status: {
            required: true
        }
    },
    messages: {},
    submitHandler: function(form) {
    	if (confirm("Are you sure update kyc?")) {
	        form.submit();
	    }
	    return false;
    }
});

$("form[name='fundraiser-kyc-domestic']").validate({
    rules: {
        kyc_document_id: {
            required: true,
        },kyc_status: {
            required: true,
        }
    },
    messages: {},
    submitHandler: function(form) {
    	if (confirm("Are you sure update kyc?")) {
	        form.submit();
	    }
	    return false;
    }
});
function kycstatus(status){
    if(status==2){
        $('.kyc_reject_cause').fadeIn();
    }else{
        $('.kyc_reject_cause').fadeOut();
    }
}