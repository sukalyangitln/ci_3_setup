$(document).ready(function() {
    $('#car_long_description').trumbowyg({ 
    });
});
$(function(){
    $(".sort-div-campaign-doc").sortable();
    $(".sort-campaign-gallery").sortable();
});
$("#thummb_image").on('click', function(event){
    $('#car_thmb_image').click();
});
car_thmb_image.onchange = evt => {
  const [file] = car_thmb_image.files
  if (file) {
    thummb_image.src = URL.createObjectURL(file)
  }
}
$("form[name='edit_car']").validate({
    rules: {
        car_id: {
            required: true,
        },
        car_FK_category: {
            required: true,
        },car_FK_brand: {
            required: true,
        },car_title: {
            required: true,
        },car_normal_user_rent: {
            required: true,
        },car_prime_user_rent: {
            required: true,
        },car_make: {
            required: true,
        },car_model: {
            required: true,
        },car_fuel_type: {
            required: true,
        },
    },
    messages: {},
    submitHandler: function(form) {
        var video_id = $('input[name="car_video"]').val();
        if(video_id != '') {
            $.ajax({
                type: 'GET',
                url: BASE_URL + 'admin/check-video-existance-by-video-id',
                data: {
                    'video_id': video_id
                },
                // dataType:'json',
                success: function(res) {
                    if(res == 1) {
                        $('label[for="car_video"]').text('Video').css('color', '#495057');
                        form.submit();
                    } else {
                        $('label[for="car_video"]').text('Video not found!').css('color', 'red');
                        $('input[name="car_video"]').focus();
                        event.preventDefault();
                        return false;
                    }
                }
            });
        } else {
            form.submit();
        }
    }
});
function validate_the_video(video_id) {
    $.ajax({
        type: 'GET',
        url: BASE_URL + 'admin/check-video-existance-by-video-id',
        data: {
            'video_id': video_id
        },
        // dataType:'json',
        success: function(res) {
            if(res == 1) {
                $('label[for="car_video"]').text('Video').css('color', '#495057');
            } else {
                $('label[for="car_video"]').text('Video not found!').css('color', 'red');
            }
        }
    });
}
// let gallery_image_index=1;
$(".add-gallery-image").on('click', function(event){
    var file = '<input type="hidden" name="gallery_image_index[]" value="'+gallery_image_index+'"><input type="file" name="gallery_image'+gallery_image_index+'" id="gallery_image'+gallery_image_index+'" onchange="gallery_image_show('+gallery_image_index+')" class="d-none" accept="image/png, image/jpg, image/jpeg">';
    var html = '<li class="ui-state-default ui-sortable-handle gallery-image-li'+gallery_image_index+'">'+file+'<img src="'+BASE_URL+'assets/uploads/car/default.jpg" class="gallery-image" id="gallery_image_show'+gallery_image_index+'" onclick="push_gallery_image('+gallery_image_index+')"><i class="fa fa-trash delete-image" onclick="delete_gallery_image('+gallery_image_index+')"></i></li>';
    $('.sort-campaign-gallery').append(html);
    gallery_image_index++;
});
function push_gallery_image(row){
    $('#gallery_image'+row).click();
}
function gallery_image_show(row){
    var file = $('#gallery_image'+row).prop("files")[0];
    var imagen = URL.createObjectURL(file);
    $('#gallery_image_show'+row).attr('src',imagen);
}
function delete_gallery_image(row){
    if (confirm("Are you sure delete this document?")) {
        $('.gallery-image-li'+row).remove();
    }
    return false;
}
//** TAG **//
$(document).on("click", ".remove-tag-keyword" , function() {
    var tag_id = $(this).attr('id');
    $(this).parent().remove();
});
$(document).on("click", ".tag-keyword-div .add-tag-btn" , function() {
    var keyword = $('.tag-search-input-box').val();
    var html='<li class="tag-keyword-list"><input type="hidden" name="car_tag_json[]" value="'+keyword+'">'+keyword+'<i class="fa fa-trash remove-tag-keyword"></i></li>';
    $('.tag-keyword-div ul').append(html);
    $.ajax({
        type:'GET',
        url:BASE_URL+'Admin/Car_Crud/add_tag',
        data:{'tag':keyword},
        success:function(res){
        }
    });
});

$(document).on("click", ".tag-suggestion-div ul li" , function() {
    var keyword = $(this).text();
    var html='<li class="tag-keyword-list"><input type="hidden" name="car_tag_json[]" value="'+keyword+'">'+keyword+'<i class="fa fa-trash remove-tag-keyword"></i></li>';
    $('.tag-keyword-div ul').append(html);
    $('.tag-suggestion-div').fadeOut();
});
$('.tag-search-input-box').keyup(function(event){
    var keyword = $(this).val();
    if(keyword.length>2){
        $.ajax({
            type:'GET',
            url:BASE_URL+'Admin/Car_Crud/get_tag_suggestion',
            value:{'tag':keyword},
            dataType:'json',
            success:function(res){
                if(res.status==1){
                    var search_sug_html='';
                    $.each(res.data, function (i) {
                        var kws="'"+res.data[i].tag_name+"'";
                        search_sug_html = search_sug_html+'<li>'+res.data[i].tag_name+'</li>';
                    });
                    $('.tag-suggestion-div ul').html(search_sug_html);
                    $('.tag-suggestion-div').fadeIn();
                }else{
                    $('.tag-suggestion-div ul').html('');
                }
            }
        }); 
    }else{
        $('.tag-suggestion-div').fadeOut();
        $('.tag-suggestion-div ul').html('');
    }
});
//** END TAG **//

///////***** START PIN CODE SEARCH ******///////
$(document).on("click", ".available-location ul li .delete-location" , function() {
    $(this).parent().remove();
});
$('input[name="pin_code_search"]').keyup(function(event){
    var keyword = $(this).val();
    if(keyword.length>2){
        $.ajax({
            type:'GET',
            url:BASE_URL+'Admin/Car_Crud/get_search_pincode',
            data:{'keyword':keyword},
            dataType:'json',
            success:function(res){
                if(res.status==1){
                    var search_sug_html='';
                    $.each(res.data, function (i) {
                        search_sug_html = search_sug_html+'<li value="'+res.data[i].pc_id+'">'+res.data[i].pc_pincode+'</li>';
                    });
                    $('.location-suggestion-div ul').html(search_sug_html);
                    $('.location-suggestion-div').fadeIn();
                }else{
                    $('.location-suggestion-div ul').html('');
                    $('.location-suggestion-div').fadeOut();
                }
            }
        });
    }else{
        $('.location-suggestion-div').fadeOut();
        $('.location-suggestion-div ul').html('');
    }
});
$(document).on("click", ".location-suggestion-div ul li" , function() {
    var val_id = $(this).val();
    var text = $(this).text();
    var exist_pin_lists = $("input[name='pin_code[]']").map(function(){return parseInt($(this).val());}).get();
    if ($.inArray(val_id, exist_pin_lists) != -1){
    }else{
        console.log('not found');
        console.log(exist_pin_lists);
       var html='<li class="location-list"><input type="hidden" name="pin_code[]" value="'+val_id+'">'+text+'<i class="fa fa-trash delete-location"></i></li>';
       $('.available-location ul').append(html);
    }   
    $('.location-suggestion-div').fadeOut();
    $('input[name="pin_code_search"]').val('');
});
$(".pin-code-group").on('click', function(event){
    var pin_code_group =$('select[name="pin_code_group"]').val();
    $.ajax({
        type:'GET',
        url:BASE_URL+'Admin/Car_Crud/get_pincode_group',
        data:{'pin_code_group':pin_code_group},
        dataType:'json',
        success:function(res){
            if(res.status==1){
                $.each(res.data, function (i) {
                    var exist_pin_lists = $("input[name='pin_code[]']").map(function(){return $(this).val();}).get();
                    if($.inArray(res.data[i].pc_id, exist_pin_lists) !== -1 ) {
                    }else{
                        var html = '<li class="location-list"><input type="hidden" name="pin_code[]" value="'+res.data[i].pc_id+'">'+res.data[i].pc_pincode+'<i class="fa fa-trash delete-location"></i></li>';
                        $('.available-location ul').append(html);
                    }
                });
            }
        }
    });
});
$(document).on("click", ".add-pincode" , function() {
    var pin_code = $('input[name="pin_code_search"]').val();
    if(pin_code!=''){
        if (confirm("Are you sure add this pincode?")) {
            $.ajax({
                type:'GET',
                url:BASE_URL+'Admin/Availability_Locations_Crud/add_pincode_urgent',
                data:{'pin_code':pin_code},
                dataType:'json',
                success:function(res){
                    if(res.status==1){
                        console.log(res);
                        var exist_pin_lists = $("input[name='pin_code[]']").map(function(){return $(this).val();}).get();
                        if($.inArray(res.id, exist_pin_lists) !== -1 ) {
                        }else{
                            var html = '<li class="location-list"><input type="hidden" name="pin_code[]" value="'+res.id+'">'+res.pincode+'<i class="fa fa-trash delete-location"></i></li>';
                            $('.available-location ul').append(html);
                            console.log(html);
                        }
                    }else{
                        toastr.error(res.msg, 'Error');
                    }
                }
            });
        }
        return false;
    }
});
///////***** END PIN CODE SEARCH ******///////

$(document).ready(function() {
  // Function to validate input value
  function validateInput(input) {
    // Regular expression to match integer or float value
    var pattern = /^-?\d*\.?\d+(?:[eE][-+]?\d+)?$/;
    return pattern.test(input);
  }
  // Event handler for input change
  $('.intfloat').on('input', function() {
    var inputValue = $(this).val();
    if (!validateInput(inputValue)) {
      // If input is invalid, remove last entered character
      $(this).val(function(_, val) {
        return val.slice(0, -1);
      });
    }
  });
});