<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-03 00:59:16 --> Total execution time: 1.0552
DEBUG - 2022-05-03 00:59:32 --> Total execution time: 0.0613
DEBUG - 2022-05-03 01:00:42 --> Total execution time: 0.0332
DEBUG - 2022-05-03 02:12:43 --> Total execution time: 1.1060
DEBUG - 2022-05-03 02:15:11 --> Total execution time: 0.8791
DEBUG - 2022-05-03 02:30:46 --> Total execution time: 1.0633
DEBUG - 2022-05-03 01:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:33:02 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:03:02 --> Total execution time: 0.8345
DEBUG - 2022-05-03 01:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:36:00 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:06:00 --> Total execution time: 0.2151
DEBUG - 2022-05-03 01:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:36:33 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:06:33 --> Total execution time: 0.0307
DEBUG - 2022-05-03 01:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:36:35 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:06:35 --> Total execution time: 0.0318
DEBUG - 2022-05-03 01:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:36:49 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:06:49 --> Total execution time: 0.0299
DEBUG - 2022-05-03 01:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:40:20 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:10:20 --> Total execution time: 0.0341
DEBUG - 2022-05-03 01:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:42:57 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:12:57 --> Total execution time: 0.0311
DEBUG - 2022-05-03 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:43:13 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:13:13 --> Total execution time: 0.0328
DEBUG - 2022-05-03 01:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:44:58 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:14:58 --> Total execution time: 0.0302
DEBUG - 2022-05-03 01:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:27:17 --> Total execution time: 0.8081
DEBUG - 2022-05-03 01:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 01:58:19 --> No URI present. Default controller set.
DEBUG - 2022-05-03 01:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 01:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:28:19 --> Total execution time: 0.0528
DEBUG - 2022-05-03 02:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:06:58 --> No URI present. Default controller set.
DEBUG - 2022-05-03 02:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:36:59 --> Total execution time: 0.8131
DEBUG - 2022-05-03 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:44:05 --> Total execution time: 0.0316
DEBUG - 2022-05-03 02:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:48:44 --> Total execution time: 0.0358
DEBUG - 2022-05-03 02:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:50:36 --> Total execution time: 0.0331
DEBUG - 2022-05-03 02:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:51:44 --> Total execution time: 0.0294
DEBUG - 2022-05-03 02:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:55:09 --> Total execution time: 0.8020
DEBUG - 2022-05-03 02:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:55:34 --> Total execution time: 0.0303
DEBUG - 2022-05-03 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:55:54 --> Total execution time: 0.0287
DEBUG - 2022-05-03 02:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:56:22 --> Total execution time: 0.0309
DEBUG - 2022-05-03 02:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 07:56:36 --> Total execution time: 0.0274
DEBUG - 2022-05-03 02:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:04:03 --> Total execution time: 0.8010
DEBUG - 2022-05-03 02:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:04:38 --> Total execution time: 0.0287
DEBUG - 2022-05-03 02:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:04:44 --> Total execution time: 0.0275
DEBUG - 2022-05-03 02:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:06:13 --> Total execution time: 0.5402
DEBUG - 2022-05-03 02:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:06:22 --> Total execution time: 0.0292
DEBUG - 2022-05-03 02:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:08:22 --> Total execution time: 0.8050
DEBUG - 2022-05-03 02:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:09:13 --> Total execution time: 0.0544
DEBUG - 2022-05-03 02:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:39:39 --> No URI present. Default controller set.
DEBUG - 2022-05-03 02:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:09:39 --> Total execution time: 0.8271
DEBUG - 2022-05-03 02:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:45:39 --> Total execution time: 0.9324
DEBUG - 2022-05-03 02:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:45:39 --> Total execution time: 0.0309
DEBUG - 2022-05-03 02:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:15:43 --> Total execution time: 0.0658
DEBUG - 2022-05-03 02:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:15:46 --> Total execution time: 0.1160
DEBUG - 2022-05-03 02:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:45:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:15:56 --> Total execution time: 0.2141
DEBUG - 2022-05-03 02:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:16:11 --> Total execution time: 0.0565
DEBUG - 2022-05-03 02:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:16:27 --> Total execution time: 0.8521
DEBUG - 2022-05-03 02:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:16:28 --> Total execution time: 0.0452
DEBUG - 2022-05-03 02:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:16:49 --> Total execution time: 0.1361
DEBUG - 2022-05-03 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:47:01 --> No URI present. Default controller set.
DEBUG - 2022-05-03 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:17:02 --> Total execution time: 0.8411
DEBUG - 2022-05-03 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:17:24 --> Total execution time: 2.8622
DEBUG - 2022-05-03 02:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:17 --> Total execution time: 0.0544
DEBUG - 2022-05-03 02:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:18 --> Total execution time: 0.0586
DEBUG - 2022-05-03 02:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:24 --> Total execution time: 0.8252
DEBUG - 2022-05-03 02:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:27 --> Total execution time: 0.0396
DEBUG - 2022-05-03 02:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:31 --> Total execution time: 0.0386
DEBUG - 2022-05-03 02:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:43 --> Total execution time: 0.6731
DEBUG - 2022-05-03 02:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:18:48 --> Total execution time: 0.1455
DEBUG - 2022-05-03 02:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-03 02:49:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:14 --> Total execution time: 0.0877
DEBUG - 2022-05-03 02:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:18 --> Total execution time: 0.0821
DEBUG - 2022-05-03 02:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:40 --> Total execution time: 0.0844
DEBUG - 2022-05-03 02:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:44 --> Total execution time: 0.0355
DEBUG - 2022-05-03 02:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:49 --> Total execution time: 0.0322
DEBUG - 2022-05-03 02:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:55 --> Total execution time: 0.0314
DEBUG - 2022-05-03 02:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:23:59 --> Total execution time: 0.8421
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 02:54:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-03 02:54:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-03 02:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 02:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:24:43 --> Total execution time: 0.0859
DEBUG - 2022-05-03 02:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 02:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 02:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:24:45 --> Total execution time: 0.4421
DEBUG - 2022-05-03 03:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:02:26 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:32:27 --> Total execution time: 1.0392
DEBUG - 2022-05-03 03:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:04:17 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:34:18 --> Total execution time: 0.8231
DEBUG - 2022-05-03 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:37:16 --> Total execution time: 0.8453
DEBUG - 2022-05-03 03:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:07:22 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:07:39 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:07:55 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:19:20 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:19:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:21 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:22 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:23 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:24 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:25 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
ERROR - 2022-05-03 08:49:26 --> Severity: Notice --> Undefined property: stdClass::$ser_registered /home/gvprods/public_html/v1/gvv3/application/controllers/Welcome.php 47
DEBUG - 2022-05-03 03:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:19:44 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:20:36 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:22:09 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:16 --> Total execution time: 2.5519
DEBUG - 2022-05-03 03:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:30 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:30 --> Total execution time: 0.0693
DEBUG - 2022-05-03 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:37 --> Total execution time: 0.0669
DEBUG - 2022-05-03 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:40 --> Total execution time: 0.0320
DEBUG - 2022-05-03 03:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:49 --> Total execution time: 0.0310
DEBUG - 2022-05-03 03:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:54 --> Total execution time: 0.0347
DEBUG - 2022-05-03 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:53:57 --> Total execution time: 0.0434
DEBUG - 2022-05-03 03:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:27:16 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:57:17 --> Total execution time: 0.8211
DEBUG - 2022-05-03 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:31:21 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:01:22 --> Total execution time: 0.8276
DEBUG - 2022-05-03 03:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:03:33 --> Total execution time: 0.8814
DEBUG - 2022-05-03 03:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:05:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-03 03:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:05:42 --> Total execution time: 0.0831
DEBUG - 2022-05-03 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:35:47 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:05:47 --> Total execution time: 0.0437
DEBUG - 2022-05-03 03:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:07:09 --> Total execution time: 0.8387
DEBUG - 2022-05-03 03:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:07:15 --> Total execution time: 0.0751
DEBUG - 2022-05-03 03:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:42 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:07:43 --> Total execution time: 0.8277
DEBUG - 2022-05-03 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:07:55 --> Total execution time: 0.0823
DEBUG - 2022-05-03 03:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:37:58 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:07:58 --> Total execution time: 0.0297
DEBUG - 2022-05-03 03:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:08:27 --> Total execution time: 0.5931
DEBUG - 2022-05-03 03:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:08:32 --> Total execution time: 0.0297
DEBUG - 2022-05-03 03:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:38:35 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:08:35 --> Total execution time: 0.0288
DEBUG - 2022-05-03 03:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:09:24 --> Total execution time: 0.0395
DEBUG - 2022-05-03 03:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:09:29 --> Total execution time: 0.0318
DEBUG - 2022-05-03 03:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 03:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:09:39 --> Total execution time: 0.0296
DEBUG - 2022-05-03 03:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 03:39:42 --> No URI present. Default controller set.
DEBUG - 2022-05-03 03:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 03:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 09:09:42 --> Total execution time: 0.0298
DEBUG - 2022-05-03 05:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:12:57 --> Total execution time: 1.0490
DEBUG - 2022-05-03 05:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:43:04 --> Total execution time: 0.1816
DEBUG - 2022-05-03 05:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:43:16 --> Total execution time: 0.0416
DEBUG - 2022-05-03 05:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:43:57 --> Total execution time: 0.0612
DEBUG - 2022-05-03 05:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-03 05:14:15 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-05-03 05:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:44:20 --> Total execution time: 0.0307
DEBUG - 2022-05-03 05:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:47:21 --> Total execution time: 0.6025
DEBUG - 2022-05-03 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:47:46 --> Total execution time: 0.0318
DEBUG - 2022-05-03 05:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:48:02 --> Total execution time: 0.0434
DEBUG - 2022-05-03 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:48:23 --> Total execution time: 0.0305
DEBUG - 2022-05-03 05:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:48:36 --> Total execution time: 0.0312
DEBUG - 2022-05-03 05:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:49:04 --> Total execution time: 0.0318
DEBUG - 2022-05-03 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:49:11 --> Total execution time: 0.0323
DEBUG - 2022-05-03 05:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:50:06 --> Total execution time: 0.0351
DEBUG - 2022-05-03 05:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:50:17 --> Total execution time: 0.0315
DEBUG - 2022-05-03 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:50:54 --> Total execution time: 0.5463
DEBUG - 2022-05-03 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:52:03 --> Total execution time: 0.0340
DEBUG - 2022-05-03 05:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:52:12 --> Total execution time: 0.0341
DEBUG - 2022-05-03 05:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:52:18 --> Total execution time: 0.0322
DEBUG - 2022-05-03 05:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:52:28 --> Total execution time: 0.0397
DEBUG - 2022-05-03 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:53:12 --> Total execution time: 0.0630
DEBUG - 2022-05-03 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:53:27 --> Total execution time: 0.0357
DEBUG - 2022-05-03 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:53:35 --> Total execution time: 0.0307
DEBUG - 2022-05-03 05:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:54:11 --> Total execution time: 0.3909
DEBUG - 2022-05-03 05:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:54:45 --> Total execution time: 0.8747
DEBUG - 2022-05-03 05:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:54:53 --> Total execution time: 0.8346
DEBUG - 2022-05-03 05:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:55:04 --> Total execution time: 0.8897
DEBUG - 2022-05-03 05:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:55:42 --> Total execution time: 0.0864
DEBUG - 2022-05-03 05:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:56:01 --> Total execution time: 0.9919
DEBUG - 2022-05-03 05:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:56:17 --> Total execution time: 0.8745
DEBUG - 2022-05-03 05:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:56:39 --> Total execution time: 0.8388
DEBUG - 2022-05-03 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:56:53 --> Total execution time: 0.8666
DEBUG - 2022-05-03 05:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:57:41 --> Total execution time: 0.0856
DEBUG - 2022-05-03 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 05:28:29 --> No URI present. Default controller set.
DEBUG - 2022-05-03 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 05:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 10:58:30 --> Total execution time: 0.8340
DEBUG - 2022-05-03 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 06:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 06:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 06:32:33 --> Total execution time: 1.0782
DEBUG - 2022-05-03 06:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 06:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 06:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 06:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 06:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 06:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 12:02:36 --> Total execution time: 0.0581
DEBUG - 2022-05-03 06:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 06:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 06:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 12:02:44 --> Total execution time: 2.5557
DEBUG - 2022-05-03 06:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 06:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 06:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 12:22:16 --> Total execution time: 3.2196
DEBUG - 2022-05-03 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:46:19 --> No URI present. Default controller set.
DEBUG - 2022-05-03 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:16:20 --> Total execution time: 1.0471
DEBUG - 2022-05-03 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:17:50 --> Total execution time: 0.0459
DEBUG - 2022-05-03 08:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:17:53 --> Total execution time: 0.2855
DEBUG - 2022-05-03 08:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 08:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:18:09 --> Total execution time: 0.0944
DEBUG - 2022-05-03 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:18:20 --> Total execution time: 0.0524
DEBUG - 2022-05-03 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:18:28 --> Total execution time: 0.0531
DEBUG - 2022-05-03 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:18:54 --> Total execution time: 2.1450
DEBUG - 2022-05-03 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:19:11 --> Total execution time: 0.1286
DEBUG - 2022-05-03 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:19:32 --> Total execution time: 0.0561
DEBUG - 2022-05-03 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:19:43 --> Total execution time: 0.0839
DEBUG - 2022-05-03 08:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:19:54 --> Total execution time: 0.0306
DEBUG - 2022-05-03 08:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:20:50 --> Total execution time: 0.2850
DEBUG - 2022-05-03 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:20:58 --> Total execution time: 0.0384
DEBUG - 2022-05-03 08:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:21:11 --> Total execution time: 2.1834
DEBUG - 2022-05-03 08:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:21:21 --> Total execution time: 0.0450
DEBUG - 2022-05-03 08:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:21:31 --> Total execution time: 0.0628
DEBUG - 2022-05-03 08:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:24:40 --> Total execution time: 0.8316
DEBUG - 2022-05-03 08:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:28:45 --> Total execution time: 0.8427
DEBUG - 2022-05-03 08:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 08:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 08:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 14:29:29 --> Total execution time: 0.0321
DEBUG - 2022-05-03 11:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:17:34 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:47:35 --> Total execution time: 1.3121
DEBUG - 2022-05-03 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:17:39 --> Total execution time: 0.0425
DEBUG - 2022-05-03 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:19:23 --> Total execution time: 0.7967
DEBUG - 2022-05-03 11:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:52:02 --> Total execution time: 0.0963
DEBUG - 2022-05-03 11:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:52:09 --> Total execution time: 0.1004
DEBUG - 2022-05-03 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:52:12 --> Total execution time: 0.1507
DEBUG - 2022-05-03 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:52:17 --> Total execution time: 0.0347
DEBUG - 2022-05-03 11:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:23:09 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:53:09 --> Total execution time: 0.8274
DEBUG - 2022-05-03 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:58:57 --> Total execution time: 0.8476
DEBUG - 2022-05-03 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:21 --> Total execution time: 0.0311
DEBUG - 2022-05-03 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:27 --> Total execution time: 0.0305
DEBUG - 2022-05-03 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:32 --> Total execution time: 0.0300
DEBUG - 2022-05-03 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:33 --> Total execution time: 0.0288
DEBUG - 2022-05-03 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:35 --> Total execution time: 0.0294
DEBUG - 2022-05-03 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:37 --> Total execution time: 0.0316
DEBUG - 2022-05-03 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:59:52 --> Total execution time: 0.0308
DEBUG - 2022-05-03 11:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:00:50 --> Total execution time: 0.0634
DEBUG - 2022-05-03 11:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:01:10 --> Total execution time: 0.0299
DEBUG - 2022-05-03 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 11:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:01:32 --> Total execution time: 0.0347
DEBUG - 2022-05-03 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:31:34 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:01:34 --> Total execution time: 0.0450
DEBUG - 2022-05-03 11:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:02:42 --> Total execution time: 0.8317
DEBUG - 2022-05-03 11:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:32:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-03 17:02:49 --> Severity: Notice --> Undefined variable: CourseData /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/add_course.php 87
ERROR - 2022-05-03 17:02:49 --> Severity: Notice --> Trying to get property 'product_first_tier' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/add_course.php 87
ERROR - 2022-05-03 17:02:49 --> Severity: Notice --> Undefined variable: CourseData /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/add_course.php 93
ERROR - 2022-05-03 17:02:49 --> Severity: Notice --> Trying to get property 'product_second_tier' of non-object /home/gvprods/public_html/v1/gvv3/application/views/Admin/course/add_course.php 93
DEBUG - 2022-05-03 17:02:49 --> Total execution time: 0.0967
DEBUG - 2022-05-03 11:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:03:15 --> Total execution time: 0.0310
DEBUG - 2022-05-03 11:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:46:32 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:16:33 --> Total execution time: 0.9437
DEBUG - 2022-05-03 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:20 --> Total execution time: 0.0533
DEBUG - 2022-05-03 11:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:38 --> Total execution time: 0.0279
DEBUG - 2022-05-03 11:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:51 --> Total execution time: 0.0274
DEBUG - 2022-05-03 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:19:14 --> Total execution time: 0.0320
DEBUG - 2022-05-03 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:49:25 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:19:25 --> Total execution time: 0.0651
DEBUG - 2022-05-03 11:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 11:51:05 --> No URI present. Default controller set.
DEBUG - 2022-05-03 11:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 11:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:21:06 --> Total execution time: 0.7763
DEBUG - 2022-05-03 12:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 12:46:48 --> No URI present. Default controller set.
DEBUG - 2022-05-03 12:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 12:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 18:16:49 --> Total execution time: 0.9299
DEBUG - 2022-05-03 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 12:47:04 --> No URI present. Default controller set.
DEBUG - 2022-05-03 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 12:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 18:17:04 --> Total execution time: 0.0309
DEBUG - 2022-05-03 16:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:49:55 --> No URI present. Default controller set.
DEBUG - 2022-05-03 16:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:19:56 --> Total execution time: 1.3300
DEBUG - 2022-05-03 16:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:24:37 --> Total execution time: 0.8786
DEBUG - 2022-05-03 16:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 16:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:25:16 --> Total execution time: 0.0934
DEBUG - 2022-05-03 16:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:25:27 --> Total execution time: 0.0521
DEBUG - 2022-05-03 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:25:38 --> Total execution time: 0.0603
DEBUG - 2022-05-03 16:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:25:41 --> Total execution time: 0.0409
DEBUG - 2022-05-03 16:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:25:49 --> Total execution time: 0.0315
DEBUG - 2022-05-03 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:58:25 --> No URI present. Default controller set.
DEBUG - 2022-05-03 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:28:25 --> Total execution time: 0.4265
DEBUG - 2022-05-03 16:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 16:58:29 --> No URI present. Default controller set.
DEBUG - 2022-05-03 16:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 16:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:28:29 --> Total execution time: 0.0297
DEBUG - 2022-05-03 17:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:15:21 --> Total execution time: 0.9380
DEBUG - 2022-05-03 17:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:15:21 --> Total execution time: 0.0279
DEBUG - 2022-05-03 17:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:45:27 --> Total execution time: 0.0831
DEBUG - 2022-05-03 17:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:45:34 --> Total execution time: 0.0604
DEBUG - 2022-05-03 17:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:45:47 --> Total execution time: 0.0808
DEBUG - 2022-05-03 17:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:46:07 --> Total execution time: 0.0306
DEBUG - 2022-05-03 17:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:46:27 --> Total execution time: 2.4738
DEBUG - 2022-05-03 17:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:46:49 --> Total execution time: 0.0432
DEBUG - 2022-05-03 17:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:08 --> Total execution time: 2.7375
DEBUG - 2022-05-03 17:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:23 --> Total execution time: 0.0457
DEBUG - 2022-05-03 17:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:33 --> Total execution time: 0.9366
DEBUG - 2022-05-03 17:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:38 --> Total execution time: 0.0303
DEBUG - 2022-05-03 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:44 --> Total execution time: 0.0325
DEBUG - 2022-05-03 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:47:57 --> Total execution time: 0.0304
DEBUG - 2022-05-03 17:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:08 --> Total execution time: 0.0292
DEBUG - 2022-05-03 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:18:29 --> Total execution time: 0.0293
DEBUG - 2022-05-03 17:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:48:39 --> Total execution time: 0.0670
DEBUG - 2022-05-03 17:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:48:48 --> Total execution time: 0.0285
DEBUG - 2022-05-03 17:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:49:11 --> Total execution time: 0.0306
DEBUG - 2022-05-03 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:49:14 --> Total execution time: 0.1215
DEBUG - 2022-05-03 17:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:49:16 --> Total execution time: 0.0352
DEBUG - 2022-05-03 17:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:49:20 --> Total execution time: 0.0824
DEBUG - 2022-05-03 17:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:49:20 --> Total execution time: 0.0388
DEBUG - 2022-05-03 17:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:50:26 --> Total execution time: 0.0277
DEBUG - 2022-05-03 17:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:50:41 --> Total execution time: 0.0330
DEBUG - 2022-05-03 17:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:50:50 --> Total execution time: 0.0301
DEBUG - 2022-05-03 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:51:03 --> Total execution time: 0.0322
DEBUG - 2022-05-03 17:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:51:12 --> Total execution time: 1.0907
DEBUG - 2022-05-03 17:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:51:34 --> Total execution time: 0.0344
DEBUG - 2022-05-03 17:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 22:51:38 --> Total execution time: 0.0319
DEBUG - 2022-05-03 17:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:05:16 --> Total execution time: 0.8276
DEBUG - 2022-05-03 17:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:05:24 --> Total execution time: 0.0451
DEBUG - 2022-05-03 17:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:35:30 --> No URI present. Default controller set.
DEBUG - 2022-05-03 17:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:05:30 --> Total execution time: 0.0544
DEBUG - 2022-05-03 17:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:22:57 --> Total execution time: 0.0477
DEBUG - 2022-05-03 17:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 17:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:23:08 --> Total execution time: 0.0654
DEBUG - 2022-05-03 17:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:23:16 --> Total execution time: 0.0434
DEBUG - 2022-05-03 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:23:20 --> Total execution time: 0.0307
DEBUG - 2022-05-03 17:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 17:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 17:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-03 23:23:58 --> Total execution time: 0.0633
