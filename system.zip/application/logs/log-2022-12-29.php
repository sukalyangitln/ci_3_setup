<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-29 01:07:41 --> Total execution time: 0.3517
DEBUG - 2022-12-29 01:07:45 --> Total execution time: 0.0535
DEBUG - 2022-12-29 01:07:58 --> Total execution time: 0.0581
DEBUG - 2022-12-29 01:08:02 --> Total execution time: 0.0630
DEBUG - 2022-12-29 01:08:39 --> Total execution time: 0.0526
DEBUG - 2022-12-29 01:08:56 --> Total execution time: 0.0506
DEBUG - 2022-12-29 01:10:07 --> Total execution time: 0.0785
DEBUG - 2022-12-29 01:26:44 --> Total execution time: 0.0736
DEBUG - 2022-12-29 01:32:31 --> Total execution time: 0.0671
DEBUG - 2022-12-29 01:32:56 --> Total execution time: 0.0534
DEBUG - 2022-12-29 01:33:05 --> Total execution time: 0.0690
DEBUG - 2022-12-29 01:34:12 --> Total execution time: 0.0695
DEBUG - 2022-12-29 01:37:25 --> Total execution time: 0.0644
DEBUG - 2022-12-29 01:37:56 --> Total execution time: 0.0739
DEBUG - 2022-12-29 01:39:11 --> Total execution time: 0.0664
DEBUG - 2022-12-29 01:39:50 --> Total execution time: 0.0766
DEBUG - 2022-12-29 01:41:37 --> Total execution time: 0.1092
DEBUG - 2022-12-29 01:41:51 --> Total execution time: 0.0589
DEBUG - 2022-12-29 01:46:18 --> Total execution time: 0.0658
DEBUG - 2022-12-29 01:47:50 --> Total execution time: 0.0641
DEBUG - 2022-12-29 02:07:03 --> Total execution time: 0.0683
DEBUG - 2022-12-29 02:07:04 --> Total execution time: 0.0935
DEBUG - 2022-12-29 02:07:06 --> Total execution time: 0.0524
DEBUG - 2022-12-29 02:09:01 --> Total execution time: 0.0633
DEBUG - 2022-12-29 02:10:14 --> Total execution time: 0.0684
ERROR - 2022-12-29 02:15:38 --> Severity: Notice --> Undefined property: stdClass::$p_campaign_from_date C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-list.php 89
ERROR - 2022-12-29 02:15:38 --> Severity: Notice --> Undefined property: stdClass::$p_campaign_to_date C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-list.php 98
ERROR - 2022-12-29 02:15:38 --> Severity: Notice --> Undefined property: stdClass::$p_created_by C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-list.php 106
DEBUG - 2022-12-29 02:15:38 --> Total execution time: 0.1044
ERROR - 2022-12-29 02:16:21 --> Severity: Notice --> Undefined property: stdClass::$p_created_by C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-list.php 106
DEBUG - 2022-12-29 02:16:21 --> Total execution time: 0.0815
DEBUG - 2022-12-29 02:16:45 --> Total execution time: 0.0671
DEBUG - 2022-12-29 02:25:40 --> Total execution time: 0.0630
DEBUG - 2022-12-29 02:25:51 --> Total execution time: 0.0587
DEBUG - 2022-12-29 02:25:57 --> Total execution time: 0.0638
DEBUG - 2022-12-29 02:26:03 --> Total execution time: 0.0612
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 153
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 153
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 153
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 153
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 159
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_gallery_img_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 159
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 159
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_gallery_img_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 159
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 167
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_documents_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 167
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Undefined variable: EXIST C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 167
ERROR - 2022-12-29 02:31:41 --> Severity: Notice --> Trying to get property 'p_documents_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 167
DEBUG - 2022-12-29 02:31:41 --> Total execution time: 0.1404
DEBUG - 2022-12-29 02:32:07 --> Total execution time: 0.0516
DEBUG - 2022-12-29 02:32:31 --> Total execution time: 0.0605
DEBUG - 2022-12-29 02:32:33 --> Total execution time: 0.1145
DEBUG - 2022-12-29 02:32:34 --> Total execution time: 0.0959
DEBUG - 2022-12-29 02:34:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:34:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:34:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:34:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:34:46 --> Total execution time: 0.0512
DEBUG - 2022-12-29 02:34:47 --> Total execution time: 0.0789
DEBUG - 2022-12-29 02:34:49 --> Total execution time: 0.0536
DEBUG - 2022-12-29 02:34:52 --> Total execution time: 0.0854
DEBUG - 2022-12-29 02:34:56 --> Total execution time: 0.0555
DEBUG - 2022-12-29 02:35:05 --> Total execution time: 0.1054
DEBUG - 2022-12-29 02:35:07 --> Total execution time: 0.0547
DEBUG - 2022-12-29 02:35:09 --> Total execution time: 0.0581
DEBUG - 2022-12-29 02:35:10 --> Total execution time: 0.0742
DEBUG - 2022-12-29 02:37:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:37:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:37:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:37:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:37:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 02:37:07 --> Total execution time: 0.0529
DEBUG - 2022-12-29 02:37:07 --> Total execution time: 0.0743
DEBUG - 2022-12-29 02:37:31 --> Total execution time: 0.0790
DEBUG - 2022-12-29 02:37:31 --> Total execution time: 0.0775
DEBUG - 2022-12-29 02:37:44 --> Total execution time: 0.0539
DEBUG - 2022-12-29 02:37:46 --> Total execution time: 0.0781
DEBUG - 2022-12-29 02:38:13 --> Total execution time: 0.0697
DEBUG - 2022-12-29 02:39:05 --> Total execution time: 0.0773
DEBUG - 2022-12-29 02:39:50 --> Total execution time: 0.0694
DEBUG - 2022-12-29 02:40:06 --> Total execution time: 0.0907
DEBUG - 2022-12-29 02:58:06 --> Total execution time: 0.0551
DEBUG - 2022-12-29 03:02:16 --> Total execution time: 0.0642
DEBUG - 2022-12-29 03:02:16 --> Total execution time: 0.1129
DEBUG - 2022-12-29 03:03:28 --> Total execution time: 0.0561
DEBUG - 2022-12-29 03:03:29 --> Total execution time: 0.0846
DEBUG - 2022-12-29 03:07:48 --> Total execution time: 0.1148
DEBUG - 2022-12-29 03:07:48 --> Total execution time: 0.0778
ERROR - 2022-12-29 03:12:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 58
ERROR - 2022-12-29 03:12:40 --> Severity: Notice --> Trying to get property 'p_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 58
DEBUG - 2022-12-29 03:12:40 --> Total execution time: 0.0771
ERROR - 2022-12-29 03:12:40 --> Severity: Notice --> Undefined variable: value C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 58
ERROR - 2022-12-29 03:12:40 --> Severity: Notice --> Trying to get property 'p_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 58
DEBUG - 2022-12-29 03:12:40 --> Total execution time: 0.0777
DEBUG - 2022-12-29 03:12:56 --> Total execution time: 0.0932
DEBUG - 2022-12-29 03:12:57 --> Total execution time: 0.0793
DEBUG - 2022-12-29 03:14:26 --> Total execution time: 0.0686
DEBUG - 2022-12-29 03:14:27 --> Total execution time: 0.0739
DEBUG - 2022-12-29 03:16:21 --> Total execution time: 0.0691
DEBUG - 2022-12-29 03:16:21 --> Total execution time: 0.0837
DEBUG - 2022-12-29 03:22:40 --> Total execution time: 0.0576
DEBUG - 2022-12-29 03:22:40 --> Total execution time: 0.0859
DEBUG - 2022-12-29 03:35:20 --> Total execution time: 0.0723
DEBUG - 2022-12-29 03:35:20 --> Total execution time: 0.0776
DEBUG - 2022-12-29 03:41:33 --> Total execution time: 0.0664
DEBUG - 2022-12-29 03:41:33 --> Total execution time: 0.0793
DEBUG - 2022-12-29 03:41:43 --> Total execution time: 0.0580
DEBUG - 2022-12-29 03:41:43 --> Total execution time: 0.0806
DEBUG - 2022-12-29 03:41:49 --> Total execution time: 0.0571
DEBUG - 2022-12-29 03:41:49 --> Total execution time: 0.0864
DEBUG - 2022-12-29 03:44:46 --> Total execution time: 0.0891
DEBUG - 2022-12-29 03:44:47 --> Total execution time: 0.0770
DEBUG - 2022-12-29 03:45:01 --> Total execution time: 0.0552
DEBUG - 2022-12-29 03:45:01 --> Total execution time: 0.0731
ERROR - 2022-12-29 03:51:22 --> Severity: error --> Exception: syntax error, unexpected '>', expecting end of file C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-edit.php 36
DEBUG - 2022-12-29 03:51:41 --> Total execution time: 0.0579
DEBUG - 2022-12-29 03:51:42 --> Total execution time: 0.1009
DEBUG - 2022-12-29 04:10:09 --> Total execution time: 0.0722
DEBUG - 2022-12-29 04:10:09 --> Total execution time: 0.0921
DEBUG - 2022-12-29 04:10:16 --> Total execution time: 0.0555
DEBUG - 2022-12-29 04:10:16 --> Total execution time: 0.0869
DEBUG - 2022-12-29 04:10:25 --> Total execution time: 0.0568
DEBUG - 2022-12-29 04:10:26 --> Total execution time: 0.0964
DEBUG - 2022-12-29 04:10:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 04:10:28 --> You did not select a file to upload.
DEBUG - 2022-12-29 04:19:38 --> Total execution time: 0.0610
DEBUG - 2022-12-29 04:19:38 --> Total execution time: 0.0823
DEBUG - 2022-12-29 04:20:00 --> Total execution time: 0.0878
DEBUG - 2022-12-29 04:20:00 --> Total execution time: 0.0782
DEBUG - 2022-12-29 04:22:49 --> Total execution time: 0.0688
DEBUG - 2022-12-29 04:22:49 --> Total execution time: 0.0901
DEBUG - 2022-12-29 04:22:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 04:22:55 --> You did not select a file to upload.
DEBUG - 2022-12-29 04:25:24 --> Total execution time: 0.0685
DEBUG - 2022-12-29 04:25:24 --> Total execution time: 0.0907
DEBUG - 2022-12-29 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 10:21:45 --> Total execution time: 0.0644
DEBUG - 2022-12-29 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:51:48 --> Total execution time: 0.0721
DEBUG - 2022-12-29 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:21:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:52:45 --> Total execution time: 0.1137
DEBUG - 2022-12-29 10:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:22:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:52:48 --> Total execution time: 0.0730
DEBUG - 2022-12-29 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:22:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:52:48 --> Total execution time: 0.0906
DEBUG - 2022-12-29 10:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:59:51 --> Total execution time: 0.0568
DEBUG - 2022-12-29 10:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:29:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:59:52 --> Total execution time: 0.0936
DEBUG - 2022-12-29 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 14:59:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 14:59:55 --> You did not select a file to upload.
ERROR - 2022-12-29 14:59:55 --> Severity: Notice --> Undefined variable: p_documents_path C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 187
DEBUG - 2022-12-29 14:59:55 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-29 14:59:55 --> The upload path does not appear to be valid.
ERROR - 2022-12-29 14:59:55 --> Severity: Notice --> Undefined variable: p_documents_path C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 187
DEBUG - 2022-12-29 14:59:55 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-29 14:59:55 --> The upload path does not appear to be valid.
DEBUG - 2022-12-29 10:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:04 --> Total execution time: 0.0528
DEBUG - 2022-12-29 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:05 --> Total execution time: 0.0824
DEBUG - 2022-12-29 10:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:07 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:00:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:07 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:00:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:07 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:10 --> Total execution time: 0.0525
DEBUG - 2022-12-29 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:11 --> Total execution time: 0.0798
DEBUG - 2022-12-29 10:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:00:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:17 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:00:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:17 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:00:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:00:17 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:01 --> Total execution time: 0.0544
DEBUG - 2022-12-29 10:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:01 --> Total execution time: 0.0738
DEBUG - 2022-12-29 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:14 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:14 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:14 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:14 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:14 --> Total execution time: 0.0506
DEBUG - 2022-12-29 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:33:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:14 --> Total execution time: 0.0831
DEBUG - 2022-12-29 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:22 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:22 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:22 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:03:22 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:03:22 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:22 --> Total execution time: 0.0750
DEBUG - 2022-12-29 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:33:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:03:23 --> Total execution time: 0.0821
DEBUG - 2022-12-29 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:05:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:05:26 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:05:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:05:26 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:05:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:05:26 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:05:27 --> Total execution time: 0.0550
DEBUG - 2022-12-29 10:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:35:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:05:27 --> Total execution time: 0.0867
DEBUG - 2022-12-29 10:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:09:35 --> Total execution time: 0.0736
DEBUG - 2022-12-29 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:39:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:09:36 --> Total execution time: 0.0802
DEBUG - 2022-12-29 10:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:09:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:09:40 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:09:40 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:09:41 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:09:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:09:41 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:09:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:09:41 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:09:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:09:41 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:09:41 --> Total execution time: 0.0606
DEBUG - 2022-12-29 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:39:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:09:41 --> Total execution time: 0.0771
DEBUG - 2022-12-29 10:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:01 --> Total execution time: 0.0567
DEBUG - 2022-12-29 10:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:41:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:01 --> Total execution time: 0.0882
DEBUG - 2022-12-29 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:15 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:15 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:15 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:15 --> Total execution time: 0.0513
DEBUG - 2022-12-29 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:41:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:15 --> Total execution time: 0.0753
DEBUG - 2022-12-29 10:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:21 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:21 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:21 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:21 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:21 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:21 --> Total execution time: 0.0546
DEBUG - 2022-12-29 10:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:41:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:22 --> Total execution time: 0.0868
DEBUG - 2022-12-29 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:39 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:39 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:39 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:11:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:11:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:39 --> Total execution time: 0.0516
DEBUG - 2022-12-29 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:41:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:39 --> Total execution time: 0.0836
DEBUG - 2022-12-29 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:59 --> Total execution time: 0.0616
DEBUG - 2022-12-29 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:41:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:11:59 --> Total execution time: 0.0810
DEBUG - 2022-12-29 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:12:04 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:12:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:12:04 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:12:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:12:04 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:12:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:12:04 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:12:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:12:04 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:04 --> Total execution time: 0.0557
DEBUG - 2022-12-29 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:42:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:04 --> Total execution time: 0.0745
DEBUG - 2022-12-29 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:14 --> Total execution time: 0.0543
DEBUG - 2022-12-29 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:42:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:16 --> Total execution time: 0.0919
DEBUG - 2022-12-29 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:52 --> Total execution time: 0.0554
DEBUG - 2022-12-29 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:42:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:12:53 --> Total execution time: 0.1121
DEBUG - 2022-12-29 10:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:13:25 --> Total execution time: 0.0728
DEBUG - 2022-12-29 10:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:43:36 --> UTF-8 Support Enabled
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:43:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:43:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:15:34 --> Total execution time: 0.0656
DEBUG - 2022-12-29 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:45:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:15:35 --> Total execution time: 0.0884
DEBUG - 2022-12-29 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:17:13 --> Total execution time: 0.0785
DEBUG - 2022-12-29 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:17:14 --> Total execution time: 0.0841
DEBUG - 2022-12-29 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:17:20 --> Total execution time: 0.0683
DEBUG - 2022-12-29 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:17:20 --> Total execution time: 0.0772
DEBUG - 2022-12-29 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:47:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:47:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:18:59 --> Total execution time: 0.0646
DEBUG - 2022-12-29 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:48:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:18:59 --> Total execution time: 0.0891
DEBUG - 2022-12-29 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:03 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:03 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:03 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:03 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:03 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:03 --> Total execution time: 0.0575
DEBUG - 2022-12-29 10:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:04 --> Total execution time: 0.0837
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:49:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:53 --> Total execution time: 0.0755
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:49:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:53 --> Total execution time: 0.1025
DEBUG - 2022-12-29 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:58 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:58 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:58 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:58 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:19:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:19:58 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:58 --> Total execution time: 0.0577
DEBUG - 2022-12-29 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:49:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:19:59 --> Total execution time: 0.0912
DEBUG - 2022-12-29 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:20:20 --> Total execution time: 0.0654
DEBUG - 2022-12-29 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:50:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:50:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:20:22 --> Total execution time: 0.0542
DEBUG - 2022-12-29 10:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:50:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:21:26 --> Total execution time: 0.0663
DEBUG - 2022-12-29 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:51:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:21:27 --> Total execution time: 0.0803
DEBUG - 2022-12-29 10:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:22:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:22:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:48 --> Total execution time: 0.1673
DEBUG - 2022-12-29 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:52:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:48 --> Total execution time: 0.0914
DEBUG - 2022-12-29 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:50 --> Total execution time: 0.0549
DEBUG - 2022-12-29 10:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:52:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:58 --> Total execution time: 0.1020
DEBUG - 2022-12-29 10:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:22:59 --> Total execution time: 0.0577
DEBUG - 2022-12-29 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:00 --> Total execution time: 0.0806
DEBUG - 2022-12-29 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:23:06 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:23:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:23:06 --> You did not select a file to upload.
DEBUG - 2022-12-29 15:23:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 15:23:06 --> You did not select a file to upload.
DEBUG - 2022-12-29 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:06 --> Total execution time: 0.0598
DEBUG - 2022-12-29 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:06 --> Total execution time: 0.0795
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:13 --> Total execution time: 0.0622
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:34 --> Total execution time: 0.0526
DEBUG - 2022-12-29 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:23:48 --> Total execution time: 0.0532
DEBUG - 2022-12-29 10:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:53:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:25:45 --> Total execution time: 0.0650
DEBUG - 2022-12-29 10:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:55:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:26:11 --> Total execution time: 0.0598
DEBUG - 2022-12-29 10:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:56:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:26:18 --> Total execution time: 0.0924
DEBUG - 2022-12-29 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:56:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 10:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 10:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:26:35 --> Total execution time: 0.0541
DEBUG - 2022-12-29 10:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 10:56:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 10:56:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:01:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 15:31:23 --> Severity: Notice --> Undefined property: Campaign_Controller::$posts C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 332
ERROR - 2022-12-29 15:31:23 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 332
DEBUG - 2022-12-29 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:31:28 --> Total execution time: 0.0578
DEBUG - 2022-12-29 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:01:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:36:41 --> Total execution time: 0.0603
DEBUG - 2022-12-29 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:06:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:37:34 --> Total execution time: 0.0601
DEBUG - 2022-12-29 11:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:07:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:37:48 --> Total execution time: 0.0678
DEBUG - 2022-12-29 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:07:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:37:52 --> Total execution time: 0.0693
DEBUG - 2022-12-29 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:07:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:07:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:37:57 --> Total execution time: 0.0612
DEBUG - 2022-12-29 11:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:07:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:07:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:00 --> Total execution time: 0.0869
DEBUG - 2022-12-29 11:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:08 --> Total execution time: 0.0669
DEBUG - 2022-12-29 11:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:19 --> Total execution time: 0.0705
DEBUG - 2022-12-29 11:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:23 --> Total execution time: 0.0703
DEBUG - 2022-12-29 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:08:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:29 --> Total execution time: 0.0757
DEBUG - 2022-12-29 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:08:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:38:32 --> Total execution time: 0.0877
DEBUG - 2022-12-29 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:08:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:43:25 --> Total execution time: 0.0734
DEBUG - 2022-12-29 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:13:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:13:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:44:28 --> Total execution time: 0.1019
DEBUG - 2022-12-29 11:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:44:37 --> Total execution time: 0.0691
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:37 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:14:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:38 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:45:00 --> Total execution time: 0.0783
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:15:00 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:15:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:15:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:15:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:15:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:15:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:47:14 --> Total execution time: 0.0716
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:14 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:17:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:17:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:17:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:19:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 60
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Trying to get property 'ul_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 60
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 62
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Trying to get property 'ul_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 62
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 62
ERROR - 2022-12-29 15:49:36 --> Severity: Notice --> Trying to get property 'ul_name' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\view\campaign-view.php 62
DEBUG - 2022-12-29 15:49:36 --> Total execution time: 0.1044
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:49:51 --> Total execution time: 0.1147
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:19:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:19:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:19:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:19:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:19:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:50:04 --> Total execution time: 0.1671
DEBUG - 2022-12-29 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:20:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:20:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:51:12 --> Total execution time: 0.0960
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:51:15 --> Total execution time: 0.1612
DEBUG - 2022-12-29 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:21:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:21:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:21:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:21:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:21:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:52:24 --> Total execution time: 0.0797
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:52:26 --> Total execution time: 0.0669
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:22:26 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-29 11:22:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:27 --> UTF-8 Support Enabled
ERROR - 2022-12-29 11:22:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 11:22:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:22:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:27:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 15:57:14 --> Query error: Table 'crowd_funding.w_fk_ul_id' doesn't exist - Invalid query: SELECT *
FROM `wallets`, `w_FK_ul_id`
DEBUG - 2022-12-29 11:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:27:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:27:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 15:57:40 --> Query error: Table 'crowd_funding.w_fk_ul_id' doesn't exist - Invalid query: SELECT *
FROM `wallets`, `w_FK_ul_id`
DEBUG - 2022-12-29 11:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:58:08 --> Total execution time: 0.0671
DEBUG - 2022-12-29 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 15:58:10 --> Total execution time: 0.0849
DEBUG - 2022-12-29 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:28:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 16:21:24 --> Total execution time: 0.0759
DEBUG - 2022-12-29 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:51:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 11:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 16:22:02 --> Total execution time: 0.0970
DEBUG - 2022-12-29 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 11:52:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 11:52:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:44:02 --> Total execution time: 0.2719
DEBUG - 2022-12-29 13:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:14:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:45:34 --> Total execution time: 0.0910
DEBUG - 2022-12-29 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:15:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:46:05 --> Total execution time: 0.0618
DEBUG - 2022-12-29 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:16:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:46:13 --> Total execution time: 0.0588
DEBUG - 2022-12-29 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:16:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:46:17 --> Total execution time: 0.0624
DEBUG - 2022-12-29 13:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:16:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:50:47 --> Total execution time: 0.0751
DEBUG - 2022-12-29 13:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:20:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:20:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:52:20 --> Total execution time: 0.0719
DEBUG - 2022-12-29 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:22:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:22:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:56:58 --> Total execution time: 0.0772
DEBUG - 2022-12-29 13:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:26:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:57:46 --> Total execution time: 0.0762
DEBUG - 2022-12-29 13:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:27:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:58:08 --> Total execution time: 0.0720
DEBUG - 2022-12-29 13:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:28:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:58:21 --> Total execution time: 0.0716
DEBUG - 2022-12-29 13:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:28:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:58:29 --> Total execution time: 0.0615
DEBUG - 2022-12-29 13:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:28:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:58:35 --> Total execution time: 0.0739
DEBUG - 2022-12-29 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:28:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:58:55 --> Total execution time: 0.0749
DEBUG - 2022-12-29 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:28:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:59:14 --> Total execution time: 0.0615
DEBUG - 2022-12-29 13:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:29:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:00:39 --> Total execution time: 0.0624
DEBUG - 2022-12-29 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:30:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:03:32 --> Total execution time: 0.0893
DEBUG - 2022-12-29 13:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:33:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:04:26 --> Total execution time: 0.0879
DEBUG - 2022-12-29 13:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:34:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:04:47 --> Total execution time: 0.0983
DEBUG - 2022-12-29 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:34:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:34:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:08:16 --> Total execution time: 0.0702
DEBUG - 2022-12-29 13:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:38:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:38:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:38:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:10:14 --> Total execution time: 0.0777
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:10:43 --> Total execution time: 0.0626
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:44 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:11:23 --> Total execution time: 0.0759
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:11:48 --> Total execution time: 0.0663
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:49 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:41:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:41:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:41:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:12:30 --> Total execution time: 0.0631
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:42:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:16:48 --> Total execution time: 0.0760
DEBUG - 2022-12-29 13:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:46:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:17:00 --> Total execution time: 0.0768
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:17:25 --> Total execution time: 0.0757
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:47:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:26 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:47:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:18:04 --> Total execution time: 0.0730
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:18:13 --> Total execution time: 0.0691
DEBUG - 2022-12-29 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:18:42 --> Total execution time: 0.0819
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:48:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:48:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:21:49 --> Total execution time: 0.0915
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:49 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:51:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:51:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:51:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:22:19 --> Total execution time: 0.0622
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:52:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:52:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:23:34 --> Total execution time: 0.1064
DEBUG - 2022-12-29 13:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:53:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:53:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:23:48 --> Total execution time: 0.0808
DEBUG - 2022-12-29 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:53:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:53:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:25:14 --> Total execution time: 0.0848
DEBUG - 2022-12-29 13:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:25:44 --> Total execution time: 0.0883
DEBUG - 2022-12-29 13:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 13:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 13:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 13:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:27:04 --> Total execution time: 0.0812
DEBUG - 2022-12-29 13:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 13:57:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 13:57:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:32:39 --> Total execution time: 0.0639
DEBUG - 2022-12-29 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:02:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:32:42 --> Total execution time: 0.0723
DEBUG - 2022-12-29 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:02:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:32:42 --> Total execution time: 0.1033
DEBUG - 2022-12-29 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 18:34:02 --> You did not select a file to upload.
DEBUG - 2022-12-29 18:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 18:34:02 --> You did not select a file to upload.
DEBUG - 2022-12-29 18:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 18:34:02 --> You did not select a file to upload.
DEBUG - 2022-12-29 18:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 18:34:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:34:02 --> Total execution time: 0.0608
DEBUG - 2022-12-29 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:04:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:34:02 --> Total execution time: 0.0960
DEBUG - 2022-12-29 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:34:03 --> Total execution time: 0.0607
DEBUG - 2022-12-29 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:04:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 14:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:34:06 --> Total execution time: 0.0639
DEBUG - 2022-12-29 14:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:04:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 14:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 14:07:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 17:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:57:25 --> Total execution time: 0.0674
DEBUG - 2022-12-29 17:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 17:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:27:27 --> Total execution time: 0.0617
DEBUG - 2022-12-29 17:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 17:57:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 17:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:27:48 --> Total execution time: 0.0640
DEBUG - 2022-12-29 17:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 17:57:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 17:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:28:16 --> Total execution time: 0.0726
DEBUG - 2022-12-29 17:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:58:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 17:58:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:28:23 --> Total execution time: 0.0605
DEBUG - 2022-12-29 17:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 17:58:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 17:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 17:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:29:19 --> Total execution time: 0.0641
DEBUG - 2022-12-29 17:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 17:59:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 17:59:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:33:35 --> Total execution time: 0.0620
DEBUG - 2022-12-29 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:03:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:03:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:27 --> Total execution time: 0.0617
DEBUG - 2022-12-29 18:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:04:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:29 --> Total execution time: 0.0805
DEBUG - 2022-12-29 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:04:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:31 --> Total execution time: 0.0728
DEBUG - 2022-12-29 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:04:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:31 --> Total execution time: 0.0973
DEBUG - 2022-12-29 18:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:50 --> Total execution time: 0.1047
DEBUG - 2022-12-29 18:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:04:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:34:59 --> Total execution time: 0.0645
DEBUG - 2022-12-29 18:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:04:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:35:27 --> Total execution time: 0.0701
DEBUG - 2022-12-29 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:05:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:05:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:06:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 22:36:40 --> Severity: Notice --> Undefined property: stdClass::$p_image_path C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-running-list.php 45
ERROR - 2022-12-29 22:36:40 --> Severity: Notice --> Undefined property: stdClass::$p_image C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-running-list.php 45
ERROR - 2022-12-29 22:36:40 --> Severity: Notice --> Undefined property: stdClass::$p_image_path C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-running-list.php 45
ERROR - 2022-12-29 22:36:40 --> Severity: Notice --> Undefined property: stdClass::$p_image C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-running-list.php 45
DEBUG - 2022-12-29 22:36:40 --> Total execution time: 0.1260
DEBUG - 2022-12-29 18:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:06:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:37:08 --> Total execution time: 0.0697
DEBUG - 2022-12-29 18:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:07:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:07:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:39:10 --> Total execution time: 0.0631
DEBUG - 2022-12-29 18:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:09:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:39:44 --> Total execution time: 0.0884
DEBUG - 2022-12-29 18:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:09:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:09:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:41:01 --> Total execution time: 0.0886
DEBUG - 2022-12-29 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:11:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:41:04 --> Total execution time: 0.0752
DEBUG - 2022-12-29 18:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:11:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:41:14 --> Total execution time: 0.0587
DEBUG - 2022-12-29 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:11:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:41:26 --> Total execution time: 0.0615
DEBUG - 2022-12-29 18:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:11:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:11:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:44:20 --> Total execution time: 0.0874
DEBUG - 2022-12-29 18:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:14:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:44:26 --> Total execution time: 0.0649
DEBUG - 2022-12-29 18:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:14:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:44:26 --> Total execution time: 0.0846
DEBUG - 2022-12-29 18:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 22:45:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:47 --> Total execution time: 0.0942
DEBUG - 2022-12-29 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:47 --> Total execution time: 0.1053
DEBUG - 2022-12-29 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:49 --> Total execution time: 0.0665
DEBUG - 2022-12-29 18:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:50 --> Total execution time: 0.0781
DEBUG - 2022-12-29 18:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:52 --> Total execution time: 0.0789
DEBUG - 2022-12-29 18:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:55 --> Total execution time: 0.0736
DEBUG - 2022-12-29 18:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:45:56 --> Total execution time: 0.0591
DEBUG - 2022-12-29 18:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:15:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:27:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 22:57:04 --> Severity: Notice --> Undefined property: Campaign_Controller::$Promoitions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 355
ERROR - 2022-12-29 22:57:04 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 355
DEBUG - 2022-12-29 18:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 22:59:47 --> Total execution time: 0.0947
DEBUG - 2022-12-29 18:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:29:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:11 --> Total execution time: 0.1030
DEBUG - 2022-12-29 18:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:31:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:16 --> Total execution time: 0.1066
DEBUG - 2022-12-29 18:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:31:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:18 --> Total execution time: 0.1078
DEBUG - 2022-12-29 18:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:19 --> Total execution time: 0.0678
DEBUG - 2022-12-29 18:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:31:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:19 --> Total execution time: 0.0896
DEBUG - 2022-12-29 18:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 23:01:23 --> You did not select a file to upload.
DEBUG - 2022-12-29 23:01:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-29 23:01:23 --> You did not select a file to upload.
DEBUG - 2022-12-29 18:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:23 --> Total execution time: 0.0655
DEBUG - 2022-12-29 18:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:31:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:24 --> Total execution time: 0.1080
DEBUG - 2022-12-29 18:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:01:26 --> Total execution time: 0.0701
DEBUG - 2022-12-29 18:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:31:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:31:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:02:20 --> Total execution time: 0.0694
DEBUG - 2022-12-29 18:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:32:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:32:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:04:38 --> Total execution time: 0.0871
DEBUG - 2022-12-29 18:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:34:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:05:11 --> Total execution time: 0.0652
DEBUG - 2022-12-29 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:35:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:35:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:07:44 --> Total execution time: 0.0764
DEBUG - 2022-12-29 18:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:37:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:37:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 18:38:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 18:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:09:11 --> Total execution time: 0.0908
DEBUG - 2022-12-29 18:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:39:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:39:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:09:21 --> Total execution time: 0.0696
DEBUG - 2022-12-29 18:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:39:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:39:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:39:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 23:09:41 --> Severity: Notice --> Undefined property: Campaign_Controller::$Promoitions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 368
ERROR - 2022-12-29 23:09:41 --> Severity: error --> Exception: Call to a member function updateWhere() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\campaign\Campaign_Controller.php 368
DEBUG - 2022-12-29 18:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:10:06 --> Total execution time: 0.0652
DEBUG - 2022-12-29 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:10:10 --> Total execution time: 0.0650
DEBUG - 2022-12-29 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:40:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:40:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:10:23 --> Total execution time: 0.0686
DEBUG - 2022-12-29 18:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:40:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 23:15:05 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 52
ERROR - 2022-12-29 23:15:05 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 52
ERROR - 2022-12-29 23:15:05 --> Severity: Notice --> Undefined variable: list C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 52
ERROR - 2022-12-29 23:15:05 --> Severity: Notice --> Trying to get property 'p_title' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\campaign\campaign-promotion.php 52
DEBUG - 2022-12-29 23:15:05 --> Total execution time: 0.1039
DEBUG - 2022-12-29 18:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:45:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:15:35 --> Total execution time: 0.0734
DEBUG - 2022-12-29 18:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:45:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:15:50 --> Total execution time: 0.0676
DEBUG - 2022-12-29 18:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:45:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 18:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:15:57 --> Total execution time: 0.0691
DEBUG - 2022-12-29 18:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:45:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:16:17 --> Total execution time: 0.0767
DEBUG - 2022-12-29 18:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:46:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:26:24 --> Total execution time: 0.0716
DEBUG - 2022-12-29 18:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:56:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:26:25 --> Total execution time: 0.0602
DEBUG - 2022-12-29 18:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:56:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 18:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 18:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 18:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:28:38 --> Total execution time: 0.0754
DEBUG - 2022-12-29 18:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 18:58:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 18:58:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:35:01 --> Total execution time: 0.0850
DEBUG - 2022-12-29 19:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:05:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:02 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:24:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:05 --> Severity: Compile Error --> Cannot redeclare admin_get_running_campaign_list() (previously declared in C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php:71) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 129
DEBUG - 2022-12-29 19:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:33 --> Severity: Compile Error --> Cannot redeclare admin_get_running_campaign_list() (previously declared in C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php:71) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 129
DEBUG - 2022-12-29 19:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:24:50 --> Severity: Compile Error --> Cannot redeclare admin_get_running_campaign_list() (previously declared in C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php:71) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 129
DEBUG - 2022-12-29 19:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:14 --> Severity: Compile Error --> Cannot redeclare admin_get_running_campaign_list() (previously declared in C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php:71) C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 129
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:55:54 --> Total execution time: 0.0866
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:25:54 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:25:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 23:56:04 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::like_or() C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 135
DEBUG - 2022-12-29 19:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-29 23:56:08 --> Severity: error --> Exception: Call to undefined method CI_DB_mysqli_driver::like_or() C:\xampp\htdocs\gopal\crowd_funding\application\helpers\admin_helper.php 135
DEBUG - 2022-12-29 19:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:20 --> Total execution time: 0.0877
DEBUG - 2022-12-29 19:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:24 --> Total execution time: 0.0581
DEBUG - 2022-12-29 19:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:26 --> Total execution time: 0.0847
DEBUG - 2022-12-29 19:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:26 --> Total execution time: 0.0688
DEBUG - 2022-12-29 19:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:29 --> Total execution time: 0.0673
DEBUG - 2022-12-29 19:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:29 --> Total execution time: 0.0822
DEBUG - 2022-12-29 19:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:35 --> Total execution time: 0.0807
DEBUG - 2022-12-29 19:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:35 --> Total execution time: 0.0681
DEBUG - 2022-12-29 19:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:36 --> Total execution time: 0.0736
DEBUG - 2022-12-29 19:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:36 --> Total execution time: 0.0694
DEBUG - 2022-12-29 19:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:37 --> Total execution time: 0.0779
DEBUG - 2022-12-29 19:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:44 --> Total execution time: 0.0694
DEBUG - 2022-12-29 19:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:45 --> Total execution time: 0.0871
DEBUG - 2022-12-29 19:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:56:51 --> Total execution time: 0.0641
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:26:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-29 19:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:57:12 --> Total execution time: 0.0799
DEBUG - 2022-12-29 19:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:27:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:27:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 23:57:30 --> Total execution time: 0.0794
DEBUG - 2022-12-29 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:27:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:39:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:39:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:42:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:42:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:42:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:42:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:42:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:42:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:43:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:45:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:46:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:48:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:53:14 --> Severity: error --> Exception: syntax error, unexpected '$don_phone' (T_VARIABLE) C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Donate_Controller.php 27
DEBUG - 2022-12-29 19:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:53:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:53:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:54:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:54:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:54:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 19:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 19:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 19:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 19:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 19:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 19:55:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:22:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:23:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:23:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:23:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:24:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:27:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:27:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:28:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:28:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:29:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:29:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:30:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:30:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:31:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:31:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:33:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:33:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:33:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:33:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-29 21:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-29 21:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-29 21:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-29 21:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-29 21:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-29 21:34:01 --> 404 Page Not Found: Assets/website_esa
