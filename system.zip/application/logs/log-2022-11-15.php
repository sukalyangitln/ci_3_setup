<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-15 00:00:00 --> Total execution time: 0.2626
DEBUG - 2022-11-15 00:00:01 --> Total execution time: 0.1738
DEBUG - 2022-11-15 00:00:08 --> Total execution time: 0.1670
DEBUG - 2022-11-15 00:00:17 --> Total execution time: 0.1751
DEBUG - 2022-11-15 00:00:37 --> Total execution time: 0.2767
DEBUG - 2022-11-15 00:01:37 --> Total execution time: 0.1688
DEBUG - 2022-11-15 00:01:43 --> Total execution time: 0.1229
DEBUG - 2022-11-15 00:02:11 --> Total execution time: 0.1669
DEBUG - 2022-11-15 00:02:29 --> Total execution time: 0.1258
DEBUG - 2022-11-15 00:04:01 --> Total execution time: 0.1713
DEBUG - 2022-11-15 00:09:08 --> Total execution time: 0.2034
DEBUG - 2022-11-15 00:09:13 --> Total execution time: 0.2032
DEBUG - 2022-11-15 00:09:16 --> Total execution time: 0.1814
DEBUG - 2022-11-15 00:09:25 --> Total execution time: 0.1919
DEBUG - 2022-11-15 00:12:33 --> Total execution time: 0.4438
DEBUG - 2022-11-15 00:16:09 --> Total execution time: 0.1956
DEBUG - 2022-11-15 00:20:31 --> Total execution time: 0.1389
DEBUG - 2022-11-15 00:20:31 --> Total execution time: 0.1087
DEBUG - 2022-11-15 00:22:13 --> Total execution time: 0.1088
DEBUG - 2022-11-15 00:22:13 --> Total execution time: 0.1054
DEBUG - 2022-11-15 00:22:22 --> Total execution time: 0.1981
DEBUG - 2022-11-15 00:22:29 --> Total execution time: 0.1887
DEBUG - 2022-11-15 00:22:33 --> Total execution time: 0.1787
DEBUG - 2022-11-15 00:22:38 --> Total execution time: 0.2433
DEBUG - 2022-11-15 00:22:48 --> Total execution time: 0.1857
DEBUG - 2022-11-15 00:23:16 --> Total execution time: 0.1100
DEBUG - 2022-11-15 00:23:23 --> Total execution time: 0.1709
DEBUG - 2022-11-15 00:23:26 --> Total execution time: 0.1088
DEBUG - 2022-11-15 00:23:27 --> Total execution time: 0.1144
DEBUG - 2022-11-15 00:23:29 --> Total execution time: 0.2283
DEBUG - 2022-11-15 00:23:35 --> Total execution time: 0.2232
DEBUG - 2022-11-15 00:23:36 --> Total execution time: 0.1783
DEBUG - 2022-11-15 00:23:44 --> Total execution time: 0.1834
DEBUG - 2022-11-15 00:23:59 --> Total execution time: 0.1823
DEBUG - 2022-11-15 00:24:02 --> Total execution time: 0.1930
DEBUG - 2022-11-15 00:24:08 --> Total execution time: 0.1756
DEBUG - 2022-11-15 00:24:16 --> Total execution time: 0.1783
DEBUG - 2022-11-15 00:24:23 --> Total execution time: 0.1746
DEBUG - 2022-11-15 00:24:48 --> Total execution time: 0.2645
DEBUG - 2022-11-15 00:25:01 --> Total execution time: 0.2336
DEBUG - 2022-11-15 00:25:30 --> Total execution time: 0.2364
DEBUG - 2022-11-15 00:25:58 --> Total execution time: 0.1797
DEBUG - 2022-11-15 00:26:21 --> Total execution time: 0.1137
DEBUG - 2022-11-15 00:26:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-15 00:26:30 --> Total execution time: 0.2018
DEBUG - 2022-11-15 00:26:40 --> Total execution time: 0.2055
DEBUG - 2022-11-15 00:26:52 --> Total execution time: 0.1976
DEBUG - 2022-11-15 00:27:07 --> Total execution time: 0.2042
DEBUG - 2022-11-15 00:27:11 --> Total execution time: 0.2113
DEBUG - 2022-11-15 00:27:17 --> Total execution time: 0.2044
DEBUG - 2022-11-15 00:27:36 --> Total execution time: 0.1830
DEBUG - 2022-11-15 00:27:47 --> Total execution time: 0.1898
DEBUG - 2022-11-15 00:27:51 --> Total execution time: 0.1984
DEBUG - 2022-11-15 00:27:59 --> Total execution time: 0.2638
DEBUG - 2022-11-15 00:29:09 --> Total execution time: 0.4833
DEBUG - 2022-11-15 00:29:13 --> Total execution time: 0.1974
DEBUG - 2022-11-15 00:29:17 --> Total execution time: 0.2701
DEBUG - 2022-11-15 00:29:25 --> Total execution time: 0.2671
DEBUG - 2022-11-15 00:30:02 --> Total execution time: 0.4826
DEBUG - 2022-11-15 00:30:29 --> Total execution time: 0.2033
DEBUG - 2022-11-15 00:30:33 --> Total execution time: 0.1950
DEBUG - 2022-11-15 00:31:02 --> Total execution time: 0.1853
DEBUG - 2022-11-15 00:31:07 --> Total execution time: 0.5437
DEBUG - 2022-11-15 00:31:07 --> Total execution time: 0.5614
DEBUG - 2022-11-15 00:33:03 --> Total execution time: 0.1908
DEBUG - 2022-11-15 00:35:31 --> Total execution time: 0.1303
DEBUG - 2022-11-15 00:40:50 --> Total execution time: 0.9101
DEBUG - 2022-11-15 00:42:17 --> Total execution time: 0.1315
DEBUG - 2022-11-15 00:43:47 --> Total execution time: 0.1141
DEBUG - 2022-11-15 00:44:05 --> Total execution time: 0.1095
DEBUG - 2022-11-15 00:45:31 --> Total execution time: 0.1721
DEBUG - 2022-11-15 00:46:21 --> Total execution time: 0.1928
DEBUG - 2022-11-15 00:46:35 --> Total execution time: 0.1988
DEBUG - 2022-11-15 00:47:06 --> Total execution time: 0.2004
DEBUG - 2022-11-15 00:47:31 --> Total execution time: 0.1863
DEBUG - 2022-11-15 00:47:32 --> Total execution time: 0.2338
DEBUG - 2022-11-15 00:47:33 --> Total execution time: 0.2125
DEBUG - 2022-11-15 00:47:46 --> Total execution time: 0.2489
DEBUG - 2022-11-15 00:48:03 --> Total execution time: 0.1685
DEBUG - 2022-11-15 00:48:05 --> Total execution time: 0.1754
DEBUG - 2022-11-15 00:53:42 --> Total execution time: 1.0112
DEBUG - 2022-11-15 00:53:48 --> Total execution time: 0.1820
DEBUG - 2022-11-15 00:54:27 --> Total execution time: 0.1175
DEBUG - 2022-11-15 00:55:12 --> Total execution time: 0.1702
DEBUG - 2022-11-15 01:15:53 --> Total execution time: 0.5673
DEBUG - 2022-11-15 01:20:31 --> Total execution time: 0.1257
DEBUG - 2022-11-15 01:24:39 --> Total execution time: 0.4992
DEBUG - 2022-11-15 01:30:03 --> Total execution time: 1.2320
DEBUG - 2022-11-15 01:45:22 --> Total execution time: 0.4934
DEBUG - 2022-11-15 01:47:51 --> Total execution time: 0.2329
DEBUG - 2022-11-15 01:47:51 --> Total execution time: 0.3697
DEBUG - 2022-11-15 01:47:52 --> Total execution time: 0.3099
DEBUG - 2022-11-15 01:48:45 --> Total execution time: 0.1117
DEBUG - 2022-11-15 01:49:27 --> Total execution time: 0.1173
DEBUG - 2022-11-15 01:50:31 --> Total execution time: 0.1141
DEBUG - 2022-11-15 02:12:23 --> Total execution time: 0.5434
DEBUG - 2022-11-15 02:12:39 --> Total execution time: 0.1747
DEBUG - 2022-11-15 02:12:44 --> Total execution time: 0.1756
DEBUG - 2022-11-15 02:12:51 --> Total execution time: 0.1932
DEBUG - 2022-11-15 02:13:07 --> Total execution time: 0.1726
DEBUG - 2022-11-15 02:14:09 --> Total execution time: 0.2034
DEBUG - 2022-11-15 02:14:29 --> Total execution time: 0.1697
DEBUG - 2022-11-15 02:30:02 --> Total execution time: 0.6512
DEBUG - 2022-11-15 02:30:24 --> Total execution time: 0.1321
DEBUG - 2022-11-15 02:42:20 --> Total execution time: 1.2091
DEBUG - 2022-11-15 02:53:30 --> Total execution time: 0.5823
DEBUG - 2022-11-15 02:57:39 --> Total execution time: 0.9105
DEBUG - 2022-11-15 03:08:51 --> Total execution time: 0.1951
DEBUG - 2022-11-15 03:20:21 --> Total execution time: 0.5934
DEBUG - 2022-11-15 03:20:22 --> Total execution time: 0.1657
DEBUG - 2022-11-15 03:20:44 --> Total execution time: 0.1063
DEBUG - 2022-11-15 03:21:30 --> Total execution time: 0.1751
DEBUG - 2022-11-15 03:30:05 --> Total execution time: 3.3381
DEBUG - 2022-11-15 03:40:22 --> Total execution time: 0.1119
DEBUG - 2022-11-15 03:59:12 --> Total execution time: 0.6386
DEBUG - 2022-11-15 04:24:31 --> Total execution time: 0.5447
DEBUG - 2022-11-15 04:27:44 --> Total execution time: 0.7424
DEBUG - 2022-11-15 04:27:45 --> Total execution time: 0.1313
DEBUG - 2022-11-15 04:27:47 --> Total execution time: 0.1741
DEBUG - 2022-11-15 04:27:50 --> Total execution time: 0.1396
DEBUG - 2022-11-15 04:28:16 --> Total execution time: 0.1332
DEBUG - 2022-11-15 04:30:02 --> Total execution time: 0.1900
DEBUG - 2022-11-15 04:31:53 --> Total execution time: 0.1222
DEBUG - 2022-11-15 04:55:58 --> Total execution time: 0.4703
DEBUG - 2022-11-15 05:07:24 --> Total execution time: 0.6906
DEBUG - 2022-11-15 05:12:19 --> Total execution time: 0.4863
DEBUG - 2022-11-15 05:20:30 --> Total execution time: 0.4910
DEBUG - 2022-11-15 05:22:33 --> Total execution time: 0.1193
DEBUG - 2022-11-15 05:22:49 --> Total execution time: 0.1813
DEBUG - 2022-11-15 05:23:16 --> Total execution time: 0.2030
DEBUG - 2022-11-15 05:23:38 --> Total execution time: 0.2049
DEBUG - 2022-11-15 05:23:45 --> Total execution time: 0.2297
DEBUG - 2022-11-15 05:25:47 --> Total execution time: 0.1247
DEBUG - 2022-11-15 05:26:06 --> Total execution time: 0.1774
DEBUG - 2022-11-15 05:27:43 --> Total execution time: 0.1887
DEBUG - 2022-11-15 05:30:02 --> Total execution time: 0.1787
DEBUG - 2022-11-15 05:52:44 --> Total execution time: 0.5900
DEBUG - 2022-11-15 06:02:16 --> Total execution time: 0.5325
DEBUG - 2022-11-15 06:02:28 --> Total execution time: 0.2364
DEBUG - 2022-11-15 06:02:42 --> Total execution time: 0.1913
DEBUG - 2022-11-15 06:06:13 --> Total execution time: 0.5003
DEBUG - 2022-11-15 06:11:17 --> Total execution time: 0.1810
DEBUG - 2022-11-15 06:11:30 --> Total execution time: 0.1902
DEBUG - 2022-11-15 06:11:38 --> Total execution time: 0.2073
DEBUG - 2022-11-15 06:12:03 --> Total execution time: 0.1959
DEBUG - 2022-11-15 06:12:04 --> Total execution time: 0.1320
DEBUG - 2022-11-15 06:12:37 --> Total execution time: 0.1158
DEBUG - 2022-11-15 06:14:17 --> Total execution time: 0.3952
DEBUG - 2022-11-15 06:14:34 --> Total execution time: 0.1799
DEBUG - 2022-11-15 06:14:50 --> Total execution time: 0.2057
DEBUG - 2022-11-15 06:14:51 --> Total execution time: 0.1731
DEBUG - 2022-11-15 06:15:06 --> Total execution time: 0.2228
DEBUG - 2022-11-15 06:15:23 --> Total execution time: 0.2762
DEBUG - 2022-11-15 06:19:30 --> Total execution time: 0.1075
DEBUG - 2022-11-15 06:19:40 --> Total execution time: 0.1228
DEBUG - 2022-11-15 06:21:40 --> Total execution time: 0.1117
DEBUG - 2022-11-15 06:25:38 --> Total execution time: 0.1799
DEBUG - 2022-11-15 06:29:49 --> Total execution time: 0.1698
DEBUG - 2022-11-15 06:29:53 --> Total execution time: 0.1148
DEBUG - 2022-11-15 06:30:02 --> Total execution time: 0.1675
DEBUG - 2022-11-15 06:30:05 --> Total execution time: 0.2543
DEBUG - 2022-11-15 06:30:08 --> Total execution time: 0.1796
DEBUG - 2022-11-15 06:30:08 --> Total execution time: 0.2303
DEBUG - 2022-11-15 06:30:12 --> Total execution time: 0.1937
DEBUG - 2022-11-15 06:31:39 --> Total execution time: 0.1162
DEBUG - 2022-11-15 06:31:55 --> Total execution time: 0.1698
DEBUG - 2022-11-15 06:31:59 --> Total execution time: 0.1707
DEBUG - 2022-11-15 06:32:41 --> Total execution time: 0.1721
DEBUG - 2022-11-15 06:33:36 --> Total execution time: 0.1791
DEBUG - 2022-11-15 06:33:48 --> Total execution time: 0.1736
DEBUG - 2022-11-15 06:33:59 --> Total execution time: 0.1890
DEBUG - 2022-11-15 06:34:00 --> Total execution time: 0.1699
DEBUG - 2022-11-15 06:34:50 --> Total execution time: 0.1712
DEBUG - 2022-11-15 06:34:53 --> Total execution time: 0.2167
DEBUG - 2022-11-15 06:35:16 --> Total execution time: 0.2173
DEBUG - 2022-11-15 06:35:29 --> Total execution time: 0.1797
DEBUG - 2022-11-15 06:35:34 --> Total execution time: 0.1888
DEBUG - 2022-11-15 06:35:46 --> Total execution time: 0.1737
DEBUG - 2022-11-15 06:36:12 --> Total execution time: 0.1786
DEBUG - 2022-11-15 06:36:18 --> Total execution time: 0.1727
DEBUG - 2022-11-15 06:36:20 --> Total execution time: 0.1879
DEBUG - 2022-11-15 06:36:22 --> Total execution time: 0.1735
DEBUG - 2022-11-15 06:36:24 --> Total execution time: 0.1716
DEBUG - 2022-11-15 06:36:26 --> Total execution time: 0.1737
DEBUG - 2022-11-15 06:36:28 --> Total execution time: 0.1659
DEBUG - 2022-11-15 06:36:29 --> Total execution time: 0.1650
DEBUG - 2022-11-15 06:37:06 --> Total execution time: 2.6548
DEBUG - 2022-11-15 06:37:45 --> Total execution time: 0.1696
DEBUG - 2022-11-15 06:41:51 --> Total execution time: 0.1783
DEBUG - 2022-11-15 06:42:00 --> Total execution time: 0.2061
DEBUG - 2022-11-15 06:42:06 --> Total execution time: 0.1974
DEBUG - 2022-11-15 06:42:09 --> Total execution time: 0.1903
DEBUG - 2022-11-15 06:44:08 --> Total execution time: 0.1321
DEBUG - 2022-11-15 06:44:52 --> Total execution time: 0.1687
DEBUG - 2022-11-15 06:45:59 --> Total execution time: 0.1140
DEBUG - 2022-11-15 06:47:55 --> Total execution time: 0.1670
DEBUG - 2022-11-15 06:48:04 --> Total execution time: 0.4988
DEBUG - 2022-11-15 06:48:07 --> Total execution time: 0.2382
DEBUG - 2022-11-15 06:48:15 --> Total execution time: 0.1850
DEBUG - 2022-11-15 06:48:16 --> Total execution time: 0.1944
DEBUG - 2022-11-15 06:48:16 --> Total execution time: 0.1835
DEBUG - 2022-11-15 06:48:32 --> Total execution time: 0.1685
DEBUG - 2022-11-15 06:51:47 --> Total execution time: 1.4513
DEBUG - 2022-11-15 06:52:22 --> Total execution time: 0.1897
DEBUG - 2022-11-15 06:52:33 --> Total execution time: 0.1929
DEBUG - 2022-11-15 06:52:47 --> Total execution time: 0.2127
DEBUG - 2022-11-15 06:52:54 --> Total execution time: 0.1719
DEBUG - 2022-11-15 06:52:55 --> Total execution time: 0.1736
DEBUG - 2022-11-15 06:52:55 --> Total execution time: 0.1647
DEBUG - 2022-11-15 06:56:24 --> Total execution time: 0.1806
DEBUG - 2022-11-15 06:58:26 --> Total execution time: 0.1080
DEBUG - 2022-11-15 06:59:41 --> Total execution time: 0.5462
DEBUG - 2022-11-15 07:00:11 --> Total execution time: 0.1676
DEBUG - 2022-11-15 07:03:21 --> Total execution time: 0.2398
DEBUG - 2022-11-15 07:03:54 --> Total execution time: 0.4661
DEBUG - 2022-11-15 07:04:48 --> Total execution time: 0.2057
DEBUG - 2022-11-15 07:05:08 --> Total execution time: 0.1839
DEBUG - 2022-11-15 07:06:35 --> Total execution time: 0.2138
DEBUG - 2022-11-15 07:08:36 --> Total execution time: 0.6537
DEBUG - 2022-11-15 07:18:19 --> Total execution time: 0.1730
DEBUG - 2022-11-15 07:18:36 --> Total execution time: 0.2022
DEBUG - 2022-11-15 07:19:02 --> Total execution time: 0.1841
DEBUG - 2022-11-15 07:19:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-15 07:19:54 --> Total execution time: 0.1823
DEBUG - 2022-11-15 07:20:16 --> Total execution time: 0.1904
DEBUG - 2022-11-15 07:21:05 --> Total execution time: 0.1980
DEBUG - 2022-11-15 07:21:24 --> Total execution time: 0.1794
DEBUG - 2022-11-15 07:21:35 --> Total execution time: 0.1686
DEBUG - 2022-11-15 07:23:20 --> Total execution time: 0.1131
DEBUG - 2022-11-15 07:30:03 --> Total execution time: 0.8395
DEBUG - 2022-11-15 07:30:49 --> Total execution time: 0.1707
DEBUG - 2022-11-15 07:30:59 --> Total execution time: 0.1942
DEBUG - 2022-11-15 07:31:00 --> Total execution time: 0.1675
DEBUG - 2022-11-15 07:31:09 --> Total execution time: 0.2049
DEBUG - 2022-11-15 07:31:13 --> Total execution time: 0.2218
DEBUG - 2022-11-15 07:31:21 --> Total execution time: 0.1701
DEBUG - 2022-11-15 07:31:21 --> Total execution time: 0.1146
DEBUG - 2022-11-15 07:31:42 --> Total execution time: 0.2021
DEBUG - 2022-11-15 07:31:48 --> Total execution time: 0.1816
DEBUG - 2022-11-15 07:31:49 --> Total execution time: 0.1778
DEBUG - 2022-11-15 07:31:54 --> Total execution time: 0.1631
DEBUG - 2022-11-15 07:32:35 --> Total execution time: 0.1077
DEBUG - 2022-11-15 07:32:41 --> Total execution time: 0.1708
DEBUG - 2022-11-15 07:33:03 --> Total execution time: 0.1149
DEBUG - 2022-11-15 07:33:27 --> Total execution time: 0.1060
DEBUG - 2022-11-15 07:33:28 --> Total execution time: 0.1060
DEBUG - 2022-11-15 07:34:34 --> Total execution time: 0.1731
DEBUG - 2022-11-15 07:34:40 --> Total execution time: 0.2073
DEBUG - 2022-11-15 07:34:46 --> Total execution time: 0.2213
DEBUG - 2022-11-15 07:34:46 --> Total execution time: 0.2792
DEBUG - 2022-11-15 07:34:54 --> Total execution time: 0.4541
DEBUG - 2022-11-15 07:35:12 --> Total execution time: 0.1777
DEBUG - 2022-11-15 07:35:19 --> Total execution time: 0.1060
DEBUG - 2022-11-15 07:35:50 --> Total execution time: 0.1362
DEBUG - 2022-11-15 07:36:07 --> Total execution time: 0.4760
DEBUG - 2022-11-15 07:36:17 --> Total execution time: 0.1918
DEBUG - 2022-11-15 07:36:24 --> Total execution time: 0.2165
DEBUG - 2022-11-15 07:36:29 --> Total execution time: 0.2084
DEBUG - 2022-11-15 07:36:51 --> Total execution time: 0.1926
DEBUG - 2022-11-15 07:37:01 --> Total execution time: 0.1784
DEBUG - 2022-11-15 07:37:08 --> Total execution time: 0.2565
DEBUG - 2022-11-15 07:37:09 --> Total execution time: 0.2573
DEBUG - 2022-11-15 07:37:13 --> Total execution time: 0.1736
DEBUG - 2022-11-15 07:37:22 --> Total execution time: 0.1751
DEBUG - 2022-11-15 07:37:36 --> Total execution time: 0.4871
DEBUG - 2022-11-15 07:37:42 --> Total execution time: 0.1778
DEBUG - 2022-11-15 07:37:49 --> Total execution time: 0.1682
DEBUG - 2022-11-15 07:38:11 --> Total execution time: 0.2150
DEBUG - 2022-11-15 07:38:14 --> Total execution time: 0.1720
DEBUG - 2022-11-15 07:38:22 --> Total execution time: 0.1734
DEBUG - 2022-11-15 07:38:30 --> Total execution time: 0.1892
DEBUG - 2022-11-15 07:38:30 --> Total execution time: 0.1996
DEBUG - 2022-11-15 07:38:37 --> Total execution time: 0.1698
DEBUG - 2022-11-15 07:38:41 --> Total execution time: 0.1707
DEBUG - 2022-11-15 07:38:45 --> Total execution time: 0.2152
DEBUG - 2022-11-15 07:39:00 --> Total execution time: 0.2470
DEBUG - 2022-11-15 07:39:14 --> Total execution time: 0.3541
DEBUG - 2022-11-15 07:39:35 --> Total execution time: 2.1954
DEBUG - 2022-11-15 07:39:52 --> Total execution time: 0.5043
DEBUG - 2022-11-15 07:39:58 --> Total execution time: 0.1069
DEBUG - 2022-11-15 07:40:04 --> Total execution time: 0.1806
DEBUG - 2022-11-15 07:40:17 --> Total execution time: 0.1851
DEBUG - 2022-11-15 07:40:23 --> Total execution time: 0.2145
DEBUG - 2022-11-15 07:40:44 --> Total execution time: 0.1730
DEBUG - 2022-11-15 07:40:48 --> Total execution time: 0.1662
DEBUG - 2022-11-15 07:40:52 --> Total execution time: 0.1832
DEBUG - 2022-11-15 07:41:01 --> Total execution time: 0.1882
DEBUG - 2022-11-15 07:41:02 --> Total execution time: 0.1784
DEBUG - 2022-11-15 07:41:15 --> Total execution time: 0.1732
DEBUG - 2022-11-15 07:41:21 --> Total execution time: 0.2536
DEBUG - 2022-11-15 07:41:32 --> Total execution time: 0.1923
DEBUG - 2022-11-15 07:41:39 --> Total execution time: 0.1855
DEBUG - 2022-11-15 07:41:43 --> Total execution time: 0.2515
DEBUG - 2022-11-15 07:41:49 --> Total execution time: 0.2301
DEBUG - 2022-11-15 07:42:06 --> Total execution time: 0.2427
DEBUG - 2022-11-15 07:42:11 --> Total execution time: 0.1781
DEBUG - 2022-11-15 07:42:50 --> Total execution time: 0.1732
DEBUG - 2022-11-15 07:43:08 --> Total execution time: 0.2120
DEBUG - 2022-11-15 07:43:15 --> Total execution time: 0.1879
DEBUG - 2022-11-15 07:43:18 --> Total execution time: 0.1850
DEBUG - 2022-11-15 07:43:22 --> Total execution time: 0.2118
DEBUG - 2022-11-15 07:43:22 --> Total execution time: 0.2125
DEBUG - 2022-11-15 07:43:23 --> Total execution time: 0.5215
DEBUG - 2022-11-15 07:43:39 --> Total execution time: 0.2086
DEBUG - 2022-11-15 07:43:52 --> Total execution time: 0.1658
DEBUG - 2022-11-15 07:43:52 --> Total execution time: 0.1994
DEBUG - 2022-11-15 07:44:02 --> Total execution time: 0.2898
DEBUG - 2022-11-15 07:44:08 --> Total execution time: 0.1635
DEBUG - 2022-11-15 07:44:09 --> Total execution time: 0.1633
DEBUG - 2022-11-15 07:44:09 --> Total execution time: 0.1754
DEBUG - 2022-11-15 07:44:19 --> Total execution time: 0.1764
DEBUG - 2022-11-15 07:44:28 --> Total execution time: 0.1751
DEBUG - 2022-11-15 07:44:33 --> Total execution time: 0.1746
DEBUG - 2022-11-15 07:44:34 --> Total execution time: 0.1653
DEBUG - 2022-11-15 07:44:39 --> Total execution time: 0.1748
DEBUG - 2022-11-15 07:44:40 --> Total execution time: 0.1680
DEBUG - 2022-11-15 07:44:43 --> Total execution time: 0.2064
DEBUG - 2022-11-15 07:45:05 --> Total execution time: 0.1992
DEBUG - 2022-11-15 07:45:25 --> Total execution time: 0.1916
DEBUG - 2022-11-15 07:45:52 --> Total execution time: 0.4545
DEBUG - 2022-11-15 07:49:03 --> Total execution time: 0.2990
DEBUG - 2022-11-15 07:49:10 --> Total execution time: 0.2106
DEBUG - 2022-11-15 07:49:29 --> Total execution time: 0.1933
DEBUG - 2022-11-15 07:49:39 --> Total execution time: 0.1732
DEBUG - 2022-11-15 07:49:51 --> Total execution time: 0.1824
DEBUG - 2022-11-15 07:50:16 --> Total execution time: 0.1752
DEBUG - 2022-11-15 07:50:23 --> Total execution time: 0.2008
DEBUG - 2022-11-15 07:50:31 --> Total execution time: 0.2180
DEBUG - 2022-11-15 07:50:40 --> Total execution time: 0.1114
DEBUG - 2022-11-15 07:51:41 --> Total execution time: 0.2229
DEBUG - 2022-11-15 07:52:02 --> Total execution time: 0.6192
DEBUG - 2022-11-15 07:52:06 --> Total execution time: 0.2240
DEBUG - 2022-11-15 07:52:40 --> Total execution time: 0.2058
DEBUG - 2022-11-15 07:52:53 --> Total execution time: 0.1851
DEBUG - 2022-11-15 07:53:26 --> Total execution time: 0.1803
DEBUG - 2022-11-15 08:02:40 --> Total execution time: 0.6280
DEBUG - 2022-11-15 08:04:11 --> Total execution time: 0.4706
DEBUG - 2022-11-15 08:04:44 --> Total execution time: 0.1747
DEBUG - 2022-11-15 08:05:08 --> Total execution time: 2.1620
DEBUG - 2022-11-15 08:05:12 --> Total execution time: 0.1725
DEBUG - 2022-11-15 08:05:20 --> Total execution time: 0.1842
DEBUG - 2022-11-15 08:05:29 --> Total execution time: 0.2034
DEBUG - 2022-11-15 08:05:32 --> Total execution time: 0.1875
DEBUG - 2022-11-15 08:05:36 --> Total execution time: 0.1674
DEBUG - 2022-11-15 08:05:51 --> Total execution time: 0.1717
DEBUG - 2022-11-15 08:06:02 --> Total execution time: 0.1848
DEBUG - 2022-11-15 08:06:31 --> Total execution time: 0.1907
DEBUG - 2022-11-15 08:06:43 --> Total execution time: 0.2086
DEBUG - 2022-11-15 08:07:03 --> Total execution time: 0.1251
DEBUG - 2022-11-15 08:07:04 --> Total execution time: 0.1311
DEBUG - 2022-11-15 08:07:06 --> Total execution time: 0.1758
DEBUG - 2022-11-15 08:07:10 --> Total execution time: 0.1639
DEBUG - 2022-11-15 08:07:14 --> Total execution time: 0.1744
DEBUG - 2022-11-15 08:07:24 --> Total execution time: 0.1898
DEBUG - 2022-11-15 08:07:36 --> Total execution time: 0.2562
DEBUG - 2022-11-15 08:08:00 --> Total execution time: 0.5300
DEBUG - 2022-11-15 08:08:06 --> Total execution time: 0.1819
DEBUG - 2022-11-15 08:08:07 --> Total execution time: 0.1692
DEBUG - 2022-11-15 08:08:17 --> Total execution time: 0.1657
DEBUG - 2022-11-15 08:08:30 --> Total execution time: 0.2253
DEBUG - 2022-11-15 08:08:40 --> Total execution time: 0.2194
DEBUG - 2022-11-15 08:08:48 --> Total execution time: 0.4377
DEBUG - 2022-11-15 08:08:53 --> Total execution time: 0.2185
DEBUG - 2022-11-15 08:08:55 --> Total execution time: 0.2478
DEBUG - 2022-11-15 08:09:50 --> Total execution time: 0.1667
DEBUG - 2022-11-15 08:11:17 --> Total execution time: 0.1667
DEBUG - 2022-11-15 08:11:34 --> Total execution time: 0.1914
DEBUG - 2022-11-15 08:11:39 --> Total execution time: 0.2472
DEBUG - 2022-11-15 08:11:43 --> Total execution time: 0.1613
DEBUG - 2022-11-15 08:12:14 --> Total execution time: 0.1808
DEBUG - 2022-11-15 08:12:22 --> Total execution time: 0.2073
DEBUG - 2022-11-15 08:12:23 --> Total execution time: 0.2079
DEBUG - 2022-11-15 08:12:42 --> Total execution time: 0.2203
DEBUG - 2022-11-15 08:12:53 --> Total execution time: 0.4851
DEBUG - 2022-11-15 08:13:02 --> Total execution time: 0.2154
DEBUG - 2022-11-15 08:13:03 --> Total execution time: 0.1862
DEBUG - 2022-11-15 08:13:08 --> Total execution time: 0.1835
DEBUG - 2022-11-15 08:13:19 --> Total execution time: 0.1698
DEBUG - 2022-11-15 08:13:21 --> Total execution time: 0.1772
DEBUG - 2022-11-15 08:14:58 --> Total execution time: 0.1118
DEBUG - 2022-11-15 08:15:06 --> Total execution time: 0.1769
DEBUG - 2022-11-15 08:15:10 --> Total execution time: 0.1884
DEBUG - 2022-11-15 08:15:15 --> Total execution time: 0.1933
DEBUG - 2022-11-15 08:15:20 --> Total execution time: 0.4589
DEBUG - 2022-11-15 08:15:22 --> Total execution time: 0.1701
DEBUG - 2022-11-15 08:15:34 --> Total execution time: 0.1816
DEBUG - 2022-11-15 08:15:48 --> Total execution time: 0.2203
DEBUG - 2022-11-15 08:15:57 --> Total execution time: 0.4648
DEBUG - 2022-11-15 08:16:32 --> Total execution time: 0.1714
DEBUG - 2022-11-15 08:17:28 --> Total execution time: 0.1051
DEBUG - 2022-11-15 08:17:37 --> Total execution time: 0.1678
DEBUG - 2022-11-15 08:18:54 --> Total execution time: 0.1925
DEBUG - 2022-11-15 08:19:02 --> Total execution time: 0.1769
DEBUG - 2022-11-15 08:19:03 --> Total execution time: 0.1775
DEBUG - 2022-11-15 08:19:19 --> Total execution time: 0.1713
DEBUG - 2022-11-15 08:19:30 --> Total execution time: 0.2255
DEBUG - 2022-11-15 08:19:30 --> Total execution time: 0.1722
DEBUG - 2022-11-15 08:19:39 --> Total execution time: 0.1808
DEBUG - 2022-11-15 08:19:43 --> Total execution time: 0.1723
DEBUG - 2022-11-15 08:19:56 --> Total execution time: 0.2111
DEBUG - 2022-11-15 08:20:02 --> Total execution time: 0.2390
DEBUG - 2022-11-15 08:20:37 --> Total execution time: 0.2120
DEBUG - 2022-11-15 08:20:47 --> Total execution time: 0.1108
DEBUG - 2022-11-15 08:21:29 --> Total execution time: 0.2423
DEBUG - 2022-11-15 08:21:47 --> Total execution time: 0.1916
DEBUG - 2022-11-15 08:21:57 --> Total execution time: 0.1425
DEBUG - 2022-11-15 08:22:23 --> Total execution time: 0.1225
DEBUG - 2022-11-15 08:22:32 --> Total execution time: 0.1674
DEBUG - 2022-11-15 08:22:38 --> Total execution time: 0.1709
DEBUG - 2022-11-15 08:22:51 --> Total execution time: 0.1270
DEBUG - 2022-11-15 08:22:52 --> Total execution time: 0.1302
DEBUG - 2022-11-15 08:22:53 --> Total execution time: 0.1091
DEBUG - 2022-11-15 08:22:53 --> Total execution time: 0.1686
DEBUG - 2022-11-15 08:22:54 --> Total execution time: 0.1257
DEBUG - 2022-11-15 08:22:54 --> Total execution time: 0.1750
DEBUG - 2022-11-15 08:22:56 --> Total execution time: 0.1316
DEBUG - 2022-11-15 08:22:58 --> Total execution time: 0.1124
DEBUG - 2022-11-15 08:22:58 --> Total execution time: 0.1699
DEBUG - 2022-11-15 08:23:02 --> Total execution time: 0.1140
DEBUG - 2022-11-15 08:23:14 --> Total execution time: 0.1730
DEBUG - 2022-11-15 08:23:24 --> Total execution time: 0.2184
DEBUG - 2022-11-15 08:23:35 --> Total execution time: 0.2597
DEBUG - 2022-11-15 08:23:37 --> Total execution time: 0.1922
DEBUG - 2022-11-15 08:23:48 --> Total execution time: 0.1772
DEBUG - 2022-11-15 08:23:49 --> Total execution time: 0.1886
DEBUG - 2022-11-15 08:23:53 --> Total execution time: 0.1788
DEBUG - 2022-11-15 08:23:58 --> Total execution time: 0.1779
DEBUG - 2022-11-15 08:24:02 --> Total execution time: 0.1876
DEBUG - 2022-11-15 08:24:02 --> Total execution time: 0.3809
DEBUG - 2022-11-15 08:24:05 --> Total execution time: 0.1910
DEBUG - 2022-11-15 08:24:18 --> Total execution time: 0.1283
DEBUG - 2022-11-15 08:24:33 --> Total execution time: 0.1105
DEBUG - 2022-11-15 08:24:38 --> Total execution time: 0.1680
DEBUG - 2022-11-15 08:24:40 --> Total execution time: 0.1695
DEBUG - 2022-11-15 08:24:52 --> Total execution time: 0.1737
DEBUG - 2022-11-15 08:24:56 --> Total execution time: 0.1639
DEBUG - 2022-11-15 08:24:57 --> Total execution time: 2.1899
DEBUG - 2022-11-15 08:24:58 --> Total execution time: 0.1758
DEBUG - 2022-11-15 08:25:01 --> Total execution time: 0.1674
DEBUG - 2022-11-15 08:25:07 --> Total execution time: 0.1860
DEBUG - 2022-11-15 08:25:08 --> Total execution time: 0.2529
DEBUG - 2022-11-15 08:25:14 --> Total execution time: 0.1927
DEBUG - 2022-11-15 08:25:17 --> Total execution time: 0.1736
DEBUG - 2022-11-15 08:25:18 --> Total execution time: 0.1834
DEBUG - 2022-11-15 08:25:25 --> Total execution time: 0.1833
DEBUG - 2022-11-15 08:25:32 --> Total execution time: 0.4795
DEBUG - 2022-11-15 08:25:35 --> Total execution time: 0.2144
DEBUG - 2022-11-15 08:25:39 --> Total execution time: 0.1676
DEBUG - 2022-11-15 08:25:52 --> Total execution time: 0.1745
DEBUG - 2022-11-15 08:25:56 --> Total execution time: 0.1839
DEBUG - 2022-11-15 08:26:09 --> Total execution time: 0.1672
DEBUG - 2022-11-15 08:26:17 --> Total execution time: 1.8198
DEBUG - 2022-11-15 08:26:28 --> Total execution time: 0.1669
DEBUG - 2022-11-15 08:26:31 --> Total execution time: 0.1921
DEBUG - 2022-11-15 08:26:38 --> Total execution time: 0.1676
DEBUG - 2022-11-15 08:26:45 --> Total execution time: 0.1792
DEBUG - 2022-11-15 08:27:04 --> Total execution time: 0.1758
DEBUG - 2022-11-15 08:27:22 --> Total execution time: 0.1292
DEBUG - 2022-11-15 08:27:29 --> Total execution time: 0.1820
DEBUG - 2022-11-15 08:27:43 --> Total execution time: 0.1706
DEBUG - 2022-11-15 08:27:58 --> Total execution time: 0.2093
DEBUG - 2022-11-15 08:28:07 --> Total execution time: 0.1751
DEBUG - 2022-11-15 08:28:12 --> Total execution time: 0.1816
DEBUG - 2022-11-15 08:28:19 --> Total execution time: 0.1765
DEBUG - 2022-11-15 08:28:26 --> Total execution time: 0.1890
DEBUG - 2022-11-15 08:28:31 --> Total execution time: 0.1886
DEBUG - 2022-11-15 08:28:36 --> Total execution time: 0.1716
DEBUG - 2022-11-15 08:28:38 --> Total execution time: 0.1661
DEBUG - 2022-11-15 08:28:47 --> Total execution time: 0.1995
DEBUG - 2022-11-15 08:28:56 --> Total execution time: 0.1773
DEBUG - 2022-11-15 08:29:16 --> Total execution time: 0.1943
DEBUG - 2022-11-15 08:30:02 --> Total execution time: 0.1681
DEBUG - 2022-11-15 08:30:15 --> Total execution time: 0.1918
DEBUG - 2022-11-15 08:30:21 --> Total execution time: 0.1722
DEBUG - 2022-11-15 08:30:31 --> Total execution time: 0.5188
DEBUG - 2022-11-15 08:30:51 --> Total execution time: 0.1815
DEBUG - 2022-11-15 08:30:52 --> Total execution time: 0.1816
DEBUG - 2022-11-15 08:32:02 --> Total execution time: 0.1179
DEBUG - 2022-11-15 08:32:45 --> Total execution time: 0.1913
DEBUG - 2022-11-15 08:37:00 --> Total execution time: 0.7097
DEBUG - 2022-11-15 08:37:29 --> Total execution time: 0.5091
DEBUG - 2022-11-15 08:41:30 --> Total execution time: 1.6994
DEBUG - 2022-11-15 08:42:05 --> Total execution time: 0.4807
DEBUG - 2022-11-15 08:43:11 --> Total execution time: 0.7773
DEBUG - 2022-11-15 08:43:23 --> Total execution time: 0.1781
DEBUG - 2022-11-15 08:43:29 --> Total execution time: 0.3473
DEBUG - 2022-11-15 08:43:52 --> Total execution time: 0.1824
DEBUG - 2022-11-15 08:45:45 --> Total execution time: 0.1669
DEBUG - 2022-11-15 08:46:42 --> Total execution time: 0.1934
DEBUG - 2022-11-15 08:46:47 --> Total execution time: 0.2854
DEBUG - 2022-11-15 08:48:13 --> Total execution time: 0.1637
DEBUG - 2022-11-15 08:48:19 --> Total execution time: 0.1706
DEBUG - 2022-11-15 08:48:57 --> Total execution time: 0.1766
DEBUG - 2022-11-15 08:49:02 --> Total execution time: 0.2365
DEBUG - 2022-11-15 08:50:28 --> Total execution time: 0.1460
DEBUG - 2022-11-15 08:51:44 --> Total execution time: 0.4683
DEBUG - 2022-11-15 08:52:43 --> Total execution time: 0.1164
DEBUG - 2022-11-15 08:52:57 --> Total execution time: 0.1040
DEBUG - 2022-11-15 08:53:08 --> Total execution time: 0.1805
DEBUG - 2022-11-15 08:53:28 --> Total execution time: 0.1851
DEBUG - 2022-11-15 08:53:33 --> Total execution time: 0.1745
DEBUG - 2022-11-15 08:53:49 --> Total execution time: 0.1672
DEBUG - 2022-11-15 08:53:50 --> Total execution time: 0.1633
DEBUG - 2022-11-15 09:00:00 --> Total execution time: 0.6140
DEBUG - 2022-11-15 09:01:57 --> Total execution time: 0.1783
DEBUG - 2022-11-15 09:05:13 --> Total execution time: 0.6001
DEBUG - 2022-11-15 09:06:46 --> Total execution time: 0.1180
DEBUG - 2022-11-15 09:06:52 --> Total execution time: 0.1013
DEBUG - 2022-11-15 09:06:57 --> Total execution time: 0.1644
DEBUG - 2022-11-15 09:07:25 --> Total execution time: 0.1664
DEBUG - 2022-11-15 09:07:31 --> Total execution time: 0.2056
DEBUG - 2022-11-15 09:10:15 --> Total execution time: 0.1635
DEBUG - 2022-11-15 09:10:21 --> Total execution time: 0.1691
DEBUG - 2022-11-15 09:12:46 --> Total execution time: 0.2101
DEBUG - 2022-11-15 09:14:27 --> Total execution time: 2.4220
DEBUG - 2022-11-15 09:14:30 --> Total execution time: 0.1818
DEBUG - 2022-11-15 09:14:33 --> Total execution time: 0.1861
DEBUG - 2022-11-15 09:14:43 --> Total execution time: 0.1749
DEBUG - 2022-11-15 09:14:58 --> Total execution time: 0.1850
DEBUG - 2022-11-15 09:15:05 --> Total execution time: 0.1137
DEBUG - 2022-11-15 09:15:09 --> Total execution time: 0.1703
DEBUG - 2022-11-15 09:15:16 --> Total execution time: 0.4524
DEBUG - 2022-11-15 09:15:19 --> Total execution time: 0.2340
DEBUG - 2022-11-15 09:16:25 --> Total execution time: 0.2124
DEBUG - 2022-11-15 09:16:35 --> Total execution time: 0.1908
DEBUG - 2022-11-15 09:16:43 --> Total execution time: 0.2022
DEBUG - 2022-11-15 09:17:02 --> Total execution time: 0.2012
DEBUG - 2022-11-15 09:23:41 --> Total execution time: 0.5608
DEBUG - 2022-11-15 09:23:51 --> Total execution time: 0.1688
DEBUG - 2022-11-15 09:24:22 --> Total execution time: 0.1067
DEBUG - 2022-11-15 09:25:17 --> Total execution time: 0.1177
DEBUG - 2022-11-15 09:25:30 --> Total execution time: 0.1213
DEBUG - 2022-11-15 09:25:36 --> Total execution time: 0.1115
DEBUG - 2022-11-15 09:25:38 --> Total execution time: 0.1297
DEBUG - 2022-11-15 09:25:50 --> Total execution time: 0.2248
DEBUG - 2022-11-15 09:25:53 --> Total execution time: 0.1083
DEBUG - 2022-11-15 09:25:54 --> Total execution time: 0.1083
DEBUG - 2022-11-15 09:26:01 --> Total execution time: 0.1684
DEBUG - 2022-11-15 09:26:05 --> Total execution time: 0.2701
DEBUG - 2022-11-15 09:26:07 --> Total execution time: 0.1382
DEBUG - 2022-11-15 09:26:13 --> Total execution time: 0.2540
DEBUG - 2022-11-15 09:26:15 --> Total execution time: 0.1434
DEBUG - 2022-11-15 09:26:18 --> Total execution time: 0.1811
DEBUG - 2022-11-15 09:26:29 --> Total execution time: 0.1780
DEBUG - 2022-11-15 09:26:33 --> Total execution time: 0.1762
DEBUG - 2022-11-15 09:26:40 --> Total execution time: 0.1656
DEBUG - 2022-11-15 09:27:14 --> Total execution time: 0.1774
DEBUG - 2022-11-15 09:27:34 --> Total execution time: 0.1168
DEBUG - 2022-11-15 09:27:43 --> Total execution time: 0.1771
DEBUG - 2022-11-15 09:27:44 --> Total execution time: 0.2234
DEBUG - 2022-11-15 09:27:48 --> Total execution time: 0.1661
DEBUG - 2022-11-15 09:27:55 --> Total execution time: 0.1286
DEBUG - 2022-11-15 09:28:39 --> Total execution time: 0.1463
DEBUG - 2022-11-15 09:28:51 --> Total execution time: 0.1081
DEBUG - 2022-11-15 09:29:07 --> Total execution time: 0.1129
DEBUG - 2022-11-15 09:29:23 --> Total execution time: 0.1865
DEBUG - 2022-11-15 09:29:45 --> Total execution time: 0.2437
DEBUG - 2022-11-15 09:29:54 --> Total execution time: 0.1901
DEBUG - 2022-11-15 09:30:02 --> Total execution time: 0.1899
DEBUG - 2022-11-15 09:30:08 --> Total execution time: 0.1979
DEBUG - 2022-11-15 09:30:27 --> Total execution time: 0.1166
DEBUG - 2022-11-15 09:30:33 --> Total execution time: 0.1761
DEBUG - 2022-11-15 09:31:12 --> Total execution time: 0.2105
DEBUG - 2022-11-15 09:31:14 --> Total execution time: 0.1758
DEBUG - 2022-11-15 09:31:17 --> Total execution time: 0.2158
DEBUG - 2022-11-15 09:31:24 --> Total execution time: 0.2209
DEBUG - 2022-11-15 09:32:27 --> Total execution time: 0.1975
DEBUG - 2022-11-15 09:32:45 --> Total execution time: 0.1083
DEBUG - 2022-11-15 09:32:46 --> Total execution time: 0.0998
DEBUG - 2022-11-15 09:32:59 --> Total execution time: 0.1594
DEBUG - 2022-11-15 09:33:06 --> Total execution time: 0.1577
DEBUG - 2022-11-15 09:33:12 --> Total execution time: 0.1690
DEBUG - 2022-11-15 09:33:15 --> Total execution time: 0.1622
DEBUG - 2022-11-15 09:33:36 --> Total execution time: 0.1718
DEBUG - 2022-11-15 09:33:38 --> Total execution time: 0.1863
DEBUG - 2022-11-15 09:34:26 --> Total execution time: 0.1736
DEBUG - 2022-11-15 09:34:28 --> Total execution time: 0.1962
DEBUG - 2022-11-15 09:34:36 --> Total execution time: 0.3310
DEBUG - 2022-11-15 09:34:57 --> Total execution time: 0.1792
DEBUG - 2022-11-15 09:35:28 --> Total execution time: 0.2513
DEBUG - 2022-11-15 09:35:28 --> Total execution time: 0.1071
DEBUG - 2022-11-15 09:35:29 --> Total execution time: 0.1870
DEBUG - 2022-11-15 09:36:50 --> Total execution time: 0.1724
DEBUG - 2022-11-15 09:36:52 --> Total execution time: 0.1075
DEBUG - 2022-11-15 09:37:55 --> Total execution time: 0.1799
DEBUG - 2022-11-15 09:38:12 --> Total execution time: 0.1793
DEBUG - 2022-11-15 09:39:00 --> Total execution time: 0.1738
DEBUG - 2022-11-15 09:39:33 --> Total execution time: 0.1063
DEBUG - 2022-11-15 09:40:08 --> Total execution time: 0.1871
DEBUG - 2022-11-15 09:40:15 --> Total execution time: 0.4658
DEBUG - 2022-11-15 09:40:17 --> Total execution time: 0.2525
DEBUG - 2022-11-15 09:40:21 --> Total execution time: 0.2081
DEBUG - 2022-11-15 09:40:21 --> Total execution time: 0.2124
DEBUG - 2022-11-15 09:40:32 --> Total execution time: 0.1925
DEBUG - 2022-11-15 09:40:33 --> Total execution time: 0.2180
DEBUG - 2022-11-15 09:40:41 --> Total execution time: 0.2600
DEBUG - 2022-11-15 09:40:47 --> Total execution time: 0.1786
DEBUG - 2022-11-15 09:41:02 --> Total execution time: 0.2012
DEBUG - 2022-11-15 09:41:05 --> Total execution time: 0.1812
DEBUG - 2022-11-15 09:41:21 --> Total execution time: 0.2035
DEBUG - 2022-11-15 09:41:42 --> Total execution time: 0.1759
DEBUG - 2022-11-15 09:42:39 --> Total execution time: 0.4536
DEBUG - 2022-11-15 09:43:13 --> Total execution time: 2.0182
DEBUG - 2022-11-15 09:43:42 --> Total execution time: 0.1083
DEBUG - 2022-11-15 09:43:44 --> Total execution time: 0.2342
DEBUG - 2022-11-15 09:43:44 --> Total execution time: 0.2106
DEBUG - 2022-11-15 09:43:57 --> Total execution time: 0.1704
DEBUG - 2022-11-15 09:43:59 --> Total execution time: 0.1638
DEBUG - 2022-11-15 09:44:04 --> Total execution time: 0.1761
DEBUG - 2022-11-15 09:44:12 --> Total execution time: 0.1903
DEBUG - 2022-11-15 09:44:22 --> Total execution time: 0.2390
DEBUG - 2022-11-15 09:44:32 --> Total execution time: 0.2056
DEBUG - 2022-11-15 09:44:42 --> Total execution time: 0.1769
DEBUG - 2022-11-15 09:44:48 --> Total execution time: 0.1918
DEBUG - 2022-11-15 09:45:02 --> Total execution time: 0.1967
DEBUG - 2022-11-15 09:49:06 --> Total execution time: 0.2287
DEBUG - 2022-11-15 09:49:37 --> Total execution time: 0.1859
DEBUG - 2022-11-15 09:53:59 --> Total execution time: 0.2031
DEBUG - 2022-11-15 09:56:33 --> Total execution time: 0.1405
DEBUG - 2022-11-15 09:56:45 --> Total execution time: 0.1830
DEBUG - 2022-11-15 09:57:09 --> Total execution time: 0.4517
DEBUG - 2022-11-15 09:57:37 --> Total execution time: 0.2023
DEBUG - 2022-11-15 09:57:44 --> Total execution time: 0.1909
DEBUG - 2022-11-15 09:57:50 --> Total execution time: 0.1701
DEBUG - 2022-11-15 09:57:54 --> Total execution time: 0.1939
DEBUG - 2022-11-15 09:57:59 --> Total execution time: 0.1999
DEBUG - 2022-11-15 09:58:05 --> Total execution time: 0.2040
DEBUG - 2022-11-15 09:58:14 --> Total execution time: 0.1740
DEBUG - 2022-11-15 09:58:22 --> Total execution time: 0.1912
DEBUG - 2022-11-15 09:58:34 --> Total execution time: 0.1779
DEBUG - 2022-11-15 09:58:44 --> Total execution time: 0.1705
DEBUG - 2022-11-15 09:58:46 --> Total execution time: 0.2377
DEBUG - 2022-11-15 09:58:49 --> Total execution time: 0.1857
DEBUG - 2022-11-15 09:58:55 --> Total execution time: 0.1646
DEBUG - 2022-11-15 09:59:09 --> Total execution time: 0.1834
DEBUG - 2022-11-15 09:59:25 --> Total execution time: 0.2367
DEBUG - 2022-11-15 09:59:27 --> Total execution time: 0.1755
DEBUG - 2022-11-15 09:59:34 --> Total execution time: 0.1852
DEBUG - 2022-11-15 09:59:46 --> Total execution time: 0.1767
DEBUG - 2022-11-15 09:59:55 --> Total execution time: 0.1786
DEBUG - 2022-11-15 10:00:03 --> Total execution time: 0.5021
DEBUG - 2022-11-15 10:00:07 --> Total execution time: 0.4918
DEBUG - 2022-11-15 10:00:09 --> Total execution time: 0.1690
DEBUG - 2022-11-15 10:00:14 --> Total execution time: 0.1770
DEBUG - 2022-11-15 10:00:18 --> Total execution time: 0.1763
DEBUG - 2022-11-15 10:00:48 --> Total execution time: 0.1701
DEBUG - 2022-11-15 10:00:53 --> Total execution time: 0.1636
DEBUG - 2022-11-15 10:00:56 --> Total execution time: 0.2199
DEBUG - 2022-11-15 10:01:10 --> Total execution time: 0.1762
DEBUG - 2022-11-15 10:01:18 --> Total execution time: 0.1740
DEBUG - 2022-11-15 10:01:21 --> Total execution time: 0.0987
DEBUG - 2022-11-15 10:01:21 --> Total execution time: 0.1735
DEBUG - 2022-11-15 10:01:28 --> Total execution time: 0.2270
DEBUG - 2022-11-15 10:01:28 --> Total execution time: 0.1758
DEBUG - 2022-11-15 10:01:33 --> Total execution time: 0.1801
DEBUG - 2022-11-15 10:01:33 --> Total execution time: 0.3498
DEBUG - 2022-11-15 10:01:34 --> Total execution time: 0.1889
DEBUG - 2022-11-15 10:01:37 --> Total execution time: 0.1695
DEBUG - 2022-11-15 10:01:50 --> Total execution time: 0.2074
DEBUG - 2022-11-15 10:01:56 --> Total execution time: 0.1725
DEBUG - 2022-11-15 10:02:02 --> Total execution time: 0.2066
DEBUG - 2022-11-15 10:02:05 --> Total execution time: 0.2169
DEBUG - 2022-11-15 10:03:20 --> Total execution time: 0.1846
DEBUG - 2022-11-15 10:03:52 --> Total execution time: 0.1645
DEBUG - 2022-11-15 10:04:15 --> Total execution time: 0.1108
DEBUG - 2022-11-15 10:04:16 --> Total execution time: 0.1712
DEBUG - 2022-11-15 10:04:21 --> Total execution time: 0.1783
DEBUG - 2022-11-15 10:04:26 --> Total execution time: 0.4647
DEBUG - 2022-11-15 10:04:26 --> Total execution time: 0.1722
DEBUG - 2022-11-15 10:04:35 --> Total execution time: 0.1713
DEBUG - 2022-11-15 10:04:49 --> Total execution time: 0.1992
DEBUG - 2022-11-15 10:04:54 --> Total execution time: 0.1711
DEBUG - 2022-11-15 10:05:02 --> Total execution time: 0.2053
DEBUG - 2022-11-15 10:05:03 --> Total execution time: 0.2291
DEBUG - 2022-11-15 10:05:10 --> Total execution time: 0.2061
DEBUG - 2022-11-15 10:05:17 --> Total execution time: 0.1770
DEBUG - 2022-11-15 10:05:20 --> Total execution time: 0.1704
DEBUG - 2022-11-15 10:05:24 --> Total execution time: 0.1629
DEBUG - 2022-11-15 10:05:35 --> Total execution time: 0.1665
DEBUG - 2022-11-15 10:06:29 --> Total execution time: 0.1111
DEBUG - 2022-11-15 10:06:35 --> Total execution time: 0.1069
DEBUG - 2022-11-15 10:06:36 --> Total execution time: 0.1042
DEBUG - 2022-11-15 10:06:42 --> Total execution time: 0.1864
DEBUG - 2022-11-15 10:06:45 --> Total execution time: 0.1871
DEBUG - 2022-11-15 10:06:47 --> Total execution time: 0.1932
DEBUG - 2022-11-15 10:06:51 --> Total execution time: 0.1961
DEBUG - 2022-11-15 10:06:57 --> Total execution time: 0.1892
DEBUG - 2022-11-15 10:06:59 --> Total execution time: 0.1841
DEBUG - 2022-11-15 10:07:07 --> Total execution time: 0.1639
DEBUG - 2022-11-15 10:07:15 --> Total execution time: 0.2263
DEBUG - 2022-11-15 10:07:16 --> Total execution time: 0.1780
DEBUG - 2022-11-15 10:07:27 --> Total execution time: 0.1873
DEBUG - 2022-11-15 10:07:53 --> Total execution time: 0.1940
DEBUG - 2022-11-15 10:07:56 --> Total execution time: 0.2079
DEBUG - 2022-11-15 10:08:08 --> Total execution time: 0.2297
DEBUG - 2022-11-15 10:09:40 --> Total execution time: 0.1746
DEBUG - 2022-11-15 10:11:47 --> Total execution time: 0.2813
DEBUG - 2022-11-15 10:11:57 --> Total execution time: 0.2068
DEBUG - 2022-11-15 10:12:08 --> Total execution time: 0.2233
DEBUG - 2022-11-15 10:12:19 --> Total execution time: 0.1730
DEBUG - 2022-11-15 10:12:21 --> Total execution time: 0.1957
DEBUG - 2022-11-15 10:12:32 --> Total execution time: 0.2060
DEBUG - 2022-11-15 10:12:39 --> Total execution time: 0.1619
DEBUG - 2022-11-15 10:12:42 --> Total execution time: 0.1805
DEBUG - 2022-11-15 10:14:38 --> Total execution time: 0.2145
DEBUG - 2022-11-15 10:14:46 --> Total execution time: 0.1888
DEBUG - 2022-11-15 10:14:47 --> Total execution time: 0.1786
DEBUG - 2022-11-15 10:14:50 --> Total execution time: 0.4740
DEBUG - 2022-11-15 10:14:54 --> Total execution time: 0.2457
DEBUG - 2022-11-15 10:14:57 --> Total execution time: 0.2313
DEBUG - 2022-11-15 10:14:58 --> Total execution time: 0.2229
DEBUG - 2022-11-15 10:15:00 --> Total execution time: 0.1220
DEBUG - 2022-11-15 10:15:10 --> Total execution time: 0.1135
DEBUG - 2022-11-15 10:15:11 --> Total execution time: 0.2345
DEBUG - 2022-11-15 10:15:12 --> Total execution time: 0.1826
DEBUG - 2022-11-15 10:15:17 --> Total execution time: 0.1746
DEBUG - 2022-11-15 10:15:20 --> Total execution time: 0.1673
DEBUG - 2022-11-15 10:15:21 --> Total execution time: 0.1822
DEBUG - 2022-11-15 10:15:23 --> Total execution time: 0.1941
DEBUG - 2022-11-15 10:15:29 --> Total execution time: 0.1743
DEBUG - 2022-11-15 10:15:31 --> Total execution time: 0.1714
DEBUG - 2022-11-15 10:15:31 --> Total execution time: 0.1100
DEBUG - 2022-11-15 10:15:42 --> Total execution time: 0.2095
DEBUG - 2022-11-15 10:15:53 --> Total execution time: 0.1720
DEBUG - 2022-11-15 10:15:54 --> Total execution time: 0.1757
DEBUG - 2022-11-15 10:16:07 --> Total execution time: 0.2454
DEBUG - 2022-11-15 10:16:13 --> Total execution time: 0.2083
DEBUG - 2022-11-15 10:16:49 --> Total execution time: 0.1110
DEBUG - 2022-11-15 10:16:56 --> Total execution time: 0.5258
DEBUG - 2022-11-15 10:17:02 --> Total execution time: 0.2091
DEBUG - 2022-11-15 10:17:10 --> Total execution time: 0.1990
DEBUG - 2022-11-15 10:17:48 --> Total execution time: 0.2076
DEBUG - 2022-11-15 10:21:31 --> Total execution time: 1.1876
DEBUG - 2022-11-15 10:23:27 --> Total execution time: 0.7537
DEBUG - 2022-11-15 10:23:55 --> Total execution time: 1.0482
DEBUG - 2022-11-15 10:23:55 --> Total execution time: 0.1236
DEBUG - 2022-11-15 10:24:03 --> Total execution time: 0.1703
DEBUG - 2022-11-15 10:24:03 --> Total execution time: 0.2652
DEBUG - 2022-11-15 10:24:11 --> Total execution time: 0.3031
DEBUG - 2022-11-15 10:24:11 --> Total execution time: 0.1869
DEBUG - 2022-11-15 10:24:17 --> Total execution time: 0.2776
DEBUG - 2022-11-15 10:24:30 --> Total execution time: 0.5507
DEBUG - 2022-11-15 10:24:41 --> Total execution time: 0.1939
DEBUG - 2022-11-15 10:24:53 --> Total execution time: 0.2374
DEBUG - 2022-11-15 10:24:57 --> Total execution time: 0.1793
DEBUG - 2022-11-15 10:25:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-15 10:25:11 --> Total execution time: 0.2649
DEBUG - 2022-11-15 10:25:15 --> Total execution time: 0.2103
DEBUG - 2022-11-15 10:25:31 --> Total execution time: 0.2057
DEBUG - 2022-11-15 10:25:36 --> Total execution time: 0.2145
DEBUG - 2022-11-15 10:25:37 --> Total execution time: 0.2309
DEBUG - 2022-11-15 10:25:37 --> Total execution time: 0.2481
DEBUG - 2022-11-15 10:25:52 --> Total execution time: 0.2166
DEBUG - 2022-11-15 10:26:50 --> Total execution time: 0.1083
DEBUG - 2022-11-15 10:27:33 --> Total execution time: 0.1187
DEBUG - 2022-11-15 10:27:51 --> Total execution time: 0.1892
DEBUG - 2022-11-15 10:28:03 --> Total execution time: 0.2504
DEBUG - 2022-11-15 10:28:52 --> Total execution time: 0.1706
DEBUG - 2022-11-15 10:30:03 --> Total execution time: 0.2965
DEBUG - 2022-11-15 10:30:46 --> Total execution time: 0.4580
DEBUG - 2022-11-15 10:35:48 --> Total execution time: 0.1970
DEBUG - 2022-11-15 10:36:07 --> Total execution time: 0.1838
DEBUG - 2022-11-15 10:36:18 --> Total execution time: 0.2463
DEBUG - 2022-11-15 10:36:28 --> Total execution time: 0.9187
DEBUG - 2022-11-15 10:36:57 --> Total execution time: 0.3600
DEBUG - 2022-11-15 10:36:57 --> Total execution time: 0.4855
DEBUG - 2022-11-15 10:37:05 --> Total execution time: 0.2097
DEBUG - 2022-11-15 10:37:29 --> Total execution time: 0.1875
DEBUG - 2022-11-15 10:39:33 --> Total execution time: 0.1987
DEBUG - 2022-11-15 10:39:49 --> Total execution time: 0.1188
DEBUG - 2022-11-15 10:39:53 --> Total execution time: 0.1085
DEBUG - 2022-11-15 10:40:00 --> Total execution time: 0.1783
DEBUG - 2022-11-15 10:40:05 --> Total execution time: 0.1970
DEBUG - 2022-11-15 10:40:06 --> Total execution time: 0.2066
DEBUG - 2022-11-15 10:40:06 --> Total execution time: 0.2537
DEBUG - 2022-11-15 10:40:07 --> Total execution time: 0.2452
DEBUG - 2022-11-15 10:40:14 --> Total execution time: 0.1663
DEBUG - 2022-11-15 10:40:18 --> Total execution time: 0.1971
DEBUG - 2022-11-15 10:49:24 --> Total execution time: 0.6942
DEBUG - 2022-11-15 10:49:36 --> Total execution time: 0.1134
DEBUG - 2022-11-15 10:52:21 --> Total execution time: 0.5762
DEBUG - 2022-11-15 10:52:27 --> Total execution time: 0.1993
DEBUG - 2022-11-15 10:52:51 --> Total execution time: 0.1919
DEBUG - 2022-11-15 10:53:03 --> Total execution time: 0.1947
DEBUG - 2022-11-15 10:53:08 --> Total execution time: 0.1718
DEBUG - 2022-11-15 10:53:22 --> Total execution time: 0.1652
DEBUG - 2022-11-15 10:53:26 --> Total execution time: 0.1094
DEBUG - 2022-11-15 10:53:26 --> Total execution time: 0.1107
DEBUG - 2022-11-15 10:53:34 --> Total execution time: 0.1803
DEBUG - 2022-11-15 10:53:45 --> Total execution time: 0.2177
DEBUG - 2022-11-15 10:54:03 --> Total execution time: 0.1763
DEBUG - 2022-11-15 10:54:07 --> Total execution time: 0.1859
DEBUG - 2022-11-15 10:54:45 --> Total execution time: 0.1989
DEBUG - 2022-11-15 10:54:58 --> Total execution time: 0.2257
DEBUG - 2022-11-15 10:55:24 --> Total execution time: 0.1757
DEBUG - 2022-11-15 10:55:29 --> Total execution time: 0.1708
DEBUG - 2022-11-15 10:55:37 --> Total execution time: 0.1802
DEBUG - 2022-11-15 10:55:47 --> Total execution time: 0.2064
DEBUG - 2022-11-15 10:56:00 --> Total execution time: 0.2108
DEBUG - 2022-11-15 10:56:32 --> Total execution time: 0.2109
DEBUG - 2022-11-15 10:56:38 --> Total execution time: 0.1732
DEBUG - 2022-11-15 10:56:45 --> Total execution time: 0.2221
DEBUG - 2022-11-15 10:56:52 --> Total execution time: 0.1727
DEBUG - 2022-11-15 10:57:00 --> Total execution time: 0.1743
DEBUG - 2022-11-15 10:57:58 --> Total execution time: 3.1627
DEBUG - 2022-11-15 10:58:25 --> Total execution time: 0.8534
DEBUG - 2022-11-15 10:58:25 --> Total execution time: 0.1677
DEBUG - 2022-11-15 10:58:43 --> Total execution time: 0.2622
DEBUG - 2022-11-15 11:01:48 --> Total execution time: 1.3261
DEBUG - 2022-11-15 11:02:20 --> Total execution time: 0.2360
DEBUG - 2022-11-15 11:02:27 --> Total execution time: 0.2978
DEBUG - 2022-11-15 11:02:31 --> Total execution time: 0.3748
DEBUG - 2022-11-15 11:02:48 --> Total execution time: 0.1408
DEBUG - 2022-11-15 11:02:55 --> Total execution time: 0.1659
DEBUG - 2022-11-15 11:02:57 --> Total execution time: 0.1630
DEBUG - 2022-11-15 11:03:17 --> Total execution time: 0.1732
DEBUG - 2022-11-15 11:03:21 --> Total execution time: 0.2453
DEBUG - 2022-11-15 11:03:34 --> Total execution time: 0.1482
DEBUG - 2022-11-15 11:03:37 --> Total execution time: 0.1811
DEBUG - 2022-11-15 11:03:39 --> Total execution time: 0.1737
DEBUG - 2022-11-15 11:03:48 --> Total execution time: 0.1721
DEBUG - 2022-11-15 11:03:49 --> Total execution time: 0.1901
DEBUG - 2022-11-15 11:04:02 --> Total execution time: 0.2709
DEBUG - 2022-11-15 11:04:24 --> Total execution time: 0.1796
DEBUG - 2022-11-15 11:04:26 --> Total execution time: 0.1657
DEBUG - 2022-11-15 11:04:48 --> Total execution time: 0.2346
DEBUG - 2022-11-15 11:05:26 --> Total execution time: 0.1675
DEBUG - 2022-11-15 11:05:38 --> Total execution time: 0.1995
DEBUG - 2022-11-15 11:07:47 --> Total execution time: 0.1974
DEBUG - 2022-11-15 11:08:28 --> Total execution time: 0.4981
DEBUG - 2022-11-15 11:09:29 --> Total execution time: 0.2011
DEBUG - 2022-11-15 11:09:41 --> Total execution time: 0.2101
DEBUG - 2022-11-15 11:09:52 --> Total execution time: 0.1347
DEBUG - 2022-11-15 11:10:12 --> Total execution time: 0.1785
DEBUG - 2022-11-15 11:10:24 --> Total execution time: 0.1663
DEBUG - 2022-11-15 11:10:33 --> Total execution time: 0.4619
DEBUG - 2022-11-15 11:10:43 --> Total execution time: 0.1393
DEBUG - 2022-11-15 11:10:54 --> Total execution time: 0.1727
DEBUG - 2022-11-15 11:10:56 --> Total execution time: 0.1634
DEBUG - 2022-11-15 11:11:11 --> Total execution time: 0.1819
DEBUG - 2022-11-15 11:12:08 --> Total execution time: 0.1843
DEBUG - 2022-11-15 11:13:17 --> Total execution time: 0.1132
DEBUG - 2022-11-15 11:14:29 --> Total execution time: 1.1198
DEBUG - 2022-11-15 11:15:28 --> Total execution time: 0.1789
DEBUG - 2022-11-15 11:15:37 --> Total execution time: 0.1696
DEBUG - 2022-11-15 11:16:20 --> Total execution time: 0.1676
DEBUG - 2022-11-15 11:16:34 --> Total execution time: 0.1723
DEBUG - 2022-11-15 11:17:16 --> Total execution time: 0.1137
DEBUG - 2022-11-15 11:17:26 --> Total execution time: 0.1782
DEBUG - 2022-11-15 11:17:44 --> Total execution time: 0.2766
DEBUG - 2022-11-15 11:17:46 --> Total execution time: 0.2723
DEBUG - 2022-11-15 11:18:07 --> Total execution time: 0.1914
DEBUG - 2022-11-15 11:18:15 --> Total execution time: 0.2062
DEBUG - 2022-11-15 11:18:29 --> Total execution time: 0.1975
DEBUG - 2022-11-15 11:18:38 --> Total execution time: 0.5039
DEBUG - 2022-11-15 11:20:19 --> Total execution time: 0.1821
DEBUG - 2022-11-15 11:20:31 --> Total execution time: 0.2008
DEBUG - 2022-11-15 11:21:20 --> Total execution time: 0.2242
DEBUG - 2022-11-15 11:24:08 --> Total execution time: 0.6489
DEBUG - 2022-11-15 11:24:15 --> Total execution time: 0.1079
DEBUG - 2022-11-15 11:29:07 --> Total execution time: 0.6523
DEBUG - 2022-11-15 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:30:04 --> Total execution time: 1.7942
DEBUG - 2022-11-15 00:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:32:21 --> Total execution time: 0.8122
DEBUG - 2022-11-15 00:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:32:23 --> Total execution time: 0.5632
DEBUG - 2022-11-15 00:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:33:05 --> Total execution time: 0.6923
DEBUG - 2022-11-15 00:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:37:16 --> Total execution time: 0.2025
DEBUG - 2022-11-15 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:41:04 --> Total execution time: 1.6354
DEBUG - 2022-11-15 00:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:12:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:42:22 --> Total execution time: 2.3318
DEBUG - 2022-11-15 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:44:09 --> Total execution time: 0.1704
DEBUG - 2022-11-15 00:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 00:14:51 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-11-15 00:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 00:18:20 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-15 00:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:21:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:51:38 --> Total execution time: 1.5569
DEBUG - 2022-11-15 00:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:51:45 --> Total execution time: 0.1624
DEBUG - 2022-11-15 00:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:52:06 --> Total execution time: 0.1691
DEBUG - 2022-11-15 00:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:52:31 --> Total execution time: 0.2250
DEBUG - 2022-11-15 00:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:52:50 --> Total execution time: 0.2686
DEBUG - 2022-11-15 00:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:53:11 --> Total execution time: 0.2215
DEBUG - 2022-11-15 00:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:56:05 --> Total execution time: 0.1922
DEBUG - 2022-11-15 00:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:58:50 --> Total execution time: 2.9418
DEBUG - 2022-11-15 00:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:59:02 --> Total execution time: 0.5717
DEBUG - 2022-11-15 00:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:59:14 --> Total execution time: 0.2987
DEBUG - 2022-11-15 00:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:59:54 --> Total execution time: 0.1720
DEBUG - 2022-11-15 00:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:30:06 --> Total execution time: 0.2625
DEBUG - 2022-11-15 00:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:00:12 --> Total execution time: 0.1664
DEBUG - 2022-11-15 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:00:15 --> Total execution time: 0.1822
DEBUG - 2022-11-15 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:00:21 --> Total execution time: 0.3299
DEBUG - 2022-11-15 00:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:00:21 --> Total execution time: 0.1142
DEBUG - 2022-11-15 00:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:00:34 --> Total execution time: 0.1908
DEBUG - 2022-11-15 00:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:05 --> Total execution time: 0.2352
DEBUG - 2022-11-15 00:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:14 --> Total execution time: 0.1884
DEBUG - 2022-11-15 00:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:14 --> Total execution time: 0.1659
DEBUG - 2022-11-15 00:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:19 --> Total execution time: 0.1668
DEBUG - 2022-11-15 00:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:20 --> Total execution time: 0.2817
DEBUG - 2022-11-15 00:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:32 --> Total execution time: 0.2177
DEBUG - 2022-11-15 00:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:39 --> Total execution time: 0.1906
DEBUG - 2022-11-15 00:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:52 --> Total execution time: 0.1749
DEBUG - 2022-11-15 00:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:02:14 --> Total execution time: 0.1974
DEBUG - 2022-11-15 00:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:30 --> Total execution time: 1.8180
DEBUG - 2022-11-15 00:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:02:30 --> Total execution time: 0.1958
DEBUG - 2022-11-15 00:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:02:35 --> Total execution time: 0.1892
DEBUG - 2022-11-15 00:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:02:48 --> Total execution time: 0.1908
DEBUG - 2022-11-15 00:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:02:55 --> Total execution time: 0.2468
DEBUG - 2022-11-15 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:03:31 --> Total execution time: 1.1992
DEBUG - 2022-11-15 00:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:04:03 --> Total execution time: 2.2895
DEBUG - 2022-11-15 00:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:04:35 --> Total execution time: 0.7260
DEBUG - 2022-11-15 00:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:34:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 00:34:46 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 00:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:04 --> Total execution time: 0.5226
DEBUG - 2022-11-15 00:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:39 --> Total execution time: 0.2631
DEBUG - 2022-11-15 00:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:40 --> Total execution time: 0.6441
DEBUG - 2022-11-15 00:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:41 --> Total execution time: 0.1895
DEBUG - 2022-11-15 00:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:42 --> Total execution time: 0.1715
DEBUG - 2022-11-15 00:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:46 --> Total execution time: 0.1666
DEBUG - 2022-11-15 00:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:55 --> Total execution time: 0.1771
DEBUG - 2022-11-15 00:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:57 --> Total execution time: 0.2019
DEBUG - 2022-11-15 00:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:05:58 --> Total execution time: 0.1743
DEBUG - 2022-11-15 00:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:03 --> Total execution time: 0.2374
DEBUG - 2022-11-15 00:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:05 --> Total execution time: 0.1336
DEBUG - 2022-11-15 00:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:06 --> Total execution time: 0.1786
DEBUG - 2022-11-15 00:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:07 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:07 --> Total execution time: 0.2026
DEBUG - 2022-11-15 00:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:14 --> Total execution time: 0.2132
DEBUG - 2022-11-15 00:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:16 --> Total execution time: 0.2057
DEBUG - 2022-11-15 00:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:29 --> Total execution time: 0.2419
DEBUG - 2022-11-15 00:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:41 --> Total execution time: 0.2221
DEBUG - 2022-11-15 00:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:06:43 --> Total execution time: 0.2742
DEBUG - 2022-11-15 00:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:07 --> Total execution time: 0.3972
DEBUG - 2022-11-15 00:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:08 --> Total execution time: 0.4581
DEBUG - 2022-11-15 00:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:10 --> Total execution time: 0.1936
DEBUG - 2022-11-15 00:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:37:29 --> Total execution time: 0.1868
DEBUG - 2022-11-15 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:37:31 --> Total execution time: 0.2451
DEBUG - 2022-11-15 00:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:37:31 --> Total execution time: 0.2074
DEBUG - 2022-11-15 00:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:36 --> Total execution time: 0.1774
DEBUG - 2022-11-15 00:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:37 --> Total execution time: 0.1267
DEBUG - 2022-11-15 00:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:37:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:47 --> Total execution time: 0.1228
DEBUG - 2022-11-15 00:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:10:43 --> Total execution time: 2.9315
DEBUG - 2022-11-15 00:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:10:44 --> Total execution time: 0.3413
DEBUG - 2022-11-15 00:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:10:49 --> Total execution time: 0.4985
DEBUG - 2022-11-15 00:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:10:58 --> Total execution time: 0.1805
DEBUG - 2022-11-15 00:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:11:10 --> Total execution time: 0.1867
DEBUG - 2022-11-15 00:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:44:27 --> Total execution time: 0.9810
DEBUG - 2022-11-15 00:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:44:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:14:31 --> Total execution time: 0.2162
DEBUG - 2022-11-15 00:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:16:43 --> Total execution time: 0.3187
DEBUG - 2022-11-15 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:49:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:19:58 --> Total execution time: 0.7942
DEBUG - 2022-11-15 00:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:19:58 --> Total execution time: 0.2199
DEBUG - 2022-11-15 00:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:20:02 --> Total execution time: 0.1839
DEBUG - 2022-11-15 00:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:20:08 --> Total execution time: 0.2222
DEBUG - 2022-11-15 00:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:20:11 --> Total execution time: 0.1763
DEBUG - 2022-11-15 00:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:20:16 --> Total execution time: 0.4705
DEBUG - 2022-11-15 00:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:20:17 --> Total execution time: 0.3783
DEBUG - 2022-11-15 00:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:21:15 --> Total execution time: 1.8405
DEBUG - 2022-11-15 00:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:21:20 --> Total execution time: 0.1914
DEBUG - 2022-11-15 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:21:33 --> Total execution time: 0.1668
DEBUG - 2022-11-15 00:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:23:59 --> Total execution time: 2.3462
DEBUG - 2022-11-15 00:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:23:59 --> Total execution time: 1.2017
DEBUG - 2022-11-15 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:11 --> Total execution time: 2.1040
DEBUG - 2022-11-15 00:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:23 --> Total execution time: 1.9363
DEBUG - 2022-11-15 00:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:28 --> Total execution time: 0.1817
DEBUG - 2022-11-15 00:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:51 --> No URI present. Default controller set.
DEBUG - 2022-11-15 00:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:51 --> Total execution time: 0.1277
DEBUG - 2022-11-15 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 00:57:52 --> 404 Page Not Found: Wp-includes/wp-includes.php
DEBUG - 2022-11-15 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:58 --> Total execution time: 0.2057
DEBUG - 2022-11-15 00:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:28:02 --> Total execution time: 0.6620
DEBUG - 2022-11-15 00:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:28:04 --> Total execution time: 0.1769
DEBUG - 2022-11-15 00:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:28:07 --> Total execution time: 0.2905
DEBUG - 2022-11-15 00:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:28:26 --> Total execution time: 0.2506
DEBUG - 2022-11-15 00:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:28:33 --> Total execution time: 0.3440
DEBUG - 2022-11-15 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:29:40 --> Total execution time: 0.5525
DEBUG - 2022-11-15 00:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:29:41 --> Total execution time: 0.1734
DEBUG - 2022-11-15 00:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 00:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 00:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 00:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:29:45 --> Total execution time: 0.1793
DEBUG - 2022-11-15 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:02 --> Total execution time: 0.1821
DEBUG - 2022-11-15 01:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:10 --> Total execution time: 0.2431
DEBUG - 2022-11-15 01:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:16 --> Total execution time: 0.1371
DEBUG - 2022-11-15 01:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:35 --> Total execution time: 0.6424
DEBUG - 2022-11-15 01:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:35 --> Total execution time: 0.1898
DEBUG - 2022-11-15 01:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:40 --> Total execution time: 0.2620
DEBUG - 2022-11-15 01:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:41 --> Total execution time: 0.2165
DEBUG - 2022-11-15 01:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:43 --> Total execution time: 0.1671
DEBUG - 2022-11-15 01:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:43 --> Total execution time: 0.1881
DEBUG - 2022-11-15 01:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:44 --> Total execution time: 0.2151
DEBUG - 2022-11-15 01:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:50 --> Total execution time: 0.1942
DEBUG - 2022-11-15 01:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:53 --> Total execution time: 0.3246
DEBUG - 2022-11-15 01:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:54 --> Total execution time: 0.2675
DEBUG - 2022-11-15 01:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:30:56 --> Total execution time: 0.3130
DEBUG - 2022-11-15 01:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:00 --> Total execution time: 0.1666
DEBUG - 2022-11-15 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:00 --> Total execution time: 0.2172
DEBUG - 2022-11-15 01:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:03 --> Total execution time: 0.2579
DEBUG - 2022-11-15 01:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:03 --> Total execution time: 0.3996
DEBUG - 2022-11-15 01:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:04 --> Total execution time: 0.3136
DEBUG - 2022-11-15 01:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:18 --> Total execution time: 0.2139
DEBUG - 2022-11-15 01:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:22 --> Total execution time: 0.1805
DEBUG - 2022-11-15 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:28 --> Total execution time: 0.1113
DEBUG - 2022-11-15 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:30 --> Total execution time: 0.1803
DEBUG - 2022-11-15 01:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:50 --> Total execution time: 0.1289
DEBUG - 2022-11-15 01:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:52 --> Total execution time: 0.1684
DEBUG - 2022-11-15 01:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:54 --> Total execution time: 0.1663
DEBUG - 2022-11-15 01:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:59 --> Total execution time: 0.1833
DEBUG - 2022-11-15 01:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:32:05 --> Total execution time: 0.2987
DEBUG - 2022-11-15 01:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:13 --> Total execution time: 0.1776
DEBUG - 2022-11-15 01:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:25 --> Total execution time: 0.1717
DEBUG - 2022-11-15 01:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:29 --> Total execution time: 0.1725
DEBUG - 2022-11-15 01:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:43 --> Total execution time: 0.1638
DEBUG - 2022-11-15 01:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:02:46 --> Total execution time: 0.1911
DEBUG - 2022-11-15 01:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:32:48 --> Total execution time: 0.2474
DEBUG - 2022-11-15 01:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:03:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:33:42 --> Total execution time: 0.2292
DEBUG - 2022-11-15 01:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:03:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:33:50 --> Total execution time: 0.1823
DEBUG - 2022-11-15 01:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:33:59 --> Total execution time: 0.1731
DEBUG - 2022-11-15 01:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:03 --> Total execution time: 0.1233
DEBUG - 2022-11-15 01:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:04 --> Total execution time: 0.1597
DEBUG - 2022-11-15 01:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:07 --> Total execution time: 0.1758
DEBUG - 2022-11-15 01:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:10 --> Total execution time: 0.1843
DEBUG - 2022-11-15 01:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:12 --> Total execution time: 0.1950
DEBUG - 2022-11-15 01:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:21 --> Total execution time: 0.1732
DEBUG - 2022-11-15 01:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:25 --> Total execution time: 0.2283
DEBUG - 2022-11-15 01:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:33 --> Total execution time: 0.2309
DEBUG - 2022-11-15 01:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:40 --> Total execution time: 0.1166
DEBUG - 2022-11-15 01:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:51 --> Total execution time: 0.1054
DEBUG - 2022-11-15 01:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:53 --> Total execution time: 0.1975
DEBUG - 2022-11-15 01:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:58 --> Total execution time: 0.1806
DEBUG - 2022-11-15 01:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:04 --> Total execution time: 0.1708
DEBUG - 2022-11-15 01:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:05 --> Total execution time: 0.2164
DEBUG - 2022-11-15 01:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:10 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:10 --> Total execution time: 0.1622
DEBUG - 2022-11-15 01:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:11 --> Total execution time: 0.1618
DEBUG - 2022-11-15 01:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:13 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:13 --> Total execution time: 0.1745
DEBUG - 2022-11-15 01:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:16 --> Total execution time: 0.2143
DEBUG - 2022-11-15 01:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:24 --> Total execution time: 0.5076
DEBUG - 2022-11-15 01:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:24 --> Total execution time: 0.3123
DEBUG - 2022-11-15 01:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:24 --> Total execution time: 0.2673
DEBUG - 2022-11-15 01:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:30 --> Total execution time: 0.1866
DEBUG - 2022-11-15 01:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:34 --> Total execution time: 0.1933
DEBUG - 2022-11-15 01:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:40 --> Total execution time: 0.1957
DEBUG - 2022-11-15 01:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:44 --> Total execution time: 0.2166
DEBUG - 2022-11-15 01:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:04 --> Total execution time: 0.1774
DEBUG - 2022-11-15 01:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:11 --> Total execution time: 0.1816
DEBUG - 2022-11-15 01:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:21 --> Total execution time: 0.1982
DEBUG - 2022-11-15 01:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:21 --> Total execution time: 0.1755
DEBUG - 2022-11-15 01:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:26 --> Total execution time: 0.1758
DEBUG - 2022-11-15 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:29 --> Total execution time: 0.1804
DEBUG - 2022-11-15 01:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:32 --> Total execution time: 0.2347
DEBUG - 2022-11-15 01:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:33 --> Total execution time: 0.2117
DEBUG - 2022-11-15 01:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:36:58 --> Total execution time: 0.1731
DEBUG - 2022-11-15 01:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:03 --> Total execution time: 0.1853
DEBUG - 2022-11-15 01:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:04 --> Total execution time: 0.1702
DEBUG - 2022-11-15 01:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:08 --> Total execution time: 0.1827
DEBUG - 2022-11-15 01:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:12 --> Total execution time: 0.1795
DEBUG - 2022-11-15 01:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:19 --> Total execution time: 0.1710
DEBUG - 2022-11-15 01:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:24 --> Total execution time: 0.2049
DEBUG - 2022-11-15 01:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:26 --> Total execution time: 0.1861
DEBUG - 2022-11-15 01:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:27 --> Total execution time: 0.2206
DEBUG - 2022-11-15 01:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:28 --> Total execution time: 0.1852
DEBUG - 2022-11-15 01:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:39 --> Total execution time: 0.2655
DEBUG - 2022-11-15 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:37:40 --> Total execution time: 0.2210
DEBUG - 2022-11-15 01:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:41:10 --> Total execution time: 0.7158
DEBUG - 2022-11-15 01:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:11:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:41:56 --> Total execution time: 1.0210
DEBUG - 2022-11-15 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:12:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:42:25 --> Total execution time: 2.7455
DEBUG - 2022-11-15 01:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:16:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:46:17 --> Total execution time: 0.6590
DEBUG - 2022-11-15 01:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:17:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:48 --> Total execution time: 0.4767
DEBUG - 2022-11-15 01:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:47:49 --> Total execution time: 5.3499
DEBUG - 2022-11-15 01:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:49 --> Total execution time: 0.2375
DEBUG - 2022-11-15 01:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:53 --> Total execution time: 0.4271
DEBUG - 2022-11-15 01:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:05 --> Total execution time: 0.1797
DEBUG - 2022-11-15 01:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:42 --> Total execution time: 0.2207
DEBUG - 2022-11-15 01:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:19:46 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 01:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:33 --> Total execution time: 0.1754
DEBUG - 2022-11-15 01:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:42 --> Total execution time: 0.2074
DEBUG - 2022-11-15 01:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:44 --> Total execution time: 0.2771
DEBUG - 2022-11-15 01:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:44 --> Total execution time: 0.2075
DEBUG - 2022-11-15 01:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:54 --> Total execution time: 0.1792
DEBUG - 2022-11-15 01:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:51:56 --> Total execution time: 0.1760
DEBUG - 2022-11-15 01:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:52:23 --> Total execution time: 0.2041
DEBUG - 2022-11-15 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:23:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:53:15 --> Total execution time: 0.4657
DEBUG - 2022-11-15 01:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:24:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:54:20 --> Total execution time: 0.1153
DEBUG - 2022-11-15 01:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:24:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:54:24 --> Total execution time: 0.1703
DEBUG - 2022-11-15 01:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:24:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:54:28 --> Total execution time: 0.1752
DEBUG - 2022-11-15 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:26:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:56:58 --> Total execution time: 1.4292
DEBUG - 2022-11-15 01:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:03 --> Total execution time: 0.2790
DEBUG - 2022-11-15 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:15 --> Total execution time: 0.2940
DEBUG - 2022-11-15 01:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:22 --> Total execution time: 0.1815
DEBUG - 2022-11-15 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:23 --> Total execution time: 0.1926
DEBUG - 2022-11-15 01:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:36 --> Total execution time: 0.4592
DEBUG - 2022-11-15 01:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:29:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:47 --> Total execution time: 0.5981
DEBUG - 2022-11-15 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:56 --> Total execution time: 0.1781
DEBUG - 2022-11-15 01:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:02 --> Total execution time: 0.3252
DEBUG - 2022-11-15 01:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:10 --> Total execution time: 0.2970
DEBUG - 2022-11-15 01:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:26 --> Total execution time: 0.2240
DEBUG - 2022-11-15 01:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:39 --> Total execution time: 0.1716
DEBUG - 2022-11-15 01:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:03 --> Total execution time: 1.9090
DEBUG - 2022-11-15 01:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:12 --> Total execution time: 0.1695
DEBUG - 2022-11-15 01:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:15 --> Total execution time: 0.1825
DEBUG - 2022-11-15 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:32:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:22 --> Total execution time: 0.1825
DEBUG - 2022-11-15 01:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:32:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:22 --> Total execution time: 0.1766
DEBUG - 2022-11-15 01:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:15 --> Total execution time: 0.4781
DEBUG - 2022-11-15 01:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:31 --> Total execution time: 0.2766
DEBUG - 2022-11-15 01:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:32 --> Total execution time: 0.2168
DEBUG - 2022-11-15 01:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:32 --> Total execution time: 0.2306
DEBUG - 2022-11-15 01:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:03:33 --> Total execution time: 0.2276
DEBUG - 2022-11-15 01:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:33 --> Total execution time: 0.2940
DEBUG - 2022-11-15 01:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:34 --> Total execution time: 0.2136
DEBUG - 2022-11-15 01:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:04:23 --> Total execution time: 0.2037
DEBUG - 2022-11-15 01:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:04:27 --> Total execution time: 0.1796
DEBUG - 2022-11-15 01:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:04:45 --> Total execution time: 0.1276
DEBUG - 2022-11-15 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:34:51 --> Total execution time: 0.1718
DEBUG - 2022-11-15 01:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:34:59 --> Total execution time: 0.1767
DEBUG - 2022-11-15 01:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:34:59 --> Total execution time: 0.4624
DEBUG - 2022-11-15 01:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:13 --> Total execution time: 0.2663
DEBUG - 2022-11-15 01:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:13 --> Total execution time: 0.5788
DEBUG - 2022-11-15 01:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:19 --> Total execution time: 0.2260
DEBUG - 2022-11-15 01:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:37 --> Total execution time: 2.3480
DEBUG - 2022-11-15 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:35:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:17 --> Total execution time: 0.1897
DEBUG - 2022-11-15 01:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:20 --> Total execution time: 0.4214
DEBUG - 2022-11-15 01:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:36:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:46 --> Total execution time: 0.1976
DEBUG - 2022-11-15 01:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:53 --> Total execution time: 0.1244
DEBUG - 2022-11-15 01:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:37:22 --> 404 Page Not Found: Wp-admin/wp-admin.php
DEBUG - 2022-11-15 01:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:37:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:22 --> Total execution time: 0.1890
DEBUG - 2022-11-15 01:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:32 --> Total execution time: 0.5379
DEBUG - 2022-11-15 01:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:37:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:34 --> Total execution time: 0.1202
DEBUG - 2022-11-15 01:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:55 --> Total execution time: 0.1721
DEBUG - 2022-11-15 01:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:02 --> Total execution time: 0.2035
DEBUG - 2022-11-15 01:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:19 --> Total execution time: 0.1919
DEBUG - 2022-11-15 01:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:22 --> Total execution time: 0.1167
DEBUG - 2022-11-15 01:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:34 --> Total execution time: 0.1877
DEBUG - 2022-11-15 01:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:41 --> Total execution time: 0.1710
DEBUG - 2022-11-15 01:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:08:53 --> Total execution time: 0.1781
DEBUG - 2022-11-15 01:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:05 --> Total execution time: 0.1637
DEBUG - 2022-11-15 01:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:06 --> Total execution time: 0.1431
DEBUG - 2022-11-15 01:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:10 --> Total execution time: 0.1348
DEBUG - 2022-11-15 01:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:11 --> Total execution time: 0.1131
DEBUG - 2022-11-15 01:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:12 --> Total execution time: 0.1465
DEBUG - 2022-11-15 01:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:29 --> Total execution time: 0.1105
DEBUG - 2022-11-15 01:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:37 --> Total execution time: 0.1732
DEBUG - 2022-11-15 01:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:47 --> Total execution time: 0.1870
DEBUG - 2022-11-15 01:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:09:55 --> Total execution time: 0.2724
DEBUG - 2022-11-15 01:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:03 --> Total execution time: 0.2205
DEBUG - 2022-11-15 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:04 --> Total execution time: 0.2206
DEBUG - 2022-11-15 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:05 --> Total execution time: 0.2204
DEBUG - 2022-11-15 01:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:18 --> Total execution time: 0.2861
DEBUG - 2022-11-15 01:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:19 --> Total execution time: 0.1818
DEBUG - 2022-11-15 01:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:40:21 --> Total execution time: 0.1739
DEBUG - 2022-11-15 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:40:24 --> Total execution time: 0.2156
DEBUG - 2022-11-15 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:40:24 --> Total execution time: 0.1780
DEBUG - 2022-11-15 01:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:35 --> Total execution time: 0.1140
DEBUG - 2022-11-15 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:36 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:36 --> Total execution time: 0.1100
DEBUG - 2022-11-15 01:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:10:37 --> Total execution time: 0.1853
DEBUG - 2022-11-15 01:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:13 --> Total execution time: 0.1717
DEBUG - 2022-11-15 01:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:14 --> Total execution time: 0.1963
DEBUG - 2022-11-15 01:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:20 --> Total execution time: 0.2735
DEBUG - 2022-11-15 01:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:29 --> Total execution time: 0.1904
DEBUG - 2022-11-15 01:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:38 --> Total execution time: 0.1919
DEBUG - 2022-11-15 01:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:41:40 --> Total execution time: 0.1689
DEBUG - 2022-11-15 01:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:52 --> Total execution time: 0.5452
DEBUG - 2022-11-15 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:57 --> Total execution time: 0.2016
DEBUG - 2022-11-15 01:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:41:59 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:11:59 --> Total execution time: 0.1806
DEBUG - 2022-11-15 01:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:04 --> Total execution time: 0.2154
DEBUG - 2022-11-15 01:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:05 --> Total execution time: 0.4172
DEBUG - 2022-11-15 01:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:08 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:08 --> Total execution time: 0.4861
DEBUG - 2022-11-15 01:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:13 --> Total execution time: 0.1778
DEBUG - 2022-11-15 01:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:13 --> Total execution time: 0.1718
DEBUG - 2022-11-15 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:17 --> Total execution time: 0.1129
DEBUG - 2022-11-15 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:19 --> Total execution time: 0.2457
DEBUG - 2022-11-15 01:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:22 --> Total execution time: 0.5022
DEBUG - 2022-11-15 01:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:23 --> Total execution time: 0.3148
DEBUG - 2022-11-15 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:27 --> Total execution time: 0.2222
DEBUG - 2022-11-15 01:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:30 --> Total execution time: 0.2603
DEBUG - 2022-11-15 01:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:31 --> Total execution time: 0.1820
DEBUG - 2022-11-15 01:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:38 --> Total execution time: 0.1818
DEBUG - 2022-11-15 01:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:39 --> Total execution time: 0.1866
DEBUG - 2022-11-15 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:42:40 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-15 01:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:50 --> Total execution time: 0.1781
DEBUG - 2022-11-15 01:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:51 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:51 --> Total execution time: 0.1660
DEBUG - 2022-11-15 01:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:42:54 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-15 01:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:01 --> Total execution time: 0.2368
DEBUG - 2022-11-15 01:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:04 --> Total execution time: 0.2091
DEBUG - 2022-11-15 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:04 --> Total execution time: 0.1969
DEBUG - 2022-11-15 01:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:43:06 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 01:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:43:22 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 01:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:39 --> Total execution time: 0.1949
DEBUG - 2022-11-15 01:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:13:40 --> Total execution time: 0.1358
DEBUG - 2022-11-15 01:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:42 --> Total execution time: 0.2450
DEBUG - 2022-11-15 01:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:43:42 --> Total execution time: 0.5198
DEBUG - 2022-11-15 01:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:44:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:44:44 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-15 01:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:47:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:17:22 --> Total execution time: 0.6688
DEBUG - 2022-11-15 01:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:48:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:18:01 --> Total execution time: 0.9174
DEBUG - 2022-11-15 01:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:49:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:19:54 --> Total execution time: 0.5601
DEBUG - 2022-11-15 01:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:20:10 --> Total execution time: 0.2024
DEBUG - 2022-11-15 01:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:20:31 --> Total execution time: 0.3126
DEBUG - 2022-11-15 01:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:20:40 --> Total execution time: 0.2158
DEBUG - 2022-11-15 01:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:20:49 --> Total execution time: 0.1741
DEBUG - 2022-11-15 01:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:23:14 --> Total execution time: 0.1987
DEBUG - 2022-11-15 01:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:23:23 --> Total execution time: 0.3408
DEBUG - 2022-11-15 01:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:23:37 --> Total execution time: 0.2553
DEBUG - 2022-11-15 01:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:53:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:23:52 --> Total execution time: 0.1753
DEBUG - 2022-11-15 01:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:27:58 --> Total execution time: 0.9824
DEBUG - 2022-11-15 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:58:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:28:21 --> Total execution time: 0.1159
DEBUG - 2022-11-15 01:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:58:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 01:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:28:28 --> Total execution time: 0.1736
DEBUG - 2022-11-15 01:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:28:45 --> Total execution time: 0.1862
DEBUG - 2022-11-15 01:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:29:24 --> Total execution time: 0.1700
DEBUG - 2022-11-15 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:29:38 --> Total execution time: 0.2059
DEBUG - 2022-11-15 01:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:29:40 --> Total execution time: 0.1740
DEBUG - 2022-11-15 01:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 01:59:51 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 01:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:29:51 --> Total execution time: 0.2858
DEBUG - 2022-11-15 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:29:58 --> Total execution time: 0.1725
DEBUG - 2022-11-15 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:03 --> Total execution time: 0.1886
DEBUG - 2022-11-15 02:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:38 --> Total execution time: 0.4837
DEBUG - 2022-11-15 02:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:38 --> Total execution time: 0.1752
DEBUG - 2022-11-15 02:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:50 --> Total execution time: 0.2412
DEBUG - 2022-11-15 02:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:56 --> Total execution time: 0.1986
DEBUG - 2022-11-15 02:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:05 --> Total execution time: 0.1959
DEBUG - 2022-11-15 02:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:20 --> Total execution time: 0.1710
DEBUG - 2022-11-15 02:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:33:05 --> Total execution time: 0.3054
DEBUG - 2022-11-15 02:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:34:16 --> Total execution time: 0.3319
DEBUG - 2022-11-15 02:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:35:11 --> Total execution time: 0.1945
DEBUG - 2022-11-15 02:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:35:30 --> Total execution time: 0.1869
DEBUG - 2022-11-15 02:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:35:42 --> Total execution time: 0.8941
DEBUG - 2022-11-15 02:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:35:44 --> Total execution time: 0.3833
DEBUG - 2022-11-15 02:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:35:58 --> Total execution time: 0.2479
DEBUG - 2022-11-15 02:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:36:44 --> Total execution time: 0.1940
DEBUG - 2022-11-15 02:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:36:51 --> Total execution time: 0.2384
DEBUG - 2022-11-15 02:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:37:02 --> Total execution time: 0.1914
DEBUG - 2022-11-15 02:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:37:52 --> Total execution time: 0.2484
DEBUG - 2022-11-15 02:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:37:59 --> Total execution time: 0.1769
DEBUG - 2022-11-15 02:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:38:03 --> Total execution time: 0.1831
DEBUG - 2022-11-15 02:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:38:04 --> Total execution time: 0.2139
DEBUG - 2022-11-15 02:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:38:17 --> Total execution time: 0.2089
DEBUG - 2022-11-15 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:09:26 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:39:26 --> Total execution time: 0.1474
DEBUG - 2022-11-15 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:09:26 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:39:27 --> Total execution time: 0.1086
DEBUG - 2022-11-15 02:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:10:20 --> Total execution time: 2.8011
DEBUG - 2022-11-15 02:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:10:22 --> Total execution time: 0.3683
DEBUG - 2022-11-15 02:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:10:24 --> Total execution time: 1.4162
DEBUG - 2022-11-15 02:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:40:43 --> Total execution time: 0.9052
DEBUG - 2022-11-15 13:40:43 --> Total execution time: 0.3737
DEBUG - 2022-11-15 02:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:41:23 --> Total execution time: 4.2068
DEBUG - 2022-11-15 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:41:33 --> Total execution time: 0.2505
DEBUG - 2022-11-15 02:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:02 --> Total execution time: 0.3938
DEBUG - 2022-11-15 02:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:04 --> Total execution time: 0.2220
DEBUG - 2022-11-15 02:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:05 --> Total execution time: 0.2081
DEBUG - 2022-11-15 02:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:21 --> Total execution time: 0.1941
DEBUG - 2022-11-15 02:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:27 --> Total execution time: 0.1093
DEBUG - 2022-11-15 02:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:42:31 --> Total execution time: 0.1625
DEBUG - 2022-11-15 02:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:43:33 --> Total execution time: 2.9114
DEBUG - 2022-11-15 02:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:44:01 --> Total execution time: 2.0401
DEBUG - 2022-11-15 02:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:44:56 --> Total execution time: 2.4719
DEBUG - 2022-11-15 02:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:46:02 --> Total execution time: 4.1295
DEBUG - 2022-11-15 02:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:47:50 --> Total execution time: 0.1726
DEBUG - 2022-11-15 02:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:09 --> Total execution time: 0.2217
DEBUG - 2022-11-15 02:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:10 --> Total execution time: 0.1873
DEBUG - 2022-11-15 02:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:18 --> Total execution time: 0.5001
DEBUG - 2022-11-15 02:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:18 --> Total execution time: 0.1885
DEBUG - 2022-11-15 02:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:18 --> Total execution time: 0.1163
DEBUG - 2022-11-15 02:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:24 --> Total execution time: 0.2328
DEBUG - 2022-11-15 02:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:34 --> Total execution time: 0.1945
DEBUG - 2022-11-15 02:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:37 --> Total execution time: 0.1791
DEBUG - 2022-11-15 02:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:40 --> Total execution time: 0.1778
DEBUG - 2022-11-15 02:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:45 --> Total execution time: 0.1850
DEBUG - 2022-11-15 02:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:53 --> Total execution time: 0.1849
DEBUG - 2022-11-15 02:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:50:01 --> Total execution time: 0.2279
DEBUG - 2022-11-15 02:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:51:55 --> Total execution time: 0.3409
DEBUG - 2022-11-15 02:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:22:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:23 --> Total execution time: 0.1500
DEBUG - 2022-11-15 02:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:22:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:42 --> Total execution time: 0.1145
DEBUG - 2022-11-15 02:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:59 --> Total execution time: 0.2032
DEBUG - 2022-11-15 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:09 --> Total execution time: 0.2226
DEBUG - 2022-11-15 02:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:24 --> Total execution time: 0.2335
DEBUG - 2022-11-15 02:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:40 --> Total execution time: 0.3561
DEBUG - 2022-11-15 02:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:04 --> Total execution time: 0.1871
DEBUG - 2022-11-15 02:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:14 --> Total execution time: 0.1951
DEBUG - 2022-11-15 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:22 --> Total execution time: 0.1994
DEBUG - 2022-11-15 02:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:30 --> Total execution time: 0.1805
DEBUG - 2022-11-15 02:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:35 --> Total execution time: 0.1915
DEBUG - 2022-11-15 02:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:01:48 --> Total execution time: 0.1666
DEBUG - 2022-11-15 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:02:19 --> Total execution time: 0.4668
DEBUG - 2022-11-15 02:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:02:50 --> Total execution time: 0.1677
DEBUG - 2022-11-15 02:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:03:26 --> Total execution time: 0.1692
DEBUG - 2022-11-15 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:33 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:03:33 --> Total execution time: 0.1100
DEBUG - 2022-11-15 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:03:34 --> Total execution time: 0.1057
DEBUG - 2022-11-15 02:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:33:48 --> Total execution time: 0.1803
DEBUG - 2022-11-15 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:33:50 --> Total execution time: 0.1762
DEBUG - 2022-11-15 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:33:50 --> Total execution time: 0.1755
DEBUG - 2022-11-15 02:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:34:28 --> Total execution time: 0.1714
DEBUG - 2022-11-15 02:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:34:33 --> Total execution time: 0.1917
DEBUG - 2022-11-15 02:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:34:37 --> Total execution time: 0.1772
DEBUG - 2022-11-15 02:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:04:44 --> Total execution time: 2.1179
DEBUG - 2022-11-15 02:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:34:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:34:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 02:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:05:02 --> Total execution time: 0.2478
DEBUG - 2022-11-15 02:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:05:37 --> Total execution time: 0.3994
DEBUG - 2022-11-15 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:05:47 --> Total execution time: 0.2942
DEBUG - 2022-11-15 02:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:00 --> Total execution time: 0.2266
DEBUG - 2022-11-15 02:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:07 --> Total execution time: 0.7142
DEBUG - 2022-11-15 02:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:35 --> Total execution time: 0.6865
DEBUG - 2022-11-15 02:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:40 --> Total execution time: 0.2858
DEBUG - 2022-11-15 02:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:52 --> Total execution time: 0.8021
DEBUG - 2022-11-15 02:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:06:57 --> Total execution time: 1.1248
DEBUG - 2022-11-15 02:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:07:03 --> Total execution time: 0.1857
DEBUG - 2022-11-15 02:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:07:09 --> Total execution time: 0.3135
DEBUG - 2022-11-15 02:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:09:17 --> Total execution time: 2.8235
DEBUG - 2022-11-15 02:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:09:24 --> Total execution time: 0.4355
DEBUG - 2022-11-15 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:42:36 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:12:37 --> Total execution time: 0.6343
DEBUG - 2022-11-15 02:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:43:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:43:22 --> 404 Page Not Found: Stylephp/index
DEBUG - 2022-11-15 02:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:43:46 --> 404 Page Not Found: Stylephp/index
DEBUG - 2022-11-15 02:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:16:43 --> Total execution time: 0.1857
DEBUG - 2022-11-15 02:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:16:57 --> Total execution time: 0.1189
DEBUG - 2022-11-15 02:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:16:58 --> Total execution time: 0.1944
DEBUG - 2022-11-15 02:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:07 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:17:07 --> Total execution time: 0.1712
DEBUG - 2022-11-15 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:17:08 --> Total execution time: 0.2291
DEBUG - 2022-11-15 02:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:17:36 --> Total execution time: 0.1713
DEBUG - 2022-11-15 02:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:17:41 --> Total execution time: 0.1901
DEBUG - 2022-11-15 02:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:00 --> Total execution time: 0.2396
DEBUG - 2022-11-15 02:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:06 --> Total execution time: 0.2015
DEBUG - 2022-11-15 02:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:11 --> Total execution time: 0.2096
DEBUG - 2022-11-15 02:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:19 --> Total execution time: 0.2093
DEBUG - 2022-11-15 02:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:25 --> Total execution time: 0.1964
DEBUG - 2022-11-15 02:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:30 --> Total execution time: 0.1758
DEBUG - 2022-11-15 02:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:44 --> Total execution time: 0.1834
DEBUG - 2022-11-15 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:53 --> Total execution time: 0.2609
DEBUG - 2022-11-15 02:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:18:55 --> Total execution time: 0.2236
DEBUG - 2022-11-15 02:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:19:03 --> Total execution time: 0.1656
DEBUG - 2022-11-15 02:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:19:08 --> Total execution time: 0.2121
DEBUG - 2022-11-15 02:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:19:44 --> Total execution time: 0.4924
DEBUG - 2022-11-15 02:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:19:51 --> Total execution time: 0.2346
DEBUG - 2022-11-15 02:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:19:52 --> Total execution time: 0.1761
DEBUG - 2022-11-15 02:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:21 --> Total execution time: 0.1947
DEBUG - 2022-11-15 02:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:30 --> Total execution time: 0.2338
DEBUG - 2022-11-15 02:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:36 --> Total execution time: 0.2045
DEBUG - 2022-11-15 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:43 --> Total execution time: 0.1836
DEBUG - 2022-11-15 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:45 --> Total execution time: 0.1239
DEBUG - 2022-11-15 02:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:20:56 --> Total execution time: 0.1681
DEBUG - 2022-11-15 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:01 --> Total execution time: 0.1097
DEBUG - 2022-11-15 02:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:06 --> Total execution time: 0.1854
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:51:10 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 02:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:14 --> Total execution time: 0.1716
DEBUG - 2022-11-15 02:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:24 --> Total execution time: 0.1782
DEBUG - 2022-11-15 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:31 --> Total execution time: 0.2544
DEBUG - 2022-11-15 02:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:21:53 --> Total execution time: 0.2580
DEBUG - 2022-11-15 02:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 02:51:54 --> Total execution time: 0.2011
DEBUG - 2022-11-15 02:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:22:11 --> Total execution time: 0.4586
DEBUG - 2022-11-15 02:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:22:58 --> Total execution time: 0.1668
DEBUG - 2022-11-15 02:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:53:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 02:53:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:55:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:25:42 --> Total execution time: 0.1214
DEBUG - 2022-11-15 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 02:55:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:25:42 --> Total execution time: 0.1691
DEBUG - 2022-11-15 08:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:18:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:48:33 --> Total execution time: 0.5513
DEBUG - 2022-11-15 08:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:18:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:48:47 --> Total execution time: 0.1365
DEBUG - 2022-11-15 08:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:18:59 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:48:59 --> Total execution time: 0.1314
DEBUG - 2022-11-15 08:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:19:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:49:28 --> Total execution time: 0.1309
DEBUG - 2022-11-15 08:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:50:20 --> Total execution time: 0.1880
DEBUG - 2022-11-15 08:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:50:22 --> Total execution time: 0.1431
DEBUG - 2022-11-15 08:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:20:30 --> Total execution time: 0.1908
DEBUG - 2022-11-15 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:50:32 --> Total execution time: 0.2111
DEBUG - 2022-11-15 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:20:32 --> Total execution time: 0.2716
DEBUG - 2022-11-15 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:20:32 --> Total execution time: 0.2207
DEBUG - 2022-11-15 08:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:20:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:50:46 --> Total execution time: 0.1890
DEBUG - 2022-11-15 08:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:51:16 --> Total execution time: 2.5400
DEBUG - 2022-11-15 08:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:21:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 08:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:51:28 --> Total execution time: 0.1468
DEBUG - 2022-11-15 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:51:35 --> Total execution time: 0.2077
DEBUG - 2022-11-15 08:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:51:56 --> Total execution time: 0.1952
DEBUG - 2022-11-15 08:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:51:58 --> Total execution time: 0.4138
DEBUG - 2022-11-15 08:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:52:10 --> Total execution time: 0.2256
DEBUG - 2022-11-15 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:52:21 --> Total execution time: 0.2528
DEBUG - 2022-11-15 08:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:52:28 --> Total execution time: 0.2067
DEBUG - 2022-11-15 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:52:34 --> Total execution time: 0.1937
DEBUG - 2022-11-15 08:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:52:38 --> Total execution time: 0.2270
DEBUG - 2022-11-15 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:23:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:53:20 --> Total execution time: 0.1310
DEBUG - 2022-11-15 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:23:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:53:21 --> Total execution time: 0.1369
DEBUG - 2022-11-15 08:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:23:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:53:39 --> Total execution time: 0.1265
DEBUG - 2022-11-15 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:37 --> Total execution time: 0.1375
DEBUG - 2022-11-15 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:38 --> Total execution time: 0.1397
DEBUG - 2022-11-15 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:47 --> Total execution time: 0.2387
DEBUG - 2022-11-15 08:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:48 --> Total execution time: 0.1360
DEBUG - 2022-11-15 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:55 --> Total execution time: 0.2649
DEBUG - 2022-11-15 08:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:13 --> Total execution time: 0.1920
DEBUG - 2022-11-15 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:16 --> Total execution time: 0.2289
DEBUG - 2022-11-15 08:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:24 --> Total execution time: 0.2938
DEBUG - 2022-11-15 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:24 --> Total execution time: 0.2207
DEBUG - 2022-11-15 08:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:26 --> Total execution time: 0.1960
DEBUG - 2022-11-15 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:39 --> Total execution time: 0.2558
DEBUG - 2022-11-15 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:42 --> Total execution time: 0.1976
DEBUG - 2022-11-15 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:49 --> Total execution time: 0.1967
DEBUG - 2022-11-15 08:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:51 --> Total execution time: 0.1928
DEBUG - 2022-11-15 08:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:25:52 --> Total execution time: 0.1896
DEBUG - 2022-11-15 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:55:56 --> Total execution time: 0.1963
DEBUG - 2022-11-15 08:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:01 --> Total execution time: 0.1360
DEBUG - 2022-11-15 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:56:05 --> Total execution time: 0.1863
DEBUG - 2022-11-15 08:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:05 --> Total execution time: 0.2373
DEBUG - 2022-11-15 08:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:32 --> Total execution time: 0.1248
DEBUG - 2022-11-15 08:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:35 --> Total execution time: 0.1289
DEBUG - 2022-11-15 08:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:49 --> Total execution time: 0.1976
DEBUG - 2022-11-15 08:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:56:54 --> Total execution time: 0.1843
DEBUG - 2022-11-15 08:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:04 --> Total execution time: 0.1991
DEBUG - 2022-11-15 08:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:11 --> Total execution time: 0.1900
DEBUG - 2022-11-15 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:16 --> Total execution time: 0.1846
DEBUG - 2022-11-15 08:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:18 --> Total execution time: 0.1702
DEBUG - 2022-11-15 08:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:22 --> Total execution time: 0.1897
DEBUG - 2022-11-15 08:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:25 --> Total execution time: 0.2051
DEBUG - 2022-11-15 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:33 --> Total execution time: 0.2003
DEBUG - 2022-11-15 19:57:33 --> Total execution time: 0.6289
DEBUG - 2022-11-15 08:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:36 --> Total execution time: 0.2608
DEBUG - 2022-11-15 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:37 --> Total execution time: 0.1283
DEBUG - 2022-11-15 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:57:44 --> Total execution time: 0.2817
DEBUG - 2022-11-15 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:45 --> Total execution time: 0.1943
DEBUG - 2022-11-15 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:46 --> Total execution time: 0.1903
DEBUG - 2022-11-15 08:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:48 --> Total execution time: 0.1926
DEBUG - 2022-11-15 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:57:52 --> Total execution time: 0.2403
DEBUG - 2022-11-15 08:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:06 --> Total execution time: 0.2535
DEBUG - 2022-11-15 08:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:07 --> Total execution time: 0.2063
DEBUG - 2022-11-15 08:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:19 --> Total execution time: 0.2062
DEBUG - 2022-11-15 08:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:23 --> Total execution time: 0.2175
DEBUG - 2022-11-15 08:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:24 --> Total execution time: 0.1357
DEBUG - 2022-11-15 08:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:25 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:25 --> Total execution time: 0.1287
DEBUG - 2022-11-15 08:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:31 --> Total execution time: 0.2115
DEBUG - 2022-11-15 08:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:35 --> Total execution time: 0.1345
DEBUG - 2022-11-15 08:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:36 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:36 --> Total execution time: 0.1300
DEBUG - 2022-11-15 08:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:38 --> Total execution time: 0.1837
DEBUG - 2022-11-15 08:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:58:42 --> Total execution time: 2.0120
DEBUG - 2022-11-15 08:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:28:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:28:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 08:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:08 --> Total execution time: 0.6883
DEBUG - 2022-11-15 08:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:15 --> Total execution time: 0.1321
DEBUG - 2022-11-15 08:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:19 --> Total execution time: 0.4640
DEBUG - 2022-11-15 08:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:22 --> Total execution time: 0.2604
DEBUG - 2022-11-15 08:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:29 --> Total execution time: 0.2197
DEBUG - 2022-11-15 08:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:32 --> Total execution time: 1.7684
DEBUG - 2022-11-15 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:59:47 --> Total execution time: 0.1903
DEBUG - 2022-11-15 08:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:04 --> Total execution time: 0.2452
DEBUG - 2022-11-15 08:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:04 --> Total execution time: 0.1424
DEBUG - 2022-11-15 08:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:08 --> Total execution time: 0.2295
DEBUG - 2022-11-15 08:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:14 --> Total execution time: 0.2060
DEBUG - 2022-11-15 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:19 --> Total execution time: 0.2593
DEBUG - 2022-11-15 08:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:22 --> Total execution time: 0.2278
DEBUG - 2022-11-15 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:29 --> Total execution time: 0.2244
DEBUG - 2022-11-15 08:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:43 --> Total execution time: 0.2223
DEBUG - 2022-11-15 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:45 --> Total execution time: 0.3214
DEBUG - 2022-11-15 08:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:48 --> Total execution time: 0.1984
DEBUG - 2022-11-15 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:00 --> Total execution time: 0.1943
DEBUG - 2022-11-15 08:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:02 --> Total execution time: 0.4103
DEBUG - 2022-11-15 08:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:05 --> Total execution time: 0.2089
DEBUG - 2022-11-15 08:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:08 --> Total execution time: 0.2054
DEBUG - 2022-11-15 08:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:12 --> Total execution time: 0.2366
DEBUG - 2022-11-15 08:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:14 --> Total execution time: 0.2916
DEBUG - 2022-11-15 08:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:15 --> Total execution time: 0.3300
DEBUG - 2022-11-15 08:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:19 --> Total execution time: 0.2143
DEBUG - 2022-11-15 08:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:25 --> Total execution time: 0.2182
DEBUG - 2022-11-15 08:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:28 --> Total execution time: 0.2429
DEBUG - 2022-11-15 08:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:31 --> Total execution time: 0.3008
DEBUG - 2022-11-15 08:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:50 --> Total execution time: 0.2868
DEBUG - 2022-11-15 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:08 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:08 --> Total execution time: 0.1433
DEBUG - 2022-11-15 08:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:19 --> Total execution time: 0.1925
DEBUG - 2022-11-15 08:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:20 --> Total execution time: 0.2049
DEBUG - 2022-11-15 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:30 --> Total execution time: 0.2484
DEBUG - 2022-11-15 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:34 --> Total execution time: 0.2436
DEBUG - 2022-11-15 08:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:44 --> Total execution time: 0.1883
DEBUG - 2022-11-15 08:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:50 --> Total execution time: 0.2008
DEBUG - 2022-11-15 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:53 --> Total execution time: 0.2534
DEBUG - 2022-11-15 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:55 --> Total execution time: 0.1869
DEBUG - 2022-11-15 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:03:21 --> Total execution time: 0.1934
DEBUG - 2022-11-15 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:03:58 --> Total execution time: 0.5523
DEBUG - 2022-11-15 08:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:04:00 --> Total execution time: 0.1985
DEBUG - 2022-11-15 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:04:02 --> Total execution time: 0.1921
DEBUG - 2022-11-15 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:34:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:04:50 --> Total execution time: 0.1424
DEBUG - 2022-11-15 08:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:34:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:04:56 --> Total execution time: 0.1927
DEBUG - 2022-11-15 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:05:02 --> Total execution time: 0.5065
DEBUG - 2022-11-15 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:35:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:05:38 --> Total execution time: 0.2086
DEBUG - 2022-11-15 08:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:05:39 --> Total execution time: 0.1912
DEBUG - 2022-11-15 08:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:06:46 --> Total execution time: 0.2323
DEBUG - 2022-11-15 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:06:56 --> Total execution time: 0.1970
DEBUG - 2022-11-15 08:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:06:58 --> Total execution time: 0.1872
DEBUG - 2022-11-15 08:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:03 --> Total execution time: 0.1881
DEBUG - 2022-11-15 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:18 --> Total execution time: 0.2318
DEBUG - 2022-11-15 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:21 --> Total execution time: 0.1941
DEBUG - 2022-11-15 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:31 --> Total execution time: 0.1942
DEBUG - 2022-11-15 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:38 --> Total execution time: 0.1846
DEBUG - 2022-11-15 08:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:54 --> Total execution time: 0.1975
DEBUG - 2022-11-15 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:00 --> Total execution time: 0.1966
DEBUG - 2022-11-15 08:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:07 --> Total execution time: 0.2070
DEBUG - 2022-11-15 08:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:10 --> Total execution time: 0.2127
DEBUG - 2022-11-15 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:18 --> Total execution time: 0.2266
DEBUG - 2022-11-15 08:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:19 --> Total execution time: 0.1971
DEBUG - 2022-11-15 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:24 --> Total execution time: 0.2022
DEBUG - 2022-11-15 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:24 --> Total execution time: 0.2170
DEBUG - 2022-11-15 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:25 --> Total execution time: 0.3049
DEBUG - 2022-11-15 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:25 --> Total execution time: 0.4115
DEBUG - 2022-11-15 08:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:10 --> Total execution time: 0.2074
DEBUG - 2022-11-15 08:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:18 --> Total execution time: 0.2104
DEBUG - 2022-11-15 08:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:04 --> Total execution time: 0.5274
DEBUG - 2022-11-15 08:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:20 --> Total execution time: 0.1393
DEBUG - 2022-11-15 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:24 --> Total execution time: 0.1369
DEBUG - 2022-11-15 08:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:40 --> Total execution time: 0.1937
DEBUG - 2022-11-15 08:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:41 --> Total execution time: 0.2002
DEBUG - 2022-11-15 08:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:56 --> Total execution time: 0.2907
DEBUG - 2022-11-15 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:00 --> Total execution time: 0.2198
DEBUG - 2022-11-15 08:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:05 --> Total execution time: 0.2255
DEBUG - 2022-11-15 08:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:13 --> Total execution time: 0.2377
DEBUG - 2022-11-15 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:21 --> Total execution time: 0.5256
DEBUG - 2022-11-15 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:22 --> Total execution time: 0.2225
DEBUG - 2022-11-15 08:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:25 --> Total execution time: 0.1315
DEBUG - 2022-11-15 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-15 08:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:39 --> Total execution time: 0.2311
DEBUG - 2022-11-15 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:44 --> Total execution time: 0.2409
DEBUG - 2022-11-15 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:49 --> Total execution time: 0.1887
DEBUG - 2022-11-15 08:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:51 --> Total execution time: 0.2213
DEBUG - 2022-11-15 08:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:56 --> Total execution time: 0.2026
DEBUG - 2022-11-15 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:03 --> Total execution time: 0.1972
DEBUG - 2022-11-15 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:42:03 --> Total execution time: 0.1917
DEBUG - 2022-11-15 08:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:09 --> Total execution time: 0.2009
DEBUG - 2022-11-15 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:13 --> Total execution time: 0.1942
DEBUG - 2022-11-15 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:17 --> Total execution time: 0.2183
DEBUG - 2022-11-15 08:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:17 --> Total execution time: 0.3579
DEBUG - 2022-11-15 08:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:45 --> Total execution time: 0.2235
DEBUG - 2022-11-15 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:58 --> Total execution time: 0.2077
DEBUG - 2022-11-15 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:01 --> Total execution time: 0.2617
DEBUG - 2022-11-15 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:08 --> Total execution time: 0.2410
DEBUG - 2022-11-15 08:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:09 --> Total execution time: 0.2405
DEBUG - 2022-11-15 08:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:26 --> Total execution time: 0.2017
DEBUG - 2022-11-15 08:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:33 --> Total execution time: 0.1894
DEBUG - 2022-11-15 08:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:46 --> Total execution time: 0.1285
DEBUG - 2022-11-15 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:55 --> Total execution time: 0.1972
DEBUG - 2022-11-15 08:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:43:57 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 08:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:44:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:14:28 --> Total execution time: 0.1478
DEBUG - 2022-11-15 08:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:14:35 --> Total execution time: 0.1867
DEBUG - 2022-11-15 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:44:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:44:51 --> 404 Page Not Found: Westinghouse-marble-finish-low-casserole-914923html/index
DEBUG - 2022-11-15 08:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:15:04 --> Total execution time: 0.2092
DEBUG - 2022-11-15 08:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:15:28 --> Total execution time: 2.4394
DEBUG - 2022-11-15 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:15:45 --> Total execution time: 0.2879
DEBUG - 2022-11-15 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:46:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:16:49 --> Total execution time: 0.4735
DEBUG - 2022-11-15 08:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:01 --> Total execution time: 0.1980
DEBUG - 2022-11-15 08:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:05 --> Total execution time: 0.1943
DEBUG - 2022-11-15 08:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:22 --> Total execution time: 0.2082
DEBUG - 2022-11-15 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:28 --> Total execution time: 0.2253
DEBUG - 2022-11-15 08:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:53 --> Total execution time: 0.2112
DEBUG - 2022-11-15 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:12 --> Total execution time: 0.1959
DEBUG - 2022-11-15 08:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:19 --> Total execution time: 0.2372
DEBUG - 2022-11-15 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:21 --> Total execution time: 0.2132
DEBUG - 2022-11-15 08:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:22 --> Total execution time: 0.2437
DEBUG - 2022-11-15 08:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:25 --> Total execution time: 0.2183
DEBUG - 2022-11-15 08:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:30 --> Total execution time: 0.2012
DEBUG - 2022-11-15 08:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:35 --> Total execution time: 0.1989
DEBUG - 2022-11-15 08:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:39 --> Total execution time: 0.2086
DEBUG - 2022-11-15 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:43 --> Total execution time: 0.2339
DEBUG - 2022-11-15 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:11 --> Total execution time: 0.1882
DEBUG - 2022-11-15 08:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:22 --> Total execution time: 2.1977
DEBUG - 2022-11-15 08:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:31 --> Total execution time: 0.2984
DEBUG - 2022-11-15 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:22:26 --> Total execution time: 0.6610
DEBUG - 2022-11-15 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:52:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:22:32 --> Total execution time: 0.1911
DEBUG - 2022-11-15 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:22:40 --> Total execution time: 1.7886
DEBUG - 2022-11-15 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:55:37 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-15 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:55:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:55:37 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-15 08:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:27:16 --> Total execution time: 0.6830
DEBUG - 2022-11-15 08:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:28:59 --> Total execution time: 0.9657
DEBUG - 2022-11-15 08:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 08:59:00 --> 404 Page Not Found: Department-56-the-maltings-heritage-village-collection-dickens-series-8-x-5-x-8-375979html/index
DEBUG - 2022-11-15 08:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 08:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:21 --> Total execution time: 0.2344
DEBUG - 2022-11-15 08:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:42 --> Total execution time: 0.2320
DEBUG - 2022-11-15 08:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:49 --> Total execution time: 0.2316
DEBUG - 2022-11-15 08:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:53 --> Total execution time: 0.2202
DEBUG - 2022-11-15 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:56 --> Total execution time: 0.2005
DEBUG - 2022-11-15 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:02 --> Total execution time: 0.1309
DEBUG - 2022-11-15 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:06 --> Total execution time: 0.1398
DEBUG - 2022-11-15 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:08 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:08 --> Total execution time: 0.1309
DEBUG - 2022-11-15 09:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:19 --> Total execution time: 0.2145
DEBUG - 2022-11-15 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:50 --> Total execution time: 0.2092
DEBUG - 2022-11-15 09:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:51 --> Total execution time: 0.2113
DEBUG - 2022-11-15 09:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:54 --> Total execution time: 0.2094
DEBUG - 2022-11-15 09:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:31:46 --> Total execution time: 0.1872
DEBUG - 2022-11-15 09:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:19 --> Total execution time: 0.1368
DEBUG - 2022-11-15 09:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:32 --> Total execution time: 0.2251
DEBUG - 2022-11-15 09:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:34 --> Total execution time: 0.2563
DEBUG - 2022-11-15 09:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:40 --> Total execution time: 0.1966
DEBUG - 2022-11-15 09:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:44 --> Total execution time: 0.2242
DEBUG - 2022-11-15 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:51 --> Total execution time: 0.2054
DEBUG - 2022-11-15 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:53 --> Total execution time: 0.2265
DEBUG - 2022-11-15 09:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:02 --> Total execution time: 0.1352
DEBUG - 2022-11-15 09:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:03 --> Total execution time: 0.1355
DEBUG - 2022-11-15 09:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:04 --> Total execution time: 0.2271
DEBUG - 2022-11-15 09:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:07 --> Total execution time: 0.2032
DEBUG - 2022-11-15 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:10 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:10 --> Total execution time: 0.1495
DEBUG - 2022-11-15 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:11 --> Total execution time: 0.1489
DEBUG - 2022-11-15 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:11 --> Total execution time: 0.2067
DEBUG - 2022-11-15 09:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:23 --> Total execution time: 0.2250
DEBUG - 2022-11-15 09:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:23 --> Total execution time: 0.2025
DEBUG - 2022-11-15 09:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:24 --> Total execution time: 0.2016
DEBUG - 2022-11-15 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:24 --> Total execution time: 0.4589
DEBUG - 2022-11-15 09:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:03:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:24 --> Total execution time: 0.4568
DEBUG - 2022-11-15 09:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:33:25 --> Total execution time: 0.4381
DEBUG - 2022-11-15 09:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:04:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:34:04 --> Total execution time: 0.2051
DEBUG - 2022-11-15 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:34:18 --> Total execution time: 0.1884
DEBUG - 2022-11-15 09:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:04:29 --> 404 Page Not Found: Mike-funko-pop-stranger-things-277691html/index
DEBUG - 2022-11-15 09:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:05:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:35:17 --> Total execution time: 0.2056
DEBUG - 2022-11-15 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:35:28 --> Total execution time: 0.2175
DEBUG - 2022-11-15 09:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:35:33 --> Total execution time: 0.1910
DEBUG - 2022-11-15 09:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:36:06 --> Total execution time: 0.1873
DEBUG - 2022-11-15 09:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:36:34 --> Total execution time: 0.1990
DEBUG - 2022-11-15 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:51 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:36:51 --> Total execution time: 0.1986
DEBUG - 2022-11-15 09:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:36:56 --> Total execution time: 0.2026
DEBUG - 2022-11-15 09:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:37:06 --> Total execution time: 0.2005
DEBUG - 2022-11-15 09:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:37:27 --> Total execution time: 0.7844
DEBUG - 2022-11-15 09:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:37:48 --> Total execution time: 2.3122
DEBUG - 2022-11-15 09:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:37:48 --> Total execution time: 3.1505
DEBUG - 2022-11-15 09:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:08:20 --> 404 Page Not Found: Jeans-men-521303html/index
DEBUG - 2022-11-15 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:38:40 --> Total execution time: 0.2039
DEBUG - 2022-11-15 09:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:08:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:38:56 --> Total execution time: 0.1356
DEBUG - 2022-11-15 09:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:07 --> Total execution time: 5.3355
DEBUG - 2022-11-15 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:10:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:38 --> Total execution time: 0.3312
DEBUG - 2022-11-15 09:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:10:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:10:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 09:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:10:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:43 --> Total execution time: 0.1831
DEBUG - 2022-11-15 09:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:54 --> Total execution time: 0.1942
DEBUG - 2022-11-15 09:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:01 --> Total execution time: 0.5177
DEBUG - 2022-11-15 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:06 --> Total execution time: 0.2151
DEBUG - 2022-11-15 09:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:09 --> Total execution time: 0.2329
DEBUG - 2022-11-15 09:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:13 --> Total execution time: 0.2179
DEBUG - 2022-11-15 09:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:15 --> Total execution time: 0.1917
DEBUG - 2022-11-15 09:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:16 --> Total execution time: 0.1888
DEBUG - 2022-11-15 09:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:23 --> Total execution time: 0.1888
DEBUG - 2022-11-15 09:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:29 --> Total execution time: 0.1987
DEBUG - 2022-11-15 09:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:40 --> Total execution time: 0.5109
DEBUG - 2022-11-15 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:45 --> Total execution time: 0.2446
DEBUG - 2022-11-15 09:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:41:51 --> Total execution time: 0.2052
DEBUG - 2022-11-15 09:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:00 --> Total execution time: 0.1808
DEBUG - 2022-11-15 09:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:25 --> Total execution time: 0.2085
DEBUG - 2022-11-15 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:33 --> Total execution time: 0.2120
DEBUG - 2022-11-15 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:43 --> Total execution time: 0.1955
DEBUG - 2022-11-15 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:50 --> Total execution time: 0.2013
DEBUG - 2022-11-15 09:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:12 --> Total execution time: 0.1995
DEBUG - 2022-11-15 09:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:44:00 --> Total execution time: 0.1951
DEBUG - 2022-11-15 09:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:14:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:44:30 --> Total execution time: 0.1482
DEBUG - 2022-11-15 09:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:44:53 --> Total execution time: 0.1929
DEBUG - 2022-11-15 09:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:45:02 --> Total execution time: 0.3278
DEBUG - 2022-11-15 09:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:45:12 --> Total execution time: 0.2369
DEBUG - 2022-11-15 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:45:25 --> Total execution time: 0.2294
DEBUG - 2022-11-15 09:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:45:30 --> Total execution time: 0.2356
DEBUG - 2022-11-15 09:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:15:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:15:59 --> 404 Page Not Found: 90s-baby-lot-207453html/index
DEBUG - 2022-11-15 09:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:16:00 --> 404 Page Not Found: Gnarls-barkley-st-elsewhere-lp-706264html/index
DEBUG - 2022-11-15 09:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:46:21 --> Total execution time: 0.2039
DEBUG - 2022-11-15 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:46:37 --> Total execution time: 0.2031
DEBUG - 2022-11-15 09:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:46:56 --> Total execution time: 0.1923
DEBUG - 2022-11-15 09:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:17 --> Total execution time: 0.1887
DEBUG - 2022-11-15 09:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:50 --> Total execution time: 0.1800
DEBUG - 2022-11-15 09:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:07 --> Total execution time: 0.5461
DEBUG - 2022-11-15 09:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:12 --> Total execution time: 0.1904
DEBUG - 2022-11-15 09:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:16 --> Total execution time: 0.2025
DEBUG - 2022-11-15 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:19 --> Total execution time: 0.1820
DEBUG - 2022-11-15 09:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:43 --> Total execution time: 0.2126
DEBUG - 2022-11-15 09:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:49:17 --> Total execution time: 0.5112
DEBUG - 2022-11-15 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:49:19 --> Total execution time: 0.1364
DEBUG - 2022-11-15 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:19:35 --> 404 Page Not Found: Lego-marvel-super-heroes-quinjet-aerial-battle-6869-incomplete-sealed-640284html/index
DEBUG - 2022-11-15 09:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:49:35 --> Total execution time: 0.1898
DEBUG - 2022-11-15 09:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:49:47 --> Total execution time: 0.1356
DEBUG - 2022-11-15 09:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:49:59 --> Total execution time: 0.2182
DEBUG - 2022-11-15 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:20 --> Total execution time: 0.1940
DEBUG - 2022-11-15 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:21 --> Total execution time: 0.1449
DEBUG - 2022-11-15 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:35 --> Total execution time: 0.2023
DEBUG - 2022-11-15 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:39 --> Total execution time: 0.2229
DEBUG - 2022-11-15 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:43 --> Total execution time: 0.2083
DEBUG - 2022-11-15 09:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:50 --> Total execution time: 0.1275
DEBUG - 2022-11-15 09:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:53 --> Total execution time: 0.1895
DEBUG - 2022-11-15 09:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:53 --> Total execution time: 0.2072
DEBUG - 2022-11-15 09:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:50:57 --> Total execution time: 0.2223
DEBUG - 2022-11-15 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:51:02 --> Total execution time: 0.2574
DEBUG - 2022-11-15 09:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:51:06 --> Total execution time: 0.2023
DEBUG - 2022-11-15 09:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:51:11 --> Total execution time: 0.1937
DEBUG - 2022-11-15 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:51:16 --> Total execution time: 0.2622
DEBUG - 2022-11-15 09:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:51:53 --> Total execution time: 0.5575
DEBUG - 2022-11-15 09:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:23 --> Total execution time: 0.1380
DEBUG - 2022-11-15 09:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:35 --> Total execution time: 0.4734
DEBUG - 2022-11-15 09:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:39 --> Total execution time: 0.2092
DEBUG - 2022-11-15 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:41 --> Total execution time: 0.1266
DEBUG - 2022-11-15 09:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:41 --> Total execution time: 0.1387
DEBUG - 2022-11-15 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:45 --> Total execution time: 0.5012
DEBUG - 2022-11-15 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:49 --> Total execution time: 0.1998
DEBUG - 2022-11-15 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:52:51 --> Total execution time: 0.1619
DEBUG - 2022-11-15 09:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:53:56 --> Total execution time: 0.2021
DEBUG - 2022-11-15 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:09 --> Total execution time: 0.2033
DEBUG - 2022-11-15 09:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:17 --> Total execution time: 0.2135
DEBUG - 2022-11-15 09:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:27 --> Total execution time: 0.2857
DEBUG - 2022-11-15 09:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:30 --> Total execution time: 0.1931
DEBUG - 2022-11-15 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:35 --> Total execution time: 0.2341
DEBUG - 2022-11-15 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:54 --> Total execution time: 0.1924
DEBUG - 2022-11-15 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:55:01 --> Total execution time: 0.2370
DEBUG - 2022-11-15 09:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:55:07 --> Total execution time: 0.2103
DEBUG - 2022-11-15 09:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:27:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:25 --> Total execution time: 1.1248
DEBUG - 2022-11-15 20:57:26 --> Total execution time: 3.3081
DEBUG - 2022-11-15 09:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:27 --> Total execution time: 0.1445
DEBUG - 2022-11-15 09:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:27:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:47 --> Total execution time: 0.1976
DEBUG - 2022-11-15 09:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:31 --> Total execution time: 0.1318
DEBUG - 2022-11-15 09:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:40 --> Total execution time: 0.2416
DEBUG - 2022-11-15 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:52 --> Total execution time: 0.2030
DEBUG - 2022-11-15 09:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:52 --> Total execution time: 0.1430
DEBUG - 2022-11-15 09:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:28:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:28:57 --> 404 Page Not Found: Betsey-johnson-dream-big-wristlet-pouch-772928html/index
DEBUG - 2022-11-15 09:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:22 --> Total execution time: 0.5236
DEBUG - 2022-11-15 09:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:31:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:01:19 --> Total execution time: 0.4716
DEBUG - 2022-11-15 09:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:33:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:33:23 --> 404 Page Not Found: Courses-v1/index
DEBUG - 2022-11-15 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:33:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:03:42 --> Total execution time: 0.5106
DEBUG - 2022-11-15 09:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:03:57 --> Total execution time: 0.1995
DEBUG - 2022-11-15 09:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:00 --> Total execution time: 0.2174
DEBUG - 2022-11-15 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:03 --> Total execution time: 0.1960
DEBUG - 2022-11-15 09:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:11 --> Total execution time: 0.1879
DEBUG - 2022-11-15 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:33 --> Total execution time: 0.1880
DEBUG - 2022-11-15 09:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:43 --> Total execution time: 0.2057
DEBUG - 2022-11-15 09:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:47 --> Total execution time: 0.2385
DEBUG - 2022-11-15 09:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:05:35 --> Total execution time: 0.5074
DEBUG - 2022-11-15 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:06:55 --> Total execution time: 0.4799
DEBUG - 2022-11-15 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:07:08 --> Total execution time: 0.2023
DEBUG - 2022-11-15 09:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:07:51 --> Total execution time: 0.4917
DEBUG - 2022-11-15 09:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:01 --> Total execution time: 0.1590
DEBUG - 2022-11-15 09:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:15 --> Total execution time: 0.2043
DEBUG - 2022-11-15 09:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:26 --> Total execution time: 0.1985
DEBUG - 2022-11-15 09:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:27 --> Total execution time: 0.2106
DEBUG - 2022-11-15 09:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:33 --> Total execution time: 0.2222
DEBUG - 2022-11-15 09:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:34 --> Total execution time: 0.4740
DEBUG - 2022-11-15 09:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:27 --> Total execution time: 0.2128
DEBUG - 2022-11-15 09:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:46 --> Total execution time: 0.1601
DEBUG - 2022-11-15 09:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:51 --> Total execution time: 0.1958
DEBUG - 2022-11-15 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:52 --> Total execution time: 0.2121
DEBUG - 2022-11-15 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:58 --> Total execution time: 0.2044
DEBUG - 2022-11-15 09:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:01 --> Total execution time: 0.2029
DEBUG - 2022-11-15 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:03 --> Total execution time: 0.1979
DEBUG - 2022-11-15 09:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:04 --> Total execution time: 0.2401
DEBUG - 2022-11-15 09:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:06 --> Total execution time: 0.1987
DEBUG - 2022-11-15 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:08 --> Total execution time: 0.1878
DEBUG - 2022-11-15 09:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:11 --> Total execution time: 0.1907
DEBUG - 2022-11-15 09:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:13 --> Total execution time: 0.2182
DEBUG - 2022-11-15 09:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:18 --> Total execution time: 0.1933
DEBUG - 2022-11-15 09:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:22 --> Total execution time: 0.2135
DEBUG - 2022-11-15 09:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:26 --> Total execution time: 0.2009
DEBUG - 2022-11-15 09:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:30 --> Total execution time: 0.2291
DEBUG - 2022-11-15 09:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:31 --> Total execution time: 0.1871
DEBUG - 2022-11-15 09:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:35 --> Total execution time: 0.1864
DEBUG - 2022-11-15 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:46 --> Total execution time: 0.2025
DEBUG - 2022-11-15 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:46 --> Total execution time: 0.1889
DEBUG - 2022-11-15 09:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:46 --> Total execution time: 0.2543
DEBUG - 2022-11-15 09:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:47 --> Total execution time: 0.1914
DEBUG - 2022-11-15 09:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:50 --> Total execution time: 0.1960
DEBUG - 2022-11-15 09:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:54 --> Total execution time: 0.1903
DEBUG - 2022-11-15 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:07 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:08 --> Total execution time: 0.2023
DEBUG - 2022-11-15 09:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:09 --> Total execution time: 0.2482
DEBUG - 2022-11-15 09:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:12 --> Total execution time: 0.2003
DEBUG - 2022-11-15 09:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:23 --> Total execution time: 0.2033
DEBUG - 2022-11-15 09:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:24 --> Total execution time: 0.1944
DEBUG - 2022-11-15 09:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:25 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:25 --> Total execution time: 0.1928
DEBUG - 2022-11-15 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:29 --> Total execution time: 0.1897
DEBUG - 2022-11-15 09:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:30 --> Total execution time: 0.2002
DEBUG - 2022-11-15 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:34 --> Total execution time: 0.1872
DEBUG - 2022-11-15 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:01 --> Total execution time: 0.1440
DEBUG - 2022-11-15 09:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:02 --> Total execution time: 0.2051
DEBUG - 2022-11-15 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:25 --> Total execution time: 0.2041
DEBUG - 2022-11-15 09:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:33 --> Total execution time: 0.2090
DEBUG - 2022-11-15 09:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:39 --> Total execution time: 0.2178
DEBUG - 2022-11-15 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:43 --> Total execution time: 0.3403
DEBUG - 2022-11-15 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:03 --> Total execution time: 0.3209
DEBUG - 2022-11-15 09:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:06 --> Total execution time: 0.1945
DEBUG - 2022-11-15 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:12 --> Total execution time: 0.2051
DEBUG - 2022-11-15 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:23 --> Total execution time: 0.2256
DEBUG - 2022-11-15 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:23 --> Total execution time: 0.1963
DEBUG - 2022-11-15 09:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:24 --> Total execution time: 0.1951
DEBUG - 2022-11-15 09:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:33 --> Total execution time: 0.2191
DEBUG - 2022-11-15 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:38 --> Total execution time: 0.2083
DEBUG - 2022-11-15 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:38 --> Total execution time: 0.1353
DEBUG - 2022-11-15 09:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:42 --> Total execution time: 0.1982
DEBUG - 2022-11-15 09:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:43 --> Total execution time: 0.2126
DEBUG - 2022-11-15 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:44 --> Total execution time: 0.2376
DEBUG - 2022-11-15 09:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:46 --> Total execution time: 0.2059
DEBUG - 2022-11-15 09:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:56 --> Total execution time: 0.1996
DEBUG - 2022-11-15 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:57 --> Total execution time: 0.2028
DEBUG - 2022-11-15 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:01 --> Total execution time: 0.1966
DEBUG - 2022-11-15 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:02 --> Total execution time: 0.2331
DEBUG - 2022-11-15 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:03 --> Total execution time: 0.2278
DEBUG - 2022-11-15 09:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:06 --> Total execution time: 0.1977
DEBUG - 2022-11-15 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:07 --> Total execution time: 0.1939
DEBUG - 2022-11-15 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:14 --> Total execution time: 0.1909
DEBUG - 2022-11-15 21:19:14 --> Total execution time: 0.2483
DEBUG - 2022-11-15 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:17 --> Total execution time: 0.2747
DEBUG - 2022-11-15 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:24 --> Total execution time: 0.1548
DEBUG - 2022-11-15 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:49:24 --> 404 Page Not Found: Kodak-pixpro-fz43-16-mp-digital-camera-with-4x-optical-zoom-and-27-106172html/index
DEBUG - 2022-11-15 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:27 --> Total execution time: 0.2449
DEBUG - 2022-11-15 09:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:30 --> Total execution time: 0.1881
DEBUG - 2022-11-15 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:31 --> Total execution time: 0.2109
DEBUG - 2022-11-15 09:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:38 --> Total execution time: 0.2307
DEBUG - 2022-11-15 09:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:38 --> Total execution time: 0.2263
DEBUG - 2022-11-15 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:44 --> Total execution time: 0.2057
DEBUG - 2022-11-15 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:44 --> Total execution time: 0.1898
DEBUG - 2022-11-15 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:48 --> Total execution time: 0.1968
DEBUG - 2022-11-15 09:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:49 --> Total execution time: 0.1241
DEBUG - 2022-11-15 09:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:49 --> Total execution time: 0.1258
DEBUG - 2022-11-15 09:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:50 --> Total execution time: 0.2007
DEBUG - 2022-11-15 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:53 --> Total execution time: 0.2091
DEBUG - 2022-11-15 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:54 --> Total execution time: 0.1991
DEBUG - 2022-11-15 09:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:54 --> Total execution time: 0.4879
DEBUG - 2022-11-15 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:56 --> Total execution time: 0.2711
DEBUG - 2022-11-15 09:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:59 --> Total execution time: 0.1967
DEBUG - 2022-11-15 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:01 --> Total execution time: 0.3703
DEBUG - 2022-11-15 09:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:02 --> Total execution time: 0.2601
DEBUG - 2022-11-15 09:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:06 --> Total execution time: 0.2580
DEBUG - 2022-11-15 09:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:10 --> Total execution time: 0.1842
DEBUG - 2022-11-15 09:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:12 --> Total execution time: 0.1991
DEBUG - 2022-11-15 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:13 --> Total execution time: 0.2463
DEBUG - 2022-11-15 09:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:19 --> Total execution time: 0.2160
DEBUG - 2022-11-15 09:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:24 --> Total execution time: 0.1939
DEBUG - 2022-11-15 09:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:25 --> Total execution time: 0.2698
DEBUG - 2022-11-15 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:32 --> Total execution time: 0.2421
DEBUG - 2022-11-15 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:35 --> Total execution time: 0.2331
DEBUG - 2022-11-15 09:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:45 --> Total execution time: 0.1929
DEBUG - 2022-11-15 09:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:50 --> Total execution time: 0.1882
DEBUG - 2022-11-15 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:21:02 --> Total execution time: 0.2404
DEBUG - 2022-11-15 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:21:08 --> Total execution time: 0.1980
DEBUG - 2022-11-15 09:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:21:33 --> Total execution time: 0.1951
DEBUG - 2022-11-15 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:22:01 --> Total execution time: 0.1610
DEBUG - 2022-11-15 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:22:17 --> Total execution time: 0.1952
DEBUG - 2022-11-15 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:22:31 --> Total execution time: 0.1982
DEBUG - 2022-11-15 09:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:52:36 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:22:37 --> Total execution time: 0.1334
DEBUG - 2022-11-15 09:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:07 --> Total execution time: 0.1653
DEBUG - 2022-11-15 09:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:09 --> Total execution time: 0.2418
DEBUG - 2022-11-15 09:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:16 --> Total execution time: 0.2110
DEBUG - 2022-11-15 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:29 --> Total execution time: 0.5236
DEBUG - 2022-11-15 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:30 --> Total execution time: 0.2792
DEBUG - 2022-11-15 09:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:53:34 --> 404 Page Not Found: Speed-grapher-the-complete-series-box-set-95653html/index
DEBUG - 2022-11-15 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:39 --> Total execution time: 0.2235
DEBUG - 2022-11-15 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:43 --> Total execution time: 0.2468
DEBUG - 2022-11-15 09:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:44 --> Total execution time: 0.2014
DEBUG - 2022-11-15 09:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:54 --> Total execution time: 0.2408
DEBUG - 2022-11-15 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:07 --> Total execution time: 0.1993
DEBUG - 2022-11-15 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:12 --> Total execution time: 0.1940
DEBUG - 2022-11-15 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:22 --> Total execution time: 0.4907
DEBUG - 2022-11-15 09:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:28 --> Total execution time: 0.1975
DEBUG - 2022-11-15 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:29 --> Total execution time: 0.2010
DEBUG - 2022-11-15 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:32 --> Total execution time: 0.2479
DEBUG - 2022-11-15 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:35 --> Total execution time: 0.5052
DEBUG - 2022-11-15 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:41 --> Total execution time: 0.2764
DEBUG - 2022-11-15 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:04 --> Total execution time: 0.2408
DEBUG - 2022-11-15 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:16 --> Total execution time: 0.2075
DEBUG - 2022-11-15 09:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:23 --> Total execution time: 0.2219
DEBUG - 2022-11-15 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:26 --> Total execution time: 0.1923
DEBUG - 2022-11-15 09:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:38 --> Total execution time: 0.1879
DEBUG - 2022-11-15 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:43 --> Total execution time: 0.7204
DEBUG - 2022-11-15 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:45 --> Total execution time: 0.1985
DEBUG - 2022-11-15 09:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:25:51 --> Total execution time: 0.4215
DEBUG - 2022-11-15 09:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:07 --> Total execution time: 0.2486
DEBUG - 2022-11-15 09:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:56:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:24 --> Total execution time: 0.1908
DEBUG - 2022-11-15 09:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:35 --> Total execution time: 2.1080
DEBUG - 2022-11-15 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 09:56:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:53 --> Total execution time: 0.4070
DEBUG - 2022-11-15 09:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:27:05 --> Total execution time: 1.9245
DEBUG - 2022-11-15 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:57:50 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:27:50 --> Total execution time: 0.1350
DEBUG - 2022-11-15 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:57:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:27:52 --> Total execution time: 0.2080
DEBUG - 2022-11-15 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:04 --> Total execution time: 1.7143
DEBUG - 2022-11-15 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:58:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:06 --> Total execution time: 0.4846
DEBUG - 2022-11-15 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:28 --> Total execution time: 0.2973
DEBUG - 2022-11-15 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:48 --> Total execution time: 0.1293
DEBUG - 2022-11-15 09:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:59:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:09 --> Total execution time: 0.1381
DEBUG - 2022-11-15 09:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:59:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 09:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:15 --> Total execution time: 0.1363
DEBUG - 2022-11-15 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:59:39 --> Total execution time: 0.2052
DEBUG - 2022-11-15 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:59:57 --> Total execution time: 0.2541
DEBUG - 2022-11-15 09:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 09:59:57 --> Total execution time: 0.3743
DEBUG - 2022-11-15 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:03 --> Total execution time: 0.1361
DEBUG - 2022-11-15 10:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:06 --> Total execution time: 0.1977
DEBUG - 2022-11-15 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:18 --> Total execution time: 0.1989
DEBUG - 2022-11-15 10:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:30 --> Total execution time: 0.2167
DEBUG - 2022-11-15 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:00:46 --> Total execution time: 0.2043
DEBUG - 2022-11-15 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:00:50 --> Total execution time: 0.2093
DEBUG - 2022-11-15 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:00:51 --> Total execution time: 0.2004
DEBUG - 2022-11-15 10:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:00:54 --> 404 Page Not Found: Peanuts-halloween-placemats-trick-or-treat-set-of-6-172778html/index
DEBUG - 2022-11-15 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:59 --> Total execution time: 0.2275
DEBUG - 2022-11-15 10:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:31:10 --> Total execution time: 0.2167
DEBUG - 2022-11-15 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:01:15 --> 404 Page Not Found: Lego-minifigures-disney-the-muppets-city-fire-rescue-creator-race-car-new-767430html/index
DEBUG - 2022-11-15 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:31:25 --> Total execution time: 1.8517
DEBUG - 2022-11-15 10:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:31:43 --> Total execution time: 0.1415
DEBUG - 2022-11-15 10:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:01:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:33:04 --> Total execution time: 0.5463
DEBUG - 2022-11-15 10:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:04:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:34:49 --> Total execution time: 0.1375
DEBUG - 2022-11-15 10:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:34:56 --> Total execution time: 0.1978
DEBUG - 2022-11-15 10:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:06 --> Total execution time: 0.2215
DEBUG - 2022-11-15 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:07 --> Total execution time: 0.1933
DEBUG - 2022-11-15 10:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:24 --> Total execution time: 0.2603
DEBUG - 2022-11-15 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:36 --> Total execution time: 0.2149
DEBUG - 2022-11-15 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:50 --> Total execution time: 0.2218
DEBUG - 2022-11-15 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:05:52 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-15 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:05:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:53 --> Total execution time: 0.1338
DEBUG - 2022-11-15 10:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:01 --> Total execution time: 0.2213
DEBUG - 2022-11-15 10:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:11 --> Total execution time: 0.2009
DEBUG - 2022-11-15 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:11 --> Total execution time: 0.2059
DEBUG - 2022-11-15 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:11 --> Total execution time: 0.4363
DEBUG - 2022-11-15 10:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:24 --> Total execution time: 0.1335
DEBUG - 2022-11-15 10:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:06:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:34 --> Total execution time: 0.1432
DEBUG - 2022-11-15 10:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:37:23 --> Total execution time: 0.1367
DEBUG - 2022-11-15 10:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:37:37 --> Total execution time: 0.1970
DEBUG - 2022-11-15 10:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:37:40 --> Total execution time: 0.2427
DEBUG - 2022-11-15 10:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:07:41 --> Total execution time: 0.2370
DEBUG - 2022-11-15 10:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:07:43 --> Total execution time: 0.1767
DEBUG - 2022-11-15 10:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:07:44 --> Total execution time: 0.1950
DEBUG - 2022-11-15 10:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:07:56 --> Total execution time: 0.1763
DEBUG - 2022-11-15 10:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:38:49 --> Total execution time: 2.0368
DEBUG - 2022-11-15 10:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:38:50 --> Total execution time: 0.1989
DEBUG - 2022-11-15 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:51 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:38:51 --> Total execution time: 0.1195
DEBUG - 2022-11-15 10:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:08:59 --> Total execution time: 0.2182
DEBUG - 2022-11-15 10:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:02 --> Total execution time: 0.2161
DEBUG - 2022-11-15 10:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:02 --> Total execution time: 0.3052
DEBUG - 2022-11-15 10:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:39:07 --> Total execution time: 0.1785
DEBUG - 2022-11-15 10:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:14 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:39:15 --> Total execution time: 0.1801
DEBUG - 2022-11-15 10:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:16 --> Total execution time: 0.1908
DEBUG - 2022-11-15 10:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:19 --> Total execution time: 0.2092
DEBUG - 2022-11-15 10:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:19 --> Total execution time: 0.1701
DEBUG - 2022-11-15 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:09:23 --> Total execution time: 0.2058
DEBUG - 2022-11-15 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:10:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:40:28 --> Total execution time: 0.1137
DEBUG - 2022-11-15 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:41:03 --> Total execution time: 2.0938
DEBUG - 2022-11-15 10:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:41:03 --> Total execution time: 0.1306
DEBUG - 2022-11-15 10:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:11:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:41:45 --> Total execution time: 0.1084
DEBUG - 2022-11-15 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:41:53 --> Total execution time: 0.1814
DEBUG - 2022-11-15 10:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:00 --> Total execution time: 0.1693
DEBUG - 2022-11-15 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:02 --> Total execution time: 0.1824
DEBUG - 2022-11-15 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:02 --> Total execution time: 0.1825
DEBUG - 2022-11-15 10:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:07 --> Total execution time: 0.1745
DEBUG - 2022-11-15 10:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:07 --> Total execution time: 0.2192
DEBUG - 2022-11-15 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:11 --> Total execution time: 0.1714
DEBUG - 2022-11-15 10:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:13 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:14 --> Total execution time: 0.4642
DEBUG - 2022-11-15 10:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:21 --> Total execution time: 0.1853
DEBUG - 2022-11-15 10:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:23 --> Total execution time: 0.1798
DEBUG - 2022-11-15 10:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:31 --> Total execution time: 0.1927
DEBUG - 2022-11-15 10:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:33 --> Total execution time: 0.1882
DEBUG - 2022-11-15 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:40 --> Total execution time: 0.1855
DEBUG - 2022-11-15 10:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:41 --> Total execution time: 0.1809
DEBUG - 2022-11-15 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:45 --> Total execution time: 0.2092
DEBUG - 2022-11-15 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:52 --> Total execution time: 0.1791
DEBUG - 2022-11-15 10:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:58 --> Total execution time: 0.1757
DEBUG - 2022-11-15 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:03 --> Total execution time: 0.1943
DEBUG - 2022-11-15 10:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:07 --> Total execution time: 0.2357
DEBUG - 2022-11-15 10:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:11 --> Total execution time: 0.1907
DEBUG - 2022-11-15 10:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:13:18 --> 404 Page Not Found: Art-of-world-of-warcraft-book-975710html/index
DEBUG - 2022-11-15 10:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:21 --> Total execution time: 0.1815
DEBUG - 2022-11-15 10:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:27 --> Total execution time: 0.2036
DEBUG - 2022-11-15 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:32 --> Total execution time: 0.2027
DEBUG - 2022-11-15 10:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:13:38 --> Total execution time: 0.1853
DEBUG - 2022-11-15 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:41 --> Total execution time: 0.2373
DEBUG - 2022-11-15 10:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:13:41 --> Total execution time: 0.1786
DEBUG - 2022-11-15 10:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:13:42 --> Total execution time: 0.6303
DEBUG - 2022-11-15 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:47 --> Total execution time: 0.1894
DEBUG - 2022-11-15 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:53 --> Total execution time: 0.4513
DEBUG - 2022-11-15 10:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:53 --> Total execution time: 0.1897
DEBUG - 2022-11-15 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:55 --> Total execution time: 0.1741
DEBUG - 2022-11-15 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:55 --> Total execution time: 0.1950
DEBUG - 2022-11-15 10:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:13:57 --> 404 Page Not Found: Nike-aaron-donald-rams-nike-jersey-1248197html/index
DEBUG - 2022-11-15 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:28 --> Total execution time: 0.4735
DEBUG - 2022-11-15 10:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:28 --> Total execution time: 0.1740
DEBUG - 2022-11-15 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:32 --> Total execution time: 0.1669
DEBUG - 2022-11-15 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:36 --> Total execution time: 0.6820
DEBUG - 2022-11-15 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:38 --> Total execution time: 0.1790
DEBUG - 2022-11-15 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:39 --> Total execution time: 0.1919
DEBUG - 2022-11-15 10:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:40 --> Total execution time: 0.2403
DEBUG - 2022-11-15 10:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:41 --> Total execution time: 0.2164
DEBUG - 2022-11-15 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:41 --> Total execution time: 0.1772
DEBUG - 2022-11-15 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:44 --> Total execution time: 0.2078
DEBUG - 2022-11-15 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:44 --> Total execution time: 0.1078
DEBUG - 2022-11-15 10:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:45 --> Total execution time: 0.2068
DEBUG - 2022-11-15 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:47 --> Total execution time: 0.1821
DEBUG - 2022-11-15 10:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:48 --> Total execution time: 0.1664
DEBUG - 2022-11-15 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:50 --> Total execution time: 0.1633
DEBUG - 2022-11-15 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:51 --> Total execution time: 0.1881
DEBUG - 2022-11-15 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:53 --> Total execution time: 0.1788
DEBUG - 2022-11-15 10:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:58 --> Total execution time: 0.1842
DEBUG - 2022-11-15 10:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:01 --> Total execution time: 0.2954
DEBUG - 2022-11-15 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:19 --> Total execution time: 0.1725
DEBUG - 2022-11-15 10:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:24 --> Total execution time: 0.1676
DEBUG - 2022-11-15 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:32 --> Total execution time: 0.1662
DEBUG - 2022-11-15 10:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:15:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:54 --> Total execution time: 0.2625
DEBUG - 2022-11-15 10:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:54 --> Total execution time: 0.4542
DEBUG - 2022-11-15 10:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:47 --> Total execution time: 0.1649
DEBUG - 2022-11-15 10:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:50 --> Total execution time: 0.1639
DEBUG - 2022-11-15 10:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:06 --> Total execution time: 0.4519
DEBUG - 2022-11-15 10:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:11 --> Total execution time: 0.1801
DEBUG - 2022-11-15 10:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:13 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:13 --> Total execution time: 0.1096
DEBUG - 2022-11-15 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:14 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:14 --> Total execution time: 0.1305
DEBUG - 2022-11-15 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:17 --> Total execution time: 0.1824
DEBUG - 2022-11-15 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:21 --> Total execution time: 0.1800
DEBUG - 2022-11-15 10:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:24 --> Total execution time: 0.2184
DEBUG - 2022-11-15 10:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:24 --> Total execution time: 0.2669
DEBUG - 2022-11-15 10:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:25 --> Total execution time: 0.3524
DEBUG - 2022-11-15 10:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:30 --> Total execution time: 0.1675
DEBUG - 2022-11-15 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:34 --> Total execution time: 0.1729
DEBUG - 2022-11-15 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:48:27 --> Total execution time: 0.1804
DEBUG - 2022-11-15 10:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:48:48 --> Total execution time: 0.1682
DEBUG - 2022-11-15 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:18:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:48:55 --> Total execution time: 0.4528
DEBUG - 2022-11-15 10:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:49:19 --> Total execution time: 0.1666
DEBUG - 2022-11-15 10:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:51 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:49:51 --> Total execution time: 0.4617
DEBUG - 2022-11-15 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:49:55 --> Total execution time: 0.1697
DEBUG - 2022-11-15 10:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:19:56 --> Total execution time: 0.1702
DEBUG - 2022-11-15 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:19:58 --> Total execution time: 0.1772
DEBUG - 2022-11-15 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:19:59 --> Total execution time: 0.2019
DEBUG - 2022-11-15 10:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:26 --> Total execution time: 0.1688
DEBUG - 2022-11-15 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:37 --> Total execution time: 2.2172
DEBUG - 2022-11-15 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:20:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:52 --> Total execution time: 0.1712
DEBUG - 2022-11-15 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:55 --> Total execution time: 0.1695
DEBUG - 2022-11-15 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:57 --> Total execution time: 0.1896
DEBUG - 2022-11-15 10:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:51:01 --> Total execution time: 0.2253
DEBUG - 2022-11-15 10:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:51:25 --> Total execution time: 0.1822
DEBUG - 2022-11-15 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:51:57 --> Total execution time: 0.1667
DEBUG - 2022-11-15 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:19 --> Total execution time: 0.1951
DEBUG - 2022-11-15 10:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:24 --> Total execution time: 0.1092
DEBUG - 2022-11-15 10:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:34 --> Total execution time: 0.1123
DEBUG - 2022-11-15 10:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:36 --> Total execution time: 0.2016
DEBUG - 2022-11-15 10:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:43 --> Total execution time: 0.1729
DEBUG - 2022-11-15 10:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:43 --> Total execution time: 0.1989
DEBUG - 2022-11-15 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:55 --> Total execution time: 0.2131
DEBUG - 2022-11-15 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:19 --> Total execution time: 0.2130
DEBUG - 2022-11-15 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:24 --> Total execution time: 0.1736
DEBUG - 2022-11-15 10:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:27 --> Total execution time: 0.1694
DEBUG - 2022-11-15 10:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:27 --> Total execution time: 0.1948
DEBUG - 2022-11-15 10:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:29 --> Total execution time: 0.1678
DEBUG - 2022-11-15 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:34 --> Total execution time: 0.1716
DEBUG - 2022-11-15 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:43 --> Total execution time: 0.2092
DEBUG - 2022-11-15 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:46 --> Total execution time: 0.1781
DEBUG - 2022-11-15 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:59 --> Total execution time: 0.1954
DEBUG - 2022-11-15 10:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:54:02 --> Total execution time: 0.4941
DEBUG - 2022-11-15 10:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:54:25 --> Total execution time: 0.1865
DEBUG - 2022-11-15 10:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:54:34 --> Total execution time: 0.1853
DEBUG - 2022-11-15 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:24:48 --> Total execution time: 0.1742
DEBUG - 2022-11-15 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:24:55 --> Total execution time: 0.2680
DEBUG - 2022-11-15 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:24:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:54:56 --> Total execution time: 0.4604
DEBUG - 2022-11-15 10:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:55:05 --> Total execution time: 0.1738
DEBUG - 2022-11-15 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:25:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:55:41 --> Total execution time: 0.1327
DEBUG - 2022-11-15 10:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:25:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:55:48 --> Total execution time: 0.1274
DEBUG - 2022-11-15 10:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:55:53 --> Total execution time: 0.1753
DEBUG - 2022-11-15 10:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:26:01 --> Total execution time: 0.2902
DEBUG - 2022-11-15 10:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:26:06 --> Total execution time: 0.1702
DEBUG - 2022-11-15 10:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:15 --> Total execution time: 0.4890
DEBUG - 2022-11-15 10:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:17 --> Total execution time: 0.1832
DEBUG - 2022-11-15 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:26 --> Total execution time: 0.1954
DEBUG - 2022-11-15 10:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:31 --> Total execution time: 0.1845
DEBUG - 2022-11-15 10:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:34 --> Total execution time: 0.1937
DEBUG - 2022-11-15 10:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:34 --> Total execution time: 0.2122
DEBUG - 2022-11-15 10:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:42 --> Total execution time: 0.1801
DEBUG - 2022-11-15 10:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:47 --> Total execution time: 0.2844
DEBUG - 2022-11-15 10:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:48 --> Total execution time: 0.1796
DEBUG - 2022-11-15 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:27:16 --> Total execution time: 0.1725
DEBUG - 2022-11-15 10:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:18 --> Total execution time: 0.1111
DEBUG - 2022-11-15 10:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:19 --> Total execution time: 0.1701
DEBUG - 2022-11-15 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:47 --> Total execution time: 0.1081
DEBUG - 2022-11-15 10:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:08 --> Total execution time: 0.2894
DEBUG - 2022-11-15 10:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:30 --> Total execution time: 0.2247
DEBUG - 2022-11-15 10:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:43 --> Total execution time: 0.1893
DEBUG - 2022-11-15 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:44 --> Total execution time: 0.1782
DEBUG - 2022-11-15 10:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:46 --> Total execution time: 0.1223
DEBUG - 2022-11-15 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:49 --> Total execution time: 0.2152
DEBUG - 2022-11-15 10:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:58 --> Total execution time: 0.5011
DEBUG - 2022-11-15 10:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:58 --> Total execution time: 0.2107
DEBUG - 2022-11-15 10:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:58:59 --> Total execution time: 0.1763
DEBUG - 2022-11-15 10:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:59:13 --> Total execution time: 0.1781
DEBUG - 2022-11-15 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:59:31 --> Total execution time: 0.2442
DEBUG - 2022-11-15 10:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:59:47 --> Total execution time: 0.4639
DEBUG - 2022-11-15 10:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:11 --> Total execution time: 0.1339
DEBUG - 2022-11-15 10:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:12 --> Total execution time: 0.2282
DEBUG - 2022-11-15 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:13 --> Total execution time: 0.2202
DEBUG - 2022-11-15 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:20 --> Total execution time: 0.2307
DEBUG - 2022-11-15 10:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:21 --> Total execution time: 0.2386
DEBUG - 2022-11-15 10:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:45 --> Total execution time: 0.2833
DEBUG - 2022-11-15 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:46 --> Total execution time: 0.2181
DEBUG - 2022-11-15 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:30:48 --> Total execution time: 0.1815
DEBUG - 2022-11-15 10:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:59 --> Total execution time: 0.1824
DEBUG - 2022-11-15 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:01 --> Total execution time: 0.1751
DEBUG - 2022-11-15 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:05 --> Total execution time: 0.2458
DEBUG - 2022-11-15 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:09 --> Total execution time: 0.1931
DEBUG - 2022-11-15 10:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:10 --> Total execution time: 0.1914
DEBUG - 2022-11-15 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:11 --> Total execution time: 0.2399
DEBUG - 2022-11-15 10:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:12 --> Total execution time: 0.4095
DEBUG - 2022-11-15 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:13 --> Total execution time: 0.1609
DEBUG - 2022-11-15 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:31 --> Total execution time: 0.1728
DEBUG - 2022-11-15 10:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:34 --> Total execution time: 0.2127
DEBUG - 2022-11-15 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:40 --> Total execution time: 0.1970
DEBUG - 2022-11-15 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:44 --> Total execution time: 0.2632
DEBUG - 2022-11-15 10:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:48 --> Total execution time: 0.1769
DEBUG - 2022-11-15 10:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:01:50 --> Total execution time: 0.1666
DEBUG - 2022-11-15 10:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:02:01 --> Total execution time: 0.1108
DEBUG - 2022-11-15 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:02:02 --> Total execution time: 0.2075
DEBUG - 2022-11-15 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:33:17 --> 404 Page Not Found: Pyrex-friendship-501-502-994660html/index
DEBUG - 2022-11-15 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:34:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:15 --> Total execution time: 0.1478
DEBUG - 2022-11-15 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:05:27 --> Total execution time: 1.2093
DEBUG - 2022-11-15 10:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:05:44 --> Total execution time: 0.2124
DEBUG - 2022-11-15 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:21 --> Total execution time: 0.1119
DEBUG - 2022-11-15 10:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:28 --> Total execution time: 0.1777
DEBUG - 2022-11-15 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:39 --> Total execution time: 0.1754
DEBUG - 2022-11-15 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:40 --> Total execution time: 0.1699
DEBUG - 2022-11-15 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:49 --> Total execution time: 0.1755
DEBUG - 2022-11-15 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:56 --> Total execution time: 0.1860
DEBUG - 2022-11-15 10:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:05 --> Total execution time: 0.3044
DEBUG - 2022-11-15 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:05 --> Total execution time: 0.1876
DEBUG - 2022-11-15 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:23 --> Total execution time: 0.1784
DEBUG - 2022-11-15 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:24 --> Total execution time: 0.2208
DEBUG - 2022-11-15 10:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:24 --> Total execution time: 0.3198
DEBUG - 2022-11-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:25 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:25 --> Total execution time: 0.1228
DEBUG - 2022-11-15 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:25 --> Total execution time: 0.2558
DEBUG - 2022-11-15 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:25 --> Total execution time: 0.5602
DEBUG - 2022-11-15 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:25 --> Total execution time: 0.4988
DEBUG - 2022-11-15 10:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:26 --> Total execution time: 0.1834
DEBUG - 2022-11-15 10:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:27 --> Total execution time: 0.1747
DEBUG - 2022-11-15 10:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:30 --> Total execution time: 0.1752
DEBUG - 2022-11-15 10:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:31 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:31 --> Total execution time: 0.1978
DEBUG - 2022-11-15 10:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:37:33 --> Total execution time: 0.1808
DEBUG - 2022-11-15 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:37:37 --> Total execution time: 0.1785
DEBUG - 2022-11-15 10:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:37:38 --> Total execution time: 0.4058
DEBUG - 2022-11-15 10:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:45 --> Total execution time: 2.2417
DEBUG - 2022-11-15 10:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:45 --> Total execution time: 0.1721
DEBUG - 2022-11-15 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:49 --> Total execution time: 0.1776
DEBUG - 2022-11-15 10:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:38:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:52 --> Total execution time: 0.1108
DEBUG - 2022-11-15 10:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:56 --> Total execution time: 0.1747
DEBUG - 2022-11-15 10:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:59 --> Total execution time: 0.2143
DEBUG - 2022-11-15 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:04 --> Total execution time: 0.2264
DEBUG - 2022-11-15 10:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:12 --> Total execution time: 0.2200
DEBUG - 2022-11-15 10:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:13 --> Total execution time: 0.1992
DEBUG - 2022-11-15 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:18 --> Total execution time: 0.1947
DEBUG - 2022-11-15 10:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:33 --> Total execution time: 0.1787
DEBUG - 2022-11-15 10:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:40 --> Total execution time: 0.1100
DEBUG - 2022-11-15 10:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:39:50 --> Total execution time: 0.1752
DEBUG - 2022-11-15 10:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:39:52 --> Total execution time: 0.1837
DEBUG - 2022-11-15 10:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:39:52 --> Total execution time: 0.1784
DEBUG - 2022-11-15 10:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:40:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:06 --> Total execution time: 0.1171
DEBUG - 2022-11-15 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:40:13 --> Total execution time: 0.1716
DEBUG - 2022-11-15 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:40:14 --> Total execution time: 0.1734
DEBUG - 2022-11-15 10:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:40:15 --> Total execution time: 0.1792
DEBUG - 2022-11-15 10:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:11:45 --> Total execution time: 0.2208
DEBUG - 2022-11-15 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:11:55 --> Total execution time: 1.8900
DEBUG - 2022-11-15 10:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:41:56 --> Total execution time: 0.2158
DEBUG - 2022-11-15 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:41:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:41:58 --> Total execution time: 0.1975
DEBUG - 2022-11-15 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:41:58 --> Total execution time: 0.1710
DEBUG - 2022-11-15 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:06 --> Total execution time: 0.2565
DEBUG - 2022-11-15 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:11 --> Total execution time: 0.1205
DEBUG - 2022-11-15 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:14 --> Total execution time: 0.2341
DEBUG - 2022-11-15 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:18 --> Total execution time: 0.2185
DEBUG - 2022-11-15 10:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:27 --> Total execution time: 0.1368
DEBUG - 2022-11-15 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:42:35 --> Total execution time: 0.1925
DEBUG - 2022-11-15 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:42:37 --> Total execution time: 0.1714
DEBUG - 2022-11-15 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:42:37 --> Total execution time: 0.1634
DEBUG - 2022-11-15 10:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:43 --> Total execution time: 0.2097
DEBUG - 2022-11-15 10:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:12:45 --> Total execution time: 0.3998
DEBUG - 2022-11-15 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:43:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-15 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:10 --> Total execution time: 0.1932
DEBUG - 2022-11-15 10:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:17 --> Total execution time: 0.2080
DEBUG - 2022-11-15 10:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:19 --> Total execution time: 0.1670
DEBUG - 2022-11-15 10:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:25 --> Total execution time: 0.1874
DEBUG - 2022-11-15 10:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:26 --> Total execution time: 0.1809
DEBUG - 2022-11-15 10:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:31 --> Total execution time: 0.2951
DEBUG - 2022-11-15 10:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:31 --> Total execution time: 0.1918
DEBUG - 2022-11-15 10:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:34 --> Total execution time: 0.1933
DEBUG - 2022-11-15 10:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:35 --> Total execution time: 0.1168
DEBUG - 2022-11-15 10:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:51 --> Total execution time: 0.1876
DEBUG - 2022-11-15 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:58 --> Total execution time: 1.6980
DEBUG - 2022-11-15 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:44:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 10:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:16 --> Total execution time: 0.2320
DEBUG - 2022-11-15 10:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:43 --> Total execution time: 0.1930
DEBUG - 2022-11-15 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:44 --> Total execution time: 0.1804
DEBUG - 2022-11-15 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:45 --> Total execution time: 0.3740
DEBUG - 2022-11-15 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:44:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-15 10:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:52 --> Total execution time: 0.1984
DEBUG - 2022-11-15 10:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:52 --> Total execution time: 0.1124
DEBUG - 2022-11-15 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:06 --> Total execution time: 0.1216
DEBUG - 2022-11-15 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:15 --> Total execution time: 0.1824
DEBUG - 2022-11-15 10:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:45:17 --> Total execution time: 0.1805
DEBUG - 2022-11-15 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:45:18 --> Total execution time: 0.1966
DEBUG - 2022-11-15 10:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:45:19 --> Total execution time: 0.4036
DEBUG - 2022-11-15 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:22 --> Total execution time: 0.1796
DEBUG - 2022-11-15 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:25 --> Total execution time: 0.5668
DEBUG - 2022-11-15 10:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:57 --> Total execution time: 0.2098
DEBUG - 2022-11-15 10:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:14 --> Total execution time: 0.2666
DEBUG - 2022-11-15 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:27 --> Total execution time: 0.1800
DEBUG - 2022-11-15 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:28 --> Total execution time: 0.1853
DEBUG - 2022-11-15 10:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:46:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:45 --> Total execution time: 0.1096
DEBUG - 2022-11-15 10:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:04 --> Total execution time: 0.1765
DEBUG - 2022-11-15 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:47:18 --> Total execution time: 0.1753
DEBUG - 2022-11-15 10:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:54 --> Total execution time: 0.1744
DEBUG - 2022-11-15 10:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:57 --> Total execution time: 0.1918
DEBUG - 2022-11-15 10:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:04 --> Total execution time: 0.1806
DEBUG - 2022-11-15 10:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:12 --> Total execution time: 0.1777
DEBUG - 2022-11-15 10:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:12 --> Total execution time: 0.1760
DEBUG - 2022-11-15 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:44 --> Total execution time: 0.2398
DEBUG - 2022-11-15 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:47 --> Total execution time: 0.2484
DEBUG - 2022-11-15 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:09 --> Total execution time: 0.2234
DEBUG - 2022-11-15 10:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:11 --> Total execution time: 0.1808
DEBUG - 2022-11-15 10:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:15 --> Total execution time: 0.1776
DEBUG - 2022-11-15 10:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:49:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:47 --> Total execution time: 0.1309
DEBUG - 2022-11-15 10:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:49:58 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:58 --> Total execution time: 0.1184
DEBUG - 2022-11-15 10:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:06 --> Total execution time: 0.1738
DEBUG - 2022-11-15 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:10 --> Total execution time: 0.1712
DEBUG - 2022-11-15 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:12 --> Total execution time: 0.3616
DEBUG - 2022-11-15 10:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:19 --> Total execution time: 0.1691
DEBUG - 2022-11-15 10:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:33 --> Total execution time: 0.1839
DEBUG - 2022-11-15 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:46 --> Total execution time: 0.1281
DEBUG - 2022-11-15 10:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:46 --> Total execution time: 0.4983
DEBUG - 2022-11-15 10:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:49 --> Total execution time: 0.1853
DEBUG - 2022-11-15 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:01 --> Total execution time: 0.1707
DEBUG - 2022-11-15 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:02 --> Total execution time: 0.1770
DEBUG - 2022-11-15 10:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:51:02 --> 404 Page Not Found: Human-hair-blend-dirty-blonde-wig-143469html/index
DEBUG - 2022-11-15 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:51 --> Total execution time: 0.1920
DEBUG - 2022-11-15 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:22:31 --> Total execution time: 0.1862
DEBUG - 2022-11-15 10:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:52:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:22:32 --> Total execution time: 0.1105
DEBUG - 2022-11-15 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:01 --> Total execution time: 0.1817
DEBUG - 2022-11-15 10:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:17 --> Total execution time: 0.1816
DEBUG - 2022-11-15 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:33 --> Total execution time: 0.1748
DEBUG - 2022-11-15 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:37 --> Total execution time: 0.1840
DEBUG - 2022-11-15 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:44 --> Total execution time: 0.1106
DEBUG - 2022-11-15 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:44 --> Total execution time: 0.1798
DEBUG - 2022-11-15 10:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:49 --> Total execution time: 0.1751
DEBUG - 2022-11-15 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:23:51 --> Total execution time: 0.1741
DEBUG - 2022-11-15 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:54:10 --> 404 Page Not Found: 6-handmade-soaps-1031338html/index
DEBUG - 2022-11-15 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 10:54:12 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-11-15 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:12 --> Total execution time: 0.1118
DEBUG - 2022-11-15 10:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:13 --> Total execution time: 0.1695
DEBUG - 2022-11-15 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:31 --> Total execution time: 0.1948
DEBUG - 2022-11-15 10:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:34 --> Total execution time: 0.1894
DEBUG - 2022-11-15 10:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:46 --> Total execution time: 0.1183
DEBUG - 2022-11-15 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:48 --> Total execution time: 0.2768
DEBUG - 2022-11-15 10:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:04 --> Total execution time: 0.1941
DEBUG - 2022-11-15 10:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:09 --> Total execution time: 0.1927
DEBUG - 2022-11-15 10:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:19 --> Total execution time: 0.1105
DEBUG - 2022-11-15 10:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:26 --> Total execution time: 0.1710
DEBUG - 2022-11-15 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:33 --> Total execution time: 0.1678
DEBUG - 2022-11-15 10:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:36 --> Total execution time: 0.1861
DEBUG - 2022-11-15 10:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:42 --> Total execution time: 0.1192
DEBUG - 2022-11-15 10:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:50 --> Total execution time: 0.4624
DEBUG - 2022-11-15 10:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:25:58 --> Total execution time: 0.1071
DEBUG - 2022-11-15 10:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:06 --> Total execution time: 0.1701
DEBUG - 2022-11-15 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:06 --> Total execution time: 0.1712
DEBUG - 2022-11-15 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:19 --> Total execution time: 0.1923
DEBUG - 2022-11-15 10:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:27 --> Total execution time: 0.2376
DEBUG - 2022-11-15 10:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:42 --> Total execution time: 0.4510
DEBUG - 2022-11-15 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:44 --> Total execution time: 0.1742
DEBUG - 2022-11-15 10:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:47 --> Total execution time: 0.1795
DEBUG - 2022-11-15 10:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:48 --> Total execution time: 0.1815
DEBUG - 2022-11-15 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:50 --> Total execution time: 0.2477
DEBUG - 2022-11-15 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:57 --> Total execution time: 0.2576
DEBUG - 2022-11-15 10:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:06 --> Total execution time: 0.1772
DEBUG - 2022-11-15 10:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:57:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 10:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:22 --> Total execution time: 0.4741
DEBUG - 2022-11-15 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:27 --> Total execution time: 0.1658
DEBUG - 2022-11-15 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:06 --> Total execution time: 0.4662
DEBUG - 2022-11-15 10:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:15 --> Total execution time: 0.1792
DEBUG - 2022-11-15 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:20 --> Total execution time: 0.1748
DEBUG - 2022-11-15 10:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:25 --> Total execution time: 0.2268
DEBUG - 2022-11-15 10:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:35 --> Total execution time: 0.2493
DEBUG - 2022-11-15 10:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:28:38 --> Total execution time: 0.2062
DEBUG - 2022-11-15 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-15 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:01 --> Total execution time: 0.2066
DEBUG - 2022-11-15 10:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:06 --> Total execution time: 0.2094
DEBUG - 2022-11-15 10:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:09 --> Total execution time: 0.2114
DEBUG - 2022-11-15 10:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:14 --> Total execution time: 0.2232
DEBUG - 2022-11-15 10:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 10:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:32 --> Total execution time: 0.1903
DEBUG - 2022-11-15 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:30:03 --> Total execution time: 0.1686
DEBUG - 2022-11-15 11:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:30:31 --> Total execution time: 0.2189
DEBUG - 2022-11-15 11:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:30:43 --> Total execution time: 0.2024
DEBUG - 2022-11-15 11:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:30:48 --> Total execution time: 0.2237
DEBUG - 2022-11-15 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:31:07 --> Total execution time: 0.2068
DEBUG - 2022-11-15 11:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:32:36 --> Total execution time: 0.1702
DEBUG - 2022-11-15 11:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:02:51 --> Total execution time: 0.1766
DEBUG - 2022-11-15 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:03:09 --> Total execution time: 0.1864
DEBUG - 2022-11-15 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:03:23 --> Total execution time: 0.1749
DEBUG - 2022-11-15 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:04:13 --> 404 Page Not Found: Pokemon-sabrina39s-alakazam-psa-7-79880html/index
DEBUG - 2022-11-15 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:34:34 --> Total execution time: 0.1682
DEBUG - 2022-11-15 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:05:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:35:39 --> Total execution time: 0.1203
DEBUG - 2022-11-15 11:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:06 --> Total execution time: 0.1693
DEBUG - 2022-11-15 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:06:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:21 --> Total execution time: 0.1769
DEBUG - 2022-11-15 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:27 --> Total execution time: 0.1727
DEBUG - 2022-11-15 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:31 --> Total execution time: 0.1833
DEBUG - 2022-11-15 11:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:06:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:45 --> Total execution time: 0.1870
DEBUG - 2022-11-15 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:07:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:01 --> Total execution time: 0.1838
DEBUG - 2022-11-15 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:07 --> Total execution time: 0.1676
DEBUG - 2022-11-15 11:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:07:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:24 --> Total execution time: 0.1774
DEBUG - 2022-11-15 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:07:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:41 --> Total execution time: 0.1814
DEBUG - 2022-11-15 11:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:22 --> Total execution time: 0.1887
DEBUG - 2022-11-15 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:33 --> Total execution time: 0.1678
DEBUG - 2022-11-15 11:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:46 --> Total execution time: 0.2006
DEBUG - 2022-11-15 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:48 --> Total execution time: 0.1700
DEBUG - 2022-11-15 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:49 --> Total execution time: 0.1891
DEBUG - 2022-11-15 11:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:51 --> Total execution time: 0.1792
DEBUG - 2022-11-15 11:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:08:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:53 --> Total execution time: 0.1933
DEBUG - 2022-11-15 11:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:00 --> Total execution time: 0.1715
DEBUG - 2022-11-15 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:26 --> Total execution time: 0.5889
DEBUG - 2022-11-15 11:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:27 --> Total execution time: 0.2511
DEBUG - 2022-11-15 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:42 --> Total execution time: 0.1859
DEBUG - 2022-11-15 11:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:47 --> Total execution time: 0.1992
DEBUG - 2022-11-15 11:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:54 --> Total execution time: 0.2557
DEBUG - 2022-11-15 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:40:12 --> Total execution time: 0.5608
DEBUG - 2022-11-15 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:01 --> Total execution time: 0.2715
DEBUG - 2022-11-15 11:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:08 --> Total execution time: 0.1874
DEBUG - 2022-11-15 11:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:15 --> Total execution time: 0.1785
DEBUG - 2022-11-15 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:23 --> Total execution time: 0.1679
DEBUG - 2022-11-15 11:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:28 --> Total execution time: 0.1778
DEBUG - 2022-11-15 11:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:43:55 --> Total execution time: 0.1740
DEBUG - 2022-11-15 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:43:59 --> Total execution time: 0.1699
DEBUG - 2022-11-15 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:03 --> Total execution time: 0.4690
DEBUG - 2022-11-15 11:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:04 --> Total execution time: 0.1746
DEBUG - 2022-11-15 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:06 --> Total execution time: 0.1802
DEBUG - 2022-11-15 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:08 --> Total execution time: 0.1714
DEBUG - 2022-11-15 11:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:12 --> Total execution time: 0.1669
DEBUG - 2022-11-15 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:14 --> Total execution time: 0.1703
DEBUG - 2022-11-15 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:13 --> Total execution time: 0.7030
DEBUG - 2022-11-15 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:19 --> Total execution time: 0.1178
DEBUG - 2022-11-15 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:23 --> Total execution time: 0.1735
DEBUG - 2022-11-15 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:32 --> Total execution time: 0.2051
DEBUG - 2022-11-15 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:41 --> Total execution time: 0.2033
DEBUG - 2022-11-15 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:41 --> Total execution time: 0.1925
DEBUG - 2022-11-15 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:58 --> Total execution time: 0.1687
DEBUG - 2022-11-15 11:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:02 --> Total execution time: 0.2004
DEBUG - 2022-11-15 11:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:04 --> Total execution time: 0.1870
DEBUG - 2022-11-15 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:11 --> Total execution time: 0.1835
DEBUG - 2022-11-15 11:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:14 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:14 --> Total execution time: 0.1249
DEBUG - 2022-11-15 11:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:15 --> Total execution time: 0.1834
DEBUG - 2022-11-15 11:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:20 --> Total execution time: 0.1755
DEBUG - 2022-11-15 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:23 --> Total execution time: 0.1810
DEBUG - 2022-11-15 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:24 --> Total execution time: 0.2328
DEBUG - 2022-11-15 11:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:22:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:38 --> Total execution time: 0.1128
DEBUG - 2022-11-15 11:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:23:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:53:35 --> Total execution time: 0.1741
DEBUG - 2022-11-15 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:09 --> Total execution time: 0.1812
DEBUG - 2022-11-15 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:28 --> Total execution time: 0.1703
DEBUG - 2022-11-15 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:24:43 --> Total execution time: 0.1896
DEBUG - 2022-11-15 11:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:25:19 --> Total execution time: 0.1691
DEBUG - 2022-11-15 11:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:25:24 --> Total execution time: 0.1975
DEBUG - 2022-11-15 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:25:26 --> Total execution time: 0.1721
DEBUG - 2022-11-15 11:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:55:38 --> Total execution time: 0.1766
DEBUG - 2022-11-15 11:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:25:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:55:45 --> Total execution time: 0.1750
DEBUG - 2022-11-15 11:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:18 --> Total execution time: 0.1815
DEBUG - 2022-11-15 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:20 --> Total execution time: 0.1781
DEBUG - 2022-11-15 11:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:21 --> Total execution time: 0.1804
DEBUG - 2022-11-15 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:38 --> Total execution time: 0.2252
DEBUG - 2022-11-15 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:42 --> Total execution time: 0.1815
DEBUG - 2022-11-15 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:43 --> Total execution time: 0.2223
DEBUG - 2022-11-15 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:52 --> Total execution time: 0.1974
DEBUG - 2022-11-15 11:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:55 --> Total execution time: 0.1747
DEBUG - 2022-11-15 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:17 --> Total execution time: 0.1860
DEBUG - 2022-11-15 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:21 --> Total execution time: 0.1845
DEBUG - 2022-11-15 11:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:28 --> Total execution time: 0.1180
DEBUG - 2022-11-15 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:37 --> Total execution time: 0.1734
DEBUG - 2022-11-15 11:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:42 --> Total execution time: 0.2284
DEBUG - 2022-11-15 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:48 --> Total execution time: 0.5248
DEBUG - 2022-11-15 11:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:49 --> Total execution time: 0.2066
DEBUG - 2022-11-15 11:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:50 --> Total execution time: 1.0573
DEBUG - 2022-11-15 11:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:59 --> Total execution time: 0.2029
DEBUG - 2022-11-15 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:11 --> Total execution time: 0.1859
DEBUG - 2022-11-15 11:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:45 --> Total execution time: 0.2522
DEBUG - 2022-11-15 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:51 --> Total execution time: 0.2073
DEBUG - 2022-11-15 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:57 --> Total execution time: 0.1791
DEBUG - 2022-11-15 11:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:03 --> Total execution time: 0.1916
DEBUG - 2022-11-15 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:37:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:07:49 --> Total execution time: 1.5403
DEBUG - 2022-11-15 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:08:27 --> Total execution time: 2.3155
DEBUG - 2022-11-15 11:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:08:28 --> Total execution time: 0.1952
DEBUG - 2022-11-15 11:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:08:31 --> Total execution time: 0.1713
DEBUG - 2022-11-15 11:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:08:34 --> Total execution time: 0.1753
DEBUG - 2022-11-15 11:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:39:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:38 --> Total execution time: 0.4748
DEBUG - 2022-11-15 11:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:39:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:46 --> Total execution time: 0.1060
DEBUG - 2022-11-15 11:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:57 --> Total execution time: 0.1770
DEBUG - 2022-11-15 11:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:59 --> Total execution time: 0.1733
DEBUG - 2022-11-15 11:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:12 --> Total execution time: 0.8090
DEBUG - 2022-11-15 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:20 --> Total execution time: 0.1175
DEBUG - 2022-11-15 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:21 --> Total execution time: 0.2400
DEBUG - 2022-11-15 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:27 --> Total execution time: 0.1770
DEBUG - 2022-11-15 11:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:34 --> Total execution time: 0.2101
DEBUG - 2022-11-15 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:00 --> Total execution time: 0.1688
DEBUG - 2022-11-15 11:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:41:34 --> 404 Page Not Found: Sony-playstation-camera-model-cuhzey1-71280html/index
DEBUG - 2022-11-15 11:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:23 --> Total execution time: 0.1713
DEBUG - 2022-11-15 11:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:28 --> Total execution time: 0.2242
DEBUG - 2022-11-15 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:37 --> Total execution time: 0.1183
DEBUG - 2022-11-15 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:47 --> Total execution time: 0.1718
DEBUG - 2022-11-15 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:57 --> Total execution time: 0.1859
DEBUG - 2022-11-15 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:10 --> Total execution time: 0.1928
DEBUG - 2022-11-15 11:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:15 --> Total execution time: 0.1896
DEBUG - 2022-11-15 11:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:25 --> Total execution time: 0.1766
DEBUG - 2022-11-15 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:51 --> Total execution time: 0.1801
DEBUG - 2022-11-15 11:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:54 --> Total execution time: 0.1746
DEBUG - 2022-11-15 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:59 --> Total execution time: 0.1688
DEBUG - 2022-11-15 11:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:14:02 --> Total execution time: 0.2419
DEBUG - 2022-11-15 11:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:14:45 --> Total execution time: 0.1962
DEBUG - 2022-11-15 11:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:44:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:44:51 --> 404 Page Not Found: Autographed-overlord-volume-3-920293html/index
DEBUG - 2022-11-15 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:46:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:46:29 --> 404 Page Not Found: Ron-popeils-pocket-fisherman-new-old-stock-in-box-with-paperwork-58650html/index
DEBUG - 2022-11-15 11:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:27 --> Total execution time: 0.1763
DEBUG - 2022-11-15 11:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:57 --> Total execution time: 0.1682
DEBUG - 2022-11-15 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:19:46 --> Total execution time: 0.1810
DEBUG - 2022-11-15 11:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:20:15 --> Total execution time: 0.1693
DEBUG - 2022-11-15 11:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:50:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:20:35 --> Total execution time: 0.4823
DEBUG - 2022-11-15 11:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:50:51 --> Total execution time: 0.1737
DEBUG - 2022-11-15 11:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:50:53 --> Total execution time: 0.2158
DEBUG - 2022-11-15 11:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:50:53 --> Total execution time: 0.1760
DEBUG - 2022-11-15 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:51:14 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:21:14 --> Total execution time: 0.1089
DEBUG - 2022-11-15 11:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:51:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:21:22 --> Total execution time: 0.1839
DEBUG - 2022-11-15 11:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:51:35 --> Total execution time: 0.1756
DEBUG - 2022-11-15 11:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:51:36 --> Total execution time: 0.1664
DEBUG - 2022-11-15 11:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:51:37 --> Total execution time: 0.1779
DEBUG - 2022-11-15 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:52:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:22:03 --> Total execution time: 0.1774
DEBUG - 2022-11-15 11:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:22:31 --> Total execution time: 0.1707
DEBUG - 2022-11-15 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:22:35 --> Total execution time: 0.1676
DEBUG - 2022-11-15 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:22:37 --> Total execution time: 0.1725
DEBUG - 2022-11-15 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:22:40 --> Total execution time: 0.1694
DEBUG - 2022-11-15 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:54:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:17 --> Total execution time: 0.1261
DEBUG - 2022-11-15 11:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:18 --> Total execution time: 0.1929
DEBUG - 2022-11-15 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:20 --> Total execution time: 0.1772
DEBUG - 2022-11-15 11:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:54:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:54:40 --> 404 Page Not Found: Disney-pooh-collector-plates-lot-of-4-214101html/index
DEBUG - 2022-11-15 11:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 11:57:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 11:57:31 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-15 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:04 --> Total execution time: 1.0742
DEBUG - 2022-11-15 12:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:09 --> Total execution time: 0.1798
DEBUG - 2022-11-15 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:12 --> Total execution time: 0.1691
DEBUG - 2022-11-15 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:17 --> Total execution time: 0.1690
DEBUG - 2022-11-15 12:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:34 --> Total execution time: 0.1327
DEBUG - 2022-11-15 12:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:43 --> Total execution time: 0.2046
DEBUG - 2022-11-15 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:57 --> Total execution time: 0.1608
DEBUG - 2022-11-15 12:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:58 --> Total execution time: 0.1012
DEBUG - 2022-11-15 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:59 --> Total execution time: 0.1615
DEBUG - 2022-11-15 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:00 --> Total execution time: 0.1826
DEBUG - 2022-11-15 12:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:01 --> Total execution time: 0.1631
DEBUG - 2022-11-15 12:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:02 --> Total execution time: 0.2187
DEBUG - 2022-11-15 12:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:02 --> Total execution time: 0.1711
DEBUG - 2022-11-15 12:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:03 --> Total execution time: 0.1756
DEBUG - 2022-11-15 12:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:35 --> Total execution time: 0.1804
DEBUG - 2022-11-15 12:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:20 --> Total execution time: 0.1884
DEBUG - 2022-11-15 12:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:23 --> Total execution time: 0.2211
DEBUG - 2022-11-15 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:37 --> Total execution time: 0.1110
DEBUG - 2022-11-15 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:37 --> Total execution time: 0.1813
DEBUG - 2022-11-15 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:39 --> Total execution time: 0.1710
DEBUG - 2022-11-15 12:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:41 --> Total execution time: 0.1766
DEBUG - 2022-11-15 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:43 --> Total execution time: 0.1816
DEBUG - 2022-11-15 12:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:52 --> Total execution time: 0.1919
DEBUG - 2022-11-15 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:55 --> Total execution time: 0.1781
DEBUG - 2022-11-15 12:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:58 --> Total execution time: 0.1707
DEBUG - 2022-11-15 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:59 --> Total execution time: 0.1689
DEBUG - 2022-11-15 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:03 --> Total execution time: 0.1729
DEBUG - 2022-11-15 12:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:21 --> Total execution time: 0.1698
DEBUG - 2022-11-15 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:23 --> Total execution time: 0.1732
DEBUG - 2022-11-15 12:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:08 --> Total execution time: 0.2506
DEBUG - 2022-11-15 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:10 --> Total execution time: 0.2371
DEBUG - 2022-11-15 12:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:19 --> Total execution time: 0.2116
DEBUG - 2022-11-15 12:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:19 --> Total execution time: 0.1770
DEBUG - 2022-11-15 12:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:23 --> Total execution time: 0.1734
DEBUG - 2022-11-15 12:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:11 --> Total execution time: 0.1722
DEBUG - 2022-11-15 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:15 --> Total execution time: 0.1679
DEBUG - 2022-11-15 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:18 --> Total execution time: 0.1699
DEBUG - 2022-11-15 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:19 --> Total execution time: 0.1669
DEBUG - 2022-11-15 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:20 --> Total execution time: 0.1703
DEBUG - 2022-11-15 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:31 --> Total execution time: 0.1784
DEBUG - 2022-11-15 12:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:34 --> Total execution time: 0.1905
DEBUG - 2022-11-15 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:40 --> Total execution time: 0.1696
DEBUG - 2022-11-15 12:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:44 --> Total execution time: 0.1695
DEBUG - 2022-11-15 12:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:48 --> Total execution time: 0.1790
DEBUG - 2022-11-15 12:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:53 --> Total execution time: 0.1977
DEBUG - 2022-11-15 12:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:55 --> Total execution time: 0.1703
DEBUG - 2022-11-15 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:03 --> Total execution time: 0.1714
DEBUG - 2022-11-15 12:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:05 --> Total execution time: 0.4950
DEBUG - 2022-11-15 12:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:15 --> Total execution time: 0.1754
DEBUG - 2022-11-15 12:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:15 --> Total execution time: 0.1861
DEBUG - 2022-11-15 12:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:17 --> Total execution time: 0.1823
DEBUG - 2022-11-15 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:22 --> Total execution time: 0.1785
DEBUG - 2022-11-15 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:25 --> Total execution time: 0.1847
DEBUG - 2022-11-15 12:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:28 --> Total execution time: 0.1801
DEBUG - 2022-11-15 12:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:36 --> Total execution time: 0.1807
DEBUG - 2022-11-15 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:43 --> Total execution time: 0.2422
DEBUG - 2022-11-15 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:51 --> Total execution time: 0.1678
DEBUG - 2022-11-15 12:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:54 --> Total execution time: 0.1686
DEBUG - 2022-11-15 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:01 --> Total execution time: 0.1754
DEBUG - 2022-11-15 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:31 --> Total execution time: 0.1930
DEBUG - 2022-11-15 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:32 --> Total execution time: 0.2619
DEBUG - 2022-11-15 12:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:33 --> Total execution time: 0.3746
DEBUG - 2022-11-15 12:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:34 --> Total execution time: 0.2891
DEBUG - 2022-11-15 12:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:35 --> Total execution time: 0.4879
DEBUG - 2022-11-15 12:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:36 --> Total execution time: 0.1750
DEBUG - 2022-11-15 12:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:37 --> Total execution time: 0.2063
DEBUG - 2022-11-15 12:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:38 --> Total execution time: 0.1918
DEBUG - 2022-11-15 12:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:42 --> Total execution time: 0.1824
DEBUG - 2022-11-15 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:44 --> Total execution time: 0.1770
DEBUG - 2022-11-15 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:09:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:09:00 --> 404 Page Not Found: Skims-sculpting-bodysuit-w-snaps-817253html/index
DEBUG - 2022-11-15 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:09:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:39:35 --> Total execution time: 0.1105
DEBUG - 2022-11-15 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:57 --> Total execution time: 0.1988
DEBUG - 2022-11-15 12:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:26 --> Total execution time: 0.1688
DEBUG - 2022-11-15 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:13:37 --> 404 Page Not Found: Nwt-marc-by-marc-jacobs-liquid-travel-reversible-tote-black-pink-481631html/index
DEBUG - 2022-11-15 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:43:41 --> Total execution time: 0.1681
DEBUG - 2022-11-15 12:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:42 --> Total execution time: 0.1853
DEBUG - 2022-11-15 12:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:51 --> Total execution time: 0.1707
DEBUG - 2022-11-15 12:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:14:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:55 --> Total execution time: 0.1785
DEBUG - 2022-11-15 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:45:08 --> Total execution time: 0.2247
DEBUG - 2022-11-15 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:45:57 --> Total execution time: 0.2023
DEBUG - 2022-11-15 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:46:01 --> Total execution time: 0.2382
DEBUG - 2022-11-15 12:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:18 --> Total execution time: 0.5091
DEBUG - 2022-11-15 12:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:24 --> Total execution time: 0.1881
DEBUG - 2022-11-15 12:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:31 --> Total execution time: 0.2072
DEBUG - 2022-11-15 12:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:48:32 --> Total execution time: 0.1804
DEBUG - 2022-11-15 12:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:52:51 --> Total execution time: 0.1939
DEBUG - 2022-11-15 12:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:52:59 --> Total execution time: 0.1955
DEBUG - 2022-11-15 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:03 --> Total execution time: 0.1723
DEBUG - 2022-11-15 12:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:21 --> Total execution time: 0.1699
DEBUG - 2022-11-15 12:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:23 --> Total execution time: 0.1890
DEBUG - 2022-11-15 12:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:28 --> Total execution time: 0.1902
DEBUG - 2022-11-15 12:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:31 --> Total execution time: 0.1955
DEBUG - 2022-11-15 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:32 --> Total execution time: 0.1683
DEBUG - 2022-11-15 12:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:08 --> Total execution time: 0.2013
DEBUG - 2022-11-15 12:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:11 --> Total execution time: 0.4585
DEBUG - 2022-11-15 12:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:14 --> Total execution time: 0.1980
DEBUG - 2022-11-15 12:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:22 --> Total execution time: 0.1773
DEBUG - 2022-11-15 12:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:24 --> Total execution time: 0.1995
DEBUG - 2022-11-15 12:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:30 --> Total execution time: 0.1769
DEBUG - 2022-11-15 12:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:31 --> Total execution time: 0.1818
DEBUG - 2022-11-15 12:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:32 --> Total execution time: 0.1807
DEBUG - 2022-11-15 12:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:33 --> Total execution time: 0.2029
DEBUG - 2022-11-15 12:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:37 --> Total execution time: 0.2039
DEBUG - 2022-11-15 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:51 --> Total execution time: 0.1679
DEBUG - 2022-11-15 12:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:54 --> Total execution time: 0.1704
DEBUG - 2022-11-15 12:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:54:57 --> Total execution time: 0.1839
DEBUG - 2022-11-15 12:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:03 --> Total execution time: 0.1960
DEBUG - 2022-11-15 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:05 --> Total execution time: 0.1725
DEBUG - 2022-11-15 12:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:08 --> Total execution time: 0.1818
DEBUG - 2022-11-15 12:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:13 --> Total execution time: 0.5060
DEBUG - 2022-11-15 12:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:14 --> Total execution time: 0.1682
DEBUG - 2022-11-15 12:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:17 --> Total execution time: 0.1689
DEBUG - 2022-11-15 12:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:21 --> Total execution time: 0.1771
DEBUG - 2022-11-15 12:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:41 --> Total execution time: 0.1842
DEBUG - 2022-11-15 12:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:44 --> Total execution time: 0.1741
DEBUG - 2022-11-15 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:51 --> Total execution time: 0.1662
DEBUG - 2022-11-15 12:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:56 --> Total execution time: 0.1747
DEBUG - 2022-11-15 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:12 --> Total execution time: 0.1754
DEBUG - 2022-11-15 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:14 --> Total execution time: 0.1953
DEBUG - 2022-11-15 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:21 --> Total execution time: 0.1853
DEBUG - 2022-11-15 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:22 --> Total execution time: 0.1708
DEBUG - 2022-11-15 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:29 --> Total execution time: 0.1750
DEBUG - 2022-11-15 12:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:49 --> Total execution time: 0.1712
DEBUG - 2022-11-15 12:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:05 --> Total execution time: 0.8360
DEBUG - 2022-11-15 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:12 --> Total execution time: 0.1698
DEBUG - 2022-11-15 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:15 --> Total execution time: 0.1689
DEBUG - 2022-11-15 12:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:24 --> Total execution time: 0.1687
DEBUG - 2022-11-15 12:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:32 --> Total execution time: 0.1718
DEBUG - 2022-11-15 12:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:44 --> Total execution time: 0.1904
DEBUG - 2022-11-15 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:51 --> Total execution time: 0.1691
DEBUG - 2022-11-15 12:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:09 --> Total execution time: 0.1703
DEBUG - 2022-11-15 12:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:13 --> Total execution time: 0.1782
DEBUG - 2022-11-15 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:16 --> Total execution time: 0.1790
DEBUG - 2022-11-15 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:36 --> Total execution time: 0.1702
DEBUG - 2022-11-15 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:38 --> Total execution time: 0.1736
DEBUG - 2022-11-15 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:58:57 --> Total execution time: 0.1737
DEBUG - 2022-11-15 12:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:59:07 --> Total execution time: 0.1894
DEBUG - 2022-11-15 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:31:26 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:33:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:34:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:34:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:34:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:35:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:39:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:39:20 --> 404 Page Not Found: Rare-set-one-brite-dreams-prints-copyright-brite-music-inc-1988-34341html/index
DEBUG - 2022-11-15 12:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:40:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:40:30 --> 404 Page Not Found: Pokemon-1021431html/index
DEBUG - 2022-11-15 12:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:43:20 --> 404 Page Not Found: Vintage-js-collection-black-velvet-opera-coat-long-duster-witchcore-gothic-coat-809313html/index
DEBUG - 2022-11-15 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:45:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:45:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:46:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:46:39 --> 404 Page Not Found: New-lot-10x-clinique-dramatically-different-lipstick-50-a-different-grape-505029html/index
DEBUG - 2022-11-15 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:50:10 --> 404 Page Not Found: Wooden-thomas-the-train-1999-wooden-annie-and-clarabel-coaches-and-2000-thomas-3789html/index
DEBUG - 2022-11-15 12:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 12:59:34 --> 404 Page Not Found: Apple-magsafe-wallet-761855html/index
DEBUG - 2022-11-15 12:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 12:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:03:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:03:13 --> 404 Page Not Found: Nwt-scary-movie-stoned-ghost-face-scream-spoof-mask-fun-world-495445html/index
DEBUG - 2022-11-15 13:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:05:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:07:05 --> 404 Page Not Found: Fossil-dark-brown-leather-fs4828-watch-697755html/index
DEBUG - 2022-11-15 13:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:12:04 --> 404 Page Not Found: Chic-vegan-leather-floral-applique-bag-787177html/index
DEBUG - 2022-11-15 13:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:14:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:14:51 --> 404 Page Not Found: Trends-international-keith-kimberlin-cattitude-framed-wall-poster-prints-1186388html/index
DEBUG - 2022-11-15 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:17:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:17:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:23:23 --> 404 Page Not Found: Bts-jimin-ytc-busan-hotel-pc-887641html/index
DEBUG - 2022-11-15 13:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:27:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:27:02 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-15 13:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:27:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:27:03 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-15 13:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:30:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:30:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:36:11 --> 404 Page Not Found: Detroit-tigers-brandon-inge-majestic-jersey-size-xxl-classic-home-white-980470html/index
DEBUG - 2022-11-15 13:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:38:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:38:27 --> 404 Page Not Found: Skeleton-jack-and-monster-taco-funko-pop-506843html/index
DEBUG - 2022-11-15 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:40:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:46:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:47:36 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:47:40 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 13:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:47:47 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-11-15 13:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:47:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 13:47:50 --> 404 Page Not Found: Wp-includes/wp-class.php
DEBUG - 2022-11-15 13:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:30 --> Total execution time: 0.1756
DEBUG - 2022-11-15 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:32 --> Total execution time: 0.1776
DEBUG - 2022-11-15 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:32 --> Total execution time: 0.1680
DEBUG - 2022-11-15 13:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:48:48 --> Total execution time: 0.1735
DEBUG - 2022-11-15 13:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:49:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:50:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 13:53:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 13:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:00:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:00:48 --> 404 Page Not Found: Automatic-extension-tube-macro-photography-for-canon-rf-mount-eos-r-r5-r6-rp-usa-325384html/index
DEBUG - 2022-11-15 14:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:02:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:02:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:20 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:21 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:44 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:45 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:03:50 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:04:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:04:16 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:04:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:04:40 --> 404 Page Not Found: Esalestrixin/assets
DEBUG - 2022-11-15 14:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:06:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:06:18 --> 404 Page Not Found: Musetex-g05-gaming-computer-case-with-5-fans-rgb-view-phantom-ft-glass-side-pann-119326html/index
DEBUG - 2022-11-15 14:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:07:38 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:09:31 --> 404 Page Not Found: Sports-resort-on-nintendo-wii-and-wii-sports-630009html/index
DEBUG - 2022-11-15 14:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:10:10 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:13:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:17:05 --> 404 Page Not Found: Radiotxt/index
DEBUG - 2022-11-15 14:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:19:45 --> 404 Page Not Found: Birdhouse-with-crown-833463html/index
DEBUG - 2022-11-15 14:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:20:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:20:42 --> 404 Page Not Found: Commercial-paper-towel-dispenser-277051html/index
DEBUG - 2022-11-15 14:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:20:43 --> 404 Page Not Found: Disney-hocus-pocus-girls-halloween-socks-5-pack-390067html/index
DEBUG - 2022-11-15 14:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:21:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:23:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:23:23 --> 404 Page Not Found: Fujifilm-instax-mini-camera-and-acessries-89620html/index
DEBUG - 2022-11-15 14:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:37 --> Total execution time: 0.1861
DEBUG - 2022-11-15 14:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:29:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:29:07 --> 404 Page Not Found: Vintage-cartoon-and-comics-by-walter-foster-790954html/index
DEBUG - 2022-11-15 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:34:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:34:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:37:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:43:04 --> 404 Page Not Found: My-zone-mz1-heart-rate-monitor-physical-activity-belt-593555html/index
DEBUG - 2022-11-15 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:47:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 14:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:47:31 --> 404 Page Not Found: Wp-content/wp-content.php
DEBUG - 2022-11-15 14:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:48:56 --> 404 Page Not Found: Bke-tyler-32-x-32-straight-leg-stretch-denim-jeans-with-coolmax-470315html/index
DEBUG - 2022-11-15 14:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 14:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:51:12 --> 404 Page Not Found: Stereoplasm-indie-perfume-oil-3ml-lot-of-3-916446html/index
DEBUG - 2022-11-15 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 14:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 14:54:46 --> 404 Page Not Found: Bke-tyler-32-x-32-straight-leg-stretch-denim-jeans-with-coolmax-470315html/index
DEBUG - 2022-11-15 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:01:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 15:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:03:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:03:46 --> 404 Page Not Found: Tweakd-spray-duo-34051html/index
DEBUG - 2022-11-15 15:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:14:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 15:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:16:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 15:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:19:46 --> 404 Page Not Found: Coolux-remote-control-for-epson-projector-ready-to-use-soft-buttons-powerlite-7378html/index
DEBUG - 2022-11-15 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:20:39 --> 404 Page Not Found: Brand-new-hp-gaming-pc-desktop-r5-rx-5500-graphics-selling-on-offerup-for-450-571602html/index
DEBUG - 2022-11-15 15:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:20:39 --> 404 Page Not Found: Brand-new-hp-gaming-pc-desktop-r5-rx-5500-graphics-selling-on-offerup-for-450-571602html/index
DEBUG - 2022-11-15 15:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:21:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:21:38 --> 404 Page Not Found: Vintage-nos-paul-mall-super-windproof-c2-lighter-flip-top-butane-lighter-269004html/index
DEBUG - 2022-11-15 15:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:23:58 --> 404 Page Not Found: Isaac-bruce-autograhphed-mini-helmet-652180html/index
DEBUG - 2022-11-15 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:24:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:24:53 --> 404 Page Not Found: From-an-acorn-to-an-oak-messages-on-developing-christian-6-cassettes-swaggart-833979html/index
DEBUG - 2022-11-15 15:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:33:30 --> 404 Page Not Found: 2022-starbucks-gold-grande-bling-cup-1033378html/index
DEBUG - 2022-11-15 15:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:35:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:35:57 --> 404 Page Not Found: Ryans-world-combo-panda-helicopter-716423html/index
DEBUG - 2022-11-15 15:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:46:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-11-15 15:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:51:10 --> 404 Page Not Found: _ignition/health-check
DEBUG - 2022-11-15 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:51:13 --> 404 Page Not Found: Public/_ignition
DEBUG - 2022-11-15 15:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:51:40 --> 404 Page Not Found: Action-replay-ds-611313html/index
DEBUG - 2022-11-15 15:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:51:41 --> 404 Page Not Found: Acrylic-laptop-and-phone-standportable-ergonomic-laptopphone-stand-for-desktop-267747html/index
DEBUG - 2022-11-15 15:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 15:54:39 --> 404 Page Not Found: 4-diamond-kings-fotl-sp-13-531859html/index
DEBUG - 2022-11-15 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 15:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 15:57:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 15:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 15:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:00:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:00:12 --> 404 Page Not Found: Kate-quinn-36-bundle-323828html/index
DEBUG - 2022-11-15 16:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:08:10 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:09:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:09:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:09:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:09:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:11:11 --> 404 Page Not Found: Toshiba-vhs-dvd-recorder-787090html/index
DEBUG - 2022-11-15 16:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:20:00 --> Total execution time: 0.1815
DEBUG - 2022-11-15 16:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:22:55 --> Total execution time: 0.4458
DEBUG - 2022-11-15 16:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:22:55 --> Total execution time: 0.1212
DEBUG - 2022-11-15 16:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:24:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:24:03 --> 404 Page Not Found: Kirkland-halloween-witch-gnome-yard-decor-prop-pumpkin-bat-standing-926092html/index
DEBUG - 2022-11-15 16:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:24:09 --> 404 Page Not Found: Arif/Telerik.Web.UI.WebResource.axd
DEBUG - 2022-11-15 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:26:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:27:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:27:29 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-15 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:27:30 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-15 16:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:37:43 --> 404 Page Not Found: Isaiah-spiller-2022-certified-rookie-tricolor-pieces-of-the-game-patch-50-172426html/index
DEBUG - 2022-11-15 16:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:41:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 16:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 16:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 16:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:47:54 --> 404 Page Not Found: Youth-hunting-camo-shirt-659569html/index
DEBUG - 2022-11-15 16:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:57:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:57:07 --> 404 Page Not Found: Gameboy-advance-sp-ags-1869html/index
DEBUG - 2022-11-15 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 16:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 16:57:15 --> 404 Page Not Found: Purple-longchamp-le-pliage-backpack-441660html/index
DEBUG - 2022-11-15 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:02:10 --> 404 Page Not Found: Site/assets
DEBUG - 2022-11-15 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:04:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:04:58 --> 404 Page Not Found: Raquel-welch-wig-trend-setter-red-copper-textured-shag-open-box-504532html/index
DEBUG - 2022-11-15 17:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:06:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 17:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:10:20 --> 404 Page Not Found: Blue-gloomy-bear-pouch-957175html/index
DEBUG - 2022-11-15 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:11:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:11:45 --> 404 Page Not Found: Betsey-johnson-dream-big-wristlet-pouch-772928html/index
DEBUG - 2022-11-15 17:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:25:21 --> No URI present. Default controller set.
DEBUG - 2022-11-15 17:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:35:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:35:36 --> 404 Page Not Found: Boys-zip-up-hoodie-and-sweats-921262html/index
DEBUG - 2022-11-15 17:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:44:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 17:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:44:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:45:03 --> 404 Page Not Found: 3-randy-moss-rookie-cards-255597html/index
DEBUG - 2022-11-15 17:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:47:14 --> No URI present. Default controller set.
DEBUG - 2022-11-15 17:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:49:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:49:15 --> 404 Page Not Found: Iron-man-scentsy-warmer-new-926567html/index
DEBUG - 2022-11-15 17:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:54:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:54:00 --> 404 Page Not Found: Disney-parks-50th-anniversary-earidescent-shimmer-gold-blue-minnie-ear-headband-383018html/index
DEBUG - 2022-11-15 17:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:57:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 17:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:58:28 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-15 17:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 17:58:28 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-15 17:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 17:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 17:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 17:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:00:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:24 --> Total execution time: 0.2008
DEBUG - 2022-11-15 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:27 --> Total execution time: 0.2003
DEBUG - 2022-11-15 18:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:01:27 --> Total execution time: 0.1877
DEBUG - 2022-11-15 18:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:03:07 --> Total execution time: 0.1619
DEBUG - 2022-11-15 18:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:03:10 --> Total execution time: 0.1706
DEBUG - 2022-11-15 18:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:03:10 --> Total execution time: 0.1686
DEBUG - 2022-11-15 18:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:04:22 --> Total execution time: 0.1708
DEBUG - 2022-11-15 18:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:04:25 --> Total execution time: 0.1811
DEBUG - 2022-11-15 18:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:04:25 --> Total execution time: 0.3968
DEBUG - 2022-11-15 18:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:43 --> Total execution time: 0.1690
DEBUG - 2022-11-15 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:46 --> Total execution time: 0.1695
DEBUG - 2022-11-15 18:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:05:46 --> Total execution time: 0.3978
DEBUG - 2022-11-15 18:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:05:52 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-11-15 18:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:05:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:06:16 --> 404 Page Not Found: Taylor-swift-rsd-crystal-clear-turquoise-colored-vinyl-lp-rare-152346html/index
DEBUG - 2022-11-15 18:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:21 --> Total execution time: 0.1744
DEBUG - 2022-11-15 18:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:26 --> Total execution time: 0.2048
DEBUG - 2022-11-15 18:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:34 --> Total execution time: 0.1568
DEBUG - 2022-11-15 18:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:40 --> Total execution time: 0.1690
DEBUG - 2022-11-15 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:15:45 --> Total execution time: 0.1708
DEBUG - 2022-11-15 18:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:18:26 --> 404 Page Not Found: Lilo-and-stitch-christmas-lights-stitch-christmas-stocking-new-11100html/index
DEBUG - 2022-11-15 18:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:18:27 --> 404 Page Not Found: How-to-train-your-dragon-311098html/index
DEBUG - 2022-11-15 18:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:20:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:25:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:25:51 --> 404 Page Not Found: Wp-includes/sodium_compat
DEBUG - 2022-11-15 18:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:34:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:34:23 --> 404 Page Not Found: Wp-admin/user
DEBUG - 2022-11-15 18:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:36:16 --> 404 Page Not Found: Rocky-mens-camouflage-insulated-hunting-jacket-coat-xxl-mossy-oak-new-break-up-255244html/index
DEBUG - 2022-11-15 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:36:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:36:16 --> 404 Page Not Found: Author/admin
DEBUG - 2022-11-15 18:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:37:08 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 18:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:46:54 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 18:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:48:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:48:18 --> 404 Page Not Found: Traxxas-ez-peak-plus-charger-lipo-276754html/index
DEBUG - 2022-11-15 18:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:50:40 --> 404 Page Not Found: Costway-48-inch-pre-lit-cordless-wreath-christmas-199644html/index
DEBUG - 2022-11-15 18:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:51:16 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 18:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:51:29 --> 404 Page Not Found: New-abercrombie-kids-khaki-pants-for-boys-391523html/index
DEBUG - 2022-11-15 18:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:52:51 --> 404 Page Not Found: Randy-travis-cassette-tapes-lot-of-3-new-used-1077820html/index
DEBUG - 2022-11-15 18:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:52:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:54:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 18:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:54:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 18:54:32 --> 404 Page Not Found: 2020-justin-herbert-score-rc-rookie-card-362nla-chargers-qb-360057html/index
DEBUG - 2022-11-15 18:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 18:57:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 18:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 18:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:05:42 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:04 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:06:16 --> 404 Page Not Found: Category/education
DEBUG - 2022-11-15 19:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:06:16 --> 404 Page Not Found: Horimiya-vol-15-1041618html/index
DEBUG - 2022-11-15 19:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:07:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:17:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:17:10 --> 404 Page Not Found: Wp-admin/ms-admin-wp.php
DEBUG - 2022-11-15 19:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:18:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:20:40 --> 404 Page Not Found: Boss-by-hugo-boss-dark-navyblack-white-hekata-short-casual-dress-8-m-335427html/index
DEBUG - 2022-11-15 19:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:20:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:25:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:27:53 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-11-15 19:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:28:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:28:17 --> 404 Page Not Found: Nba-2k23-xbox-one-655674html/index
DEBUG - 2022-11-15 19:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:35:22 --> 404 Page Not Found: Black-backpack-1956html/index
DEBUG - 2022-11-15 19:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:36:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:36:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:36:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:36:31 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:37:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 19:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:37:42 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-11-15 19:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:37:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 19:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:43:06 --> 404 Page Not Found: Js/js.php
DEBUG - 2022-11-15 19:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:43:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 19:43:43 --> 404 Page Not Found: Catalog/catalog.php
DEBUG - 2022-11-15 19:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 19:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 19:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 19:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:01:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:08 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:10:59 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:11:06 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:11:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:13:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:22:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:24:31 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:26:07 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:28 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:33 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 20:32:44 --> 404 Page Not Found: Strings-xmlphp/index
DEBUG - 2022-11-15 20:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 20:35:12 --> 404 Page Not Found: Android-tv-box-788610html/index
DEBUG - 2022-11-15 20:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:40:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:43:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:48:25 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 20:48:26 --> 404 Page Not Found: 2-stephen-king-graphic-novels-424342html/index
DEBUG - 2022-11-15 20:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:53:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:53:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:55:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 20:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 20:59:29 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-15 20:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 20:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 20:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 20:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:00:30 --> 404 Page Not Found: Walt-disney-world-664844html/index
DEBUG - 2022-11-15 21:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:01:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:05:21 --> 404 Page Not Found: Sony-linkbuds-184097html/index
DEBUG - 2022-11-15 21:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:47 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:09:48 --> 404 Page Not Found: Nib-ps5-fit-dual-sense-2controller-charger-fast-led-428217html/index
DEBUG - 2022-11-15 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:10:21 --> 404 Page Not Found: Obsession-by-calvin-klein-eau-de-parfum-perfume-spray-5-oz-15-ml-77028html/index
DEBUG - 2022-11-15 21:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:11:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:11:17 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:44 --> Total execution time: 0.1946
DEBUG - 2022-11-15 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:47 --> Total execution time: 0.1813
DEBUG - 2022-11-15 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:11:47 --> Total execution time: 0.1798
DEBUG - 2022-11-15 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:13:07 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:14:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:19:41 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:23:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:26:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:27:39 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:28:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:29:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:29:59 --> Total execution time: 0.1688
DEBUG - 2022-11-15 21:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:09 --> Total execution time: 0.2145
DEBUG - 2022-11-15 21:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:09 --> Total execution time: 0.4419
DEBUG - 2022-11-15 21:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:30:22 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:39:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:39:36 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-15 21:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:39:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:39:56 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-15 21:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:40:04 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-15 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:40:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:41:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:43:20 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-11-15 21:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:43 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:41 --> Total execution time: 0.1762
DEBUG - 2022-11-15 21:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:45:50 --> Total execution time: 0.2031
DEBUG - 2022-11-15 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:49:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 21:51:48 --> 404 Page Not Found: Banu-and-ruby-5-christmas-2022-squishmallow-flipamallow-99810html/index
DEBUG - 2022-11-15 21:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:52:08 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:57:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 21:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 21:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 21:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:02:30 --> 404 Page Not Found: Lowprphp/index
DEBUG - 2022-11-15 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:03:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:21 --> Total execution time: 0.1607
DEBUG - 2022-11-15 22:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:28 --> Total execution time: 0.1834
DEBUG - 2022-11-15 22:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:35 --> Total execution time: 0.1610
DEBUG - 2022-11-15 22:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:41 --> Total execution time: 0.1783
DEBUG - 2022-11-15 22:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:10:56 --> Total execution time: 0.1723
DEBUG - 2022-11-15 22:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:11:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:11:40 --> 404 Page Not Found: Disney-eeyore-figure-by-jim-shore-winnie-the-pooh-17087html/index
DEBUG - 2022-11-15 22:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:13:40 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:51 --> Total execution time: 0.1908
DEBUG - 2022-11-15 22:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:14:52 --> Total execution time: 0.2057
DEBUG - 2022-11-15 22:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:13 --> Total execution time: 0.2050
DEBUG - 2022-11-15 22:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:16 --> Total execution time: 0.1679
DEBUG - 2022-11-15 22:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:19 --> Total execution time: 0.1684
DEBUG - 2022-11-15 22:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:21 --> Total execution time: 0.1991
DEBUG - 2022-11-15 22:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:15:33 --> Total execution time: 0.2084
DEBUG - 2022-11-15 22:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:02 --> Total execution time: 0.1689
DEBUG - 2022-11-15 22:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:16 --> Total execution time: 0.1872
DEBUG - 2022-11-15 22:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:26 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:27 --> Total execution time: 0.2018
DEBUG - 2022-11-15 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:32 --> Total execution time: 0.1707
DEBUG - 2022-11-15 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:34 --> Total execution time: 0.1676
DEBUG - 2022-11-15 22:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:38 --> Total execution time: 0.1695
DEBUG - 2022-11-15 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:42 --> Total execution time: 0.1782
DEBUG - 2022-11-15 22:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:45 --> Total execution time: 0.1662
DEBUG - 2022-11-15 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:49 --> Total execution time: 0.1818
DEBUG - 2022-11-15 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:51 --> Total execution time: 0.1744
DEBUG - 2022-11-15 22:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:02 --> Total execution time: 0.2006
DEBUG - 2022-11-15 22:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:05 --> Total execution time: 0.2741
DEBUG - 2022-11-15 22:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:05 --> Total execution time: 0.1713
DEBUG - 2022-11-15 22:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:11 --> Total execution time: 0.1670
DEBUG - 2022-11-15 22:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:19 --> Total execution time: 0.1724
DEBUG - 2022-11-15 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:22 --> Total execution time: 0.2112
DEBUG - 2022-11-15 22:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:19 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:26 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:19:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:19:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 22:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:19:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:20:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:20:55 --> 404 Page Not Found: Variety-of-most-new-playing-cards-cigarettes-marlboro-boag-s-budweiser-97208html/index
DEBUG - 2022-11-15 22:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:22:51 --> 404 Page Not Found: Teacher/index
DEBUG - 2022-11-15 22:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:29:52 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:40:03 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:40:15 --> 404 Page Not Found: Mickey-mouse-disney-mini-backpack-657194html/index
DEBUG - 2022-11-15 22:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:41:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 22:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:41:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:42:02 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:42:13 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:45:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:45:31 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-15 22:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:45:32 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-15 22:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:47:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:47:54 --> 404 Page Not Found: Fully-extended-48-orlimar-wr1-driver-105-degree-uniflex-258378html/index
DEBUG - 2022-11-15 22:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:48:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:50:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:05 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:53:56 --> 404 Page Not Found: Lego-star-wars-the-skywalker-saga-for-nintendo-switch-148533html/index
DEBUG - 2022-11-15 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:55:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 22:55:27 --> 404 Page Not Found: 7-fall-and-thanksgiving-bath-and-body-works-wallflower-plugs-301368html/index
DEBUG - 2022-11-15 22:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:56:11 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:57:23 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:58:33 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:20 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:44 --> No URI present. Default controller set.
DEBUG - 2022-11-15 22:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 22:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 22:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 22:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:24 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:00:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:01:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:18 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:03:49 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:05:26 --> 404 Page Not Found: Used-excellent-condition-lubed-super-silent-new-keycaps-corsair-mechanical-keybo-190525html/index
DEBUG - 2022-11-15 23:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:05:44 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-15 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:05:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-15 23:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:05:50 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:05:53 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-15 23:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:06:48 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:12 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:10:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:13:33 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:13:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:13:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:25 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:31 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:56 --> UTF-8 Support Enabled
ERROR - 2022-11-15 23:15:56 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-15 23:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:15:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:15:57 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-15 23:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:31 --> Total execution time: 0.1689
DEBUG - 2022-11-15 23:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:33 --> Total execution time: 0.1919
DEBUG - 2022-11-15 23:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:33 --> Total execution time: 0.2067
DEBUG - 2022-11-15 23:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:46 --> Total execution time: 0.1888
DEBUG - 2022-11-15 23:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:19:34 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:19:35 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:20:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:20:28 --> 404 Page Not Found: Team-umizoomi-millie-learning-shapes-numbers-talking-plush-12-715262html/index
DEBUG - 2022-11-15 23:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:20:57 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:19 --> Total execution time: 0.1823
DEBUG - 2022-11-15 23:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:24:20 --> Total execution time: 0.1927
DEBUG - 2022-11-15 23:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:28:24 --> 404 Page Not Found: Galarian-ponyta-set-of-3-pokemon-center-mini-hand-towel-sword-and-shield-213773html/index
DEBUG - 2022-11-15 23:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:32:01 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:32:30 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:16 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:23 --> Total execution time: 0.1784
DEBUG - 2022-11-15 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:25 --> Total execution time: 0.1753
DEBUG - 2022-11-15 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:26 --> Total execution time: 0.1792
DEBUG - 2022-11-15 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:26 --> Total execution time: 0.1857
DEBUG - 2022-11-15 23:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:28 --> Total execution time: 0.2038
DEBUG - 2022-11-15 23:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:29 --> Total execution time: 0.1991
DEBUG - 2022-11-15 23:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:46 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:54 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:55 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:09 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:27 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:35 --> Total execution time: 0.4842
DEBUG - 2022-11-15 23:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:37 --> Total execution time: 0.5984
DEBUG - 2022-11-15 23:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:38 --> Total execution time: 0.8161
DEBUG - 2022-11-15 23:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:36:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 23:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:37 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:37:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:38:55 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-11-15 23:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:38:56 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:32 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:45 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:45:15 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:45:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:45:29 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-11-15 23:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:46:53 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:48:00 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:03 --> Total execution time: 0.1873
DEBUG - 2022-11-15 23:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:05 --> Total execution time: 0.1700
DEBUG - 2022-11-15 23:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:06 --> Total execution time: 0.2702
DEBUG - 2022-11-15 23:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:13 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:46 --> Total execution time: 0.1101
DEBUG - 2022-11-15 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:56 --> Total execution time: 0.2122
DEBUG - 2022-11-15 23:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:50:57 --> Total execution time: 0.4117
DEBUG - 2022-11-15 23:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:51:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-15 23:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-15 23:56:10 --> 404 Page Not Found: 1980-warner-bros-the-dukes-of-hazzard-general-lee-dodge-368749html/index
DEBUG - 2022-11-15 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:59:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:59:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-15 23:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-15 23:59:29 --> No URI present. Default controller set.
DEBUG - 2022-11-15 23:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-15 23:59:29 --> Encryption: Auto-configured driver 'openssl'.
