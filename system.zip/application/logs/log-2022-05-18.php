<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-18 00:54:27 --> Total execution time: 0.0185
DEBUG - 2022-05-18 00:54:32 --> Total execution time: 0.0209
DEBUG - 2022-05-18 00:55:05 --> Total execution time: 0.0152
DEBUG - 2022-05-18 00:59:55 --> Total execution time: 0.0186
DEBUG - 2022-05-18 01:04:17 --> Total execution time: 0.0160
DEBUG - 2022-05-18 01:04:19 --> Total execution time: 0.0133
DEBUG - 2022-05-18 01:04:26 --> Total execution time: 0.0224
DEBUG - 2022-05-18 01:04:53 --> Total execution time: 0.0150
DEBUG - 2022-05-18 01:05:27 --> Total execution time: 0.0330
DEBUG - 2022-05-18 01:05:40 --> Total execution time: 0.0265
DEBUG - 2022-05-18 01:05:51 --> Total execution time: 0.1856
DEBUG - 2022-05-18 01:06:03 --> Total execution time: 0.0171
DEBUG - 2022-05-18 01:32:32 --> Total execution time: 0.0775
DEBUG - 2022-05-18 01:35:51 --> Total execution time: 0.0161
DEBUG - 2022-05-18 01:57:15 --> Total execution time: 0.1069
DEBUG - 2022-05-18 01:58:32 --> Total execution time: 0.0340
DEBUG - 2022-05-18 02:04:46 --> Total execution time: 0.0601
DEBUG - 2022-05-18 02:08:53 --> Total execution time: 0.0214
DEBUG - 2022-05-18 02:08:55 --> Total execution time: 0.0112
DEBUG - 2022-05-18 02:12:10 --> Total execution time: 0.0683
DEBUG - 2022-05-18 02:12:18 --> Total execution time: 0.0215
DEBUG - 2022-05-18 02:23:01 --> Total execution time: 0.1422
DEBUG - 2022-05-18 03:18:48 --> Total execution time: 0.1176
DEBUG - 2022-05-18 03:18:52 --> Total execution time: 0.0069
DEBUG - 2022-05-18 03:20:09 --> Total execution time: 0.0167
DEBUG - 2022-05-18 03:20:22 --> Total execution time: 0.0124
DEBUG - 2022-05-18 03:22:35 --> Total execution time: 0.0226
DEBUG - 2022-05-18 03:23:05 --> Total execution time: 0.0159
DEBUG - 2022-05-18 03:23:39 --> Total execution time: 0.0125
DEBUG - 2022-05-18 03:24:18 --> Total execution time: 0.0196
DEBUG - 2022-05-18 03:24:40 --> Total execution time: 0.0135
DEBUG - 2022-05-18 03:25:02 --> Total execution time: 0.0138
DEBUG - 2022-05-18 03:25:59 --> Total execution time: 0.0128
DEBUG - 2022-05-18 03:40:53 --> Total execution time: 0.1010
DEBUG - 2022-05-18 03:41:07 --> Total execution time: 0.0169
DEBUG - 2022-05-18 03:44:20 --> Total execution time: 0.0137
DEBUG - 2022-05-18 03:44:58 --> Total execution time: 0.0123
DEBUG - 2022-05-18 03:45:04 --> Total execution time: 0.0165
DEBUG - 2022-05-18 03:45:07 --> Total execution time: 0.0176
DEBUG - 2022-05-18 03:45:18 --> Total execution time: 0.0133
DEBUG - 2022-05-18 03:45:30 --> Total execution time: 0.0202
DEBUG - 2022-05-18 03:45:41 --> Total execution time: 0.0374
DEBUG - 2022-05-18 03:45:49 --> Total execution time: 0.0299
DEBUG - 2022-05-18 03:46:37 --> Total execution time: 0.0174
DEBUG - 2022-05-18 03:46:41 --> Total execution time: 0.0135
DEBUG - 2022-05-18 03:47:01 --> Total execution time: 0.0194
DEBUG - 2022-05-18 03:47:17 --> Total execution time: 0.0199
DEBUG - 2022-05-18 03:47:25 --> Total execution time: 0.0135
DEBUG - 2022-05-18 03:47:27 --> Total execution time: 0.0173
DEBUG - 2022-05-18 03:47:32 --> Total execution time: 0.0135
DEBUG - 2022-05-18 03:48:25 --> Total execution time: 0.0134
DEBUG - 2022-05-18 03:48:35 --> Total execution time: 0.0131
DEBUG - 2022-05-18 03:48:41 --> Total execution time: 0.0162
DEBUG - 2022-05-18 03:48:44 --> Total execution time: 0.0090
DEBUG - 2022-05-18 03:48:53 --> Total execution time: 0.0067
DEBUG - 2022-05-18 03:49:18 --> Total execution time: 0.0131
DEBUG - 2022-05-18 03:49:33 --> Total execution time: 0.0140
DEBUG - 2022-05-18 03:49:59 --> Total execution time: 0.0141
DEBUG - 2022-05-18 03:50:28 --> Total execution time: 0.0190
DEBUG - 2022-05-18 03:50:38 --> Total execution time: 0.0139
DEBUG - 2022-05-18 03:50:56 --> Total execution time: 0.0140
DEBUG - 2022-05-18 03:51:04 --> Total execution time: 0.0137
DEBUG - 2022-05-18 03:51:08 --> Total execution time: 0.0138
DEBUG - 2022-05-18 03:51:18 --> Total execution time: 0.0193
DEBUG - 2022-05-18 03:51:22 --> Total execution time: 0.0247
DEBUG - 2022-05-18 03:51:42 --> Total execution time: 0.0158
DEBUG - 2022-05-18 03:51:45 --> Total execution time: 0.2015
DEBUG - 2022-05-18 03:51:52 --> Total execution time: 0.0167
DEBUG - 2022-05-18 03:51:52 --> Total execution time: 0.0165
DEBUG - 2022-05-18 03:51:59 --> Total execution time: 0.0163
DEBUG - 2022-05-18 03:52:02 --> Total execution time: 0.0138
DEBUG - 2022-05-18 03:52:04 --> Total execution time: 0.0133
DEBUG - 2022-05-18 03:52:08 --> Total execution time: 0.0134
DEBUG - 2022-05-18 03:52:27 --> Total execution time: 0.0139
DEBUG - 2022-05-18 03:52:30 --> Total execution time: 0.0127
DEBUG - 2022-05-18 03:52:33 --> Total execution time: 0.0133
DEBUG - 2022-05-18 03:52:38 --> Total execution time: 0.0142
DEBUG - 2022-05-18 03:52:40 --> Total execution time: 0.0189
DEBUG - 2022-05-18 03:52:49 --> Total execution time: 0.0155
DEBUG - 2022-05-18 03:52:52 --> Total execution time: 0.0241
DEBUG - 2022-05-18 03:52:55 --> Total execution time: 0.0130
DEBUG - 2022-05-18 03:52:59 --> Total execution time: 0.0128
DEBUG - 2022-05-18 03:53:03 --> Total execution time: 0.0164
DEBUG - 2022-05-18 03:56:34 --> Total execution time: 0.0342
DEBUG - 2022-05-18 03:56:42 --> Total execution time: 0.0139
DEBUG - 2022-05-18 03:56:52 --> Total execution time: 0.0160
DEBUG - 2022-05-18 03:57:40 --> Total execution time: 0.0177
DEBUG - 2022-05-18 03:57:52 --> Total execution time: 0.0182
DEBUG - 2022-05-18 03:58:01 --> Total execution time: 0.0158
DEBUG - 2022-05-18 03:58:10 --> Total execution time: 0.0134
DEBUG - 2022-05-18 03:58:18 --> Total execution time: 0.0139
DEBUG - 2022-05-18 03:58:39 --> Total execution time: 0.0137
DEBUG - 2022-05-18 03:59:09 --> Total execution time: 0.0129
DEBUG - 2022-05-18 03:59:26 --> Total execution time: 0.0139
DEBUG - 2022-05-18 04:00:23 --> Total execution time: 0.0161
DEBUG - 2022-05-18 04:00:28 --> Total execution time: 0.0135
DEBUG - 2022-05-18 04:00:45 --> Total execution time: 0.0137
DEBUG - 2022-05-18 04:01:00 --> Total execution time: 0.0183
DEBUG - 2022-05-18 04:01:11 --> Total execution time: 0.0146
DEBUG - 2022-05-18 04:01:27 --> Total execution time: 0.0168
DEBUG - 2022-05-18 04:02:04 --> Total execution time: 0.1810
DEBUG - 2022-05-18 04:02:16 --> Total execution time: 0.0160
DEBUG - 2022-05-18 04:02:29 --> Total execution time: 0.1647
DEBUG - 2022-05-18 04:03:45 --> Total execution time: 0.1694
DEBUG - 2022-05-18 04:13:35 --> Total execution time: 0.0836
DEBUG - 2022-05-18 04:13:57 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 04:13:58 --> Total execution time: 0.0210
DEBUG - 2022-05-18 04:14:28 --> Total execution time: 0.0190
DEBUG - 2022-05-18 04:14:42 --> Total execution time: 0.0205
DEBUG - 2022-05-18 04:14:50 --> Total execution time: 0.0199
DEBUG - 2022-05-18 04:14:53 --> Total execution time: 0.0160
DEBUG - 2022-05-18 04:15:05 --> Total execution time: 0.0180
DEBUG - 2022-05-18 04:15:25 --> Total execution time: 0.0167
DEBUG - 2022-05-18 04:15:30 --> Total execution time: 0.0554
DEBUG - 2022-05-18 04:15:43 --> Total execution time: 0.0466
DEBUG - 2022-05-18 04:17:36 --> Total execution time: 0.3373
DEBUG - 2022-05-18 04:17:50 --> Total execution time: 0.2355
DEBUG - 2022-05-18 04:18:02 --> Total execution time: 0.3963
DEBUG - 2022-05-18 04:20:02 --> Total execution time: 0.2342
DEBUG - 2022-05-18 04:20:13 --> Total execution time: 0.0401
DEBUG - 2022-05-18 04:20:32 --> Total execution time: 0.0439
DEBUG - 2022-05-18 04:20:43 --> Total execution time: 0.0209
DEBUG - 2022-05-18 04:20:53 --> Total execution time: 0.0158
DEBUG - 2022-05-18 04:20:58 --> Total execution time: 0.0218
DEBUG - 2022-05-18 04:21:02 --> Total execution time: 0.0391
DEBUG - 2022-05-18 04:21:09 --> Total execution time: 0.0154
DEBUG - 2022-05-18 04:21:18 --> Total execution time: 0.0148
DEBUG - 2022-05-18 04:21:21 --> Total execution time: 0.0195
DEBUG - 2022-05-18 04:21:40 --> Total execution time: 0.0166
DEBUG - 2022-05-18 04:22:02 --> Total execution time: 0.0223
DEBUG - 2022-05-18 04:22:21 --> Total execution time: 0.0403
DEBUG - 2022-05-18 04:22:30 --> Total execution time: 0.0409
DEBUG - 2022-05-18 04:22:33 --> Total execution time: 0.0399
DEBUG - 2022-05-18 04:23:34 --> Total execution time: 0.0626
DEBUG - 2022-05-18 04:23:58 --> Total execution time: 0.0393
DEBUG - 2022-05-18 04:25:54 --> Total execution time: 0.2481
DEBUG - 2022-05-18 04:28:25 --> Total execution time: 0.0971
DEBUG - 2022-05-18 04:32:54 --> Total execution time: 0.3015
DEBUG - 2022-05-18 04:34:28 --> Total execution time: 0.0847
DEBUG - 2022-05-18 04:34:38 --> Total execution time: 0.2499
DEBUG - 2022-05-18 04:36:15 --> Total execution time: 0.0474
DEBUG - 2022-05-18 04:36:26 --> Total execution time: 0.2256
DEBUG - 2022-05-18 04:40:49 --> Total execution time: 0.0773
DEBUG - 2022-05-18 04:41:02 --> Total execution time: 0.0159
DEBUG - 2022-05-18 04:42:24 --> Total execution time: 0.0155
DEBUG - 2022-05-18 04:43:34 --> Total execution time: 0.0199
DEBUG - 2022-05-18 04:43:42 --> Total execution time: 0.0194
DEBUG - 2022-05-18 04:43:58 --> Total execution time: 0.0170
DEBUG - 2022-05-18 04:45:14 --> Total execution time: 0.0171
DEBUG - 2022-05-18 04:45:39 --> Total execution time: 0.0154
DEBUG - 2022-05-18 04:45:59 --> Total execution time: 0.0187
DEBUG - 2022-05-18 04:46:17 --> Total execution time: 0.0152
DEBUG - 2022-05-18 04:50:42 --> Total execution time: 0.0773
DEBUG - 2022-05-18 04:50:50 --> Total execution time: 0.0169
DEBUG - 2022-05-18 08:27:37 --> Total execution time: 0.1090
DEBUG - 2022-05-18 03:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 03:55:27 --> No URI present. Default controller set.
DEBUG - 2022-05-18 03:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 03:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:25:27 --> Total execution time: 0.1125
DEBUG - 2022-05-18 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:11:39 --> No URI present. Default controller set.
DEBUG - 2022-05-18 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:41:39 --> Total execution time: 0.0608
DEBUG - 2022-05-18 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:41:44 --> Total execution time: 0.0494
DEBUG - 2022-05-18 04:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 04:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:41:54 --> Total execution time: 0.0399
DEBUG - 2022-05-18 04:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:41:59 --> Total execution time: 0.0525
DEBUG - 2022-05-18 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:42:03 --> Total execution time: 0.0532
DEBUG - 2022-05-18 04:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:42:27 --> Total execution time: 0.0314
DEBUG - 2022-05-18 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 04:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:42:34 --> Total execution time: 0.0334
DEBUG - 2022-05-18 04:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:15:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 04:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:45:06 --> Total execution time: 0.0382
DEBUG - 2022-05-18 04:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 04:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 04:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:16 --> Total execution time: 0.0958
DEBUG - 2022-05-18 05:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:21:16 --> No URI present. Default controller set.
DEBUG - 2022-05-18 05:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:51:16 --> Total execution time: 0.1042
DEBUG - 2022-05-18 05:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:51:36 --> Total execution time: 0.0432
DEBUG - 2022-05-18 05:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:51:56 --> Total execution time: 0.0174
DEBUG - 2022-05-18 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:52:11 --> Total execution time: 0.0189
DEBUG - 2022-05-18 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:52:48 --> Total execution time: 0.0122
DEBUG - 2022-05-18 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:53:32 --> Total execution time: 0.0142
DEBUG - 2022-05-18 05:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:24:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 05:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:54:06 --> Total execution time: 0.0425
DEBUG - 2022-05-18 05:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:24:08 --> No URI present. Default controller set.
DEBUG - 2022-05-18 05:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:54:09 --> Total execution time: 0.0225
DEBUG - 2022-05-18 05:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:54:13 --> Total execution time: 0.0133
DEBUG - 2022-05-18 05:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:54:37 --> Total execution time: 0.0285
DEBUG - 2022-05-18 05:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:55:02 --> Total execution time: 0.0305
DEBUG - 2022-05-18 05:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:55:22 --> Total execution time: 0.0289
DEBUG - 2022-05-18 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:58:30 --> Total execution time: 0.0906
DEBUG - 2022-05-18 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:58:38 --> Total execution time: 0.0644
DEBUG - 2022-05-18 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:00:16 --> Total execution time: 0.0542
DEBUG - 2022-05-18 05:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:00:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 05:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:00:47 --> Total execution time: 0.0476
DEBUG - 2022-05-18 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:01:12 --> Total execution time: 0.0461
DEBUG - 2022-05-18 05:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:01:27 --> Total execution time: 0.0466
DEBUG - 2022-05-18 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:01:40 --> Total execution time: 0.0455
DEBUG - 2022-05-18 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:01:47 --> Total execution time: 0.0621
DEBUG - 2022-05-18 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:02:00 --> Total execution time: 0.0538
DEBUG - 2022-05-18 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:02:38 --> Total execution time: 0.0656
DEBUG - 2022-05-18 05:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:02:46 --> Total execution time: 0.0639
DEBUG - 2022-05-18 05:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:08:58 --> Total execution time: 0.0508
DEBUG - 2022-05-18 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:09:15 --> Total execution time: 0.0477
DEBUG - 2022-05-18 05:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:09:18 --> Total execution time: 0.0615
DEBUG - 2022-05-18 05:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:09:58 --> Total execution time: 0.0619
DEBUG - 2022-05-18 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:09:59 --> Total execution time: 0.0589
DEBUG - 2022-05-18 05:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:10:05 --> Total execution time: 0.0590
DEBUG - 2022-05-18 05:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:02 --> Total execution time: 0.0629
DEBUG - 2022-05-18 05:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:20 --> Total execution time: 0.0448
DEBUG - 2022-05-18 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:40 --> Total execution time: 0.0587
DEBUG - 2022-05-18 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:40 --> Total execution time: 0.0642
DEBUG - 2022-05-18 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:41 --> No URI present. Default controller set.
DEBUG - 2022-05-18 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:41 --> Total execution time: 0.0349
DEBUG - 2022-05-18 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:43 --> Total execution time: 0.0169
DEBUG - 2022-05-18 05:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:48 --> Total execution time: 0.0193
DEBUG - 2022-05-18 05:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:11:58 --> Total execution time: 0.0237
DEBUG - 2022-05-18 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:14:35 --> Total execution time: 0.0484
DEBUG - 2022-05-18 05:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:14:42 --> Total execution time: 0.0186
DEBUG - 2022-05-18 05:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:15:51 --> Total execution time: 0.0158
DEBUG - 2022-05-18 05:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:15:59 --> Total execution time: 0.0216
DEBUG - 2022-05-18 05:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:16:21 --> Total execution time: 0.0201
DEBUG - 2022-05-18 05:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 05:55:04 --> No URI present. Default controller set.
DEBUG - 2022-05-18 05:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 05:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:25:04 --> Total execution time: 0.1088
DEBUG - 2022-05-18 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 16:59:45 --> Total execution time: 0.0682
DEBUG - 2022-05-18 06:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:50:34 --> No URI present. Default controller set.
DEBUG - 2022-05-18 06:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:20:34 --> Total execution time: 0.1288
DEBUG - 2022-05-18 06:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:53:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 06:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:23:06 --> Total execution time: 0.0494
DEBUG - 2022-05-18 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:58:31 --> No URI present. Default controller set.
DEBUG - 2022-05-18 06:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:28:31 --> Total execution time: 0.0276
DEBUG - 2022-05-18 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 06:59:56 --> Total execution time: 0.0200
DEBUG - 2022-05-18 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 06:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 06:59:58 --> Total execution time: 0.0365
DEBUG - 2022-05-18 06:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 06:59:58 --> Total execution time: 0.0351
DEBUG - 2022-05-18 07:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:03:25 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:33:25 --> Total execution time: 0.0658
DEBUG - 2022-05-18 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:03:36 --> Total execution time: 0.0372
DEBUG - 2022-05-18 07:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:04:03 --> Total execution time: 0.0158
DEBUG - 2022-05-18 07:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:04:09 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:34:09 --> Total execution time: 0.0186
DEBUG - 2022-05-18 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:34:32 --> Total execution time: 0.0162
DEBUG - 2022-05-18 07:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:34:41 --> Total execution time: 3.2293
DEBUG - 2022-05-18 07:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:05:35 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:35:35 --> Total execution time: 0.0190
DEBUG - 2022-05-18 07:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:12 --> Total execution time: 0.0246
DEBUG - 2022-05-18 07:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:25 --> Total execution time: 0.0358
DEBUG - 2022-05-18 07:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:36 --> Total execution time: 0.0287
DEBUG - 2022-05-18 07:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:42 --> Total execution time: 0.0169
DEBUG - 2022-05-18 07:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:44 --> Total execution time: 0.0156
DEBUG - 2022-05-18 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:36:49 --> Total execution time: 0.0239
DEBUG - 2022-05-18 07:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:37:43 --> Total execution time: 0.0169
DEBUG - 2022-05-18 07:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:37:54 --> Total execution time: 0.0185
DEBUG - 2022-05-18 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:38:03 --> Total execution time: 0.0185
DEBUG - 2022-05-18 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:38:17 --> Total execution time: 0.0233
DEBUG - 2022-05-18 07:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:40:07 --> Total execution time: 0.0448
DEBUG - 2022-05-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:19:54 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:49:55 --> Total execution time: 0.1031
DEBUG - 2022-05-18 07:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:21:21 --> Total execution time: 0.0334
DEBUG - 2022-05-18 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:21:22 --> Total execution time: 0.0175
DEBUG - 2022-05-18 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:51:45 --> Total execution time: 1.5580
DEBUG - 2022-05-18 07:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:52:53 --> Total execution time: 0.0196
DEBUG - 2022-05-18 07:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 17:53:31 --> Total execution time: 37.5251
DEBUG - 2022-05-18 07:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 17:53:31 --> Total execution time: 32.5693
DEBUG - 2022-05-18 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:31:43 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:01:43 --> Total execution time: 0.1476
DEBUG - 2022-05-18 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:33:34 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:03:34 --> Total execution time: 0.0413
DEBUG - 2022-05-18 07:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:03:51 --> Total execution time: 0.0158
DEBUG - 2022-05-18 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:34:17 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:04:17 --> Total execution time: 0.0257
DEBUG - 2022-05-18 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:04:19 --> Total execution time: 0.0141
DEBUG - 2022-05-18 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:04:32 --> Total execution time: 0.0312
DEBUG - 2022-05-18 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:04:42 --> Total execution time: 0.0304
DEBUG - 2022-05-18 07:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:05:12 --> Total execution time: 0.1754
DEBUG - 2022-05-18 07:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:05:49 --> Total execution time: 0.0162
DEBUG - 2022-05-18 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:05:55 --> Total execution time: 0.0187
DEBUG - 2022-05-18 07:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:10 --> Total execution time: 0.0273
DEBUG - 2022-05-18 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:12 --> Total execution time: 0.1447
DEBUG - 2022-05-18 07:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:13 --> Total execution time: 0.0235
DEBUG - 2022-05-18 07:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:14 --> Total execution time: 0.0140
DEBUG - 2022-05-18 07:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:15 --> Total execution time: 0.0166
DEBUG - 2022-05-18 07:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:36:16 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:06:16 --> Total execution time: 0.0156
DEBUG - 2022-05-18 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:37:56 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:07:56 --> Total execution time: 0.0440
DEBUG - 2022-05-18 07:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:14 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:14 --> Total execution time: 0.0506
DEBUG - 2022-05-18 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:17 --> Total execution time: 0.0233
DEBUG - 2022-05-18 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:21 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:21 --> Total execution time: 0.0217
DEBUG - 2022-05-18 07:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:23 --> Total execution time: 0.0228
DEBUG - 2022-05-18 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:29 --> Total execution time: 0.0126
DEBUG - 2022-05-18 07:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:31 --> Total execution time: 0.0136
DEBUG - 2022-05-18 07:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:33 --> Total execution time: 0.0154
DEBUG - 2022-05-18 07:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:47 --> Total execution time: 0.0157
DEBUG - 2022-05-18 07:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:10:53 --> Total execution time: 0.0250
DEBUG - 2022-05-18 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:05 --> Total execution time: 0.0140
DEBUG - 2022-05-18 07:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:12 --> Total execution time: 0.0172
DEBUG - 2022-05-18 07:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:20 --> Total execution time: 0.0176
DEBUG - 2022-05-18 07:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:29 --> Total execution time: 0.0260
DEBUG - 2022-05-18 07:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:30 --> Total execution time: 0.0171
DEBUG - 2022-05-18 07:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:35 --> Total execution time: 0.0242
DEBUG - 2022-05-18 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:11:40 --> Total execution time: 0.0218
DEBUG - 2022-05-18 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:01 --> Total execution time: 0.0166
DEBUG - 2022-05-18 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:03 --> Total execution time: 0.0232
DEBUG - 2022-05-18 07:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:13 --> Total execution time: 0.0204
DEBUG - 2022-05-18 07:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:16 --> Total execution time: 0.0149
DEBUG - 2022-05-18 07:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:21 --> Total execution time: 0.0165
DEBUG - 2022-05-18 07:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:24 --> Total execution time: 0.0159
DEBUG - 2022-05-18 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:32 --> Total execution time: 0.0134
DEBUG - 2022-05-18 07:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:35 --> Total execution time: 0.0168
DEBUG - 2022-05-18 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:37 --> Total execution time: 0.0152
DEBUG - 2022-05-18 07:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:42 --> Total execution time: 0.0124
DEBUG - 2022-05-18 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:45 --> Total execution time: 0.0132
DEBUG - 2022-05-18 07:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:12:52 --> Total execution time: 0.0159
DEBUG - 2022-05-18 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:04 --> Total execution time: 0.0190
DEBUG - 2022-05-18 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:07 --> Total execution time: 0.0143
DEBUG - 2022-05-18 07:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:10 --> Total execution time: 0.0222
DEBUG - 2022-05-18 07:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:25 --> Total execution time: 0.0338
DEBUG - 2022-05-18 07:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:33 --> Total execution time: 0.0194
DEBUG - 2022-05-18 07:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:38 --> Total execution time: 0.0248
DEBUG - 2022-05-18 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:44 --> Total execution time: 0.0432
DEBUG - 2022-05-18 07:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:49 --> Total execution time: 0.0218
DEBUG - 2022-05-18 07:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:52 --> Total execution time: 0.0170
DEBUG - 2022-05-18 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:13:57 --> Total execution time: 0.0249
DEBUG - 2022-05-18 07:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:14:10 --> Total execution time: 0.0143
DEBUG - 2022-05-18 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:14:14 --> Total execution time: 0.0278
DEBUG - 2022-05-18 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:14:27 --> Total execution time: 0.0193
DEBUG - 2022-05-18 07:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:14:37 --> Total execution time: 0.0244
DEBUG - 2022-05-18 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:46:27 --> No URI present. Default controller set.
DEBUG - 2022-05-18 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:16:27 --> Total execution time: 0.0481
DEBUG - 2022-05-18 07:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:20:26 --> Total execution time: 0.0544
DEBUG - 2022-05-18 07:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:20:31 --> Total execution time: 0.1683
DEBUG - 2022-05-18 07:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 07:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 07:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 07:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:28:47 --> Total execution time: 0.0192
DEBUG - 2022-05-18 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:05:27 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:35:27 --> Total execution time: 0.0449
DEBUG - 2022-05-18 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:35:56 --> Total execution time: 0.0202
DEBUG - 2022-05-18 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:05:59 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:35:59 --> Total execution time: 0.0197
DEBUG - 2022-05-18 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:06:48 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:36:48 --> Total execution time: 0.0222
DEBUG - 2022-05-18 08:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:13:03 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:43:03 --> Total execution time: 0.0454
DEBUG - 2022-05-18 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:43:05 --> Total execution time: 0.0143
DEBUG - 2022-05-18 08:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:43:11 --> Total execution time: 0.0270
DEBUG - 2022-05-18 08:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:43:14 --> Total execution time: 0.0238
DEBUG - 2022-05-18 08:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:14:45 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:44:45 --> Total execution time: 0.0213
DEBUG - 2022-05-18 08:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:21:35 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:51:35 --> Total execution time: 0.1020
DEBUG - 2022-05-18 08:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 18:52:30 --> Total execution time: 0.0178
DEBUG - 2022-05-18 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:33:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:03:06 --> Total execution time: 0.0936
DEBUG - 2022-05-18 08:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:03:20 --> Total execution time: 0.0198
DEBUG - 2022-05-18 08:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:04:15 --> Total execution time: 0.0209
DEBUG - 2022-05-18 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:04:26 --> Total execution time: 0.0256
DEBUG - 2022-05-18 08:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:04:40 --> Total execution time: 0.0199
DEBUG - 2022-05-18 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:35:51 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:05:51 --> Total execution time: 0.0168
DEBUG - 2022-05-18 08:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:07:27 --> Total execution time: 0.0346
DEBUG - 2022-05-18 08:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:42:24 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:12:24 --> Total execution time: 0.1114
DEBUG - 2022-05-18 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:13:30 --> Total execution time: 0.0131
DEBUG - 2022-05-18 08:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:14:36 --> Total execution time: 0.0325
DEBUG - 2022-05-18 08:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:16:44 --> Total execution time: 0.0132
DEBUG - 2022-05-18 08:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:19:06 --> Total execution time: 0.0246
DEBUG - 2022-05-18 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:19:11 --> Total execution time: 0.0346
DEBUG - 2022-05-18 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:19:17 --> Total execution time: 0.0179
DEBUG - 2022-05-18 08:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:19:22 --> Total execution time: 0.0251
DEBUG - 2022-05-18 08:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:19:33 --> Total execution time: 0.0301
DEBUG - 2022-05-18 08:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:20:01 --> Total execution time: 0.0188
DEBUG - 2022-05-18 08:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:20:43 --> Total execution time: 0.0374
DEBUG - 2022-05-18 08:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:20:55 --> Total execution time: 0.0282
DEBUG - 2022-05-18 08:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:00 --> Total execution time: 0.0145
DEBUG - 2022-05-18 08:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:02 --> Total execution time: 0.0192
DEBUG - 2022-05-18 08:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:15 --> Total execution time: 0.0137
DEBUG - 2022-05-18 08:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:31 --> Total execution time: 0.0139
DEBUG - 2022-05-18 08:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:36 --> Total execution time: 0.0154
DEBUG - 2022-05-18 08:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:37 --> Total execution time: 0.0131
DEBUG - 2022-05-18 08:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:39 --> Total execution time: 0.0133
DEBUG - 2022-05-18 08:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:21:56 --> Total execution time: 0.0086
DEBUG - 2022-05-18 08:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:22:06 --> Total execution time: 0.0269
DEBUG - 2022-05-18 08:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:22:27 --> Total execution time: 0.0159
DEBUG - 2022-05-18 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:22:31 --> Total execution time: 0.0163
DEBUG - 2022-05-18 08:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:22:34 --> Total execution time: 0.0137
DEBUG - 2022-05-18 08:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:22:46 --> Total execution time: 0.0127
DEBUG - 2022-05-18 08:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:23:05 --> Total execution time: 0.0150
DEBUG - 2022-05-18 08:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:23:35 --> Total execution time: 0.0340
DEBUG - 2022-05-18 08:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:23:41 --> Total execution time: 0.0247
DEBUG - 2022-05-18 08:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:23:50 --> Total execution time: 0.0269
DEBUG - 2022-05-18 08:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:23:55 --> Total execution time: 0.0142
DEBUG - 2022-05-18 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:24:07 --> Total execution time: 0.0556
DEBUG - 2022-05-18 08:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:24:41 --> Total execution time: 0.1986
DEBUG - 2022-05-18 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:18 --> Total execution time: 0.0526
DEBUG - 2022-05-18 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:30 --> Total execution time: 0.0333
DEBUG - 2022-05-18 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:38 --> Total execution time: 0.0214
DEBUG - 2022-05-18 08:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:47 --> Total execution time: 0.0185
DEBUG - 2022-05-18 08:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:51 --> Total execution time: 0.0291
DEBUG - 2022-05-18 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:52 --> Total execution time: 0.0331
DEBUG - 2022-05-18 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:25:58 --> Total execution time: 0.0464
DEBUG - 2022-05-18 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:26:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:26:45 --> Total execution time: 0.0230
DEBUG - 2022-05-18 08:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 08:56:45 --> 404 Page Not Found: User/update-thumbnail
DEBUG - 2022-05-18 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:26:56 --> Total execution time: 0.0323
DEBUG - 2022-05-18 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:00 --> Total execution time: 0.0223
DEBUG - 2022-05-18 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:01 --> Total execution time: 0.0237
DEBUG - 2022-05-18 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:02 --> Total execution time: 0.0434
DEBUG - 2022-05-18 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:03 --> Total execution time: 0.0322
DEBUG - 2022-05-18 08:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:03 --> Total execution time: 0.0106
DEBUG - 2022-05-18 08:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:05 --> Total execution time: 0.0083
DEBUG - 2022-05-18 08:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:06 --> Total execution time: 0.0086
DEBUG - 2022-05-18 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:27:06 --> Total execution time: 0.0369
DEBUG - 2022-05-18 08:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:28:10 --> Total execution time: 0.0157
DEBUG - 2022-05-18 08:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:28:24 --> Total execution time: 0.0150
DEBUG - 2022-05-18 08:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:28:32 --> Total execution time: 0.1568
DEBUG - 2022-05-18 08:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:58:55 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:28:55 --> Total execution time: 0.0196
DEBUG - 2022-05-18 08:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:02 --> Total execution time: 0.0169
DEBUG - 2022-05-18 08:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:03 --> Total execution time: 0.0160
DEBUG - 2022-05-18 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:03 --> Total execution time: 0.0203
DEBUG - 2022-05-18 08:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:04 --> Total execution time: 0.0245
DEBUG - 2022-05-18 08:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:05 --> Total execution time: 0.0189
DEBUG - 2022-05-18 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:05 --> No URI present. Default controller set.
DEBUG - 2022-05-18 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:05 --> Total execution time: 0.0148
DEBUG - 2022-05-18 08:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:13 --> Total execution time: 0.0140
DEBUG - 2022-05-18 08:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:13 --> Total execution time: 0.0164
DEBUG - 2022-05-18 08:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:19 --> Total execution time: 0.0133
DEBUG - 2022-05-18 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 08:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:29:44 --> Total execution time: 0.0160
DEBUG - 2022-05-18 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:30:00 --> Total execution time: 0.0221
DEBUG - 2022-05-18 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:30:12 --> Total execution time: 0.0523
DEBUG - 2022-05-18 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:30:14 --> Total execution time: 0.0172
DEBUG - 2022-05-18 09:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:30:20 --> Total execution time: 0.0257
DEBUG - 2022-05-18 09:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:30:47 --> Total execution time: 0.0252
DEBUG - 2022-05-18 09:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:07 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:07 --> Total execution time: 0.0249
DEBUG - 2022-05-18 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:10 --> Total execution time: 0.0150
DEBUG - 2022-05-18 09:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:13 --> Total execution time: 0.0158
DEBUG - 2022-05-18 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:16 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:16 --> Total execution time: 0.0155
DEBUG - 2022-05-18 09:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:16 --> Total execution time: 0.0142
DEBUG - 2022-05-18 09:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:22 --> Total execution time: 0.0130
DEBUG - 2022-05-18 09:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:30 --> Total execution time: 0.0226
DEBUG - 2022-05-18 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:44 --> Total execution time: 0.0151
DEBUG - 2022-05-18 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:33:47 --> Total execution time: 0.0155
DEBUG - 2022-05-18 09:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:34:10 --> Total execution time: 0.1337
DEBUG - 2022-05-18 09:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:04:11 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:34:11 --> Total execution time: 0.0547
DEBUG - 2022-05-18 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:34:25 --> Total execution time: 0.0172
DEBUG - 2022-05-18 09:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:00 --> Total execution time: 0.0153
DEBUG - 2022-05-18 09:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:02 --> Total execution time: 0.0275
DEBUG - 2022-05-18 09:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:18 --> Total execution time: 0.0170
DEBUG - 2022-05-18 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:28 --> Total execution time: 0.0242
DEBUG - 2022-05-18 09:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:39 --> Total execution time: 0.0197
DEBUG - 2022-05-18 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:45 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:45 --> Total execution time: 0.0108
DEBUG - 2022-05-18 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:45 --> Total execution time: 0.0182
DEBUG - 2022-05-18 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:35:48 --> Total execution time: 0.0153
DEBUG - 2022-05-18 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:36:12 --> Total execution time: 0.0066
DEBUG - 2022-05-18 09:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:36:17 --> Total execution time: 0.0070
DEBUG - 2022-05-18 09:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:36:49 --> Total execution time: 0.0184
DEBUG - 2022-05-18 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:37:01 --> Total execution time: 0.0089
DEBUG - 2022-05-18 09:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:37:10 --> Total execution time: 0.0166
DEBUG - 2022-05-18 09:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:37:16 --> Total execution time: 0.1589
DEBUG - 2022-05-18 09:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:44:49 --> Total execution time: 0.0465
DEBUG - 2022-05-18 09:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:14:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 09:14:53 --> 404 Page Not Found: Iso-certificate/index
DEBUG - 2022-05-18 09:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 09:16:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/new1.esalestrix.in/application/controllers/Welcome.php:81) /home3/esalesei/new1.esalestrix.in/system/core/Common.php 570
ERROR - 2022-05-18 09:16:05 --> Severity: Compile Error --> Cannot redeclare Welcome::about_us() /home3/esalesei/new1.esalestrix.in/application/controllers/Welcome.php 81
DEBUG - 2022-05-18 09:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:46:41 --> Total execution time: 0.0154
DEBUG - 2022-05-18 09:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:48:06 --> Total execution time: 0.0386
DEBUG - 2022-05-18 09:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:48:46 --> Total execution time: 0.0159
DEBUG - 2022-05-18 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:48:50 --> Total execution time: 0.0211
DEBUG - 2022-05-18 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:49:00 --> Total execution time: 0.0161
DEBUG - 2022-05-18 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:49:28 --> Total execution time: 0.0184
DEBUG - 2022-05-18 09:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:49:44 --> Total execution time: 3.1680
DEBUG - 2022-05-18 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:20:58 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:50:58 --> Total execution time: 0.0223
DEBUG - 2022-05-18 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:51:17 --> Total execution time: 0.0153
DEBUG - 2022-05-18 09:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:51:26 --> Total execution time: 0.0353
DEBUG - 2022-05-18 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:51:56 --> Total execution time: 0.0177
DEBUG - 2022-05-18 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:52:02 --> Total execution time: 0.0289
DEBUG - 2022-05-18 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:52:07 --> Total execution time: 0.3529
DEBUG - 2022-05-18 09:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:22:39 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:52:39 --> Total execution time: 0.0155
DEBUG - 2022-05-18 09:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:53:19 --> Total execution time: 0.0140
DEBUG - 2022-05-18 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:54:31 --> Total execution time: 0.0161
DEBUG - 2022-05-18 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:54:48 --> Total execution time: 0.0188
DEBUG - 2022-05-18 09:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:55:03 --> Total execution time: 0.0257
DEBUG - 2022-05-18 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:55:16 --> Total execution time: 0.0228
DEBUG - 2022-05-18 09:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:55:25 --> Total execution time: 0.0200
DEBUG - 2022-05-18 09:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:55:34 --> Total execution time: 0.0184
DEBUG - 2022-05-18 09:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:55:44 --> Total execution time: 0.1972
DEBUG - 2022-05-18 09:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:58:18 --> Total execution time: 0.2057
DEBUG - 2022-05-18 09:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 19:59:37 --> Total execution time: 0.1762
DEBUG - 2022-05-18 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:00:16 --> Total execution time: 0.0294
DEBUG - 2022-05-18 09:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:00:21 --> Total execution time: 0.1749
DEBUG - 2022-05-18 09:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:00:44 --> Total execution time: 0.0267
DEBUG - 2022-05-18 09:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:03:09 --> Total execution time: 0.0743
DEBUG - 2022-05-18 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:10:27 --> Total execution time: 0.0949
DEBUG - 2022-05-18 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:12:09 --> Total execution time: 0.0911
DEBUG - 2022-05-18 09:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:16:17 --> Total execution time: 0.5521
DEBUG - 2022-05-18 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 09:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:17:06 --> Total execution time: 0.0517
DEBUG - 2022-05-18 09:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:17:30 --> Total execution time: 0.0157
DEBUG - 2022-05-18 09:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:17:34 --> Total execution time: 0.0139
DEBUG - 2022-05-18 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:17:47 --> Total execution time: 0.0809
DEBUG - 2022-05-18 09:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:17:57 --> Total execution time: 0.0163
DEBUG - 2022-05-18 09:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 09:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:18:01 --> Total execution time: 1.4928
DEBUG - 2022-05-18 09:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:18:02 --> Total execution time: 1.8766
DEBUG - 2022-05-18 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:18:11 --> Total execution time: 0.0188
DEBUG - 2022-05-18 09:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:18:25 --> Total execution time: 0.0205
DEBUG - 2022-05-18 09:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:18:33 --> Total execution time: 0.0777
DEBUG - 2022-05-18 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:18:43 --> Total execution time: 0.0199
DEBUG - 2022-05-18 09:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:20:05 --> Total execution time: 0.0179
DEBUG - 2022-05-18 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:22:12 --> Total execution time: 0.2167
DEBUG - 2022-05-18 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:22:28 --> Total execution time: 0.4726
DEBUG - 2022-05-18 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:24:25 --> Total execution time: 0.0219
DEBUG - 2022-05-18 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:25:17 --> Total execution time: 0.0249
DEBUG - 2022-05-18 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:29:35 --> Total execution time: 0.1485
DEBUG - 2022-05-18 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:00:09 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:30:09 --> Total execution time: 0.0234
DEBUG - 2022-05-18 10:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:30:13 --> Total execution time: 0.0154
DEBUG - 2022-05-18 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:30:26 --> Total execution time: 0.0159
DEBUG - 2022-05-18 10:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:01:17 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:31:17 --> Total execution time: 0.1166
DEBUG - 2022-05-18 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:31:27 --> Total execution time: 0.0199
DEBUG - 2022-05-18 10:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:31:37 --> Total execution time: 0.0263
DEBUG - 2022-05-18 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:32:14 --> Total execution time: 0.0534
DEBUG - 2022-05-18 10:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:32:29 --> Total execution time: 0.0314
DEBUG - 2022-05-18 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:32:35 --> Total execution time: 0.0463
DEBUG - 2022-05-18 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:35:52 --> Total execution time: 0.0555
DEBUG - 2022-05-18 10:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:11:44 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:41:44 --> Total execution time: 0.0650
DEBUG - 2022-05-18 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:11:52 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:41:52 --> Total execution time: 0.0262
DEBUG - 2022-05-18 10:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:07 --> Total execution time: 0.0352
DEBUG - 2022-05-18 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:30 --> Total execution time: 0.0237
DEBUG - 2022-05-18 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:33 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:33 --> Total execution time: 0.0307
DEBUG - 2022-05-18 10:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:44 --> Total execution time: 0.0311
DEBUG - 2022-05-18 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:45 --> Total execution time: 0.0330
DEBUG - 2022-05-18 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:42:52 --> Total execution time: 0.0524
DEBUG - 2022-05-18 10:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:13:02 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:43:02 --> Total execution time: 0.0317
DEBUG - 2022-05-18 10:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:14:08 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:44:08 --> Total execution time: 0.0355
DEBUG - 2022-05-18 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:44:51 --> Total execution time: 0.0395
DEBUG - 2022-05-18 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:44:58 --> Total execution time: 0.0354
DEBUG - 2022-05-18 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:45:20 --> Total execution time: 0.0317
DEBUG - 2022-05-18 10:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:45:56 --> Total execution time: 0.0459
DEBUG - 2022-05-18 10:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:06 --> Total execution time: 0.0360
DEBUG - 2022-05-18 10:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:09 --> Total execution time: 0.0333
DEBUG - 2022-05-18 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:11 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:11 --> Total execution time: 0.0357
DEBUG - 2022-05-18 10:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:14 --> Total execution time: 0.0321
DEBUG - 2022-05-18 10:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:47 --> Total execution time: 0.0373
DEBUG - 2022-05-18 10:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:46:50 --> Total execution time: 0.0300
DEBUG - 2022-05-18 10:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:47:02 --> Total execution time: 0.0314
DEBUG - 2022-05-18 10:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:47:06 --> Total execution time: 0.0305
DEBUG - 2022-05-18 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:47:21 --> Total execution time: 0.0321
DEBUG - 2022-05-18 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:47:37 --> Total execution time: 0.0495
DEBUG - 2022-05-18 10:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:48:39 --> Total execution time: 0.1516
DEBUG - 2022-05-18 10:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:50:43 --> Total execution time: 0.0373
DEBUG - 2022-05-18 10:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:56:37 --> Total execution time: 0.7253
DEBUG - 2022-05-18 10:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:28:03 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:58:03 --> Total execution time: 0.0609
DEBUG - 2022-05-18 10:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:58:26 --> Total execution time: 0.0537
DEBUG - 2022-05-18 10:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:28:45 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:58:45 --> Total execution time: 0.0343
DEBUG - 2022-05-18 10:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:58:53 --> Total execution time: 0.0317
DEBUG - 2022-05-18 10:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:28:59 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:58:59 --> Total execution time: 0.0365
DEBUG - 2022-05-18 10:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:59:12 --> Total execution time: 0.0311
DEBUG - 2022-05-18 10:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:59:18 --> Total execution time: 0.0380
DEBUG - 2022-05-18 10:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:29:52 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:59:52 --> Total execution time: 0.0394
DEBUG - 2022-05-18 10:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:00:00 --> Total execution time: 0.0315
DEBUG - 2022-05-18 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:00:34 --> Total execution time: 0.0305
DEBUG - 2022-05-18 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:01:02 --> Total execution time: 0.0379
DEBUG - 2022-05-18 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:20 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:01:20 --> Total execution time: 0.0385
DEBUG - 2022-05-18 10:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:01:24 --> Total execution time: 0.0302
DEBUG - 2022-05-18 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:01:44 --> Total execution time: 0.0378
DEBUG - 2022-05-18 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:02:17 --> Total execution time: 0.0535
DEBUG - 2022-05-18 10:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:33:23 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:03:24 --> Total execution time: 0.0439
DEBUG - 2022-05-18 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:03:28 --> Total execution time: 0.0493
DEBUG - 2022-05-18 10:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:03:34 --> Total execution time: 0.0311
DEBUG - 2022-05-18 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:08 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:08 --> Total execution time: 0.0357
DEBUG - 2022-05-18 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:15 --> Total execution time: 0.0332
DEBUG - 2022-05-18 10:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:22 --> Total execution time: 0.0497
DEBUG - 2022-05-18 10:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:23 --> Total execution time: 0.0323
DEBUG - 2022-05-18 10:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:35 --> Total execution time: 0.0529
DEBUG - 2022-05-18 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:49 --> Total execution time: 0.0344
DEBUG - 2022-05-18 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:04:57 --> Total execution time: 0.0323
DEBUG - 2022-05-18 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:34:57 --> Total execution time: 0.0421
DEBUG - 2022-05-18 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:05:01 --> Total execution time: 0.0340
DEBUG - 2022-05-18 10:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:05:07 --> Total execution time: 0.0432
DEBUG - 2022-05-18 10:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:05:24 --> Total execution time: 0.0920
DEBUG - 2022-05-18 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:06:01 --> Total execution time: 0.0454
DEBUG - 2022-05-18 10:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:03 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:03 --> Total execution time: 0.0725
DEBUG - 2022-05-18 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:18 --> Total execution time: 0.0756
DEBUG - 2022-05-18 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:19 --> Total execution time: 0.0349
DEBUG - 2022-05-18 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:20 --> Total execution time: 0.0479
DEBUG - 2022-05-18 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:21 --> Total execution time: 0.0331
DEBUG - 2022-05-18 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:22 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:22 --> Total execution time: 0.0348
DEBUG - 2022-05-18 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:23 --> Total execution time: 0.0458
DEBUG - 2022-05-18 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:37:23 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:07:23 --> Total execution time: 0.0394
DEBUG - 2022-05-18 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:08:25 --> Total execution time: 0.0682
DEBUG - 2022-05-18 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:38:40 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:08:40 --> Total execution time: 0.0367
DEBUG - 2022-05-18 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:38:57 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:08:57 --> Total execution time: 0.0400
DEBUG - 2022-05-18 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:12 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:12 --> Total execution time: 0.0620
DEBUG - 2022-05-18 10:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:16 --> Total execution time: 0.0392
DEBUG - 2022-05-18 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:28 --> Total execution time: 0.0381
DEBUG - 2022-05-18 10:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:39:31 --> Total execution time: 0.0343
DEBUG - 2022-05-18 10:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:32 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:32 --> Total execution time: 0.0335
DEBUG - 2022-05-18 10:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:39:33 --> Total execution time: 0.0442
DEBUG - 2022-05-18 10:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:39:33 --> Total execution time: 0.0351
DEBUG - 2022-05-18 10:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:39 --> Total execution time: 0.0593
DEBUG - 2022-05-18 10:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:46 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:46 --> Total execution time: 0.0357
DEBUG - 2022-05-18 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:53 --> Total execution time: 0.0401
DEBUG - 2022-05-18 10:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:39:54 --> Total execution time: 0.0317
DEBUG - 2022-05-18 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:56 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:56 --> Total execution time: 0.0275
DEBUG - 2022-05-18 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:39:59 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:09:59 --> Total execution time: 0.0462
DEBUG - 2022-05-18 10:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:14 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:14 --> Total execution time: 0.0346
DEBUG - 2022-05-18 10:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:23 --> Total execution time: 0.0443
DEBUG - 2022-05-18 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:24 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:24 --> Total execution time: 0.0339
DEBUG - 2022-05-18 10:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:27 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:27 --> Total execution time: 0.0421
DEBUG - 2022-05-18 10:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:40:30 --> Total execution time: 0.0357
DEBUG - 2022-05-18 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:40:31 --> Total execution time: 0.0338
DEBUG - 2022-05-18 10:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:40:31 --> Total execution time: 0.0334
DEBUG - 2022-05-18 10:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:40:38 --> Total execution time: 0.0402
DEBUG - 2022-05-18 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:44 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:44 --> Total execution time: 0.0341
DEBUG - 2022-05-18 10:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:51 --> Total execution time: 0.0364
DEBUG - 2022-05-18 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:40:51 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:10:51 --> Total execution time: 0.0405
DEBUG - 2022-05-18 10:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:00 --> Total execution time: 0.0325
DEBUG - 2022-05-18 10:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:06 --> Total execution time: 0.0509
DEBUG - 2022-05-18 10:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:06 --> Total execution time: 0.0373
DEBUG - 2022-05-18 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:10 --> Total execution time: 0.0450
DEBUG - 2022-05-18 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:12 --> Total execution time: 0.0307
DEBUG - 2022-05-18 10:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:15 --> Total execution time: 0.0315
DEBUG - 2022-05-18 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:19 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:19 --> Total execution time: 0.0333
DEBUG - 2022-05-18 10:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:20 --> Total execution time: 0.0384
DEBUG - 2022-05-18 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:25 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:25 --> Total execution time: 0.0405
DEBUG - 2022-05-18 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:35 --> Total execution time: 0.0418
DEBUG - 2022-05-18 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:43 --> Total execution time: 0.0310
DEBUG - 2022-05-18 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:46 --> Total execution time: 0.0369
DEBUG - 2022-05-18 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:48 --> Total execution time: 0.0373
DEBUG - 2022-05-18 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:48 --> Total execution time: 0.0331
DEBUG - 2022-05-18 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:52 --> Total execution time: 0.0590
DEBUG - 2022-05-18 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:41:59 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:11:59 --> Total execution time: 0.0332
DEBUG - 2022-05-18 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:04 --> Total execution time: 0.0390
DEBUG - 2022-05-18 10:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:07 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:07 --> Total execution time: 0.0348
DEBUG - 2022-05-18 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:11 --> Total execution time: 0.0328
DEBUG - 2022-05-18 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:19 --> Total execution time: 0.0327
DEBUG - 2022-05-18 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:19 --> Total execution time: 0.0482
DEBUG - 2022-05-18 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:37 --> Total execution time: 0.0505
DEBUG - 2022-05-18 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:37 --> Total execution time: 0.0444
DEBUG - 2022-05-18 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:45 --> Total execution time: 0.0367
DEBUG - 2022-05-18 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:45 --> Total execution time: 0.0310
DEBUG - 2022-05-18 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:53 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:53 --> Total execution time: 0.0365
DEBUG - 2022-05-18 10:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:56 --> Total execution time: 0.0350
DEBUG - 2022-05-18 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:06 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:13:06 --> Total execution time: 0.0336
DEBUG - 2022-05-18 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:13:46 --> Total execution time: 0.0565
DEBUG - 2022-05-18 10:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:13:53 --> Total execution time: 0.0438
DEBUG - 2022-05-18 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:43:54 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:13:54 --> Total execution time: 0.0328
DEBUG - 2022-05-18 10:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:00 --> Total execution time: 0.0348
DEBUG - 2022-05-18 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:02 --> Total execution time: 0.0368
DEBUG - 2022-05-18 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:18 --> Total execution time: 0.0961
DEBUG - 2022-05-18 10:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:20 --> Total execution time: 0.0354
DEBUG - 2022-05-18 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:32 --> Total execution time: 0.0319
DEBUG - 2022-05-18 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:34 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:34 --> Total execution time: 0.0366
DEBUG - 2022-05-18 10:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:35 --> Total execution time: 0.0457
DEBUG - 2022-05-18 10:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:43 --> Total execution time: 0.0392
DEBUG - 2022-05-18 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:44 --> Total execution time: 0.0328
DEBUG - 2022-05-18 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:48 --> Total execution time: 0.0429
DEBUG - 2022-05-18 10:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:49 --> Total execution time: 0.0357
DEBUG - 2022-05-18 10:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:50 --> Total execution time: 0.0729
DEBUG - 2022-05-18 10:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:51 --> Total execution time: 0.0325
DEBUG - 2022-05-18 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:57 --> Total execution time: 0.0352
DEBUG - 2022-05-18 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:58 --> Total execution time: 0.0350
DEBUG - 2022-05-18 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:58 --> Total execution time: 0.0343
DEBUG - 2022-05-18 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:03 --> Total execution time: 0.0368
DEBUG - 2022-05-18 10:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:05 --> Total execution time: 0.0378
DEBUG - 2022-05-18 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:14 --> Total execution time: 0.0363
DEBUG - 2022-05-18 10:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:15 --> Total execution time: 0.0578
DEBUG - 2022-05-18 10:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:30 --> Total execution time: 0.0841
DEBUG - 2022-05-18 10:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:33 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:33 --> Total execution time: 0.0506
DEBUG - 2022-05-18 10:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:51 --> Total execution time: 0.0352
DEBUG - 2022-05-18 10:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:45:55 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:55 --> Total execution time: 0.0284
DEBUG - 2022-05-18 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:00 --> Total execution time: 0.0400
DEBUG - 2022-05-18 10:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:32 --> Total execution time: 0.0395
DEBUG - 2022-05-18 10:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:37 --> Total execution time: 0.0508
DEBUG - 2022-05-18 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:41 --> Total execution time: 0.0332
DEBUG - 2022-05-18 10:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:47 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:47 --> Total execution time: 0.0374
DEBUG - 2022-05-18 10:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:55 --> Total execution time: 0.0443
DEBUG - 2022-05-18 10:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:03 --> Total execution time: 0.0372
DEBUG - 2022-05-18 10:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:05 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:05 --> Total execution time: 0.0418
DEBUG - 2022-05-18 10:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:15 --> Total execution time: 0.0564
DEBUG - 2022-05-18 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:23 --> Total execution time: 0.0547
DEBUG - 2022-05-18 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:25 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:25 --> Total execution time: 0.0391
DEBUG - 2022-05-18 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:28 --> Total execution time: 0.0379
DEBUG - 2022-05-18 10:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:28 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:28 --> Total execution time: 0.0513
DEBUG - 2022-05-18 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:33 --> Total execution time: 0.0592
DEBUG - 2022-05-18 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:42 --> Total execution time: 0.0480
DEBUG - 2022-05-18 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:49 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:49 --> Total execution time: 0.0474
DEBUG - 2022-05-18 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:51 --> Total execution time: 0.0519
DEBUG - 2022-05-18 10:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:54 --> Total execution time: 0.0462
DEBUG - 2022-05-18 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:56 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:56 --> Total execution time: 0.0341
DEBUG - 2022-05-18 10:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:17:56 --> Total execution time: 0.0411
DEBUG - 2022-05-18 10:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:13 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:13 --> Total execution time: 0.0518
DEBUG - 2022-05-18 10:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:16 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:16 --> Total execution time: 0.0369
DEBUG - 2022-05-18 10:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:23 --> Total execution time: 0.0372
DEBUG - 2022-05-18 10:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:44 --> Total execution time: 0.0695
DEBUG - 2022-05-18 10:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:49 --> Total execution time: 0.0462
DEBUG - 2022-05-18 10:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:53 --> Total execution time: 0.0564
DEBUG - 2022-05-18 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:56 --> Total execution time: 0.0553
DEBUG - 2022-05-18 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:18:56 --> Total execution time: 0.0669
DEBUG - 2022-05-18 10:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:05 --> Total execution time: 0.0441
DEBUG - 2022-05-18 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:14 --> Total execution time: 0.0612
DEBUG - 2022-05-18 10:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:19 --> Total execution time: 0.0415
DEBUG - 2022-05-18 10:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:26 --> Total execution time: 0.0599
DEBUG - 2022-05-18 10:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:30 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:30 --> Total execution time: 0.0397
DEBUG - 2022-05-18 10:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:38 --> Total execution time: 0.0468
DEBUG - 2022-05-18 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:45 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:45 --> Total execution time: 0.0423
DEBUG - 2022-05-18 10:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:49 --> Total execution time: 0.0341
DEBUG - 2022-05-18 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:52 --> Total execution time: 0.0369
DEBUG - 2022-05-18 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:53 --> Total execution time: 0.0328
DEBUG - 2022-05-18 10:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:19:53 --> Total execution time: 0.0433
DEBUG - 2022-05-18 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:20:01 --> Total execution time: 0.0501
DEBUG - 2022-05-18 10:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:50:22 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:20:22 --> Total execution time: 0.0371
DEBUG - 2022-05-18 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:20:24 --> Total execution time: 0.0303
DEBUG - 2022-05-18 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:50:35 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:20:35 --> Total execution time: 0.0363
DEBUG - 2022-05-18 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:18 --> Total execution time: 0.0751
DEBUG - 2022-05-18 10:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:33 --> Total execution time: 0.0395
DEBUG - 2022-05-18 10:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:52:31 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:22:31 --> Total execution time: 0.0801
DEBUG - 2022-05-18 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:28 --> Total execution time: 0.0528
DEBUG - 2022-05-18 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:38 --> Total execution time: 0.2143
DEBUG - 2022-05-18 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:57 --> Total execution time: 0.5092
DEBUG - 2022-05-18 10:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:24:12 --> Total execution time: 0.0331
DEBUG - 2022-05-18 10:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:55:44 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:25:44 --> Total execution time: 0.0467
DEBUG - 2022-05-18 10:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:25:56 --> Total execution time: 0.0803
DEBUG - 2022-05-18 10:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:26:45 --> Total execution time: 0.0320
DEBUG - 2022-05-18 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:27:16 --> Total execution time: 0.0641
DEBUG - 2022-05-18 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:27:16 --> Total execution time: 0.0356
DEBUG - 2022-05-18 10:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:27:38 --> Total execution time: 0.0329
DEBUG - 2022-05-18 10:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:58:36 --> No URI present. Default controller set.
DEBUG - 2022-05-18 10:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:28:36 --> Total execution time: 0.0424
DEBUG - 2022-05-18 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:21 --> Total execution time: 0.0333
DEBUG - 2022-05-18 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:22 --> Total execution time: 0.0370
DEBUG - 2022-05-18 10:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:22 --> Total execution time: 0.0381
DEBUG - 2022-05-18 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:29:24 --> Total execution time: 0.0328
DEBUG - 2022-05-18 10:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:29:37 --> Total execution time: 0.0319
DEBUG - 2022-05-18 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 10:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:29:59 --> Total execution time: 0.0373
DEBUG - 2022-05-18 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:15 --> Total execution time: 0.0627
DEBUG - 2022-05-18 11:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:21 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:21 --> Total execution time: 0.0355
DEBUG - 2022-05-18 11:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:28 --> Total execution time: 0.0309
DEBUG - 2022-05-18 11:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:30 --> Total execution time: 0.0373
DEBUG - 2022-05-18 11:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:37 --> Total execution time: 0.0398
DEBUG - 2022-05-18 11:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:43 --> Total execution time: 0.0399
DEBUG - 2022-05-18 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:46 --> Total execution time: 0.0360
DEBUG - 2022-05-18 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:55 --> Total execution time: 0.0329
DEBUG - 2022-05-18 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:58 --> Total execution time: 0.0339
DEBUG - 2022-05-18 11:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:01 --> Total execution time: 0.0354
DEBUG - 2022-05-18 11:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:09 --> Total execution time: 0.0383
DEBUG - 2022-05-18 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:18 --> Total execution time: 0.0439
DEBUG - 2022-05-18 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:21 --> Total execution time: 0.0347
DEBUG - 2022-05-18 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:39 --> Total execution time: 0.0446
DEBUG - 2022-05-18 11:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:43 --> Total execution time: 0.0345
DEBUG - 2022-05-18 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:52 --> Total execution time: 0.0366
DEBUG - 2022-05-18 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:31:57 --> Total execution time: 0.0348
DEBUG - 2022-05-18 11:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:02:02 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:32:02 --> Total execution time: 0.0372
DEBUG - 2022-05-18 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:32:33 --> Total execution time: 0.0354
DEBUG - 2022-05-18 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:35:53 --> Total execution time: 0.0785
DEBUG - 2022-05-18 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:06:20 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:20 --> Total execution time: 0.0484
DEBUG - 2022-05-18 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:24 --> Total execution time: 0.0299
DEBUG - 2022-05-18 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:06:37 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:37 --> Total execution time: 0.0336
DEBUG - 2022-05-18 11:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:37:13 --> Total execution time: 0.9038
DEBUG - 2022-05-18 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:37:22 --> Total execution time: 0.5288
DEBUG - 2022-05-18 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:37:31 --> Total execution time: 0.2184
DEBUG - 2022-05-18 11:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:38:48 --> Total execution time: 0.0482
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:10:55 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:40:55 --> Total execution time: 0.0534
DEBUG - 2022-05-18 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:05 --> Total execution time: 0.0332
DEBUG - 2022-05-18 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:06 --> Total execution time: 0.0284
DEBUG - 2022-05-18 11:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:26 --> Total execution time: 0.0302
DEBUG - 2022-05-18 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:35 --> Total execution time: 0.0422
DEBUG - 2022-05-18 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:11:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-18 11:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:56 --> Total execution time: 0.0532
DEBUG - 2022-05-18 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:06 --> Total execution time: 0.0583
DEBUG - 2022-05-18 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:10 --> Total execution time: 0.0378
DEBUG - 2022-05-18 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:21 --> Total execution time: 0.0465
DEBUG - 2022-05-18 11:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:49 --> Total execution time: 0.0421
DEBUG - 2022-05-18 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:53 --> Total execution time: 0.0350
DEBUG - 2022-05-18 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:43:23 --> Total execution time: 0.0311
DEBUG - 2022-05-18 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:28 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:28 --> Total execution time: 0.0457
DEBUG - 2022-05-18 11:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:37 --> Total execution time: 0.0316
DEBUG - 2022-05-18 11:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:40 --> Total execution time: 0.0328
DEBUG - 2022-05-18 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:48 --> Total execution time: 0.0319
DEBUG - 2022-05-18 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:49 --> Total execution time: 0.0337
DEBUG - 2022-05-18 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:16:49 --> Total execution time: 0.0393
DEBUG - 2022-05-18 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:17:50 --> Total execution time: 0.0403
DEBUG - 2022-05-18 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:17:50 --> Total execution time: 0.0365
DEBUG - 2022-05-18 11:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:22:16 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:52:16 --> Total execution time: 0.0644
DEBUG - 2022-05-18 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:52:32 --> Total execution time: 0.0315
DEBUG - 2022-05-18 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:52:45 --> Total execution time: 0.0314
DEBUG - 2022-05-18 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:52:52 --> Total execution time: 0.0328
DEBUG - 2022-05-18 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:53:41 --> Total execution time: 0.0321
DEBUG - 2022-05-18 11:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:53:53 --> Total execution time: 0.0335
DEBUG - 2022-05-18 11:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:54:51 --> Total execution time: 0.0324
DEBUG - 2022-05-18 11:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:55:25 --> Total execution time: 0.0354
DEBUG - 2022-05-18 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:56:52 --> Total execution time: 0.0379
DEBUG - 2022-05-18 11:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:27:23 --> Total execution time: 0.0417
DEBUG - 2022-05-18 11:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:27:24 --> Total execution time: 0.0361
DEBUG - 2022-05-18 11:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:27:24 --> Total execution time: 0.0479
DEBUG - 2022-05-18 11:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:05 --> Total execution time: 0.0367
DEBUG - 2022-05-18 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:07 --> Total execution time: 0.0348
DEBUG - 2022-05-18 11:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:07 --> Total execution time: 0.0429
DEBUG - 2022-05-18 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:23 --> Total execution time: 0.0323
DEBUG - 2022-05-18 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:24 --> Total execution time: 0.0345
DEBUG - 2022-05-18 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:24 --> Total execution time: 0.0404
DEBUG - 2022-05-18 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:27 --> Total execution time: 0.0316
DEBUG - 2022-05-18 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:42 --> Total execution time: 0.0320
DEBUG - 2022-05-18 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:28:43 --> Total execution time: 0.0349
DEBUG - 2022-05-18 11:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:28:43 --> Total execution time: 0.0317
DEBUG - 2022-05-18 11:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:29:22 --> Total execution time: 0.0345
DEBUG - 2022-05-18 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:29:23 --> Total execution time: 0.0338
DEBUG - 2022-05-18 11:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:29:23 --> Total execution time: 0.0317
DEBUG - 2022-05-18 11:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:29 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:29 --> Total execution time: 0.0338
DEBUG - 2022-05-18 11:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:43 --> Total execution time: 1.5558
DEBUG - 2022-05-18 11:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:19 --> Total execution time: 0.0355
DEBUG - 2022-05-18 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:21 --> Total execution time: 0.0535
DEBUG - 2022-05-18 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:25 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:25 --> Total execution time: 0.0334
DEBUG - 2022-05-18 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:28 --> Total execution time: 0.0345
DEBUG - 2022-05-18 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:30 --> Total execution time: 0.0431
DEBUG - 2022-05-18 11:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:37 --> Total execution time: 0.0376
DEBUG - 2022-05-18 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:41 --> Total execution time: 0.0643
DEBUG - 2022-05-18 11:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:32:14 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:02:14 --> Total execution time: 0.0556
DEBUG - 2022-05-18 11:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:32:32 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:02:32 --> Total execution time: 0.0375
DEBUG - 2022-05-18 11:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:02:55 --> Total execution time: 0.0339
DEBUG - 2022-05-18 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:06 --> Total execution time: 0.0562
DEBUG - 2022-05-18 11:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:29 --> Total execution time: 0.0379
DEBUG - 2022-05-18 11:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:32 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:32 --> Total execution time: 0.0511
DEBUG - 2022-05-18 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:36 --> Total execution time: 0.0348
DEBUG - 2022-05-18 11:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:41 --> Total execution time: 0.0379
DEBUG - 2022-05-18 11:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:47 --> Total execution time: 0.0371
DEBUG - 2022-05-18 11:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:33:50 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:03:50 --> Total execution time: 0.0336
DEBUG - 2022-05-18 11:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:04:23 --> Total execution time: 0.0379
DEBUG - 2022-05-18 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:34:50 --> Total execution time: 0.0307
DEBUG - 2022-05-18 11:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:11 --> Total execution time: 0.0306
DEBUG - 2022-05-18 11:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:05:16 --> Total execution time: 0.0421
DEBUG - 2022-05-18 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:05:20 --> Total execution time: 0.0367
DEBUG - 2022-05-18 11:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:31 --> Total execution time: 0.0258
DEBUG - 2022-05-18 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:44 --> Total execution time: 0.0301
DEBUG - 2022-05-18 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:05:46 --> Total execution time: 0.0438
DEBUG - 2022-05-18 11:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:35:49 --> Total execution time: 0.0311
DEBUG - 2022-05-18 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:50 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:05:50 --> Total execution time: 0.0581
DEBUG - 2022-05-18 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:35:57 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:05:57 --> Total execution time: 0.0380
DEBUG - 2022-05-18 11:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:00 --> Total execution time: 0.0329
DEBUG - 2022-05-18 11:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:36:02 --> Total execution time: 0.0310
DEBUG - 2022-05-18 11:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:03 --> Total execution time: 0.0303
DEBUG - 2022-05-18 11:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:09 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:09 --> Total execution time: 0.0342
DEBUG - 2022-05-18 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:18 --> Total execution time: 0.0462
DEBUG - 2022-05-18 11:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:18 --> Total execution time: 0.0315
DEBUG - 2022-05-18 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:19 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:19 --> Total execution time: 0.0356
DEBUG - 2022-05-18 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:28 --> Total execution time: 0.0389
DEBUG - 2022-05-18 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:29 --> Total execution time: 0.0395
DEBUG - 2022-05-18 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:32 --> Total execution time: 0.0333
DEBUG - 2022-05-18 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:06:35 --> Total execution time: 0.0351
DEBUG - 2022-05-18 11:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:36:40 --> Total execution time: 0.0327
DEBUG - 2022-05-18 11:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:37:17 --> Total execution time: 0.0354
DEBUG - 2022-05-18 11:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:37:17 --> Total execution time: 0.0445
DEBUG - 2022-05-18 11:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:07:56 --> Total execution time: 0.0367
DEBUG - 2022-05-18 11:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:37:58 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:07:58 --> Total execution time: 0.0337
DEBUG - 2022-05-18 11:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:08:10 --> Total execution time: 1.5443
DEBUG - 2022-05-18 11:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:38:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:38:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-18 11:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:38:47 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:08:47 --> Total execution time: 0.0320
DEBUG - 2022-05-18 11:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:39:10 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:09:10 --> Total execution time: 0.0558
DEBUG - 2022-05-18 11:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:10:22 --> Total execution time: 0.0796
DEBUG - 2022-05-18 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:40:47 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:10:47 --> Total execution time: 0.0349
DEBUG - 2022-05-18 11:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:10:55 --> Total execution time: 0.0364
DEBUG - 2022-05-18 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:01 --> Total execution time: 0.0555
DEBUG - 2022-05-18 11:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:43 --> Total execution time: 0.0363
DEBUG - 2022-05-18 11:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:44 --> Total execution time: 0.0344
DEBUG - 2022-05-18 11:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:47 --> Total execution time: 0.0429
DEBUG - 2022-05-18 11:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:55 --> Total execution time: 0.0336
DEBUG - 2022-05-18 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:11:57 --> Total execution time: 0.0369
DEBUG - 2022-05-18 11:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:12:00 --> Total execution time: 0.0329
DEBUG - 2022-05-18 11:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:42:03 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:12:03 --> Total execution time: 0.0329
DEBUG - 2022-05-18 11:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:44:47 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:14:47 --> Total execution time: 0.0609
DEBUG - 2022-05-18 11:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:14:56 --> Total execution time: 0.0323
DEBUG - 2022-05-18 11:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:15:05 --> Total execution time: 0.0383
DEBUG - 2022-05-18 11:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:15:48 --> Total execution time: 0.0408
DEBUG - 2022-05-18 11:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:16:49 --> Total execution time: 0.0376
DEBUG - 2022-05-18 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:16:57 --> Total execution time: 0.0393
DEBUG - 2022-05-18 11:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:05 --> Total execution time: 0.0370
DEBUG - 2022-05-18 11:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:20 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:20 --> Total execution time: 0.0322
DEBUG - 2022-05-18 11:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:29 --> Total execution time: 0.0342
DEBUG - 2022-05-18 11:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:31 --> Total execution time: 0.0324
DEBUG - 2022-05-18 11:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:35 --> Total execution time: 0.0484
DEBUG - 2022-05-18 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:17:47 --> Total execution time: 0.0529
DEBUG - 2022-05-18 11:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:18:29 --> Total execution time: 0.0487
DEBUG - 2022-05-18 11:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:48:44 --> Total execution time: 0.0339
DEBUG - 2022-05-18 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:48:47 --> Total execution time: 0.0339
DEBUG - 2022-05-18 11:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:48:47 --> Total execution time: 0.0391
DEBUG - 2022-05-18 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:18:49 --> Total execution time: 0.0304
DEBUG - 2022-05-18 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:48:49 --> No URI present. Default controller set.
DEBUG - 2022-05-18 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:18:49 --> Total execution time: 0.0334
DEBUG - 2022-05-18 11:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:19:05 --> Total execution time: 0.0381
DEBUG - 2022-05-18 11:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:53:21 --> Total execution time: 0.0710
DEBUG - 2022-05-18 11:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:53:23 --> Total execution time: 0.0354
DEBUG - 2022-05-18 11:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:53:23 --> Total execution time: 0.0327
DEBUG - 2022-05-18 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:17 --> Total execution time: 0.0374
DEBUG - 2022-05-18 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:19 --> Total execution time: 0.0343
DEBUG - 2022-05-18 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:19 --> Total execution time: 0.0347
DEBUG - 2022-05-18 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:56 --> Total execution time: 0.0414
DEBUG - 2022-05-18 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:57 --> Total execution time: 0.0402
DEBUG - 2022-05-18 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:54:57 --> Total execution time: 0.0486
DEBUG - 2022-05-18 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:24:59 --> Total execution time: 0.0522
DEBUG - 2022-05-18 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:25:08 --> Total execution time: 0.0275
DEBUG - 2022-05-18 11:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:25:48 --> Total execution time: 0.0373
DEBUG - 2022-05-18 11:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:26:16 --> Total execution time: 0.0364
DEBUG - 2022-05-18 11:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:26:22 --> Total execution time: 0.0393
DEBUG - 2022-05-18 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:26:49 --> Total execution time: 0.0319
DEBUG - 2022-05-18 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:58:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 11:58:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-18 11:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 11:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 11:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:30:09 --> Total execution time: 41.4266
DEBUG - 2022-05-18 12:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:00:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-18 22:30:28 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 62
ERROR - 2022-05-18 22:30:28 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 64
ERROR - 2022-05-18 22:30:28 --> Severity: Notice --> Trying to get property 'wallet_amount' of non-object /home3/esalesei/new1.esalestrix.in/application/helpers/project_helper.php 174
ERROR - 2022-05-18 22:30:28 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 46
ERROR - 2022-05-18 22:30:28 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 47
DEBUG - 2022-05-18 22:30:28 --> Total execution time: 0.0554
DEBUG - 2022-05-18 12:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:00:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-18 22:30:51 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 62
ERROR - 2022-05-18 22:30:51 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 64
ERROR - 2022-05-18 22:30:51 --> Severity: Notice --> Trying to get property 'wallet_amount' of non-object /home3/esalesei/new1.esalestrix.in/application/helpers/project_helper.php 174
ERROR - 2022-05-18 22:30:51 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 46
ERROR - 2022-05-18 22:30:51 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 47
DEBUG - 2022-05-18 22:30:51 --> Total execution time: 8.3046
DEBUG - 2022-05-18 12:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:00:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-18 22:30:56 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 62
ERROR - 2022-05-18 22:30:56 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/inc/header.php 64
ERROR - 2022-05-18 22:30:56 --> Severity: Notice --> Trying to get property 'wallet_amount' of non-object /home3/esalesei/new1.esalestrix.in/application/helpers/project_helper.php 174
ERROR - 2022-05-18 22:30:56 --> Severity: Notice --> Trying to get property 'ul_thumbnail' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 46
ERROR - 2022-05-18 22:30:56 --> Severity: Notice --> Trying to get property 'ul_name' of non-object /home3/esalesei/new1.esalestrix.in/application/views/User/affiliate-account.php 47
DEBUG - 2022-05-18 22:30:56 --> Total execution time: 0.0549
DEBUG - 2022-05-18 12:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:31:46 --> Total execution time: 0.0587
DEBUG - 2022-05-18 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:31:56 --> Total execution time: 3.1490
DEBUG - 2022-05-18 12:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:32:29 --> Total execution time: 0.0352
DEBUG - 2022-05-18 12:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:32:32 --> Total execution time: 0.0407
DEBUG - 2022-05-18 12:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:32:36 --> Total execution time: 0.0400
DEBUG - 2022-05-18 12:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:33:22 --> Total execution time: 0.0354
DEBUG - 2022-05-18 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:33:30 --> Total execution time: 0.0449
DEBUG - 2022-05-18 12:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:33:33 --> Total execution time: 0.0469
DEBUG - 2022-05-18 12:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:33:39 --> Total execution time: 0.2250
DEBUG - 2022-05-18 12:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:10:15 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:40:15 --> Total execution time: 0.1137
DEBUG - 2022-05-18 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:40:25 --> Total execution time: 0.0116
DEBUG - 2022-05-18 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:41:00 --> Total execution time: 0.0224
DEBUG - 2022-05-18 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:41:09 --> Total execution time: 0.0239
DEBUG - 2022-05-18 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:00 --> Total execution time: 0.0170
DEBUG - 2022-05-18 12:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:21 --> Total execution time: 0.0199
DEBUG - 2022-05-18 12:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:33 --> Total execution time: 0.0235
DEBUG - 2022-05-18 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:45 --> Total execution time: 0.0156
DEBUG - 2022-05-18 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:49 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:49 --> Total execution time: 0.0235
DEBUG - 2022-05-18 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:52 --> Total execution time: 0.0173
DEBUG - 2022-05-18 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:52 --> Total execution time: 0.0169
DEBUG - 2022-05-18 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:53 --> Total execution time: 0.0146
DEBUG - 2022-05-18 12:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:42:57 --> Total execution time: 0.0313
DEBUG - 2022-05-18 12:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:02 --> Total execution time: 0.0241
DEBUG - 2022-05-18 12:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:13:10 --> Total execution time: 0.0164
DEBUG - 2022-05-18 12:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:12 --> Total execution time: 0.0213
DEBUG - 2022-05-18 12:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:15 --> Total execution time: 0.0275
DEBUG - 2022-05-18 12:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:16 --> Total execution time: 0.0150
DEBUG - 2022-05-18 12:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:18 --> Total execution time: 0.0209
DEBUG - 2022-05-18 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:34 --> Total execution time: 0.0220
DEBUG - 2022-05-18 12:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-18 12:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:51 --> Total execution time: 0.0337
DEBUG - 2022-05-18 12:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:43:57 --> Total execution time: 0.0164
DEBUG - 2022-05-18 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:02 --> Total execution time: 0.0171
DEBUG - 2022-05-18 12:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:04 --> Total execution time: 0.0333
DEBUG - 2022-05-18 12:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:05 --> Total execution time: 0.0142
DEBUG - 2022-05-18 12:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:07 --> Total execution time: 0.0147
DEBUG - 2022-05-18 12:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:09 --> Total execution time: 0.0386
DEBUG - 2022-05-18 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:22 --> Total execution time: 0.0204
DEBUG - 2022-05-18 12:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:44:23 --> Total execution time: 0.0213
DEBUG - 2022-05-18 12:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:16:35 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:46:35 --> Total execution time: 0.0794
DEBUG - 2022-05-18 12:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:16:46 --> Total execution time: 0.0140
DEBUG - 2022-05-18 12:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:47:11 --> Total execution time: 0.0171
DEBUG - 2022-05-18 12:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:47:32 --> Total execution time: 3.1946
DEBUG - 2022-05-18 12:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:50:06 --> Total execution time: 0.1135
DEBUG - 2022-05-18 12:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:50:15 --> Total execution time: 0.0338
DEBUG - 2022-05-18 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:51:10 --> Total execution time: 0.0369
DEBUG - 2022-05-18 12:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:51:15 --> Total execution time: 0.0744
DEBUG - 2022-05-18 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:52:02 --> Total execution time: 0.0900
DEBUG - 2022-05-18 12:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:52:32 --> Total execution time: 0.0462
DEBUG - 2022-05-18 12:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:52:40 --> Total execution time: 0.0169
DEBUG - 2022-05-18 12:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:52:44 --> Total execution time: 0.0287
DEBUG - 2022-05-18 12:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:54:10 --> Total execution time: 0.9062
DEBUG - 2022-05-18 12:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:55:23 --> Total execution time: 0.0167
DEBUG - 2022-05-18 12:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:55:38 --> Total execution time: 0.0175
DEBUG - 2022-05-18 12:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:55:45 --> Total execution time: 0.0260
DEBUG - 2022-05-18 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:55:52 --> Total execution time: 0.7281
DEBUG - 2022-05-18 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:03 --> Total execution time: 0.0138
DEBUG - 2022-05-18 12:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:08 --> Total execution time: 0.0143
DEBUG - 2022-05-18 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:13 --> Total execution time: 0.0279
DEBUG - 2022-05-18 12:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:29 --> Total execution time: 0.2399
DEBUG - 2022-05-18 12:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:39 --> Total execution time: 0.0216
DEBUG - 2022-05-18 12:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:43 --> Total execution time: 0.0242
DEBUG - 2022-05-18 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:56:50 --> Total execution time: 0.1652
DEBUG - 2022-05-18 12:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:06:45 --> Total execution time: 0.0879
DEBUG - 2022-05-18 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:40:55 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:10:55 --> Total execution time: 0.0458
DEBUG - 2022-05-18 12:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:11:01 --> Total execution time: 0.0131
DEBUG - 2022-05-18 12:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:11:19 --> Total execution time: 0.0175
DEBUG - 2022-05-18 12:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:11:30 --> Total execution time: 0.0236
DEBUG - 2022-05-18 12:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:42:23 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:12:23 --> Total execution time: 0.0192
DEBUG - 2022-05-18 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:42:43 --> No URI present. Default controller set.
DEBUG - 2022-05-18 12:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:12:43 --> Total execution time: 0.0369
DEBUG - 2022-05-18 12:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:14:09 --> Total execution time: 0.0150
DEBUG - 2022-05-18 12:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 12:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:14:21 --> Total execution time: 0.0148
DEBUG - 2022-05-18 12:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:14:32 --> Total execution time: 0.0253
DEBUG - 2022-05-18 12:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:14:42 --> Total execution time: 0.0145
DEBUG - 2022-05-18 12:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:07 --> Total execution time: 0.0246
DEBUG - 2022-05-18 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:08 --> Total execution time: 0.0224
DEBUG - 2022-05-18 12:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:21 --> Total execution time: 0.0148
DEBUG - 2022-05-18 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:28 --> Total execution time: 0.0152
DEBUG - 2022-05-18 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:16:27 --> Total execution time: 0.0134
DEBUG - 2022-05-18 12:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:18:38 --> Total execution time: 0.0375
DEBUG - 2022-05-18 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:19:33 --> Total execution time: 0.0167
DEBUG - 2022-05-18 12:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:25:43 --> Total execution time: 0.2303
DEBUG - 2022-05-18 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:25:49 --> Total execution time: 0.1770
DEBUG - 2022-05-18 12:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:27:14 --> Total execution time: 0.1897
DEBUG - 2022-05-18 12:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 12:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 12:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:27:19 --> Total execution time: 0.0234
DEBUG - 2022-05-18 13:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:19:46 --> No URI present. Default controller set.
DEBUG - 2022-05-18 13:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:49:46 --> Total execution time: 0.1476
DEBUG - 2022-05-18 13:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:19:53 --> Total execution time: 0.0149
DEBUG - 2022-05-18 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:19:54 --> Total execution time: 0.0307
DEBUG - 2022-05-18 13:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:19:54 --> Total execution time: 0.0365
DEBUG - 2022-05-18 13:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:50:00 --> Total execution time: 0.0177
DEBUG - 2022-05-18 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:50:34 --> Total execution time: 0.0125
DEBUG - 2022-05-18 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:51:03 --> Total execution time: 0.0124
DEBUG - 2022-05-18 13:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:51:58 --> Total execution time: 0.0128
DEBUG - 2022-05-18 13:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:22:43 --> No URI present. Default controller set.
DEBUG - 2022-05-18 13:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:52:43 --> Total execution time: 0.0170
DEBUG - 2022-05-18 13:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:53:07 --> Total execution time: 0.0187
DEBUG - 2022-05-18 13:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:53:52 --> Total execution time: 0.0129
DEBUG - 2022-05-18 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:55:29 --> Total execution time: 0.0124
DEBUG - 2022-05-18 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:25:39 --> No URI present. Default controller set.
DEBUG - 2022-05-18 13:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:55:39 --> Total execution time: 0.0200
DEBUG - 2022-05-18 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:32:22 --> No URI present. Default controller set.
DEBUG - 2022-05-18 13:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 13:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 13:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 13:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 14:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 14:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 14:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:03:55 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:19 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:08:49 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:28 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:10:49 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:00 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:13:23 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:44:01 --> No URI present. Default controller set.
DEBUG - 2022-05-18 15:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 15:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 15:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 15:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-18 15:44:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-18 20:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:20:58 --> No URI present. Default controller set.
DEBUG - 2022-05-18 20:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:23:09 --> No URI present. Default controller set.
DEBUG - 2022-05-18 20:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 20:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 20:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 20:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:20:37 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:23:42 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:27:18 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:41:40 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:42:42 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:44:41 --> No URI present. Default controller set.
DEBUG - 2022-05-18 21:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 21:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 21:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:14 --> No URI present. Default controller set.
DEBUG - 2022-05-18 22:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:49:44 --> No URI present. Default controller set.
DEBUG - 2022-05-18 22:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 22:50:31 --> No URI present. Default controller set.
DEBUG - 2022-05-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 22:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:14:15 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:30:23 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:34:45 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:39:53 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:44:39 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:44:39 --> No URI present. Default controller set.
DEBUG - 2022-05-18 23:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:18 --> Total execution time: 0.0413
DEBUG - 2022-05-18 23:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:34 --> Total execution time: 0.0363
DEBUG - 2022-05-18 23:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:42 --> Total execution time: 0.0413
DEBUG - 2022-05-18 23:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:42 --> Total execution time: 0.0339
DEBUG - 2022-05-18 23:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:47:52 --> Total execution time: 0.0321
DEBUG - 2022-05-18 23:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-18 23:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-18 23:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-18 23:52:58 --> Encryption: Auto-configured driver 'openssl'.
