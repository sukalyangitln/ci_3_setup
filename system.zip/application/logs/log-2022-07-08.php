<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-08 00:02:28 --> Total execution time: 0.1231
DEBUG - 2022-07-08 00:02:30 --> Total execution time: 0.1641
DEBUG - 2022-07-08 00:03:06 --> Total execution time: 0.1328
DEBUG - 2022-07-08 00:03:35 --> Total execution time: 0.0563
DEBUG - 2022-07-08 00:04:16 --> Total execution time: 0.0721
DEBUG - 2022-07-08 00:16:36 --> Total execution time: 0.1842
DEBUG - 2022-07-08 00:16:56 --> Total execution time: 0.0540
DEBUG - 2022-07-08 00:16:56 --> Total execution time: 0.1144
DEBUG - 2022-07-08 00:16:56 --> Total execution time: 0.0760
DEBUG - 2022-07-08 00:18:31 --> Total execution time: 0.0698
DEBUG - 2022-07-08 00:18:40 --> Total execution time: 0.0543
DEBUG - 2022-07-08 00:18:48 --> Total execution time: 0.0704
DEBUG - 2022-07-08 00:18:53 --> Total execution time: 0.0641
DEBUG - 2022-07-08 00:19:00 --> Total execution time: 0.0490
DEBUG - 2022-07-08 00:19:12 --> Total execution time: 0.0515
DEBUG - 2022-07-08 00:19:42 --> Total execution time: 0.0569
DEBUG - 2022-07-08 00:19:49 --> Total execution time: 0.0599
DEBUG - 2022-07-08 00:19:56 --> Total execution time: 0.0672
DEBUG - 2022-07-08 00:19:59 --> Total execution time: 0.0969
DEBUG - 2022-07-08 00:20:00 --> Total execution time: 0.0544
DEBUG - 2022-07-08 00:20:05 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:20:17 --> Total execution time: 0.0491
DEBUG - 2022-07-08 00:20:19 --> Total execution time: 0.0691
DEBUG - 2022-07-08 00:20:27 --> Total execution time: 0.0932
DEBUG - 2022-07-08 00:20:30 --> Total execution time: 0.0590
DEBUG - 2022-07-08 00:20:33 --> Total execution time: 0.0520
DEBUG - 2022-07-08 00:20:55 --> Total execution time: 0.0512
DEBUG - 2022-07-08 00:21:17 --> Total execution time: 0.0708
DEBUG - 2022-07-08 00:21:24 --> Total execution time: 0.0479
DEBUG - 2022-07-08 00:22:22 --> Total execution time: 0.0526
DEBUG - 2022-07-08 00:22:59 --> Total execution time: 0.0563
DEBUG - 2022-07-08 00:23:29 --> Total execution time: 0.0503
DEBUG - 2022-07-08 00:23:48 --> Total execution time: 0.1434
DEBUG - 2022-07-08 00:23:58 --> Total execution time: 0.0689
DEBUG - 2022-07-08 00:24:04 --> Total execution time: 0.0772
DEBUG - 2022-07-08 00:24:34 --> Total execution time: 0.0716
DEBUG - 2022-07-08 00:24:41 --> Total execution time: 0.0621
DEBUG - 2022-07-08 00:24:49 --> Total execution time: 0.0714
DEBUG - 2022-07-08 00:24:53 --> Total execution time: 0.0778
DEBUG - 2022-07-08 00:24:56 --> Total execution time: 0.0614
DEBUG - 2022-07-08 00:24:59 --> Total execution time: 0.0814
DEBUG - 2022-07-08 00:25:04 --> Total execution time: 0.0724
DEBUG - 2022-07-08 00:25:10 --> Total execution time: 0.1613
DEBUG - 2022-07-08 00:25:23 --> Total execution time: 0.0731
DEBUG - 2022-07-08 00:25:26 --> Total execution time: 0.0525
DEBUG - 2022-07-08 00:25:30 --> Total execution time: 0.0535
DEBUG - 2022-07-08 00:25:30 --> Total execution time: 0.0592
DEBUG - 2022-07-08 00:25:34 --> Total execution time: 0.0550
DEBUG - 2022-07-08 00:25:35 --> Total execution time: 0.0544
DEBUG - 2022-07-08 00:25:37 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:25:44 --> Total execution time: 0.0482
DEBUG - 2022-07-08 00:25:45 --> Total execution time: 0.0528
DEBUG - 2022-07-08 00:25:48 --> Total execution time: 0.0651
DEBUG - 2022-07-08 00:25:49 --> Total execution time: 0.0486
DEBUG - 2022-07-08 00:25:54 --> Total execution time: 0.0611
DEBUG - 2022-07-08 00:25:55 --> Total execution time: 0.0487
DEBUG - 2022-07-08 00:25:57 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:26:01 --> Total execution time: 0.0983
DEBUG - 2022-07-08 00:26:14 --> Total execution time: 0.0488
DEBUG - 2022-07-08 00:27:27 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:28:15 --> Total execution time: 0.1562
DEBUG - 2022-07-08 00:28:53 --> Total execution time: 0.0743
DEBUG - 2022-07-08 00:29:05 --> Total execution time: 0.0494
DEBUG - 2022-07-08 00:29:07 --> Total execution time: 0.0483
DEBUG - 2022-07-08 00:29:09 --> Total execution time: 0.0866
DEBUG - 2022-07-08 00:29:18 --> Total execution time: 0.0524
DEBUG - 2022-07-08 00:29:20 --> Total execution time: 0.0423
DEBUG - 2022-07-08 00:29:47 --> Total execution time: 0.0712
DEBUG - 2022-07-08 00:29:56 --> Total execution time: 0.0657
DEBUG - 2022-07-08 00:30:02 --> Total execution time: 0.3018
DEBUG - 2022-07-08 00:30:14 --> Total execution time: 0.0846
DEBUG - 2022-07-08 00:30:24 --> Total execution time: 0.0967
DEBUG - 2022-07-08 00:31:14 --> Total execution time: 0.0500
DEBUG - 2022-07-08 00:32:10 --> Total execution time: 0.0530
DEBUG - 2022-07-08 00:32:42 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:32:50 --> Total execution time: 0.0668
DEBUG - 2022-07-08 00:32:59 --> Total execution time: 0.0577
DEBUG - 2022-07-08 00:33:22 --> Total execution time: 0.1235
DEBUG - 2022-07-08 00:33:36 --> Total execution time: 0.1248
DEBUG - 2022-07-08 00:33:36 --> Total execution time: 0.0554
DEBUG - 2022-07-08 00:34:53 --> Total execution time: 0.0546
DEBUG - 2022-07-08 00:35:04 --> Total execution time: 0.0787
DEBUG - 2022-07-08 00:35:26 --> Total execution time: 0.0707
DEBUG - 2022-07-08 00:38:23 --> Total execution time: 0.0696
DEBUG - 2022-07-08 00:38:33 --> Total execution time: 0.0689
DEBUG - 2022-07-08 00:38:38 --> Total execution time: 0.0576
DEBUG - 2022-07-08 00:38:41 --> Total execution time: 0.0540
DEBUG - 2022-07-08 00:38:43 --> Total execution time: 0.0508
DEBUG - 2022-07-08 00:44:40 --> Total execution time: 0.1073
DEBUG - 2022-07-08 00:44:45 --> Total execution time: 0.0606
DEBUG - 2022-07-08 00:46:10 --> Total execution time: 0.0546
DEBUG - 2022-07-08 00:46:52 --> Total execution time: 0.0433
DEBUG - 2022-07-08 01:01:02 --> Total execution time: 0.1224
DEBUG - 2022-07-08 01:01:35 --> Total execution time: 0.0433
DEBUG - 2022-07-08 01:01:43 --> Total execution time: 0.0503
DEBUG - 2022-07-08 01:01:48 --> Total execution time: 0.0617
DEBUG - 2022-07-08 01:01:56 --> Total execution time: 0.0611
DEBUG - 2022-07-08 01:02:03 --> Total execution time: 0.0819
DEBUG - 2022-07-08 01:02:17 --> Total execution time: 0.0535
DEBUG - 2022-07-08 01:02:52 --> Total execution time: 0.0547
DEBUG - 2022-07-08 01:03:14 --> Total execution time: 0.0580
DEBUG - 2022-07-08 01:03:35 --> Total execution time: 0.0510
DEBUG - 2022-07-08 01:03:42 --> Total execution time: 0.0534
DEBUG - 2022-07-08 01:03:50 --> Total execution time: 0.0529
DEBUG - 2022-07-08 01:05:00 --> Total execution time: 0.1266
DEBUG - 2022-07-08 01:12:58 --> Total execution time: 0.1139
DEBUG - 2022-07-08 01:15:15 --> Total execution time: 0.1475
DEBUG - 2022-07-08 01:15:26 --> Total execution time: 0.0588
DEBUG - 2022-07-08 01:15:33 --> Total execution time: 0.0788
DEBUG - 2022-07-08 01:15:38 --> Total execution time: 0.0596
DEBUG - 2022-07-08 01:15:57 --> Total execution time: 0.0573
DEBUG - 2022-07-08 01:15:59 --> Total execution time: 0.0814
DEBUG - 2022-07-08 01:16:05 --> Total execution time: 0.0778
DEBUG - 2022-07-08 01:30:02 --> Total execution time: 0.1416
DEBUG - 2022-07-08 01:36:43 --> Total execution time: 0.0970
DEBUG - 2022-07-08 01:44:31 --> Total execution time: 0.0527
DEBUG - 2022-07-08 01:44:42 --> Total execution time: 0.0662
DEBUG - 2022-07-08 01:44:45 --> Total execution time: 0.0825
DEBUG - 2022-07-08 01:45:00 --> Total execution time: 0.0760
DEBUG - 2022-07-08 01:45:15 --> Total execution time: 0.0519
DEBUG - 2022-07-08 01:46:09 --> Total execution time: 0.1495
DEBUG - 2022-07-08 01:47:23 --> Total execution time: 0.0386
DEBUG - 2022-07-08 01:54:34 --> Total execution time: 0.1025
DEBUG - 2022-07-08 02:01:58 --> Total execution time: 0.0915
DEBUG - 2022-07-08 02:25:54 --> Total execution time: 0.1750
DEBUG - 2022-07-08 02:25:55 --> Total execution time: 0.0297
DEBUG - 2022-07-08 02:25:56 --> Total execution time: 0.0296
DEBUG - 2022-07-08 02:28:04 --> Total execution time: 0.0865
DEBUG - 2022-07-08 02:30:02 --> Total execution time: 0.0688
DEBUG - 2022-07-08 02:39:38 --> Total execution time: 0.0450
DEBUG - 2022-07-08 02:39:40 --> Total execution time: 0.0374
DEBUG - 2022-07-08 02:39:46 --> Total execution time: 0.0384
DEBUG - 2022-07-08 02:39:49 --> Total execution time: 0.0334
DEBUG - 2022-07-08 02:39:50 --> Total execution time: 0.0323
DEBUG - 2022-07-08 02:39:50 --> Total execution time: 0.0353
DEBUG - 2022-07-08 02:40:58 --> Total execution time: 0.0917
DEBUG - 2022-07-08 02:41:03 --> Total execution time: 0.0372
DEBUG - 2022-07-08 02:41:17 --> Total execution time: 0.0948
DEBUG - 2022-07-08 02:41:20 --> Total execution time: 0.0492
DEBUG - 2022-07-08 02:41:30 --> Total execution time: 0.0641
DEBUG - 2022-07-08 02:41:33 --> Total execution time: 0.0334
DEBUG - 2022-07-08 02:41:33 --> Total execution time: 0.0608
DEBUG - 2022-07-08 02:41:35 --> Total execution time: 0.0347
DEBUG - 2022-07-08 02:41:48 --> Total execution time: 0.0511
DEBUG - 2022-07-08 02:50:07 --> Total execution time: 0.1143
DEBUG - 2022-07-08 03:26:44 --> Total execution time: 0.1689
DEBUG - 2022-07-08 03:26:51 --> Total execution time: 0.0373
DEBUG - 2022-07-08 03:27:30 --> Total execution time: 0.0402
DEBUG - 2022-07-08 03:30:04 --> Total execution time: 0.1419
DEBUG - 2022-07-08 03:30:27 --> Total execution time: 0.0491
DEBUG - 2022-07-08 03:33:59 --> Total execution time: 0.0994
DEBUG - 2022-07-08 03:35:29 --> Total execution time: 0.0419
DEBUG - 2022-07-08 03:38:20 --> Total execution time: 0.0415
DEBUG - 2022-07-08 03:58:02 --> Total execution time: 0.2118
DEBUG - 2022-07-08 04:15:31 --> Total execution time: 0.1359
DEBUG - 2022-07-08 04:30:03 --> Total execution time: 0.2403
DEBUG - 2022-07-08 05:05:31 --> Total execution time: 0.0972
DEBUG - 2022-07-08 05:05:33 --> Total execution time: 0.0475
DEBUG - 2022-07-08 05:05:34 --> Total execution time: 0.0434
DEBUG - 2022-07-08 05:17:47 --> Total execution time: 0.1027
DEBUG - 2022-07-08 05:20:45 --> Total execution time: 0.0463
DEBUG - 2022-07-08 05:23:19 --> Total execution time: 0.0991
DEBUG - 2022-07-08 05:30:02 --> Total execution time: 0.1059
DEBUG - 2022-07-08 05:42:42 --> Total execution time: 0.0924
DEBUG - 2022-07-08 06:02:06 --> Total execution time: 0.1208
DEBUG - 2022-07-08 06:07:38 --> Total execution time: 0.0982
DEBUG - 2022-07-08 06:21:56 --> Total execution time: 0.1194
DEBUG - 2022-07-08 06:30:03 --> Total execution time: 0.1255
DEBUG - 2022-07-08 06:35:22 --> Total execution time: 0.0538
DEBUG - 2022-07-08 06:35:34 --> Total execution time: 0.0922
DEBUG - 2022-07-08 06:35:42 --> Total execution time: 0.0742
DEBUG - 2022-07-08 06:36:23 --> Total execution time: 0.0623
DEBUG - 2022-07-08 06:36:39 --> Total execution time: 0.0555
DEBUG - 2022-07-08 06:44:10 --> Total execution time: 0.1819
DEBUG - 2022-07-08 06:44:19 --> Total execution time: 0.1246
DEBUG - 2022-07-08 06:44:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 06:45:00 --> Total execution time: 0.0871
DEBUG - 2022-07-08 06:45:15 --> Total execution time: 0.0857
DEBUG - 2022-07-08 06:45:19 --> Total execution time: 0.0790
DEBUG - 2022-07-08 06:45:28 --> Total execution time: 0.1161
DEBUG - 2022-07-08 06:46:02 --> Total execution time: 0.0686
DEBUG - 2022-07-08 06:46:14 --> Total execution time: 0.0579
DEBUG - 2022-07-08 06:46:27 --> Total execution time: 0.0824
DEBUG - 2022-07-08 06:46:38 --> Total execution time: 0.1306
DEBUG - 2022-07-08 06:49:21 --> Total execution time: 0.0958
DEBUG - 2022-07-08 06:51:04 --> Total execution time: 0.0363
DEBUG - 2022-07-08 06:51:53 --> Total execution time: 0.0514
DEBUG - 2022-07-08 06:52:12 --> Total execution time: 0.0837
DEBUG - 2022-07-08 06:52:14 --> Total execution time: 0.0665
DEBUG - 2022-07-08 06:52:14 --> Total execution time: 0.0794
DEBUG - 2022-07-08 06:52:16 --> Total execution time: 0.0628
DEBUG - 2022-07-08 06:52:27 --> Total execution time: 0.0712
DEBUG - 2022-07-08 06:52:34 --> Total execution time: 0.0592
DEBUG - 2022-07-08 06:57:26 --> Total execution time: 0.2410
DEBUG - 2022-07-08 06:57:34 --> Total execution time: 0.0578
DEBUG - 2022-07-08 06:57:42 --> Total execution time: 0.0471
DEBUG - 2022-07-08 06:57:48 --> Total execution time: 0.0521
DEBUG - 2022-07-08 06:58:01 --> Total execution time: 0.0551
DEBUG - 2022-07-08 06:58:59 --> Total execution time: 0.0553
DEBUG - 2022-07-08 06:59:30 --> Total execution time: 0.0562
DEBUG - 2022-07-08 06:59:34 --> Total execution time: 0.0749
DEBUG - 2022-07-08 06:59:40 --> Total execution time: 0.0588
DEBUG - 2022-07-08 06:59:44 --> Total execution time: 0.0562
DEBUG - 2022-07-08 06:59:47 --> Total execution time: 0.0569
DEBUG - 2022-07-08 07:05:39 --> Total execution time: 0.2226
DEBUG - 2022-07-08 07:08:42 --> Total execution time: 0.0394
DEBUG - 2022-07-08 07:08:59 --> Total execution time: 0.0473
DEBUG - 2022-07-08 07:11:25 --> Total execution time: 0.0412
DEBUG - 2022-07-08 07:13:25 --> Total execution time: 0.0535
DEBUG - 2022-07-08 07:18:50 --> Total execution time: 0.1219
DEBUG - 2022-07-08 07:24:54 --> Total execution time: 0.1114
DEBUG - 2022-07-08 07:30:07 --> Total execution time: 0.1670
DEBUG - 2022-07-08 07:34:59 --> Total execution time: 0.0974
DEBUG - 2022-07-08 07:36:07 --> Total execution time: 0.0566
DEBUG - 2022-07-08 07:36:10 --> Total execution time: 0.1479
DEBUG - 2022-07-08 07:36:14 --> Total execution time: 0.0576
DEBUG - 2022-07-08 07:36:24 --> Total execution time: 0.0518
DEBUG - 2022-07-08 07:40:38 --> Total execution time: 0.0544
DEBUG - 2022-07-08 07:46:00 --> Total execution time: 0.1965
DEBUG - 2022-07-08 07:46:04 --> Total execution time: 0.0794
DEBUG - 2022-07-08 07:46:19 --> Total execution time: 0.0651
DEBUG - 2022-07-08 07:47:00 --> Total execution time: 0.0627
DEBUG - 2022-07-08 08:08:36 --> Total execution time: 0.0550
DEBUG - 2022-07-08 08:16:40 --> Total execution time: 0.0744
DEBUG - 2022-07-08 08:16:49 --> Total execution time: 0.0815
DEBUG - 2022-07-08 08:16:59 --> Total execution time: 0.0696
DEBUG - 2022-07-08 08:17:02 --> Total execution time: 0.0745
DEBUG - 2022-07-08 08:17:16 --> Total execution time: 0.0748
DEBUG - 2022-07-08 08:23:36 --> Total execution time: 0.1344
DEBUG - 2022-07-08 08:23:40 --> Total execution time: 0.0762
DEBUG - 2022-07-08 08:23:57 --> Total execution time: 0.0611
DEBUG - 2022-07-08 08:24:05 --> Total execution time: 0.0577
DEBUG - 2022-07-08 08:24:15 --> Total execution time: 0.0554
DEBUG - 2022-07-08 08:28:00 --> Total execution time: 0.1056
DEBUG - 2022-07-08 08:28:06 --> Total execution time: 0.0353
DEBUG - 2022-07-08 08:28:15 --> Total execution time: 0.0594
DEBUG - 2022-07-08 08:28:24 --> Total execution time: 0.0767
DEBUG - 2022-07-08 08:28:32 --> Total execution time: 0.0980
DEBUG - 2022-07-08 08:28:35 --> Total execution time: 0.0637
DEBUG - 2022-07-08 08:28:40 --> Total execution time: 0.0491
DEBUG - 2022-07-08 08:28:43 --> Total execution time: 0.0526
DEBUG - 2022-07-08 08:28:49 --> Total execution time: 0.0528
DEBUG - 2022-07-08 08:28:51 --> Total execution time: 0.0572
DEBUG - 2022-07-08 08:28:56 --> Total execution time: 0.0621
DEBUG - 2022-07-08 08:29:01 --> Total execution time: 0.0659
DEBUG - 2022-07-08 08:29:29 --> Total execution time: 0.1230
DEBUG - 2022-07-08 08:29:38 --> Total execution time: 0.0462
DEBUG - 2022-07-08 08:30:02 --> Total execution time: 0.1075
DEBUG - 2022-07-08 08:30:40 --> Total execution time: 0.0489
DEBUG - 2022-07-08 08:30:50 --> Total execution time: 0.0524
DEBUG - 2022-07-08 08:31:14 --> Total execution time: 0.0698
DEBUG - 2022-07-08 08:31:20 --> Total execution time: 0.0695
DEBUG - 2022-07-08 08:31:44 --> Total execution time: 0.0781
DEBUG - 2022-07-08 08:32:46 --> Total execution time: 0.0377
DEBUG - 2022-07-08 08:32:54 --> Total execution time: 0.0557
DEBUG - 2022-07-08 08:33:10 --> Total execution time: 0.0599
DEBUG - 2022-07-08 08:33:29 --> Total execution time: 0.0548
DEBUG - 2022-07-08 08:33:36 --> Total execution time: 0.0590
DEBUG - 2022-07-08 08:33:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:33:37 --> Total execution time: 0.0527
DEBUG - 2022-07-08 08:34:11 --> Total execution time: 0.2187
DEBUG - 2022-07-08 08:34:19 --> Total execution time: 0.0507
DEBUG - 2022-07-08 08:35:20 --> Total execution time: 0.0518
DEBUG - 2022-07-08 08:35:37 --> Total execution time: 0.0710
DEBUG - 2022-07-08 08:35:38 --> Total execution time: 0.0486
DEBUG - 2022-07-08 08:35:41 --> Total execution time: 0.0586
DEBUG - 2022-07-08 08:35:42 --> Total execution time: 0.1406
DEBUG - 2022-07-08 08:35:49 --> Total execution time: 0.0604
DEBUG - 2022-07-08 08:35:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:35:49 --> Total execution time: 0.0660
DEBUG - 2022-07-08 08:35:50 --> Total execution time: 0.0543
DEBUG - 2022-07-08 08:35:52 --> Total execution time: 0.0754
DEBUG - 2022-07-08 08:35:55 --> Total execution time: 0.0767
DEBUG - 2022-07-08 08:36:05 --> Total execution time: 0.0561
DEBUG - 2022-07-08 08:36:49 --> Total execution time: 0.0508
DEBUG - 2022-07-08 08:36:57 --> Total execution time: 0.0632
DEBUG - 2022-07-08 08:36:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:36:58 --> Total execution time: 0.0817
DEBUG - 2022-07-08 08:37:28 --> Total execution time: 0.0787
DEBUG - 2022-07-08 08:37:30 --> Total execution time: 0.0499
DEBUG - 2022-07-08 08:37:39 --> Total execution time: 0.0511
DEBUG - 2022-07-08 08:37:58 --> Total execution time: 0.0788
DEBUG - 2022-07-08 08:38:08 --> Total execution time: 0.1172
DEBUG - 2022-07-08 08:38:19 --> Total execution time: 0.0588
DEBUG - 2022-07-08 08:38:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:38:20 --> Total execution time: 0.0710
DEBUG - 2022-07-08 08:38:24 --> Total execution time: 0.0709
DEBUG - 2022-07-08 08:39:00 --> Total execution time: 0.0396
DEBUG - 2022-07-08 08:39:48 --> Total execution time: 0.0556
DEBUG - 2022-07-08 08:40:09 --> Total execution time: 0.0592
DEBUG - 2022-07-08 08:40:19 --> Total execution time: 0.0892
DEBUG - 2022-07-08 08:40:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:40:20 --> Total execution time: 0.0590
DEBUG - 2022-07-08 08:42:17 --> Total execution time: 0.0557
DEBUG - 2022-07-08 08:42:23 --> Total execution time: 0.0551
DEBUG - 2022-07-08 08:42:49 --> Total execution time: 0.0510
DEBUG - 2022-07-08 08:42:50 --> Total execution time: 0.0537
DEBUG - 2022-07-08 08:42:57 --> Total execution time: 0.0529
DEBUG - 2022-07-08 08:43:05 --> Total execution time: 0.0550
DEBUG - 2022-07-08 08:43:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 08:43:06 --> Total execution time: 0.0515
DEBUG - 2022-07-08 08:44:32 --> Total execution time: 0.0721
DEBUG - 2022-07-08 08:49:02 --> Total execution time: 0.1315
DEBUG - 2022-07-08 08:49:27 --> Total execution time: 0.1888
DEBUG - 2022-07-08 08:49:50 --> Total execution time: 0.0501
DEBUG - 2022-07-08 08:49:57 --> Total execution time: 0.0564
DEBUG - 2022-07-08 08:51:13 --> Total execution time: 0.0551
DEBUG - 2022-07-08 08:51:57 --> Total execution time: 0.0485
DEBUG - 2022-07-08 08:52:07 --> Total execution time: 0.0490
DEBUG - 2022-07-08 08:52:53 --> Total execution time: 0.0614
DEBUG - 2022-07-08 08:53:03 --> Total execution time: 0.1136
DEBUG - 2022-07-08 08:56:20 --> Total execution time: 0.4025
DEBUG - 2022-07-08 08:58:11 --> Total execution time: 0.0537
DEBUG - 2022-07-08 08:58:14 --> Total execution time: 0.0442
DEBUG - 2022-07-08 08:58:58 --> Total execution time: 0.0391
DEBUG - 2022-07-08 08:58:59 --> Total execution time: 0.0291
DEBUG - 2022-07-08 09:00:38 --> Total execution time: 2.8656
DEBUG - 2022-07-08 09:00:53 --> Total execution time: 0.0345
DEBUG - 2022-07-08 09:00:57 --> Total execution time: 0.0549
DEBUG - 2022-07-08 09:01:02 --> Total execution time: 0.0574
DEBUG - 2022-07-08 09:01:21 --> Total execution time: 0.0509
DEBUG - 2022-07-08 09:01:32 --> Total execution time: 0.0492
DEBUG - 2022-07-08 09:01:50 --> Total execution time: 0.0583
DEBUG - 2022-07-08 09:02:15 --> Total execution time: 0.0605
DEBUG - 2022-07-08 09:02:33 --> Total execution time: 0.0450
DEBUG - 2022-07-08 09:02:47 --> Total execution time: 0.0518
DEBUG - 2022-07-08 09:03:37 --> Total execution time: 0.0373
DEBUG - 2022-07-08 09:03:50 --> Total execution time: 0.0598
DEBUG - 2022-07-08 09:03:56 --> Total execution time: 0.0335
DEBUG - 2022-07-08 09:04:06 --> Total execution time: 0.0587
DEBUG - 2022-07-08 09:04:11 --> Total execution time: 0.0570
DEBUG - 2022-07-08 09:04:12 --> Total execution time: 1.6752
DEBUG - 2022-07-08 09:04:47 --> Total execution time: 0.0373
DEBUG - 2022-07-08 09:05:38 --> Total execution time: 0.1320
DEBUG - 2022-07-08 09:10:49 --> Total execution time: 0.2234
DEBUG - 2022-07-08 09:10:55 --> Total execution time: 0.0589
DEBUG - 2022-07-08 09:11:00 --> Total execution time: 0.0720
DEBUG - 2022-07-08 09:11:21 --> Total execution time: 0.0704
DEBUG - 2022-07-08 09:11:40 --> Total execution time: 0.0492
DEBUG - 2022-07-08 09:11:43 --> Total execution time: 0.0863
DEBUG - 2022-07-08 09:11:54 --> Total execution time: 0.0670
DEBUG - 2022-07-08 09:11:57 --> Total execution time: 0.1012
DEBUG - 2022-07-08 09:12:00 --> Total execution time: 0.0516
DEBUG - 2022-07-08 09:12:08 --> Total execution time: 0.0567
DEBUG - 2022-07-08 09:12:35 --> Total execution time: 0.0676
DEBUG - 2022-07-08 09:12:35 --> Total execution time: 0.0609
DEBUG - 2022-07-08 09:12:35 --> Total execution time: 0.0555
DEBUG - 2022-07-08 09:12:35 --> Total execution time: 0.0610
DEBUG - 2022-07-08 09:12:46 --> Total execution time: 0.0694
DEBUG - 2022-07-08 09:13:38 --> Total execution time: 0.0598
DEBUG - 2022-07-08 09:13:47 --> Total execution time: 0.0552
DEBUG - 2022-07-08 09:19:08 --> Total execution time: 0.1510
DEBUG - 2022-07-08 09:19:15 --> Total execution time: 0.0493
DEBUG - 2022-07-08 09:19:15 --> Total execution time: 0.0525
DEBUG - 2022-07-08 09:19:26 --> Total execution time: 0.0638
DEBUG - 2022-07-08 09:19:29 --> Total execution time: 0.0525
DEBUG - 2022-07-08 09:19:33 --> Total execution time: 0.0486
DEBUG - 2022-07-08 09:19:36 --> Total execution time: 0.0509
DEBUG - 2022-07-08 09:19:36 --> Total execution time: 0.0514
DEBUG - 2022-07-08 09:19:39 --> Total execution time: 0.0546
DEBUG - 2022-07-08 09:19:44 --> Total execution time: 0.0368
DEBUG - 2022-07-08 09:19:49 --> Total execution time: 0.0493
DEBUG - 2022-07-08 09:21:19 --> Total execution time: 0.1161
DEBUG - 2022-07-08 09:21:23 --> Total execution time: 0.0694
DEBUG - 2022-07-08 09:21:30 --> Total execution time: 0.0839
DEBUG - 2022-07-08 09:22:45 --> Total execution time: 0.0855
DEBUG - 2022-07-08 09:23:24 --> Total execution time: 0.0744
DEBUG - 2022-07-08 09:25:13 --> Total execution time: 0.0367
DEBUG - 2022-07-08 09:26:07 --> Total execution time: 0.0841
DEBUG - 2022-07-08 09:26:23 --> Total execution time: 0.0347
DEBUG - 2022-07-08 09:26:32 --> Total execution time: 0.1022
DEBUG - 2022-07-08 09:26:50 --> Total execution time: 0.0851
DEBUG - 2022-07-08 09:27:04 --> Total execution time: 0.0820
DEBUG - 2022-07-08 09:27:10 --> Total execution time: 0.0595
DEBUG - 2022-07-08 09:27:15 --> Total execution time: 0.1287
DEBUG - 2022-07-08 09:27:15 --> Total execution time: 0.1093
DEBUG - 2022-07-08 09:27:44 --> Total execution time: 0.0420
DEBUG - 2022-07-08 09:28:31 --> Total execution time: 0.1272
DEBUG - 2022-07-08 09:28:39 --> Total execution time: 0.0642
DEBUG - 2022-07-08 09:28:49 --> Total execution time: 0.0753
DEBUG - 2022-07-08 09:29:27 --> Total execution time: 0.0686
DEBUG - 2022-07-08 09:30:02 --> Total execution time: 0.0707
DEBUG - 2022-07-08 09:32:59 --> Total execution time: 0.1617
DEBUG - 2022-07-08 09:32:59 --> Total execution time: 0.0582
DEBUG - 2022-07-08 09:33:03 --> Total execution time: 0.0704
DEBUG - 2022-07-08 09:33:07 --> Total execution time: 0.0513
DEBUG - 2022-07-08 09:33:35 --> Total execution time: 0.0493
DEBUG - 2022-07-08 09:33:44 --> Total execution time: 0.1064
DEBUG - 2022-07-08 09:33:51 --> Total execution time: 0.0566
DEBUG - 2022-07-08 09:33:52 --> Total execution time: 0.0514
DEBUG - 2022-07-08 09:38:39 --> Total execution time: 0.1128
DEBUG - 2022-07-08 09:39:29 --> Total execution time: 0.0392
DEBUG - 2022-07-08 09:39:31 --> Total execution time: 0.0356
DEBUG - 2022-07-08 09:44:58 --> Total execution time: 0.1457
DEBUG - 2022-07-08 09:48:15 --> Total execution time: 0.1281
DEBUG - 2022-07-08 09:48:48 --> Total execution time: 0.0404
DEBUG - 2022-07-08 09:50:49 --> Total execution time: 0.0366
DEBUG - 2022-07-08 09:58:41 --> Total execution time: 0.1281
DEBUG - 2022-07-08 09:58:42 --> Total execution time: 0.0356
DEBUG - 2022-07-08 09:58:42 --> Total execution time: 0.0371
DEBUG - 2022-07-08 09:59:16 --> Total execution time: 0.0387
DEBUG - 2022-07-08 09:59:16 --> Total execution time: 0.0415
DEBUG - 2022-07-08 09:59:57 --> Total execution time: 0.0555
DEBUG - 2022-07-08 09:59:58 --> Total execution time: 0.0336
DEBUG - 2022-07-08 10:00:08 --> Total execution time: 0.1071
DEBUG - 2022-07-08 10:00:32 --> Total execution time: 0.0876
DEBUG - 2022-07-08 10:07:34 --> Total execution time: 0.0600
DEBUG - 2022-07-08 10:07:48 --> Total execution time: 0.0496
DEBUG - 2022-07-08 10:07:49 --> Total execution time: 0.0687
DEBUG - 2022-07-08 10:07:52 --> Total execution time: 0.0579
DEBUG - 2022-07-08 10:07:57 --> Total execution time: 0.0569
DEBUG - 2022-07-08 10:07:58 --> Total execution time: 0.0818
DEBUG - 2022-07-08 10:08:04 --> Total execution time: 0.0549
DEBUG - 2022-07-08 10:08:06 --> Total execution time: 0.0785
DEBUG - 2022-07-08 10:08:07 --> Total execution time: 0.0415
DEBUG - 2022-07-08 10:08:29 --> Total execution time: 0.1151
DEBUG - 2022-07-08 10:15:18 --> Total execution time: 0.2523
DEBUG - 2022-07-08 10:16:06 --> Total execution time: 0.4479
DEBUG - 2022-07-08 10:18:03 --> Total execution time: 0.0608
DEBUG - 2022-07-08 10:18:31 --> Total execution time: 0.0757
DEBUG - 2022-07-08 10:19:51 --> Total execution time: 0.2478
DEBUG - 2022-07-08 10:19:56 --> Total execution time: 0.0692
DEBUG - 2022-07-08 10:20:32 --> Total execution time: 0.0794
DEBUG - 2022-07-08 10:20:32 --> Total execution time: 0.0401
DEBUG - 2022-07-08 10:20:36 --> Total execution time: 0.0376
DEBUG - 2022-07-08 10:20:52 --> Total execution time: 0.0669
DEBUG - 2022-07-08 10:20:53 --> Total execution time: 0.0497
DEBUG - 2022-07-08 10:20:54 --> Total execution time: 0.0330
DEBUG - 2022-07-08 10:21:05 --> Total execution time: 0.0401
DEBUG - 2022-07-08 10:21:06 --> Total execution time: 0.0605
DEBUG - 2022-07-08 10:21:06 --> Total execution time: 0.0426
DEBUG - 2022-07-08 10:21:06 --> Total execution time: 0.0373
DEBUG - 2022-07-08 10:21:16 --> Total execution time: 0.0726
DEBUG - 2022-07-08 10:21:24 --> Total execution time: 0.0670
DEBUG - 2022-07-08 10:21:27 --> Total execution time: 0.0624
DEBUG - 2022-07-08 10:21:30 --> Total execution time: 0.0654
DEBUG - 2022-07-08 10:21:38 --> Total execution time: 0.0811
DEBUG - 2022-07-08 10:21:41 --> Total execution time: 0.0546
DEBUG - 2022-07-08 10:21:50 --> Total execution time: 0.0590
DEBUG - 2022-07-08 10:22:02 --> Total execution time: 0.0749
DEBUG - 2022-07-08 10:22:03 --> Total execution time: 0.0588
DEBUG - 2022-07-08 10:22:03 --> Total execution time: 0.0603
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0715
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0548
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0626
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0534
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0529
DEBUG - 2022-07-08 10:22:04 --> Total execution time: 0.0618
DEBUG - 2022-07-08 10:22:50 --> Total execution time: 0.0764
DEBUG - 2022-07-08 10:23:09 --> Total execution time: 0.0927
DEBUG - 2022-07-08 10:23:29 --> Total execution time: 0.0624
DEBUG - 2022-07-08 10:23:32 --> Total execution time: 0.0514
DEBUG - 2022-07-08 10:23:36 --> Total execution time: 0.0619
DEBUG - 2022-07-08 10:23:37 --> Total execution time: 0.0539
DEBUG - 2022-07-08 10:23:58 --> Total execution time: 0.0566
DEBUG - 2022-07-08 10:23:59 --> Total execution time: 0.0707
DEBUG - 2022-07-08 10:24:06 --> Total execution time: 0.0570
DEBUG - 2022-07-08 10:24:07 --> Total execution time: 0.0606
DEBUG - 2022-07-08 10:24:07 --> Total execution time: 0.0634
DEBUG - 2022-07-08 10:24:07 --> Total execution time: 0.0625
DEBUG - 2022-07-08 10:24:07 --> Total execution time: 0.0681
DEBUG - 2022-07-08 10:24:08 --> Total execution time: 0.0574
DEBUG - 2022-07-08 10:24:08 --> Total execution time: 0.0530
DEBUG - 2022-07-08 10:24:10 --> Total execution time: 0.0739
DEBUG - 2022-07-08 10:24:14 --> Total execution time: 0.0525
DEBUG - 2022-07-08 10:24:40 --> Total execution time: 0.0510
DEBUG - 2022-07-08 10:26:06 --> Total execution time: 0.1488
DEBUG - 2022-07-08 10:26:10 --> Total execution time: 0.0872
DEBUG - 2022-07-08 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:30:03 --> Total execution time: 0.1759
DEBUG - 2022-07-08 00:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:03:14 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-08 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:03:28 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-08 00:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:06:37 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:36:37 --> Total execution time: 0.1142
DEBUG - 2022-07-08 00:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:06:43 --> Total execution time: 0.0347
DEBUG - 2022-07-08 00:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:06:56 --> Total execution time: 0.0691
DEBUG - 2022-07-08 00:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:39:11 --> Total execution time: 0.0692
DEBUG - 2022-07-08 00:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:40:32 --> Total execution time: 0.2173
DEBUG - 2022-07-08 00:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:40:33 --> Total execution time: 0.0737
DEBUG - 2022-07-08 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:40:37 --> Total execution time: 0.0542
DEBUG - 2022-07-08 00:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:17:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 00:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:20:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:20:39 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:21:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:51:16 --> Total execution time: 0.1938
DEBUG - 2022-07-08 00:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:21:42 --> Total execution time: 0.0534
DEBUG - 2022-07-08 00:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:21:43 --> Total execution time: 0.0514
DEBUG - 2022-07-08 00:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:21:44 --> Total execution time: 0.1559
DEBUG - 2022-07-08 00:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:21:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:51:57 --> Total execution time: 0.0593
DEBUG - 2022-07-08 00:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:22:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:22:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 00:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:56:37 --> Total execution time: 0.1098
DEBUG - 2022-07-08 00:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:56:45 --> Total execution time: 0.0837
DEBUG - 2022-07-08 00:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:56:50 --> Total execution time: 0.1158
DEBUG - 2022-07-08 00:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:57:55 --> Total execution time: 0.1432
DEBUG - 2022-07-08 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:28:25 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-08 00:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:58:31 --> Total execution time: 0.0819
DEBUG - 2022-07-08 00:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:00:59 --> Total execution time: 0.1356
DEBUG - 2022-07-08 00:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:01:08 --> Total execution time: 0.0645
DEBUG - 2022-07-08 00:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:01:18 --> Total execution time: 0.0591
DEBUG - 2022-07-08 00:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:01:25 --> Total execution time: 0.0718
DEBUG - 2022-07-08 00:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:03:51 --> Total execution time: 0.1648
DEBUG - 2022-07-08 00:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:03:56 --> Total execution time: 0.1342
DEBUG - 2022-07-08 00:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:03:57 --> Total execution time: 0.0960
DEBUG - 2022-07-08 00:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:04:05 --> Total execution time: 0.0562
DEBUG - 2022-07-08 00:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:04:33 --> Total execution time: 0.1292
DEBUG - 2022-07-08 00:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:04:40 --> Total execution time: 0.0627
DEBUG - 2022-07-08 00:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:04:45 --> Total execution time: 0.0504
DEBUG - 2022-07-08 00:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:05:50 --> Total execution time: 0.0860
DEBUG - 2022-07-08 00:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:06:04 --> Total execution time: 0.0581
DEBUG - 2022-07-08 00:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:39:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:09:29 --> Total execution time: 0.1267
DEBUG - 2022-07-08 00:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:39:49 --> Total execution time: 0.0371
DEBUG - 2022-07-08 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:39:51 --> Total execution time: 0.0608
DEBUG - 2022-07-08 00:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:39:51 --> Total execution time: 0.0936
DEBUG - 2022-07-08 00:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:03 --> Total execution time: 0.0694
DEBUG - 2022-07-08 00:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:40:34 --> Total execution time: 0.0879
DEBUG - 2022-07-08 00:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:40:35 --> Total execution time: 0.0563
DEBUG - 2022-07-08 00:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:40:35 --> Total execution time: 0.1233
DEBUG - 2022-07-08 00:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:40:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:58 --> Total execution time: 0.0551
DEBUG - 2022-07-08 00:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:41:45 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:11:45 --> Total execution time: 0.0377
DEBUG - 2022-07-08 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:11:49 --> Total execution time: 0.0578
DEBUG - 2022-07-08 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:01 --> Total execution time: 0.0900
DEBUG - 2022-07-08 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:10 --> Total execution time: 0.0587
DEBUG - 2022-07-08 00:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:17 --> Total execution time: 0.0572
DEBUG - 2022-07-08 00:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:31 --> Total execution time: 0.0606
DEBUG - 2022-07-08 00:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:34 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:34 --> Total execution time: 0.0364
DEBUG - 2022-07-08 00:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:42:46 --> Total execution time: 0.0589
DEBUG - 2022-07-08 00:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:50 --> Total execution time: 0.0777
DEBUG - 2022-07-08 00:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:14:23 --> Total execution time: 0.0516
DEBUG - 2022-07-08 00:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:14:38 --> Total execution time: 0.0509
DEBUG - 2022-07-08 00:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:14:53 --> Total execution time: 0.0589
DEBUG - 2022-07-08 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:15:06 --> Total execution time: 0.0681
DEBUG - 2022-07-08 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:15:34 --> Total execution time: 0.0606
DEBUG - 2022-07-08 00:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:15:37 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:15:39 --> Total execution time: 0.0368
DEBUG - 2022-07-08 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:15:47 --> Total execution time: 0.0539
DEBUG - 2022-07-08 00:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:16:03 --> Total execution time: 0.0972
DEBUG - 2022-07-08 00:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:16:11 --> Total execution time: 0.0663
DEBUG - 2022-07-08 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:16:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 00:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:16:12 --> Total execution time: 0.0583
DEBUG - 2022-07-08 00:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:03 --> Total execution time: 0.0554
DEBUG - 2022-07-08 00:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:06 --> Total execution time: 0.0751
DEBUG - 2022-07-08 00:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:07 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:08 --> Total execution time: 0.0909
DEBUG - 2022-07-08 00:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:35 --> Total execution time: 0.0559
DEBUG - 2022-07-08 00:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:48 --> Total execution time: 0.0606
DEBUG - 2022-07-08 00:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:52 --> Total execution time: 0.0640
DEBUG - 2022-07-08 00:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:48:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:48:55 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 00:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:03 --> Total execution time: 0.0570
DEBUG - 2022-07-08 00:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:22 --> Total execution time: 0.0677
DEBUG - 2022-07-08 00:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:39 --> Total execution time: 0.0675
DEBUG - 2022-07-08 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:43 --> Total execution time: 0.0636
DEBUG - 2022-07-08 00:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:48 --> Total execution time: 0.0750
DEBUG - 2022-07-08 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:56 --> Total execution time: 0.0488
DEBUG - 2022-07-08 00:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:01 --> Total execution time: 0.0573
DEBUG - 2022-07-08 00:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:09 --> Total execution time: 0.0564
DEBUG - 2022-07-08 00:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:20 --> Total execution time: 0.0548
DEBUG - 2022-07-08 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:37 --> Total execution time: 0.0589
DEBUG - 2022-07-08 00:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 00:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:38 --> Total execution time: 0.0767
DEBUG - 2022-07-08 00:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:54:07 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-08 00:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 00:54:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 00:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:25:02 --> Total execution time: 0.2781
DEBUG - 2022-07-08 00:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:25:05 --> Total execution time: 0.0583
DEBUG - 2022-07-08 00:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:55:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:25:35 --> Total execution time: 0.0644
DEBUG - 2022-07-08 00:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:26:07 --> Total execution time: 0.0573
DEBUG - 2022-07-08 00:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:00 --> No URI present. Default controller set.
DEBUG - 2022-07-08 00:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:00 --> Total execution time: 0.1033
DEBUG - 2022-07-08 00:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:04 --> Total execution time: 0.1394
DEBUG - 2022-07-08 00:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 00:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:12 --> Total execution time: 0.1399
DEBUG - 2022-07-08 00:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:17 --> Total execution time: 0.1075
DEBUG - 2022-07-08 00:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:20 --> Total execution time: 0.1110
DEBUG - 2022-07-08 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 00:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 00:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:29:40 --> Total execution time: 0.0529
DEBUG - 2022-07-08 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:30:02 --> Total execution time: 0.1575
DEBUG - 2022-07-08 01:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:15 --> Total execution time: 0.1422
DEBUG - 2022-07-08 01:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:28 --> Total execution time: 0.0754
DEBUG - 2022-07-08 01:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:29 --> Total execution time: 0.0654
DEBUG - 2022-07-08 01:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:33 --> Total execution time: 0.0564
DEBUG - 2022-07-08 01:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:39 --> Total execution time: 0.0798
DEBUG - 2022-07-08 01:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:42 --> Total execution time: 0.0646
DEBUG - 2022-07-08 01:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:43 --> Total execution time: 0.0785
DEBUG - 2022-07-08 01:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:54 --> Total execution time: 0.0655
DEBUG - 2022-07-08 01:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 01:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:55 --> Total execution time: 0.0581
DEBUG - 2022-07-08 01:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:33:57 --> Total execution time: 0.0616
DEBUG - 2022-07-08 01:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:34:05 --> Total execution time: 0.0649
DEBUG - 2022-07-08 01:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:34:08 --> Total execution time: 0.0824
DEBUG - 2022-07-08 01:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:34:16 --> Total execution time: 0.0591
DEBUG - 2022-07-08 01:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:34:47 --> Total execution time: 0.0871
DEBUG - 2022-07-08 01:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:01 --> Total execution time: 0.0842
DEBUG - 2022-07-08 01:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:10 --> Total execution time: 0.0676
DEBUG - 2022-07-08 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:20 --> Total execution time: 0.0555
DEBUG - 2022-07-08 01:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:20 --> Total execution time: 0.1299
DEBUG - 2022-07-08 01:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:23 --> Total execution time: 0.0796
DEBUG - 2022-07-08 01:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:28 --> Total execution time: 0.0634
DEBUG - 2022-07-08 01:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:32 --> Total execution time: 0.0551
DEBUG - 2022-07-08 01:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:37 --> Total execution time: 0.0649
DEBUG - 2022-07-08 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 01:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:38 --> Total execution time: 0.0569
DEBUG - 2022-07-08 01:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:07:37 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:37:37 --> Total execution time: 0.0676
DEBUG - 2022-07-08 01:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:07:43 --> Total execution time: 0.0559
DEBUG - 2022-07-08 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:07:45 --> Total execution time: 0.0523
DEBUG - 2022-07-08 01:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:07:45 --> Total execution time: 0.1274
DEBUG - 2022-07-08 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:12 --> Total execution time: 0.0588
DEBUG - 2022-07-08 01:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:18 --> Total execution time: 0.0622
DEBUG - 2022-07-08 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:25 --> Total execution time: 0.0542
DEBUG - 2022-07-08 01:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:33 --> Total execution time: 0.0566
DEBUG - 2022-07-08 01:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 01:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:38:35 --> Total execution time: 0.0754
DEBUG - 2022-07-08 01:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:40:19 --> Total execution time: 0.1433
DEBUG - 2022-07-08 01:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:40:45 --> Total execution time: 0.0801
DEBUG - 2022-07-08 01:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:10:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:40:49 --> Total execution time: 0.0587
DEBUG - 2022-07-08 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:40:54 --> Total execution time: 0.0557
DEBUG - 2022-07-08 01:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:40:55 --> Total execution time: 0.0533
DEBUG - 2022-07-08 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:13 --> Total execution time: 0.0474
DEBUG - 2022-07-08 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:38 --> Total execution time: 0.0504
DEBUG - 2022-07-08 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:44 --> Total execution time: 0.0571
DEBUG - 2022-07-08 01:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:44 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 01:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:45 --> Total execution time: 0.0493
DEBUG - 2022-07-08 01:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:42:00 --> Total execution time: 0.0549
DEBUG - 2022-07-08 01:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:42:05 --> Total execution time: 0.0554
DEBUG - 2022-07-08 01:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:42:14 --> Total execution time: 0.0517
DEBUG - 2022-07-08 01:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:43:53 --> Total execution time: 0.0549
DEBUG - 2022-07-08 01:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:16:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:46:40 --> Total execution time: 0.2130
DEBUG - 2022-07-08 01:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:46:48 --> Total execution time: 0.0528
DEBUG - 2022-07-08 01:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:47:20 --> Total execution time: 0.0631
DEBUG - 2022-07-08 01:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:47:27 --> Total execution time: 0.0611
DEBUG - 2022-07-08 01:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:47:45 --> Total execution time: 0.0755
DEBUG - 2022-07-08 01:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:47:50 --> Total execution time: 0.0832
DEBUG - 2022-07-08 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:48:01 --> Total execution time: 0.1137
DEBUG - 2022-07-08 01:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:49:49 --> Total execution time: 0.0589
DEBUG - 2022-07-08 01:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:50:58 --> Total execution time: 0.0670
DEBUG - 2022-07-08 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:51:10 --> Total execution time: 0.1232
DEBUG - 2022-07-08 01:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:51:11 --> Total execution time: 0.0996
DEBUG - 2022-07-08 01:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:51:17 --> Total execution time: 0.0651
DEBUG - 2022-07-08 01:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:09 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:09 --> Total execution time: 0.0501
DEBUG - 2022-07-08 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:10 --> Total execution time: 0.0670
DEBUG - 2022-07-08 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:20 --> Total execution time: 0.0374
DEBUG - 2022-07-08 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:45 --> Total execution time: 0.0498
DEBUG - 2022-07-08 01:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:51 --> Total execution time: 0.0432
DEBUG - 2022-07-08 01:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:52 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:52 --> Total execution time: 0.0439
DEBUG - 2022-07-08 01:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:57 --> Total execution time: 0.0333
DEBUG - 2022-07-08 01:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:02 --> Total execution time: 0.0640
DEBUG - 2022-07-08 01:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:06 --> Total execution time: 0.0462
DEBUG - 2022-07-08 01:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:11 --> Total execution time: 0.0722
DEBUG - 2022-07-08 01:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:13 --> Total execution time: 0.0715
DEBUG - 2022-07-08 01:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:13 --> Total execution time: 0.0451
DEBUG - 2022-07-08 01:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:26 --> Total execution time: 0.0574
DEBUG - 2022-07-08 01:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:30 --> Total execution time: 0.1369
DEBUG - 2022-07-08 01:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:32 --> Total execution time: 0.0636
DEBUG - 2022-07-08 01:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:39 --> Total execution time: 0.0682
DEBUG - 2022-07-08 01:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:52 --> Total execution time: 0.0912
DEBUG - 2022-07-08 01:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:01 --> Total execution time: 0.1558
DEBUG - 2022-07-08 01:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:05 --> Total execution time: 0.0639
DEBUG - 2022-07-08 01:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:10 --> Total execution time: 0.0576
DEBUG - 2022-07-08 01:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:12 --> Total execution time: 0.0688
DEBUG - 2022-07-08 01:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:15 --> Total execution time: 0.0807
DEBUG - 2022-07-08 01:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:20 --> Total execution time: 0.0657
DEBUG - 2022-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:27 --> Total execution time: 0.0685
DEBUG - 2022-07-08 01:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:33 --> Total execution time: 0.0659
DEBUG - 2022-07-08 01:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:08 --> Total execution time: 0.0756
DEBUG - 2022-07-08 01:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:27 --> Total execution time: 0.0667
DEBUG - 2022-07-08 01:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:36 --> Total execution time: 0.0633
DEBUG - 2022-07-08 01:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:46 --> Total execution time: 0.1632
DEBUG - 2022-07-08 01:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:53 --> Total execution time: 0.0540
DEBUG - 2022-07-08 01:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:56 --> Total execution time: 0.0969
DEBUG - 2022-07-08 01:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:01 --> Total execution time: 0.0558
DEBUG - 2022-07-08 01:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:30 --> Total execution time: 0.0700
DEBUG - 2022-07-08 01:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:33 --> Total execution time: 0.0563
DEBUG - 2022-07-08 01:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:35 --> Total execution time: 0.0554
DEBUG - 2022-07-08 01:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:36 --> Total execution time: 0.0550
DEBUG - 2022-07-08 01:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:37 --> Total execution time: 0.0595
DEBUG - 2022-07-08 01:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:38 --> Total execution time: 0.0655
DEBUG - 2022-07-08 01:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:39 --> Total execution time: 0.0558
DEBUG - 2022-07-08 01:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:51 --> Total execution time: 0.0635
DEBUG - 2022-07-08 01:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:09 --> Total execution time: 0.0720
DEBUG - 2022-07-08 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:21 --> Total execution time: 0.0761
DEBUG - 2022-07-08 01:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:22 --> Total execution time: 0.1025
DEBUG - 2022-07-08 01:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:41 --> Total execution time: 0.0386
DEBUG - 2022-07-08 01:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:59:02 --> Total execution time: 0.0603
DEBUG - 2022-07-08 01:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:59:32 --> Total execution time: 0.1581
DEBUG - 2022-07-08 01:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:29:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:59:51 --> Total execution time: 0.1530
DEBUG - 2022-07-08 01:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:25 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:03:25 --> Total execution time: 0.1644
DEBUG - 2022-07-08 01:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:03:51 --> Total execution time: 0.0624
DEBUG - 2022-07-08 01:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:03:59 --> Total execution time: 0.0544
DEBUG - 2022-07-08 01:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:04:12 --> Total execution time: 0.0641
DEBUG - 2022-07-08 01:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:04:20 --> Total execution time: 0.1168
DEBUG - 2022-07-08 01:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:04:35 --> Total execution time: 0.0592
DEBUG - 2022-07-08 01:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:06:10 --> Total execution time: 0.0635
DEBUG - 2022-07-08 01:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:06:20 --> Total execution time: 0.0601
DEBUG - 2022-07-08 01:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:06:33 --> Total execution time: 0.0637
DEBUG - 2022-07-08 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:06:36 --> Total execution time: 0.0589
DEBUG - 2022-07-08 01:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:37 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:37 --> Total execution time: 0.1344
DEBUG - 2022-07-08 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:44 --> Total execution time: 0.0546
DEBUG - 2022-07-08 01:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:46 --> Total execution time: 0.0618
DEBUG - 2022-07-08 01:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:56 --> Total execution time: 0.0586
DEBUG - 2022-07-08 01:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:09:15 --> Total execution time: 0.1406
DEBUG - 2022-07-08 01:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:10:35 --> Total execution time: 0.0659
DEBUG - 2022-07-08 01:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:10:37 --> Total execution time: 0.0558
DEBUG - 2022-07-08 01:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:06 --> Total execution time: 0.0715
DEBUG - 2022-07-08 01:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:22 --> Total execution time: 0.0651
DEBUG - 2022-07-08 01:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:27 --> Total execution time: 0.0596
DEBUG - 2022-07-08 01:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:36 --> Total execution time: 0.0684
DEBUG - 2022-07-08 01:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:47 --> Total execution time: 0.0651
DEBUG - 2022-07-08 01:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:18 --> Total execution time: 0.0705
DEBUG - 2022-07-08 01:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:22 --> Total execution time: 0.0612
DEBUG - 2022-07-08 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:26 --> Total execution time: 0.0595
DEBUG - 2022-07-08 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:30 --> Total execution time: 0.0434
DEBUG - 2022-07-08 01:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:30 --> Total execution time: 0.0546
DEBUG - 2022-07-08 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:33 --> Total execution time: 0.0329
DEBUG - 2022-07-08 01:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:39 --> Total execution time: 0.2088
DEBUG - 2022-07-08 01:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:42 --> Total execution time: 0.0549
DEBUG - 2022-07-08 01:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:13:44 --> Total execution time: 0.0781
DEBUG - 2022-07-08 01:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:14:04 --> Total execution time: 0.0601
DEBUG - 2022-07-08 01:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:14:39 --> Total execution time: 0.0659
DEBUG - 2022-07-08 01:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:14:46 --> Total execution time: 0.0703
DEBUG - 2022-07-08 01:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:16:56 --> Total execution time: 0.0910
DEBUG - 2022-07-08 01:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:00 --> Total execution time: 0.0663
DEBUG - 2022-07-08 01:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:03 --> Total execution time: 0.0641
DEBUG - 2022-07-08 01:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:14 --> Total execution time: 0.0422
DEBUG - 2022-07-08 01:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:18 --> Total execution time: 0.0578
DEBUG - 2022-07-08 01:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:21 --> Total execution time: 0.0601
DEBUG - 2022-07-08 01:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:17:25 --> Total execution time: 0.0554
DEBUG - 2022-07-08 01:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:48:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 01:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:18:53 --> Total execution time: 0.0495
DEBUG - 2022-07-08 01:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:06 --> Total execution time: 0.0752
DEBUG - 2022-07-08 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:18 --> Total execution time: 0.0823
DEBUG - 2022-07-08 01:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:22 --> Total execution time: 0.0949
DEBUG - 2022-07-08 01:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 01:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 01:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:30 --> Total execution time: 0.0864
DEBUG - 2022-07-08 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:02 --> Total execution time: 0.1440
DEBUG - 2022-07-08 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:04 --> Total execution time: 0.0584
DEBUG - 2022-07-08 02:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:15 --> Total execution time: 0.0711
DEBUG - 2022-07-08 02:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:16 --> Total execution time: 0.0688
DEBUG - 2022-07-08 02:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:21 --> Total execution time: 0.0994
DEBUG - 2022-07-08 02:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:04:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:34:12 --> Total execution time: 0.1314
DEBUG - 2022-07-08 02:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:04:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:34:35 --> Total execution time: 0.0526
DEBUG - 2022-07-08 02:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:07:21 --> Total execution time: 0.0542
DEBUG - 2022-07-08 02:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:37:25 --> Total execution time: 0.0788
DEBUG - 2022-07-08 02:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:07:27 --> Total execution time: 0.0526
DEBUG - 2022-07-08 02:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:37:30 --> Total execution time: 0.0805
DEBUG - 2022-07-08 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:37:46 --> Total execution time: 0.0561
DEBUG - 2022-07-08 02:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:38:09 --> Total execution time: 0.0506
DEBUG - 2022-07-08 02:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 02:09:12 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:39:46 --> Total execution time: 0.0703
DEBUG - 2022-07-08 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:39:46 --> Total execution time: 0.1580
DEBUG - 2022-07-08 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:39:57 --> Total execution time: 0.0536
DEBUG - 2022-07-08 02:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:39:57 --> Total execution time: 0.0560
DEBUG - 2022-07-08 02:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:40:52 --> Total execution time: 0.0738
DEBUG - 2022-07-08 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:40:57 --> Total execution time: 0.0804
DEBUG - 2022-07-08 02:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:41:25 --> Total execution time: 0.0749
DEBUG - 2022-07-08 02:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:41:29 --> Total execution time: 0.0768
DEBUG - 2022-07-08 02:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:41:34 --> Total execution time: 0.0611
DEBUG - 2022-07-08 02:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:41:41 --> Total execution time: 0.0755
DEBUG - 2022-07-08 02:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 02:12:18 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 02:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:44:32 --> Total execution time: 0.1288
DEBUG - 2022-07-08 02:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:14:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 02:14:46 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 02:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:44:51 --> Total execution time: 0.1749
DEBUG - 2022-07-08 02:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:44:55 --> Total execution time: 0.0809
DEBUG - 2022-07-08 02:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:44:56 --> Total execution time: 0.0516
DEBUG - 2022-07-08 02:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:17:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:47:12 --> Total execution time: 0.1126
DEBUG - 2022-07-08 02:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:47:42 --> Total execution time: 0.0546
DEBUG - 2022-07-08 02:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:47:51 --> Total execution time: 0.0564
DEBUG - 2022-07-08 02:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:47:52 --> Total execution time: 0.0537
DEBUG - 2022-07-08 02:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:05 --> Total execution time: 0.1091
DEBUG - 2022-07-08 02:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:10 --> Total execution time: 0.0670
DEBUG - 2022-07-08 02:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:15 --> Total execution time: 0.0765
DEBUG - 2022-07-08 02:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:27 --> Total execution time: 0.1577
DEBUG - 2022-07-08 02:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:27 --> Total execution time: 0.0667
DEBUG - 2022-07-08 02:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:30 --> Total execution time: 0.0850
DEBUG - 2022-07-08 02:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:45 --> Total execution time: 0.0872
DEBUG - 2022-07-08 02:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:48:56 --> Total execution time: 0.0845
DEBUG - 2022-07-08 02:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:49:08 --> Total execution time: 0.0812
DEBUG - 2022-07-08 02:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:49:23 --> Total execution time: 0.0523
DEBUG - 2022-07-08 02:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:50:05 --> Total execution time: 0.0560
DEBUG - 2022-07-08 02:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:51:48 --> Total execution time: 0.1401
DEBUG - 2022-07-08 02:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:51:53 --> Total execution time: 0.0920
DEBUG - 2022-07-08 02:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:25:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:55:22 --> Total execution time: 0.0690
DEBUG - 2022-07-08 02:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:25:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:55:42 --> Total execution time: 0.0411
DEBUG - 2022-07-08 02:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:56:20 --> Total execution time: 0.0502
DEBUG - 2022-07-08 02:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:57:57 --> Total execution time: 0.0583
DEBUG - 2022-07-08 02:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:02:46 --> Total execution time: 0.0707
DEBUG - 2022-07-08 02:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:03:05 --> Total execution time: 0.0957
DEBUG - 2022-07-08 02:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:03:25 --> Total execution time: 0.3487
DEBUG - 2022-07-08 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:03:34 --> Total execution time: 0.1069
DEBUG - 2022-07-08 02:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:34:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:04:18 --> Total execution time: 0.0440
DEBUG - 2022-07-08 02:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:05:13 --> Total execution time: 0.0534
DEBUG - 2022-07-08 02:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:05:50 --> Total execution time: 0.0748
DEBUG - 2022-07-08 02:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:08:50 --> Total execution time: 0.2116
DEBUG - 2022-07-08 02:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:09:49 --> Total execution time: 0.0675
DEBUG - 2022-07-08 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 02:42:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 02:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:20:51 --> Total execution time: 0.2286
DEBUG - 2022-07-08 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:21:31 --> Total execution time: 0.0809
DEBUG - 2022-07-08 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:21:36 --> Total execution time: 0.0605
DEBUG - 2022-07-08 02:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:21:46 --> Total execution time: 0.0621
DEBUG - 2022-07-08 02:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:21:58 --> Total execution time: 0.0625
DEBUG - 2022-07-08 02:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:22:06 --> Total execution time: 0.0530
DEBUG - 2022-07-08 02:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:22:17 --> Total execution time: 0.0596
DEBUG - 2022-07-08 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:22:20 --> Total execution time: 0.0892
DEBUG - 2022-07-08 02:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:22:24 --> Total execution time: 0.0497
DEBUG - 2022-07-08 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:53:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:23:07 --> Total execution time: 0.0489
DEBUG - 2022-07-08 02:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:53:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:23:38 --> Total execution time: 0.0810
DEBUG - 2022-07-08 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:56:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:26:49 --> Total execution time: 0.1132
DEBUG - 2022-07-08 02:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:26:57 --> Total execution time: 0.0567
DEBUG - 2022-07-08 02:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:27:20 --> Total execution time: 0.0792
DEBUG - 2022-07-08 02:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:27:32 --> Total execution time: 0.1060
DEBUG - 2022-07-08 02:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:27:41 --> Total execution time: 0.0541
DEBUG - 2022-07-08 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:27:49 --> Total execution time: 0.0833
DEBUG - 2022-07-08 02:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:03 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:03 --> Total execution time: 0.0391
DEBUG - 2022-07-08 02:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:05 --> Total execution time: 0.0545
DEBUG - 2022-07-08 02:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:11 --> Total execution time: 0.0356
DEBUG - 2022-07-08 02:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:16 --> Total execution time: 0.0438
DEBUG - 2022-07-08 02:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 02:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:23 --> Total execution time: 0.0617
DEBUG - 2022-07-08 02:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:26 --> No URI present. Default controller set.
DEBUG - 2022-07-08 02:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:26 --> Total execution time: 0.0428
DEBUG - 2022-07-08 02:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 02:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 02:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:28:29 --> Total execution time: 0.0751
DEBUG - 2022-07-08 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:30:02 --> Total execution time: 0.0735
DEBUG - 2022-07-08 03:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:03:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:33:42 --> Total execution time: 0.0404
DEBUG - 2022-07-08 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:36:36 --> Total execution time: 0.0548
DEBUG - 2022-07-08 03:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:07:19 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:37:19 --> Total execution time: 0.2127
DEBUG - 2022-07-08 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:07:28 --> Total execution time: 0.0721
DEBUG - 2022-07-08 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:07:30 --> Total execution time: 0.0755
DEBUG - 2022-07-08 03:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:07:30 --> Total execution time: 0.1042
DEBUG - 2022-07-08 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:09:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:39:13 --> Total execution time: 1.9512
DEBUG - 2022-07-08 03:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 03:09:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 03:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:09:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:39:42 --> Total execution time: 0.1246
DEBUG - 2022-07-08 03:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:39:48 --> Total execution time: 0.0605
DEBUG - 2022-07-08 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:40:07 --> Total execution time: 0.1633
DEBUG - 2022-07-08 03:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:10:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:40:27 --> Total execution time: 0.0453
DEBUG - 2022-07-08 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:10:48 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:40:48 --> Total execution time: 0.0517
DEBUG - 2022-07-08 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:11:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:41:23 --> Total execution time: 0.0445
DEBUG - 2022-07-08 03:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:41:53 --> Total execution time: 0.0744
DEBUG - 2022-07-08 03:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:41:54 --> Total execution time: 0.0761
DEBUG - 2022-07-08 03:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:42:13 --> Total execution time: 0.0734
DEBUG - 2022-07-08 03:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:42:28 --> Total execution time: 0.0564
DEBUG - 2022-07-08 03:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:42:32 --> Total execution time: 0.0928
DEBUG - 2022-07-08 03:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:42:39 --> Total execution time: 0.1320
DEBUG - 2022-07-08 03:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:04 --> Total execution time: 1.6536
DEBUG - 2022-07-08 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:11 --> Total execution time: 0.0762
DEBUG - 2022-07-08 03:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:20 --> Total execution time: 0.0755
DEBUG - 2022-07-08 03:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:26 --> Total execution time: 0.0684
DEBUG - 2022-07-08 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:30 --> Total execution time: 0.0600
DEBUG - 2022-07-08 03:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:34 --> Total execution time: 0.0499
DEBUG - 2022-07-08 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:54 --> Total execution time: 0.0547
DEBUG - 2022-07-08 03:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:46:05 --> Total execution time: 0.1017
DEBUG - 2022-07-08 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:16:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:46:12 --> Total execution time: 0.0755
DEBUG - 2022-07-08 03:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:46:25 --> Total execution time: 1.5062
DEBUG - 2022-07-08 03:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:18:51 --> Total execution time: 0.1150
DEBUG - 2022-07-08 03:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:48:55 --> Total execution time: 0.0711
DEBUG - 2022-07-08 03:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:16 --> Total execution time: 0.0826
DEBUG - 2022-07-08 03:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:18 --> Total execution time: 0.0791
DEBUG - 2022-07-08 03:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:51 --> Total execution time: 0.0529
DEBUG - 2022-07-08 03:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:52 --> Total execution time: 0.0566
DEBUG - 2022-07-08 03:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:56 --> Total execution time: 0.0572
DEBUG - 2022-07-08 03:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:57 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:58 --> Total execution time: 0.0514
DEBUG - 2022-07-08 03:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:49:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 13:49:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 13:49:59 --> Total execution time: 0.2300
DEBUG - 2022-07-08 03:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:04 --> Total execution time: 0.0691
DEBUG - 2022-07-08 03:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:17 --> Total execution time: 0.0517
DEBUG - 2022-07-08 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:18 --> Total execution time: 0.0740
DEBUG - 2022-07-08 03:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:25 --> Total execution time: 0.0615
DEBUG - 2022-07-08 03:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:38 --> Total execution time: 0.0755
DEBUG - 2022-07-08 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:50:54 --> Total execution time: 0.0634
DEBUG - 2022-07-08 03:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:51:13 --> Total execution time: 0.0678
DEBUG - 2022-07-08 03:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:51:31 --> Total execution time: 0.0549
DEBUG - 2022-07-08 03:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:51:32 --> Total execution time: 0.0840
DEBUG - 2022-07-08 03:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:21:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:51:32 --> Total execution time: 0.0580
DEBUG - 2022-07-08 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:25:02 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:55:02 --> Total execution time: 0.1488
DEBUG - 2022-07-08 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:55:07 --> Total execution time: 0.0528
DEBUG - 2022-07-08 03:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:55:29 --> Total execution time: 0.0501
DEBUG - 2022-07-08 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:56:02 --> Total execution time: 0.0627
DEBUG - 2022-07-08 03:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:56:08 --> Total execution time: 0.0875
DEBUG - 2022-07-08 03:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:56:24 --> Total execution time: 0.0627
DEBUG - 2022-07-08 03:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:01 --> Total execution time: 0.0674
DEBUG - 2022-07-08 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:10 --> Total execution time: 0.0593
DEBUG - 2022-07-08 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:14 --> Total execution time: 0.0707
DEBUG - 2022-07-08 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:18 --> Total execution time: 0.0573
DEBUG - 2022-07-08 03:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:21 --> Total execution time: 0.1273
DEBUG - 2022-07-08 03:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:25 --> Total execution time: 0.0486
DEBUG - 2022-07-08 03:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:28 --> Total execution time: 0.0618
DEBUG - 2022-07-08 03:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:27:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:57:40 --> Total execution time: 0.0551
DEBUG - 2022-07-08 03:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:05 --> Total execution time: 0.1589
DEBUG - 2022-07-08 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:13 --> Total execution time: 0.0512
DEBUG - 2022-07-08 03:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:16 --> Total execution time: 0.0508
DEBUG - 2022-07-08 03:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:34 --> Total execution time: 0.0536
DEBUG - 2022-07-08 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:40 --> Total execution time: 0.0585
DEBUG - 2022-07-08 03:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:58:56 --> Total execution time: 0.0677
DEBUG - 2022-07-08 03:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:59:05 --> Total execution time: 0.1123
DEBUG - 2022-07-08 03:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:59:17 --> Total execution time: 0.0732
DEBUG - 2022-07-08 03:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:59:24 --> Total execution time: 0.0828
DEBUG - 2022-07-08 03:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:31:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:01:38 --> Total execution time: 0.0539
DEBUG - 2022-07-08 03:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:04:31 --> Total execution time: 0.0528
DEBUG - 2022-07-08 03:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:07:10 --> Total execution time: 0.1861
DEBUG - 2022-07-08 03:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:09:17 --> Total execution time: 0.1380
DEBUG - 2022-07-08 03:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:10:53 --> Total execution time: 0.0484
DEBUG - 2022-07-08 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:11:44 --> Total execution time: 0.0590
DEBUG - 2022-07-08 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:11:48 --> Total execution time: 0.0790
DEBUG - 2022-07-08 03:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:12:31 --> Total execution time: 0.0575
DEBUG - 2022-07-08 03:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:13:00 --> Total execution time: 0.1391
DEBUG - 2022-07-08 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:13:09 --> Total execution time: 0.0615
DEBUG - 2022-07-08 03:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:13:12 --> Total execution time: 0.0656
DEBUG - 2022-07-08 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:13:57 --> Total execution time: 0.0588
DEBUG - 2022-07-08 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:13 --> Total execution time: 0.0593
DEBUG - 2022-07-08 03:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:17 --> Total execution time: 0.0854
DEBUG - 2022-07-08 03:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:26 --> Total execution time: 0.0542
DEBUG - 2022-07-08 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:30 --> Total execution time: 0.0591
DEBUG - 2022-07-08 03:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:33 --> Total execution time: 0.0648
DEBUG - 2022-07-08 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:38 --> Total execution time: 0.0518
DEBUG - 2022-07-08 03:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:42 --> Total execution time: 0.0606
DEBUG - 2022-07-08 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:56 --> Total execution time: 0.0620
DEBUG - 2022-07-08 03:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:57 --> Total execution time: 0.1527
DEBUG - 2022-07-08 03:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:47:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:17:12 --> Total execution time: 0.1602
DEBUG - 2022-07-08 03:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:47:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:17:29 --> Total execution time: 0.0661
DEBUG - 2022-07-08 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:47:36 --> Total execution time: 0.0770
DEBUG - 2022-07-08 03:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:47:38 --> Total execution time: 0.0541
DEBUG - 2022-07-08 03:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:47:38 --> Total execution time: 0.1108
DEBUG - 2022-07-08 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:48:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:18:10 --> Total execution time: 0.0504
DEBUG - 2022-07-08 03:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:19:31 --> Total execution time: 0.1491
DEBUG - 2022-07-08 03:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:19:34 --> Total execution time: 0.1416
DEBUG - 2022-07-08 03:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:19:35 --> Total execution time: 0.0572
DEBUG - 2022-07-08 03:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:19:37 --> Total execution time: 0.0609
DEBUG - 2022-07-08 03:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:19:52 --> Total execution time: 0.0617
DEBUG - 2022-07-08 03:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:21:52 --> Total execution time: 0.0526
DEBUG - 2022-07-08 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:22:06 --> Total execution time: 0.0816
DEBUG - 2022-07-08 03:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:52:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:22:13 --> Total execution time: 2.0637
DEBUG - 2022-07-08 03:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:22:13 --> Total execution time: 0.0445
DEBUG - 2022-07-08 03:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:52:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 03:52:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:23:17 --> Total execution time: 0.0516
DEBUG - 2022-07-08 03:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:53:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:23:23 --> Total execution time: 0.0593
DEBUG - 2022-07-08 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:53:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:23:36 --> Total execution time: 0.0548
DEBUG - 2022-07-08 03:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:23:43 --> Total execution time: 1.4994
DEBUG - 2022-07-08 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:24:24 --> Total execution time: 2.4450
DEBUG - 2022-07-08 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:24:35 --> Total execution time: 0.0653
DEBUG - 2022-07-08 03:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:54:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:24:36 --> Total execution time: 0.0808
DEBUG - 2022-07-08 03:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:24:43 --> Total execution time: 2.5820
DEBUG - 2022-07-08 03:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:24:54 --> Total execution time: 0.0517
DEBUG - 2022-07-08 03:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:55:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:25:50 --> Total execution time: 0.0414
DEBUG - 2022-07-08 14:25:50 --> Total execution time: 1.4902
DEBUG - 2022-07-08 03:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:02 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:02 --> Total execution time: 0.0587
DEBUG - 2022-07-08 03:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:22 --> Total execution time: 0.0425
DEBUG - 2022-07-08 03:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:23 --> Total execution time: 0.0402
DEBUG - 2022-07-08 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:26 --> Total execution time: 0.0686
DEBUG - 2022-07-08 03:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:29 --> Total execution time: 0.0354
DEBUG - 2022-07-08 03:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:33 --> Total execution time: 0.0893
DEBUG - 2022-07-08 03:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:53 --> Total execution time: 0.0747
DEBUG - 2022-07-08 03:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:26:58 --> Total execution time: 0.0537
DEBUG - 2022-07-08 03:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:01 --> Total execution time: 0.1245
DEBUG - 2022-07-08 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:32 --> Total execution time: 0.0599
DEBUG - 2022-07-08 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:50 --> Total execution time: 0.0506
DEBUG - 2022-07-08 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:50 --> Total execution time: 0.0620
DEBUG - 2022-07-08 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:51 --> Total execution time: 0.0519
DEBUG - 2022-07-08 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:52 --> Total execution time: 0.0588
DEBUG - 2022-07-08 03:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:58:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 03:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:28:11 --> Total execution time: 0.1503
DEBUG - 2022-07-08 03:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:28:18 --> Total execution time: 1.7881
DEBUG - 2022-07-08 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 03:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 03:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 03:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:28:57 --> Total execution time: 0.0589
DEBUG - 2022-07-08 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:30:02 --> Total execution time: 0.0450
DEBUG - 2022-07-08 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:31:50 --> Total execution time: 0.0522
DEBUG - 2022-07-08 04:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:23 --> Total execution time: 0.0540
DEBUG - 2022-07-08 04:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:31 --> Total execution time: 0.1629
DEBUG - 2022-07-08 04:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:38 --> Total execution time: 0.0553
DEBUG - 2022-07-08 04:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:41 --> Total execution time: 0.0766
DEBUG - 2022-07-08 04:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:42 --> Total execution time: 0.0799
DEBUG - 2022-07-08 04:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:32:53 --> Total execution time: 1.5374
DEBUG - 2022-07-08 04:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:06 --> Total execution time: 1.4570
DEBUG - 2022-07-08 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:13 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:13 --> Total execution time: 0.1536
DEBUG - 2022-07-08 04:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:19 --> Total execution time: 0.0492
DEBUG - 2022-07-08 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:32 --> Total execution time: 0.0577
DEBUG - 2022-07-08 04:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:34 --> Total execution time: 0.0568
DEBUG - 2022-07-08 04:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:33:38 --> Total execution time: 0.0606
DEBUG - 2022-07-08 04:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:38 --> Total execution time: 0.0700
DEBUG - 2022-07-08 04:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:40 --> Total execution time: 0.0544
DEBUG - 2022-07-08 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:41 --> Total execution time: 0.0545
DEBUG - 2022-07-08 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 14:33:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 14:33:42 --> Total execution time: 0.1973
DEBUG - 2022-07-08 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:46 --> Total execution time: 0.0539
DEBUG - 2022-07-08 04:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:33:52 --> Total execution time: 0.0726
DEBUG - 2022-07-08 04:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:04:08 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 04:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:34:10 --> Total execution time: 0.0595
DEBUG - 2022-07-08 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:34:24 --> Total execution time: 0.0519
DEBUG - 2022-07-08 04:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:00 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:00 --> Total execution time: 0.1170
DEBUG - 2022-07-08 04:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:01 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:01 --> Total execution time: 0.0532
DEBUG - 2022-07-08 04:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:05 --> Total execution time: 0.0495
DEBUG - 2022-07-08 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:07:07 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 04:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:15 --> Total execution time: 0.0613
DEBUG - 2022-07-08 04:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:24 --> Total execution time: 0.1063
DEBUG - 2022-07-08 04:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:38 --> Total execution time: 0.0367
DEBUG - 2022-07-08 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:46 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:46 --> Total execution time: 0.0741
DEBUG - 2022-07-08 04:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:47 --> Total execution time: 0.0388
DEBUG - 2022-07-08 04:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:50 --> Total execution time: 0.0600
DEBUG - 2022-07-08 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:37:54 --> Total execution time: 0.0530
DEBUG - 2022-07-08 04:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:01 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:38:01 --> Total execution time: 0.1914
DEBUG - 2022-07-08 04:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:38:14 --> Total execution time: 0.0537
DEBUG - 2022-07-08 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:08:20 --> Total execution time: 0.0553
DEBUG - 2022-07-08 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:08:21 --> Total execution time: 0.0560
DEBUG - 2022-07-08 04:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:08:22 --> Total execution time: 0.1058
DEBUG - 2022-07-08 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:24 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:38:24 --> Total execution time: 0.0520
DEBUG - 2022-07-08 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:38:55 --> Total execution time: 0.0869
DEBUG - 2022-07-08 04:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:38:58 --> Total execution time: 0.0509
DEBUG - 2022-07-08 04:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:05 --> Total execution time: 0.0601
DEBUG - 2022-07-08 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:11 --> Total execution time: 0.0581
DEBUG - 2022-07-08 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:18 --> Total execution time: 0.1413
DEBUG - 2022-07-08 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:20 --> Total execution time: 0.1014
DEBUG - 2022-07-08 04:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:24 --> Total execution time: 0.0763
DEBUG - 2022-07-08 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:27 --> Total execution time: 0.0515
DEBUG - 2022-07-08 04:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:09:31 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:47 --> Total execution time: 0.0536
DEBUG - 2022-07-08 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:39:55 --> Total execution time: 0.0579
DEBUG - 2022-07-08 04:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:03 --> Total execution time: 0.0488
DEBUG - 2022-07-08 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:06 --> Total execution time: 0.0611
DEBUG - 2022-07-08 04:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:08 --> Total execution time: 0.0533
DEBUG - 2022-07-08 04:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:19 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:19 --> Total execution time: 0.0515
DEBUG - 2022-07-08 04:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:27 --> Total execution time: 0.0547
DEBUG - 2022-07-08 04:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:10:28 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:40:28 --> Total execution time: 0.0527
DEBUG - 2022-07-08 04:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:41:30 --> Total execution time: 0.0587
DEBUG - 2022-07-08 04:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:41:35 --> Total execution time: 0.1481
DEBUG - 2022-07-08 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:41:40 --> Total execution time: 0.0737
DEBUG - 2022-07-08 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:41:45 --> Total execution time: 0.0924
DEBUG - 2022-07-08 04:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:11:48 --> Total execution time: 0.0557
DEBUG - 2022-07-08 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:11:50 --> Total execution time: 0.0549
DEBUG - 2022-07-08 04:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:11:50 --> Total execution time: 0.1352
DEBUG - 2022-07-08 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:41:57 --> Total execution time: 0.0973
DEBUG - 2022-07-08 04:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:12:04 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:42:04 --> Total execution time: 0.0535
DEBUG - 2022-07-08 04:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:42:10 --> Total execution time: 0.0779
DEBUG - 2022-07-08 04:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:42:16 --> Total execution time: 0.0524
DEBUG - 2022-07-08 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:18 --> Total execution time: 0.2059
DEBUG - 2022-07-08 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:24 --> Total execution time: 0.0509
DEBUG - 2022-07-08 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:29 --> Total execution time: 0.0590
DEBUG - 2022-07-08 04:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:30 --> Total execution time: 0.0425
DEBUG - 2022-07-08 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:37 --> Total execution time: 0.0774
DEBUG - 2022-07-08 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:43 --> Total execution time: 0.0510
DEBUG - 2022-07-08 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:49 --> Total execution time: 0.0729
DEBUG - 2022-07-08 04:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:43:51 --> Total execution time: 0.0569
DEBUG - 2022-07-08 04:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:44:23 --> Total execution time: 0.0520
DEBUG - 2022-07-08 04:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:20 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:20 --> Total execution time: 0.1674
DEBUG - 2022-07-08 04:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:25 --> Total execution time: 0.0582
DEBUG - 2022-07-08 04:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:35 --> Total execution time: 0.0771
DEBUG - 2022-07-08 04:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:37 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:37 --> Total execution time: 0.0510
DEBUG - 2022-07-08 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:41 --> Total execution time: 0.0645
DEBUG - 2022-07-08 04:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:46 --> Total execution time: 0.0581
DEBUG - 2022-07-08 04:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:49 --> Total execution time: 0.0952
DEBUG - 2022-07-08 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:51 --> Total execution time: 0.0638
DEBUG - 2022-07-08 04:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:59 --> Total execution time: 0.0641
DEBUG - 2022-07-08 04:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:13 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:46:13 --> Total execution time: 0.1704
DEBUG - 2022-07-08 04:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:16:20 --> Total execution time: 0.0534
DEBUG - 2022-07-08 04:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:16:21 --> Total execution time: 0.0662
DEBUG - 2022-07-08 04:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:16:21 --> Total execution time: 0.1003
DEBUG - 2022-07-08 04:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:46:35 --> Total execution time: 0.1384
DEBUG - 2022-07-08 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:46:51 --> Total execution time: 0.0993
DEBUG - 2022-07-08 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:17:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:16 --> Total execution time: 1.8952
DEBUG - 2022-07-08 04:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:17:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:26 --> Total execution time: 0.1003
DEBUG - 2022-07-08 04:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:28 --> Total execution time: 0.0526
DEBUG - 2022-07-08 04:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:29 --> Total execution time: 0.0630
DEBUG - 2022-07-08 04:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:35 --> Total execution time: 0.1177
DEBUG - 2022-07-08 04:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:47 --> Total execution time: 1.4732
DEBUG - 2022-07-08 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:47:52 --> Total execution time: 0.0551
DEBUG - 2022-07-08 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:48:05 --> Total execution time: 3.9279
DEBUG - 2022-07-08 04:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:50:19 --> Total execution time: 0.2117
DEBUG - 2022-07-08 04:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:50:39 --> Total execution time: 0.1303
DEBUG - 2022-07-08 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:50:40 --> Total execution time: 0.0547
DEBUG - 2022-07-08 04:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:50:51 --> Total execution time: 0.1692
DEBUG - 2022-07-08 04:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:26:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:56:43 --> Total execution time: 0.2777
DEBUG - 2022-07-08 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:56:56 --> Total execution time: 0.0423
DEBUG - 2022-07-08 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:57:07 --> Total execution time: 0.0343
DEBUG - 2022-07-08 04:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:57:07 --> Total execution time: 0.0425
DEBUG - 2022-07-08 04:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:57:53 --> Total execution time: 0.0741
DEBUG - 2022-07-08 04:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:58:00 --> Total execution time: 0.0742
DEBUG - 2022-07-08 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:58:04 --> Total execution time: 0.0344
DEBUG - 2022-07-08 04:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:58:30 --> Total execution time: 0.1062
DEBUG - 2022-07-08 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:59:07 --> Total execution time: 0.0771
DEBUG - 2022-07-08 04:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:59:10 --> Total execution time: 0.0289
DEBUG - 2022-07-08 04:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:59:12 --> Total execution time: 0.0775
DEBUG - 2022-07-08 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:59:15 --> Total execution time: 0.0515
DEBUG - 2022-07-08 04:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:59:21 --> Total execution time: 0.0481
DEBUG - 2022-07-08 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:00:15 --> Total execution time: 0.0575
DEBUG - 2022-07-08 04:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:00:26 --> Total execution time: 0.0698
DEBUG - 2022-07-08 04:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:31:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:01:07 --> Total execution time: 0.0402
DEBUG - 2022-07-08 04:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:01:17 --> Total execution time: 0.1524
DEBUG - 2022-07-08 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:01:18 --> Total execution time: 0.0501
DEBUG - 2022-07-08 04:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:01:46 --> Total execution time: 0.0612
DEBUG - 2022-07-08 04:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:02:04 --> Total execution time: 0.0593
DEBUG - 2022-07-08 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:02:11 --> Total execution time: 0.0725
DEBUG - 2022-07-08 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:02:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 04:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:02:12 --> Total execution time: 0.0556
DEBUG - 2022-07-08 04:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:22 --> Total execution time: 0.0515
DEBUG - 2022-07-08 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:31 --> Total execution time: 0.0702
DEBUG - 2022-07-08 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:58 --> Total execution time: 0.0574
DEBUG - 2022-07-08 04:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:04:07 --> Total execution time: 0.0563
DEBUG - 2022-07-08 04:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:04:11 --> Total execution time: 0.0541
DEBUG - 2022-07-08 04:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:04:34 --> Total execution time: 0.0633
DEBUG - 2022-07-08 04:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:04:36 --> Total execution time: 0.0518
DEBUG - 2022-07-08 04:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:04:42 --> Total execution time: 0.0440
DEBUG - 2022-07-08 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:05:12 --> Total execution time: 0.0499
DEBUG - 2022-07-08 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:05:19 --> Total execution time: 0.0963
DEBUG - 2022-07-08 04:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:36:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 04:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:37:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:07:51 --> Total execution time: 0.0630
DEBUG - 2022-07-08 04:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:07:59 --> Total execution time: 0.0604
DEBUG - 2022-07-08 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:12 --> Total execution time: 0.0652
DEBUG - 2022-07-08 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:18 --> Total execution time: 0.0451
DEBUG - 2022-07-08 04:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:18 --> Total execution time: 0.0531
DEBUG - 2022-07-08 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:27 --> Total execution time: 0.0564
DEBUG - 2022-07-08 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:29 --> Total execution time: 0.0638
DEBUG - 2022-07-08 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:40 --> Total execution time: 0.0536
DEBUG - 2022-07-08 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:08:41 --> Total execution time: 0.0595
DEBUG - 2022-07-08 04:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:09:11 --> Total execution time: 0.0507
DEBUG - 2022-07-08 04:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:09:15 --> Total execution time: 0.0924
DEBUG - 2022-07-08 04:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:09:21 --> Total execution time: 0.1117
DEBUG - 2022-07-08 04:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:42:28 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:12:29 --> Total execution time: 0.1081
DEBUG - 2022-07-08 04:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 04:43:46 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:15:36 --> Total execution time: 0.2534
DEBUG - 2022-07-08 04:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:19:45 --> Total execution time: 0.1421
DEBUG - 2022-07-08 04:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:20:07 --> Total execution time: 0.2202
DEBUG - 2022-07-08 04:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:20:14 --> Total execution time: 0.1707
DEBUG - 2022-07-08 04:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:22:02 --> Total execution time: 0.0862
DEBUG - 2022-07-08 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:22:12 --> Total execution time: 0.0622
DEBUG - 2022-07-08 04:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:24:52 --> Total execution time: 0.1512
DEBUG - 2022-07-08 04:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 04:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:26:21 --> Total execution time: 0.1483
DEBUG - 2022-07-08 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:56:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:26:36 --> Total execution time: 0.0517
DEBUG - 2022-07-08 04:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:56:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:26:36 --> Total execution time: 0.0451
DEBUG - 2022-07-08 04:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:56:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:26:53 --> Total execution time: 0.0571
DEBUG - 2022-07-08 04:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:57:00 --> No URI present. Default controller set.
DEBUG - 2022-07-08 04:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:27:00 --> Total execution time: 0.0583
DEBUG - 2022-07-08 04:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:27:39 --> Total execution time: 0.2494
DEBUG - 2022-07-08 04:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:08 --> Total execution time: 0.1051
DEBUG - 2022-07-08 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:10 --> Total execution time: 0.1091
DEBUG - 2022-07-08 04:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:14 --> Total execution time: 0.0992
DEBUG - 2022-07-08 04:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:14 --> Total execution time: 0.1045
DEBUG - 2022-07-08 04:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:15 --> Total execution time: 0.0931
DEBUG - 2022-07-08 04:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:17 --> Total execution time: 0.0852
DEBUG - 2022-07-08 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:18 --> Total execution time: 0.0834
DEBUG - 2022-07-08 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:18 --> Total execution time: 0.1047
DEBUG - 2022-07-08 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:23 --> Total execution time: 0.2631
DEBUG - 2022-07-08 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:56 --> Total execution time: 0.1085
DEBUG - 2022-07-08 04:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 04:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 04:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:29:58 --> Total execution time: 0.0879
DEBUG - 2022-07-08 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:02 --> Total execution time: 0.0460
DEBUG - 2022-07-08 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:04 --> Total execution time: 0.1625
DEBUG - 2022-07-08 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:05 --> Total execution time: 0.1167
DEBUG - 2022-07-08 05:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:05 --> Total execution time: 0.1220
DEBUG - 2022-07-08 05:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:07 --> Total execution time: 0.0862
DEBUG - 2022-07-08 05:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:30:11 --> Total execution time: 0.2783
DEBUG - 2022-07-08 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:31:19 --> Total execution time: 0.0406
DEBUG - 2022-07-08 05:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:31:38 --> Total execution time: 0.0658
DEBUG - 2022-07-08 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:06 --> Total execution time: 0.0927
DEBUG - 2022-07-08 05:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:17 --> Total execution time: 0.0388
DEBUG - 2022-07-08 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:25 --> Total execution time: 0.0463
DEBUG - 2022-07-08 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:28 --> Total execution time: 0.0762
DEBUG - 2022-07-08 05:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:34 --> Total execution time: 0.1241
DEBUG - 2022-07-08 05:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:40 --> Total execution time: 0.0863
DEBUG - 2022-07-08 05:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:33:07 --> Total execution time: 0.0844
DEBUG - 2022-07-08 05:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:04:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:34:22 --> Total execution time: 0.0399
DEBUG - 2022-07-08 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:34:43 --> Total execution time: 0.0503
DEBUG - 2022-07-08 05:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:35:05 --> Total execution time: 0.0490
DEBUG - 2022-07-08 05:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:16 --> Total execution time: 0.1086
DEBUG - 2022-07-08 05:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:32 --> Total execution time: 0.0656
DEBUG - 2022-07-08 05:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:39 --> Total execution time: 0.0503
DEBUG - 2022-07-08 05:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:44 --> Total execution time: 0.0656
DEBUG - 2022-07-08 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:51 --> Total execution time: 0.0547
DEBUG - 2022-07-08 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:36:53 --> Total execution time: 0.1273
DEBUG - 2022-07-08 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:04 --> Total execution time: 0.0349
DEBUG - 2022-07-08 05:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:04 --> Total execution time: 0.0567
DEBUG - 2022-07-08 05:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:08 --> Total execution time: 0.0832
DEBUG - 2022-07-08 05:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:23 --> Total execution time: 0.0839
DEBUG - 2022-07-08 05:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:24 --> Total execution time: 0.0558
DEBUG - 2022-07-08 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:37:47 --> Total execution time: 0.0677
DEBUG - 2022-07-08 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:47 --> Total execution time: 0.0618
DEBUG - 2022-07-08 05:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:37:57 --> Total execution time: 0.0534
DEBUG - 2022-07-08 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:38:12 --> Total execution time: 0.0935
DEBUG - 2022-07-08 05:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:38:33 --> Total execution time: 0.0695
DEBUG - 2022-07-08 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:38:35 --> Total execution time: 0.0632
DEBUG - 2022-07-08 05:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:38:54 --> Total execution time: 0.0692
DEBUG - 2022-07-08 05:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:38:57 --> Total execution time: 0.0442
DEBUG - 2022-07-08 05:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:07 --> Total execution time: 0.0516
DEBUG - 2022-07-08 05:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:12 --> Total execution time: 0.0469
DEBUG - 2022-07-08 05:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:13 --> Total execution time: 0.0649
DEBUG - 2022-07-08 05:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:14 --> Total execution time: 0.0445
DEBUG - 2022-07-08 05:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:15 --> Total execution time: 0.0477
DEBUG - 2022-07-08 05:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:16 --> Total execution time: 0.0487
DEBUG - 2022-07-08 05:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:18 --> Total execution time: 0.0544
DEBUG - 2022-07-08 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:28 --> Total execution time: 0.0814
DEBUG - 2022-07-08 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:36 --> Total execution time: 0.0883
DEBUG - 2022-07-08 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:37 --> Total execution time: 0.0510
DEBUG - 2022-07-08 05:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:39 --> Total execution time: 0.0676
DEBUG - 2022-07-08 05:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:50 --> Total execution time: 0.0550
DEBUG - 2022-07-08 05:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:51 --> Total execution time: 0.0589
DEBUG - 2022-07-08 05:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:40:11 --> Total execution time: 0.0803
DEBUG - 2022-07-08 05:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:40:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:40:12 --> Total execution time: 0.0714
DEBUG - 2022-07-08 05:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:40:39 --> Total execution time: 0.0733
DEBUG - 2022-07-08 05:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:40:49 --> Total execution time: 0.0495
DEBUG - 2022-07-08 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:41:31 --> Total execution time: 0.0728
DEBUG - 2022-07-08 05:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:02 --> Total execution time: 0.0635
DEBUG - 2022-07-08 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:10 --> Total execution time: 0.0518
DEBUG - 2022-07-08 05:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:17 --> Total execution time: 0.0547
DEBUG - 2022-07-08 05:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:44 --> Total execution time: 0.0560
DEBUG - 2022-07-08 05:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:42:45 --> Total execution time: 0.0508
DEBUG - 2022-07-08 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:14:33 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:44:33 --> Total execution time: 0.0607
DEBUG - 2022-07-08 05:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:45:14 --> Total execution time: 0.0648
DEBUG - 2022-07-08 05:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:45:16 --> Total execution time: 0.0362
DEBUG - 2022-07-08 05:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:45:16 --> Total execution time: 0.0400
DEBUG - 2022-07-08 05:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:15:42 --> Total execution time: 0.0527
DEBUG - 2022-07-08 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:15:45 --> Total execution time: 0.0572
DEBUG - 2022-07-08 05:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:15:45 --> Total execution time: 0.1235
DEBUG - 2022-07-08 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:45:53 --> Total execution time: 0.0539
DEBUG - 2022-07-08 05:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:45:56 --> Total execution time: 0.0507
DEBUG - 2022-07-08 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:05 --> Total execution time: 0.1240
DEBUG - 2022-07-08 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:14 --> Total execution time: 0.1502
DEBUG - 2022-07-08 05:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:21 --> Total execution time: 0.0556
DEBUG - 2022-07-08 05:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:23 --> Total execution time: 0.0508
DEBUG - 2022-07-08 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:46:29 --> Total execution time: 0.0574
DEBUG - 2022-07-08 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:02 --> Total execution time: 0.1863
DEBUG - 2022-07-08 05:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:03 --> Total execution time: 0.1365
DEBUG - 2022-07-08 05:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:17:04 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:04 --> Total execution time: 0.1302
DEBUG - 2022-07-08 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:17 --> Total execution time: 0.1646
DEBUG - 2022-07-08 05:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:25 --> Total execution time: 0.0637
DEBUG - 2022-07-08 05:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:45 --> Total execution time: 0.0600
DEBUG - 2022-07-08 05:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:19:00 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:49:00 --> Total execution time: 0.0628
DEBUG - 2022-07-08 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:49:45 --> Total execution time: 0.0558
DEBUG - 2022-07-08 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:50:16 --> Total execution time: 0.0796
DEBUG - 2022-07-08 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:52:01 --> Total execution time: 0.1267
DEBUG - 2022-07-08 05:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:05 --> Total execution time: 0.0586
DEBUG - 2022-07-08 05:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:52:10 --> Total execution time: 0.0488
DEBUG - 2022-07-08 05:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:12 --> Total execution time: 0.0612
DEBUG - 2022-07-08 05:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:52:20 --> Total execution time: 0.0903
DEBUG - 2022-07-08 05:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:52:27 --> Total execution time: 0.1312
DEBUG - 2022-07-08 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:37 --> Total execution time: 0.0525
DEBUG - 2022-07-08 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:38 --> Total execution time: 0.0520
DEBUG - 2022-07-08 05:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:22:38 --> Total execution time: 0.1088
DEBUG - 2022-07-08 05:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:23:02 --> Total execution time: 0.0826
DEBUG - 2022-07-08 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:23:03 --> Total execution time: 0.0956
DEBUG - 2022-07-08 05:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:23:03 --> Total execution time: 0.1148
DEBUG - 2022-07-08 05:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:24:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:54:42 --> Total execution time: 0.0560
DEBUG - 2022-07-08 05:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:24:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:54:51 --> Total execution time: 0.0524
DEBUG - 2022-07-08 05:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:24:55 --> Total execution time: 0.0590
DEBUG - 2022-07-08 05:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:24:57 --> Total execution time: 0.0579
DEBUG - 2022-07-08 05:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:24:57 --> Total execution time: 0.1168
DEBUG - 2022-07-08 05:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:25:43 --> Total execution time: 0.0687
DEBUG - 2022-07-08 05:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:25:44 --> Total execution time: 0.0573
DEBUG - 2022-07-08 05:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:25:44 --> Total execution time: 0.1092
DEBUG - 2022-07-08 05:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:26:19 --> Total execution time: 0.0569
DEBUG - 2022-07-08 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:56:24 --> Total execution time: 0.0814
DEBUG - 2022-07-08 05:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:27:29 --> Total execution time: 0.1267
DEBUG - 2022-07-08 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:27:30 --> Total execution time: 0.0609
DEBUG - 2022-07-08 05:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:27:30 --> Total execution time: 0.1047
DEBUG - 2022-07-08 05:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:27:36 --> Total execution time: 0.0661
DEBUG - 2022-07-08 05:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:27:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:57:57 --> Total execution time: 2.9922
DEBUG - 2022-07-08 05:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:28:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:28:19 --> 404 Page Not Found: Assets/images
DEBUG - 2022-07-08 05:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:58:48 --> Total execution time: 0.0630
DEBUG - 2022-07-08 05:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:58:53 --> Total execution time: 0.1431
DEBUG - 2022-07-08 05:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:05 --> Total execution time: 0.0648
DEBUG - 2022-07-08 05:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 15:59:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 15:59:06 --> Total execution time: 0.1868
DEBUG - 2022-07-08 05:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:17 --> Total execution time: 0.0606
DEBUG - 2022-07-08 05:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:27 --> Total execution time: 0.0832
DEBUG - 2022-07-08 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:29 --> Total execution time: 0.0625
DEBUG - 2022-07-08 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:32 --> Total execution time: 0.0608
DEBUG - 2022-07-08 05:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:35 --> Total execution time: 0.0742
DEBUG - 2022-07-08 05:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:38 --> Total execution time: 0.0792
DEBUG - 2022-07-08 05:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:51 --> Total execution time: 0.0676
DEBUG - 2022-07-08 05:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:51 --> Total execution time: 0.0634
DEBUG - 2022-07-08 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:58 --> Total execution time: 0.0656
DEBUG - 2022-07-08 05:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:59 --> Total execution time: 0.0542
DEBUG - 2022-07-08 05:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:02 --> Total execution time: 1.5649
DEBUG - 2022-07-08 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:08 --> Total execution time: 0.0628
DEBUG - 2022-07-08 05:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:30:09 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:09 --> Total execution time: 0.0699
DEBUG - 2022-07-08 05:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:19 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:19 --> Total execution time: 0.0365
DEBUG - 2022-07-08 05:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:23 --> Total execution time: 0.1359
DEBUG - 2022-07-08 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:31:27 --> 404 Page Not Found: Terms/index
DEBUG - 2022-07-08 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:31 --> Total execution time: 0.0795
DEBUG - 2022-07-08 05:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:32 --> Total execution time: 0.0532
DEBUG - 2022-07-08 05:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:32 --> Total execution time: 0.0703
DEBUG - 2022-07-08 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:33 --> Total execution time: 0.0544
DEBUG - 2022-07-08 05:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:33 --> Total execution time: 0.1096
DEBUG - 2022-07-08 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:35 --> Total execution time: 0.0584
DEBUG - 2022-07-08 05:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:37 --> Total execution time: 0.0562
DEBUG - 2022-07-08 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:01:54 --> Total execution time: 0.0528
DEBUG - 2022-07-08 05:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:09 --> Total execution time: 0.0742
DEBUG - 2022-07-08 05:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:10 --> Total execution time: 0.0745
DEBUG - 2022-07-08 05:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:19 --> Total execution time: 0.1926
DEBUG - 2022-07-08 05:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:20 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:20 --> Total execution time: 0.0871
DEBUG - 2022-07-08 05:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:32:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:24 --> Total execution time: 1.4462
DEBUG - 2022-07-08 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:32:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 05:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:32 --> Total execution time: 0.1304
DEBUG - 2022-07-08 05:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:55 --> Total execution time: 0.1521
DEBUG - 2022-07-08 05:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:56 --> Total execution time: 0.0847
DEBUG - 2022-07-08 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:00 --> Total execution time: 0.0877
DEBUG - 2022-07-08 05:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:11 --> Total execution time: 0.0783
DEBUG - 2022-07-08 05:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:14 --> Total execution time: 0.1207
DEBUG - 2022-07-08 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:24 --> Total execution time: 0.0778
DEBUG - 2022-07-08 05:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:34 --> Total execution time: 0.0598
DEBUG - 2022-07-08 05:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:38 --> Total execution time: 0.0676
DEBUG - 2022-07-08 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:41 --> Total execution time: 0.0521
DEBUG - 2022-07-08 05:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:43 --> Total execution time: 0.0662
DEBUG - 2022-07-08 05:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:33:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:03:57 --> Total execution time: 0.1546
DEBUG - 2022-07-08 05:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:04:27 --> Total execution time: 0.0486
DEBUG - 2022-07-08 05:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:04:27 --> Total execution time: 0.0468
DEBUG - 2022-07-08 05:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:04:41 --> Total execution time: 0.0427
DEBUG - 2022-07-08 05:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:04:53 --> Total execution time: 0.0907
DEBUG - 2022-07-08 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:04:55 --> Total execution time: 0.0315
DEBUG - 2022-07-08 05:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:03 --> Total execution time: 0.0539
DEBUG - 2022-07-08 05:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:10 --> Total execution time: 0.0750
DEBUG - 2022-07-08 05:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:20 --> Total execution time: 0.0430
DEBUG - 2022-07-08 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:23 --> Total execution time: 0.0673
DEBUG - 2022-07-08 05:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:28 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:28 --> Total execution time: 0.0477
DEBUG - 2022-07-08 05:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:30 --> Total execution time: 0.0468
DEBUG - 2022-07-08 05:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:31 --> Total execution time: 0.0645
DEBUG - 2022-07-08 05:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:32 --> Total execution time: 0.1159
DEBUG - 2022-07-08 05:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:34 --> Total execution time: 0.1179
DEBUG - 2022-07-08 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:38 --> Total execution time: 0.1332
DEBUG - 2022-07-08 05:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:47 --> Total execution time: 0.0554
DEBUG - 2022-07-08 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:05:50 --> Total execution time: 0.0554
DEBUG - 2022-07-08 05:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:56 --> Total execution time: 0.0671
DEBUG - 2022-07-08 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:58 --> Total execution time: 0.0575
DEBUG - 2022-07-08 05:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:35:58 --> Total execution time: 0.1072
DEBUG - 2022-07-08 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:12 --> Total execution time: 0.0611
DEBUG - 2022-07-08 05:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:18 --> Total execution time: 0.0722
DEBUG - 2022-07-08 05:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:23 --> Total execution time: 0.0565
DEBUG - 2022-07-08 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:27 --> Total execution time: 0.1611
DEBUG - 2022-07-08 05:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:45 --> Total execution time: 0.0679
DEBUG - 2022-07-08 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:06:47 --> Total execution time: 0.0931
DEBUG - 2022-07-08 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:08:11 --> Total execution time: 0.0856
DEBUG - 2022-07-08 05:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:08:17 --> Total execution time: 0.0657
DEBUG - 2022-07-08 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:08:50 --> Total execution time: 0.0592
DEBUG - 2022-07-08 05:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:07 --> Total execution time: 0.0518
DEBUG - 2022-07-08 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:15 --> Total execution time: 0.0581
DEBUG - 2022-07-08 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:20 --> Total execution time: 0.0781
DEBUG - 2022-07-08 05:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 05:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:26 --> Total execution time: 0.1123
DEBUG - 2022-07-08 05:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:29 --> Total execution time: 0.0549
DEBUG - 2022-07-08 05:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:31 --> Total execution time: 0.1458
DEBUG - 2022-07-08 05:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:38 --> Total execution time: 0.0546
DEBUG - 2022-07-08 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:39 --> Total execution time: 0.0574
DEBUG - 2022-07-08 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:42 --> Total execution time: 0.0811
DEBUG - 2022-07-08 05:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:46 --> Total execution time: 0.0659
DEBUG - 2022-07-08 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:47 --> Total execution time: 0.0526
DEBUG - 2022-07-08 05:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:47 --> Total execution time: 0.0624
DEBUG - 2022-07-08 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:51 --> Total execution time: 0.0510
DEBUG - 2022-07-08 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:39:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:09:54 --> Total execution time: 0.1669
DEBUG - 2022-07-08 05:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:02 --> Total execution time: 0.3689
DEBUG - 2022-07-08 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:44 --> Total execution time: 0.0925
DEBUG - 2022-07-08 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:46 --> Total execution time: 0.1002
DEBUG - 2022-07-08 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:49 --> Total execution time: 0.1069
DEBUG - 2022-07-08 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:51 --> Total execution time: 0.1145
DEBUG - 2022-07-08 05:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:55 --> Total execution time: 0.0768
DEBUG - 2022-07-08 05:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:10:56 --> Total execution time: 0.0985
DEBUG - 2022-07-08 05:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:01 --> Total execution time: 0.1551
DEBUG - 2022-07-08 05:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:10 --> Total execution time: 0.0592
DEBUG - 2022-07-08 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:16 --> Total execution time: 0.0691
DEBUG - 2022-07-08 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:20 --> Total execution time: 0.0572
DEBUG - 2022-07-08 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:23 --> Total execution time: 0.1476
DEBUG - 2022-07-08 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:31 --> Total execution time: 0.0613
DEBUG - 2022-07-08 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:31 --> Total execution time: 0.1341
DEBUG - 2022-07-08 05:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:44 --> Total execution time: 0.0938
DEBUG - 2022-07-08 05:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:11:51 --> Total execution time: 0.0794
DEBUG - 2022-07-08 05:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:00 --> Total execution time: 0.0919
DEBUG - 2022-07-08 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:03 --> Total execution time: 0.0903
DEBUG - 2022-07-08 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:03 --> Total execution time: 0.0996
DEBUG - 2022-07-08 05:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:05 --> Total execution time: 0.0589
DEBUG - 2022-07-08 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:08 --> Total execution time: 0.0742
DEBUG - 2022-07-08 05:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:09 --> Total execution time: 0.0548
DEBUG - 2022-07-08 05:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:12 --> Total execution time: 0.0570
DEBUG - 2022-07-08 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:14 --> Total execution time: 0.0675
DEBUG - 2022-07-08 05:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:19 --> Total execution time: 0.0547
DEBUG - 2022-07-08 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:12:38 --> Total execution time: 0.1104
DEBUG - 2022-07-08 05:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:13:04 --> Total execution time: 0.0567
DEBUG - 2022-07-08 05:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:13:10 --> Total execution time: 0.0601
DEBUG - 2022-07-08 05:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:13:41 --> Total execution time: 0.0529
DEBUG - 2022-07-08 05:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:14:10 --> Total execution time: 0.1763
DEBUG - 2022-07-08 05:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:44:28 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:14:28 --> Total execution time: 0.1409
DEBUG - 2022-07-08 05:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:15:08 --> Total execution time: 0.0603
DEBUG - 2022-07-08 05:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:23 --> Total execution time: 0.0679
DEBUG - 2022-07-08 05:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:26 --> Total execution time: 0.0622
DEBUG - 2022-07-08 05:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:28 --> Total execution time: 0.0611
DEBUG - 2022-07-08 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:30 --> Total execution time: 0.0739
DEBUG - 2022-07-08 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:33 --> Total execution time: 0.1520
DEBUG - 2022-07-08 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:35 --> Total execution time: 0.0826
DEBUG - 2022-07-08 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:37 --> Total execution time: 0.0841
DEBUG - 2022-07-08 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:37 --> Total execution time: 0.0621
DEBUG - 2022-07-08 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:39 --> Total execution time: 0.0755
DEBUG - 2022-07-08 05:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:44 --> Total execution time: 0.0549
DEBUG - 2022-07-08 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:16:54 --> Total execution time: 0.0619
DEBUG - 2022-07-08 05:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:01 --> Total execution time: 0.0582
DEBUG - 2022-07-08 05:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:15 --> Total execution time: 0.0602
DEBUG - 2022-07-08 05:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:27 --> Total execution time: 0.0862
DEBUG - 2022-07-08 05:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:53 --> Total execution time: 0.0846
DEBUG - 2022-07-08 05:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:59 --> Total execution time: 0.0814
DEBUG - 2022-07-08 05:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:18:17 --> Total execution time: 0.0733
DEBUG - 2022-07-08 05:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:18:23 --> Total execution time: 0.1037
DEBUG - 2022-07-08 05:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:48:33 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:18:34 --> Total execution time: 0.0400
DEBUG - 2022-07-08 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:18:56 --> Total execution time: 0.0519
DEBUG - 2022-07-08 05:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:49:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:19:18 --> Total execution time: 0.0522
DEBUG - 2022-07-08 05:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:19:26 --> Total execution time: 0.0509
DEBUG - 2022-07-08 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:49:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:19:41 --> Total execution time: 0.0536
DEBUG - 2022-07-08 05:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:49:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:19:44 --> Total execution time: 0.0540
DEBUG - 2022-07-08 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:20:16 --> Total execution time: 0.0643
DEBUG - 2022-07-08 05:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:20:39 --> Total execution time: 0.0620
DEBUG - 2022-07-08 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:21:35 --> Total execution time: 0.0562
DEBUG - 2022-07-08 05:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 05:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:22:19 --> Total execution time: 0.0606
DEBUG - 2022-07-08 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:52:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:22:30 --> Total execution time: 0.1611
DEBUG - 2022-07-08 05:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:23:39 --> Total execution time: 0.0684
DEBUG - 2022-07-08 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:54:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:24:43 --> Total execution time: 0.0520
DEBUG - 2022-07-08 05:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:25:33 --> Total execution time: 0.1358
DEBUG - 2022-07-08 05:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:25:49 --> Total execution time: 0.0706
DEBUG - 2022-07-08 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:57:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 05:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 05:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:29:14 --> Total execution time: 0.2333
DEBUG - 2022-07-08 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 05:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 05:59:30 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:30:02 --> Total execution time: 0.1075
DEBUG - 2022-07-08 06:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:39:18 --> Total execution time: 0.1220
DEBUG - 2022-07-08 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:53:48 --> Total execution time: 0.1463
DEBUG - 2022-07-08 06:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:25:28 --> No URI present. Default controller set.
DEBUG - 2022-07-08 06:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:55:29 --> Total execution time: 0.1616
DEBUG - 2022-07-08 06:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:25:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 06:25:33 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 06:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:58:50 --> Total execution time: 0.1070
DEBUG - 2022-07-08 06:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:59:05 --> Total execution time: 0.1250
DEBUG - 2022-07-08 06:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:59:23 --> Total execution time: 0.1121
DEBUG - 2022-07-08 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:59:28 --> Total execution time: 0.0857
DEBUG - 2022-07-08 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:59:59 --> Total execution time: 0.0756
DEBUG - 2022-07-08 06:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:00:04 --> Total execution time: 0.2932
DEBUG - 2022-07-08 06:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:30:04 --> No URI present. Default controller set.
DEBUG - 2022-07-08 06:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:00:04 --> Total execution time: 0.1163
DEBUG - 2022-07-08 06:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:00:09 --> Total execution time: 0.2945
DEBUG - 2022-07-08 06:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:12:40 --> Total execution time: 0.2270
DEBUG - 2022-07-08 06:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:15 --> Total execution time: 0.0969
DEBUG - 2022-07-08 06:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:22 --> Total execution time: 0.0730
DEBUG - 2022-07-08 06:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 06:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:23 --> Total execution time: 0.0475
DEBUG - 2022-07-08 06:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:30 --> Total execution time: 0.0631
DEBUG - 2022-07-08 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:36 --> Total execution time: 0.0597
DEBUG - 2022-07-08 06:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 06:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:39 --> Total execution time: 0.1350
DEBUG - 2022-07-08 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:45 --> Total execution time: 0.0545
DEBUG - 2022-07-08 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:08 --> Total execution time: 0.0737
DEBUG - 2022-07-08 06:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:40 --> Total execution time: 0.0591
DEBUG - 2022-07-08 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:31 --> Total execution time: 0.0590
DEBUG - 2022-07-08 06:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:36 --> Total execution time: 0.0589
DEBUG - 2022-07-08 06:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:59 --> Total execution time: 0.0341
DEBUG - 2022-07-08 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:08 --> Total execution time: 0.0552
DEBUG - 2022-07-08 06:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:14 --> Total execution time: 0.0655
DEBUG - 2022-07-08 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:48:27 --> Total execution time: 0.0570
DEBUG - 2022-07-08 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:31 --> Total execution time: 0.0844
DEBUG - 2022-07-08 06:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:40 --> Total execution time: 0.0561
DEBUG - 2022-07-08 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:45 --> Total execution time: 0.0600
DEBUG - 2022-07-08 06:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:18:50 --> Total execution time: 0.0534
DEBUG - 2022-07-08 06:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 06:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 06:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 06:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:23:36 --> Total execution time: 0.3845
DEBUG - 2022-07-08 17:23:36 --> Total execution time: 0.2589
DEBUG - 2022-07-08 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:30:04 --> Total execution time: 0.2168
DEBUG - 2022-07-08 07:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:32:59 --> Total execution time: 0.0761
DEBUG - 2022-07-08 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:05 --> Total execution time: 0.0666
DEBUG - 2022-07-08 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:15 --> Total execution time: 0.0633
DEBUG - 2022-07-08 07:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:20 --> Total execution time: 0.0899
DEBUG - 2022-07-08 07:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:23 --> Total execution time: 0.0645
DEBUG - 2022-07-08 07:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:49 --> Total execution time: 0.1993
DEBUG - 2022-07-08 07:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:33:57 --> Total execution time: 0.0900
DEBUG - 2022-07-08 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:20 --> Total execution time: 0.0624
DEBUG - 2022-07-08 07:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:25 --> Total execution time: 0.1665
DEBUG - 2022-07-08 07:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:26 --> Total execution time: 0.0778
DEBUG - 2022-07-08 07:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:34 --> Total execution time: 0.0847
DEBUG - 2022-07-08 07:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:34 --> Total execution time: 0.1873
DEBUG - 2022-07-08 07:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:34 --> Total execution time: 0.0925
DEBUG - 2022-07-08 07:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:35 --> Total execution time: 0.0854
DEBUG - 2022-07-08 07:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:39 --> Total execution time: 0.2066
DEBUG - 2022-07-08 07:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:47 --> Total execution time: 0.0790
DEBUG - 2022-07-08 07:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:48 --> Total execution time: 0.0798
DEBUG - 2022-07-08 07:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:55 --> Total execution time: 0.0795
DEBUG - 2022-07-08 07:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:56 --> Total execution time: 0.1019
DEBUG - 2022-07-08 07:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:56 --> Total execution time: 0.0757
DEBUG - 2022-07-08 07:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:58 --> Total execution time: 0.0819
DEBUG - 2022-07-08 07:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:58 --> Total execution time: 0.0798
DEBUG - 2022-07-08 07:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:59 --> Total execution time: 0.0834
DEBUG - 2022-07-08 07:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:34:59 --> Total execution time: 0.0711
DEBUG - 2022-07-08 07:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:35:03 --> Total execution time: 0.7886
DEBUG - 2022-07-08 07:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:37:03 --> Total execution time: 0.0461
DEBUG - 2022-07-08 07:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:37:06 --> Total execution time: 0.0494
DEBUG - 2022-07-08 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:37:10 --> Total execution time: 0.0579
DEBUG - 2022-07-08 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:37:22 --> Total execution time: 0.0606
DEBUG - 2022-07-08 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:39:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:39:42 --> Total execution time: 0.1074
DEBUG - 2022-07-08 07:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:40:42 --> Total execution time: 0.0648
DEBUG - 2022-07-08 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:40:43 --> Total execution time: 0.2416
DEBUG - 2022-07-08 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:40:49 --> Total execution time: 0.0507
DEBUG - 2022-07-08 07:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:11:08 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 07:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:41:41 --> Total execution time: 0.1891
DEBUG - 2022-07-08 07:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:13:45 --> Total execution time: 0.1343
DEBUG - 2022-07-08 07:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:13:53 --> Total execution time: 0.0992
DEBUG - 2022-07-08 07:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:44:23 --> Total execution time: 0.3354
DEBUG - 2022-07-08 17:44:23 --> Total execution time: 0.2042
DEBUG - 2022-07-08 07:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:44:53 --> Total execution time: 0.1132
DEBUG - 2022-07-08 07:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:12 --> Total execution time: 0.1505
DEBUG - 2022-07-08 07:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:17 --> Total execution time: 0.1003
DEBUG - 2022-07-08 07:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:20 --> Total execution time: 0.0631
DEBUG - 2022-07-08 07:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:24 --> Total execution time: 0.1325
DEBUG - 2022-07-08 07:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:24 --> Total execution time: 0.1360
DEBUG - 2022-07-08 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:27 --> Total execution time: 0.0990
DEBUG - 2022-07-08 07:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:28 --> Total execution time: 0.0688
DEBUG - 2022-07-08 07:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:32 --> Total execution time: 0.2224
DEBUG - 2022-07-08 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:35 --> Total execution time: 0.1916
DEBUG - 2022-07-08 07:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:38 --> Total execution time: 0.1163
DEBUG - 2022-07-08 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:39 --> Total execution time: 0.1129
DEBUG - 2022-07-08 07:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:45:43 --> Total execution time: 0.0908
DEBUG - 2022-07-08 07:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:46:07 --> Total execution time: 0.1158
DEBUG - 2022-07-08 07:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:46:13 --> Total execution time: 0.3191
DEBUG - 2022-07-08 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:46:19 --> Total execution time: 0.1333
DEBUG - 2022-07-08 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:46:40 --> Total execution time: 0.2054
DEBUG - 2022-07-08 07:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:47:10 --> Total execution time: 0.2282
DEBUG - 2022-07-08 07:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:47:41 --> Total execution time: 0.1034
DEBUG - 2022-07-08 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:47:55 --> Total execution time: 0.1251
DEBUG - 2022-07-08 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:48:19 --> Total execution time: 0.3566
DEBUG - 2022-07-08 07:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:48:32 --> Total execution time: 0.1125
DEBUG - 2022-07-08 07:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:48:52 --> Total execution time: 0.0756
DEBUG - 2022-07-08 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:49:28 --> Total execution time: 0.1261
DEBUG - 2022-07-08 07:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:52:34 --> Total execution time: 0.2246
DEBUG - 2022-07-08 07:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:23:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:53:39 --> Total execution time: 0.0985
DEBUG - 2022-07-08 07:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:23:56 --> Total execution time: 0.0395
DEBUG - 2022-07-08 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:23:58 --> Total execution time: 0.0511
DEBUG - 2022-07-08 07:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:23:58 --> Total execution time: 0.1091
DEBUG - 2022-07-08 07:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:09 --> Total execution time: 0.0676
DEBUG - 2022-07-08 07:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:25 --> Total execution time: 0.0619
DEBUG - 2022-07-08 07:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:29 --> Total execution time: 0.0597
DEBUG - 2022-07-08 07:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:30 --> Total execution time: 0.0579
DEBUG - 2022-07-08 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:35 --> Total execution time: 0.1145
DEBUG - 2022-07-08 07:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:39 --> Total execution time: 0.0554
DEBUG - 2022-07-08 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:54:41 --> Total execution time: 0.0791
DEBUG - 2022-07-08 07:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:26:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:56:23 --> Total execution time: 0.0603
DEBUG - 2022-07-08 07:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:26:26 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:56:26 --> Total execution time: 0.0433
DEBUG - 2022-07-08 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:00:22 --> Total execution time: 0.1319
DEBUG - 2022-07-08 07:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:00:47 --> Total execution time: 0.0658
DEBUG - 2022-07-08 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:03:45 --> Total execution time: 0.2010
DEBUG - 2022-07-08 07:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:03:51 --> Total execution time: 0.0719
DEBUG - 2022-07-08 07:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:05:01 --> Total execution time: 0.0618
DEBUG - 2022-07-08 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:05:27 --> Total execution time: 0.0574
DEBUG - 2022-07-08 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:05:34 --> Total execution time: 0.0607
DEBUG - 2022-07-08 07:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:06:17 --> Total execution time: 0.0706
DEBUG - 2022-07-08 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:37:07 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 07:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:37:18 --> 404 Page Not Found: Lessons/nimbuss-delivery-issues-handle-important
DEBUG - 2022-07-08 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:19 --> Total execution time: 0.0551
DEBUG - 2022-07-08 07:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:34 --> Total execution time: 0.0627
DEBUG - 2022-07-08 07:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:47 --> Total execution time: 0.1364
DEBUG - 2022-07-08 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:48 --> Total execution time: 0.0513
DEBUG - 2022-07-08 07:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:50 --> Total execution time: 0.1369
DEBUG - 2022-07-08 07:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:59 --> Total execution time: 0.0621
DEBUG - 2022-07-08 07:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:00 --> Total execution time: 0.0507
DEBUG - 2022-07-08 07:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:11 --> Total execution time: 0.0647
DEBUG - 2022-07-08 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:19 --> Total execution time: 0.0630
DEBUG - 2022-07-08 07:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:26 --> Total execution time: 0.0507
DEBUG - 2022-07-08 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:30 --> Total execution time: 0.0519
DEBUG - 2022-07-08 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:38:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:08:44 --> Total execution time: 0.0423
DEBUG - 2022-07-08 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:39:34 --> Total execution time: 0.0529
DEBUG - 2022-07-08 07:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:39:40 --> Total execution time: 0.0675
DEBUG - 2022-07-08 07:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:39:40 --> Total execution time: 0.0510
DEBUG - 2022-07-08 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:09:41 --> Total execution time: 0.0751
DEBUG - 2022-07-08 07:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:09:50 --> Total execution time: 0.0573
DEBUG - 2022-07-08 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:09:54 --> Total execution time: 0.0569
DEBUG - 2022-07-08 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:10:01 --> Total execution time: 0.0515
DEBUG - 2022-07-08 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:10:06 --> Total execution time: 0.0504
DEBUG - 2022-07-08 07:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:40:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:10:08 --> Total execution time: 0.0532
DEBUG - 2022-07-08 07:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:41:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:41:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 07:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:44:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 07:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:04 --> Total execution time: 0.1485
DEBUG - 2022-07-08 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:08 --> Total execution time: 0.1597
DEBUG - 2022-07-08 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:10 --> Total execution time: 0.0621
DEBUG - 2022-07-08 07:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:11 --> Total execution time: 0.0663
DEBUG - 2022-07-08 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:11 --> Total execution time: 0.0557
DEBUG - 2022-07-08 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:12 --> Total execution time: 0.0552
DEBUG - 2022-07-08 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:13 --> Total execution time: 0.0547
DEBUG - 2022-07-08 07:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:45:15 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:15:15 --> Total execution time: 0.0420
DEBUG - 2022-07-08 07:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:16:20 --> Total execution time: 0.0499
DEBUG - 2022-07-08 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:46:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:46:54 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 07:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:21 --> Total execution time: 0.0593
DEBUG - 2022-07-08 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:27 --> Total execution time: 0.0755
DEBUG - 2022-07-08 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:30 --> Total execution time: 0.0641
DEBUG - 2022-07-08 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:30 --> Total execution time: 0.0512
DEBUG - 2022-07-08 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:36 --> Total execution time: 0.0500
DEBUG - 2022-07-08 07:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:45 --> Total execution time: 0.0545
DEBUG - 2022-07-08 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:21:55 --> Total execution time: 0.0630
DEBUG - 2022-07-08 07:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:12 --> Total execution time: 0.0539
DEBUG - 2022-07-08 07:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:12 --> Total execution time: 0.0593
DEBUG - 2022-07-08 07:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:23 --> Total execution time: 0.0553
DEBUG - 2022-07-08 07:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:27 --> Total execution time: 0.0641
DEBUG - 2022-07-08 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:34 --> Total execution time: 0.0595
DEBUG - 2022-07-08 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:34 --> Total execution time: 0.0755
DEBUG - 2022-07-08 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:41 --> Total execution time: 0.0628
DEBUG - 2022-07-08 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:52:44 --> Total execution time: 0.0670
DEBUG - 2022-07-08 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:52:46 --> Total execution time: 0.0572
DEBUG - 2022-07-08 07:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:52:46 --> Total execution time: 0.1422
DEBUG - 2022-07-08 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:22:50 --> Total execution time: 0.0594
DEBUG - 2022-07-08 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:03 --> Total execution time: 0.0618
DEBUG - 2022-07-08 07:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:11 --> Total execution time: 0.0532
DEBUG - 2022-07-08 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:15 --> Total execution time: 0.0552
DEBUG - 2022-07-08 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:18 --> Total execution time: 0.0596
DEBUG - 2022-07-08 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:35 --> Total execution time: 0.0493
DEBUG - 2022-07-08 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:47 --> Total execution time: 0.0549
DEBUG - 2022-07-08 07:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:57 --> Total execution time: 0.0638
DEBUG - 2022-07-08 07:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:23:59 --> Total execution time: 0.0691
DEBUG - 2022-07-08 07:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:54:03 --> Total execution time: 0.0587
DEBUG - 2022-07-08 07:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:54:05 --> Total execution time: 0.0620
DEBUG - 2022-07-08 07:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:54:06 --> Total execution time: 0.0886
DEBUG - 2022-07-08 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:24:18 --> Total execution time: 0.0559
DEBUG - 2022-07-08 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:24:29 --> Total execution time: 0.0660
DEBUG - 2022-07-08 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:24:32 --> Total execution time: 0.0645
DEBUG - 2022-07-08 07:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:55:35 --> Total execution time: 0.0670
DEBUG - 2022-07-08 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:55:38 --> Total execution time: 0.0501
DEBUG - 2022-07-08 07:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:55:38 --> Total execution time: 0.0544
DEBUG - 2022-07-08 07:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:48 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:25:48 --> Total execution time: 0.0349
DEBUG - 2022-07-08 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:55:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:25:49 --> Total execution time: 0.0482
DEBUG - 2022-07-08 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:26:26 --> Total execution time: 0.0473
DEBUG - 2022-07-08 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:26:35 --> Total execution time: 0.0473
DEBUG - 2022-07-08 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:26:38 --> Total execution time: 0.0539
DEBUG - 2022-07-08 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:26:54 --> Total execution time: 0.1832
DEBUG - 2022-07-08 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:27:12 --> Total execution time: 0.0570
DEBUG - 2022-07-08 07:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:27:24 --> Total execution time: 0.0920
DEBUG - 2022-07-08 07:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:57:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:27:51 --> Total execution time: 0.0698
DEBUG - 2022-07-08 07:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:28:06 --> Total execution time: 1.8932
DEBUG - 2022-07-08 07:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 07:58:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:28:14 --> Total execution time: 0.0406
DEBUG - 2022-07-08 07:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:28:24 --> Total execution time: 0.1295
DEBUG - 2022-07-08 07:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:28:24 --> Total execution time: 0.0607
DEBUG - 2022-07-08 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:28:26 --> Total execution time: 0.0501
DEBUG - 2022-07-08 07:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:58:54 --> Total execution time: 0.0497
DEBUG - 2022-07-08 07:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:58:56 --> Total execution time: 0.0584
DEBUG - 2022-07-08 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 07:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 07:58:57 --> Total execution time: 0.0546
DEBUG - 2022-07-08 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:30:02 --> Total execution time: 0.1091
DEBUG - 2022-07-08 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:30:35 --> Total execution time: 0.1287
DEBUG - 2022-07-08 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:01:15 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:31:15 --> Total execution time: 0.0537
DEBUG - 2022-07-08 08:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:33:05 --> Total execution time: 3.9540
DEBUG - 2022-07-08 08:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:05:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:35:39 --> Total execution time: 0.1136
DEBUG - 2022-07-08 08:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:36:40 --> Total execution time: 0.0573
DEBUG - 2022-07-08 08:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:37:08 --> Total execution time: 0.0867
DEBUG - 2022-07-08 08:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:37:45 --> Total execution time: 0.0662
DEBUG - 2022-07-08 08:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:37:51 --> Total execution time: 0.0383
DEBUG - 2022-07-08 08:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:37:55 --> Total execution time: 0.0548
DEBUG - 2022-07-08 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:06 --> Total execution time: 0.1296
DEBUG - 2022-07-08 08:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:14 --> Total execution time: 0.0607
DEBUG - 2022-07-08 08:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:21 --> Total execution time: 0.0620
DEBUG - 2022-07-08 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:37 --> Total execution time: 0.0811
DEBUG - 2022-07-08 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:38 --> Total execution time: 0.0623
DEBUG - 2022-07-08 08:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:40 --> Total execution time: 0.0792
DEBUG - 2022-07-08 08:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:38:49 --> Total execution time: 0.0538
DEBUG - 2022-07-08 08:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:39:11 --> Total execution time: 0.0650
DEBUG - 2022-07-08 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:39:13 --> Total execution time: 0.0928
DEBUG - 2022-07-08 08:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:39:59 --> Total execution time: 0.0664
DEBUG - 2022-07-08 08:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:11:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:41:40 --> Total execution time: 0.0406
DEBUG - 2022-07-08 08:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:41:51 --> Total execution time: 0.0376
DEBUG - 2022-07-08 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:41:59 --> Total execution time: 0.0564
DEBUG - 2022-07-08 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:42:12 --> Total execution time: 0.0971
DEBUG - 2022-07-08 08:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 08:12:38 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 08:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:42:41 --> Total execution time: 0.0921
DEBUG - 2022-07-08 08:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:42:48 --> Total execution time: 0.0539
DEBUG - 2022-07-08 08:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:42:54 --> Total execution time: 0.0568
DEBUG - 2022-07-08 08:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:43:17 --> Total execution time: 0.1420
DEBUG - 2022-07-08 08:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:43:25 --> Total execution time: 0.0582
DEBUG - 2022-07-08 08:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:43:27 --> Total execution time: 0.0711
DEBUG - 2022-07-08 08:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:44:17 --> Total execution time: 0.0758
DEBUG - 2022-07-08 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:44:23 --> Total execution time: 0.0549
DEBUG - 2022-07-08 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:08 --> Total execution time: 0.1502
DEBUG - 2022-07-08 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:13 --> Total execution time: 0.0632
DEBUG - 2022-07-08 08:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:23 --> Total execution time: 0.0511
DEBUG - 2022-07-08 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:42 --> Total execution time: 0.1261
DEBUG - 2022-07-08 08:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:46 --> Total execution time: 0.0855
DEBUG - 2022-07-08 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:46:58 --> Total execution time: 0.0515
DEBUG - 2022-07-08 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:47:41 --> Total execution time: 0.0596
DEBUG - 2022-07-08 08:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:48:36 --> Total execution time: 0.1293
DEBUG - 2022-07-08 08:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:49:51 --> Total execution time: 0.0633
DEBUG - 2022-07-08 08:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:51:32 --> Total execution time: 0.0571
DEBUG - 2022-07-08 08:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:51:42 --> Total execution time: 0.0506
DEBUG - 2022-07-08 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:53:52 --> Total execution time: 0.2370
DEBUG - 2022-07-08 08:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:53:56 --> Total execution time: 0.0606
DEBUG - 2022-07-08 08:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:53:59 --> Total execution time: 0.0629
DEBUG - 2022-07-08 08:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:56:28 --> Total execution time: 0.0663
DEBUG - 2022-07-08 08:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:17 --> Total execution time: 0.1281
DEBUG - 2022-07-08 08:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:18 --> Total execution time: 0.0404
DEBUG - 2022-07-08 08:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:22 --> Total execution time: 0.0356
DEBUG - 2022-07-08 08:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:30 --> Total execution time: 0.0640
DEBUG - 2022-07-08 08:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:46 --> Total execution time: 0.0500
DEBUG - 2022-07-08 08:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:00:07 --> Total execution time: 0.0668
DEBUG - 2022-07-08 08:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:00:09 --> Total execution time: 0.0604
DEBUG - 2022-07-08 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:00:19 --> Total execution time: 0.0751
DEBUG - 2022-07-08 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:33:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:03:05 --> Total execution time: 0.1375
DEBUG - 2022-07-08 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:33:06 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:03:06 --> Total execution time: 0.0517
DEBUG - 2022-07-08 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:34:59 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:04:59 --> Total execution time: 0.0386
DEBUG - 2022-07-08 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:35:34 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:34 --> Total execution time: 0.0400
DEBUG - 2022-07-08 08:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:32 --> Total execution time: 0.1233
DEBUG - 2022-07-08 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:39 --> Total execution time: 0.0600
DEBUG - 2022-07-08 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:39 --> Total execution time: 0.0536
DEBUG - 2022-07-08 08:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:39 --> Total execution time: 0.0875
DEBUG - 2022-07-08 08:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:40 --> Total execution time: 0.0515
DEBUG - 2022-07-08 08:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:40 --> Total execution time: 0.0714
DEBUG - 2022-07-08 08:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:41 --> Total execution time: 0.1028
DEBUG - 2022-07-08 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:41 --> Total execution time: 0.0600
DEBUG - 2022-07-08 08:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:39:41 --> Total execution time: 0.1162
DEBUG - 2022-07-08 08:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:03 --> Total execution time: 0.0669
DEBUG - 2022-07-08 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:04 --> Total execution time: 0.0540
DEBUG - 2022-07-08 08:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:04 --> Total execution time: 0.1143
DEBUG - 2022-07-08 08:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:11 --> Total execution time: 0.0576
DEBUG - 2022-07-08 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:12 --> Total execution time: 0.0495
DEBUG - 2022-07-08 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:13 --> Total execution time: 0.0723
DEBUG - 2022-07-08 08:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:13 --> Total execution time: 0.0845
DEBUG - 2022-07-08 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:16 --> Total execution time: 0.0553
DEBUG - 2022-07-08 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:17 --> Total execution time: 0.0524
DEBUG - 2022-07-08 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:17 --> Total execution time: 0.1042
DEBUG - 2022-07-08 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:22 --> Total execution time: 0.0629
DEBUG - 2022-07-08 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:28 --> Total execution time: 0.0592
DEBUG - 2022-07-08 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:29 --> Total execution time: 0.0528
DEBUG - 2022-07-08 08:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:29 --> Total execution time: 0.0647
DEBUG - 2022-07-08 08:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:30 --> Total execution time: 0.0515
DEBUG - 2022-07-08 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:31 --> Total execution time: 0.0533
DEBUG - 2022-07-08 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:32 --> Total execution time: 0.1142
DEBUG - 2022-07-08 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:35 --> Total execution time: 0.0509
DEBUG - 2022-07-08 08:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:45 --> Total execution time: 0.0602
DEBUG - 2022-07-08 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:47 --> Total execution time: 0.0578
DEBUG - 2022-07-08 08:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:40:47 --> Total execution time: 0.0972
DEBUG - 2022-07-08 08:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:59 --> Total execution time: 0.0509
DEBUG - 2022-07-08 08:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:11:05 --> Total execution time: 0.0513
DEBUG - 2022-07-08 08:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:08 --> Total execution time: 0.0564
DEBUG - 2022-07-08 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:09 --> Total execution time: 0.0541
DEBUG - 2022-07-08 08:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:09 --> Total execution time: 0.0953
DEBUG - 2022-07-08 08:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:11:18 --> Total execution time: 0.0516
DEBUG - 2022-07-08 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:22 --> Total execution time: 0.0509
DEBUG - 2022-07-08 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:23 --> Total execution time: 0.0497
DEBUG - 2022-07-08 08:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:41:23 --> Total execution time: 0.0995
DEBUG - 2022-07-08 08:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:15:21 --> Total execution time: 0.1229
DEBUG - 2022-07-08 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:27 --> Total execution time: 0.0439
DEBUG - 2022-07-08 08:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:28 --> Total execution time: 0.0572
DEBUG - 2022-07-08 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:29 --> Total execution time: 0.0514
DEBUG - 2022-07-08 08:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:29 --> Total execution time: 0.1017
DEBUG - 2022-07-08 08:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:34 --> Total execution time: 0.0639
DEBUG - 2022-07-08 08:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:36 --> Total execution time: 0.0638
DEBUG - 2022-07-08 08:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:36 --> Total execution time: 0.1030
DEBUG - 2022-07-08 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:43 --> Total execution time: 0.0530
DEBUG - 2022-07-08 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:43 --> Total execution time: 0.0587
DEBUG - 2022-07-08 08:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:43 --> Total execution time: 0.1071
DEBUG - 2022-07-08 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:44 --> Total execution time: 0.0574
DEBUG - 2022-07-08 08:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:44 --> Total execution time: 0.1228
DEBUG - 2022-07-08 08:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:48 --> Total execution time: 0.0542
DEBUG - 2022-07-08 08:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:49 --> Total execution time: 0.0538
DEBUG - 2022-07-08 08:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:49 --> Total execution time: 0.1110
DEBUG - 2022-07-08 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:51 --> Total execution time: 0.0494
DEBUG - 2022-07-08 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:52 --> Total execution time: 0.0561
DEBUG - 2022-07-08 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:45:52 --> Total execution time: 0.0720
DEBUG - 2022-07-08 08:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:15:54 --> Total execution time: 0.0546
DEBUG - 2022-07-08 08:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:13 --> Total execution time: 0.0577
DEBUG - 2022-07-08 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:14 --> Total execution time: 0.0497
DEBUG - 2022-07-08 08:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:15 --> Total execution time: 0.1037
DEBUG - 2022-07-08 08:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:18 --> Total execution time: 0.0584
DEBUG - 2022-07-08 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:19 --> Total execution time: 0.0544
DEBUG - 2022-07-08 08:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:19 --> Total execution time: 0.1300
DEBUG - 2022-07-08 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:21 --> Total execution time: 0.0504
DEBUG - 2022-07-08 08:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:22 --> Total execution time: 0.0501
DEBUG - 2022-07-08 08:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:22 --> Total execution time: 0.1152
DEBUG - 2022-07-08 08:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:25 --> Total execution time: 0.0524
DEBUG - 2022-07-08 08:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:26 --> Total execution time: 0.0539
DEBUG - 2022-07-08 08:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:27 --> Total execution time: 0.1163
DEBUG - 2022-07-08 08:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:32 --> Total execution time: 0.0549
DEBUG - 2022-07-08 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:34 --> Total execution time: 0.0559
DEBUG - 2022-07-08 08:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:34 --> Total execution time: 0.1226
DEBUG - 2022-07-08 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:35 --> Total execution time: 0.0721
DEBUG - 2022-07-08 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:36 --> Total execution time: 0.0576
DEBUG - 2022-07-08 08:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:36 --> Total execution time: 0.0899
DEBUG - 2022-07-08 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:16:38 --> Total execution time: 0.0563
DEBUG - 2022-07-08 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:49 --> Total execution time: 0.0529
DEBUG - 2022-07-08 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:50 --> Total execution time: 0.0576
DEBUG - 2022-07-08 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:46:51 --> Total execution time: 0.1256
DEBUG - 2022-07-08 08:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:46:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:16:53 --> Total execution time: 0.0623
DEBUG - 2022-07-08 08:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:17:02 --> Total execution time: 0.0706
DEBUG - 2022-07-08 08:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:06 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:17:06 --> Total execution time: 0.0636
DEBUG - 2022-07-08 08:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:10 --> Total execution time: 0.0652
DEBUG - 2022-07-08 08:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:12 --> Total execution time: 0.0681
DEBUG - 2022-07-08 08:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:12 --> Total execution time: 0.1309
DEBUG - 2022-07-08 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:15 --> Total execution time: 0.0595
DEBUG - 2022-07-08 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:16 --> Total execution time: 0.0561
DEBUG - 2022-07-08 08:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:16 --> Total execution time: 0.1139
DEBUG - 2022-07-08 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:17 --> Total execution time: 0.0781
DEBUG - 2022-07-08 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:18 --> Total execution time: 0.0546
DEBUG - 2022-07-08 08:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:18 --> Total execution time: 0.1171
DEBUG - 2022-07-08 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:27 --> Total execution time: 0.0543
DEBUG - 2022-07-08 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:28 --> Total execution time: 0.0488
DEBUG - 2022-07-08 08:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:28 --> Total execution time: 0.1120
DEBUG - 2022-07-08 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:33 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:17:33 --> Total execution time: 0.1340
DEBUG - 2022-07-08 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:34 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:17:34 --> Total execution time: 0.0508
DEBUG - 2022-07-08 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:48 --> Total execution time: 0.0639
DEBUG - 2022-07-08 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:50 --> Total execution time: 0.0695
DEBUG - 2022-07-08 08:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:47:50 --> Total execution time: 0.0855
DEBUG - 2022-07-08 08:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:02 --> Total execution time: 0.0438
DEBUG - 2022-07-08 08:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:04 --> Total execution time: 0.0510
DEBUG - 2022-07-08 08:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:04 --> Total execution time: 0.0891
DEBUG - 2022-07-08 08:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:18:05 --> Total execution time: 0.0511
DEBUG - 2022-07-08 08:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:18:08 --> Total execution time: 0.0515
DEBUG - 2022-07-08 08:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:18:13 --> Total execution time: 0.0590
DEBUG - 2022-07-08 08:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:27 --> Total execution time: 0.0507
DEBUG - 2022-07-08 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:28 --> Total execution time: 0.0600
DEBUG - 2022-07-08 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:28 --> Total execution time: 0.1194
DEBUG - 2022-07-08 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:55 --> Total execution time: 0.0687
DEBUG - 2022-07-08 08:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:56 --> Total execution time: 0.0733
DEBUG - 2022-07-08 08:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:57 --> Total execution time: 0.1215
DEBUG - 2022-07-08 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:48:59 --> Total execution time: 0.0498
DEBUG - 2022-07-08 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:48:59 --> No URI present. Default controller set.
DEBUG - 2022-07-08 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:18:59 --> Total execution time: 0.0539
DEBUG - 2022-07-08 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:00 --> Total execution time: 0.0529
DEBUG - 2022-07-08 08:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:00 --> Total execution time: 0.0943
DEBUG - 2022-07-08 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:14 --> Total execution time: 0.0504
DEBUG - 2022-07-08 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:15 --> Total execution time: 0.0696
DEBUG - 2022-07-08 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:15 --> Total execution time: 0.1242
DEBUG - 2022-07-08 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:29 --> Total execution time: 0.0518
DEBUG - 2022-07-08 08:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:30 --> Total execution time: 0.0698
DEBUG - 2022-07-08 08:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:30 --> Total execution time: 0.1486
DEBUG - 2022-07-08 08:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:37 --> Total execution time: 0.0553
DEBUG - 2022-07-08 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:38 --> Total execution time: 0.0641
DEBUG - 2022-07-08 08:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:38 --> Total execution time: 0.1003
DEBUG - 2022-07-08 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:44 --> Total execution time: 0.0513
DEBUG - 2022-07-08 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:46 --> Total execution time: 0.0533
DEBUG - 2022-07-08 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 08:49:46 --> Total execution time: 0.1062
DEBUG - 2022-07-08 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:30:02 --> Total execution time: 0.2068
DEBUG - 2022-07-08 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:02:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:02:16 --> 404 Page Not Found: Event/lesley-2030-help-shape-our-future
DEBUG - 2022-07-08 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:32:51 --> Total execution time: 0.0563
DEBUG - 2022-07-08 09:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:33:01 --> Total execution time: 0.0573
DEBUG - 2022-07-08 09:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:33:08 --> Total execution time: 0.0520
DEBUG - 2022-07-08 09:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:05 --> Total execution time: 0.1060
DEBUG - 2022-07-08 09:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:11 --> Total execution time: 0.0523
DEBUG - 2022-07-08 09:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:29 --> Total execution time: 0.0821
DEBUG - 2022-07-08 09:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:36 --> Total execution time: 0.0358
DEBUG - 2022-07-08 09:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:37 --> Total execution time: 0.0728
DEBUG - 2022-07-08 09:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:40 --> Total execution time: 0.0592
DEBUG - 2022-07-08 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:37:59 --> Total execution time: 0.0519
DEBUG - 2022-07-08 09:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:38:22 --> Total execution time: 0.0559
DEBUG - 2022-07-08 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:56:13 --> Total execution time: 0.0834
DEBUG - 2022-07-08 09:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:56:21 --> Total execution time: 0.1357
DEBUG - 2022-07-08 09:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:56:28 --> Total execution time: 0.0540
DEBUG - 2022-07-08 09:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:56:37 --> Total execution time: 0.0611
DEBUG - 2022-07-08 09:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:56:48 --> Total execution time: 0.0509
DEBUG - 2022-07-08 09:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:59:46 --> Total execution time: 0.0507
DEBUG - 2022-07-08 09:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:31:24 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:01:24 --> Total execution time: 0.0467
DEBUG - 2022-07-08 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:32:21 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:02:59 --> Total execution time: 0.0491
DEBUG - 2022-07-08 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:03:09 --> Total execution time: 0.0674
DEBUG - 2022-07-08 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:03:17 --> Total execution time: 0.0912
DEBUG - 2022-07-08 09:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:34:15 --> Total execution time: 0.0367
DEBUG - 2022-07-08 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:34:21 --> Total execution time: 0.0610
DEBUG - 2022-07-08 09:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:34:21 --> Total execution time: 0.1124
DEBUG - 2022-07-08 09:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:35:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:35:11 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 09:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:37:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:37:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:42:01 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:12:01 --> Total execution time: 0.1507
DEBUG - 2022-07-08 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:12:10 --> Total execution time: 0.1465
DEBUG - 2022-07-08 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:46:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:38 --> Total execution time: 0.1155
DEBUG - 2022-07-08 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:46:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:41 --> Total execution time: 0.0452
DEBUG - 2022-07-08 09:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:49 --> Total execution time: 0.0412
DEBUG - 2022-07-08 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:17:09 --> Total execution time: 0.0499
DEBUG - 2022-07-08 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:17:28 --> Total execution time: 0.0616
DEBUG - 2022-07-08 09:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:17:38 --> Total execution time: 0.1363
DEBUG - 2022-07-08 09:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:45 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:19:45 --> Total execution time: 0.0479
DEBUG - 2022-07-08 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:46 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-08 09:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:47 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:49 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:50 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:51 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:52 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:54 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:49:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:49:55 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:50:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:20:48 --> Total execution time: 0.0427
DEBUG - 2022-07-08 09:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:50:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:20:56 --> Total execution time: 0.0295
DEBUG - 2022-07-08 09:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:04 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:04 --> Total execution time: 0.0386
DEBUG - 2022-07-08 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:51:11 --> Total execution time: 0.0560
DEBUG - 2022-07-08 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:51:12 --> Total execution time: 0.0930
DEBUG - 2022-07-08 09:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:51:12 --> Total execution time: 0.1009
DEBUG - 2022-07-08 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:23 --> Total execution time: 0.1365
DEBUG - 2022-07-08 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:23 --> Total execution time: 0.0545
DEBUG - 2022-07-08 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:23 --> Total execution time: 0.0563
DEBUG - 2022-07-08 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:51:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:23 --> Total execution time: 0.0526
DEBUG - 2022-07-08 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:06 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:23:06 --> Total execution time: 0.0539
DEBUG - 2022-07-08 09:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:23:07 --> Total execution time: 0.0508
DEBUG - 2022-07-08 09:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:23:07 --> Total execution time: 0.0601
DEBUG - 2022-07-08 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:38 --> Total execution time: 0.0541
DEBUG - 2022-07-08 09:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:40 --> Total execution time: 0.0506
DEBUG - 2022-07-08 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:42 --> Total execution time: 0.0542
DEBUG - 2022-07-08 09:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:42 --> Total execution time: 0.0490
DEBUG - 2022-07-08 09:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:53:59 --> Total execution time: 0.0523
DEBUG - 2022-07-08 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:54:41 --> Total execution time: 0.0544
DEBUG - 2022-07-08 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:55:13 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 09:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:25:16 --> Total execution time: 3.1159
DEBUG - 2022-07-08 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 09:55:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:56:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:49 --> Total execution time: 0.0364
DEBUG - 2022-07-08 09:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:56:54 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:54 --> Total execution time: 0.0513
DEBUG - 2022-07-08 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:27:01 --> Total execution time: 0.0558
DEBUG - 2022-07-08 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:27:12 --> Total execution time: 0.0385
DEBUG - 2022-07-08 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:27:53 --> Total execution time: 0.0555
DEBUG - 2022-07-08 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:57:55 --> Total execution time: 0.0342
DEBUG - 2022-07-08 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:57:57 --> Total execution time: 0.0575
DEBUG - 2022-07-08 09:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:57:58 --> Total execution time: 0.1076
DEBUG - 2022-07-08 09:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:58:01 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:28:01 --> Total execution time: 0.0634
DEBUG - 2022-07-08 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:28:08 --> Total execution time: 0.0686
DEBUG - 2022-07-08 09:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:28:16 --> Total execution time: 0.1285
DEBUG - 2022-07-08 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:58:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 09:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:28:29 --> Total execution time: 0.0353
DEBUG - 2022-07-08 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:29:20 --> Total execution time: 0.0493
DEBUG - 2022-07-08 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:29:35 --> Total execution time: 0.0520
DEBUG - 2022-07-08 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 09:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:29:50 --> Total execution time: 0.0533
DEBUG - 2022-07-08 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 09:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:29:55 --> Total execution time: 0.0730
DEBUG - 2022-07-08 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:30:02 --> Total execution time: 0.0685
DEBUG - 2022-07-08 10:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:30:06 --> Total execution time: 0.1339
DEBUG - 2022-07-08 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:30:28 --> Total execution time: 0.0809
DEBUG - 2022-07-08 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:30:37 --> Total execution time: 0.0615
DEBUG - 2022-07-08 10:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:30:47 --> Total execution time: 0.0772
DEBUG - 2022-07-08 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:01:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:31:41 --> Total execution time: 0.0383
DEBUG - 2022-07-08 10:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:01:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 10:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:31:50 --> Total execution time: 1.4770
DEBUG - 2022-07-08 10:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:01:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:32:31 --> Total execution time: 0.0644
DEBUG - 2022-07-08 10:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:03:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:03:30 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 10:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:04:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:34:47 --> Total execution time: 0.0367
DEBUG - 2022-07-08 10:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:34:56 --> Total execution time: 0.0332
DEBUG - 2022-07-08 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:35:05 --> Total execution time: 0.0532
DEBUG - 2022-07-08 10:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:35:29 --> Total execution time: 0.0378
DEBUG - 2022-07-08 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:35:32 --> Total execution time: 0.0580
DEBUG - 2022-07-08 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:35:37 --> Total execution time: 0.0748
DEBUG - 2022-07-08 10:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:05:51 --> Total execution time: 0.0517
DEBUG - 2022-07-08 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:06:02 --> Total execution time: 0.0545
DEBUG - 2022-07-08 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:06:02 --> Total execution time: 0.1235
DEBUG - 2022-07-08 10:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:36:43 --> Total execution time: 0.1316
DEBUG - 2022-07-08 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:06:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:36:56 --> Total execution time: 0.0456
DEBUG - 2022-07-08 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:37:10 --> Total execution time: 0.0594
DEBUG - 2022-07-08 10:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:07:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:37:36 --> Total execution time: 0.0518
DEBUG - 2022-07-08 10:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:07:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:37:36 --> Total execution time: 0.0396
DEBUG - 2022-07-08 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:07 --> Total execution time: 0.0594
DEBUG - 2022-07-08 10:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:11 --> Total execution time: 0.0591
DEBUG - 2022-07-08 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:13 --> Total execution time: 0.0755
DEBUG - 2022-07-08 10:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:27 --> Total execution time: 0.0609
DEBUG - 2022-07-08 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:54 --> Total execution time: 0.0720
DEBUG - 2022-07-08 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:10:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:07 --> Total execution time: 1.4700
DEBUG - 2022-07-08 10:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:10:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 10:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:43 --> Total execution time: 0.0604
DEBUG - 2022-07-08 10:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:10:46 --> Total execution time: 0.0590
DEBUG - 2022-07-08 10:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:51 --> Total execution time: 0.0548
DEBUG - 2022-07-08 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:57 --> Total execution time: 0.0751
DEBUG - 2022-07-08 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:59 --> Total execution time: 0.1269
DEBUG - 2022-07-08 10:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:05 --> Total execution time: 0.0847
DEBUG - 2022-07-08 10:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:07 --> Total execution time: 0.0656
DEBUG - 2022-07-08 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:42 --> Total execution time: 0.0536
DEBUG - 2022-07-08 10:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:43 --> Total execution time: 0.0538
DEBUG - 2022-07-08 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:48 --> Total execution time: 0.0581
DEBUG - 2022-07-08 10:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:49 --> Total execution time: 0.1190
DEBUG - 2022-07-08 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:51 --> Total execution time: 0.0504
DEBUG - 2022-07-08 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 20:41:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 20:41:52 --> Total execution time: 0.1852
DEBUG - 2022-07-08 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:04 --> Total execution time: 0.0616
DEBUG - 2022-07-08 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:11 --> Total execution time: 0.0588
DEBUG - 2022-07-08 10:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:16 --> Total execution time: 0.0607
DEBUG - 2022-07-08 10:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:33 --> Total execution time: 0.0774
DEBUG - 2022-07-08 10:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:41 --> Total execution time: 0.0727
DEBUG - 2022-07-08 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:12:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:50 --> Total execution time: 0.0357
DEBUG - 2022-07-08 10:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:27 --> Total execution time: 0.0549
DEBUG - 2022-07-08 10:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:44:19 --> Total execution time: 0.0561
DEBUG - 2022-07-08 10:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:45 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:48:45 --> Total execution time: 0.1401
DEBUG - 2022-07-08 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:48 --> Total execution time: 0.0564
DEBUG - 2022-07-08 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:50 --> Total execution time: 0.0532
DEBUG - 2022-07-08 10:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:52 --> Total execution time: 0.0846
DEBUG - 2022-07-08 10:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:52 --> Total execution time: 0.1606
DEBUG - 2022-07-08 10:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:18:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:48:56 --> Total execution time: 0.0538
DEBUG - 2022-07-08 10:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:49:21 --> Total execution time: 0.0875
DEBUG - 2022-07-08 10:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:49:22 --> Total execution time: 0.0893
DEBUG - 2022-07-08 10:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:49:47 --> Total execution time: 0.0837
DEBUG - 2022-07-08 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:38 --> Total execution time: 0.0640
DEBUG - 2022-07-08 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:39 --> Total execution time: 0.0702
DEBUG - 2022-07-08 10:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:47 --> Total execution time: 0.0554
DEBUG - 2022-07-08 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:49 --> Total execution time: 0.0502
DEBUG - 2022-07-08 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 20:50:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 20:50:50 --> Total execution time: 0.1820
DEBUG - 2022-07-08 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:54 --> Total execution time: 0.0768
DEBUG - 2022-07-08 10:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:55 --> Total execution time: 0.0777
DEBUG - 2022-07-08 10:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:06 --> Total execution time: 0.0764
DEBUG - 2022-07-08 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:14 --> Total execution time: 0.0406
DEBUG - 2022-07-08 10:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:21:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 10:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:38 --> Total execution time: 1.8297
DEBUG - 2022-07-08 10:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:39 --> Total execution time: 0.0382
DEBUG - 2022-07-08 10:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:21:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:46 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:46 --> Total execution time: 0.0365
DEBUG - 2022-07-08 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:47 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:47 --> Total execution time: 0.0390
DEBUG - 2022-07-08 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:21:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:51:58 --> Total execution time: 0.0610
DEBUG - 2022-07-08 10:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:18 --> Total execution time: 0.0605
DEBUG - 2022-07-08 10:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:28 --> Total execution time: 0.0507
DEBUG - 2022-07-08 10:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:36 --> Total execution time: 0.0619
DEBUG - 2022-07-08 10:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:39 --> Total execution time: 0.0504
DEBUG - 2022-07-08 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:46 --> Total execution time: 0.0566
DEBUG - 2022-07-08 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:53:09 --> Total execution time: 0.0630
DEBUG - 2022-07-08 10:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:53:33 --> Total execution time: 0.0589
DEBUG - 2022-07-08 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:53:42 --> Total execution time: 0.0645
DEBUG - 2022-07-08 10:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:54:08 --> Total execution time: 0.0651
DEBUG - 2022-07-08 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:54:21 --> Total execution time: 0.0635
DEBUG - 2022-07-08 10:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:27:37 --> Total execution time: 1.7765
DEBUG - 2022-07-08 10:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:27:42 --> Total execution time: 0.0986
DEBUG - 2022-07-08 10:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:59:44 --> Total execution time: 1.6514
DEBUG - 2022-07-08 10:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:29:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:00:24 --> Total execution time: 1.5408
DEBUG - 2022-07-08 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:30:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 10:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:01:16 --> Total execution time: 0.0837
DEBUG - 2022-07-08 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:01:22 --> Total execution time: 0.0795
DEBUG - 2022-07-08 10:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:02:14 --> Total execution time: 0.0995
DEBUG - 2022-07-08 10:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:02:52 --> Total execution time: 0.0828
DEBUG - 2022-07-08 10:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:02:53 --> Total execution time: 0.0495
DEBUG - 2022-07-08 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:03 --> Total execution time: 0.0713
DEBUG - 2022-07-08 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:20 --> Total execution time: 0.0467
DEBUG - 2022-07-08 10:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:20 --> Total execution time: 0.0910
DEBUG - 2022-07-08 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:29 --> Total execution time: 0.0480
DEBUG - 2022-07-08 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:33 --> Total execution time: 0.0554
DEBUG - 2022-07-08 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:38 --> Total execution time: 0.1286
DEBUG - 2022-07-08 10:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:03:45 --> Total execution time: 0.0598
DEBUG - 2022-07-08 10:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:07 --> Total execution time: 0.0865
DEBUG - 2022-07-08 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:13 --> Total execution time: 0.0541
DEBUG - 2022-07-08 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:15 --> Total execution time: 0.0650
DEBUG - 2022-07-08 10:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:18 --> Total execution time: 0.0641
DEBUG - 2022-07-08 10:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:31 --> Total execution time: 0.0555
DEBUG - 2022-07-08 10:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:36 --> Total execution time: 0.0785
DEBUG - 2022-07-08 10:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:56 --> Total execution time: 0.0608
DEBUG - 2022-07-08 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:34:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:57 --> Total execution time: 0.0601
DEBUG - 2022-07-08 10:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:12 --> Total execution time: 0.1293
DEBUG - 2022-07-08 10:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:17 --> Total execution time: 0.0608
DEBUG - 2022-07-08 10:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:26 --> Total execution time: 0.0685
DEBUG - 2022-07-08 10:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:29 --> Total execution time: 0.0560
DEBUG - 2022-07-08 10:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:32 --> Total execution time: 0.0551
DEBUG - 2022-07-08 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:33 --> Total execution time: 0.0550
DEBUG - 2022-07-08 10:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:45 --> Total execution time: 0.0591
DEBUG - 2022-07-08 10:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:55 --> Total execution time: 0.0679
DEBUG - 2022-07-08 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:05:57 --> Total execution time: 0.0574
DEBUG - 2022-07-08 10:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:07 --> Total execution time: 0.0526
DEBUG - 2022-07-08 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:08 --> Total execution time: 0.0702
DEBUG - 2022-07-08 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:17 --> Total execution time: 0.0570
DEBUG - 2022-07-08 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:17 --> Total execution time: 0.1614
DEBUG - 2022-07-08 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:40 --> Total execution time: 0.1211
DEBUG - 2022-07-08 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:37:24 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:25 --> Total execution time: 0.0642
DEBUG - 2022-07-08 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:15 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:15 --> Total execution time: 0.0584
DEBUG - 2022-07-08 10:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:21 --> Total execution time: 0.0559
DEBUG - 2022-07-08 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:39 --> Total execution time: 0.0487
DEBUG - 2022-07-08 10:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:50 --> Total execution time: 0.0528
DEBUG - 2022-07-08 10:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:55 --> Total execution time: 0.0896
DEBUG - 2022-07-08 10:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:12 --> Total execution time: 0.0566
DEBUG - 2022-07-08 10:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:41:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:32 --> Total execution time: 0.1298
DEBUG - 2022-07-08 10:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:41:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:56 --> Total execution time: 0.0580
DEBUG - 2022-07-08 10:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:42:13 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:13 --> Total execution time: 0.0729
DEBUG - 2022-07-08 10:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:44:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:14:43 --> Total execution time: 0.1958
DEBUG - 2022-07-08 10:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:14:48 --> Total execution time: 0.0717
DEBUG - 2022-07-08 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:14:58 --> Total execution time: 0.0914
DEBUG - 2022-07-08 10:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:01 --> Total execution time: 0.0555
DEBUG - 2022-07-08 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:05 --> Total execution time: 0.0603
DEBUG - 2022-07-08 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:11 --> Total execution time: 0.0544
DEBUG - 2022-07-08 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:14 --> Total execution time: 0.0812
DEBUG - 2022-07-08 10:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:30 --> Total execution time: 0.0638
DEBUG - 2022-07-08 10:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:15:35 --> Total execution time: 0.0551
DEBUG - 2022-07-08 10:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:46:11 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 10:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 10:46:15 --> 404 Page Not Found: Lessons/how-to-post-on-instagram
DEBUG - 2022-07-08 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:16:28 --> Total execution time: 0.0567
DEBUG - 2022-07-08 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:16:39 --> Total execution time: 0.1553
DEBUG - 2022-07-08 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:16:56 --> Total execution time: 0.0680
DEBUG - 2022-07-08 10:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:22 --> Total execution time: 0.0777
DEBUG - 2022-07-08 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:33 --> Total execution time: 0.0545
DEBUG - 2022-07-08 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:42 --> Total execution time: 0.0665
DEBUG - 2022-07-08 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:42 --> Total execution time: 0.0621
DEBUG - 2022-07-08 10:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:42 --> Total execution time: 0.0548
DEBUG - 2022-07-08 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:51 --> Total execution time: 0.0627
DEBUG - 2022-07-08 10:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:51 --> Total execution time: 0.0558
DEBUG - 2022-07-08 10:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:51:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:21:05 --> Total execution time: 0.1281
DEBUG - 2022-07-08 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:51:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:21:31 --> Total execution time: 0.0522
DEBUG - 2022-07-08 10:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:21:48 --> Total execution time: 0.1295
DEBUG - 2022-07-08 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:21:59 --> Total execution time: 0.0587
DEBUG - 2022-07-08 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:22:03 --> Total execution time: 0.0573
DEBUG - 2022-07-08 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:22:16 --> Total execution time: 0.0629
DEBUG - 2022-07-08 10:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:22:37 --> Total execution time: 0.0538
DEBUG - 2022-07-08 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:23:12 --> Total execution time: 0.0638
DEBUG - 2022-07-08 10:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:54:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:24:21 --> Total execution time: 0.0361
DEBUG - 2022-07-08 10:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:54:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:24:27 --> Total execution time: 0.0513
DEBUG - 2022-07-08 10:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:54:37 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:24:37 --> Total execution time: 0.0722
DEBUG - 2022-07-08 10:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 10:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:24:55 --> Total execution time: 0.0607
DEBUG - 2022-07-08 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:25:01 --> Total execution time: 0.1000
DEBUG - 2022-07-08 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:25:16 --> Total execution time: 0.0827
DEBUG - 2022-07-08 10:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:25:29 --> Total execution time: 0.0611
DEBUG - 2022-07-08 10:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:59:03 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:29:03 --> Total execution time: 0.1128
DEBUG - 2022-07-08 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 10:59:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 10:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 10:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:29:50 --> Total execution time: 0.0549
DEBUG - 2022-07-08 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:30:02 --> Total execution time: 0.0949
DEBUG - 2022-07-08 11:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:33:12 --> Total execution time: 0.0655
DEBUG - 2022-07-08 11:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:33:55 --> Total execution time: 0.0599
DEBUG - 2022-07-08 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:33:56 --> Total execution time: 0.0809
DEBUG - 2022-07-08 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:34:09 --> Total execution time: 0.0563
DEBUG - 2022-07-08 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:34:33 --> Total execution time: 1.9553
DEBUG - 2022-07-08 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:05 --> Total execution time: 1.5831
DEBUG - 2022-07-08 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:05:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 11:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:14 --> Total execution time: 0.0790
DEBUG - 2022-07-08 11:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:15 --> Total execution time: 0.0605
DEBUG - 2022-07-08 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:20 --> Total execution time: 0.0827
DEBUG - 2022-07-08 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:27 --> Total execution time: 0.0765
DEBUG - 2022-07-08 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:34 --> Total execution time: 0.0593
DEBUG - 2022-07-08 11:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 11:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:07 --> Total execution time: 0.0611
DEBUG - 2022-07-08 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 21:37:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 21:37:08 --> Total execution time: 0.1822
DEBUG - 2022-07-08 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:38:32 --> Total execution time: 0.0409
DEBUG - 2022-07-08 11:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:08:40 --> Total execution time: 0.0515
DEBUG - 2022-07-08 11:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:43 --> Total execution time: 0.0541
DEBUG - 2022-07-08 11:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:08:43 --> Total execution time: 0.0661
DEBUG - 2022-07-08 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:38:56 --> Total execution time: 0.1536
DEBUG - 2022-07-08 11:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:38:57 --> Total execution time: 0.0466
DEBUG - 2022-07-08 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:12 --> Total execution time: 0.0516
DEBUG - 2022-07-08 11:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:23 --> Total execution time: 0.0744
DEBUG - 2022-07-08 11:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:30 --> Total execution time: 0.0782
DEBUG - 2022-07-08 11:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:41 --> Total execution time: 0.0536
DEBUG - 2022-07-08 11:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:45 --> Total execution time: 0.0367
DEBUG - 2022-07-08 11:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:48 --> Total execution time: 0.0973
DEBUG - 2022-07-08 11:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:50 --> Total execution time: 0.0566
DEBUG - 2022-07-08 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:09:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:57 --> Total execution time: 0.0766
DEBUG - 2022-07-08 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:02 --> Total execution time: 0.0814
DEBUG - 2022-07-08 11:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:07 --> Total execution time: 0.0551
DEBUG - 2022-07-08 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:09 --> Total execution time: 0.0716
DEBUG - 2022-07-08 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:09 --> Total execution time: 0.0584
DEBUG - 2022-07-08 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:15 --> Total execution time: 0.0747
DEBUG - 2022-07-08 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:21 --> Total execution time: 0.0522
DEBUG - 2022-07-08 11:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:32 --> Total execution time: 0.0519
DEBUG - 2022-07-08 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:38 --> Total execution time: 0.0495
DEBUG - 2022-07-08 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:38 --> Total execution time: 0.0531
DEBUG - 2022-07-08 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:39 --> Total execution time: 0.0451
DEBUG - 2022-07-08 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:10:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:40:55 --> Total execution time: 1.4817
DEBUG - 2022-07-08 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:10:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 11:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:41:43 --> Total execution time: 0.0396
DEBUG - 2022-07-08 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:41:57 --> Total execution time: 0.1780
DEBUG - 2022-07-08 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:03 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:42:03 --> Total execution time: 0.0547
DEBUG - 2022-07-08 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:42:07 --> Total execution time: 0.0503
DEBUG - 2022-07-08 11:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:42:12 --> Total execution time: 0.0544
DEBUG - 2022-07-08 11:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:42:17 --> Total execution time: 0.0933
DEBUG - 2022-07-08 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:43:23 --> Total execution time: 0.0882
DEBUG - 2022-07-08 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:17:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:47:55 --> Total execution time: 0.1196
DEBUG - 2022-07-08 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:17:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:47:56 --> Total execution time: 0.0434
DEBUG - 2022-07-08 11:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:48:01 --> Total execution time: 0.0508
DEBUG - 2022-07-08 11:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:48:11 --> Total execution time: 0.0621
DEBUG - 2022-07-08 11:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:48:29 --> Total execution time: 0.0755
DEBUG - 2022-07-08 11:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:48:53 --> Total execution time: 0.1055
DEBUG - 2022-07-08 11:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:48:54 --> Total execution time: 0.0473
DEBUG - 2022-07-08 11:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:49:01 --> Total execution time: 0.0926
DEBUG - 2022-07-08 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:49:28 --> Total execution time: 0.0917
DEBUG - 2022-07-08 11:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:19:45 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:49:45 --> Total execution time: 0.0370
DEBUG - 2022-07-08 11:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:19:59 --> Total execution time: 0.0506
DEBUG - 2022-07-08 11:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:50:01 --> Total execution time: 0.0561
DEBUG - 2022-07-08 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:02 --> Total execution time: 0.0954
DEBUG - 2022-07-08 11:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:02 --> Total execution time: 0.1481
DEBUG - 2022-07-08 11:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:09 --> Total execution time: 0.0721
DEBUG - 2022-07-08 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:11 --> Total execution time: 0.0531
DEBUG - 2022-07-08 11:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:11 --> Total execution time: 0.0536
DEBUG - 2022-07-08 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:16 --> Total execution time: 0.0776
DEBUG - 2022-07-08 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:50:16 --> Total execution time: 0.0650
DEBUG - 2022-07-08 11:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:50:17 --> Total execution time: 0.0552
DEBUG - 2022-07-08 11:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:18 --> Total execution time: 0.0540
DEBUG - 2022-07-08 11:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:18 --> Total execution time: 0.1049
DEBUG - 2022-07-08 11:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:53 --> Total execution time: 0.0555
DEBUG - 2022-07-08 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:54 --> Total execution time: 0.0656
DEBUG - 2022-07-08 11:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:20:54 --> Total execution time: 0.1367
DEBUG - 2022-07-08 11:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:51:17 --> Total execution time: 0.0666
DEBUG - 2022-07-08 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:51:17 --> Total execution time: 0.0469
DEBUG - 2022-07-08 11:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:21:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 11:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:51:32 --> Total execution time: 2.0709
DEBUG - 2022-07-08 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:21:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:21:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 11:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:13 --> Total execution time: 0.0594
DEBUG - 2022-07-08 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:22:21 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 11:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:22 --> Total execution time: 0.1450
DEBUG - 2022-07-08 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:32 --> Total execution time: 0.0562
DEBUG - 2022-07-08 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:39 --> Total execution time: 0.0596
DEBUG - 2022-07-08 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:40 --> Total execution time: 0.0826
DEBUG - 2022-07-08 11:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:40 --> Total execution time: 0.0706
DEBUG - 2022-07-08 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:52:44 --> Total execution time: 0.0831
DEBUG - 2022-07-08 11:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:23:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:17 --> Total execution time: 0.0471
DEBUG - 2022-07-08 11:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 11:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:24 --> Total execution time: 0.0545
DEBUG - 2022-07-08 11:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:23:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-08 21:53:26 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-07-08 21:53:26 --> Total execution time: 0.0604
DEBUG - 2022-07-08 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:00 --> Total execution time: 0.0545
DEBUG - 2022-07-08 11:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:13 --> Total execution time: 0.0545
DEBUG - 2022-07-08 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:28 --> Total execution time: 0.0555
DEBUG - 2022-07-08 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:38 --> Total execution time: 0.0562
DEBUG - 2022-07-08 11:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:55:10 --> Total execution time: 0.0338
DEBUG - 2022-07-08 11:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:25:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:25:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 11:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:55:59 --> Total execution time: 0.0537
DEBUG - 2022-07-08 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:56:20 --> Total execution time: 0.0556
DEBUG - 2022-07-08 11:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:56:41 --> Total execution time: 0.0688
DEBUG - 2022-07-08 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:56:41 --> Total execution time: 0.0723
DEBUG - 2022-07-08 11:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:05 --> Total execution time: 0.0549
DEBUG - 2022-07-08 11:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:06 --> Total execution time: 0.0580
DEBUG - 2022-07-08 11:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:23 --> Total execution time: 0.0556
DEBUG - 2022-07-08 11:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:25 --> Total execution time: 0.0582
DEBUG - 2022-07-08 11:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:42 --> Total execution time: 0.0538
DEBUG - 2022-07-08 11:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:27:45 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:54 --> Total execution time: 0.0533
DEBUG - 2022-07-08 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:56 --> Total execution time: 0.0561
DEBUG - 2022-07-08 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:56 --> Total execution time: 0.0504
DEBUG - 2022-07-08 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:58:04 --> Total execution time: 0.0587
DEBUG - 2022-07-08 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:01:15 --> Total execution time: 0.0558
DEBUG - 2022-07-08 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:01:50 --> Total execution time: 0.0586
DEBUG - 2022-07-08 11:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:02:28 --> Total execution time: 0.0564
DEBUG - 2022-07-08 11:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:02:33 --> Total execution time: 0.0787
DEBUG - 2022-07-08 11:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:02:45 --> Total execution time: 0.0643
DEBUG - 2022-07-08 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:04:05 --> Total execution time: 0.0687
DEBUG - 2022-07-08 11:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:04:06 --> Total execution time: 0.1587
DEBUG - 2022-07-08 11:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:13 --> Total execution time: 0.0548
DEBUG - 2022-07-08 11:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:35:37 --> Total execution time: 0.0642
DEBUG - 2022-07-08 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:16 --> Total execution time: 0.0485
DEBUG - 2022-07-08 11:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:25 --> Total execution time: 0.1376
DEBUG - 2022-07-08 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:31 --> Total execution time: 0.0967
DEBUG - 2022-07-08 11:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:39 --> Total execution time: 0.0780
DEBUG - 2022-07-08 11:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:45 --> Total execution time: 0.0798
DEBUG - 2022-07-08 11:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:37:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:55 --> Total execution time: 0.0396
DEBUG - 2022-07-08 11:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:08:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 11:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:08:03 --> Total execution time: 0.1118
DEBUG - 2022-07-08 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:10:16 --> Total execution time: 0.1252
DEBUG - 2022-07-08 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:10:16 --> Total execution time: 0.1385
DEBUG - 2022-07-08 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:10:27 --> Total execution time: 0.0613
DEBUG - 2022-07-08 11:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:10:33 --> Total execution time: 0.0564
DEBUG - 2022-07-08 11:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:11:35 --> Total execution time: 0.0579
DEBUG - 2022-07-08 11:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:42 --> Total execution time: 0.0545
DEBUG - 2022-07-08 11:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:11:46 --> Total execution time: 0.0556
DEBUG - 2022-07-08 11:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:11:49 --> Total execution time: 0.0553
DEBUG - 2022-07-08 11:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:11:52 --> Total execution time: 0.0609
DEBUG - 2022-07-08 11:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:01 --> Total execution time: 0.0962
DEBUG - 2022-07-08 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:24 --> Total execution time: 0.0329
DEBUG - 2022-07-08 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:37 --> Total execution time: 0.0599
DEBUG - 2022-07-08 11:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:41 --> Total execution time: 0.0672
DEBUG - 2022-07-08 11:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:44 --> Total execution time: 0.0643
DEBUG - 2022-07-08 11:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:49 --> Total execution time: 0.0605
DEBUG - 2022-07-08 11:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:52 --> Total execution time: 0.0450
DEBUG - 2022-07-08 11:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:58 --> Total execution time: 0.0629
DEBUG - 2022-07-08 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:13:14 --> Total execution time: 0.0513
DEBUG - 2022-07-08 11:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:43:30 --> Total execution time: 0.0748
DEBUG - 2022-07-08 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:13:41 --> Total execution time: 0.0598
DEBUG - 2022-07-08 11:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:27 --> Total execution time: 0.2027
DEBUG - 2022-07-08 11:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:36 --> Total execution time: 0.0565
DEBUG - 2022-07-08 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:48 --> Total execution time: 0.0753
DEBUG - 2022-07-08 11:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:03 --> Total execution time: 0.0932
DEBUG - 2022-07-08 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:20 --> Total execution time: 0.0988
DEBUG - 2022-07-08 11:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:36 --> Total execution time: 0.1587
DEBUG - 2022-07-08 11:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:45 --> Total execution time: 0.1057
DEBUG - 2022-07-08 11:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:28 --> Total execution time: 0.1415
DEBUG - 2022-07-08 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:36 --> Total execution time: 0.0589
DEBUG - 2022-07-08 11:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:38 --> Total execution time: 0.0574
DEBUG - 2022-07-08 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:41 --> Total execution time: 0.0596
DEBUG - 2022-07-08 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:42 --> Total execution time: 0.0589
DEBUG - 2022-07-08 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:42 --> Total execution time: 0.0526
DEBUG - 2022-07-08 11:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:19:45 --> Total execution time: 0.0546
DEBUG - 2022-07-08 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:20:08 --> Total execution time: 0.0751
DEBUG - 2022-07-08 11:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:20:08 --> Total execution time: 0.0746
DEBUG - 2022-07-08 11:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:51:31 --> Total execution time: 0.0643
DEBUG - 2022-07-08 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:52:17 --> Total execution time: 0.0651
DEBUG - 2022-07-08 11:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:22:49 --> Total execution time: 0.0605
DEBUG - 2022-07-08 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:17 --> Total execution time: 0.0496
DEBUG - 2022-07-08 11:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:25 --> Total execution time: 0.0524
DEBUG - 2022-07-08 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:27 --> Total execution time: 0.0679
DEBUG - 2022-07-08 11:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:28 --> Total execution time: 0.0671
DEBUG - 2022-07-08 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:36 --> Total execution time: 0.0489
DEBUG - 2022-07-08 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:37 --> Total execution time: 0.0513
DEBUG - 2022-07-08 11:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:39 --> Total execution time: 0.0494
DEBUG - 2022-07-08 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:40 --> Total execution time: 0.0511
DEBUG - 2022-07-08 11:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:42 --> Total execution time: 0.0504
DEBUG - 2022-07-08 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:44 --> Total execution time: 0.0486
DEBUG - 2022-07-08 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:44 --> Total execution time: 0.0690
DEBUG - 2022-07-08 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:47 --> Total execution time: 0.0512
DEBUG - 2022-07-08 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:52 --> Total execution time: 0.0652
DEBUG - 2022-07-08 11:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:55 --> Total execution time: 0.0773
DEBUG - 2022-07-08 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:57 --> Total execution time: 0.0645
DEBUG - 2022-07-08 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:57 --> Total execution time: 0.0588
DEBUG - 2022-07-08 11:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:23:59 --> Total execution time: 0.0521
DEBUG - 2022-07-08 11:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:04 --> Total execution time: 0.0616
DEBUG - 2022-07-08 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:15 --> Total execution time: 0.0502
DEBUG - 2022-07-08 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:15 --> Total execution time: 0.0498
DEBUG - 2022-07-08 11:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:16 --> Total execution time: 0.0555
DEBUG - 2022-07-08 11:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:17 --> Total execution time: 0.0507
DEBUG - 2022-07-08 11:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:29 --> Total execution time: 0.0587
DEBUG - 2022-07-08 11:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:30 --> Total execution time: 0.0517
DEBUG - 2022-07-08 11:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 11:54:35 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 11:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:49 --> Total execution time: 0.0507
DEBUG - 2022-07-08 11:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:55 --> Total execution time: 0.0554
DEBUG - 2022-07-08 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:11 --> Total execution time: 0.0761
DEBUG - 2022-07-08 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:13 --> Total execution time: 0.0514
DEBUG - 2022-07-08 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:14 --> Total execution time: 0.0504
DEBUG - 2022-07-08 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:15 --> Total execution time: 0.0495
DEBUG - 2022-07-08 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:16 --> Total execution time: 0.0509
DEBUG - 2022-07-08 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:18 --> Total execution time: 0.0586
DEBUG - 2022-07-08 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:24 --> Total execution time: 0.0542
DEBUG - 2022-07-08 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:28 --> Total execution time: 0.0845
DEBUG - 2022-07-08 11:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:28 --> Total execution time: 0.0539
DEBUG - 2022-07-08 11:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:33 --> Total execution time: 0.0876
DEBUG - 2022-07-08 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:35 --> Total execution time: 0.0813
DEBUG - 2022-07-08 11:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:38 --> Total execution time: 0.0493
DEBUG - 2022-07-08 11:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:25:45 --> Total execution time: 0.0531
DEBUG - 2022-07-08 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:26:42 --> Total execution time: 0.0538
DEBUG - 2022-07-08 11:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:00 --> Total execution time: 0.0548
DEBUG - 2022-07-08 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:10 --> Total execution time: 0.1292
DEBUG - 2022-07-08 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:13 --> Total execution time: 0.0520
DEBUG - 2022-07-08 11:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:25 --> Total execution time: 0.0526
DEBUG - 2022-07-08 11:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:28 --> Total execution time: 0.0596
DEBUG - 2022-07-08 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:34 --> Total execution time: 0.0549
DEBUG - 2022-07-08 11:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:45 --> Total execution time: 0.0538
DEBUG - 2022-07-08 11:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:52 --> Total execution time: 0.0744
DEBUG - 2022-07-08 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:27:55 --> Total execution time: 0.0496
DEBUG - 2022-07-08 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:15 --> Total execution time: 0.0508
DEBUG - 2022-07-08 11:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:21 --> Total execution time: 0.0660
DEBUG - 2022-07-08 11:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:32 --> Total execution time: 0.0727
DEBUG - 2022-07-08 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:39 --> Total execution time: 0.0585
DEBUG - 2022-07-08 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:43 --> Total execution time: 0.0367
DEBUG - 2022-07-08 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:50 --> Total execution time: 0.0571
DEBUG - 2022-07-08 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:52 --> No URI present. Default controller set.
DEBUG - 2022-07-08 11:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:52 --> Total execution time: 0.1240
DEBUG - 2022-07-08 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:28:54 --> Total execution time: 0.0616
DEBUG - 2022-07-08 11:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 11:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 11:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:29:01 --> Total execution time: 0.0856
DEBUG - 2022-07-08 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:30:04 --> Total execution time: 0.0679
DEBUG - 2022-07-08 12:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:30:51 --> Total execution time: 0.0595
DEBUG - 2022-07-08 12:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:31:13 --> Total execution time: 0.0525
DEBUG - 2022-07-08 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:31:59 --> Total execution time: 0.0509
DEBUG - 2022-07-08 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:33:15 --> Total execution time: 0.1328
DEBUG - 2022-07-08 12:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:33:23 --> Total execution time: 0.0526
DEBUG - 2022-07-08 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:03:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:33:55 --> Total execution time: 0.0381
DEBUG - 2022-07-08 12:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:03:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:33:55 --> Total execution time: 0.0385
DEBUG - 2022-07-08 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:34:02 --> Total execution time: 0.0340
DEBUG - 2022-07-08 12:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:34:21 --> Total execution time: 0.1573
DEBUG - 2022-07-08 12:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:37:05 --> Total execution time: 0.3931
DEBUG - 2022-07-08 12:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:37:58 --> Total execution time: 0.0549
DEBUG - 2022-07-08 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:17 --> Total execution time: 0.0545
DEBUG - 2022-07-08 12:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:32 --> Total execution time: 0.0621
DEBUG - 2022-07-08 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:37 --> Total execution time: 0.0509
DEBUG - 2022-07-08 12:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:38 --> Total execution time: 0.0510
DEBUG - 2022-07-08 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:40 --> Total execution time: 0.1256
DEBUG - 2022-07-08 12:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:41 --> Total execution time: 0.0546
DEBUG - 2022-07-08 12:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:58 --> Total execution time: 0.0614
DEBUG - 2022-07-08 12:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:08:59 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:59 --> Total execution time: 0.0566
DEBUG - 2022-07-08 12:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:09:00 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:39:00 --> Total execution time: 0.0541
DEBUG - 2022-07-08 12:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:39:09 --> Total execution time: 0.0482
DEBUG - 2022-07-08 12:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:09:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:09:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:39:30 --> Total execution time: 0.0836
DEBUG - 2022-07-08 12:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:39:30 --> Total execution time: 0.1371
DEBUG - 2022-07-08 12:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:39:51 --> Total execution time: 0.1531
DEBUG - 2022-07-08 12:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:10:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:40:51 --> Total execution time: 0.0376
DEBUG - 2022-07-08 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:10:52 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:40:53 --> Total execution time: 0.0537
DEBUG - 2022-07-08 12:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:18 --> Total execution time: 0.0638
DEBUG - 2022-07-08 12:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:28 --> Total execution time: 0.0582
DEBUG - 2022-07-08 12:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:31 --> Total execution time: 0.0918
DEBUG - 2022-07-08 12:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:35 --> Total execution time: 0.0723
DEBUG - 2022-07-08 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:40 --> Total execution time: 0.0562
DEBUG - 2022-07-08 12:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:43:06 --> Total execution time: 0.0514
DEBUG - 2022-07-08 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:15:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:45:12 --> Total execution time: 0.0395
DEBUG - 2022-07-08 12:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:22:20 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:52:20 --> Total execution time: 0.1200
DEBUG - 2022-07-08 12:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:22:44 --> Total execution time: 0.0603
DEBUG - 2022-07-08 12:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:03 --> Total execution time: 0.1244
DEBUG - 2022-07-08 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:23:04 --> Total execution time: 0.0415
DEBUG - 2022-07-08 12:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:23:04 --> Total execution time: 0.0369
DEBUG - 2022-07-08 12:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:59 --> Total execution time: 0.0340
DEBUG - 2022-07-08 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:54:28 --> Total execution time: 0.0473
DEBUG - 2022-07-08 12:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:54:47 --> Total execution time: 0.0674
DEBUG - 2022-07-08 12:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:54:58 --> Total execution time: 0.0576
DEBUG - 2022-07-08 12:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:04 --> Total execution time: 0.0337
DEBUG - 2022-07-08 12:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:09 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:09 --> Total execution time: 0.0552
DEBUG - 2022-07-08 12:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:24 --> Total execution time: 0.0340
DEBUG - 2022-07-08 12:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:27 --> Total execution time: 0.0333
DEBUG - 2022-07-08 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:30 --> Total execution time: 0.0376
DEBUG - 2022-07-08 12:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:32 --> Total execution time: 0.0563
DEBUG - 2022-07-08 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:36 --> Total execution time: 0.0511
DEBUG - 2022-07-08 12:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:48 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:48 --> Total execution time: 0.0364
DEBUG - 2022-07-08 12:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:54 --> Total execution time: 0.0577
DEBUG - 2022-07-08 12:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:57 --> Total execution time: 0.0588
DEBUG - 2022-07-08 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:02 --> Total execution time: 0.0390
DEBUG - 2022-07-08 12:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:07 --> Total execution time: 0.0617
DEBUG - 2022-07-08 12:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:08 --> Total execution time: 0.0331
DEBUG - 2022-07-08 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:10 --> Total execution time: 0.0387
DEBUG - 2022-07-08 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:12 --> Total execution time: 0.0572
DEBUG - 2022-07-08 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:18 --> Total execution time: 0.0627
DEBUG - 2022-07-08 12:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:23 --> Total execution time: 0.0818
DEBUG - 2022-07-08 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:36 --> Total execution time: 0.0374
DEBUG - 2022-07-08 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:49 --> Total execution time: 0.0342
DEBUG - 2022-07-08 12:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:26:56 --> Total execution time: 0.0339
DEBUG - 2022-07-08 12:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:57 --> Total execution time: 0.0504
DEBUG - 2022-07-08 12:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:04 --> Total execution time: 0.0406
DEBUG - 2022-07-08 12:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:04 --> Total execution time: 0.0375
DEBUG - 2022-07-08 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:06 --> Total execution time: 0.0351
DEBUG - 2022-07-08 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:07 --> Total execution time: 0.0374
DEBUG - 2022-07-08 12:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:07 --> Total execution time: 0.0378
DEBUG - 2022-07-08 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:12 --> Total execution time: 0.0419
DEBUG - 2022-07-08 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:14 --> Total execution time: 0.0333
DEBUG - 2022-07-08 12:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:17 --> Total execution time: 0.0530
DEBUG - 2022-07-08 12:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:18 --> Total execution time: 0.0357
DEBUG - 2022-07-08 12:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:22 --> Total execution time: 0.0337
DEBUG - 2022-07-08 12:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:28 --> Total execution time: 0.0581
DEBUG - 2022-07-08 12:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:31 --> Total execution time: 0.0619
DEBUG - 2022-07-08 12:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:42 --> Total execution time: 0.0582
DEBUG - 2022-07-08 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:46 --> Total execution time: 0.0286
DEBUG - 2022-07-08 12:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:02 --> Total execution time: 1.9172
DEBUG - 2022-07-08 12:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:04 --> Total execution time: 0.0544
DEBUG - 2022-07-08 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 12:28:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 12:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 12:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:44 --> Total execution time: 0.0711
DEBUG - 2022-07-08 12:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 22:58:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 22:58:46 --> Total execution time: 0.1808
DEBUG - 2022-07-08 12:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:11 --> Total execution time: 0.0534
DEBUG - 2022-07-08 12:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:16 --> Total execution time: 0.0530
DEBUG - 2022-07-08 12:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:24 --> Total execution time: 0.0774
DEBUG - 2022-07-08 12:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:31 --> Total execution time: 0.0568
DEBUG - 2022-07-08 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:03 --> Total execution time: 0.1880
DEBUG - 2022-07-08 12:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:08 --> Total execution time: 0.0582
DEBUG - 2022-07-08 12:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:17 --> Total execution time: 0.0411
DEBUG - 2022-07-08 12:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:21 --> Total execution time: 0.0525
DEBUG - 2022-07-08 12:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:28 --> Total execution time: 0.0521
DEBUG - 2022-07-08 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:32 --> Total execution time: 0.1277
DEBUG - 2022-07-08 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:32 --> Total execution time: 0.0470
DEBUG - 2022-07-08 12:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:41 --> Total execution time: 0.0566
DEBUG - 2022-07-08 12:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:52 --> Total execution time: 0.0600
DEBUG - 2022-07-08 12:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:01:02 --> Total execution time: 0.0506
DEBUG - 2022-07-08 12:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:01:23 --> Total execution time: 0.0521
DEBUG - 2022-07-08 12:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:01:31 --> Total execution time: 0.1500
DEBUG - 2022-07-08 12:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:32:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:02:14 --> Total execution time: 0.0388
DEBUG - 2022-07-08 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:02:41 --> Total execution time: 0.0734
DEBUG - 2022-07-08 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:02:49 --> Total execution time: 0.0536
DEBUG - 2022-07-08 12:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:02:58 --> Total execution time: 0.1220
DEBUG - 2022-07-08 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:03:01 --> Total execution time: 0.0623
DEBUG - 2022-07-08 12:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:03:57 --> Total execution time: 0.0339
DEBUG - 2022-07-08 12:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:04:09 --> Total execution time: 0.0492
DEBUG - 2022-07-08 12:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:04:16 --> Total execution time: 0.0346
DEBUG - 2022-07-08 12:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:04:34 --> Total execution time: 0.0355
DEBUG - 2022-07-08 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:00 --> Total execution time: 0.0976
DEBUG - 2022-07-08 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:35:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:31 --> Total execution time: 0.1220
DEBUG - 2022-07-08 12:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:46 --> Total execution time: 1.4249
DEBUG - 2022-07-08 12:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:36:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:06:41 --> Total execution time: 0.0425
DEBUG - 2022-07-08 12:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:07:02 --> Total execution time: 0.0458
DEBUG - 2022-07-08 12:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:07:06 --> Total execution time: 0.0362
DEBUG - 2022-07-08 12:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:07:25 --> Total execution time: 0.0334
DEBUG - 2022-07-08 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:39:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:09:51 --> Total execution time: 0.1146
DEBUG - 2022-07-08 12:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:09:58 --> Total execution time: 0.0349
DEBUG - 2022-07-08 12:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:31 --> Total execution time: 0.0607
DEBUG - 2022-07-08 12:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:38 --> Total execution time: 0.0785
DEBUG - 2022-07-08 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:44 --> Total execution time: 0.0737
DEBUG - 2022-07-08 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:44 --> Total execution time: 0.0413
DEBUG - 2022-07-08 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:54 --> Total execution time: 0.0570
DEBUG - 2022-07-08 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:56 --> Total execution time: 0.0607
DEBUG - 2022-07-08 12:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:11 --> Total execution time: 0.0630
DEBUG - 2022-07-08 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:27 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:27 --> Total execution time: 0.0534
DEBUG - 2022-07-08 12:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:42:35 --> Total execution time: 0.0527
DEBUG - 2022-07-08 12:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:42:36 --> Total execution time: 0.0534
DEBUG - 2022-07-08 12:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:42:37 --> Total execution time: 0.1113
DEBUG - 2022-07-08 12:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:05 --> Total execution time: 0.0525
DEBUG - 2022-07-08 12:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:15 --> Total execution time: 0.0394
DEBUG - 2022-07-08 12:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:26 --> Total execution time: 0.0950
DEBUG - 2022-07-08 12:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:45:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:49 --> Total execution time: 0.0587
DEBUG - 2022-07-08 12:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:16 --> Total execution time: 0.0599
DEBUG - 2022-07-08 12:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:22 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:22 --> Total execution time: 0.0372
DEBUG - 2022-07-08 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:27 --> Total execution time: 0.0566
DEBUG - 2022-07-08 12:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:32 --> Total execution time: 0.0570
DEBUG - 2022-07-08 12:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:37 --> Total execution time: 0.0573
DEBUG - 2022-07-08 12:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:41 --> Total execution time: 0.0490
DEBUG - 2022-07-08 12:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:48:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:18:58 --> Total execution time: 0.0852
DEBUG - 2022-07-08 12:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:49:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:11 --> Total execution time: 0.0364
DEBUG - 2022-07-08 12:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 12:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:21:05 --> Total execution time: 0.0546
DEBUG - 2022-07-08 12:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:55:26 --> No URI present. Default controller set.
DEBUG - 2022-07-08 12:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 12:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:25:26 --> Total execution time: 0.1232
DEBUG - 2022-07-08 12:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 12:58:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 12:58:38 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-08 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:02 --> Total execution time: 0.1813
DEBUG - 2022-07-08 13:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:20 --> Total execution time: 0.1559
DEBUG - 2022-07-08 13:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:27 --> Total execution time: 0.0868
DEBUG - 2022-07-08 13:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:34 --> Total execution time: 0.0625
DEBUG - 2022-07-08 13:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:00:58 --> Total execution time: 0.0578
DEBUG - 2022-07-08 13:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:00:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 13:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:58 --> Total execution time: 0.0429
DEBUG - 2022-07-08 13:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:01:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 13:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:31:05 --> Total execution time: 0.0590
DEBUG - 2022-07-08 13:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:31:07 --> Total execution time: 0.0620
DEBUG - 2022-07-08 13:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:31:26 --> Total execution time: 0.0613
DEBUG - 2022-07-08 13:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:31:28 --> Total execution time: 0.0593
DEBUG - 2022-07-08 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:09:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 13:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:39:55 --> Total execution time: 0.1160
DEBUG - 2022-07-08 13:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:12:24 --> No URI present. Default controller set.
DEBUG - 2022-07-08 13:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:24 --> Total execution time: 0.0865
DEBUG - 2022-07-08 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 13:14:22 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 13:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 13:17:19 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 13:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 13:19:35 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 13:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:18 --> Total execution time: 0.1893
DEBUG - 2022-07-08 13:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:54 --> Total execution time: 0.0659
DEBUG - 2022-07-08 13:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:30:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 13:30:28 --> 404 Page Not Found: Category/sports
DEBUG - 2022-07-08 13:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:32:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 13:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 13:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 13:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 13:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 13:45:41 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:09:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:11:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 14:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:14:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 14:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:27:54 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-07-08 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 14:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:45:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:45:22 --> 404 Page Not Found: Wp-content/cache.php
DEBUG - 2022-07-08 14:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:46:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:46:49 --> 404 Page Not Found: Wp-content/app.php
DEBUG - 2022-07-08 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:47:54 --> 404 Page Not Found: Authorizephp/index
DEBUG - 2022-07-08 14:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:50:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:50:05 --> 404 Page Not Found: Toolphp/index
DEBUG - 2022-07-08 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:50:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:50:44 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-08 14:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:50:51 --> 404 Page Not Found: Assets/global
DEBUG - 2022-07-08 14:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:50:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:50:56 --> 404 Page Not Found: Wp-admin/tool.php
DEBUG - 2022-07-08 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:51:37 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-07-08 14:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:52:27 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-07-08 14:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:54:25 --> 404 Page Not Found: Wp-admin/include.php
DEBUG - 2022-07-08 14:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 14:54:51 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-08 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 14:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 14:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:02:28 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:05:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:05:14 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 15:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:07:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 15:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 15:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:32:43 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 15:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:41:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 15:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 15:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:41:15 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 15:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:41:25 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 15:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 15:41:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 15:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 15:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:41:34 --> No URI present. Default controller set.
DEBUG - 2022-07-08 15:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:55:03 --> No URI present. Default controller set.
DEBUG - 2022-07-08 15:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 15:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 15:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 15:59:52 --> Total execution time: 0.1200
DEBUG - 2022-07-08 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:03 --> Total execution time: 0.1930
DEBUG - 2022-07-08 16:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:07 --> Total execution time: 0.0881
DEBUG - 2022-07-08 16:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:02:21 --> Total execution time: 0.0811
DEBUG - 2022-07-08 16:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:17:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:17:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 16:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:17:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:17:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:22:34 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-07-08 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:46:45 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 16:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:49:22 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 16:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:50:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:50:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 16:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:51:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:51:39 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 16:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:53:54 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:53:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 16:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:55:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:55:54 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-08 16:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:55:55 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-08 16:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:55:55 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-08 16:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:55:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:55:56 --> 404 Page Not Found: Contact/index
DEBUG - 2022-07-08 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:56:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:56:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:56:29 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-08 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:56:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:56:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:56:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 16:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:58:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 16:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 16:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 16:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 16:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 16:58:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:01:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 17:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:01:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:01:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:03:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 17:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:03:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:06:03 --> No URI present. Default controller set.
DEBUG - 2022-07-08 17:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:06:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:06:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:07:59 --> No URI present. Default controller set.
DEBUG - 2022-07-08 17:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:07:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:07:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:11:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 17:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:11:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 17:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 17:16:40 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 17:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:32:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 17:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 17:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 17:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:07:48 --> No URI present. Default controller set.
DEBUG - 2022-07-08 18:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:17:13 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-08 18:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:30:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:30:57 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 18:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:31:38 --> No URI present. Default controller set.
DEBUG - 2022-07-08 18:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:33:32 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 18:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:35:37 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 18:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:48:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 18:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:54:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 18:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 18:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 18:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 18:59:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 18:59:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:03:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:09:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:09 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:15:13 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 19:17:45 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 19:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 19:29:03 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-08 19:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:29:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 19:29:06 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-08 19:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:41:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 19:49:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 19:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 19:52:22 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-08 19:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:12 --> No URI present. Default controller set.
DEBUG - 2022-07-08 19:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 19:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 19:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 19:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:05:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:05:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:05:25 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:09:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:12:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 20:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:15:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:15:28 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:16:02 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:16:48 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:17:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 20:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:17:37 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 20:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:17:50 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:21 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:42 --> Total execution time: 0.0689
DEBUG - 2022-07-08 20:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:52 --> Total execution time: 0.0557
DEBUG - 2022-07-08 20:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:26:53 --> Total execution time: 0.0652
DEBUG - 2022-07-08 20:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:15 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:37:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:41 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:39:25 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-08 20:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:42 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 20:42:10 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 20:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:43:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:45:09 --> Total execution time: 0.0362
DEBUG - 2022-07-08 20:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:45:11 --> Total execution time: 0.0546
DEBUG - 2022-07-08 20:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:45:11 --> Total execution time: 0.0492
DEBUG - 2022-07-08 20:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:45:24 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:50:43 --> No URI present. Default controller set.
DEBUG - 2022-07-08 20:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 20:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 20:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:04:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:04:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 21:04:41 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-08 21:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:25 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:38 --> Total execution time: 0.0503
DEBUG - 2022-07-08 21:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:39 --> Total execution time: 0.0537
DEBUG - 2022-07-08 21:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:12:39 --> Total execution time: 0.1002
DEBUG - 2022-07-08 21:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:13 --> Total execution time: 0.0478
DEBUG - 2022-07-08 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:14 --> Total execution time: 0.0600
DEBUG - 2022-07-08 21:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:14 --> Total execution time: 0.1126
DEBUG - 2022-07-08 21:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:35:30 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:36 --> Total execution time: 0.0554
DEBUG - 2022-07-08 21:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:38 --> Total execution time: 0.0752
DEBUG - 2022-07-08 21:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:35:38 --> Total execution time: 0.1331
DEBUG - 2022-07-08 21:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-08 21:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:36:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 21:36:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-08 21:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:42:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:53:10 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:53:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 21:53:12 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 21:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:53:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:54:06 --> No URI present. Default controller set.
DEBUG - 2022-07-08 21:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 21:55:49 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 21:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:57:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 21:57:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 21:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 21:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 21:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:07:15 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:08:45 --> Total execution time: 0.0606
DEBUG - 2022-07-08 22:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:08:52 --> Total execution time: 0.1235
DEBUG - 2022-07-08 22:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:14:24 --> Total execution time: 0.0796
DEBUG - 2022-07-08 22:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:14:36 --> Total execution time: 0.1363
DEBUG - 2022-07-08 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:22:14 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-08 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:19 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-07-08 22:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:21 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:22 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:23 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:25 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:26 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:28 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:24:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 22:24:29 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 22:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:30:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:36:51 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:37:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:47:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:39 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:52:59 --> Total execution time: 0.0372
DEBUG - 2022-07-08 22:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:01 --> Total execution time: 0.0598
DEBUG - 2022-07-08 22:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:01 --> Total execution time: 0.1206
DEBUG - 2022-07-08 22:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:59:53 --> No URI present. Default controller set.
DEBUG - 2022-07-08 22:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 22:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 22:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 22:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:03:49 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:09:33 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:44 --> Total execution time: 0.0489
DEBUG - 2022-07-08 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:48 --> Total execution time: 0.0584
DEBUG - 2022-07-08 23:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:48 --> Total execution time: 0.1266
DEBUG - 2022-07-08 23:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:12:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:13:58 --> Total execution time: 0.0589
DEBUG - 2022-07-08 23:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:14:08 --> Total execution time: 0.0544
DEBUG - 2022-07-08 23:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:14:18 --> Total execution time: 0.0546
DEBUG - 2022-07-08 23:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:14:18 --> Total execution time: 0.1345
DEBUG - 2022-07-08 23:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:14:59 --> Total execution time: 0.0509
DEBUG - 2022-07-08 23:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:01 --> Total execution time: 0.0481
DEBUG - 2022-07-08 23:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:01 --> Total execution time: 0.0718
DEBUG - 2022-07-08 23:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:15:59 --> Total execution time: 0.0523
DEBUG - 2022-07-08 23:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:00 --> Total execution time: 0.0573
DEBUG - 2022-07-08 23:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:00 --> Total execution time: 0.1216
DEBUG - 2022-07-08 23:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:16 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:22 --> Total execution time: 0.0503
DEBUG - 2022-07-08 23:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:23 --> Total execution time: 0.0560
DEBUG - 2022-07-08 23:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:24 --> Total execution time: 0.1329
DEBUG - 2022-07-08 23:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:40 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:18:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:18:44 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:25 --> Total execution time: 0.0348
DEBUG - 2022-07-08 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:27 --> Total execution time: 0.0631
DEBUG - 2022-07-08 23:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:27 --> Total execution time: 0.1078
DEBUG - 2022-07-08 23:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:22:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:22:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 23:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:22:25 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-08 23:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:32:56 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:37:14 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:38:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:38:54 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-08 23:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:39:17 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:41:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-08 23:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:22 --> Total execution time: 0.0528
DEBUG - 2022-07-08 23:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:23 --> Total execution time: 0.0551
DEBUG - 2022-07-08 23:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:23 --> Total execution time: 0.1147
DEBUG - 2022-07-08 23:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:31 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:32 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:44:06 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-08 23:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:25 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:44:58 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:23 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:07 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:11 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:36 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-08 23:47:17 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-08 23:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:18 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:33 --> Total execution time: 0.0502
DEBUG - 2022-07-08 23:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:35 --> Total execution time: 0.0608
DEBUG - 2022-07-08 23:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:35 --> Total execution time: 0.1447
DEBUG - 2022-07-08 23:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:48:57 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:49:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:49:08 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:29 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:50:55 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:52:05 --> No URI present. Default controller set.
DEBUG - 2022-07-08 23:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:20 --> Total execution time: 0.0536
DEBUG - 2022-07-08 23:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-08 23:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-08 23:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-08 23:59:41 --> Encryption: Auto-configured driver 'openssl'.
