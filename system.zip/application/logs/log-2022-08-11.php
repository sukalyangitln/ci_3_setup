<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-11 00:00:17 --> Total execution time: 0.3047
DEBUG - 2022-08-11 00:03:34 --> Total execution time: 0.1067
DEBUG - 2022-08-11 00:03:45 --> Total execution time: 0.0774
DEBUG - 2022-08-11 00:05:02 --> Total execution time: 0.0710
DEBUG - 2022-08-11 00:05:21 --> Total execution time: 0.0845
DEBUG - 2022-08-11 00:05:22 --> Total execution time: 0.0683
DEBUG - 2022-08-11 00:05:31 --> Total execution time: 0.0754
DEBUG - 2022-08-11 00:05:45 --> Total execution time: 0.0785
DEBUG - 2022-08-11 00:05:46 --> Total execution time: 0.0721
DEBUG - 2022-08-11 00:06:34 --> Total execution time: 0.0869
DEBUG - 2022-08-11 00:06:54 --> Total execution time: 0.0882
DEBUG - 2022-08-11 00:06:56 --> Total execution time: 0.0800
DEBUG - 2022-08-11 00:07:10 --> Total execution time: 0.1156
DEBUG - 2022-08-11 00:07:28 --> Total execution time: 0.1188
DEBUG - 2022-08-11 00:07:38 --> Total execution time: 0.1118
DEBUG - 2022-08-11 00:07:42 --> Total execution time: 0.0793
DEBUG - 2022-08-11 00:07:54 --> Total execution time: 0.1559
DEBUG - 2022-08-11 00:08:16 --> Total execution time: 0.1059
DEBUG - 2022-08-11 00:08:22 --> Total execution time: 0.0820
DEBUG - 2022-08-11 00:08:29 --> Total execution time: 0.0828
DEBUG - 2022-08-11 00:10:20 --> Total execution time: 0.2209
DEBUG - 2022-08-11 00:11:33 --> Total execution time: 0.1047
DEBUG - 2022-08-11 00:11:54 --> Total execution time: 0.0801
DEBUG - 2022-08-11 00:12:48 --> Total execution time: 0.0716
DEBUG - 2022-08-11 00:12:49 --> Total execution time: 0.0515
DEBUG - 2022-08-11 00:13:29 --> Total execution time: 0.0556
DEBUG - 2022-08-11 00:13:52 --> Total execution time: 0.0813
DEBUG - 2022-08-11 00:14:24 --> Total execution time: 0.0491
DEBUG - 2022-08-11 00:14:42 --> Total execution time: 0.0768
DEBUG - 2022-08-11 00:14:54 --> Total execution time: 0.0856
DEBUG - 2022-08-11 00:15:15 --> Total execution time: 0.0862
DEBUG - 2022-08-11 00:15:26 --> Total execution time: 0.0808
DEBUG - 2022-08-11 00:15:39 --> Total execution time: 0.0882
DEBUG - 2022-08-11 00:15:45 --> Total execution time: 0.1371
DEBUG - 2022-08-11 00:16:27 --> Total execution time: 0.0891
DEBUG - 2022-08-11 00:16:37 --> Total execution time: 0.0489
DEBUG - 2022-08-11 00:16:39 --> Total execution time: 0.0983
DEBUG - 2022-08-11 00:16:48 --> Total execution time: 0.1021
DEBUG - 2022-08-11 00:17:02 --> Total execution time: 0.0490
DEBUG - 2022-08-11 00:17:20 --> Total execution time: 0.0774
DEBUG - 2022-08-11 00:17:53 --> Total execution time: 0.0789
DEBUG - 2022-08-11 00:17:54 --> Total execution time: 0.0777
DEBUG - 2022-08-11 00:24:25 --> Total execution time: 0.2559
DEBUG - 2022-08-11 00:24:33 --> Total execution time: 0.0795
DEBUG - 2022-08-11 00:30:03 --> Total execution time: 0.1969
DEBUG - 2022-08-11 00:36:02 --> Total execution time: 0.1010
DEBUG - 2022-08-11 00:36:06 --> Total execution time: 0.0500
DEBUG - 2022-08-11 00:36:07 --> Total execution time: 0.0753
DEBUG - 2022-08-11 00:36:15 --> Total execution time: 0.1220
DEBUG - 2022-08-11 00:36:30 --> Total execution time: 0.0737
DEBUG - 2022-08-11 00:36:34 --> Total execution time: 0.0737
DEBUG - 2022-08-11 00:36:35 --> Total execution time: 0.0724
DEBUG - 2022-08-11 00:36:51 --> Total execution time: 0.0482
DEBUG - 2022-08-11 00:41:06 --> Total execution time: 0.1072
DEBUG - 2022-08-11 00:42:17 --> Total execution time: 0.0555
DEBUG - 2022-08-11 00:44:53 --> Total execution time: 0.0699
DEBUG - 2022-08-11 00:45:01 --> Total execution time: 0.0758
DEBUG - 2022-08-11 00:45:19 --> Total execution time: 0.0680
DEBUG - 2022-08-11 00:45:33 --> Total execution time: 0.1213
DEBUG - 2022-08-11 00:45:43 --> Total execution time: 0.1235
DEBUG - 2022-08-11 00:45:54 --> Total execution time: 0.0854
DEBUG - 2022-08-11 00:46:16 --> Total execution time: 0.1918
DEBUG - 2022-08-11 00:46:33 --> Total execution time: 0.0829
DEBUG - 2022-08-11 00:47:02 --> Total execution time: 0.0854
DEBUG - 2022-08-11 00:47:15 --> Total execution time: 0.0902
DEBUG - 2022-08-11 00:48:15 --> Total execution time: 0.1015
DEBUG - 2022-08-11 00:49:00 --> Total execution time: 0.1544
DEBUG - 2022-08-11 00:49:01 --> Total execution time: 0.1224
DEBUG - 2022-08-11 00:49:28 --> Total execution time: 0.0805
DEBUG - 2022-08-11 00:49:38 --> Total execution time: 0.0800
DEBUG - 2022-08-11 00:49:39 --> Total execution time: 0.0795
DEBUG - 2022-08-11 00:49:57 --> Total execution time: 0.1969
DEBUG - 2022-08-11 00:50:07 --> Total execution time: 0.0805
DEBUG - 2022-08-11 00:50:13 --> Total execution time: 0.0795
DEBUG - 2022-08-11 00:50:39 --> Total execution time: 0.0807
DEBUG - 2022-08-11 00:52:08 --> Total execution time: 0.0797
DEBUG - 2022-08-11 00:52:36 --> Total execution time: 0.0858
DEBUG - 2022-08-11 00:52:37 --> Total execution time: 0.0785
DEBUG - 2022-08-11 01:00:31 --> Total execution time: 0.1256
DEBUG - 2022-08-11 01:08:46 --> Total execution time: 0.2389
DEBUG - 2022-08-11 01:23:04 --> Total execution time: 0.2586
DEBUG - 2022-08-11 01:23:59 --> Total execution time: 0.0531
DEBUG - 2022-08-11 01:24:33 --> Total execution time: 0.0602
DEBUG - 2022-08-11 01:30:02 --> Total execution time: 0.2054
DEBUG - 2022-08-11 01:35:20 --> Total execution time: 0.0972
DEBUG - 2022-08-11 01:36:18 --> Total execution time: 0.0507
DEBUG - 2022-08-11 01:38:59 --> Total execution time: 0.0537
DEBUG - 2022-08-11 01:39:00 --> Total execution time: 0.0502
DEBUG - 2022-08-11 01:39:00 --> Total execution time: 0.0527
DEBUG - 2022-08-11 01:39:00 --> Total execution time: 0.0484
DEBUG - 2022-08-11 01:39:01 --> Total execution time: 0.1032
DEBUG - 2022-08-11 01:39:01 --> Total execution time: 0.2512
DEBUG - 2022-08-11 01:39:01 --> Total execution time: 0.0931
DEBUG - 2022-08-11 01:39:02 --> Total execution time: 0.0755
DEBUG - 2022-08-11 01:39:02 --> Total execution time: 0.1262
DEBUG - 2022-08-11 01:42:58 --> Total execution time: 0.1031
DEBUG - 2022-08-11 01:46:26 --> Total execution time: 0.0961
DEBUG - 2022-08-11 01:48:16 --> Total execution time: 0.2001
DEBUG - 2022-08-11 01:53:56 --> Total execution time: 0.1102
DEBUG - 2022-08-11 01:53:59 --> Total execution time: 0.0786
DEBUG - 2022-08-11 01:54:44 --> Total execution time: 0.1334
DEBUG - 2022-08-11 01:55:49 --> Total execution time: 0.0786
DEBUG - 2022-08-11 01:56:02 --> Total execution time: 0.0773
DEBUG - 2022-08-11 01:56:09 --> Total execution time: 0.0768
DEBUG - 2022-08-11 01:56:16 --> Total execution time: 0.0863
DEBUG - 2022-08-11 01:58:19 --> Total execution time: 0.1754
DEBUG - 2022-08-11 01:58:44 --> Total execution time: 0.0864
DEBUG - 2022-08-11 01:58:58 --> Total execution time: 0.2014
DEBUG - 2022-08-11 01:59:02 --> Total execution time: 0.0779
DEBUG - 2022-08-11 02:30:03 --> Total execution time: 0.2725
DEBUG - 2022-08-11 02:41:02 --> Total execution time: 0.1814
DEBUG - 2022-08-11 02:55:23 --> Total execution time: 0.1192
DEBUG - 2022-08-11 02:55:30 --> Total execution time: 0.0727
DEBUG - 2022-08-11 02:55:41 --> Total execution time: 0.1252
DEBUG - 2022-08-11 02:55:43 --> Total execution time: 0.0781
DEBUG - 2022-08-11 02:55:49 --> Total execution time: 0.1186
DEBUG - 2022-08-11 02:56:08 --> Total execution time: 0.1550
DEBUG - 2022-08-11 02:56:31 --> Total execution time: 0.0745
DEBUG - 2022-08-11 03:01:09 --> Total execution time: 0.0904
DEBUG - 2022-08-11 03:01:10 --> Total execution time: 0.0526
DEBUG - 2022-08-11 03:01:20 --> Total execution time: 0.1949
DEBUG - 2022-08-11 03:01:28 --> Total execution time: 0.0731
DEBUG - 2022-08-11 03:01:28 --> Total execution time: 0.0748
DEBUG - 2022-08-11 03:01:38 --> Total execution time: 0.0824
DEBUG - 2022-08-11 03:01:43 --> Total execution time: 0.1025
DEBUG - 2022-08-11 03:01:50 --> Total execution time: 0.1015
DEBUG - 2022-08-11 03:01:59 --> Total execution time: 0.0824
DEBUG - 2022-08-11 03:03:35 --> Total execution time: 0.0783
DEBUG - 2022-08-11 03:03:40 --> Total execution time: 0.0745
DEBUG - 2022-08-11 03:03:50 --> Total execution time: 0.0782
DEBUG - 2022-08-11 03:04:01 --> Total execution time: 0.1005
DEBUG - 2022-08-11 03:04:14 --> Total execution time: 0.0741
DEBUG - 2022-08-11 03:04:29 --> Total execution time: 0.0779
DEBUG - 2022-08-11 03:10:25 --> Total execution time: 2.2603
DEBUG - 2022-08-11 03:13:27 --> Total execution time: 0.1265
DEBUG - 2022-08-11 03:13:31 --> Total execution time: 0.2885
DEBUG - 2022-08-11 03:13:50 --> Total execution time: 0.1938
DEBUG - 2022-08-11 03:13:55 --> Total execution time: 0.0832
DEBUG - 2022-08-11 03:14:05 --> Total execution time: 0.1062
DEBUG - 2022-08-11 03:14:17 --> Total execution time: 0.0834
DEBUG - 2022-08-11 03:14:43 --> Total execution time: 0.0500
DEBUG - 2022-08-11 03:14:44 --> Total execution time: 0.0582
DEBUG - 2022-08-11 03:14:59 --> Total execution time: 0.0493
DEBUG - 2022-08-11 03:15:03 --> Total execution time: 0.0793
DEBUG - 2022-08-11 03:15:45 --> Total execution time: 0.0978
DEBUG - 2022-08-11 03:16:29 --> Total execution time: 0.0785
DEBUG - 2022-08-11 03:16:42 --> Total execution time: 0.0972
DEBUG - 2022-08-11 03:16:48 --> Total execution time: 0.0915
DEBUG - 2022-08-11 03:16:59 --> Total execution time: 0.0505
DEBUG - 2022-08-11 03:17:02 --> Total execution time: 0.0701
DEBUG - 2022-08-11 03:17:11 --> Total execution time: 0.0747
DEBUG - 2022-08-11 03:17:16 --> Total execution time: 0.0813
DEBUG - 2022-08-11 03:17:24 --> Total execution time: 0.0743
DEBUG - 2022-08-11 03:30:03 --> Total execution time: 0.1214
DEBUG - 2022-08-11 03:40:11 --> Total execution time: 0.1047
DEBUG - 2022-08-11 03:43:14 --> Total execution time: 0.1076
DEBUG - 2022-08-11 03:43:21 --> Total execution time: 0.0491
DEBUG - 2022-08-11 03:53:25 --> Total execution time: 0.1226
DEBUG - 2022-08-11 04:30:03 --> Total execution time: 0.2555
DEBUG - 2022-08-11 04:45:53 --> Total execution time: 0.1345
DEBUG - 2022-08-11 04:56:12 --> Total execution time: 0.1195
DEBUG - 2022-08-11 04:56:34 --> Total execution time: 0.1051
DEBUG - 2022-08-11 04:58:29 --> Total execution time: 0.0738
DEBUG - 2022-08-11 05:02:19 --> Total execution time: 0.0791
DEBUG - 2022-08-11 05:02:29 --> Total execution time: 0.0772
DEBUG - 2022-08-11 05:04:45 --> Total execution time: 0.0905
DEBUG - 2022-08-11 05:04:45 --> Total execution time: 0.0756
DEBUG - 2022-08-11 05:04:50 --> Total execution time: 0.0735
DEBUG - 2022-08-11 05:04:58 --> Total execution time: 0.0752
DEBUG - 2022-08-11 05:14:57 --> Total execution time: 0.1381
DEBUG - 2022-08-11 05:15:30 --> Total execution time: 0.0700
DEBUG - 2022-08-11 05:30:03 --> Total execution time: 0.1406
DEBUG - 2022-08-11 05:36:28 --> Total execution time: 0.0670
DEBUG - 2022-08-11 05:36:29 --> Total execution time: 0.0753
DEBUG - 2022-08-11 05:40:31 --> Total execution time: 0.1198
DEBUG - 2022-08-11 05:42:38 --> Total execution time: 0.1049
DEBUG - 2022-08-11 05:55:19 --> Total execution time: 0.1052
DEBUG - 2022-08-11 05:57:47 --> Total execution time: 0.1053
DEBUG - 2022-08-11 05:58:27 --> Total execution time: 0.0565
DEBUG - 2022-08-11 06:02:12 --> Total execution time: 0.1079
DEBUG - 2022-08-11 06:02:41 --> Total execution time: 0.0554
DEBUG - 2022-08-11 06:03:23 --> Total execution time: 0.0761
DEBUG - 2022-08-11 06:04:31 --> Total execution time: 0.1163
DEBUG - 2022-08-11 06:04:55 --> Total execution time: 0.0521
DEBUG - 2022-08-11 06:04:58 --> Total execution time: 0.1403
DEBUG - 2022-08-11 06:05:05 --> Total execution time: 0.0507
DEBUG - 2022-08-11 06:05:08 --> Total execution time: 0.0689
DEBUG - 2022-08-11 06:05:08 --> Total execution time: 0.0753
DEBUG - 2022-08-11 06:05:14 --> Total execution time: 0.0857
DEBUG - 2022-08-11 06:05:25 --> Total execution time: 0.0789
DEBUG - 2022-08-11 06:05:27 --> Total execution time: 0.0560
DEBUG - 2022-08-11 06:05:36 --> Total execution time: 0.1196
DEBUG - 2022-08-11 06:05:37 --> Total execution time: 0.0894
DEBUG - 2022-08-11 06:05:38 --> Total execution time: 0.0707
DEBUG - 2022-08-11 06:05:47 --> Total execution time: 0.1223
DEBUG - 2022-08-11 06:05:49 --> Total execution time: 0.0892
DEBUG - 2022-08-11 06:05:53 --> Total execution time: 0.0831
DEBUG - 2022-08-11 06:05:58 --> Total execution time: 0.0848
DEBUG - 2022-08-11 06:06:00 --> Total execution time: 0.0744
DEBUG - 2022-08-11 06:06:02 --> Total execution time: 0.0419
DEBUG - 2022-08-11 06:06:19 --> Total execution time: 0.0800
DEBUG - 2022-08-11 06:06:22 --> Total execution time: 0.0762
DEBUG - 2022-08-11 06:06:34 --> Total execution time: 0.0840
DEBUG - 2022-08-11 06:06:34 --> Total execution time: 0.0740
DEBUG - 2022-08-11 06:06:41 --> Total execution time: 0.0806
DEBUG - 2022-08-11 06:06:46 --> Total execution time: 0.0856
DEBUG - 2022-08-11 06:07:20 --> Total execution time: 0.0866
DEBUG - 2022-08-11 06:07:25 --> Total execution time: 0.1667
DEBUG - 2022-08-11 06:07:42 --> Total execution time: 0.2022
DEBUG - 2022-08-11 06:13:48 --> Total execution time: 0.1146
DEBUG - 2022-08-11 06:13:55 --> Total execution time: 0.0477
DEBUG - 2022-08-11 06:14:10 --> Total execution time: 0.0885
DEBUG - 2022-08-11 06:14:14 --> Total execution time: 0.1039
DEBUG - 2022-08-11 06:14:33 --> Total execution time: 0.1093
DEBUG - 2022-08-11 06:14:40 --> Total execution time: 0.1234
DEBUG - 2022-08-11 06:14:52 --> Total execution time: 0.0826
DEBUG - 2022-08-11 06:14:58 --> Total execution time: 0.0898
DEBUG - 2022-08-11 06:15:04 --> Total execution time: 0.0938
DEBUG - 2022-08-11 06:15:14 --> Total execution time: 0.0853
DEBUG - 2022-08-11 06:15:20 --> Total execution time: 0.1228
DEBUG - 2022-08-11 06:15:28 --> Total execution time: 0.1496
DEBUG - 2022-08-11 06:15:53 --> Total execution time: 0.0989
DEBUG - 2022-08-11 06:15:57 --> Total execution time: 0.1081
DEBUG - 2022-08-11 06:16:05 --> Total execution time: 0.1038
DEBUG - 2022-08-11 06:16:19 --> Total execution time: 0.1282
DEBUG - 2022-08-11 06:16:43 --> Total execution time: 0.1110
DEBUG - 2022-08-11 06:16:52 --> Total execution time: 0.0771
DEBUG - 2022-08-11 06:17:47 --> Total execution time: 0.1182
DEBUG - 2022-08-11 06:25:15 --> Total execution time: 0.1269
DEBUG - 2022-08-11 06:30:02 --> Total execution time: 0.2159
DEBUG - 2022-08-11 06:35:14 --> Total execution time: 0.0851
DEBUG - 2022-08-11 06:35:21 --> Total execution time: 0.0762
DEBUG - 2022-08-11 06:35:31 --> Total execution time: 0.1026
DEBUG - 2022-08-11 06:35:39 --> Total execution time: 0.0887
DEBUG - 2022-08-11 06:35:44 --> Total execution time: 0.0830
DEBUG - 2022-08-11 06:35:58 --> Total execution time: 0.0865
DEBUG - 2022-08-11 06:36:30 --> Total execution time: 0.1025
DEBUG - 2022-08-11 06:36:39 --> Total execution time: 0.0884
DEBUG - 2022-08-11 06:37:27 --> Total execution time: 0.0836
DEBUG - 2022-08-11 06:40:04 --> Total execution time: 0.1048
DEBUG - 2022-08-11 06:55:13 --> Total execution time: 0.1793
DEBUG - 2022-08-11 06:55:13 --> Total execution time: 0.1984
DEBUG - 2022-08-11 06:55:15 --> Total execution time: 0.0535
DEBUG - 2022-08-11 06:55:17 --> Total execution time: 0.0839
DEBUG - 2022-08-11 06:55:17 --> Total execution time: 0.0762
DEBUG - 2022-08-11 06:55:18 --> Total execution time: 0.0834
DEBUG - 2022-08-11 06:55:49 --> Total execution time: 0.0519
DEBUG - 2022-08-11 06:56:05 --> Total execution time: 0.0767
DEBUG - 2022-08-11 06:58:59 --> Total execution time: 0.0758
DEBUG - 2022-08-11 07:00:55 --> Total execution time: 0.0610
DEBUG - 2022-08-11 07:01:06 --> Total execution time: 0.0509
DEBUG - 2022-08-11 07:01:23 --> Total execution time: 0.0766
DEBUG - 2022-08-11 07:03:23 --> Total execution time: 0.0513
DEBUG - 2022-08-11 07:03:26 --> Total execution time: 0.0585
DEBUG - 2022-08-11 07:03:30 --> Total execution time: 0.0514
DEBUG - 2022-08-11 07:03:32 --> Total execution time: 0.0514
DEBUG - 2022-08-11 07:03:33 --> Total execution time: 0.0511
DEBUG - 2022-08-11 07:03:33 --> Total execution time: 0.0497
DEBUG - 2022-08-11 07:04:34 --> Total execution time: 0.0653
DEBUG - 2022-08-11 07:06:02 --> Total execution time: 2.3939
DEBUG - 2022-08-11 07:06:42 --> Total execution time: 0.0901
DEBUG - 2022-08-11 07:06:54 --> Total execution time: 0.0530
DEBUG - 2022-08-11 07:06:58 --> Total execution time: 0.1040
DEBUG - 2022-08-11 07:11:07 --> Total execution time: 0.2649
DEBUG - 2022-08-11 07:11:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 07:11:24 --> Total execution time: 0.0846
DEBUG - 2022-08-11 07:13:53 --> Total execution time: 0.1113
DEBUG - 2022-08-11 07:14:13 --> Total execution time: 0.0998
DEBUG - 2022-08-11 07:14:18 --> Total execution time: 0.1157
DEBUG - 2022-08-11 07:14:21 --> Total execution time: 0.1031
DEBUG - 2022-08-11 07:14:29 --> Total execution time: 0.0792
DEBUG - 2022-08-11 07:14:35 --> Total execution time: 0.0915
DEBUG - 2022-08-11 07:14:53 --> Total execution time: 0.0825
DEBUG - 2022-08-11 07:16:18 --> Total execution time: 0.0906
DEBUG - 2022-08-11 07:16:24 --> Total execution time: 0.0564
DEBUG - 2022-08-11 07:17:09 --> Total execution time: 0.0829
DEBUG - 2022-08-11 07:17:28 --> Total execution time: 0.0794
DEBUG - 2022-08-11 07:18:00 --> Total execution time: 0.0837
DEBUG - 2022-08-11 07:19:06 --> Total execution time: 0.1417
DEBUG - 2022-08-11 07:19:34 --> Total execution time: 0.0989
DEBUG - 2022-08-11 07:20:07 --> Total execution time: 0.0981
DEBUG - 2022-08-11 07:20:14 --> Total execution time: 0.0984
DEBUG - 2022-08-11 07:20:28 --> Total execution time: 0.0791
DEBUG - 2022-08-11 07:20:36 --> Total execution time: 0.0566
DEBUG - 2022-08-11 07:20:36 --> Total execution time: 0.0790
DEBUG - 2022-08-11 07:20:59 --> Total execution time: 0.1495
DEBUG - 2022-08-11 07:21:02 --> Total execution time: 0.0766
DEBUG - 2022-08-11 07:21:29 --> Total execution time: 0.0482
DEBUG - 2022-08-11 07:21:32 --> Total execution time: 1.7842
DEBUG - 2022-08-11 07:21:36 --> Total execution time: 0.0773
DEBUG - 2022-08-11 07:21:47 --> Total execution time: 0.0788
DEBUG - 2022-08-11 07:21:49 --> Total execution time: 0.1179
DEBUG - 2022-08-11 07:21:51 --> Total execution time: 0.0996
DEBUG - 2022-08-11 07:21:57 --> Total execution time: 0.0845
DEBUG - 2022-08-11 07:22:06 --> Total execution time: 0.0818
DEBUG - 2022-08-11 07:22:11 --> Total execution time: 0.0993
DEBUG - 2022-08-11 07:22:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 07:22:17 --> Total execution time: 0.1014
DEBUG - 2022-08-11 07:22:18 --> Total execution time: 0.0813
DEBUG - 2022-08-11 07:23:21 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 07:23:22 --> Total execution time: 0.1001
DEBUG - 2022-08-11 07:23:44 --> Total execution time: 0.1068
DEBUG - 2022-08-11 07:23:47 --> Total execution time: 0.1042
DEBUG - 2022-08-11 07:23:51 --> Total execution time: 0.1298
DEBUG - 2022-08-11 07:23:58 --> Total execution time: 0.1249
DEBUG - 2022-08-11 07:24:30 --> Total execution time: 0.1158
DEBUG - 2022-08-11 07:25:10 --> Total execution time: 0.0749
DEBUG - 2022-08-11 07:25:14 --> Total execution time: 0.0743
DEBUG - 2022-08-11 07:25:19 --> Total execution time: 0.0737
DEBUG - 2022-08-11 07:27:31 --> Total execution time: 0.0727
DEBUG - 2022-08-11 07:27:50 --> Total execution time: 0.0826
DEBUG - 2022-08-11 07:28:35 --> Total execution time: 0.4354
DEBUG - 2022-08-11 07:28:35 --> Total execution time: 0.1368
DEBUG - 2022-08-11 07:28:35 --> Total execution time: 0.1825
DEBUG - 2022-08-11 07:28:35 --> Total execution time: 0.0566
DEBUG - 2022-08-11 07:30:02 --> Total execution time: 0.0786
DEBUG - 2022-08-11 07:33:05 --> Total execution time: 0.0781
DEBUG - 2022-08-11 07:35:02 --> Total execution time: 0.2788
DEBUG - 2022-08-11 07:35:08 --> Total execution time: 0.1143
DEBUG - 2022-08-11 07:35:22 --> Total execution time: 0.1305
DEBUG - 2022-08-11 07:35:28 --> Total execution time: 0.0913
DEBUG - 2022-08-11 07:36:16 --> Total execution time: 0.0799
DEBUG - 2022-08-11 07:36:40 --> Total execution time: 0.0776
DEBUG - 2022-08-11 07:36:48 --> Total execution time: 0.1384
DEBUG - 2022-08-11 07:37:00 --> Total execution time: 0.1252
DEBUG - 2022-08-11 07:37:07 --> Total execution time: 0.0822
DEBUG - 2022-08-11 07:37:25 --> Total execution time: 0.0818
DEBUG - 2022-08-11 07:37:29 --> Total execution time: 0.0788
DEBUG - 2022-08-11 07:38:03 --> Total execution time: 0.1052
DEBUG - 2022-08-11 07:38:07 --> Total execution time: 0.0849
DEBUG - 2022-08-11 07:38:44 --> Total execution time: 0.1000
DEBUG - 2022-08-11 07:50:08 --> Total execution time: 0.1187
DEBUG - 2022-08-11 07:50:11 --> Total execution time: 0.0510
DEBUG - 2022-08-11 07:50:18 --> Total execution time: 0.1220
DEBUG - 2022-08-11 07:50:25 --> Total execution time: 0.0847
DEBUG - 2022-08-11 07:50:29 --> Total execution time: 0.0990
DEBUG - 2022-08-11 07:50:35 --> Total execution time: 0.0776
DEBUG - 2022-08-11 07:53:54 --> Total execution time: 0.0741
DEBUG - 2022-08-11 07:57:15 --> Total execution time: 0.2509
DEBUG - 2022-08-11 07:58:21 --> Total execution time: 0.0936
DEBUG - 2022-08-11 08:03:01 --> Total execution time: 0.1005
DEBUG - 2022-08-11 08:03:40 --> Total execution time: 0.0825
DEBUG - 2022-08-11 08:04:16 --> Total execution time: 0.0945
DEBUG - 2022-08-11 08:04:29 --> Total execution time: 0.0778
DEBUG - 2022-08-11 08:04:37 --> Total execution time: 0.0855
DEBUG - 2022-08-11 08:04:45 --> Total execution time: 0.0842
DEBUG - 2022-08-11 08:05:33 --> Total execution time: 0.0698
DEBUG - 2022-08-11 08:05:46 --> Total execution time: 0.0816
DEBUG - 2022-08-11 08:05:55 --> Total execution time: 0.1005
DEBUG - 2022-08-11 08:05:58 --> Total execution time: 0.0786
DEBUG - 2022-08-11 08:06:01 --> Total execution time: 0.1036
DEBUG - 2022-08-11 08:11:50 --> Total execution time: 0.0771
DEBUG - 2022-08-11 08:11:58 --> Total execution time: 0.0826
DEBUG - 2022-08-11 08:12:04 --> Total execution time: 0.1438
DEBUG - 2022-08-11 08:12:16 --> Total execution time: 0.0558
DEBUG - 2022-08-11 08:13:12 --> Total execution time: 0.0490
DEBUG - 2022-08-11 08:13:28 --> Total execution time: 0.0820
DEBUG - 2022-08-11 08:18:00 --> Total execution time: 0.0799
DEBUG - 2022-08-11 08:18:52 --> Total execution time: 0.0570
DEBUG - 2022-08-11 08:18:53 --> Total execution time: 0.0441
DEBUG - 2022-08-11 08:19:06 --> Total execution time: 0.0507
DEBUG - 2022-08-11 08:19:09 --> Total execution time: 0.0511
DEBUG - 2022-08-11 08:20:31 --> Total execution time: 0.0798
DEBUG - 2022-08-11 08:20:37 --> Total execution time: 0.1961
DEBUG - 2022-08-11 08:20:51 --> Total execution time: 0.0823
DEBUG - 2022-08-11 08:20:59 --> Total execution time: 0.0785
DEBUG - 2022-08-11 08:21:08 --> Total execution time: 0.0767
DEBUG - 2022-08-11 08:21:13 --> Total execution time: 0.0749
DEBUG - 2022-08-11 08:21:26 --> Total execution time: 0.0818
DEBUG - 2022-08-11 08:21:29 --> Total execution time: 0.1058
DEBUG - 2022-08-11 08:22:45 --> Total execution time: 2.1502
DEBUG - 2022-08-11 08:22:46 --> Total execution time: 0.1156
DEBUG - 2022-08-11 08:23:00 --> Total execution time: 0.0804
DEBUG - 2022-08-11 08:23:18 --> Total execution time: 0.0867
DEBUG - 2022-08-11 08:24:21 --> Total execution time: 0.0578
DEBUG - 2022-08-11 08:25:43 --> Total execution time: 0.1017
DEBUG - 2022-08-11 08:25:54 --> Total execution time: 0.1171
DEBUG - 2022-08-11 08:26:48 --> Total execution time: 0.1156
DEBUG - 2022-08-11 08:26:52 --> Total execution time: 0.1106
DEBUG - 2022-08-11 08:27:18 --> Total execution time: 0.1116
DEBUG - 2022-08-11 08:27:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 08:27:36 --> Total execution time: 0.1086
DEBUG - 2022-08-11 08:28:05 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 08:28:06 --> Total execution time: 0.1053
DEBUG - 2022-08-11 08:30:02 --> Total execution time: 0.0814
DEBUG - 2022-08-11 08:30:13 --> Total execution time: 0.2107
DEBUG - 2022-08-11 08:30:25 --> Total execution time: 0.0780
DEBUG - 2022-08-11 08:31:02 --> Total execution time: 0.0477
DEBUG - 2022-08-11 08:31:04 --> Total execution time: 0.0849
DEBUG - 2022-08-11 08:31:14 --> Total execution time: 0.0778
DEBUG - 2022-08-11 08:31:16 --> Total execution time: 0.1981
DEBUG - 2022-08-11 08:31:16 --> Total execution time: 0.0849
DEBUG - 2022-08-11 08:31:22 --> Total execution time: 0.0851
DEBUG - 2022-08-11 08:31:26 --> Total execution time: 0.0784
DEBUG - 2022-08-11 08:31:27 --> Total execution time: 0.0829
DEBUG - 2022-08-11 08:31:29 --> Total execution time: 0.1003
DEBUG - 2022-08-11 08:31:53 --> Total execution time: 0.0611
DEBUG - 2022-08-11 08:32:45 --> Total execution time: 0.1049
DEBUG - 2022-08-11 08:32:55 --> Total execution time: 0.2874
DEBUG - 2022-08-11 08:33:00 --> Total execution time: 0.0750
DEBUG - 2022-08-11 08:33:19 --> Total execution time: 1.5364
DEBUG - 2022-08-11 08:33:30 --> Total execution time: 1.5608
DEBUG - 2022-08-11 08:33:42 --> Total execution time: 0.0832
DEBUG - 2022-08-11 08:34:02 --> Total execution time: 0.0772
DEBUG - 2022-08-11 08:34:04 --> Total execution time: 0.0780
DEBUG - 2022-08-11 08:34:13 --> Total execution time: 0.0498
DEBUG - 2022-08-11 08:34:20 --> Total execution time: 0.0785
DEBUG - 2022-08-11 08:34:41 --> Total execution time: 0.1030
DEBUG - 2022-08-11 08:34:56 --> Total execution time: 0.0749
DEBUG - 2022-08-11 08:35:00 --> Total execution time: 0.0799
DEBUG - 2022-08-11 08:35:25 --> Total execution time: 0.0744
DEBUG - 2022-08-11 08:35:52 --> Total execution time: 0.0772
DEBUG - 2022-08-11 08:35:55 --> Total execution time: 0.0475
DEBUG - 2022-08-11 08:35:56 --> Total execution time: 0.0732
DEBUG - 2022-08-11 08:35:58 --> Total execution time: 0.2197
DEBUG - 2022-08-11 08:36:30 --> Total execution time: 0.0746
DEBUG - 2022-08-11 08:36:31 --> Total execution time: 0.0795
DEBUG - 2022-08-11 08:36:44 --> Total execution time: 0.0723
DEBUG - 2022-08-11 08:36:47 --> Total execution time: 0.0812
DEBUG - 2022-08-11 08:36:50 --> Total execution time: 0.1031
DEBUG - 2022-08-11 08:36:53 --> Total execution time: 0.0872
DEBUG - 2022-08-11 08:36:57 --> Total execution time: 0.0735
DEBUG - 2022-08-11 08:37:03 --> Total execution time: 0.0749
DEBUG - 2022-08-11 08:37:28 --> Total execution time: 0.0736
DEBUG - 2022-08-11 08:37:37 --> Total execution time: 0.0829
DEBUG - 2022-08-11 08:37:56 --> Total execution time: 0.0725
DEBUG - 2022-08-11 08:38:02 --> Total execution time: 0.0777
DEBUG - 2022-08-11 08:38:09 --> Total execution time: 0.0863
DEBUG - 2022-08-11 08:38:12 --> Total execution time: 0.0826
DEBUG - 2022-08-11 08:38:14 --> Total execution time: 0.0858
DEBUG - 2022-08-11 08:38:46 --> Total execution time: 0.1992
DEBUG - 2022-08-11 08:38:57 --> Total execution time: 0.0752
DEBUG - 2022-08-11 08:39:14 --> Total execution time: 0.0870
DEBUG - 2022-08-11 08:39:21 --> Total execution time: 0.0747
DEBUG - 2022-08-11 08:39:23 --> Total execution time: 0.0819
DEBUG - 2022-08-11 08:39:27 --> Total execution time: 0.0778
DEBUG - 2022-08-11 08:40:21 --> Total execution time: 0.0801
DEBUG - 2022-08-11 08:40:39 --> Total execution time: 0.0858
DEBUG - 2022-08-11 08:40:46 --> Total execution time: 0.1069
DEBUG - 2022-08-11 08:40:49 --> Total execution time: 0.1141
DEBUG - 2022-08-11 08:40:54 --> Total execution time: 0.0902
DEBUG - 2022-08-11 08:40:56 --> Total execution time: 0.0855
DEBUG - 2022-08-11 08:41:09 --> Total execution time: 0.0836
DEBUG - 2022-08-11 08:41:17 --> Total execution time: 0.0821
DEBUG - 2022-08-11 08:41:35 --> Total execution time: 0.0839
DEBUG - 2022-08-11 08:41:45 --> Total execution time: 0.1017
DEBUG - 2022-08-11 08:41:50 --> Total execution time: 0.0866
DEBUG - 2022-08-11 08:42:01 --> Total execution time: 0.0762
DEBUG - 2022-08-11 08:50:47 --> Total execution time: 0.0510
DEBUG - 2022-08-11 08:53:34 --> Total execution time: 0.1144
DEBUG - 2022-08-11 08:55:00 --> Total execution time: 0.0763
DEBUG - 2022-08-11 08:55:15 --> Total execution time: 0.0503
DEBUG - 2022-08-11 08:56:04 --> Total execution time: 0.0494
DEBUG - 2022-08-11 08:56:58 --> Total execution time: 0.1965
DEBUG - 2022-08-11 08:57:02 --> Total execution time: 0.2300
DEBUG - 2022-08-11 08:57:23 --> Total execution time: 0.0849
DEBUG - 2022-08-11 08:57:40 --> Total execution time: 0.0824
DEBUG - 2022-08-11 08:57:49 --> Total execution time: 0.0788
DEBUG - 2022-08-11 08:57:50 --> Total execution time: 0.0756
DEBUG - 2022-08-11 08:58:30 --> Total execution time: 0.0886
DEBUG - 2022-08-11 08:58:55 --> Total execution time: 0.0840
DEBUG - 2022-08-11 08:59:09 --> Total execution time: 0.0491
DEBUG - 2022-08-11 08:59:43 --> Total execution time: 0.0813
DEBUG - 2022-08-11 08:59:45 --> Total execution time: 0.0822
DEBUG - 2022-08-11 09:00:53 --> Total execution time: 0.0908
DEBUG - 2022-08-11 09:01:17 --> Total execution time: 0.2080
DEBUG - 2022-08-11 09:01:22 --> Total execution time: 0.1987
DEBUG - 2022-08-11 09:01:43 --> Total execution time: 0.0852
DEBUG - 2022-08-11 09:03:58 --> Total execution time: 0.1163
DEBUG - 2022-08-11 09:05:50 --> Total execution time: 0.0940
DEBUG - 2022-08-11 09:06:02 --> Total execution time: 0.1273
DEBUG - 2022-08-11 09:06:17 --> Total execution time: 0.0809
DEBUG - 2022-08-11 09:06:59 --> Total execution time: 2.1338
DEBUG - 2022-08-11 09:07:01 --> Total execution time: 1.5035
DEBUG - 2022-08-11 09:07:13 --> Total execution time: 0.0776
DEBUG - 2022-08-11 09:07:23 --> Total execution time: 0.0732
DEBUG - 2022-08-11 09:07:55 --> Total execution time: 0.0748
DEBUG - 2022-08-11 09:07:58 --> Total execution time: 0.1951
DEBUG - 2022-08-11 09:08:06 --> Total execution time: 0.0774
DEBUG - 2022-08-11 09:08:08 --> Total execution time: 0.0836
DEBUG - 2022-08-11 09:08:15 --> Total execution time: 0.0793
DEBUG - 2022-08-11 09:08:26 --> Total execution time: 0.0791
DEBUG - 2022-08-11 09:08:30 --> Total execution time: 0.0792
DEBUG - 2022-08-11 09:08:47 --> Total execution time: 0.0810
DEBUG - 2022-08-11 09:08:50 --> Total execution time: 0.0839
DEBUG - 2022-08-11 09:08:51 --> Total execution time: 0.0814
DEBUG - 2022-08-11 09:09:00 --> Total execution time: 0.0784
DEBUG - 2022-08-11 09:09:09 --> Total execution time: 0.0802
DEBUG - 2022-08-11 09:09:58 --> Total execution time: 0.0753
DEBUG - 2022-08-11 09:10:02 --> Total execution time: 0.1995
DEBUG - 2022-08-11 09:10:04 --> Total execution time: 1.6534
DEBUG - 2022-08-11 09:10:09 --> Total execution time: 0.0823
DEBUG - 2022-08-11 09:10:22 --> Total execution time: 0.0784
DEBUG - 2022-08-11 09:10:23 --> Total execution time: 0.0805
DEBUG - 2022-08-11 09:11:08 --> Total execution time: 0.0826
DEBUG - 2022-08-11 09:11:17 --> Total execution time: 0.1089
DEBUG - 2022-08-11 09:11:22 --> Total execution time: 0.0784
DEBUG - 2022-08-11 09:11:33 --> Total execution time: 0.1044
DEBUG - 2022-08-11 09:11:44 --> Total execution time: 0.0773
DEBUG - 2022-08-11 09:12:18 --> Total execution time: 0.1066
DEBUG - 2022-08-11 09:12:24 --> Total execution time: 0.0976
DEBUG - 2022-08-11 09:12:33 --> Total execution time: 0.0743
DEBUG - 2022-08-11 09:12:37 --> Total execution time: 0.0738
DEBUG - 2022-08-11 09:12:49 --> Total execution time: 0.0955
DEBUG - 2022-08-11 09:12:50 --> Total execution time: 0.0728
DEBUG - 2022-08-11 09:12:58 --> Total execution time: 0.0985
DEBUG - 2022-08-11 09:13:10 --> Total execution time: 0.1925
DEBUG - 2022-08-11 09:16:18 --> Total execution time: 0.0508
DEBUG - 2022-08-11 09:16:22 --> Total execution time: 0.0770
DEBUG - 2022-08-11 09:18:11 --> Total execution time: 0.0518
DEBUG - 2022-08-11 09:18:15 --> Total execution time: 0.0475
DEBUG - 2022-08-11 09:18:36 --> Total execution time: 0.0821
DEBUG - 2022-08-11 09:18:39 --> Total execution time: 0.1509
DEBUG - 2022-08-11 09:18:41 --> Total execution time: 0.1039
DEBUG - 2022-08-11 09:18:43 --> Total execution time: 0.1223
DEBUG - 2022-08-11 09:18:56 --> Total execution time: 0.0996
DEBUG - 2022-08-11 09:19:05 --> Total execution time: 0.0589
DEBUG - 2022-08-11 09:19:08 --> Total execution time: 0.0485
DEBUG - 2022-08-11 09:19:13 --> Total execution time: 0.1126
DEBUG - 2022-08-11 09:19:14 --> Total execution time: 0.0798
DEBUG - 2022-08-11 09:19:18 --> Total execution time: 0.0930
DEBUG - 2022-08-11 09:19:21 --> Total execution time: 0.1249
DEBUG - 2022-08-11 09:19:23 --> Total execution time: 0.1541
DEBUG - 2022-08-11 09:19:33 --> Total execution time: 0.1945
DEBUG - 2022-08-11 09:19:33 --> Total execution time: 0.0729
DEBUG - 2022-08-11 09:19:37 --> Total execution time: 0.0796
DEBUG - 2022-08-11 09:19:39 --> Total execution time: 0.0766
DEBUG - 2022-08-11 09:19:46 --> Total execution time: 0.0800
DEBUG - 2022-08-11 09:19:51 --> Total execution time: 0.0491
DEBUG - 2022-08-11 09:20:05 --> Total execution time: 0.1342
DEBUG - 2022-08-11 09:20:06 --> Total execution time: 0.1466
DEBUG - 2022-08-11 09:20:21 --> Total execution time: 0.0776
DEBUG - 2022-08-11 09:22:51 --> Total execution time: 0.3560
DEBUG - 2022-08-11 09:23:22 --> Total execution time: 0.2062
DEBUG - 2022-08-11 09:25:32 --> Total execution time: 0.1119
DEBUG - 2022-08-11 09:25:35 --> Total execution time: 0.1094
DEBUG - 2022-08-11 09:25:37 --> Total execution time: 0.0878
DEBUG - 2022-08-11 09:25:39 --> Total execution time: 0.0766
DEBUG - 2022-08-11 09:25:44 --> Total execution time: 0.0857
DEBUG - 2022-08-11 09:25:54 --> Total execution time: 0.0899
DEBUG - 2022-08-11 09:25:54 --> Total execution time: 0.1186
DEBUG - 2022-08-11 09:25:58 --> Total execution time: 0.2010
DEBUG - 2022-08-11 09:26:05 --> Total execution time: 0.0803
DEBUG - 2022-08-11 09:26:06 --> Total execution time: 0.1206
DEBUG - 2022-08-11 09:26:07 --> Total execution time: 0.0835
DEBUG - 2022-08-11 09:26:08 --> Total execution time: 0.0910
DEBUG - 2022-08-11 09:26:19 --> Total execution time: 0.0772
DEBUG - 2022-08-11 09:26:21 --> Total execution time: 0.0755
DEBUG - 2022-08-11 09:26:22 --> Total execution time: 0.1032
DEBUG - 2022-08-11 09:26:28 --> Total execution time: 0.0886
DEBUG - 2022-08-11 09:26:29 --> Total execution time: 0.1299
DEBUG - 2022-08-11 09:26:55 --> Total execution time: 0.0911
DEBUG - 2022-08-11 09:27:09 --> Total execution time: 0.0881
DEBUG - 2022-08-11 09:27:40 --> Total execution time: 0.0750
DEBUG - 2022-08-11 09:27:52 --> Total execution time: 0.0810
DEBUG - 2022-08-11 09:27:55 --> Total execution time: 0.0773
DEBUG - 2022-08-11 09:28:03 --> Total execution time: 0.1164
DEBUG - 2022-08-11 09:28:03 --> Total execution time: 0.0820
DEBUG - 2022-08-11 09:28:03 --> Total execution time: 0.0879
DEBUG - 2022-08-11 09:28:04 --> Total execution time: 0.0797
DEBUG - 2022-08-11 09:28:21 --> Total execution time: 0.1222
DEBUG - 2022-08-11 09:28:46 --> Total execution time: 0.0794
DEBUG - 2022-08-11 09:28:47 --> Total execution time: 0.0793
DEBUG - 2022-08-11 09:28:49 --> Total execution time: 0.1258
DEBUG - 2022-08-11 09:28:53 --> Total execution time: 0.0821
DEBUG - 2022-08-11 09:28:58 --> Total execution time: 0.1150
DEBUG - 2022-08-11 09:29:11 --> Total execution time: 0.0874
DEBUG - 2022-08-11 09:29:12 --> Total execution time: 0.0811
DEBUG - 2022-08-11 09:29:18 --> Total execution time: 0.0864
DEBUG - 2022-08-11 09:30:02 --> Total execution time: 0.0671
DEBUG - 2022-08-11 09:30:19 --> Total execution time: 0.0965
DEBUG - 2022-08-11 09:30:39 --> Total execution time: 0.0842
DEBUG - 2022-08-11 09:32:16 --> Total execution time: 0.2043
DEBUG - 2022-08-11 09:32:35 --> Total execution time: 0.0921
DEBUG - 2022-08-11 09:33:57 --> Total execution time: 0.0838
DEBUG - 2022-08-11 09:34:00 --> Total execution time: 0.0897
DEBUG - 2022-08-11 09:34:03 --> Total execution time: 0.0781
DEBUG - 2022-08-11 09:34:24 --> Total execution time: 0.0818
DEBUG - 2022-08-11 09:34:25 --> Total execution time: 0.0763
DEBUG - 2022-08-11 09:35:10 --> Total execution time: 0.0974
DEBUG - 2022-08-11 09:35:22 --> Total execution time: 0.2070
DEBUG - 2022-08-11 09:35:28 --> Total execution time: 0.0809
DEBUG - 2022-08-11 09:35:38 --> Total execution time: 0.0826
DEBUG - 2022-08-11 09:35:38 --> Total execution time: 0.1140
DEBUG - 2022-08-11 09:35:44 --> Total execution time: 0.0895
DEBUG - 2022-08-11 09:35:49 --> Total execution time: 0.0919
DEBUG - 2022-08-11 09:35:51 --> Total execution time: 0.0793
DEBUG - 2022-08-11 09:35:55 --> Total execution time: 0.0934
DEBUG - 2022-08-11 09:37:17 --> Total execution time: 0.2359
DEBUG - 2022-08-11 09:37:23 --> Total execution time: 0.0803
DEBUG - 2022-08-11 09:37:28 --> Total execution time: 0.0833
DEBUG - 2022-08-11 09:37:55 --> Total execution time: 0.0785
DEBUG - 2022-08-11 09:38:02 --> Total execution time: 0.0851
DEBUG - 2022-08-11 09:38:21 --> Total execution time: 0.0844
DEBUG - 2022-08-11 09:38:28 --> Total execution time: 0.0815
DEBUG - 2022-08-11 09:38:32 --> Total execution time: 0.1159
DEBUG - 2022-08-11 09:38:45 --> Total execution time: 0.0757
DEBUG - 2022-08-11 09:39:54 --> Total execution time: 0.0673
DEBUG - 2022-08-11 09:40:57 --> Total execution time: 0.1987
DEBUG - 2022-08-11 09:41:07 --> Total execution time: 0.0841
DEBUG - 2022-08-11 09:43:12 --> Total execution time: 0.0797
DEBUG - 2022-08-11 09:43:17 --> Total execution time: 0.0749
DEBUG - 2022-08-11 09:43:27 --> Total execution time: 0.0804
DEBUG - 2022-08-11 09:43:35 --> Total execution time: 0.1043
DEBUG - 2022-08-11 09:43:39 --> Total execution time: 0.1132
DEBUG - 2022-08-11 09:44:08 --> Total execution time: 0.0525
DEBUG - 2022-08-11 09:44:28 --> Total execution time: 0.0735
DEBUG - 2022-08-11 09:44:45 --> Total execution time: 0.0511
DEBUG - 2022-08-11 09:44:53 --> Total execution time: 0.0739
DEBUG - 2022-08-11 09:45:02 --> Total execution time: 0.1010
DEBUG - 2022-08-11 09:45:23 --> Total execution time: 0.1088
DEBUG - 2022-08-11 09:45:28 --> Total execution time: 0.0800
DEBUG - 2022-08-11 09:45:36 --> Total execution time: 0.0777
DEBUG - 2022-08-11 09:45:47 --> Total execution time: 0.0869
DEBUG - 2022-08-11 09:45:47 --> Total execution time: 0.0732
DEBUG - 2022-08-11 09:46:35 --> Total execution time: 0.0502
DEBUG - 2022-08-11 09:46:40 --> Total execution time: 0.0751
DEBUG - 2022-08-11 09:46:55 --> Total execution time: 0.0847
DEBUG - 2022-08-11 09:46:58 --> Total execution time: 0.1024
DEBUG - 2022-08-11 09:47:04 --> Total execution time: 0.0731
DEBUG - 2022-08-11 09:49:06 --> Total execution time: 0.0563
DEBUG - 2022-08-11 09:49:39 --> Total execution time: 0.0632
DEBUG - 2022-08-11 09:51:47 --> Total execution time: 0.0799
DEBUG - 2022-08-11 09:52:00 --> Total execution time: 0.0843
DEBUG - 2022-08-11 09:52:11 --> Total execution time: 0.0928
DEBUG - 2022-08-11 09:52:17 --> Total execution time: 0.0936
DEBUG - 2022-08-11 09:53:19 --> Total execution time: 0.2132
DEBUG - 2022-08-11 09:53:37 --> Total execution time: 0.0865
DEBUG - 2022-08-11 09:53:37 --> Total execution time: 0.0776
DEBUG - 2022-08-11 09:53:39 --> Total execution time: 0.0813
DEBUG - 2022-08-11 10:02:44 --> Total execution time: 0.2874
DEBUG - 2022-08-11 10:02:52 --> Total execution time: 0.1229
DEBUG - 2022-08-11 10:03:03 --> Total execution time: 0.2018
DEBUG - 2022-08-11 10:03:15 --> Total execution time: 0.1102
DEBUG - 2022-08-11 10:06:02 --> Total execution time: 0.1857
DEBUG - 2022-08-11 10:10:07 --> Total execution time: 0.1727
DEBUG - 2022-08-11 10:10:58 --> Total execution time: 0.2142
DEBUG - 2022-08-11 10:15:39 --> Total execution time: 0.0842
DEBUG - 2022-08-11 10:15:46 --> Total execution time: 0.0870
DEBUG - 2022-08-11 10:15:53 --> Total execution time: 0.0988
DEBUG - 2022-08-11 10:16:01 --> Total execution time: 0.1534
DEBUG - 2022-08-11 10:17:36 --> Total execution time: 0.1080
DEBUG - 2022-08-11 10:17:49 --> Total execution time: 0.0548
DEBUG - 2022-08-11 10:18:52 --> Total execution time: 0.0879
DEBUG - 2022-08-11 10:18:52 --> Total execution time: 0.1173
DEBUG - 2022-08-11 10:19:21 --> Total execution time: 0.1037
DEBUG - 2022-08-11 10:20:03 --> Total execution time: 0.0529
DEBUG - 2022-08-11 10:20:03 --> Total execution time: 0.0494
DEBUG - 2022-08-11 10:20:13 --> Total execution time: 0.1968
DEBUG - 2022-08-11 10:20:38 --> Total execution time: 0.0815
DEBUG - 2022-08-11 10:20:44 --> Total execution time: 0.0805
DEBUG - 2022-08-11 10:20:51 --> Total execution time: 0.0827
DEBUG - 2022-08-11 10:20:58 --> Total execution time: 0.0842
DEBUG - 2022-08-11 10:21:06 --> Total execution time: 0.1192
DEBUG - 2022-08-11 10:22:04 --> Total execution time: 0.0801
DEBUG - 2022-08-11 10:22:09 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 10:22:09 --> Total execution time: 0.1224
DEBUG - 2022-08-11 10:22:19 --> Total execution time: 0.0865
DEBUG - 2022-08-11 10:22:28 --> Total execution time: 0.0786
DEBUG - 2022-08-11 10:22:35 --> Total execution time: 0.0820
DEBUG - 2022-08-11 10:22:40 --> Total execution time: 0.0821
DEBUG - 2022-08-11 10:23:10 --> Total execution time: 0.0810
DEBUG - 2022-08-11 10:23:13 --> Total execution time: 0.0864
DEBUG - 2022-08-11 10:23:20 --> Total execution time: 0.0786
DEBUG - 2022-08-11 10:23:28 --> Total execution time: 0.2261
DEBUG - 2022-08-11 10:23:49 --> Total execution time: 0.0874
DEBUG - 2022-08-11 10:25:44 --> Total execution time: 0.0739
DEBUG - 2022-08-11 10:25:44 --> Total execution time: 0.0878
DEBUG - 2022-08-11 10:25:44 --> Total execution time: 0.0497
DEBUG - 2022-08-11 10:26:59 --> Total execution time: 0.0508
DEBUG - 2022-08-11 10:27:12 --> Total execution time: 0.0751
DEBUG - 2022-08-11 10:27:14 --> Total execution time: 0.2185
DEBUG - 2022-08-11 10:27:24 --> Total execution time: 0.0810
DEBUG - 2022-08-11 10:27:31 --> Total execution time: 0.0801
DEBUG - 2022-08-11 10:27:32 --> Total execution time: 0.0934
DEBUG - 2022-08-11 10:27:32 --> Total execution time: 0.0992
DEBUG - 2022-08-11 10:27:38 --> Total execution time: 0.0813
DEBUG - 2022-08-11 10:27:42 --> Total execution time: 0.1178
DEBUG - 2022-08-11 10:28:15 --> Total execution time: 0.0825
DEBUG - 2022-08-11 10:28:26 --> Total execution time: 0.1037
DEBUG - 2022-08-11 10:28:45 --> Total execution time: 0.0822
DEBUG - 2022-08-11 10:28:50 --> Total execution time: 0.0909
DEBUG - 2022-08-11 10:28:53 --> Total execution time: 0.0863
DEBUG - 2022-08-11 10:28:55 --> Total execution time: 0.1091
DEBUG - 2022-08-11 10:28:59 --> Total execution time: 0.0858
DEBUG - 2022-08-11 10:29:02 --> Total execution time: 0.0860
DEBUG - 2022-08-11 10:29:05 --> Total execution time: 0.1644
DEBUG - 2022-08-11 10:29:21 --> Total execution time: 0.0737
DEBUG - 2022-08-11 10:29:32 --> Total execution time: 0.0734
DEBUG - 2022-08-11 10:29:34 --> Total execution time: 0.1040
DEBUG - 2022-08-11 10:29:48 --> Total execution time: 0.0544
DEBUG - 2022-08-11 10:29:48 --> Total execution time: 0.0817
DEBUG - 2022-08-11 10:29:49 --> Total execution time: 0.0940
DEBUG - 2022-08-11 10:29:59 --> Total execution time: 0.0802
DEBUG - 2022-08-11 00:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:03 --> Total execution time: 0.0927
DEBUG - 2022-08-11 00:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:23 --> Total execution time: 0.0805
DEBUG - 2022-08-11 00:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:32 --> Total execution time: 0.0793
DEBUG - 2022-08-11 00:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:47 --> Total execution time: 0.1113
DEBUG - 2022-08-11 00:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:51 --> Total execution time: 0.0826
DEBUG - 2022-08-11 00:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:57 --> Total execution time: 0.1021
DEBUG - 2022-08-11 00:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:31:02 --> Total execution time: 0.0940
DEBUG - 2022-08-11 00:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:31:18 --> Total execution time: 0.0938
DEBUG - 2022-08-11 00:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:31:44 --> Total execution time: 0.1031
DEBUG - 2022-08-11 00:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:32:13 --> Total execution time: 0.0794
DEBUG - 2022-08-11 00:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:32:19 --> Total execution time: 0.0836
DEBUG - 2022-08-11 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:32:25 --> Total execution time: 0.0795
DEBUG - 2022-08-11 00:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:05:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:35:24 --> Total execution time: 0.0763
DEBUG - 2022-08-11 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:39:18 --> Total execution time: 0.1676
DEBUG - 2022-08-11 00:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:39:18 --> Total execution time: 0.2004
DEBUG - 2022-08-11 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:39:28 --> Total execution time: 0.1055
DEBUG - 2022-08-11 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:39:33 --> Total execution time: 0.0811
DEBUG - 2022-08-11 00:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:40:30 --> Total execution time: 0.0548
DEBUG - 2022-08-11 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:44:27 --> Total execution time: 0.1260
DEBUG - 2022-08-11 00:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:44:47 --> Total execution time: 0.2333
DEBUG - 2022-08-11 00:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:48:01 --> Total execution time: 0.1701
DEBUG - 2022-08-11 00:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:48:13 --> Total execution time: 0.0711
DEBUG - 2022-08-11 00:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:48:13 --> Total execution time: 0.0586
DEBUG - 2022-08-11 00:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:48:14 --> Total execution time: 0.0574
DEBUG - 2022-08-11 00:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:48:18 --> Total execution time: 0.0723
DEBUG - 2022-08-11 00:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:18:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:48:24 --> Total execution time: 0.0527
DEBUG - 2022-08-11 00:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:50:02 --> Total execution time: 0.1327
DEBUG - 2022-08-11 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:22:43 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:52:43 --> Total execution time: 0.1461
DEBUG - 2022-08-11 00:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:52:49 --> Total execution time: 0.0798
DEBUG - 2022-08-11 00:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:53:17 --> Total execution time: 0.0687
DEBUG - 2022-08-11 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:55:05 --> Total execution time: 0.0740
DEBUG - 2022-08-11 00:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:55:59 --> Total execution time: 0.0995
DEBUG - 2022-08-11 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:56:12 --> Total execution time: 0.0777
DEBUG - 2022-08-11 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:56:17 --> Total execution time: 0.0775
DEBUG - 2022-08-11 00:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:57:41 --> Total execution time: 0.0643
DEBUG - 2022-08-11 00:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:58:02 --> Total execution time: 0.2461
DEBUG - 2022-08-11 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:58:29 --> Total execution time: 0.0774
DEBUG - 2022-08-11 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:58:49 --> Total execution time: 0.1451
DEBUG - 2022-08-11 00:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:58:53 --> Total execution time: 0.0608
DEBUG - 2022-08-11 00:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:58:59 --> Total execution time: 0.0826
DEBUG - 2022-08-11 00:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:59:06 --> Total execution time: 0.0807
DEBUG - 2022-08-11 00:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:59:23 --> Total execution time: 0.0748
DEBUG - 2022-08-11 00:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:59:28 --> Total execution time: 0.1209
DEBUG - 2022-08-11 00:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:59:44 --> Total execution time: 0.0922
DEBUG - 2022-08-11 00:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:02 --> Total execution time: 0.0991
DEBUG - 2022-08-11 00:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:07 --> Total execution time: 0.0548
DEBUG - 2022-08-11 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:21 --> Total execution time: 0.0857
DEBUG - 2022-08-11 00:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:21 --> Total execution time: 0.0817
DEBUG - 2022-08-11 00:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:35 --> Total execution time: 0.0846
DEBUG - 2022-08-11 00:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:00:40 --> Total execution time: 0.1008
DEBUG - 2022-08-11 00:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:41 --> Total execution time: 0.0826
DEBUG - 2022-08-11 00:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:57 --> Total execution time: 0.0534
DEBUG - 2022-08-11 00:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:03 --> Total execution time: 0.0821
DEBUG - 2022-08-11 00:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:16 --> Total execution time: 0.1161
DEBUG - 2022-08-11 00:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:28 --> Total execution time: 0.0785
DEBUG - 2022-08-11 00:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:47 --> Total execution time: 0.1081
DEBUG - 2022-08-11 00:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:52 --> Total execution time: 0.0851
DEBUG - 2022-08-11 00:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:57 --> Total execution time: 0.0964
DEBUG - 2022-08-11 00:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:02 --> Total execution time: 0.0807
DEBUG - 2022-08-11 00:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:14 --> Total execution time: 0.0801
DEBUG - 2022-08-11 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:17 --> Total execution time: 0.0807
DEBUG - 2022-08-11 00:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:21 --> Total execution time: 0.0892
DEBUG - 2022-08-11 00:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:25 --> Total execution time: 0.0767
DEBUG - 2022-08-11 00:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:39:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:09:08 --> Total execution time: 0.1251
DEBUG - 2022-08-11 00:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:39:39 --> Total execution time: 0.0552
DEBUG - 2022-08-11 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:39:41 --> Total execution time: 0.0811
DEBUG - 2022-08-11 00:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:39:41 --> Total execution time: 0.0801
DEBUG - 2022-08-11 00:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:40:29 --> Total execution time: 0.1133
DEBUG - 2022-08-11 00:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:40:33 --> Total execution time: 0.0760
DEBUG - 2022-08-11 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:11:45 --> Total execution time: 2.0432
DEBUG - 2022-08-11 00:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:41:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:11:48 --> Total execution time: 0.0577
DEBUG - 2022-08-11 00:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:41:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 00:41:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 00:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:41:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:11:50 --> Total execution time: 0.0603
DEBUG - 2022-08-11 00:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:13:35 --> Total execution time: 0.2121
DEBUG - 2022-08-11 00:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:13:52 --> Total execution time: 0.0877
DEBUG - 2022-08-11 00:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:46:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:10 --> Total execution time: 0.1342
DEBUG - 2022-08-11 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:46:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:10 --> Total execution time: 0.0577
DEBUG - 2022-08-11 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:46:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:10 --> Total execution time: 0.0512
DEBUG - 2022-08-11 00:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:46:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:10 --> Total execution time: 0.0764
DEBUG - 2022-08-11 00:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:47:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:17:40 --> Total execution time: 0.0601
DEBUG - 2022-08-11 00:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:47:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:17:54 --> Total execution time: 0.0933
DEBUG - 2022-08-11 00:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:49:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:19:32 --> Total execution time: 0.0652
DEBUG - 2022-08-11 00:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:29 --> Total execution time: 0.0835
DEBUG - 2022-08-11 00:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:32 --> Total execution time: 0.0928
DEBUG - 2022-08-11 00:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:40 --> Total execution time: 0.0824
DEBUG - 2022-08-11 00:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:42 --> Total execution time: 0.1136
DEBUG - 2022-08-11 00:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:59 --> Total execution time: 0.1449
DEBUG - 2022-08-11 00:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:22:01 --> Total execution time: 0.0774
DEBUG - 2022-08-11 00:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:22:04 --> Total execution time: 0.0861
DEBUG - 2022-08-11 00:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:27:09 --> Total execution time: 0.1259
DEBUG - 2022-08-11 00:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:27:23 --> Total execution time: 0.0895
DEBUG - 2022-08-11 00:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:27:45 --> Total execution time: 0.0578
DEBUG - 2022-08-11 00:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 00:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:27:46 --> Total execution time: 0.0466
DEBUG - 2022-08-11 00:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:57:52 --> Total execution time: 0.0798
DEBUG - 2022-08-11 00:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:57:54 --> Total execution time: 0.1055
DEBUG - 2022-08-11 00:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:57:54 --> Total execution time: 0.1005
DEBUG - 2022-08-11 00:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 00:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 00:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:28:34 --> Total execution time: 2.1194
DEBUG - 2022-08-11 00:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 00:58:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 00:58:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:30:02 --> Total execution time: 0.1116
DEBUG - 2022-08-11 01:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:00:32 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:30:32 --> Total execution time: 0.0520
DEBUG - 2022-08-11 01:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:01:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:48 --> Total execution time: 0.0874
DEBUG - 2022-08-11 01:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:53 --> Total execution time: 0.0844
DEBUG - 2022-08-11 01:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:01:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:55 --> Total execution time: 0.0506
DEBUG - 2022-08-11 01:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:04 --> Total execution time: 0.2053
DEBUG - 2022-08-11 01:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:02:05 --> Total execution time: 0.0916
DEBUG - 2022-08-11 01:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:02:09 --> Total execution time: 0.0946
DEBUG - 2022-08-11 01:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:02:10 --> Total execution time: 0.0813
DEBUG - 2022-08-11 01:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:11 --> Total execution time: 0.0860
DEBUG - 2022-08-11 01:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:18 --> Total execution time: 0.0872
DEBUG - 2022-08-11 01:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:22 --> Total execution time: 0.1030
DEBUG - 2022-08-11 01:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:24 --> Total execution time: 0.0925
DEBUG - 2022-08-11 01:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:26 --> Total execution time: 0.0873
DEBUG - 2022-08-11 01:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:30 --> Total execution time: 0.0938
DEBUG - 2022-08-11 01:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:34 --> Total execution time: 0.1078
DEBUG - 2022-08-11 01:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:51 --> Total execution time: 0.1235
DEBUG - 2022-08-11 01:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:32:52 --> Total execution time: 0.0847
DEBUG - 2022-08-11 01:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:01 --> Total execution time: 0.0836
DEBUG - 2022-08-11 01:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:02 --> Total execution time: 0.0892
DEBUG - 2022-08-11 01:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:13 --> Total execution time: 0.0756
DEBUG - 2022-08-11 01:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:47 --> Total execution time: 0.0875
DEBUG - 2022-08-11 01:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:47 --> Total execution time: 0.0884
DEBUG - 2022-08-11 01:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:54 --> Total execution time: 0.1048
DEBUG - 2022-08-11 01:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:54 --> Total execution time: 0.0930
DEBUG - 2022-08-11 01:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:33:56 --> Total execution time: 0.1738
DEBUG - 2022-08-11 01:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:15 --> Total execution time: 0.1522
DEBUG - 2022-08-11 01:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:20 --> Total execution time: 0.0847
DEBUG - 2022-08-11 01:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:25 --> Total execution time: 0.1124
DEBUG - 2022-08-11 01:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:28 --> Total execution time: 0.1115
DEBUG - 2022-08-11 01:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:42 --> Total execution time: 0.0843
DEBUG - 2022-08-11 01:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:45 --> Total execution time: 0.1006
DEBUG - 2022-08-11 01:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:46 --> Total execution time: 0.0815
DEBUG - 2022-08-11 01:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:51 --> Total execution time: 0.0825
DEBUG - 2022-08-11 01:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:00 --> Total execution time: 0.0832
DEBUG - 2022-08-11 01:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:02 --> Total execution time: 0.0753
DEBUG - 2022-08-11 01:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:13 --> Total execution time: 0.0927
DEBUG - 2022-08-11 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:19 --> Total execution time: 0.0811
DEBUG - 2022-08-11 01:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:36 --> Total execution time: 0.1509
DEBUG - 2022-08-11 01:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:48 --> Total execution time: 0.0895
DEBUG - 2022-08-11 01:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:48 --> Total execution time: 0.0842
DEBUG - 2022-08-11 01:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:51 --> Total execution time: 0.0815
DEBUG - 2022-08-11 01:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:09 --> Total execution time: 0.0812
DEBUG - 2022-08-11 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:11:38 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:41:39 --> Total execution time: 0.1312
DEBUG - 2022-08-11 01:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:21 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:21 --> Total execution time: 0.0644
DEBUG - 2022-08-11 01:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:32 --> Total execution time: 0.0794
DEBUG - 2022-08-11 01:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:33 --> Total execution time: 0.0845
DEBUG - 2022-08-11 01:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:40 --> Total execution time: 0.0839
DEBUG - 2022-08-11 01:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:50 --> Total execution time: 0.0901
DEBUG - 2022-08-11 01:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:45:54 --> Total execution time: 0.1555
DEBUG - 2022-08-11 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:48:01 --> Total execution time: 0.0922
DEBUG - 2022-08-11 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:48:40 --> Total execution time: 0.1144
DEBUG - 2022-08-11 01:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:50:22 --> Total execution time: 0.0878
DEBUG - 2022-08-11 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:51:53 --> Total execution time: 0.2161
DEBUG - 2022-08-11 01:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:53:28 --> Total execution time: 0.0914
DEBUG - 2022-08-11 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:00:26 --> Total execution time: 42.3523
DEBUG - 2022-08-11 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:35:26 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:35:26 --> Unable to connect to the database
ERROR - 2022-08-11 01:35:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:35:26 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:35:26 --> Unable to connect to the database
ERROR - 2022-08-11 01:35:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:35:32 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:35:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:35:32 --> Unable to connect to the database
ERROR - 2022-08-11 01:35:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:35:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:35:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 01:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:36:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:36:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:36:36 --> Unable to connect to the database
ERROR - 2022-08-11 01:36:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:37:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:37:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:37:18 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:37:19 --> Unable to connect to the database
ERROR - 2022-08-11 01:37:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:37:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:38:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:38:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 12:08:25 --> Total execution time: 173.6635
DEBUG - 2022-08-11 01:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:39:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-08-11 01:39:54 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:39:59 --> Unable to connect to the database
ERROR - 2022-08-11 01:39:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:40:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:40:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:40:31 --> Unable to connect to the database
ERROR - 2022-08-11 01:40:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:40:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:40:32 --> Unable to connect to the database
ERROR - 2022-08-11 01:40:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:40:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:40:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:40:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:40:59 --> Unable to connect to the database
ERROR - 2022-08-11 01:40:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:42:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:42:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:42:17 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:42:17 --> Unable to connect to the database
ERROR - 2022-08-11 01:42:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:42:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-08-11 12:12:32 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7acce3a6ca7bd1eff9f73a4596f119fb5187f8b7', '112.79.140.12', 1660200152, '__ci_last_regenerate|i:1660199994;')
DEBUG - 2022-08-11 01:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:12:46 --> Total execution time: 137.8394
ERROR - 2022-08-11 12:15:41 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f2844abcb844f196575a3ced932efe21fae6314b', '112.79.140.12', 1660200341, '__ci_last_regenerate|i:1660200137;')
ERROR - 2022-08-11 12:15:41 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('dbdf31302a2d445f994a97cfb8f2c905573d8620', '112.79.140.12', 1660200341, '__ci_last_regenerate|i:1660200146;')
DEBUG - 2022-08-11 12:16:22 --> Total execution time: 274.4696
DEBUG - 2022-08-11 12:16:23 --> Total execution time: 277.6182
DEBUG - 2022-08-11 01:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:46:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 01:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:47:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:53:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:54:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:54:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:54:39 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:54:39 --> Unable to connect to the database
ERROR - 2022-08-11 01:54:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 12:25:51 --> Total execution time: 110.9125
DEBUG - 2022-08-11 01:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:29:03 --> Query error: Commands out of sync; you can't run this command now - Invalid query: INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30a5bd220ad3c3c8b44a2a61e2823a24b64972ff', '2401:4900:1a5d:436b:24b1:bd0d:708f:a11e', 1660201143, '__ci_last_regenerate|i:1660201077;')
DEBUG - 2022-08-11 01:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 01:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:59:03 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:59:03 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:59:03 --> Unable to connect to the database
ERROR - 2022-08-11 01:59:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
ERROR - 2022-08-11 01:59:03 --> Unable to connect to the database
ERROR - 2022-08-11 01:59:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 01:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:59:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:59:04 --> Unable to connect to the database
ERROR - 2022-08-11 01:59:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
ERROR - 2022-08-11 01:59:04 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 01:59:04 --> Unable to connect to the database
ERROR - 2022-08-11 01:59:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 01:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 01:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 01:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 01:59:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:00:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:00:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:00:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:00:27 --> Unable to connect to the database
ERROR - 2022-08-11 02:00:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:03:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:03:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:03:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:03:03 --> Unable to connect to the database
ERROR - 2022-08-11 02:03:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
ERROR - 2022-08-11 02:04:00 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:04:00 --> Unable to connect to the database
ERROR - 2022-08-11 02:04:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:04:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:04:21 --> Severity: Warning --> mysqli::real_connect(): (08004/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:04:21 --> Unable to connect to the database
ERROR - 2022-08-11 02:04:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:07:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:07:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:37:19 --> Total execution time: 0.4657
DEBUG - 2022-08-11 02:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:07:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:37:40 --> Total execution time: 0.0551
DEBUG - 2022-08-11 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:37:57 --> Total execution time: 0.1077
DEBUG - 2022-08-11 02:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:00 --> Total execution time: 0.0507
DEBUG - 2022-08-11 02:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:03 --> Total execution time: 0.0968
DEBUG - 2022-08-11 02:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:09 --> Total execution time: 0.0898
DEBUG - 2022-08-11 02:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:17 --> Total execution time: 0.0902
DEBUG - 2022-08-11 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:22 --> Total execution time: 0.0712
DEBUG - 2022-08-11 02:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:24 --> Total execution time: 0.0967
DEBUG - 2022-08-11 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:29 --> Total execution time: 0.0772
DEBUG - 2022-08-11 02:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:48 --> Total execution time: 0.0835
DEBUG - 2022-08-11 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:40:37 --> Total execution time: 0.1031
DEBUG - 2022-08-11 02:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:40:40 --> Total execution time: 0.0854
DEBUG - 2022-08-11 02:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:10:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:10:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:10:52 --> Unable to connect to the database
ERROR - 2022-08-11 02:10:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:10:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:10:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:10:57 --> Unable to connect to the database
ERROR - 2022-08-11 02:10:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:10:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:10:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:10:58 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:10:58 --> Unable to connect to the database
ERROR - 2022-08-11 02:10:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:03 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:07 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:07 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:09 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:17 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:17 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:18 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:20 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:21 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:11:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No such file or directory /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-11 02:11:22 --> Unable to connect to the database
ERROR - 2022-08-11 02:11:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-11 02:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:32 --> Total execution time: 0.0628
DEBUG - 2022-08-11 02:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:36 --> Total execution time: 0.0420
DEBUG - 2022-08-11 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:40 --> Total execution time: 0.0538
DEBUG - 2022-08-11 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:46 --> Total execution time: 0.0694
DEBUG - 2022-08-11 02:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:47 --> Total execution time: 0.0720
DEBUG - 2022-08-11 02:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:51 --> Total execution time: 0.0831
DEBUG - 2022-08-11 02:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:41:56 --> Total execution time: 0.1368
DEBUG - 2022-08-11 02:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:05 --> Total execution time: 0.1476
DEBUG - 2022-08-11 02:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:13 --> Total execution time: 0.0960
DEBUG - 2022-08-11 02:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:17 --> Total execution time: 0.1125
DEBUG - 2022-08-11 02:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:23 --> Total execution time: 0.1568
DEBUG - 2022-08-11 02:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:26 --> Total execution time: 0.1032
DEBUG - 2022-08-11 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:40 --> Total execution time: 0.0833
DEBUG - 2022-08-11 02:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:45 --> Total execution time: 0.1150
DEBUG - 2022-08-11 02:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:47 --> Total execution time: 0.0952
DEBUG - 2022-08-11 02:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:54 --> Total execution time: 0.0808
DEBUG - 2022-08-11 02:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:42:58 --> Total execution time: 0.1115
DEBUG - 2022-08-11 02:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:03 --> Total execution time: 0.1338
DEBUG - 2022-08-11 02:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:04 --> Total execution time: 0.0735
DEBUG - 2022-08-11 02:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:06 --> Total execution time: 0.0737
DEBUG - 2022-08-11 02:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:25 --> Total execution time: 0.0978
DEBUG - 2022-08-11 02:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:33 --> Total execution time: 0.0919
DEBUG - 2022-08-11 02:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:38 --> Total execution time: 0.3786
DEBUG - 2022-08-11 02:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:49 --> Total execution time: 0.0828
DEBUG - 2022-08-11 02:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:53 --> Total execution time: 0.1137
DEBUG - 2022-08-11 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:05 --> Total execution time: 0.0754
DEBUG - 2022-08-11 02:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:11 --> Total execution time: 0.0540
DEBUG - 2022-08-11 02:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:19 --> Total execution time: 0.0577
DEBUG - 2022-08-11 02:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:20 --> Total execution time: 0.0475
DEBUG - 2022-08-11 02:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:26 --> Total execution time: 0.0743
DEBUG - 2022-08-11 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:27 --> Total execution time: 0.0529
DEBUG - 2022-08-11 02:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:14:42 --> Total execution time: 0.0963
DEBUG - 2022-08-11 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:14:44 --> Total execution time: 0.1434
DEBUG - 2022-08-11 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:14:44 --> Total execution time: 0.0862
DEBUG - 2022-08-11 02:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:44:59 --> Total execution time: 0.0728
DEBUG - 2022-08-11 02:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:04 --> Total execution time: 0.0682
DEBUG - 2022-08-11 02:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:12 --> Total execution time: 0.2007
DEBUG - 2022-08-11 02:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:19 --> Total execution time: 0.1154
DEBUG - 2022-08-11 02:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:24 --> Total execution time: 0.0915
DEBUG - 2022-08-11 02:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:39 --> Total execution time: 0.0843
DEBUG - 2022-08-11 02:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:45:48 --> Total execution time: 2.0292
DEBUG - 2022-08-11 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:15:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:15:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 02:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:13 --> Total execution time: 0.0819
DEBUG - 2022-08-11 02:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:39 --> Total execution time: 0.0899
DEBUG - 2022-08-11 02:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:16:41 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:41 --> Total execution time: 0.0603
DEBUG - 2022-08-11 02:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:53 --> Total execution time: 0.0801
DEBUG - 2022-08-11 02:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:01 --> Total execution time: 0.0896
DEBUG - 2022-08-11 02:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:03 --> Total execution time: 0.0742
DEBUG - 2022-08-11 02:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:17:06 --> Total execution time: 0.0472
DEBUG - 2022-08-11 02:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:08 --> Total execution time: 0.0790
DEBUG - 2022-08-11 02:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:17:09 --> Total execution time: 0.0826
DEBUG - 2022-08-11 02:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:17:09 --> Total execution time: 0.0778
DEBUG - 2022-08-11 02:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:17 --> Total execution time: 0.0720
DEBUG - 2022-08-11 02:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:22 --> Total execution time: 0.0793
DEBUG - 2022-08-11 02:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:27 --> Total execution time: 0.0942
DEBUG - 2022-08-11 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:31 --> Total execution time: 0.0815
DEBUG - 2022-08-11 02:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:31 --> Total execution time: 0.0756
DEBUG - 2022-08-11 02:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:42 --> Total execution time: 0.0922
DEBUG - 2022-08-11 02:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:17:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:47 --> Total execution time: 0.0940
DEBUG - 2022-08-11 02:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 02:18:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 02:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:29 --> Total execution time: 0.0535
DEBUG - 2022-08-11 02:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:35 --> Total execution time: 0.0537
DEBUG - 2022-08-11 02:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:36 --> Total execution time: 0.0553
DEBUG - 2022-08-11 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:38 --> Total execution time: 0.0858
DEBUG - 2022-08-11 02:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:18:40 --> Total execution time: 0.0481
DEBUG - 2022-08-11 02:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:18:48 --> Total execution time: 0.0827
DEBUG - 2022-08-11 02:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:51 --> Total execution time: 0.0790
DEBUG - 2022-08-11 02:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:48:54 --> Total execution time: 0.0762
DEBUG - 2022-08-11 02:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:18 --> Total execution time: 0.0727
DEBUG - 2022-08-11 02:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:26 --> Total execution time: 0.1168
DEBUG - 2022-08-11 02:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:27 --> Total execution time: 0.0642
DEBUG - 2022-08-11 02:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:28 --> Total execution time: 0.0528
DEBUG - 2022-08-11 02:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:33 --> Total execution time: 0.0826
DEBUG - 2022-08-11 02:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:34 --> Total execution time: 0.0764
DEBUG - 2022-08-11 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:36 --> Total execution time: 0.0872
DEBUG - 2022-08-11 02:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:57 --> Total execution time: 0.0491
DEBUG - 2022-08-11 02:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:49:57 --> Total execution time: 0.0902
DEBUG - 2022-08-11 02:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:02 --> Total execution time: 0.1916
DEBUG - 2022-08-11 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:20:14 --> Total execution time: 0.0800
DEBUG - 2022-08-11 02:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:29 --> Total execution time: 0.0775
DEBUG - 2022-08-11 02:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:32 --> Total execution time: 0.0781
DEBUG - 2022-08-11 02:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:20:38 --> Total execution time: 0.1044
DEBUG - 2022-08-11 02:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:48 --> Total execution time: 0.0873
DEBUG - 2022-08-11 02:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:52 --> Total execution time: 0.1337
DEBUG - 2022-08-11 02:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:50:57 --> Total execution time: 0.0795
DEBUG - 2022-08-11 02:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:03 --> Total execution time: 0.0831
DEBUG - 2022-08-11 02:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:06 --> Total execution time: 0.1021
DEBUG - 2022-08-11 02:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:13 --> Total execution time: 0.1118
DEBUG - 2022-08-11 02:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:18 --> Total execution time: 0.0895
DEBUG - 2022-08-11 02:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:22 --> Total execution time: 0.0791
DEBUG - 2022-08-11 02:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:53 --> Total execution time: 0.0900
DEBUG - 2022-08-11 02:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:22:13 --> Total execution time: 0.0802
DEBUG - 2022-08-11 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:23:06 --> Total execution time: 0.0761
DEBUG - 2022-08-11 02:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:13 --> Total execution time: 0.1036
DEBUG - 2022-08-11 02:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:41 --> Total execution time: 0.0969
DEBUG - 2022-08-11 02:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:42 --> Total execution time: 0.1111
DEBUG - 2022-08-11 02:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:50 --> Total execution time: 0.0793
DEBUG - 2022-08-11 02:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:57 --> Total execution time: 0.0853
DEBUG - 2022-08-11 02:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:54:03 --> Total execution time: 0.0856
DEBUG - 2022-08-11 02:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:54:49 --> Total execution time: 0.1889
DEBUG - 2022-08-11 02:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:54:56 --> Total execution time: 0.0784
DEBUG - 2022-08-11 02:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:00 --> Total execution time: 0.1145
DEBUG - 2022-08-11 02:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:09 --> Total execution time: 0.0766
DEBUG - 2022-08-11 02:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:14 --> Total execution time: 0.0811
DEBUG - 2022-08-11 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:17 --> Total execution time: 0.0932
DEBUG - 2022-08-11 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:19 --> Total execution time: 0.1108
DEBUG - 2022-08-11 02:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:21 --> Total execution time: 0.0803
DEBUG - 2022-08-11 02:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:21 --> Total execution time: 0.0766
DEBUG - 2022-08-11 02:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:21 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:21 --> Total execution time: 0.2022
DEBUG - 2022-08-11 02:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:36 --> Total execution time: 0.0786
DEBUG - 2022-08-11 02:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:42 --> Total execution time: 0.1080
DEBUG - 2022-08-11 02:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:46 --> Total execution time: 0.1139
DEBUG - 2022-08-11 02:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:25:46 --> Total execution time: 0.0882
DEBUG - 2022-08-11 02:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:26:50 --> Total execution time: 0.0897
DEBUG - 2022-08-11 02:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:26:53 --> Total execution time: 0.1500
DEBUG - 2022-08-11 02:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:26:53 --> Total execution time: 0.0710
DEBUG - 2022-08-11 02:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:27:24 --> Total execution time: 0.0811
DEBUG - 2022-08-11 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:27:26 --> Total execution time: 0.0768
DEBUG - 2022-08-11 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:27:26 --> Total execution time: 0.1670
DEBUG - 2022-08-11 02:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:04 --> Total execution time: 0.0739
DEBUG - 2022-08-11 02:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:10 --> Total execution time: 0.0803
DEBUG - 2022-08-11 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:13 --> Total execution time: 0.0825
DEBUG - 2022-08-11 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:13 --> Total execution time: 0.1926
DEBUG - 2022-08-11 02:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:58:19 --> Total execution time: 0.0732
DEBUG - 2022-08-11 02:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:27 --> Total execution time: 0.0774
DEBUG - 2022-08-11 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:30 --> Total execution time: 0.0734
DEBUG - 2022-08-11 02:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:30 --> Total execution time: 0.1619
DEBUG - 2022-08-11 02:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:34 --> Total execution time: 0.0691
DEBUG - 2022-08-11 02:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:28:35 --> Total execution time: 0.0842
DEBUG - 2022-08-11 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:29:12 --> Total execution time: 0.0756
DEBUG - 2022-08-11 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:29:14 --> Total execution time: 0.0776
DEBUG - 2022-08-11 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:29:14 --> Total execution time: 0.0680
DEBUG - 2022-08-11 02:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:59:28 --> Total execution time: 0.0754
DEBUG - 2022-08-11 02:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:00:12 --> Total execution time: 0.0753
DEBUG - 2022-08-11 02:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:00:19 --> Total execution time: 0.0846
DEBUG - 2022-08-11 02:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:20 --> Total execution time: 0.0747
DEBUG - 2022-08-11 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:20 --> Total execution time: 0.0770
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:20 --> Total execution time: 0.1366
DEBUG - 2022-08-11 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:20 --> Total execution time: 0.0980
DEBUG - 2022-08-11 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:30:20 --> Total execution time: 0.0761
DEBUG - 2022-08-11 02:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:00:20 --> Total execution time: 0.0833
DEBUG - 2022-08-11 02:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:30:21 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:00:21 --> Total execution time: 0.0796
DEBUG - 2022-08-11 02:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:31:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:01:05 --> Total execution time: 0.0813
DEBUG - 2022-08-11 02:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:31:12 --> Total execution time: 0.0748
DEBUG - 2022-08-11 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:31:14 --> Total execution time: 0.0871
DEBUG - 2022-08-11 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:31:14 --> Total execution time: 0.0755
DEBUG - 2022-08-11 02:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:04 --> Total execution time: 0.0910
DEBUG - 2022-08-11 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:05 --> Total execution time: 0.0812
DEBUG - 2022-08-11 02:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:06 --> Total execution time: 0.1838
DEBUG - 2022-08-11 02:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:21 --> Total execution time: 0.0743
DEBUG - 2022-08-11 02:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:28 --> Total execution time: 0.1013
DEBUG - 2022-08-11 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:34 --> Total execution time: 0.1085
DEBUG - 2022-08-11 02:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:42 --> Total execution time: 0.0710
DEBUG - 2022-08-11 02:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:48 --> Total execution time: 0.0684
DEBUG - 2022-08-11 02:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:32:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:54 --> Total execution time: 0.0701
DEBUG - 2022-08-11 02:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:00 --> Total execution time: 0.0917
DEBUG - 2022-08-11 02:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:04 --> Total execution time: 0.0829
DEBUG - 2022-08-11 02:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:04 --> Total execution time: 0.0792
DEBUG - 2022-08-11 02:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:04 --> Total execution time: 0.0550
DEBUG - 2022-08-11 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:34 --> Total execution time: 0.0685
DEBUG - 2022-08-11 02:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:36 --> Total execution time: 0.0821
DEBUG - 2022-08-11 02:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:36 --> Total execution time: 0.1924
DEBUG - 2022-08-11 02:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:43 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:43 --> Total execution time: 0.0805
DEBUG - 2022-08-11 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:33:49 --> Total execution time: 0.0729
DEBUG - 2022-08-11 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:34:22 --> Total execution time: 0.0549
DEBUG - 2022-08-11 02:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:04:22 --> Total execution time: 0.0813
DEBUG - 2022-08-11 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:34:24 --> Total execution time: 0.0795
DEBUG - 2022-08-11 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:34:24 --> Total execution time: 0.0773
DEBUG - 2022-08-11 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:35:26 --> Total execution time: 0.0739
DEBUG - 2022-08-11 02:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:05:35 --> Total execution time: 0.0823
DEBUG - 2022-08-11 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:05:46 --> Total execution time: 0.1284
DEBUG - 2022-08-11 02:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:05:48 --> Total execution time: 0.1129
DEBUG - 2022-08-11 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:28 --> Total execution time: 0.2091
DEBUG - 2022-08-11 02:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:31 --> Total execution time: 0.0758
DEBUG - 2022-08-11 02:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:31 --> Total execution time: 0.0734
DEBUG - 2022-08-11 02:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:36 --> Total execution time: 0.0697
DEBUG - 2022-08-11 02:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:38 --> Total execution time: 0.0703
DEBUG - 2022-08-11 02:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:38 --> Total execution time: 0.0754
DEBUG - 2022-08-11 02:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:07:39 --> Total execution time: 0.0676
DEBUG - 2022-08-11 02:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:07:57 --> Total execution time: 0.0770
DEBUG - 2022-08-11 02:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:08:04 --> Total execution time: 0.0755
DEBUG - 2022-08-11 02:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:08:10 --> Total execution time: 0.0888
DEBUG - 2022-08-11 02:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:08:16 --> Total execution time: 0.1031
DEBUG - 2022-08-11 02:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:08:27 --> Total execution time: 0.0747
DEBUG - 2022-08-11 02:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:38:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:08:54 --> Total execution time: 0.0510
DEBUG - 2022-08-11 02:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:09:02 --> Total execution time: 0.1939
DEBUG - 2022-08-11 02:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:09:04 --> Total execution time: 0.1990
DEBUG - 2022-08-11 02:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:09:11 --> Total execution time: 0.0860
DEBUG - 2022-08-11 02:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:09:13 --> Total execution time: 0.0793
DEBUG - 2022-08-11 02:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:39:24 --> Total execution time: 0.1063
DEBUG - 2022-08-11 02:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:39:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:09:59 --> Total execution time: 0.0862
DEBUG - 2022-08-11 02:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:14 --> Total execution time: 0.0778
DEBUG - 2022-08-11 02:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:23 --> Total execution time: 0.0482
DEBUG - 2022-08-11 02:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:24 --> Total execution time: 0.0492
DEBUG - 2022-08-11 02:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:43 --> Total execution time: 0.0520
DEBUG - 2022-08-11 02:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:46 --> Total execution time: 0.0736
DEBUG - 2022-08-11 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:50 --> Total execution time: 0.0918
DEBUG - 2022-08-11 02:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:40:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:55 --> Total execution time: 0.0829
DEBUG - 2022-08-11 02:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:04 --> Total execution time: 0.0765
DEBUG - 2022-08-11 02:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:07 --> Total execution time: 0.0828
DEBUG - 2022-08-11 02:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:08 --> Total execution time: 0.0812
DEBUG - 2022-08-11 02:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:25 --> Total execution time: 0.0838
DEBUG - 2022-08-11 02:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:31 --> Total execution time: 0.0723
DEBUG - 2022-08-11 02:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:32 --> Total execution time: 0.0789
DEBUG - 2022-08-11 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:35 --> Total execution time: 0.0811
DEBUG - 2022-08-11 02:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:36 --> Total execution time: 0.0919
DEBUG - 2022-08-11 02:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:37 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:37 --> Total execution time: 0.0804
DEBUG - 2022-08-11 02:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:40 --> Total execution time: 0.1047
DEBUG - 2022-08-11 02:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:53 --> Total execution time: 0.0783
DEBUG - 2022-08-11 02:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:57 --> Total execution time: 0.1456
DEBUG - 2022-08-11 02:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:12:00 --> Total execution time: 2.0546
DEBUG - 2022-08-11 02:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:12:09 --> Total execution time: 0.0803
DEBUG - 2022-08-11 02:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:12:18 --> Total execution time: 0.1028
DEBUG - 2022-08-11 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:12:38 --> Total execution time: 0.0782
DEBUG - 2022-08-11 02:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:12:40 --> Total execution time: 0.2591
DEBUG - 2022-08-11 02:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:13:05 --> Total execution time: 0.0743
DEBUG - 2022-08-11 02:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:13:08 --> Total execution time: 0.0805
DEBUG - 2022-08-11 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:13:31 --> Total execution time: 0.0810
DEBUG - 2022-08-11 02:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:13:37 --> Total execution time: 0.0759
DEBUG - 2022-08-11 02:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 02:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:08 --> Total execution time: 0.0848
DEBUG - 2022-08-11 02:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:34 --> Total execution time: 0.0989
DEBUG - 2022-08-11 02:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:44 --> Total execution time: 0.0875
DEBUG - 2022-08-11 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:49 --> Total execution time: 0.0734
DEBUG - 2022-08-11 02:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:14:56 --> Total execution time: 0.0811
DEBUG - 2022-08-11 02:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:15:01 --> Total execution time: 0.1071
DEBUG - 2022-08-11 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:46:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:16:18 --> Total execution time: 0.0908
DEBUG - 2022-08-11 02:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:18:46 --> Total execution time: 0.1327
DEBUG - 2022-08-11 02:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:18:57 --> Total execution time: 0.0764
DEBUG - 2022-08-11 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:19:19 --> Total execution time: 0.0814
DEBUG - 2022-08-11 02:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:19:19 --> Total execution time: 0.1062
DEBUG - 2022-08-11 02:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:49:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:19:20 --> Total execution time: 0.1301
DEBUG - 2022-08-11 02:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:50:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:20:54 --> Total execution time: 0.0614
DEBUG - 2022-08-11 02:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:21:00 --> Total execution time: 0.0494
DEBUG - 2022-08-11 02:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:21:36 --> Total execution time: 0.0807
DEBUG - 2022-08-11 02:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:51:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:21:56 --> Total execution time: 0.1919
DEBUG - 2022-08-11 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:07 --> Total execution time: 0.2366
DEBUG - 2022-08-11 02:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:16 --> Total execution time: 0.1055
DEBUG - 2022-08-11 02:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:22 --> Total execution time: 0.0776
DEBUG - 2022-08-11 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:23 --> Total execution time: 0.2339
DEBUG - 2022-08-11 02:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:30 --> Total execution time: 0.1014
DEBUG - 2022-08-11 02:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:34 --> Total execution time: 0.0790
DEBUG - 2022-08-11 02:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:40 --> Total execution time: 0.1016
DEBUG - 2022-08-11 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:23:47 --> Total execution time: 0.1503
DEBUG - 2022-08-11 02:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:24:01 --> Total execution time: 0.0819
DEBUG - 2022-08-11 02:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:25:39 --> Total execution time: 0.0489
DEBUG - 2022-08-11 02:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:25:48 --> Total execution time: 0.0820
DEBUG - 2022-08-11 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:25:53 --> Total execution time: 0.0830
DEBUG - 2022-08-11 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:55:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:25:56 --> Total execution time: 0.0567
DEBUG - 2022-08-11 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:00 --> Total execution time: 0.0861
DEBUG - 2022-08-11 02:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:14 --> Total execution time: 0.0740
DEBUG - 2022-08-11 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:15 --> Total execution time: 0.0749
DEBUG - 2022-08-11 02:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:25 --> Total execution time: 0.0876
DEBUG - 2022-08-11 02:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:27 --> Total execution time: 0.0784
DEBUG - 2022-08-11 02:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:52 --> Total execution time: 0.1975
DEBUG - 2022-08-11 02:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:26:58 --> Total execution time: 0.0786
DEBUG - 2022-08-11 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:27:00 --> Total execution time: 0.0725
DEBUG - 2022-08-11 02:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 02:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:27:13 --> Total execution time: 0.2025
DEBUG - 2022-08-11 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:27:14 --> Total execution time: 0.0979
DEBUG - 2022-08-11 02:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 02:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 02:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 02:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:27:25 --> Total execution time: 0.1035
DEBUG - 2022-08-11 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:30:02 --> Total execution time: 0.2071
DEBUG - 2022-08-11 03:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:34:26 --> Total execution time: 0.1097
DEBUG - 2022-08-11 03:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:34:31 --> Total execution time: 0.0865
DEBUG - 2022-08-11 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:34:37 --> Total execution time: 0.0968
DEBUG - 2022-08-11 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:34:41 --> Total execution time: 0.0790
DEBUG - 2022-08-11 03:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:34:46 --> Total execution time: 0.1249
DEBUG - 2022-08-11 03:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:35:46 --> Total execution time: 0.2006
DEBUG - 2022-08-11 03:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:35:48 --> Total execution time: 0.0825
DEBUG - 2022-08-11 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:35:55 --> Total execution time: 0.0868
DEBUG - 2022-08-11 03:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:06:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:36:11 --> Total execution time: 0.0503
DEBUG - 2022-08-11 03:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:07:57 --> Total execution time: 0.0786
DEBUG - 2022-08-11 03:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:08:05 --> Total execution time: 0.1012
DEBUG - 2022-08-11 03:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:25 --> Total execution time: 0.0884
DEBUG - 2022-08-11 03:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:27 --> Total execution time: 0.0926
DEBUG - 2022-08-11 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:36 --> Total execution time: 0.0550
DEBUG - 2022-08-11 03:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:37 --> Total execution time: 0.0916
DEBUG - 2022-08-11 03:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:43 --> Total execution time: 0.0807
DEBUG - 2022-08-11 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:44 --> Total execution time: 0.1032
DEBUG - 2022-08-11 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:52 --> Total execution time: 0.0859
DEBUG - 2022-08-11 03:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:38:58 --> Total execution time: 0.1053
DEBUG - 2022-08-11 03:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:41:44 --> Total execution time: 0.0604
DEBUG - 2022-08-11 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:41:46 --> Total execution time: 0.0517
DEBUG - 2022-08-11 03:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:41:51 --> Total execution time: 0.0868
DEBUG - 2022-08-11 03:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:41:57 --> Total execution time: 0.0836
DEBUG - 2022-08-11 03:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:05 --> Total execution time: 0.0960
DEBUG - 2022-08-11 03:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:14 --> Total execution time: 0.1946
DEBUG - 2022-08-11 03:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:15 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:15 --> Total execution time: 0.0759
DEBUG - 2022-08-11 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:19 --> Total execution time: 0.0735
DEBUG - 2022-08-11 03:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:19 --> Total execution time: 0.0836
DEBUG - 2022-08-11 03:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:25 --> Total execution time: 0.0810
DEBUG - 2022-08-11 03:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:31 --> Total execution time: 0.1014
DEBUG - 2022-08-11 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:42:43 --> Total execution time: 0.1033
DEBUG - 2022-08-11 03:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:44:10 --> Total execution time: 0.0486
DEBUG - 2022-08-11 03:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:14:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:44:39 --> Total execution time: 0.1957
DEBUG - 2022-08-11 03:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:16:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:46:03 --> Total execution time: 0.0503
DEBUG - 2022-08-11 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:44 --> Total execution time: 0.0761
DEBUG - 2022-08-11 03:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:19:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:49:19 --> Total execution time: 0.0531
DEBUG - 2022-08-11 03:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:53:20 --> Total execution time: 0.2978
DEBUG - 2022-08-11 03:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:53:26 --> Total execution time: 0.1153
DEBUG - 2022-08-11 03:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:53:40 --> Total execution time: 0.0765
DEBUG - 2022-08-11 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:53:48 --> Total execution time: 0.0835
DEBUG - 2022-08-11 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:25:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 03:25:42 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-08-11 03:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:27:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:57:47 --> Total execution time: 0.2345
DEBUG - 2022-08-11 03:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:28:21 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:58:22 --> Total execution time: 0.1911
DEBUG - 2022-08-11 03:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:58:59 --> Total execution time: 0.0837
DEBUG - 2022-08-11 03:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:59:00 --> Total execution time: 0.0482
DEBUG - 2022-08-11 03:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:59:38 --> Total execution time: 0.0900
DEBUG - 2022-08-11 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:29:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:59:44 --> Total execution time: 0.0706
DEBUG - 2022-08-11 03:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:59:54 --> Total execution time: 0.0540
DEBUG - 2022-08-11 03:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:05 --> Total execution time: 0.0877
DEBUG - 2022-08-11 03:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:07 --> Total execution time: 0.0518
DEBUG - 2022-08-11 03:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:08 --> Total execution time: 0.0882
DEBUG - 2022-08-11 03:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:13 --> Total execution time: 0.0790
DEBUG - 2022-08-11 03:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:14 --> Total execution time: 0.0900
DEBUG - 2022-08-11 03:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:16 --> Total execution time: 0.0938
DEBUG - 2022-08-11 03:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:18 --> Total execution time: 0.0827
DEBUG - 2022-08-11 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:24 --> Total execution time: 0.0803
DEBUG - 2022-08-11 03:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:29 --> Total execution time: 0.0686
DEBUG - 2022-08-11 03:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:30 --> Total execution time: 0.1038
DEBUG - 2022-08-11 03:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:40 --> Total execution time: 0.1983
DEBUG - 2022-08-11 03:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:44 --> Total execution time: 0.0974
DEBUG - 2022-08-11 03:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:48 --> Total execution time: 0.0676
DEBUG - 2022-08-11 03:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:56 --> Total execution time: 0.0721
DEBUG - 2022-08-11 03:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:31:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 03:31:16 --> 404 Page Not Found: Wp-admin/install-helper-private.php
DEBUG - 2022-08-11 03:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:31:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:01:20 --> Total execution time: 0.0485
DEBUG - 2022-08-11 03:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:01:47 --> Total execution time: 0.0797
DEBUG - 2022-08-11 03:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:01:50 --> Total execution time: 0.0791
DEBUG - 2022-08-11 03:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:02:28 --> Total execution time: 0.1963
DEBUG - 2022-08-11 03:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 03:34:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-11 03:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:36:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:06:00 --> Total execution time: 0.0833
DEBUG - 2022-08-11 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:06:48 --> Total execution time: 0.0904
DEBUG - 2022-08-11 03:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:06:55 --> Total execution time: 0.0768
DEBUG - 2022-08-11 03:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:09:27 --> Total execution time: 0.1535
DEBUG - 2022-08-11 03:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:09:27 --> Total execution time: 0.3418
DEBUG - 2022-08-11 03:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:09:42 --> Total execution time: 0.0902
DEBUG - 2022-08-11 03:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:09:54 --> Total execution time: 0.0986
DEBUG - 2022-08-11 03:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:11:15 --> Total execution time: 0.0997
DEBUG - 2022-08-11 03:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:11:23 --> Total execution time: 0.0896
DEBUG - 2022-08-11 03:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:11:34 --> Total execution time: 0.0450
DEBUG - 2022-08-11 03:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:11:46 --> Total execution time: 0.0759
DEBUG - 2022-08-11 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:11:49 --> Total execution time: 0.1172
DEBUG - 2022-08-11 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:13 --> Total execution time: 0.1218
DEBUG - 2022-08-11 03:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:18 --> Total execution time: 0.1306
DEBUG - 2022-08-11 03:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:22 --> Total execution time: 0.1021
DEBUG - 2022-08-11 03:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:24 --> Total execution time: 0.0423
DEBUG - 2022-08-11 03:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:53 --> Total execution time: 0.0822
DEBUG - 2022-08-11 03:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:12:59 --> Total execution time: 0.0791
DEBUG - 2022-08-11 03:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:04 --> Total execution time: 0.2173
DEBUG - 2022-08-11 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:05 --> Total execution time: 0.0777
DEBUG - 2022-08-11 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:05 --> Total execution time: 0.0712
DEBUG - 2022-08-11 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:09 --> Total execution time: 0.0810
DEBUG - 2022-08-11 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:11 --> Total execution time: 0.0912
DEBUG - 2022-08-11 03:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:21 --> Total execution time: 0.0869
DEBUG - 2022-08-11 03:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:23 --> Total execution time: 0.1061
DEBUG - 2022-08-11 03:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:28 --> Total execution time: 0.0782
DEBUG - 2022-08-11 03:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:33 --> Total execution time: 0.1111
DEBUG - 2022-08-11 03:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:36 --> Total execution time: 0.0821
DEBUG - 2022-08-11 03:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:44 --> Total execution time: 0.0893
DEBUG - 2022-08-11 03:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:13:57 --> Total execution time: 0.0806
DEBUG - 2022-08-11 03:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:15:15 --> Total execution time: 0.0743
DEBUG - 2022-08-11 03:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:45:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:15:22 --> Total execution time: 0.0520
DEBUG - 2022-08-11 03:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:46:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:16:50 --> Total execution time: 0.0525
DEBUG - 2022-08-11 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:02 --> Total execution time: 0.0532
DEBUG - 2022-08-11 03:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:18 --> Total execution time: 0.0794
DEBUG - 2022-08-11 03:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:30 --> Total execution time: 0.0850
DEBUG - 2022-08-11 03:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:35 --> Total execution time: 0.0999
DEBUG - 2022-08-11 03:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:49:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:19:34 --> Total execution time: 0.2185
DEBUG - 2022-08-11 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:00 --> Total execution time: 0.0897
DEBUG - 2022-08-11 03:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:08 --> Total execution time: 0.0841
DEBUG - 2022-08-11 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:32 --> Total execution time: 0.0790
DEBUG - 2022-08-11 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:33 --> Total execution time: 0.0815
DEBUG - 2022-08-11 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:37 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:37 --> Total execution time: 0.1904
DEBUG - 2022-08-11 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:20:46 --> Total execution time: 0.0796
DEBUG - 2022-08-11 03:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:22:25 --> Total execution time: 0.1023
DEBUG - 2022-08-11 03:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:22:49 --> Total execution time: 0.0870
DEBUG - 2022-08-11 03:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:22:56 --> Total execution time: 0.0973
DEBUG - 2022-08-11 03:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:22:57 --> Total execution time: 0.0864
DEBUG - 2022-08-11 03:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:23:08 --> Total execution time: 0.0736
DEBUG - 2022-08-11 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:23:12 --> Total execution time: 0.0862
DEBUG - 2022-08-11 03:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:53:24 --> Total execution time: 0.0919
DEBUG - 2022-08-11 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:53:25 --> Total execution time: 0.0807
DEBUG - 2022-08-11 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:53:26 --> Total execution time: 0.0740
DEBUG - 2022-08-11 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:53:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:23:34 --> Total execution time: 0.0781
DEBUG - 2022-08-11 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:54:05 --> Total execution time: 0.0781
DEBUG - 2022-08-11 03:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:54:13 --> Total execution time: 0.1253
DEBUG - 2022-08-11 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:24:36 --> Total execution time: 0.0827
DEBUG - 2022-08-11 03:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:24:44 --> Total execution time: 0.0941
DEBUG - 2022-08-11 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:24:56 --> Total execution time: 0.1010
DEBUG - 2022-08-11 03:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:00 --> Total execution time: 0.1067
DEBUG - 2022-08-11 03:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:04 --> Total execution time: 0.0869
DEBUG - 2022-08-11 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:11 --> Total execution time: 0.0966
DEBUG - 2022-08-11 03:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:31 --> Total execution time: 0.0900
DEBUG - 2022-08-11 03:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:43 --> Total execution time: 0.0985
DEBUG - 2022-08-11 03:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:47 --> Total execution time: 0.0540
DEBUG - 2022-08-11 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:51 --> Total execution time: 0.0993
DEBUG - 2022-08-11 03:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:52 --> Total execution time: 0.0801
DEBUG - 2022-08-11 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:53 --> Total execution time: 0.0835
DEBUG - 2022-08-11 03:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:26:02 --> Total execution time: 0.0782
DEBUG - 2022-08-11 03:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:26:11 --> Total execution time: 0.0842
DEBUG - 2022-08-11 03:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:26:12 --> Total execution time: 0.1129
DEBUG - 2022-08-11 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:56:18 --> Total execution time: 0.0500
DEBUG - 2022-08-11 03:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:56:20 --> Total execution time: 0.0821
DEBUG - 2022-08-11 03:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:56:21 --> Total execution time: 0.0793
DEBUG - 2022-08-11 03:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:56:30 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:26:30 --> Total execution time: 0.0773
DEBUG - 2022-08-11 03:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 03:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:29:32 --> Total execution time: 0.0819
DEBUG - 2022-08-11 03:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:59:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 03:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 03:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:29:56 --> Total execution time: 0.0654
DEBUG - 2022-08-11 03:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 03:59:58 --> 404 Page Not Found: Wp-includes/class-wp-bar.php
DEBUG - 2022-08-11 03:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 03:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 03:59:59 --> 404 Page Not Found: Feed/index
DEBUG - 2022-08-11 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:30:03 --> Total execution time: 0.0585
DEBUG - 2022-08-11 04:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:02:15 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:32:15 --> Total execution time: 0.1201
DEBUG - 2022-08-11 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:33:02 --> Total execution time: 0.0804
DEBUG - 2022-08-11 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:35:26 --> Total execution time: 0.1280
DEBUG - 2022-08-11 04:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:27 --> Total execution time: 0.1111
DEBUG - 2022-08-11 04:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:37 --> Total execution time: 0.1029
DEBUG - 2022-08-11 04:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:51 --> Total execution time: 0.1241
DEBUG - 2022-08-11 04:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:53 --> Total execution time: 0.0679
DEBUG - 2022-08-11 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:54 --> Total execution time: 0.0829
DEBUG - 2022-08-11 04:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:36:55 --> Total execution time: 0.0777
DEBUG - 2022-08-11 04:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:00 --> Total execution time: 0.1189
DEBUG - 2022-08-11 04:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:03 --> Total execution time: 0.0519
DEBUG - 2022-08-11 04:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:06 --> Total execution time: 0.1381
DEBUG - 2022-08-11 04:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:13 --> Total execution time: 0.1119
DEBUG - 2022-08-11 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:53 --> Total execution time: 0.0770
DEBUG - 2022-08-11 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:37:55 --> Total execution time: 0.0780
DEBUG - 2022-08-11 04:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:38:21 --> Total execution time: 0.1914
DEBUG - 2022-08-11 04:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:38:26 --> Total execution time: 0.0800
DEBUG - 2022-08-11 04:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:38:33 --> Total execution time: 0.0762
DEBUG - 2022-08-11 04:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:38:40 --> Total execution time: 0.1147
DEBUG - 2022-08-11 04:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:09:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:09:02 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-11 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:40:13 --> Total execution time: 0.0730
DEBUG - 2022-08-11 04:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:20 --> Total execution time: 0.0548
DEBUG - 2022-08-11 04:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:24 --> Total execution time: 0.0503
DEBUG - 2022-08-11 04:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:32 --> Total execution time: 0.0994
DEBUG - 2022-08-11 04:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:35 --> Total execution time: 0.0823
DEBUG - 2022-08-11 04:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:40 --> Total execution time: 0.1118
DEBUG - 2022-08-11 04:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:41:46 --> Total execution time: 0.0807
DEBUG - 2022-08-11 04:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:12:49 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-11 04:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:42:57 --> Total execution time: 0.2582
DEBUG - 2022-08-11 04:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:43:04 --> Total execution time: 0.0759
DEBUG - 2022-08-11 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:13:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:43:49 --> Total execution time: 0.0538
DEBUG - 2022-08-11 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:19:00 --> 404 Page Not Found: Wp-content/languages
DEBUG - 2022-08-11 04:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:51:05 --> Total execution time: 0.0834
DEBUG - 2022-08-11 04:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:52:34 --> Total execution time: 0.1371
DEBUG - 2022-08-11 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:53:19 --> Total execution time: 0.0841
DEBUG - 2022-08-11 04:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:53:24 --> Total execution time: 0.1108
DEBUG - 2022-08-11 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:53:36 --> Total execution time: 0.0947
DEBUG - 2022-08-11 04:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:24:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:54:16 --> Total execution time: 0.0530
DEBUG - 2022-08-11 04:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:24:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:54:18 --> Total execution time: 0.0702
DEBUG - 2022-08-11 04:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:24:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:54:48 --> Total execution time: 0.0538
DEBUG - 2022-08-11 04:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:24:50 --> 404 Page Not Found: Feed/index
DEBUG - 2022-08-11 04:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:25:05 --> Total execution time: 0.0802
DEBUG - 2022-08-11 04:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:25:08 --> Total execution time: 0.0774
DEBUG - 2022-08-11 04:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:25:09 --> Total execution time: 0.0775
DEBUG - 2022-08-11 04:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:56:45 --> Total execution time: 1.9463
DEBUG - 2022-08-11 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:27:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:59:34 --> Total execution time: 0.0813
DEBUG - 2022-08-11 04:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:37:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:07:53 --> Total execution time: 0.2507
DEBUG - 2022-08-11 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:08:27 --> Total execution time: 0.0777
DEBUG - 2022-08-11 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:40:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:10:00 --> Total execution time: 0.0600
DEBUG - 2022-08-11 04:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:40:12 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:10:12 --> Total execution time: 0.0848
DEBUG - 2022-08-11 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:40:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:10:49 --> Total execution time: 0.0769
DEBUG - 2022-08-11 04:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:40:58 --> Total execution time: 0.0791
DEBUG - 2022-08-11 04:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:40:59 --> Total execution time: 0.1081
DEBUG - 2022-08-11 04:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:41:00 --> Total execution time: 0.0853
DEBUG - 2022-08-11 04:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:41:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:11:52 --> Total execution time: 0.2075
DEBUG - 2022-08-11 04:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:41:59 --> Total execution time: 0.0910
DEBUG - 2022-08-11 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:42:00 --> Total execution time: 0.0864
DEBUG - 2022-08-11 04:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:42:01 --> Total execution time: 0.0752
DEBUG - 2022-08-11 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:42:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:12:04 --> Total execution time: 0.1170
DEBUG - 2022-08-11 04:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:14:06 --> Total execution time: 3.6682
DEBUG - 2022-08-11 04:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:44:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:14:18 --> Total execution time: 0.0584
DEBUG - 2022-08-11 04:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:14:37 --> Total execution time: 0.0809
DEBUG - 2022-08-11 04:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:14:39 --> Total execution time: 0.2407
DEBUG - 2022-08-11 04:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:14:47 --> Total execution time: 0.0872
DEBUG - 2022-08-11 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:24 --> Total execution time: 0.2778
DEBUG - 2022-08-11 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:26 --> Total execution time: 0.0867
DEBUG - 2022-08-11 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:17:28 --> Total execution time: 1.6207
DEBUG - 2022-08-11 04:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:29 --> Total execution time: 1.9309
DEBUG - 2022-08-11 04:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:39 --> Total execution time: 0.0989
DEBUG - 2022-08-11 04:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:44 --> Total execution time: 0.0801
DEBUG - 2022-08-11 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:46 --> Total execution time: 0.0753
DEBUG - 2022-08-11 04:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:55 --> Total execution time: 0.1011
DEBUG - 2022-08-11 04:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:17:58 --> Total execution time: 0.1134
DEBUG - 2022-08-11 04:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:18:05 --> Total execution time: 0.0800
DEBUG - 2022-08-11 04:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:18:10 --> Total execution time: 0.1097
DEBUG - 2022-08-11 04:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:48:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:18:25 --> Total execution time: 0.0512
DEBUG - 2022-08-11 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:48:32 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:18:32 --> Total execution time: 0.0667
DEBUG - 2022-08-11 04:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:49:14 --> Total execution time: 0.0982
DEBUG - 2022-08-11 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:49:16 --> Total execution time: 0.0937
DEBUG - 2022-08-11 04:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:49:16 --> Total execution time: 0.0794
DEBUG - 2022-08-11 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:22:55 --> Total execution time: 1.5466
DEBUG - 2022-08-11 04:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 04:53:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:23:31 --> Total execution time: 0.0812
DEBUG - 2022-08-11 04:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:03 --> Total execution time: 0.1022
DEBUG - 2022-08-11 04:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:16 --> Total execution time: 0.0832
DEBUG - 2022-08-11 04:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:23 --> Total execution time: 0.0872
DEBUG - 2022-08-11 04:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:31 --> Total execution time: 0.0807
DEBUG - 2022-08-11 04:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:31 --> Total execution time: 0.0550
DEBUG - 2022-08-11 04:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:35 --> Total execution time: 0.0644
DEBUG - 2022-08-11 04:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:41 --> Total execution time: 1.6626
DEBUG - 2022-08-11 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:45 --> Total execution time: 0.1109
DEBUG - 2022-08-11 04:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:24:53 --> Total execution time: 0.1248
DEBUG - 2022-08-11 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:55:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:25:07 --> Total execution time: 0.2181
DEBUG - 2022-08-11 04:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:25:27 --> Total execution time: 0.0801
DEBUG - 2022-08-11 04:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:57:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:27:01 --> Total execution time: 0.0579
DEBUG - 2022-08-11 04:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:28:28 --> Total execution time: 0.0762
DEBUG - 2022-08-11 04:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:28:46 --> Total execution time: 0.0690
DEBUG - 2022-08-11 04:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:28:54 --> Total execution time: 0.0766
DEBUG - 2022-08-11 04:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:58:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:28:56 --> Total execution time: 0.1174
DEBUG - 2022-08-11 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:28:59 --> Total execution time: 0.0812
DEBUG - 2022-08-11 04:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:02 --> Total execution time: 0.0815
DEBUG - 2022-08-11 04:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:09 --> Total execution time: 0.0940
DEBUG - 2022-08-11 04:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:11 --> Total execution time: 0.1011
DEBUG - 2022-08-11 04:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:16 --> Total execution time: 0.0577
DEBUG - 2022-08-11 04:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:17 --> Total execution time: 0.0550
DEBUG - 2022-08-11 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:18 --> Total execution time: 0.1238
DEBUG - 2022-08-11 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:23 --> Total execution time: 0.2085
DEBUG - 2022-08-11 04:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:24 --> Total execution time: 0.0936
DEBUG - 2022-08-11 04:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:26 --> Total execution time: 0.0792
DEBUG - 2022-08-11 04:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:30 --> Total execution time: 0.0765
DEBUG - 2022-08-11 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 04:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:36 --> Total execution time: 0.0935
DEBUG - 2022-08-11 04:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:42 --> Total execution time: 0.1248
DEBUG - 2022-08-11 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:51 --> Total execution time: 0.0883
DEBUG - 2022-08-11 04:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:54 --> Total execution time: 0.0877
DEBUG - 2022-08-11 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:56 --> Total execution time: 0.0644
DEBUG - 2022-08-11 04:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 04:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 04:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:29:57 --> Total execution time: 0.0903
DEBUG - 2022-08-11 05:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:00 --> Total execution time: 0.0515
DEBUG - 2022-08-11 05:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:01 --> Total execution time: 0.1110
DEBUG - 2022-08-11 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:02 --> Total execution time: 0.1126
DEBUG - 2022-08-11 05:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:03 --> Total execution time: 0.1400
DEBUG - 2022-08-11 05:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:25 --> Total execution time: 0.1035
DEBUG - 2022-08-11 05:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:33 --> Total execution time: 0.0874
DEBUG - 2022-08-11 05:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:00:37 --> Total execution time: 0.0876
DEBUG - 2022-08-11 05:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:00:39 --> Total execution time: 0.0808
DEBUG - 2022-08-11 05:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:00:39 --> Total execution time: 0.1040
DEBUG - 2022-08-11 05:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:30:53 --> Total execution time: 0.0976
DEBUG - 2022-08-11 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:31:12 --> Total execution time: 0.1263
DEBUG - 2022-08-11 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:31:24 --> Total execution time: 0.0782
DEBUG - 2022-08-11 05:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:01:54 --> Total execution time: 0.0818
DEBUG - 2022-08-11 05:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:01:56 --> Total execution time: 0.0936
DEBUG - 2022-08-11 05:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:01:56 --> Total execution time: 0.0770
DEBUG - 2022-08-11 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:02:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:32:28 --> Total execution time: 0.0599
DEBUG - 2022-08-11 05:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:02:51 --> Total execution time: 0.0601
DEBUG - 2022-08-11 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:02:54 --> Total execution time: 0.1122
DEBUG - 2022-08-11 05:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:02:55 --> Total execution time: 0.0799
DEBUG - 2022-08-11 05:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:32:56 --> Total execution time: 0.0952
DEBUG - 2022-08-11 05:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:03:08 --> Total execution time: 0.0769
DEBUG - 2022-08-11 05:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:03:14 --> Total execution time: 0.0745
DEBUG - 2022-08-11 05:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:03:18 --> Total execution time: 0.0813
DEBUG - 2022-08-11 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:03:20 --> Total execution time: 0.0759
DEBUG - 2022-08-11 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:03:24 --> Total execution time: 0.0852
DEBUG - 2022-08-11 05:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:34:45 --> Total execution time: 2.1235
DEBUG - 2022-08-11 05:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:04:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 05:04:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:35:29 --> Total execution time: 0.0863
DEBUG - 2022-08-11 05:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:36:42 --> Total execution time: 0.1064
DEBUG - 2022-08-11 05:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:06:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:36:52 --> Total execution time: 0.1035
DEBUG - 2022-08-11 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:36:59 --> Total execution time: 0.1126
DEBUG - 2022-08-11 05:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:37:38 --> Total execution time: 0.0822
DEBUG - 2022-08-11 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:37:50 --> Total execution time: 0.0914
DEBUG - 2022-08-11 05:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:38:05 --> Total execution time: 0.2007
DEBUG - 2022-08-11 05:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:38:13 --> Total execution time: 0.0796
DEBUG - 2022-08-11 05:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:38:28 --> Total execution time: 0.0772
DEBUG - 2022-08-11 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:39:29 --> Total execution time: 0.0924
DEBUG - 2022-08-11 05:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:39:44 --> Total execution time: 0.2575
DEBUG - 2022-08-11 05:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:39:51 --> Total execution time: 0.0772
DEBUG - 2022-08-11 05:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:09:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:39:59 --> Total execution time: 0.2452
DEBUG - 2022-08-11 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:40:14 --> Total execution time: 0.0797
DEBUG - 2022-08-11 05:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:40:39 --> Total execution time: 0.0771
DEBUG - 2022-08-11 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:10:53 --> Total execution time: 0.0756
DEBUG - 2022-08-11 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:10:54 --> Total execution time: 0.0802
DEBUG - 2022-08-11 05:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:10:55 --> Total execution time: 0.0777
DEBUG - 2022-08-11 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:10:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:40:59 --> Total execution time: 0.0803
DEBUG - 2022-08-11 05:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:11:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:41:01 --> Total execution time: 0.0931
DEBUG - 2022-08-11 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:11:30 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:41:30 --> Total execution time: 0.0766
DEBUG - 2022-08-11 05:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:43:19 --> Total execution time: 0.0817
DEBUG - 2022-08-11 05:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:43:56 --> Total execution time: 0.0890
DEBUG - 2022-08-11 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:44:29 --> Total execution time: 0.1941
DEBUG - 2022-08-11 05:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:14:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:44:45 --> Total execution time: 0.1248
DEBUG - 2022-08-11 05:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:14:59 --> Total execution time: 0.2060
DEBUG - 2022-08-11 05:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:15:03 --> Total execution time: 0.2376
DEBUG - 2022-08-11 05:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:15:04 --> Total execution time: 0.0916
DEBUG - 2022-08-11 05:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:16:03 --> Total execution time: 0.0777
DEBUG - 2022-08-11 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:16:05 --> Total execution time: 0.0821
DEBUG - 2022-08-11 05:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:16:05 --> Total execution time: 0.1635
DEBUG - 2022-08-11 05:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:17:24 --> Total execution time: 0.0773
DEBUG - 2022-08-11 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:17:27 --> Total execution time: 0.0799
DEBUG - 2022-08-11 05:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:17:27 --> Total execution time: 0.1607
DEBUG - 2022-08-11 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:39 --> Total execution time: 0.0856
DEBUG - 2022-08-11 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:40 --> Total execution time: 0.0828
DEBUG - 2022-08-11 05:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:40 --> Total execution time: 0.2693
DEBUG - 2022-08-11 05:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:45 --> Total execution time: 0.0873
DEBUG - 2022-08-11 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:49 --> Total execution time: 0.0922
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.0800
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.1321
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.2154
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.0780
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.0812
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.1135
DEBUG - 2022-08-11 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:17:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:47:54 --> Total execution time: 0.0937
DEBUG - 2022-08-11 05:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:48:00 --> Total execution time: 0.0773
DEBUG - 2022-08-11 05:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:48:01 --> Total execution time: 0.0838
DEBUG - 2022-08-11 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:48:05 --> Total execution time: 0.0966
DEBUG - 2022-08-11 05:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:48:12 --> Total execution time: 0.0835
DEBUG - 2022-08-11 05:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:48:57 --> Total execution time: 0.0744
DEBUG - 2022-08-11 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:49:11 --> Total execution time: 0.0737
DEBUG - 2022-08-11 05:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:49:20 --> Total execution time: 0.0806
DEBUG - 2022-08-11 05:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 05:25:43 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-11 05:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:26:20 --> Total execution time: 0.0828
DEBUG - 2022-08-11 05:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 05:32:47 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 05:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:04:30 --> Total execution time: 0.1347
DEBUG - 2022-08-11 05:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:04:49 --> Total execution time: 0.0748
DEBUG - 2022-08-11 05:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:04:59 --> Total execution time: 0.0788
DEBUG - 2022-08-11 05:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:05:27 --> Total execution time: 0.0485
DEBUG - 2022-08-11 05:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:40:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:10:03 --> Total execution time: 0.1367
DEBUG - 2022-08-11 05:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:43:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:13:29 --> Total execution time: 0.2734
DEBUG - 2022-08-11 05:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:13:39 --> Total execution time: 0.0763
DEBUG - 2022-08-11 05:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:14:00 --> Total execution time: 0.0989
DEBUG - 2022-08-11 05:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:14:31 --> Total execution time: 0.1075
DEBUG - 2022-08-11 05:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:14:39 --> Total execution time: 0.0920
DEBUG - 2022-08-11 05:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:14:50 --> Total execution time: 0.1055
DEBUG - 2022-08-11 05:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:14:51 --> Total execution time: 0.0726
DEBUG - 2022-08-11 05:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:15:45 --> Total execution time: 0.1028
DEBUG - 2022-08-11 05:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:15:46 --> Total execution time: 0.0752
DEBUG - 2022-08-11 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:16:29 --> Total execution time: 0.0807
DEBUG - 2022-08-11 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:16:30 --> Total execution time: 0.0805
DEBUG - 2022-08-11 05:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:16:49 --> Total execution time: 0.0489
DEBUG - 2022-08-11 05:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:16:57 --> Total execution time: 0.1106
DEBUG - 2022-08-11 05:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:00 --> Total execution time: 0.0901
DEBUG - 2022-08-11 05:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:09 --> Total execution time: 0.0815
DEBUG - 2022-08-11 05:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:09 --> Total execution time: 0.1107
DEBUG - 2022-08-11 05:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:10 --> Total execution time: 0.2015
DEBUG - 2022-08-11 05:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:12 --> Total execution time: 0.0861
DEBUG - 2022-08-11 05:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:19 --> Total execution time: 0.0786
DEBUG - 2022-08-11 05:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:32 --> Total execution time: 0.1146
DEBUG - 2022-08-11 05:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:38 --> Total execution time: 0.0829
DEBUG - 2022-08-11 05:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:44 --> Total execution time: 0.0838
DEBUG - 2022-08-11 05:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:54 --> Total execution time: 0.0872
DEBUG - 2022-08-11 05:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:54 --> Total execution time: 0.0756
DEBUG - 2022-08-11 05:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:18:10 --> Total execution time: 0.0805
DEBUG - 2022-08-11 05:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:48:21 --> Total execution time: 0.0816
DEBUG - 2022-08-11 05:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:48:23 --> Total execution time: 0.0805
DEBUG - 2022-08-11 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:48:24 --> Total execution time: 0.0885
DEBUG - 2022-08-11 05:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:18:36 --> Total execution time: 0.0761
DEBUG - 2022-08-11 05:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:19:11 --> Total execution time: 0.0811
DEBUG - 2022-08-11 05:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:19:15 --> Total execution time: 0.0752
DEBUG - 2022-08-11 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:19:41 --> Total execution time: 0.0910
DEBUG - 2022-08-11 05:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:19:41 --> Total execution time: 0.0940
DEBUG - 2022-08-11 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:50:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:20:03 --> Total execution time: 0.0568
DEBUG - 2022-08-11 05:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:50:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:20:04 --> Total execution time: 0.0783
DEBUG - 2022-08-11 05:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:50:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:20:10 --> Total execution time: 0.0867
DEBUG - 2022-08-11 05:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:21:51 --> Total execution time: 0.0628
DEBUG - 2022-08-11 05:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:22:14 --> Total execution time: 0.2156
DEBUG - 2022-08-11 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:52:22 --> Total execution time: 0.0754
DEBUG - 2022-08-11 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:52:26 --> Total execution time: 0.0820
DEBUG - 2022-08-11 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:52:26 --> Total execution time: 0.0756
DEBUG - 2022-08-11 05:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:22:42 --> Total execution time: 0.0488
DEBUG - 2022-08-11 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:52:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:22:46 --> Total execution time: 0.0855
DEBUG - 2022-08-11 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:01 --> Total execution time: 0.0905
DEBUG - 2022-08-11 05:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:02 --> Total execution time: 0.0511
DEBUG - 2022-08-11 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:02 --> Total execution time: 0.0841
DEBUG - 2022-08-11 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:02 --> Total execution time: 0.0820
DEBUG - 2022-08-11 05:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:05 --> Total execution time: 0.1084
DEBUG - 2022-08-11 05:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:10 --> Total execution time: 0.1041
DEBUG - 2022-08-11 05:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:10 --> Total execution time: 0.1014
DEBUG - 2022-08-11 05:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:14 --> Total execution time: 0.0737
DEBUG - 2022-08-11 05:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:16 --> Total execution time: 0.0512
DEBUG - 2022-08-11 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:18 --> Total execution time: 0.0864
DEBUG - 2022-08-11 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:19 --> Total execution time: 0.1021
DEBUG - 2022-08-11 05:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:22 --> Total execution time: 0.0866
DEBUG - 2022-08-11 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:22 --> Total execution time: 0.0786
DEBUG - 2022-08-11 05:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:24 --> Total execution time: 0.0849
DEBUG - 2022-08-11 05:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:28 --> Total execution time: 0.0863
DEBUG - 2022-08-11 05:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:35 --> Total execution time: 0.0503
DEBUG - 2022-08-11 05:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:37 --> Total execution time: 0.0832
DEBUG - 2022-08-11 05:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:38 --> Total execution time: 0.1187
DEBUG - 2022-08-11 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:38 --> Total execution time: 0.0749
DEBUG - 2022-08-11 05:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:42 --> Total execution time: 0.0755
DEBUG - 2022-08-11 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:51 --> Total execution time: 0.1928
DEBUG - 2022-08-11 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:52 --> Total execution time: 0.0695
DEBUG - 2022-08-11 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:53 --> Total execution time: 0.0764
DEBUG - 2022-08-11 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:53:54 --> Total execution time: 0.0729
DEBUG - 2022-08-11 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:53:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 05:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:23:57 --> Total execution time: 0.0728
DEBUG - 2022-08-11 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:54:08 --> Total execution time: 0.0877
DEBUG - 2022-08-11 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:54:12 --> Total execution time: 0.0781
DEBUG - 2022-08-11 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:54:12 --> Total execution time: 0.0849
DEBUG - 2022-08-11 05:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:54:20 --> Total execution time: 0.0897
DEBUG - 2022-08-11 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:24:28 --> Total execution time: 2.0596
DEBUG - 2022-08-11 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 05:54:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:21 --> Total execution time: 0.0920
DEBUG - 2022-08-11 05:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:55:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-08-11 16:25:23 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-08-11 16:25:23 --> Total execution time: 0.1347
DEBUG - 2022-08-11 05:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:43 --> Total execution time: 0.0834
DEBUG - 2022-08-11 05:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:26:52 --> Total execution time: 0.0890
DEBUG - 2022-08-11 05:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:27:04 --> Total execution time: 0.1062
DEBUG - 2022-08-11 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:09 --> Total execution time: 0.2423
DEBUG - 2022-08-11 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:13 --> Total execution time: 0.0777
DEBUG - 2022-08-11 05:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:18 --> Total execution time: 0.1296
DEBUG - 2022-08-11 05:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:26 --> Total execution time: 0.0812
DEBUG - 2022-08-11 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:29 --> Total execution time: 0.0847
DEBUG - 2022-08-11 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:33 --> Total execution time: 0.0907
DEBUG - 2022-08-11 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:35 --> Total execution time: 0.0971
DEBUG - 2022-08-11 05:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:35 --> Total execution time: 0.0842
DEBUG - 2022-08-11 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 05:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:38 --> Total execution time: 0.1041
DEBUG - 2022-08-11 05:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:28:51 --> Total execution time: 0.1206
DEBUG - 2022-08-11 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 05:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 05:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:29:27 --> Total execution time: 0.0845
DEBUG - 2022-08-11 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:03 --> Total execution time: 0.0618
DEBUG - 2022-08-11 06:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:19 --> Total execution time: 0.1026
DEBUG - 2022-08-11 06:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:26 --> Total execution time: 0.1655
DEBUG - 2022-08-11 06:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:54 --> Total execution time: 0.0883
DEBUG - 2022-08-11 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:00:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:59 --> Total execution time: 0.2032
DEBUG - 2022-08-11 06:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:21 --> Total execution time: 0.1187
DEBUG - 2022-08-11 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:22 --> Total execution time: 0.1845
DEBUG - 2022-08-11 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:25 --> Total execution time: 0.1279
DEBUG - 2022-08-11 06:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:30 --> Total execution time: 0.0854
DEBUG - 2022-08-11 06:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:34 --> Total execution time: 0.1261
DEBUG - 2022-08-11 06:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:35 --> Total execution time: 0.1010
DEBUG - 2022-08-11 06:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:45 --> Total execution time: 0.0832
DEBUG - 2022-08-11 06:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:50 --> Total execution time: 1.7538
DEBUG - 2022-08-11 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:53 --> Total execution time: 0.0818
DEBUG - 2022-08-11 06:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 06:01:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 06:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:31:59 --> Total execution time: 0.1130
DEBUG - 2022-08-11 06:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:00 --> Total execution time: 0.1026
DEBUG - 2022-08-11 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:02 --> Total execution time: 0.2061
DEBUG - 2022-08-11 06:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:17 --> Total execution time: 0.1714
DEBUG - 2022-08-11 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:33 --> Total execution time: 0.0772
DEBUG - 2022-08-11 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:40 --> Total execution time: 0.0754
DEBUG - 2022-08-11 06:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:41 --> Total execution time: 0.0786
DEBUG - 2022-08-11 06:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:02:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:32:54 --> Total execution time: 0.0632
DEBUG - 2022-08-11 06:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:10 --> Total execution time: 0.0796
DEBUG - 2022-08-11 06:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:13 --> Total execution time: 0.2669
DEBUG - 2022-08-11 06:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:17 --> Total execution time: 0.0859
DEBUG - 2022-08-11 06:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:28 --> Total execution time: 0.0895
DEBUG - 2022-08-11 06:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:34:07 --> Total execution time: 0.1080
DEBUG - 2022-08-11 06:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:04:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:34:17 --> Total execution time: 0.0561
DEBUG - 2022-08-11 06:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:34:20 --> Total execution time: 0.0847
DEBUG - 2022-08-11 06:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:35:16 --> Total execution time: 0.2150
DEBUG - 2022-08-11 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:35:18 --> Total execution time: 0.2160
DEBUG - 2022-08-11 06:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:11 --> Total execution time: 0.0956
DEBUG - 2022-08-11 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:19 --> Total execution time: 0.0706
DEBUG - 2022-08-11 06:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:20 --> Total execution time: 0.0864
DEBUG - 2022-08-11 06:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:26 --> Total execution time: 0.0519
DEBUG - 2022-08-11 06:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:38 --> Total execution time: 0.0752
DEBUG - 2022-08-11 06:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:40 --> Total execution time: 0.4030
DEBUG - 2022-08-11 06:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:50 --> Total execution time: 0.0812
DEBUG - 2022-08-11 06:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:37:59 --> Total execution time: 0.0783
DEBUG - 2022-08-11 06:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:38:06 --> Total execution time: 0.1098
DEBUG - 2022-08-11 06:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:10:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:40:04 --> Total execution time: 0.0882
DEBUG - 2022-08-11 06:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:10:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:40:34 --> Total execution time: 0.0500
DEBUG - 2022-08-11 06:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:41:01 --> Total execution time: 0.1919
DEBUG - 2022-08-11 06:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:41:04 --> Total execution time: 0.0807
DEBUG - 2022-08-11 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:41:26 --> Total execution time: 0.0699
DEBUG - 2022-08-11 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:41:51 --> Total execution time: 0.0843
DEBUG - 2022-08-11 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:41:55 --> Total execution time: 0.1280
DEBUG - 2022-08-11 06:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:42:06 --> Total execution time: 0.0889
DEBUG - 2022-08-11 06:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:17 --> Total execution time: 0.1367
DEBUG - 2022-08-11 06:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:22 --> Total execution time: 0.0609
DEBUG - 2022-08-11 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:32 --> Total execution time: 0.0854
DEBUG - 2022-08-11 06:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:40 --> Total execution time: 0.0894
DEBUG - 2022-08-11 06:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:44 --> Total execution time: 0.1186
DEBUG - 2022-08-11 06:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:51 --> Total execution time: 0.1085
DEBUG - 2022-08-11 06:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:48:58 --> Total execution time: 0.1153
DEBUG - 2022-08-11 06:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:49:06 --> Total execution time: 0.0932
DEBUG - 2022-08-11 06:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:49:17 --> Total execution time: 0.1494
DEBUG - 2022-08-11 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:49:31 --> Total execution time: 0.0962
DEBUG - 2022-08-11 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:23 --> Total execution time: 0.0781
DEBUG - 2022-08-11 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:28 --> Total execution time: 0.0728
DEBUG - 2022-08-11 06:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:36 --> Total execution time: 0.1106
DEBUG - 2022-08-11 06:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:39 --> Total execution time: 0.0813
DEBUG - 2022-08-11 06:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:43 --> Total execution time: 0.0864
DEBUG - 2022-08-11 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:48 --> Total execution time: 0.0500
DEBUG - 2022-08-11 06:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:48 --> Total execution time: 0.1991
DEBUG - 2022-08-11 06:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:54 --> Total execution time: 0.0892
DEBUG - 2022-08-11 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:01 --> Total execution time: 0.0754
DEBUG - 2022-08-11 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:07 --> Total execution time: 0.0760
DEBUG - 2022-08-11 06:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:11 --> Total execution time: 0.0846
DEBUG - 2022-08-11 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:13 --> Total execution time: 0.0749
DEBUG - 2022-08-11 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:16 --> Total execution time: 0.0795
DEBUG - 2022-08-11 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:17 --> Total execution time: 0.0857
DEBUG - 2022-08-11 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:26 --> Total execution time: 0.0905
DEBUG - 2022-08-11 06:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 06:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:30 --> Total execution time: 0.0827
DEBUG - 2022-08-11 06:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:30 --> Total execution time: 0.0850
DEBUG - 2022-08-11 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:42 --> Total execution time: 0.0697
DEBUG - 2022-08-11 06:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:46 --> Total execution time: 0.0751
DEBUG - 2022-08-11 06:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:52 --> Total execution time: 0.0771
DEBUG - 2022-08-11 06:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:53:11 --> Total execution time: 0.0873
DEBUG - 2022-08-11 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:53:13 --> Total execution time: 0.0860
DEBUG - 2022-08-11 06:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:53:15 --> Total execution time: 0.0867
DEBUG - 2022-08-11 06:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:23:38 --> Total execution time: 0.0897
DEBUG - 2022-08-11 06:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:23:45 --> Total execution time: 0.1228
DEBUG - 2022-08-11 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:53:46 --> Total execution time: 0.0827
DEBUG - 2022-08-11 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:53:50 --> Total execution time: 0.0812
DEBUG - 2022-08-11 06:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:54:04 --> Total execution time: 0.0865
DEBUG - 2022-08-11 06:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:54:21 --> Total execution time: 0.0818
DEBUG - 2022-08-11 06:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:54:29 --> Total execution time: 0.0971
DEBUG - 2022-08-11 06:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:54:41 --> Total execution time: 0.0851
DEBUG - 2022-08-11 06:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:54:54 --> Total execution time: 0.1107
DEBUG - 2022-08-11 06:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:05 --> Total execution time: 0.1062
DEBUG - 2022-08-11 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:18 --> Total execution time: 0.1039
DEBUG - 2022-08-11 06:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:35 --> Total execution time: 0.0836
DEBUG - 2022-08-11 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:44 --> Total execution time: 0.0571
DEBUG - 2022-08-11 06:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:45 --> Total execution time: 0.0906
DEBUG - 2022-08-11 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:48 --> Total execution time: 0.0751
DEBUG - 2022-08-11 06:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:49 --> Total execution time: 0.0817
DEBUG - 2022-08-11 06:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:55 --> Total execution time: 0.0791
DEBUG - 2022-08-11 06:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:57 --> Total execution time: 0.0843
DEBUG - 2022-08-11 06:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:01 --> Total execution time: 0.0839
DEBUG - 2022-08-11 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:07 --> Total execution time: 0.1302
DEBUG - 2022-08-11 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:07 --> Total execution time: 0.0993
DEBUG - 2022-08-11 06:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:08 --> Total execution time: 0.0787
DEBUG - 2022-08-11 06:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:13 --> Total execution time: 0.1017
DEBUG - 2022-08-11 06:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:17 --> Total execution time: 0.0881
DEBUG - 2022-08-11 06:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:20 --> Total execution time: 0.1306
DEBUG - 2022-08-11 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:05 --> Total execution time: 0.1007
DEBUG - 2022-08-11 06:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:16 --> Total execution time: 0.0823
DEBUG - 2022-08-11 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:21 --> Total execution time: 0.0963
DEBUG - 2022-08-11 06:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:22 --> Total execution time: 0.0802
DEBUG - 2022-08-11 06:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:35 --> Total execution time: 0.2009
DEBUG - 2022-08-11 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:41 --> Total execution time: 0.0961
DEBUG - 2022-08-11 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:49 --> Total execution time: 0.0784
DEBUG - 2022-08-11 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:58:23 --> Total execution time: 0.0897
DEBUG - 2022-08-11 06:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:59:44 --> Total execution time: 0.0661
DEBUG - 2022-08-11 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:01:38 --> Total execution time: 0.0754
DEBUG - 2022-08-11 06:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:02:25 --> Total execution time: 0.2346
DEBUG - 2022-08-11 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 06:32:46 --> 404 Page Not Found: Wp-comentsphp/index
DEBUG - 2022-08-11 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:04:11 --> Total execution time: 0.2517
DEBUG - 2022-08-11 06:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:07:10 --> Total execution time: 0.0654
DEBUG - 2022-08-11 06:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:08:44 --> Total execution time: 0.0755
DEBUG - 2022-08-11 06:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:08:52 --> Total execution time: 0.0827
DEBUG - 2022-08-11 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:08:59 --> Total execution time: 0.0984
DEBUG - 2022-08-11 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:09:06 --> Total execution time: 0.1151
DEBUG - 2022-08-11 06:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:09:14 --> Total execution time: 0.0834
DEBUG - 2022-08-11 06:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:10:06 --> Total execution time: 0.1011
DEBUG - 2022-08-11 06:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:44:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:14:02 --> Total execution time: 0.2182
DEBUG - 2022-08-11 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:45:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:15:59 --> Total execution time: 0.0598
DEBUG - 2022-08-11 06:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:05 --> Total execution time: 0.0743
DEBUG - 2022-08-11 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:14 --> Total execution time: 0.0826
DEBUG - 2022-08-11 06:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:23 --> Total execution time: 0.1050
DEBUG - 2022-08-11 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:25 --> Total execution time: 0.1062
DEBUG - 2022-08-11 06:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:33 --> Total execution time: 0.1233
DEBUG - 2022-08-11 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:54 --> Total execution time: 0.1085
DEBUG - 2022-08-11 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:16:56 --> Total execution time: 0.1032
DEBUG - 2022-08-11 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:06 --> Total execution time: 0.2436
DEBUG - 2022-08-11 06:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:17 --> Total execution time: 0.1115
DEBUG - 2022-08-11 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:21 --> Total execution time: 0.0853
DEBUG - 2022-08-11 06:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:28 --> Total execution time: 0.1057
DEBUG - 2022-08-11 06:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:39 --> Total execution time: 0.0824
DEBUG - 2022-08-11 06:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:20:54 --> Total execution time: 0.4449
DEBUG - 2022-08-11 06:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:51:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:21:37 --> Total execution time: 2.3599
DEBUG - 2022-08-11 06:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:52:54 --> Total execution time: 0.3753
DEBUG - 2022-08-11 06:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:53:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 06:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:23:32 --> Total execution time: 0.3110
DEBUG - 2022-08-11 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:53:58 --> Total execution time: 0.1371
DEBUG - 2022-08-11 06:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 06:53:58 --> Total execution time: 0.2066
DEBUG - 2022-08-11 06:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 06:55:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 06:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 06:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 06:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:26:13 --> Total execution time: 0.2304
DEBUG - 2022-08-11 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:30:03 --> Total execution time: 0.2621
DEBUG - 2022-08-11 07:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:00:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:00:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 07:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:00:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:30:30 --> Total execution time: 0.0878
DEBUG - 2022-08-11 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:00:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:30:52 --> Total execution time: 0.0607
DEBUG - 2022-08-11 07:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:31:07 --> Total execution time: 0.0543
DEBUG - 2022-08-11 07:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:31:45 --> Total execution time: 0.0781
DEBUG - 2022-08-11 07:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:31:56 --> Total execution time: 0.0845
DEBUG - 2022-08-11 07:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:32:03 --> Total execution time: 0.0846
DEBUG - 2022-08-11 07:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:32:20 --> Total execution time: 0.0843
DEBUG - 2022-08-11 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:32:29 --> Total execution time: 0.0805
DEBUG - 2022-08-11 07:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:33:02 --> Total execution time: 0.0849
DEBUG - 2022-08-11 07:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:34:36 --> Total execution time: 0.0875
DEBUG - 2022-08-11 07:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:34:41 --> Total execution time: 0.0826
DEBUG - 2022-08-11 07:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:34:49 --> Total execution time: 0.1080
DEBUG - 2022-08-11 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:04:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:34:53 --> Total execution time: 0.1144
DEBUG - 2022-08-11 07:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:34:53 --> Total execution time: 0.0556
DEBUG - 2022-08-11 07:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:35:13 --> Total execution time: 0.0987
DEBUG - 2022-08-11 07:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:35:23 --> Total execution time: 0.0889
DEBUG - 2022-08-11 07:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:35:34 --> Total execution time: 0.0794
DEBUG - 2022-08-11 07:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:35:38 --> Total execution time: 0.1083
DEBUG - 2022-08-11 07:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:07:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:37:51 --> Total execution time: 0.2961
DEBUG - 2022-08-11 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:37:57 --> Total execution time: 0.0820
DEBUG - 2022-08-11 07:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:05 --> Total execution time: 0.2005
DEBUG - 2022-08-11 07:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:06 --> Total execution time: 0.1161
DEBUG - 2022-08-11 07:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:08 --> Total execution time: 0.0896
DEBUG - 2022-08-11 07:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:09 --> Total execution time: 0.0791
DEBUG - 2022-08-11 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:11 --> Total execution time: 0.0834
DEBUG - 2022-08-11 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:15 --> Total execution time: 0.0693
DEBUG - 2022-08-11 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:17 --> Total execution time: 0.1010
DEBUG - 2022-08-11 07:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:39 --> Total execution time: 0.0746
DEBUG - 2022-08-11 07:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:41 --> Total execution time: 0.0792
DEBUG - 2022-08-11 07:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:41 --> Total execution time: 0.1272
DEBUG - 2022-08-11 07:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:45 --> Total execution time: 0.0824
DEBUG - 2022-08-11 07:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:51 --> Total execution time: 0.0772
DEBUG - 2022-08-11 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:53 --> Total execution time: 0.0815
DEBUG - 2022-08-11 07:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:08:53 --> Total execution time: 0.0893
DEBUG - 2022-08-11 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:54 --> Total execution time: 0.0791
DEBUG - 2022-08-11 07:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:55 --> Total execution time: 0.0756
DEBUG - 2022-08-11 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:08:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:38:56 --> Total execution time: 0.0768
DEBUG - 2022-08-11 07:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:39:00 --> Total execution time: 0.0776
DEBUG - 2022-08-11 07:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:09:26 --> Total execution time: 0.0868
DEBUG - 2022-08-11 07:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:09:27 --> Total execution time: 0.0911
DEBUG - 2022-08-11 07:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:09:27 --> Total execution time: 0.1401
DEBUG - 2022-08-11 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:39:31 --> Total execution time: 0.0759
DEBUG - 2022-08-11 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:39:57 --> Total execution time: 0.0888
DEBUG - 2022-08-11 07:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:40:04 --> Total execution time: 0.0846
DEBUG - 2022-08-11 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:40:12 --> Total execution time: 0.0890
DEBUG - 2022-08-11 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:40:14 --> Total execution time: 0.0759
DEBUG - 2022-08-11 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:41:55 --> Total execution time: 0.0851
DEBUG - 2022-08-11 07:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:41:57 --> Total execution time: 0.0783
DEBUG - 2022-08-11 07:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:42:10 --> Total execution time: 0.0834
DEBUG - 2022-08-11 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:42:21 --> Total execution time: 0.0966
DEBUG - 2022-08-11 07:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:42:38 --> Total execution time: 0.0828
DEBUG - 2022-08-11 07:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:42:58 --> Total execution time: 0.0867
DEBUG - 2022-08-11 07:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:00 --> Total execution time: 0.0806
DEBUG - 2022-08-11 07:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:05 --> Total execution time: 0.1326
DEBUG - 2022-08-11 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:07 --> Total execution time: 0.0809
DEBUG - 2022-08-11 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:14 --> Total execution time: 0.0824
DEBUG - 2022-08-11 07:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:18 --> Total execution time: 0.1944
DEBUG - 2022-08-11 07:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:25 --> Total execution time: 0.0825
DEBUG - 2022-08-11 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:32 --> Total execution time: 0.0943
DEBUG - 2022-08-11 07:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:34 --> Total execution time: 0.0822
DEBUG - 2022-08-11 07:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:43:45 --> Total execution time: 0.0814
DEBUG - 2022-08-11 07:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:02 --> Total execution time: 0.1090
DEBUG - 2022-08-11 07:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:10 --> Total execution time: 0.1051
DEBUG - 2022-08-11 07:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:14 --> Total execution time: 0.0497
DEBUG - 2022-08-11 07:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:23 --> Total execution time: 0.0811
DEBUG - 2022-08-11 07:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:31 --> Total execution time: 0.1476
DEBUG - 2022-08-11 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:47 --> Total execution time: 0.0787
DEBUG - 2022-08-11 07:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:45:55 --> Total execution time: 0.0904
DEBUG - 2022-08-11 07:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:46:06 --> Total execution time: 0.0804
DEBUG - 2022-08-11 07:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:46:10 --> Total execution time: 0.1417
DEBUG - 2022-08-11 07:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:16:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:46:17 --> Total execution time: 0.0791
DEBUG - 2022-08-11 07:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:46:41 --> Total execution time: 1.9825
DEBUG - 2022-08-11 07:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:16:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:19:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:49:47 --> Total execution time: 0.0604
DEBUG - 2022-08-11 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:19:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:49:50 --> Total execution time: 0.0771
DEBUG - 2022-08-11 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:19:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:49:50 --> Total execution time: 0.0521
DEBUG - 2022-08-11 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:19:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:49:54 --> Total execution time: 0.0850
DEBUG - 2022-08-11 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:20:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:50:39 --> Total execution time: 0.1048
DEBUG - 2022-08-11 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:07 --> Total execution time: 0.2741
DEBUG - 2022-08-11 07:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:17 --> Total execution time: 0.0846
DEBUG - 2022-08-11 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:27 --> Total execution time: 0.0719
DEBUG - 2022-08-11 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:32 --> Total execution time: 0.0795
DEBUG - 2022-08-11 07:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:49 --> Total execution time: 0.0836
DEBUG - 2022-08-11 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:01:59 --> Total execution time: 0.1010
DEBUG - 2022-08-11 07:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:07 --> Total execution time: 0.0838
DEBUG - 2022-08-11 07:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:21 --> Total execution time: 0.1588
DEBUG - 2022-08-11 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:23 --> Total execution time: 0.1039
DEBUG - 2022-08-11 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:26 --> Total execution time: 0.1225
DEBUG - 2022-08-11 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:34 --> Total execution time: 0.0891
DEBUG - 2022-08-11 07:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:57 --> Total execution time: 0.0870
DEBUG - 2022-08-11 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:05 --> Total execution time: 0.0863
DEBUG - 2022-08-11 07:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:05 --> Total execution time: 0.0938
DEBUG - 2022-08-11 07:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:14 --> Total execution time: 0.0934
DEBUG - 2022-08-11 07:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:19 --> Total execution time: 0.0934
DEBUG - 2022-08-11 07:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:30 --> Total execution time: 0.0893
DEBUG - 2022-08-11 07:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:36 --> Total execution time: 0.0820
DEBUG - 2022-08-11 07:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:46 --> Total execution time: 0.0819
DEBUG - 2022-08-11 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:03:54 --> Total execution time: 0.1102
DEBUG - 2022-08-11 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:34:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:04:28 --> Total execution time: 0.0781
DEBUG - 2022-08-11 07:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:05:05 --> Total execution time: 0.2016
DEBUG - 2022-08-11 07:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:05:13 --> Total execution time: 0.0821
DEBUG - 2022-08-11 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:05:20 --> Total execution time: 0.1448
DEBUG - 2022-08-11 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:05:28 --> Total execution time: 0.1007
DEBUG - 2022-08-11 07:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:05:50 --> Total execution time: 0.0759
DEBUG - 2022-08-11 07:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:36:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:06:20 --> Total execution time: 0.0568
DEBUG - 2022-08-11 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:06:27 --> Total execution time: 0.0920
DEBUG - 2022-08-11 07:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:06:35 --> Total execution time: 0.0917
DEBUG - 2022-08-11 07:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:06:39 --> Total execution time: 0.0986
DEBUG - 2022-08-11 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:06:52 --> Total execution time: 0.0858
DEBUG - 2022-08-11 07:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:37:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:07:27 --> Total execution time: 0.0898
DEBUG - 2022-08-11 07:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:37:51 --> Total execution time: 0.0514
DEBUG - 2022-08-11 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:37:54 --> Total execution time: 0.0857
DEBUG - 2022-08-11 07:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:37:54 --> Total execution time: 0.0923
DEBUG - 2022-08-11 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:00 --> Total execution time: 0.0766
DEBUG - 2022-08-11 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:02 --> Total execution time: 0.0803
DEBUG - 2022-08-11 07:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:02 --> Total execution time: 0.1156
DEBUG - 2022-08-11 07:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:09:12 --> Total execution time: 0.0513
DEBUG - 2022-08-11 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:25 --> Total execution time: 0.0849
DEBUG - 2022-08-11 07:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:27 --> Total execution time: 0.0876
DEBUG - 2022-08-11 07:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:28 --> Total execution time: 0.0874
DEBUG - 2022-08-11 07:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:09:49 --> Total execution time: 0.0757
DEBUG - 2022-08-11 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:06 --> Total execution time: 0.0794
DEBUG - 2022-08-11 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:07 --> Total execution time: 0.1131
DEBUG - 2022-08-11 07:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:15 --> Total execution time: 0.0802
DEBUG - 2022-08-11 07:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:21 --> Total execution time: 0.0828
DEBUG - 2022-08-11 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:25 --> Total execution time: 0.0807
DEBUG - 2022-08-11 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:27 --> Total execution time: 0.0802
DEBUG - 2022-08-11 07:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:27 --> Total execution time: 0.0761
DEBUG - 2022-08-11 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:28 --> Total execution time: 0.0600
DEBUG - 2022-08-11 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:29 --> Total execution time: 0.0767
DEBUG - 2022-08-11 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:29 --> Total execution time: 0.0771
DEBUG - 2022-08-11 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:31 --> Total execution time: 0.0903
DEBUG - 2022-08-11 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:32 --> Total execution time: 0.0842
DEBUG - 2022-08-11 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:40:32 --> Total execution time: 0.0761
DEBUG - 2022-08-11 07:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:10:40 --> Total execution time: 0.0868
DEBUG - 2022-08-11 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:41:01 --> Total execution time: 0.0979
DEBUG - 2022-08-11 18:11:01 --> Total execution time: 0.0959
DEBUG - 2022-08-11 07:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:41:28 --> Total execution time: 0.0804
DEBUG - 2022-08-11 07:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:41:28 --> Total execution time: 0.0888
DEBUG - 2022-08-11 07:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:41:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:11:49 --> Total execution time: 0.1985
DEBUG - 2022-08-11 07:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:42:25 --> Total execution time: 0.1314
DEBUG - 2022-08-11 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:42:27 --> Total execution time: 0.0749
DEBUG - 2022-08-11 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:42:28 --> Total execution time: 0.0691
DEBUG - 2022-08-11 07:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:12:33 --> Total execution time: 0.0727
DEBUG - 2022-08-11 07:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:42:39 --> Total execution time: 0.0722
DEBUG - 2022-08-11 07:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:12:40 --> Total execution time: 0.1899
DEBUG - 2022-08-11 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:12:46 --> Total execution time: 0.0968
DEBUG - 2022-08-11 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:12:58 --> Total execution time: 0.0849
DEBUG - 2022-08-11 07:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:13:02 --> Total execution time: 0.0781
DEBUG - 2022-08-11 07:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:13:39 --> Total execution time: 0.0780
DEBUG - 2022-08-11 07:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:13:50 --> Total execution time: 0.0811
DEBUG - 2022-08-11 07:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:13:52 --> Total execution time: 0.1126
DEBUG - 2022-08-11 07:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:14:19 --> Total execution time: 0.0794
DEBUG - 2022-08-11 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:14:25 --> Total execution time: 0.0768
DEBUG - 2022-08-11 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:44:32 --> Total execution time: 0.0753
DEBUG - 2022-08-11 07:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:44:35 --> Total execution time: 0.0852
DEBUG - 2022-08-11 07:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:14:35 --> Total execution time: 0.0514
DEBUG - 2022-08-11 07:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:44:35 --> Total execution time: 0.0741
DEBUG - 2022-08-11 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:44:39 --> Total execution time: 0.0515
DEBUG - 2022-08-11 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:44:41 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-08-11 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:44:42 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-08-11 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:44:42 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-08-11 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 07:44:43 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-08-11 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:45:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:15:35 --> Total execution time: 0.0529
DEBUG - 2022-08-11 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:45:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:15:48 --> Total execution time: 0.0570
DEBUG - 2022-08-11 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:19:29 --> Total execution time: 0.2931
DEBUG - 2022-08-11 07:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:19:36 --> Total execution time: 0.0753
DEBUG - 2022-08-11 07:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:23:29 --> Total execution time: 0.3038
DEBUG - 2022-08-11 07:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:23:33 --> Total execution time: 0.0863
DEBUG - 2022-08-11 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:23:39 --> Total execution time: 0.1103
DEBUG - 2022-08-11 07:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:23:44 --> Total execution time: 0.0879
DEBUG - 2022-08-11 07:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:23:55 --> Total execution time: 0.0825
DEBUG - 2022-08-11 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:24:40 --> Total execution time: 0.0800
DEBUG - 2022-08-11 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:03 --> Total execution time: 0.2134
DEBUG - 2022-08-11 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:38 --> Total execution time: 0.2053
DEBUG - 2022-08-11 07:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:50 --> Total execution time: 0.0954
DEBUG - 2022-08-11 07:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:51 --> Total execution time: 0.0760
DEBUG - 2022-08-11 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 07:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:53 --> Total execution time: 0.0733
DEBUG - 2022-08-11 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:26:58 --> Total execution time: 0.0764
DEBUG - 2022-08-11 07:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:04 --> Total execution time: 0.0921
DEBUG - 2022-08-11 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:05 --> Total execution time: 0.0796
DEBUG - 2022-08-11 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:06 --> Total execution time: 0.0760
DEBUG - 2022-08-11 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:09 --> Total execution time: 0.0969
DEBUG - 2022-08-11 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:12 --> Total execution time: 0.0921
DEBUG - 2022-08-11 07:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:27:20 --> Total execution time: 0.0750
DEBUG - 2022-08-11 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 07:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:28:27 --> Total execution time: 0.0865
DEBUG - 2022-08-11 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:03 --> Total execution time: 0.0701
DEBUG - 2022-08-11 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:25 --> Total execution time: 0.0854
DEBUG - 2022-08-11 08:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:25 --> Total execution time: 0.0963
DEBUG - 2022-08-11 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:31 --> Total execution time: 0.1034
DEBUG - 2022-08-11 08:00:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:32 --> Total execution time: 0.0922
DEBUG - 2022-08-11 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:35 --> Total execution time: 0.0857
DEBUG - 2022-08-11 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:30:41 --> Total execution time: 0.0765
DEBUG - 2022-08-11 08:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:31:03 --> Total execution time: 0.0755
DEBUG - 2022-08-11 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:01:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:31:31 --> Total execution time: 0.0538
DEBUG - 2022-08-11 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:31:45 --> Total execution time: 0.1954
DEBUG - 2022-08-11 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:31:56 --> Total execution time: 0.0482
DEBUG - 2022-08-11 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:00 --> Total execution time: 0.0823
DEBUG - 2022-08-11 08:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:03 --> Total execution time: 0.1010
DEBUG - 2022-08-11 08:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:11 --> Total execution time: 0.0560
DEBUG - 2022-08-11 08:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:13 --> Total execution time: 0.1189
DEBUG - 2022-08-11 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:25 --> Total execution time: 0.0931
DEBUG - 2022-08-11 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:25 --> Total execution time: 0.0746
DEBUG - 2022-08-11 08:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:26 --> Total execution time: 0.0815
DEBUG - 2022-08-11 08:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:30 --> Total execution time: 0.1049
DEBUG - 2022-08-11 08:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:31 --> Total execution time: 0.1119
DEBUG - 2022-08-11 08:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:32:31 --> Total execution time: 0.1151
DEBUG - 2022-08-11 08:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:33:26 --> Total execution time: 0.1731
DEBUG - 2022-08-11 08:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:33:38 --> Total execution time: 0.0691
DEBUG - 2022-08-11 08:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:34:04 --> Total execution time: 0.0793
DEBUG - 2022-08-11 08:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:09 --> Total execution time: 0.0838
DEBUG - 2022-08-11 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:12 --> Total execution time: 0.0912
DEBUG - 2022-08-11 08:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:12 --> Total execution time: 0.1730
DEBUG - 2022-08-11 08:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:34:16 --> Total execution time: 0.0869
DEBUG - 2022-08-11 08:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:34:21 --> Total execution time: 0.0840
DEBUG - 2022-08-11 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:04:31 --> Total execution time: 0.0829
DEBUG - 2022-08-11 08:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:35:12 --> Total execution time: 0.0781
DEBUG - 2022-08-11 08:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:05:20 --> Total execution time: 0.0751
DEBUG - 2022-08-11 08:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:35:35 --> Total execution time: 0.0767
DEBUG - 2022-08-11 08:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:05:39 --> Total execution time: 0.0788
DEBUG - 2022-08-11 08:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:36:08 --> Total execution time: 0.0823
DEBUG - 2022-08-11 08:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:36:10 --> Total execution time: 0.0807
DEBUG - 2022-08-11 08:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:36:35 --> Total execution time: 0.1177
DEBUG - 2022-08-11 08:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:01 --> Total execution time: 0.0516
DEBUG - 2022-08-11 08:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:09 --> Total execution time: 0.0753
DEBUG - 2022-08-11 08:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:11 --> Total execution time: 0.0819
DEBUG - 2022-08-11 08:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:34 --> Total execution time: 0.0544
DEBUG - 2022-08-11 08:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:43 --> Total execution time: 2.2438
DEBUG - 2022-08-11 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:44 --> Total execution time: 0.0905
DEBUG - 2022-08-11 08:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:49 --> Total execution time: 0.0521
DEBUG - 2022-08-11 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:58 --> Total execution time: 0.1012
DEBUG - 2022-08-11 08:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:37:59 --> Total execution time: 0.1220
DEBUG - 2022-08-11 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:10 --> Total execution time: 0.0667
DEBUG - 2022-08-11 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:10 --> Total execution time: 0.0474
DEBUG - 2022-08-11 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:10 --> Total execution time: 0.0770
DEBUG - 2022-08-11 08:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:11 --> Total execution time: 0.0481
DEBUG - 2022-08-11 08:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:11 --> Total execution time: 0.0657
DEBUG - 2022-08-11 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:32 --> Total execution time: 0.0808
DEBUG - 2022-08-11 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:38 --> Total execution time: 0.0684
DEBUG - 2022-08-11 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:39 --> Total execution time: 0.0790
DEBUG - 2022-08-11 08:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:44 --> Total execution time: 0.1646
DEBUG - 2022-08-11 08:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:44 --> Total execution time: 0.0821
DEBUG - 2022-08-11 08:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:46 --> Total execution time: 0.0650
DEBUG - 2022-08-11 08:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:49 --> Total execution time: 0.0872
DEBUG - 2022-08-11 08:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:51 --> Total execution time: 0.0560
DEBUG - 2022-08-11 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:53 --> Total execution time: 0.0793
DEBUG - 2022-08-11 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:53 --> Total execution time: 0.0543
DEBUG - 2022-08-11 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:54 --> Total execution time: 0.0563
DEBUG - 2022-08-11 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:54 --> Total execution time: 0.0477
DEBUG - 2022-08-11 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:54 --> Total execution time: 0.0774
DEBUG - 2022-08-11 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:54 --> Total execution time: 0.0492
DEBUG - 2022-08-11 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:55 --> Total execution time: 0.0482
DEBUG - 2022-08-11 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:55 --> Total execution time: 0.0827
DEBUG - 2022-08-11 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:56 --> Total execution time: 0.1956
DEBUG - 2022-08-11 08:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:08:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:38:58 --> Total execution time: 0.0503
DEBUG - 2022-08-11 08:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:02 --> Total execution time: 0.0479
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:07 --> Total execution time: 0.0848
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:07 --> Total execution time: 0.0848
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:07 --> Total execution time: 0.0806
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:07 --> Total execution time: 0.0985
DEBUG - 2022-08-11 08:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:07 --> Total execution time: 0.1366
DEBUG - 2022-08-11 08:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:08 --> Total execution time: 0.0894
DEBUG - 2022-08-11 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:08 --> Total execution time: 0.1057
DEBUG - 2022-08-11 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:08 --> Total execution time: 0.1080
DEBUG - 2022-08-11 08:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:18 --> Total execution time: 0.0827
DEBUG - 2022-08-11 08:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:22 --> Total execution time: 0.0497
DEBUG - 2022-08-11 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:27 --> Total execution time: 0.0605
DEBUG - 2022-08-11 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:27 --> Total execution time: 0.0563
DEBUG - 2022-08-11 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:27 --> Total execution time: 0.0481
DEBUG - 2022-08-11 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:28 --> Total execution time: 0.0478
DEBUG - 2022-08-11 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:28 --> Total execution time: 0.0569
DEBUG - 2022-08-11 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:30 --> Total execution time: 0.0548
DEBUG - 2022-08-11 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:38 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:38 --> Total execution time: 0.0813
DEBUG - 2022-08-11 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:42 --> Total execution time: 0.0899
DEBUG - 2022-08-11 08:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:09:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:39:52 --> Total execution time: 0.0892
DEBUG - 2022-08-11 08:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:40:15 --> Total execution time: 0.1044
DEBUG - 2022-08-11 08:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:40:40 --> Total execution time: 0.0807
DEBUG - 2022-08-11 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:40:50 --> Total execution time: 0.1009
DEBUG - 2022-08-11 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:11:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:41:11 --> Total execution time: 0.0518
DEBUG - 2022-08-11 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:41:15 --> Total execution time: 0.0820
DEBUG - 2022-08-11 08:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:41:22 --> Total execution time: 0.1287
DEBUG - 2022-08-11 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:41:56 --> Total execution time: 0.0911
DEBUG - 2022-08-11 08:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:41:59 --> Total execution time: 0.1453
DEBUG - 2022-08-11 08:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:42:50 --> Total execution time: 0.0688
DEBUG - 2022-08-11 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:43:00 --> Total execution time: 0.1174
DEBUG - 2022-08-11 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:43:00 --> Total execution time: 0.0705
DEBUG - 2022-08-11 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:43:16 --> Total execution time: 0.1000
DEBUG - 2022-08-11 08:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:43:41 --> Total execution time: 0.0717
DEBUG - 2022-08-11 08:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:02 --> Total execution time: 0.0851
DEBUG - 2022-08-11 08:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:11 --> Total execution time: 0.0841
DEBUG - 2022-08-11 08:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:22 --> Total execution time: 0.0891
DEBUG - 2022-08-11 08:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:24 --> Total execution time: 0.0803
DEBUG - 2022-08-11 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:34 --> Total execution time: 0.0989
DEBUG - 2022-08-11 08:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:41 --> Total execution time: 0.0897
DEBUG - 2022-08-11 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:14:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:44:55 --> Total execution time: 0.1997
DEBUG - 2022-08-11 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:45:23 --> Total execution time: 0.0743
DEBUG - 2022-08-11 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 08:15:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:15:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:45:45 --> Total execution time: 0.0500
DEBUG - 2022-08-11 08:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:46:41 --> Total execution time: 0.0477
DEBUG - 2022-08-11 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:47:35 --> Total execution time: 0.0793
DEBUG - 2022-08-11 08:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:49:17 --> Total execution time: 0.0772
DEBUG - 2022-08-11 08:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:49:39 --> Total execution time: 0.0797
DEBUG - 2022-08-11 08:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:49:45 --> Total execution time: 0.2215
DEBUG - 2022-08-11 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:50:02 --> Total execution time: 0.0782
DEBUG - 2022-08-11 08:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:20:32 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:50:32 --> Total execution time: 0.0577
DEBUG - 2022-08-11 08:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:50:50 --> Total execution time: 0.0745
DEBUG - 2022-08-11 08:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:16 --> Total execution time: 0.0739
DEBUG - 2022-08-11 08:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:29 --> Total execution time: 0.0743
DEBUG - 2022-08-11 08:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:30 --> Total execution time: 0.0910
DEBUG - 2022-08-11 08:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:34 --> Total execution time: 0.0745
DEBUG - 2022-08-11 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:37 --> Total execution time: 0.0758
DEBUG - 2022-08-11 08:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:37 --> Total execution time: 0.0766
DEBUG - 2022-08-11 08:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:38 --> Total execution time: 0.0743
DEBUG - 2022-08-11 08:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:48 --> Total execution time: 0.1034
DEBUG - 2022-08-11 08:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:51:59 --> Total execution time: 0.1307
DEBUG - 2022-08-11 08:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:00 --> Total execution time: 0.0805
DEBUG - 2022-08-11 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:01 --> Total execution time: 0.0873
DEBUG - 2022-08-11 08:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:04 --> Total execution time: 0.0714
DEBUG - 2022-08-11 08:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:12 --> Total execution time: 0.1925
DEBUG - 2022-08-11 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:13 --> Total execution time: 0.0825
DEBUG - 2022-08-11 08:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:16 --> Total execution time: 0.0833
DEBUG - 2022-08-11 08:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:18 --> Total execution time: 0.0842
DEBUG - 2022-08-11 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:24 --> Total execution time: 0.1447
DEBUG - 2022-08-11 08:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:38 --> Total execution time: 0.0777
DEBUG - 2022-08-11 08:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:42 --> Total execution time: 0.1988
DEBUG - 2022-08-11 08:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:46 --> Total execution time: 0.0838
DEBUG - 2022-08-11 08:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:53 --> Total execution time: 0.0823
DEBUG - 2022-08-11 08:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:55 --> Total execution time: 0.1030
DEBUG - 2022-08-11 08:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:52:55 --> Total execution time: 0.0915
DEBUG - 2022-08-11 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:53:00 --> Total execution time: 0.0893
DEBUG - 2022-08-11 08:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:53:03 --> Total execution time: 0.0782
DEBUG - 2022-08-11 08:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:53:24 --> Total execution time: 0.0749
DEBUG - 2022-08-11 08:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:16 --> Total execution time: 0.0833
DEBUG - 2022-08-11 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:20 --> Total execution time: 0.0880
DEBUG - 2022-08-11 08:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:24 --> Total execution time: 0.0840
DEBUG - 2022-08-11 08:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:25 --> Total execution time: 0.2006
DEBUG - 2022-08-11 08:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:37 --> Total execution time: 0.0782
DEBUG - 2022-08-11 08:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:49 --> Total execution time: 0.0501
DEBUG - 2022-08-11 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:52 --> Total execution time: 0.2024
DEBUG - 2022-08-11 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:53 --> Total execution time: 0.0632
DEBUG - 2022-08-11 08:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:54:56 --> Total execution time: 0.0765
DEBUG - 2022-08-11 08:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:06 --> Total execution time: 0.0973
DEBUG - 2022-08-11 08:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:18 --> Total execution time: 0.0857
DEBUG - 2022-08-11 08:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:19 --> Total execution time: 0.0803
DEBUG - 2022-08-11 08:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:26 --> Total execution time: 0.0789
DEBUG - 2022-08-11 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:27 --> Total execution time: 0.1056
DEBUG - 2022-08-11 08:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:32 --> Total execution time: 0.0740
DEBUG - 2022-08-11 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:42 --> Total execution time: 0.0809
DEBUG - 2022-08-11 08:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:46 --> Total execution time: 0.0901
DEBUG - 2022-08-11 08:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:47 --> Total execution time: 0.0814
DEBUG - 2022-08-11 08:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:47 --> Total execution time: 0.0803
DEBUG - 2022-08-11 08:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:49 --> Total execution time: 0.0801
DEBUG - 2022-08-11 08:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:52 --> Total execution time: 0.0816
DEBUG - 2022-08-11 08:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:52 --> Total execution time: 0.0820
DEBUG - 2022-08-11 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:55 --> Total execution time: 0.0942
DEBUG - 2022-08-11 08:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:25:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:55:58 --> Total execution time: 0.1078
DEBUG - 2022-08-11 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:03 --> Total execution time: 0.0868
DEBUG - 2022-08-11 08:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:09 --> Total execution time: 0.0838
DEBUG - 2022-08-11 08:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:12 --> Total execution time: 0.1015
DEBUG - 2022-08-11 08:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:30 --> Total execution time: 0.0922
DEBUG - 2022-08-11 08:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:34 --> Total execution time: 0.0826
DEBUG - 2022-08-11 08:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:38 --> Total execution time: 0.0820
DEBUG - 2022-08-11 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:42 --> Total execution time: 0.1021
DEBUG - 2022-08-11 08:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:26:43 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:56:43 --> Total execution time: 0.0789
DEBUG - 2022-08-11 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:57:04 --> Total execution time: 0.0860
DEBUG - 2022-08-11 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:57:45 --> Total execution time: 0.0800
DEBUG - 2022-08-11 08:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:57:50 --> Total execution time: 0.0769
DEBUG - 2022-08-11 08:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:57:54 --> Total execution time: 0.0763
DEBUG - 2022-08-11 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:58:00 --> Total execution time: 0.0825
DEBUG - 2022-08-11 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:58:02 --> Total execution time: 0.0765
DEBUG - 2022-08-11 08:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:58:03 --> Total execution time: 0.0901
DEBUG - 2022-08-11 08:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:58:13 --> Total execution time: 0.1018
DEBUG - 2022-08-11 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:58:33 --> Total execution time: 0.0827
DEBUG - 2022-08-11 08:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:29:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:59:57 --> Total execution time: 0.1954
DEBUG - 2022-08-11 08:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:30:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:00:18 --> Total execution time: 0.0769
DEBUG - 2022-08-11 08:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:32:12 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:02:12 --> Total execution time: 0.0522
DEBUG - 2022-08-11 08:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:32:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:02:55 --> Total execution time: 0.0625
DEBUG - 2022-08-11 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:03:06 --> Total execution time: 0.0494
DEBUG - 2022-08-11 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:03:10 --> Total execution time: 0.0855
DEBUG - 2022-08-11 08:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:03:12 --> Total execution time: 0.0740
DEBUG - 2022-08-11 08:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:04:04 --> Total execution time: 0.0756
DEBUG - 2022-08-11 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:04:17 --> Total execution time: 0.0750
DEBUG - 2022-08-11 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:04:59 --> Total execution time: 0.0964
DEBUG - 2022-08-11 08:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:07 --> Total execution time: 0.1385
DEBUG - 2022-08-11 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:13 --> Total execution time: 0.0750
DEBUG - 2022-08-11 08:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:15 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:15 --> Total execution time: 0.2060
DEBUG - 2022-08-11 08:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:24 --> Total execution time: 0.0872
DEBUG - 2022-08-11 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:05:30 --> Total execution time: 0.1052
DEBUG - 2022-08-11 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:06:04 --> Total execution time: 0.2011
DEBUG - 2022-08-11 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:06:04 --> Total execution time: 0.0753
DEBUG - 2022-08-11 08:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:06:30 --> Total execution time: 0.0823
DEBUG - 2022-08-11 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:06:58 --> Total execution time: 0.1566
DEBUG - 2022-08-11 08:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:07:44 --> Total execution time: 0.0739
DEBUG - 2022-08-11 08:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:07:54 --> Total execution time: 0.1009
DEBUG - 2022-08-11 08:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:08:04 --> Total execution time: 0.0774
DEBUG - 2022-08-11 08:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:08:05 --> Total execution time: 0.0836
DEBUG - 2022-08-11 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:08:25 --> Total execution time: 0.0867
DEBUG - 2022-08-11 08:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:09:02 --> Total execution time: 0.0966
DEBUG - 2022-08-11 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:09:22 --> Total execution time: 0.0773
DEBUG - 2022-08-11 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:10:17 --> Total execution time: 0.0982
DEBUG - 2022-08-11 08:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:10:25 --> Total execution time: 0.0804
DEBUG - 2022-08-11 08:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:10:37 --> Total execution time: 0.0817
DEBUG - 2022-08-11 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:11:20 --> Total execution time: 0.0752
DEBUG - 2022-08-11 08:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:11:48 --> Total execution time: 0.1151
DEBUG - 2022-08-11 08:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:11:57 --> Total execution time: 0.0806
DEBUG - 2022-08-11 08:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:12:13 --> Total execution time: 0.0747
DEBUG - 2022-08-11 08:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:13:20 --> Total execution time: 0.0772
DEBUG - 2022-08-11 08:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:13:47 --> Total execution time: 0.0736
DEBUG - 2022-08-11 08:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:14:40 --> Total execution time: 0.0747
DEBUG - 2022-08-11 08:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:44:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 08:44:47 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-11 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 08:44:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 08:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:06 --> Total execution time: 0.0788
DEBUG - 2022-08-11 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:14 --> Total execution time: 0.0665
DEBUG - 2022-08-11 08:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:22 --> Total execution time: 0.0709
DEBUG - 2022-08-11 08:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:35 --> Total execution time: 0.0817
DEBUG - 2022-08-11 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:48 --> Total execution time: 0.0709
DEBUG - 2022-08-11 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:52 --> Total execution time: 0.0449
DEBUG - 2022-08-11 08:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:15:55 --> Total execution time: 0.0701
DEBUG - 2022-08-11 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:02 --> Total execution time: 0.1426
DEBUG - 2022-08-11 08:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:03 --> Total execution time: 0.0713
DEBUG - 2022-08-11 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:38 --> Total execution time: 0.0751
DEBUG - 2022-08-11 08:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:39 --> Total execution time: 0.0745
DEBUG - 2022-08-11 08:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:48 --> Total execution time: 0.0983
DEBUG - 2022-08-11 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:11 --> Total execution time: 0.1110
DEBUG - 2022-08-11 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:16 --> Total execution time: 0.0794
DEBUG - 2022-08-11 08:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:22 --> Total execution time: 0.0858
DEBUG - 2022-08-11 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:33 --> Total execution time: 0.0891
DEBUG - 2022-08-11 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:37 --> Total execution time: 0.0811
DEBUG - 2022-08-11 08:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:41 --> Total execution time: 0.0938
DEBUG - 2022-08-11 08:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:48 --> Total execution time: 0.0931
DEBUG - 2022-08-11 08:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:17:55 --> Total execution time: 0.0885
DEBUG - 2022-08-11 08:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:09 --> Total execution time: 0.0957
DEBUG - 2022-08-11 08:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:15 --> Total execution time: 0.0855
DEBUG - 2022-08-11 08:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:33 --> Total execution time: 0.2323
DEBUG - 2022-08-11 08:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:39 --> Total execution time: 0.3188
DEBUG - 2022-08-11 08:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:48 --> Total execution time: 0.0807
DEBUG - 2022-08-11 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:18:52 --> Total execution time: 0.0751
DEBUG - 2022-08-11 08:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:19:17 --> Total execution time: 0.0780
DEBUG - 2022-08-11 08:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:19:34 --> Total execution time: 0.0745
DEBUG - 2022-08-11 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:19:46 --> Total execution time: 0.0743
DEBUG - 2022-08-11 08:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:50:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:20:16 --> Total execution time: 0.0791
DEBUG - 2022-08-11 08:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:20:34 --> Total execution time: 0.0753
DEBUG - 2022-08-11 08:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:20:53 --> Total execution time: 0.0725
DEBUG - 2022-08-11 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:13 --> Total execution time: 0.1962
DEBUG - 2022-08-11 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:17 --> Total execution time: 0.0752
DEBUG - 2022-08-11 08:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:35 --> Total execution time: 0.0865
DEBUG - 2022-08-11 08:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:49 --> Total execution time: 0.0893
DEBUG - 2022-08-11 08:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:52 --> Total execution time: 0.0767
DEBUG - 2022-08-11 08:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 08:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:54 --> Total execution time: 0.0784
DEBUG - 2022-08-11 08:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:21:58 --> Total execution time: 0.0796
DEBUG - 2022-08-11 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:22:06 --> Total execution time: 0.0746
DEBUG - 2022-08-11 08:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:22:10 --> Total execution time: 0.0924
DEBUG - 2022-08-11 08:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:22:14 --> Total execution time: 0.0843
DEBUG - 2022-08-11 08:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:22:14 --> Total execution time: 0.0868
DEBUG - 2022-08-11 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:23:12 --> Total execution time: 0.0811
DEBUG - 2022-08-11 08:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:24:03 --> Total execution time: 0.0510
DEBUG - 2022-08-11 08:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:24:43 --> Total execution time: 0.0848
DEBUG - 2022-08-11 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:50 --> Total execution time: 0.0836
DEBUG - 2022-08-11 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:24:52 --> Total execution time: 0.0827
DEBUG - 2022-08-11 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:52 --> Total execution time: 0.0847
DEBUG - 2022-08-11 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:54:52 --> Total execution time: 0.0758
DEBUG - 2022-08-11 08:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:24:57 --> Total execution time: 0.0836
DEBUG - 2022-08-11 08:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:06 --> Total execution time: 0.0896
DEBUG - 2022-08-11 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:21 --> Total execution time: 0.1052
DEBUG - 2022-08-11 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:24 --> Total execution time: 0.0492
DEBUG - 2022-08-11 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:28 --> Total execution time: 0.0933
DEBUG - 2022-08-11 08:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:29 --> Total execution time: 0.0746
DEBUG - 2022-08-11 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 08:55:30 --> 404 Page Not Found: Images/1ndex.php
DEBUG - 2022-08-11 08:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:34 --> Total execution time: 0.1165
DEBUG - 2022-08-11 08:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:41 --> Total execution time: 0.0848
DEBUG - 2022-08-11 08:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:25:59 --> Total execution time: 0.0739
DEBUG - 2022-08-11 08:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:03 --> Total execution time: 0.0839
DEBUG - 2022-08-11 08:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:15 --> Total execution time: 0.1004
DEBUG - 2022-08-11 08:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:25 --> Total execution time: 0.0951
DEBUG - 2022-08-11 08:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:27 --> Total execution time: 0.0869
DEBUG - 2022-08-11 08:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:42 --> Total execution time: 0.0830
DEBUG - 2022-08-11 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:26:56 --> Total execution time: 0.0763
DEBUG - 2022-08-11 08:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:27:54 --> Total execution time: 0.0865
DEBUG - 2022-08-11 08:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:04 --> Total execution time: 0.1186
DEBUG - 2022-08-11 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:09 --> Total execution time: 0.0786
DEBUG - 2022-08-11 08:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:13 --> Total execution time: 0.1060
DEBUG - 2022-08-11 08:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:21 --> Total execution time: 0.0929
DEBUG - 2022-08-11 08:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:33 --> Total execution time: 0.0851
DEBUG - 2022-08-11 08:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:37 --> Total execution time: 0.0801
DEBUG - 2022-08-11 08:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:43 --> Total execution time: 0.1017
DEBUG - 2022-08-11 08:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:45 --> Total execution time: 0.0820
DEBUG - 2022-08-11 08:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:50 --> Total execution time: 0.0840
DEBUG - 2022-08-11 08:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:51 --> Total execution time: 0.0892
DEBUG - 2022-08-11 08:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:54 --> Total execution time: 0.0915
DEBUG - 2022-08-11 08:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:56 --> Total execution time: 0.0824
DEBUG - 2022-08-11 08:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:28:59 --> Total execution time: 0.0849
DEBUG - 2022-08-11 08:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:29:02 --> Total execution time: 0.1262
DEBUG - 2022-08-11 08:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:29:07 --> Total execution time: 0.2066
DEBUG - 2022-08-11 08:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:29:12 --> Total execution time: 0.0841
DEBUG - 2022-08-11 08:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:29:17 --> Total execution time: 0.0836
DEBUG - 2022-08-11 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 08:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 08:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 08:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:29:56 --> Total execution time: 0.0924
DEBUG - 2022-08-11 09:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:30:03 --> Total execution time: 0.0579
DEBUG - 2022-08-11 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:30:14 --> Total execution time: 0.0813
DEBUG - 2022-08-11 09:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:30:24 --> Total execution time: 0.0529
DEBUG - 2022-08-11 09:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:30:26 --> Total execution time: 0.1949
DEBUG - 2022-08-11 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:30:46 --> Total execution time: 0.0868
DEBUG - 2022-08-11 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:31:01 --> Total execution time: 0.0861
DEBUG - 2022-08-11 09:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 09:01:19 --> 404 Page Not Found: Assets/colors
DEBUG - 2022-08-11 09:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:31:26 --> Total execution time: 0.0863
DEBUG - 2022-08-11 09:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:31:51 --> Total execution time: 0.1048
DEBUG - 2022-08-11 09:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:02:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:32:06 --> Total execution time: 0.0523
DEBUG - 2022-08-11 09:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:32:08 --> Total execution time: 0.0429
DEBUG - 2022-08-11 09:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:32:35 --> Total execution time: 0.0957
DEBUG - 2022-08-11 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:02:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:32:59 --> Total execution time: 0.0574
DEBUG - 2022-08-11 09:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:36:28 --> Total execution time: 0.2777
DEBUG - 2022-08-11 09:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:36:39 --> Total execution time: 0.0862
DEBUG - 2022-08-11 09:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:08:21 --> Total execution time: 0.0901
DEBUG - 2022-08-11 09:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:06 --> Total execution time: 0.0531
DEBUG - 2022-08-11 09:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:07 --> Total execution time: 0.2351
DEBUG - 2022-08-11 09:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:13 --> Total execution time: 0.0852
DEBUG - 2022-08-11 09:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:17 --> Total execution time: 0.0878
DEBUG - 2022-08-11 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:27 --> Total execution time: 0.0766
DEBUG - 2022-08-11 09:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:35 --> Total execution time: 0.0799
DEBUG - 2022-08-11 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:41:56 --> Total execution time: 0.0756
DEBUG - 2022-08-11 09:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:42:06 --> Total execution time: 0.1114
DEBUG - 2022-08-11 09:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:42:20 --> Total execution time: 0.0817
DEBUG - 2022-08-11 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:20 --> Total execution time: 0.1203
DEBUG - 2022-08-11 09:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:24 --> Total execution time: 0.0840
DEBUG - 2022-08-11 09:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:32 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:32 --> Total execution time: 0.2188
DEBUG - 2022-08-11 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:37 --> Total execution time: 0.0754
DEBUG - 2022-08-11 09:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:48 --> Total execution time: 0.0766
DEBUG - 2022-08-11 09:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:17:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:47:56 --> Total execution time: 0.0778
DEBUG - 2022-08-11 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:48:03 --> Total execution time: 0.0828
DEBUG - 2022-08-11 09:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:48:09 --> Total execution time: 0.0758
DEBUG - 2022-08-11 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:48:20 --> Total execution time: 0.0870
DEBUG - 2022-08-11 09:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:48:29 --> Total execution time: 0.5236
DEBUG - 2022-08-11 09:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:48:58 --> Total execution time: 0.0743
DEBUG - 2022-08-11 09:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:49:07 --> Total execution time: 0.0813
DEBUG - 2022-08-11 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:19:38 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:49:38 --> Total execution time: 0.0503
DEBUG - 2022-08-11 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:49:44 --> Total execution time: 0.0627
DEBUG - 2022-08-11 09:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:54:19 --> Total execution time: 0.1219
DEBUG - 2022-08-11 09:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:25:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:42 --> Total execution time: 0.0547
DEBUG - 2022-08-11 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:25:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:47 --> Total execution time: 0.2001
DEBUG - 2022-08-11 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:52 --> Total execution time: 0.0787
DEBUG - 2022-08-11 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:25:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:57 --> Total execution time: 0.0784
DEBUG - 2022-08-11 09:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:25:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:58 --> Total execution time: 0.0925
DEBUG - 2022-08-11 09:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:56:27 --> Total execution time: 0.0888
DEBUG - 2022-08-11 09:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:56:47 --> Total execution time: 0.1122
DEBUG - 2022-08-11 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:58:37 --> Total execution time: 0.0825
DEBUG - 2022-08-11 09:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:58:48 --> Total execution time: 0.1410
DEBUG - 2022-08-11 09:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:58:58 --> Total execution time: 0.1016
DEBUG - 2022-08-11 09:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:59:06 --> Total execution time: 0.0839
DEBUG - 2022-08-11 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:29:15 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:59:15 --> Total execution time: 0.0628
DEBUG - 2022-08-11 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:29:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:59:16 --> Total execution time: 0.0514
DEBUG - 2022-08-11 09:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 09:29:44 --> 404 Page Not Found: Cache/accesson1.php
DEBUG - 2022-08-11 09:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:00:45 --> Total execution time: 0.0879
DEBUG - 2022-08-11 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:00:52 --> Total execution time: 0.0784
DEBUG - 2022-08-11 09:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:03 --> Total execution time: 0.0754
DEBUG - 2022-08-11 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:09 --> Total execution time: 0.0749
DEBUG - 2022-08-11 09:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:09 --> Total execution time: 0.0471
DEBUG - 2022-08-11 09:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:15 --> Total execution time: 0.0882
DEBUG - 2022-08-11 09:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:32 --> Total execution time: 0.0999
DEBUG - 2022-08-11 09:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:35 --> Total execution time: 0.0876
DEBUG - 2022-08-11 09:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:01:59 --> Total execution time: 0.0778
DEBUG - 2022-08-11 09:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:02 --> Total execution time: 0.0863
DEBUG - 2022-08-11 09:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:06 --> Total execution time: 0.1035
DEBUG - 2022-08-11 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:20 --> Total execution time: 0.0792
DEBUG - 2022-08-11 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:24 --> Total execution time: 0.1203
DEBUG - 2022-08-11 09:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:25 --> Total execution time: 0.0858
DEBUG - 2022-08-11 09:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:25 --> Total execution time: 0.0856
DEBUG - 2022-08-11 09:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:26 --> Total execution time: 0.0853
DEBUG - 2022-08-11 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:27 --> Total execution time: 0.0813
DEBUG - 2022-08-11 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:32:29 --> Total execution time: 0.0824
DEBUG - 2022-08-11 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:30 --> Total execution time: 0.0742
DEBUG - 2022-08-11 09:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:02:33 --> Total execution time: 0.1970
DEBUG - 2022-08-11 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:32:41 --> Total execution time: 0.1429
DEBUG - 2022-08-11 09:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:03:09 --> Total execution time: 0.2177
DEBUG - 2022-08-11 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:03:25 --> Total execution time: 0.0783
DEBUG - 2022-08-11 09:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:03:26 --> Total execution time: 0.0858
DEBUG - 2022-08-11 09:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:03:34 --> Total execution time: 0.0837
DEBUG - 2022-08-11 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:03:35 --> Total execution time: 0.0910
DEBUG - 2022-08-11 09:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:04:20 --> Total execution time: 0.0891
DEBUG - 2022-08-11 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:34:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:04:59 --> Total execution time: 0.0780
DEBUG - 2022-08-11 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:05:05 --> Total execution time: 0.0788
DEBUG - 2022-08-11 09:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:05:12 --> Total execution time: 0.0835
DEBUG - 2022-08-11 09:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:05:18 --> Total execution time: 0.1258
DEBUG - 2022-08-11 09:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:35:23 --> Total execution time: 0.0779
DEBUG - 2022-08-11 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:35:27 --> Total execution time: 0.1219
DEBUG - 2022-08-11 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:05:58 --> Total execution time: 0.0885
DEBUG - 2022-08-11 09:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:05:59 --> Total execution time: 0.0881
DEBUG - 2022-08-11 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:06:01 --> Total execution time: 0.0881
DEBUG - 2022-08-11 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:06:15 --> Total execution time: 0.0807
DEBUG - 2022-08-11 09:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:06:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 09:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:06:54 --> Total execution time: 0.0946
DEBUG - 2022-08-11 09:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:07:08 --> Total execution time: 0.0864
DEBUG - 2022-08-11 09:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:10:35 --> Total execution time: 0.3508
DEBUG - 2022-08-11 09:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:10:52 --> Total execution time: 0.0852
DEBUG - 2022-08-11 09:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:11:04 --> Total execution time: 0.2202
DEBUG - 2022-08-11 09:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:11:24 --> Total execution time: 0.0889
DEBUG - 2022-08-11 09:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:41:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:11:55 --> Total execution time: 0.0671
DEBUG - 2022-08-11 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:12:39 --> Total execution time: 0.0782
DEBUG - 2022-08-11 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:12:48 --> Total execution time: 0.0762
DEBUG - 2022-08-11 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:12:54 --> Total execution time: 0.0923
DEBUG - 2022-08-11 09:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:44:35 --> Total execution time: 0.0870
DEBUG - 2022-08-11 09:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:44:49 --> Total execution time: 0.1365
DEBUG - 2022-08-11 09:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:15:08 --> Total execution time: 0.1338
DEBUG - 2022-08-11 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:15:37 --> Total execution time: 0.1275
DEBUG - 2022-08-11 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:15:46 --> Total execution time: 0.0866
DEBUG - 2022-08-11 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:16:41 --> Total execution time: 0.0822
DEBUG - 2022-08-11 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:16:56 --> Total execution time: 0.0915
DEBUG - 2022-08-11 09:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:17:00 --> Total execution time: 0.0774
DEBUG - 2022-08-11 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:17:22 --> Total execution time: 0.1137
DEBUG - 2022-08-11 09:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:17:32 --> Total execution time: 0.1203
DEBUG - 2022-08-11 09:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:17:43 --> Total execution time: 0.1036
DEBUG - 2022-08-11 09:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:18:09 --> Total execution time: 0.0858
DEBUG - 2022-08-11 09:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:18:56 --> Total execution time: 0.2009
DEBUG - 2022-08-11 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:18:59 --> Total execution time: 0.1159
DEBUG - 2022-08-11 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:19:03 --> Total execution time: 0.1017
DEBUG - 2022-08-11 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:19:13 --> Total execution time: 0.0824
DEBUG - 2022-08-11 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:19:21 --> Total execution time: 0.0487
DEBUG - 2022-08-11 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:49:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:19:46 --> Total execution time: 0.0573
DEBUG - 2022-08-11 09:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:32 --> Total execution time: 0.0866
DEBUG - 2022-08-11 09:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:39 --> Total execution time: 0.2033
DEBUG - 2022-08-11 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:46 --> Total execution time: 0.0808
DEBUG - 2022-08-11 09:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:51 --> Total execution time: 0.0806
DEBUG - 2022-08-11 09:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:55 --> Total execution time: 0.0864
DEBUG - 2022-08-11 09:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:59 --> Total execution time: 0.0773
DEBUG - 2022-08-11 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:08 --> Total execution time: 0.1026
DEBUG - 2022-08-11 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:09 --> Total execution time: 0.0940
DEBUG - 2022-08-11 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:13 --> Total execution time: 0.1082
DEBUG - 2022-08-11 09:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:17 --> Total execution time: 0.0756
DEBUG - 2022-08-11 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:19 --> Total execution time: 0.1061
DEBUG - 2022-08-11 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:24 --> Total execution time: 0.1397
DEBUG - 2022-08-11 20:21:24 --> Total execution time: 0.0962
DEBUG - 2022-08-11 09:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:30 --> Total execution time: 0.0866
DEBUG - 2022-08-11 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:37 --> Total execution time: 0.0753
DEBUG - 2022-08-11 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:41 --> Total execution time: 0.1129
DEBUG - 2022-08-11 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:48 --> Total execution time: 0.1155
DEBUG - 2022-08-11 09:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:15 --> Total execution time: 0.1053
DEBUG - 2022-08-11 09:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:54:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:46 --> Total execution time: 0.1201
DEBUG - 2022-08-11 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:59 --> Total execution time: 0.0569
DEBUG - 2022-08-11 09:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:55:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:25:07 --> Total execution time: 0.0717
DEBUG - 2022-08-11 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:55:23 --> Total execution time: 0.1218
DEBUG - 2022-08-11 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:55:25 --> Total execution time: 0.0905
DEBUG - 2022-08-11 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:55:26 --> Total execution time: 0.0776
DEBUG - 2022-08-11 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:55:41 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:25:41 --> Total execution time: 0.0518
DEBUG - 2022-08-11 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:26:18 --> Total execution time: 2.2013
DEBUG - 2022-08-11 09:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:56:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 09:56:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:56:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:26:49 --> Total execution time: 0.0509
DEBUG - 2022-08-11 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:57:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:27:09 --> Total execution time: 0.0774
DEBUG - 2022-08-11 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:27:35 --> Total execution time: 0.0891
DEBUG - 2022-08-11 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:57:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:27:48 --> Total execution time: 0.1017
DEBUG - 2022-08-11 09:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:28:26 --> Total execution time: 0.2372
DEBUG - 2022-08-11 09:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 09:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 09:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:28:37 --> Total execution time: 0.0779
DEBUG - 2022-08-11 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:30:02 --> Total execution time: 0.0850
DEBUG - 2022-08-11 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:30:27 --> Total execution time: 0.0760
DEBUG - 2022-08-11 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:30:38 --> Total execution time: 0.0903
DEBUG - 2022-08-11 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:30:45 --> Total execution time: 0.0839
DEBUG - 2022-08-11 10:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:30:55 --> Total execution time: 0.0870
DEBUG - 2022-08-11 10:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:31:05 --> Total execution time: 0.0758
DEBUG - 2022-08-11 10:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:02:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:32:54 --> Total execution time: 0.0619
DEBUG - 2022-08-11 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:33:06 --> Total execution time: 0.0863
DEBUG - 2022-08-11 10:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:33:08 --> Total execution time: 0.0587
DEBUG - 2022-08-11 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:03:37 --> Total execution time: 0.0515
DEBUG - 2022-08-11 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:33:38 --> Total execution time: 0.2331
DEBUG - 2022-08-11 10:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:03:39 --> Total execution time: 0.0818
DEBUG - 2022-08-11 10:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:03:39 --> Total execution time: 0.0825
DEBUG - 2022-08-11 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:34:08 --> Total execution time: 0.0798
DEBUG - 2022-08-11 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:34:10 --> Total execution time: 0.0752
DEBUG - 2022-08-11 10:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:34:43 --> Total execution time: 0.0505
DEBUG - 2022-08-11 10:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:01 --> Total execution time: 0.1199
DEBUG - 2022-08-11 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:03 --> Total execution time: 0.0795
DEBUG - 2022-08-11 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:03 --> Total execution time: 0.1649
DEBUG - 2022-08-11 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:35:08 --> Total execution time: 0.0756
DEBUG - 2022-08-11 10:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:35:17 --> Total execution time: 0.0836
DEBUG - 2022-08-11 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:35:23 --> Total execution time: 0.0759
DEBUG - 2022-08-11 10:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:35:24 --> Total execution time: 0.0770
DEBUG - 2022-08-11 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:35:32 --> Total execution time: 0.0890
DEBUG - 2022-08-11 10:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:38:09 --> Total execution time: 0.1894
DEBUG - 2022-08-11 10:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:38:15 --> Total execution time: 0.0870
DEBUG - 2022-08-11 10:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:38:25 --> Total execution time: 0.1437
DEBUG - 2022-08-11 10:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:02 --> Total execution time: 0.2598
DEBUG - 2022-08-11 10:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:20 --> Total execution time: 0.2010
DEBUG - 2022-08-11 10:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:21 --> Total execution time: 0.1161
DEBUG - 2022-08-11 10:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:29 --> Total execution time: 1.5975
DEBUG - 2022-08-11 10:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:30 --> Total execution time: 0.1015
DEBUG - 2022-08-11 10:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 10:10:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:39 --> Total execution time: 0.0855
DEBUG - 2022-08-11 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:40:57 --> Total execution time: 0.0947
DEBUG - 2022-08-11 10:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:06 --> Total execution time: 0.0858
DEBUG - 2022-08-11 10:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:18 --> Total execution time: 0.0870
DEBUG - 2022-08-11 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:25 --> Total execution time: 0.0806
DEBUG - 2022-08-11 10:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:31 --> Total execution time: 0.0886
DEBUG - 2022-08-11 10:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:37 --> Total execution time: 0.1008
DEBUG - 2022-08-11 10:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:42:58 --> Total execution time: 0.0917
DEBUG - 2022-08-11 10:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:43:09 --> Total execution time: 0.1112
DEBUG - 2022-08-11 10:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:10 --> Total execution time: 0.1639
DEBUG - 2022-08-11 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:43:14 --> Total execution time: 0.0851
DEBUG - 2022-08-11 10:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:19 --> Total execution time: 0.0782
DEBUG - 2022-08-11 10:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:13:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:13:27 --> Total execution time: 0.0989
DEBUG - 2022-08-11 10:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:01 --> Total execution time: 0.0760
DEBUG - 2022-08-11 10:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:15 --> Total execution time: 0.0739
DEBUG - 2022-08-11 10:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:38 --> Total execution time: 0.0502
DEBUG - 2022-08-11 10:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:15:52 --> Total execution time: 0.0777
DEBUG - 2022-08-11 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:15:57 --> Total execution time: 0.0761
DEBUG - 2022-08-11 10:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:04 --> Total execution time: 0.0785
DEBUG - 2022-08-11 10:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:08 --> Total execution time: 0.0752
DEBUG - 2022-08-11 10:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:15 --> Total execution time: 0.0939
DEBUG - 2022-08-11 10:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:19 --> Total execution time: 0.0795
DEBUG - 2022-08-11 10:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:16:20 --> Total execution time: 0.0793
DEBUG - 2022-08-11 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:46:25 --> Total execution time: 0.0807
DEBUG - 2022-08-11 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:46:27 --> Total execution time: 0.0824
DEBUG - 2022-08-11 10:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:46:45 --> Total execution time: 0.0854
DEBUG - 2022-08-11 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:20 --> Total execution time: 0.1389
DEBUG - 2022-08-11 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:33 --> Total execution time: 0.0867
DEBUG - 2022-08-11 10:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:42 --> Total execution time: 0.1076
DEBUG - 2022-08-11 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:54 --> Total execution time: 0.0862
DEBUG - 2022-08-11 10:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:48:05 --> Total execution time: 0.0806
DEBUG - 2022-08-11 10:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:48:15 --> Total execution time: 0.0808
DEBUG - 2022-08-11 10:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:48:27 --> Total execution time: 0.0825
DEBUG - 2022-08-11 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:49:02 --> Total execution time: 0.0885
DEBUG - 2022-08-11 10:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:49:08 --> Total execution time: 0.0867
DEBUG - 2022-08-11 10:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:50:45 --> Total execution time: 0.1982
DEBUG - 2022-08-11 10:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:52:17 --> Total execution time: 0.0827
DEBUG - 2022-08-11 10:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:22:50 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:52:50 --> Total execution time: 0.0545
DEBUG - 2022-08-11 10:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:53:01 --> Total execution time: 0.0750
DEBUG - 2022-08-11 10:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:54:24 --> Total execution time: 0.0842
DEBUG - 2022-08-11 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:54:56 --> Total execution time: 0.0789
DEBUG - 2022-08-11 10:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:55:05 --> Total execution time: 0.0865
DEBUG - 2022-08-11 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:55:41 --> Total execution time: 0.0783
DEBUG - 2022-08-11 10:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:08 --> Total execution time: 0.2013
DEBUG - 2022-08-11 10:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:09 --> Total execution time: 0.0942
DEBUG - 2022-08-11 10:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:11 --> Total execution time: 0.2326
DEBUG - 2022-08-11 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:17 --> Total execution time: 0.0913
DEBUG - 2022-08-11 10:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:20 --> Total execution time: 0.0767
DEBUG - 2022-08-11 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:21 --> Total execution time: 0.0780
DEBUG - 2022-08-11 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:31 --> Total execution time: 0.1118
DEBUG - 2022-08-11 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:34 --> Total execution time: 0.0900
DEBUG - 2022-08-11 10:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:36 --> Total execution time: 0.0541
DEBUG - 2022-08-11 10:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:41 --> Total execution time: 0.0976
DEBUG - 2022-08-11 10:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:42 --> Total execution time: 0.1089
DEBUG - 2022-08-11 10:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:43 --> Total execution time: 0.0807
DEBUG - 2022-08-11 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:44 --> Total execution time: 0.0608
DEBUG - 2022-08-11 10:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:44 --> Total execution time: 0.0783
DEBUG - 2022-08-11 10:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:49 --> Total execution time: 0.0762
DEBUG - 2022-08-11 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:58:56 --> Total execution time: 0.0785
DEBUG - 2022-08-11 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:59:12 --> Total execution time: 0.2232
DEBUG - 2022-08-11 10:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:59:31 --> Total execution time: 0.0853
DEBUG - 2022-08-11 10:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:59:39 --> Total execution time: 0.0744
DEBUG - 2022-08-11 10:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:59:50 --> Total execution time: 0.0702
DEBUG - 2022-08-11 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:59:58 --> Total execution time: 0.0793
DEBUG - 2022-08-11 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:17 --> Total execution time: 0.0787
DEBUG - 2022-08-11 10:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:22 --> Total execution time: 0.0758
DEBUG - 2022-08-11 10:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:42 --> Total execution time: 0.0875
DEBUG - 2022-08-11 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:42 --> Total execution time: 0.0708
DEBUG - 2022-08-11 10:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:43 --> Total execution time: 0.0713
DEBUG - 2022-08-11 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:01:23 --> Total execution time: 0.0868
DEBUG - 2022-08-11 10:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:02:06 --> Total execution time: 0.0749
DEBUG - 2022-08-11 10:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:32:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:02:15 --> Total execution time: 0.1979
DEBUG - 2022-08-11 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:03:42 --> Total execution time: 0.2432
DEBUG - 2022-08-11 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:03:59 --> Total execution time: 0.1993
DEBUG - 2022-08-11 10:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:04:08 --> Total execution time: 0.0928
DEBUG - 2022-08-11 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:05:22 --> Total execution time: 0.0482
DEBUG - 2022-08-11 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:05:47 --> Total execution time: 0.0481
DEBUG - 2022-08-11 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:05:47 --> Total execution time: 0.0485
DEBUG - 2022-08-11 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:05:50 --> Total execution time: 0.0768
DEBUG - 2022-08-11 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:06:17 --> Total execution time: 0.0850
DEBUG - 2022-08-11 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:07:09 --> Total execution time: 0.0989
DEBUG - 2022-08-11 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:07:20 --> Total execution time: 0.1039
DEBUG - 2022-08-11 10:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:07:47 --> Total execution time: 0.1138
DEBUG - 2022-08-11 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:07:56 --> Total execution time: 0.0792
DEBUG - 2022-08-11 10:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:09:09 --> Total execution time: 0.0767
DEBUG - 2022-08-11 10:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:09:22 --> Total execution time: 0.0751
DEBUG - 2022-08-11 10:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:09:27 --> Total execution time: 0.0763
DEBUG - 2022-08-11 10:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:10:16 --> Total execution time: 0.0760
DEBUG - 2022-08-11 10:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:10:26 --> Total execution time: 0.2022
DEBUG - 2022-08-11 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:40:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:10:45 --> Total execution time: 0.0554
DEBUG - 2022-08-11 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:40:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:10:51 --> Total execution time: 0.1965
DEBUG - 2022-08-11 10:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:11:02 --> Total execution time: 0.1570
DEBUG - 2022-08-11 10:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:11:22 --> Total execution time: 0.0896
DEBUG - 2022-08-11 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:42:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:12:25 --> Total execution time: 0.0662
DEBUG - 2022-08-11 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:13:19 --> Total execution time: 0.0699
DEBUG - 2022-08-11 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:13:23 --> Total execution time: 0.0742
DEBUG - 2022-08-11 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:13:49 --> Total execution time: 0.0822
DEBUG - 2022-08-11 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:13:55 --> Total execution time: 0.0747
DEBUG - 2022-08-11 10:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:14:51 --> Total execution time: 0.0819
DEBUG - 2022-08-11 10:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:15:14 --> Total execution time: 0.0865
DEBUG - 2022-08-11 10:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:03 --> Total execution time: 0.0511
DEBUG - 2022-08-11 10:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:18 --> Total execution time: 0.1259
DEBUG - 2022-08-11 10:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:24 --> Total execution time: 0.0748
DEBUG - 2022-08-11 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:31 --> Total execution time: 0.1284
DEBUG - 2022-08-11 10:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:31 --> Total execution time: 0.1192
DEBUG - 2022-08-11 10:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:37 --> Total execution time: 0.0824
DEBUG - 2022-08-11 10:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:38 --> Total execution time: 0.1019
DEBUG - 2022-08-11 10:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:42 --> Total execution time: 0.1076
DEBUG - 2022-08-11 10:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:44 --> Total execution time: 0.1146
DEBUG - 2022-08-11 10:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:46:56 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:16:56 --> Total execution time: 0.0514
DEBUG - 2022-08-11 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:17:24 --> Total execution time: 0.0856
DEBUG - 2022-08-11 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:48:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:18:17 --> Total execution time: 0.0961
DEBUG - 2022-08-11 10:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:49:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:14 --> Total execution time: 0.0645
DEBUG - 2022-08-11 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:49:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:18 --> Total execution time: 0.2891
DEBUG - 2022-08-11 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:49:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:49:22 --> Total execution time: 0.2543
DEBUG - 2022-08-11 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:49:24 --> Total execution time: 0.0997
DEBUG - 2022-08-11 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:49:24 --> Total execution time: 0.0857
DEBUG - 2022-08-11 10:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 10:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:23 --> Total execution time: 2.1553
DEBUG - 2022-08-11 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 10:50:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:54:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:24:39 --> Total execution time: 0.1178
DEBUG - 2022-08-11 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:28:01 --> Total execution time: 0.1202
DEBUG - 2022-08-11 10:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:58:12 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:28:12 --> Total execution time: 0.2007
DEBUG - 2022-08-11 10:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:58:37 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:28:37 --> Total execution time: 0.0524
DEBUG - 2022-08-11 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:58:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:28:51 --> Total execution time: 0.0792
DEBUG - 2022-08-11 10:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:29:42 --> Total execution time: 0.2539
DEBUG - 2022-08-11 10:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:29:50 --> Total execution time: 0.1206
DEBUG - 2022-08-11 10:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:29:57 --> Total execution time: 0.1003
DEBUG - 2022-08-11 10:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 10:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 10:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:29:58 --> Total execution time: 0.0746
DEBUG - 2022-08-11 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:03 --> Total execution time: 0.1504
DEBUG - 2022-08-11 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:08 --> Total execution time: 0.1062
DEBUG - 2022-08-11 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:15 --> Total execution time: 0.0898
DEBUG - 2022-08-11 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:20 --> Total execution time: 0.0977
DEBUG - 2022-08-11 11:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:30 --> Total execution time: 0.1936
DEBUG - 2022-08-11 11:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:46 --> Total execution time: 0.0771
DEBUG - 2022-08-11 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:51 --> Total execution time: 0.0808
DEBUG - 2022-08-11 11:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:00:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:54 --> Total execution time: 0.0846
DEBUG - 2022-08-11 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:11 --> Total execution time: 0.0795
DEBUG - 2022-08-11 11:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:13 --> Total execution time: 0.0756
DEBUG - 2022-08-11 11:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:14 --> Total execution time: 0.0707
DEBUG - 2022-08-11 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:31:36 --> Total execution time: 0.0845
DEBUG - 2022-08-11 11:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:31:44 --> Total execution time: 0.0512
DEBUG - 2022-08-11 11:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 11:01:45 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-11 11:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:31:48 --> Total execution time: 0.0966
DEBUG - 2022-08-11 11:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:03 --> Total execution time: 0.1057
DEBUG - 2022-08-11 11:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:19 --> Total execution time: 0.0835
DEBUG - 2022-08-11 11:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:22 --> Total execution time: 0.0811
DEBUG - 2022-08-11 11:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:38 --> Total execution time: 0.1152
DEBUG - 2022-08-11 11:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:42 --> Total execution time: 0.0932
DEBUG - 2022-08-11 11:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:51 --> Total execution time: 0.0847
DEBUG - 2022-08-11 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:14 --> Total execution time: 0.0803
DEBUG - 2022-08-11 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:17 --> Total execution time: 0.0790
DEBUG - 2022-08-11 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:20 --> Total execution time: 0.0855
DEBUG - 2022-08-11 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:20 --> Total execution time: 0.0753
DEBUG - 2022-08-11 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:27 --> Total execution time: 0.0800
DEBUG - 2022-08-11 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:41 --> Total execution time: 0.1958
DEBUG - 2022-08-11 11:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:41 --> Total execution time: 0.1041
DEBUG - 2022-08-11 11:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:48 --> Total execution time: 0.0774
DEBUG - 2022-08-11 11:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:49 --> Total execution time: 1.8874
DEBUG - 2022-08-11 11:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:53 --> Total execution time: 0.0844
DEBUG - 2022-08-11 11:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:33:54 --> Total execution time: 0.1084
DEBUG - 2022-08-11 11:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:06 --> Total execution time: 0.1058
DEBUG - 2022-08-11 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:09 --> Total execution time: 0.1016
DEBUG - 2022-08-11 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:10 --> Total execution time: 0.1029
DEBUG - 2022-08-11 11:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:24 --> Total execution time: 0.0785
DEBUG - 2022-08-11 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:26 --> Total execution time: 0.0838
DEBUG - 2022-08-11 11:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:44 --> Total execution time: 0.0851
DEBUG - 2022-08-11 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:34:52 --> Total execution time: 0.1277
DEBUG - 2022-08-11 11:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:03 --> Total execution time: 0.0848
DEBUG - 2022-08-11 11:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:08 --> Total execution time: 0.0835
DEBUG - 2022-08-11 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:21 --> Total execution time: 0.0864
DEBUG - 2022-08-11 11:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:36 --> Total execution time: 0.0508
DEBUG - 2022-08-11 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:47 --> Total execution time: 0.0856
DEBUG - 2022-08-11 11:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:06:06 --> Total execution time: 0.0825
DEBUG - 2022-08-11 11:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:06:14 --> Total execution time: 0.1110
DEBUG - 2022-08-11 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:11 --> Total execution time: 0.0524
DEBUG - 2022-08-11 11:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:36 --> Total execution time: 0.0552
DEBUG - 2022-08-11 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:44 --> Total execution time: 0.0861
DEBUG - 2022-08-11 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:48 --> Total execution time: 0.0506
DEBUG - 2022-08-11 11:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:38:01 --> Total execution time: 0.1586
DEBUG - 2022-08-11 11:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:38:14 --> Total execution time: 0.0940
DEBUG - 2022-08-11 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:38:55 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 11:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:38:55 --> Total execution time: 0.0894
DEBUG - 2022-08-11 11:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:39:11 --> Total execution time: 0.0597
DEBUG - 2022-08-11 11:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:09:13 --> Total execution time: 0.0773
DEBUG - 2022-08-11 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:09:27 --> Total execution time: 0.0759
DEBUG - 2022-08-11 11:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:09:27 --> Total execution time: 0.1697
DEBUG - 2022-08-11 11:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:39:46 --> Total execution time: 0.1000
DEBUG - 2022-08-11 11:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:39:52 --> Total execution time: 0.2296
DEBUG - 2022-08-11 11:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:39:55 --> Total execution time: 0.0909
DEBUG - 2022-08-11 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:10:18 --> Total execution time: 0.0797
DEBUG - 2022-08-11 11:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:10:28 --> Total execution time: 0.1213
DEBUG - 2022-08-11 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:41:06 --> Total execution time: 0.0761
DEBUG - 2022-08-11 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:41:15 --> Total execution time: 0.1169
DEBUG - 2022-08-11 11:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:41:21 --> Total execution time: 0.0829
DEBUG - 2022-08-11 11:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:41:33 --> Total execution time: 0.1177
DEBUG - 2022-08-11 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:41:40 --> Total execution time: 0.1368
DEBUG - 2022-08-11 11:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:02 --> Total execution time: 0.1069
DEBUG - 2022-08-11 11:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:21 --> Total execution time: 0.0769
DEBUG - 2022-08-11 11:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:27 --> Total execution time: 0.0967
DEBUG - 2022-08-11 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:33 --> Total execution time: 0.0840
DEBUG - 2022-08-11 11:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:44 --> Total execution time: 0.1085
DEBUG - 2022-08-11 11:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:56 --> Total execution time: 0.2050
DEBUG - 2022-08-11 11:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:03 --> Total execution time: 0.0897
DEBUG - 2022-08-11 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:05 --> Total execution time: 0.0756
DEBUG - 2022-08-11 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:30 --> Total execution time: 0.0823
DEBUG - 2022-08-11 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:45:04 --> Total execution time: 0.1121
DEBUG - 2022-08-11 11:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:45:12 --> Total execution time: 0.0933
DEBUG - 2022-08-11 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:45:36 --> Total execution time: 0.0803
DEBUG - 2022-08-11 11:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:26 --> Total execution time: 0.0519
DEBUG - 2022-08-11 11:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:34 --> Total execution time: 0.0811
DEBUG - 2022-08-11 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:49 --> Total execution time: 0.0840
DEBUG - 2022-08-11 11:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:54 --> Total execution time: 0.0822
DEBUG - 2022-08-11 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:16:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:59 --> Total execution time: 0.0854
DEBUG - 2022-08-11 11:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:18:45 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:48:45 --> Total execution time: 0.0548
DEBUG - 2022-08-11 11:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:19:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:49:34 --> Total execution time: 0.2266
DEBUG - 2022-08-11 11:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:49:46 --> Total execution time: 0.0824
DEBUG - 2022-08-11 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:50:16 --> Total execution time: 0.1322
DEBUG - 2022-08-11 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:50:41 --> Total execution time: 0.0872
DEBUG - 2022-08-11 11:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:50:57 --> Total execution time: 0.0766
DEBUG - 2022-08-11 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:51:18 --> Total execution time: 0.0884
DEBUG - 2022-08-11 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:52:25 --> Total execution time: 0.0892
DEBUG - 2022-08-11 11:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:00 --> Total execution time: 0.1341
DEBUG - 2022-08-11 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:28 --> Total execution time: 0.0426
DEBUG - 2022-08-11 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:30 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:54:30 --> Total execution time: 0.0723
DEBUG - 2022-08-11 11:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:30 --> Total execution time: 0.0514
DEBUG - 2022-08-11 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:38 --> Total execution time: 0.0766
DEBUG - 2022-08-11 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:47 --> Total execution time: 0.0837
DEBUG - 2022-08-11 11:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:53 --> Total execution time: 0.0959
DEBUG - 2022-08-11 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:03 --> Total execution time: 0.1128
DEBUG - 2022-08-11 11:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:11 --> Total execution time: 0.2266
DEBUG - 2022-08-11 11:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:11 --> Total execution time: 0.0980
DEBUG - 2022-08-11 11:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:13 --> Total execution time: 0.0987
DEBUG - 2022-08-11 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:16 --> Total execution time: 0.0513
DEBUG - 2022-08-11 11:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:16 --> Total execution time: 0.0812
DEBUG - 2022-08-11 11:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:22 --> Total execution time: 0.0766
DEBUG - 2022-08-11 11:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:23 --> Total execution time: 0.1080
DEBUG - 2022-08-11 11:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:30 --> Total execution time: 0.0876
DEBUG - 2022-08-11 11:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:40 --> Total execution time: 0.0514
DEBUG - 2022-08-11 11:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:55:50 --> Total execution time: 0.1356
DEBUG - 2022-08-11 11:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:56:06 --> Total execution time: 0.0522
DEBUG - 2022-08-11 11:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:56:07 --> Total execution time: 0.0772
DEBUG - 2022-08-11 11:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:56:18 --> Total execution time: 0.0801
DEBUG - 2022-08-11 11:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:26:35 --> Total execution time: 0.0882
DEBUG - 2022-08-11 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:26:38 --> Total execution time: 0.1096
DEBUG - 2022-08-11 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:26:39 --> Total execution time: 0.0981
DEBUG - 2022-08-11 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:26:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:56:46 --> Total execution time: 0.0533
DEBUG - 2022-08-11 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:57:11 --> Total execution time: 0.0989
DEBUG - 2022-08-11 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:58:06 --> Total execution time: 2.1491
DEBUG - 2022-08-11 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 11:28:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 11:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:28:21 --> Total execution time: 0.0752
DEBUG - 2022-08-11 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:28:24 --> Total execution time: 0.0801
DEBUG - 2022-08-11 11:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:28:24 --> Total execution time: 0.0787
DEBUG - 2022-08-11 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:28:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:58:59 --> Total execution time: 0.0621
DEBUG - 2022-08-11 11:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:29:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:59:00 --> Total execution time: 0.0515
DEBUG - 2022-08-11 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:34 --> Total execution time: 0.1233
DEBUG - 2022-08-11 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:36 --> Total execution time: 0.0854
DEBUG - 2022-08-11 11:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:36 --> Total execution time: 0.0821
DEBUG - 2022-08-11 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:01:51 --> Total execution time: 0.0825
DEBUG - 2022-08-11 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:31:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:01:54 --> Total execution time: 0.0916
DEBUG - 2022-08-11 11:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:33:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:03:27 --> Total execution time: 0.1978
DEBUG - 2022-08-11 11:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:09 --> Total execution time: 0.1066
DEBUG - 2022-08-11 11:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:11 --> Total execution time: 0.0762
DEBUG - 2022-08-11 11:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:11 --> Total execution time: 0.0829
DEBUG - 2022-08-11 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:04:19 --> Total execution time: 0.0536
DEBUG - 2022-08-11 11:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:04:22 --> Total execution time: 0.0883
DEBUG - 2022-08-11 11:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:36 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:04:36 --> Total execution time: 0.0762
DEBUG - 2022-08-11 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:04:51 --> Total execution time: 0.0767
DEBUG - 2022-08-11 11:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:35:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:05:03 --> Total execution time: 0.0771
DEBUG - 2022-08-11 11:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:35:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:05:06 --> Total execution time: 0.0798
DEBUG - 2022-08-11 11:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:31 --> Total execution time: 0.0796
DEBUG - 2022-08-11 11:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:35 --> Total execution time: 0.0707
DEBUG - 2022-08-11 11:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:35:35 --> Total execution time: 0.0932
DEBUG - 2022-08-11 11:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:23 --> Total execution time: 0.0827
DEBUG - 2022-08-11 11:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:25 --> Total execution time: 0.1087
DEBUG - 2022-08-11 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:26 --> Total execution time: 0.1913
DEBUG - 2022-08-11 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:06:30 --> Total execution time: 1.6752
DEBUG - 2022-08-11 11:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:06:33 --> Total execution time: 0.0987
DEBUG - 2022-08-11 11:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:06:42 --> Total execution time: 0.0776
DEBUG - 2022-08-11 11:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 11:36:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:01 --> Total execution time: 0.0969
DEBUG - 2022-08-11 11:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:02 --> Total execution time: 0.2009
DEBUG - 2022-08-11 11:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:03 --> Total execution time: 0.2176
DEBUG - 2022-08-11 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:05 --> Total execution time: 0.0846
DEBUG - 2022-08-11 11:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:30 --> Total execution time: 0.0822
DEBUG - 2022-08-11 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:31 --> Total execution time: 0.0914
DEBUG - 2022-08-11 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:40 --> Total execution time: 0.1141
DEBUG - 2022-08-11 11:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:07:54 --> Total execution time: 0.0882
DEBUG - 2022-08-11 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:08:06 --> Total execution time: 0.0963
DEBUG - 2022-08-11 11:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:08:17 --> Total execution time: 0.0894
DEBUG - 2022-08-11 11:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:38:34 --> Total execution time: 0.0781
DEBUG - 2022-08-11 11:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:08:35 --> Total execution time: 0.0920
DEBUG - 2022-08-11 11:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:08:48 --> Total execution time: 0.1070
DEBUG - 2022-08-11 11:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:38:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:08:51 --> Total execution time: 0.0861
DEBUG - 2022-08-11 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:09:03 --> Total execution time: 1.5710
DEBUG - 2022-08-11 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:09:50 --> Total execution time: 0.0815
DEBUG - 2022-08-11 11:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:09:52 --> Total execution time: 0.2538
DEBUG - 2022-08-11 11:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:00 --> Total execution time: 0.0859
DEBUG - 2022-08-11 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:07 --> Total execution time: 0.0841
DEBUG - 2022-08-11 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:13 --> Total execution time: 0.0756
DEBUG - 2022-08-11 11:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:21 --> Total execution time: 0.0784
DEBUG - 2022-08-11 11:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:28 --> Total execution time: 0.1018
DEBUG - 2022-08-11 11:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:11:05 --> Total execution time: 0.0757
DEBUG - 2022-08-11 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:11:06 --> Total execution time: 0.0743
DEBUG - 2022-08-11 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:12:05 --> Total execution time: 0.0790
DEBUG - 2022-08-11 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:12:10 --> Total execution time: 0.0782
DEBUG - 2022-08-11 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:43:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:13:07 --> Total execution time: 0.0535
DEBUG - 2022-08-11 11:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:45:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:15:26 --> Total execution time: 0.1399
DEBUG - 2022-08-11 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:15:52 --> Total execution time: 0.0575
DEBUG - 2022-08-11 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:46:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:00 --> Total execution time: 0.0507
DEBUG - 2022-08-11 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:46:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:01 --> Total execution time: 0.0827
DEBUG - 2022-08-11 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:24 --> Total execution time: 0.0917
DEBUG - 2022-08-11 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:47 --> Total execution time: 0.1453
DEBUG - 2022-08-11 11:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:01 --> Total execution time: 0.2128
DEBUG - 2022-08-11 11:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:06 --> Total execution time: 0.1150
DEBUG - 2022-08-11 11:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:28 --> Total execution time: 0.0877
DEBUG - 2022-08-11 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:45 --> Total execution time: 0.1282
DEBUG - 2022-08-11 11:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:56 --> Total execution time: 0.0872
DEBUG - 2022-08-11 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:31 --> Total execution time: 0.0879
DEBUG - 2022-08-11 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:39 --> Total execution time: 0.1056
DEBUG - 2022-08-11 11:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 11:48:39 --> 404 Page Not Found: User/log%20in
DEBUG - 2022-08-11 11:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 11:48:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:49 --> Total execution time: 0.1140
DEBUG - 2022-08-11 11:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:53 --> Total execution time: 0.0806
DEBUG - 2022-08-11 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:00 --> Total execution time: 0.0783
DEBUG - 2022-08-11 11:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:04 --> Total execution time: 0.0873
DEBUG - 2022-08-11 11:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:08 --> Total execution time: 0.0749
DEBUG - 2022-08-11 11:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:09 --> Total execution time: 0.0818
DEBUG - 2022-08-11 11:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:41 --> Total execution time: 0.0909
DEBUG - 2022-08-11 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:56 --> Total execution time: 0.0901
DEBUG - 2022-08-11 11:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:20:06 --> Total execution time: 0.0911
DEBUG - 2022-08-11 11:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:20:13 --> Total execution time: 0.0831
DEBUG - 2022-08-11 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:52:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:22:29 --> Total execution time: 0.0492
DEBUG - 2022-08-11 11:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:52:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:22:53 --> Total execution time: 0.0877
DEBUG - 2022-08-11 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:52:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:22:55 --> Total execution time: 0.0653
DEBUG - 2022-08-11 11:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:22:57 --> Total execution time: 0.2006
DEBUG - 2022-08-11 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:04 --> Total execution time: 0.0772
DEBUG - 2022-08-11 11:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:16 --> Total execution time: 0.0784
DEBUG - 2022-08-11 11:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:23 --> Total execution time: 0.1054
DEBUG - 2022-08-11 11:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:28 --> Total execution time: 0.0563
DEBUG - 2022-08-11 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:37 --> Total execution time: 0.0792
DEBUG - 2022-08-11 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:41 --> Total execution time: 0.1143
DEBUG - 2022-08-11 11:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:47 --> Total execution time: 0.1092
DEBUG - 2022-08-11 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:55 --> Total execution time: 0.1138
DEBUG - 2022-08-11 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:56 --> Total execution time: 0.0853
DEBUG - 2022-08-11 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:56 --> Total execution time: 0.0982
DEBUG - 2022-08-11 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:23:56 --> Total execution time: 0.0826
DEBUG - 2022-08-11 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:54:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:24:47 --> Total execution time: 0.0549
DEBUG - 2022-08-11 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:24:51 --> Total execution time: 0.0505
DEBUG - 2022-08-11 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:24:55 --> Total execution time: 0.1926
DEBUG - 2022-08-11 11:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 11:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:02 --> Total execution time: 0.0517
DEBUG - 2022-08-11 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:07 --> Total execution time: 0.0758
DEBUG - 2022-08-11 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:08 --> Total execution time: 0.0845
DEBUG - 2022-08-11 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:16 --> Total execution time: 0.0867
DEBUG - 2022-08-11 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:41 --> Total execution time: 0.0811
DEBUG - 2022-08-11 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:47 --> Total execution time: 0.0804
DEBUG - 2022-08-11 11:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:25:51 --> Total execution time: 0.0774
DEBUG - 2022-08-11 11:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:02 --> Total execution time: 0.0919
DEBUG - 2022-08-11 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:20 --> Total execution time: 0.1158
DEBUG - 2022-08-11 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:35 --> Total execution time: 0.0862
DEBUG - 2022-08-11 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:27:10 --> Total execution time: 0.0814
DEBUG - 2022-08-11 11:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:58:07 --> Total execution time: 0.0802
DEBUG - 2022-08-11 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 11:58:17 --> Total execution time: 0.0994
DEBUG - 2022-08-11 11:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:29:23 --> Total execution time: 0.1110
DEBUG - 2022-08-11 11:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 11:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 11:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:29:56 --> Total execution time: 0.2544
DEBUG - 2022-08-11 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:30:02 --> Total execution time: 0.0690
DEBUG - 2022-08-11 12:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:00:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:30:40 --> Total execution time: 0.0547
DEBUG - 2022-08-11 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:01:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:31:00 --> Total execution time: 0.0530
DEBUG - 2022-08-11 12:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:32:23 --> Total execution time: 0.1124
DEBUG - 2022-08-11 12:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:32:46 --> Total execution time: 0.0489
DEBUG - 2022-08-11 12:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:33:01 --> Total execution time: 0.1016
DEBUG - 2022-08-11 12:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:03:03 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:33:03 --> Total execution time: 0.0860
DEBUG - 2022-08-11 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:03:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:33:04 --> Total execution time: 0.0904
DEBUG - 2022-08-11 12:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:03:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:33:34 --> Total execution time: 0.0880
DEBUG - 2022-08-11 12:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:34:46 --> Total execution time: 0.1119
DEBUG - 2022-08-11 12:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:35:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-11 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:35:05 --> Total execution time: 0.1374
DEBUG - 2022-08-11 12:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:35:20 --> Total execution time: 0.0835
DEBUG - 2022-08-11 12:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:35:39 --> Total execution time: 0.1063
DEBUG - 2022-08-11 12:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:35:43 --> Total execution time: 0.0800
DEBUG - 2022-08-11 12:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:36:35 --> Total execution time: 0.1143
DEBUG - 2022-08-11 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:41:54 --> Total execution time: 0.0800
DEBUG - 2022-08-11 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:03 --> Total execution time: 0.0810
DEBUG - 2022-08-11 12:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:50:41 --> Total execution time: 0.0896
DEBUG - 2022-08-11 12:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:36 --> Total execution time: 0.1943
DEBUG - 2022-08-11 12:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:50 --> Total execution time: 0.1406
DEBUG - 2022-08-11 12:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:55 --> Total execution time: 0.1160
DEBUG - 2022-08-11 12:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:23:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:53 --> Total execution time: 0.0678
DEBUG - 2022-08-11 12:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:24:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:09 --> Total execution time: 0.1966
DEBUG - 2022-08-11 12:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:24:11 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:11 --> Total execution time: 0.0746
DEBUG - 2022-08-11 12:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:14 --> Total execution time: 0.0722
DEBUG - 2022-08-11 12:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:25:34 --> Total execution time: 0.0818
DEBUG - 2022-08-11 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:25:37 --> Total execution time: 0.0802
DEBUG - 2022-08-11 12:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:25:37 --> Total execution time: 0.0901
DEBUG - 2022-08-11 12:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:25:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:55:39 --> Total execution time: 0.0646
DEBUG - 2022-08-11 12:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:25:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:25:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 12:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:46 --> Total execution time: 1.9608
DEBUG - 2022-08-11 12:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:28:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:58:02 --> Total execution time: 0.0772
DEBUG - 2022-08-11 12:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:28:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 12:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:58:50 --> Total execution time: 0.0804
DEBUG - 2022-08-11 12:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:58:52 --> Total execution time: 0.2541
DEBUG - 2022-08-11 12:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:59:13 --> Total execution time: 0.2066
DEBUG - 2022-08-11 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:59:21 --> Total execution time: 0.0808
DEBUG - 2022-08-11 12:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:59:29 --> Total execution time: 0.0942
DEBUG - 2022-08-11 12:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:59:36 --> Total execution time: 0.1406
DEBUG - 2022-08-11 12:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:59:39 --> Total execution time: 0.0744
DEBUG - 2022-08-11 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:02 --> Total execution time: 1.6405
DEBUG - 2022-08-11 23:00:03 --> Total execution time: 1.5646
DEBUG - 2022-08-11 12:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:10 --> Total execution time: 0.0973
DEBUG - 2022-08-11 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:14 --> Total execution time: 0.0764
DEBUG - 2022-08-11 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:19 --> Total execution time: 0.0779
DEBUG - 2022-08-11 12:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:37 --> Total execution time: 0.0694
DEBUG - 2022-08-11 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:00 --> Total execution time: 0.2540
DEBUG - 2022-08-11 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:00 --> Total execution time: 0.2277
DEBUG - 2022-08-11 12:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:01 --> Total execution time: 0.1041
DEBUG - 2022-08-11 12:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:07 --> Total execution time: 0.1564
DEBUG - 2022-08-11 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:24 --> Total execution time: 0.0753
DEBUG - 2022-08-11 12:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:01:36 --> Total execution time: 0.1115
DEBUG - 2022-08-11 12:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:06:21 --> Total execution time: 0.2610
DEBUG - 2022-08-11 12:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:07:04 --> Total execution time: 0.1942
DEBUG - 2022-08-11 12:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:07:09 --> Total execution time: 0.0741
DEBUG - 2022-08-11 12:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:19 --> Total execution time: 0.0771
DEBUG - 2022-08-11 12:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:20 --> Total execution time: 0.0770
DEBUG - 2022-08-11 12:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:27 --> Total execution time: 0.0797
DEBUG - 2022-08-11 12:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:34 --> Total execution time: 0.1042
DEBUG - 2022-08-11 12:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:42 --> Total execution time: 0.1059
DEBUG - 2022-08-11 12:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:08:54 --> Total execution time: 0.0994
DEBUG - 2022-08-11 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:09:01 --> Total execution time: 0.1127
DEBUG - 2022-08-11 12:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:40:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:10:29 --> Total execution time: 0.0591
DEBUG - 2022-08-11 12:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:40:53 --> Total execution time: 0.0827
DEBUG - 2022-08-11 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:40:55 --> Total execution time: 0.0830
DEBUG - 2022-08-11 12:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:40:56 --> Total execution time: 0.0791
DEBUG - 2022-08-11 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:43:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:13:13 --> Total execution time: 0.1133
DEBUG - 2022-08-11 12:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:22 --> Total execution time: 0.0850
DEBUG - 2022-08-11 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:24 --> Total execution time: 0.0765
DEBUG - 2022-08-11 12:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:43:24 --> Total execution time: 0.2223
DEBUG - 2022-08-11 12:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:24 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:16:24 --> Total execution time: 0.1114
DEBUG - 2022-08-11 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:16:30 --> Total execution time: 2.1191
DEBUG - 2022-08-11 12:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:46:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 12:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:16:36 --> Total execution time: 0.0517
DEBUG - 2022-08-11 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:16:44 --> Total execution time: 0.1315
DEBUG - 2022-08-11 12:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:16:56 --> Total execution time: 0.0849
DEBUG - 2022-08-11 12:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:17:02 --> Total execution time: 0.0954
DEBUG - 2022-08-11 12:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:17:40 --> Total execution time: 0.0740
DEBUG - 2022-08-11 12:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:17:43 --> Total execution time: 0.2637
DEBUG - 2022-08-11 12:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:17:51 --> Total execution time: 0.0773
DEBUG - 2022-08-11 12:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:17:56 --> Total execution time: 0.0856
DEBUG - 2022-08-11 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:50:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:20:55 --> Total execution time: 0.1368
DEBUG - 2022-08-11 12:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:51:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:21:18 --> Total execution time: 0.0560
DEBUG - 2022-08-11 12:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:29 --> Total execution time: 0.0877
DEBUG - 2022-08-11 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:31 --> Total execution time: 0.0757
DEBUG - 2022-08-11 12:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:51:31 --> Total execution time: 0.0793
DEBUG - 2022-08-11 12:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:12 --> Total execution time: 1.6991
DEBUG - 2022-08-11 12:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:53:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 12:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:41 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:41 --> Total execution time: 0.0780
DEBUG - 2022-08-11 12:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:49 --> Total execution time: 0.1044
DEBUG - 2022-08-11 12:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:50 --> Total execution time: 0.0748
DEBUG - 2022-08-11 12:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:53:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:54 --> Total execution time: 0.0524
DEBUG - 2022-08-11 12:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:54:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:24:22 --> Total execution time: 0.0889
DEBUG - 2022-08-11 12:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:54:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:24:28 --> Total execution time: 0.0502
DEBUG - 2022-08-11 12:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:04 --> Total execution time: 0.0905
DEBUG - 2022-08-11 12:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:14 --> Total execution time: 0.1165
DEBUG - 2022-08-11 12:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:25 --> Total execution time: 0.1146
DEBUG - 2022-08-11 12:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:36 --> Total execution time: 0.0925
DEBUG - 2022-08-11 12:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:26:01 --> Total execution time: 0.1044
DEBUG - 2022-08-11 12:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:26:10 --> Total execution time: 0.1477
DEBUG - 2022-08-11 12:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:26:46 --> Total execution time: 0.0852
DEBUG - 2022-08-11 12:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 12:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:02 --> Total execution time: 0.0757
DEBUG - 2022-08-11 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:06 --> Total execution time: 0.0832
DEBUG - 2022-08-11 12:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:27 --> Total execution time: 0.0560
DEBUG - 2022-08-11 12:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:39 --> Total execution time: 0.0836
DEBUG - 2022-08-11 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:57:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 12:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:58:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 12:58:03 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-11 12:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:58:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:28:52 --> Total execution time: 0.0534
DEBUG - 2022-08-11 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:59:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 12:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:13 --> Total execution time: 0.0600
DEBUG - 2022-08-11 12:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 12:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 12:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:20 --> Total execution time: 0.0887
DEBUG - 2022-08-11 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:30:03 --> Total execution time: 0.0987
DEBUG - 2022-08-11 13:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:00:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:30:19 --> Total execution time: 0.2067
DEBUG - 2022-08-11 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:30:53 --> Total execution time: 0.0877
DEBUG - 2022-08-11 13:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:30:59 --> Total execution time: 0.0790
DEBUG - 2022-08-11 13:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:31:13 --> Total execution time: 0.0894
DEBUG - 2022-08-11 13:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:31:20 --> Total execution time: 0.0892
DEBUG - 2022-08-11 13:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:31:28 --> Total execution time: 0.0878
DEBUG - 2022-08-11 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:31:45 --> Total execution time: 0.0787
DEBUG - 2022-08-11 13:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:32:00 --> Total execution time: 0.0898
DEBUG - 2022-08-11 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:32:50 --> Total execution time: 0.0769
DEBUG - 2022-08-11 13:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:14 --> Total execution time: 0.0792
DEBUG - 2022-08-11 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:16 --> Total execution time: 0.1034
DEBUG - 2022-08-11 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:03:16 --> Total execution time: 0.0934
DEBUG - 2022-08-11 13:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:33:27 --> Total execution time: 0.0740
DEBUG - 2022-08-11 13:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:05:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:35:14 --> Total execution time: 0.0509
DEBUG - 2022-08-11 13:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:05:39 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:35:39 --> Total execution time: 0.1973
DEBUG - 2022-08-11 13:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:35:43 --> Total execution time: 0.0710
DEBUG - 2022-08-11 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:06:13 --> Total execution time: 0.0520
DEBUG - 2022-08-11 13:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:06:15 --> Total execution time: 0.0815
DEBUG - 2022-08-11 13:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:06:16 --> Total execution time: 0.0756
DEBUG - 2022-08-11 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:06:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:36:19 --> Total execution time: 0.0833
DEBUG - 2022-08-11 13:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:37:16 --> Total execution time: 0.0847
DEBUG - 2022-08-11 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:37:33 --> Total execution time: 0.0829
DEBUG - 2022-08-11 13:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:37:42 --> Total execution time: 0.0889
DEBUG - 2022-08-11 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:39 --> Total execution time: 0.0771
DEBUG - 2022-08-11 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:49 --> Total execution time: 0.0904
DEBUG - 2022-08-11 13:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:53 --> Total execution time: 0.0874
DEBUG - 2022-08-11 13:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:57 --> Total execution time: 0.1389
DEBUG - 2022-08-11 13:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:39:24 --> Total execution time: 0.1049
DEBUG - 2022-08-11 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:39:32 --> Total execution time: 0.0979
DEBUG - 2022-08-11 13:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:10:35 --> Total execution time: 0.0835
DEBUG - 2022-08-11 13:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:11:08 --> Total execution time: 0.1374
DEBUG - 2022-08-11 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:15:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:45:26 --> Total execution time: 0.3017
DEBUG - 2022-08-11 13:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:46:19 --> Total execution time: 0.0780
DEBUG - 2022-08-11 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:46:40 --> Total execution time: 0.2455
DEBUG - 2022-08-11 13:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:46:44 --> Total execution time: 0.1036
DEBUG - 2022-08-11 13:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:46:50 --> Total execution time: 0.0812
DEBUG - 2022-08-11 13:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:47:07 --> Total execution time: 0.0835
DEBUG - 2022-08-11 13:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:47:20 --> Total execution time: 0.0806
DEBUG - 2022-08-11 13:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:47:27 --> Total execution time: 0.0880
DEBUG - 2022-08-11 13:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:47:57 --> Total execution time: 0.0821
DEBUG - 2022-08-11 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:48:01 --> Total execution time: 0.1117
DEBUG - 2022-08-11 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:48:05 --> Total execution time: 0.0816
DEBUG - 2022-08-11 13:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:48:21 --> Total execution time: 0.0790
DEBUG - 2022-08-11 13:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:59:22 --> Total execution time: 0.1523
DEBUG - 2022-08-11 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 13:33:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 13:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 13:33:31 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-11 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:43:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:43:43 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:46:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:46:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 13:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 13:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 14:48:22 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 14:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:48:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 14:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:52:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 14:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 14:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 14:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 14:56:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 14:56:40 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-08-11 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:13:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 15:13:01 --> 404 Page Not Found: Events/page
DEBUG - 2022-08-11 15:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:21:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 15:21:48 --> 404 Page Not Found: Teacher/harry-j-bryant
DEBUG - 2022-08-11 15:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:37:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 15:37:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 15:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:37:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 15:37:46 --> 404 Page Not Found: Lessons/dow-theory-how-to-work-with-dow-theory
DEBUG - 2022-08-11 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:39:40 --> No URI present. Default controller set.
DEBUG - 2022-08-11 15:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 15:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 15:43:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 15:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 15:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 16:17:37 --> 404 Page Not Found: Events/page
DEBUG - 2022-08-11 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:24:53 --> No URI present. Default controller set.
DEBUG - 2022-08-11 16:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:31 --> Total execution time: 0.0827
DEBUG - 2022-08-11 16:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:33 --> Total execution time: 0.1326
DEBUG - 2022-08-11 16:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:25:33 --> Total execution time: 0.0801
DEBUG - 2022-08-11 16:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:27:37 --> Total execution time: 0.0781
DEBUG - 2022-08-11 16:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:27:39 --> Total execution time: 0.0983
DEBUG - 2022-08-11 16:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:27:39 --> Total execution time: 0.0780
DEBUG - 2022-08-11 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:32 --> Total execution time: 0.0812
DEBUG - 2022-08-11 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:33 --> Total execution time: 0.0832
DEBUG - 2022-08-11 16:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:34 --> Total execution time: 0.1906
DEBUG - 2022-08-11 16:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:46 --> Total execution time: 0.0791
DEBUG - 2022-08-11 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:48 --> Total execution time: 0.0832
DEBUG - 2022-08-11 16:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:48 --> Total execution time: 0.0865
DEBUG - 2022-08-11 16:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:53 --> Total execution time: 0.0975
DEBUG - 2022-08-11 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:55 --> Total execution time: 0.0778
DEBUG - 2022-08-11 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:30:56 --> Total execution time: 0.0818
DEBUG - 2022-08-11 16:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:31:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 16:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:50:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 16:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 16:55:07 --> 404 Page Not Found: Event/boston-speakers-series-james-comey
DEBUG - 2022-08-11 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 16:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 16:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:17:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 17:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 17:18:22 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-08-11 17:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 17:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 17:36:55 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 17:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 17:52:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 17:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 17:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 18:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 18:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 18:45:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 18:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 18:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 18:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 18:46:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 18:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 18:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:06:14 --> No URI present. Default controller set.
DEBUG - 2022-08-11 19:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:16:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 19:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:16:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 19:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:35:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 19:35:13 --> 404 Page Not Found: Lessons/affiliate-marketing-introduction
DEBUG - 2022-08-11 19:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:39:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 19:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 19:40:01 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-11 19:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 19:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 19:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 19:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:20:59 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:21:05 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:24:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:29:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:25 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 20:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:29 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:32 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:40 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:41 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:43 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:36:45 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-08-11 20:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:43:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:44:23 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:44:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 20:44:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 20:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:45:01 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:45:47 --> No URI present. Default controller set.
DEBUG - 2022-08-11 20:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 20:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 20:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 20:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:03:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:07:48 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:17:49 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:19:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:19:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:19:22 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:22:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:26 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:30:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 21:30:25 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-08-11 21:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:38:51 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:42:30 --> No URI present. Default controller set.
DEBUG - 2022-08-11 21:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 21:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 21:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 21:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:12:13 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:12:58 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:16:41 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:16:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:16:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:19:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:26:33 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:26:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:34:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:27 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:08 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:29 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:35 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:39:57 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:42 --> Total execution time: 0.0836
DEBUG - 2022-08-11 22:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:42:51 --> Total execution time: 0.1077
DEBUG - 2022-08-11 22:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:44:12 --> Total execution time: 0.1958
DEBUG - 2022-08-11 22:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:44:44 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:47:37 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:02 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:07 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:09 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:18 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:19 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:20 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:49 --> Total execution time: 0.0860
DEBUG - 2022-08-11 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 22:52:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-11 22:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:53 --> Total execution time: 0.0934
DEBUG - 2022-08-11 22:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:52:54 --> Total execution time: 0.0969
DEBUG - 2022-08-11 22:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:00 --> No URI present. Default controller set.
DEBUG - 2022-08-11 22:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 22:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 22:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:04:42 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 23:09:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-11 23:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:21:52 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:10 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:17 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:29:06 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:36:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:36:46 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-11 23:38:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-11 23:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:41:31 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:49:38 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:52:34 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:53:37 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:56:16 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:56:25 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:57:04 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:57:54 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:57:55 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-11 23:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-11 23:58:28 --> No URI present. Default controller set.
DEBUG - 2022-08-11 23:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-11 23:58:28 --> Encryption: Auto-configured driver 'openssl'.
