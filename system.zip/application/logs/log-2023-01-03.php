<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-03 00:00:01 --> Total execution time: 0.0711
DEBUG - 2023-01-03 00:00:05 --> Total execution time: 0.0651
DEBUG - 2023-01-03 00:00:09 --> Total execution time: 0.0550
DEBUG - 2023-01-03 00:05:21 --> Total execution time: 0.0609
DEBUG - 2023-01-03 00:05:27 --> Total execution time: 0.0818
DEBUG - 2023-01-03 00:15:12 --> Total execution time: 0.0993
DEBUG - 2023-01-03 00:16:28 --> Total execution time: 0.0672
DEBUG - 2023-01-03 00:16:37 --> Total execution time: 0.0844
DEBUG - 2023-01-03 00:16:42 --> Total execution time: 0.0973
DEBUG - 2023-01-03 00:17:05 --> Total execution time: 0.0778
DEBUG - 2023-01-03 00:18:06 --> Total execution time: 0.0620
DEBUG - 2023-01-03 00:18:44 --> Total execution time: 0.1009
DEBUG - 2023-01-03 00:19:50 --> Total execution time: 0.0670
DEBUG - 2023-01-03 00:19:58 --> Total execution time: 0.0580
DEBUG - 2023-01-03 00:21:22 --> Total execution time: 0.0825
DEBUG - 2023-01-03 00:21:38 --> Total execution time: 0.0655
DEBUG - 2023-01-03 00:21:53 --> Total execution time: 0.0705
DEBUG - 2023-01-03 00:33:03 --> Total execution time: 0.0817
DEBUG - 2023-01-03 00:34:00 --> Total execution time: 0.0719
DEBUG - 2023-01-03 00:34:19 --> Total execution time: 0.0574
DEBUG - 2023-01-03 00:34:59 --> Total execution time: 0.0651
DEBUG - 2023-01-03 00:35:15 --> Upload class already loaded. Second attempt ignored.
ERROR - 2023-01-03 00:35:15 --> Severity: Notice --> Undefined property: Dynamic_Page_Controller::$Home_page_banner C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\settings\Dynamic_Page_Controller.php 36
ERROR - 2023-01-03 00:35:15 --> Severity: error --> Exception: Call to a member function insert() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\settings\Dynamic_Page_Controller.php 36
DEBUG - 2023-01-03 00:35:49 --> Total execution time: 0.0575
DEBUG - 2023-01-03 00:36:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 00:36:00 --> Total execution time: 0.0796
DEBUG - 2023-01-03 00:44:42 --> Total execution time: 0.0834
DEBUG - 2023-01-03 01:21:37 --> Total execution time: 0.1399
DEBUG - 2023-01-03 01:22:17 --> Total execution time: 0.0700
DEBUG - 2023-01-03 01:22:43 --> Total execution time: 0.0792
DEBUG - 2023-01-03 01:23:08 --> Total execution time: 0.0675
DEBUG - 2023-01-03 01:23:17 --> Total execution time: 0.0924
DEBUG - 2023-01-03 01:25:05 --> Total execution time: 0.0804
DEBUG - 2023-01-03 01:25:24 --> Total execution time: 0.0768
DEBUG - 2023-01-03 01:25:32 --> Total execution time: 0.0710
DEBUG - 2023-01-03 01:25:48 --> Total execution time: 0.0694
DEBUG - 2023-01-03 01:35:09 --> Total execution time: 0.0685
DEBUG - 2023-01-03 01:35:12 --> Total execution time: 0.0660
DEBUG - 2023-01-03 01:35:24 --> Total execution time: 0.0709
DEBUG - 2023-01-03 01:36:13 --> Total execution time: 0.0757
DEBUG - 2023-01-03 01:36:16 --> Total execution time: 0.0721
DEBUG - 2023-01-03 01:36:32 --> Total execution time: 0.0681
DEBUG - 2023-01-03 01:36:35 --> Total execution time: 0.0959
DEBUG - 2023-01-03 01:36:38 --> Total execution time: 0.1120
DEBUG - 2023-01-03 01:36:43 --> Total execution time: 0.0737
DEBUG - 2023-01-03 01:36:50 --> Total execution time: 0.0878
DEBUG - 2023-01-03 01:37:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 01:37:06 --> Total execution time: 0.0584
DEBUG - 2023-01-03 01:38:25 --> Total execution time: 0.0747
DEBUG - 2023-01-03 01:56:44 --> Total execution time: 0.0823
DEBUG - 2023-01-03 01:57:14 --> Total execution time: 0.0994
DEBUG - 2023-01-03 01:57:16 --> Total execution time: 0.0573
DEBUG - 2023-01-03 01:57:41 --> Total execution time: 0.0623
DEBUG - 2023-01-03 01:57:45 --> Total execution time: 0.0574
DEBUG - 2023-01-03 01:59:44 --> Total execution time: 0.0639
DEBUG - 2023-01-03 01:59:46 --> Total execution time: 0.1022
DEBUG - 2023-01-03 02:08:30 --> Total execution time: 0.0759
DEBUG - 2023-01-03 02:08:31 --> Total execution time: 0.0780
ERROR - 2023-01-03 02:08:41 --> Severity: Notice --> Undefined variable: hb_id C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\settings\Dynamic_Page_Controller.php 66
DEBUG - 2023-01-03 02:08:41 --> Total execution time: 0.0633
DEBUG - 2023-01-03 02:09:06 --> Total execution time: 0.0573
DEBUG - 2023-01-03 02:09:26 --> Total execution time: 0.0669
DEBUG - 2023-01-03 02:09:27 --> Total execution time: 0.1058
ERROR - 2023-01-03 02:09:32 --> Severity: Notice --> Undefined variable: hb_id C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\settings\Dynamic_Page_Controller.php 66
DEBUG - 2023-01-03 02:09:32 --> Total execution time: 0.0611
DEBUG - 2023-01-03 02:10:13 --> Total execution time: 0.0630
DEBUG - 2023-01-03 02:10:16 --> Total execution time: 0.0573
ERROR - 2023-01-03 02:10:21 --> Severity: Notice --> Undefined variable: hb_id C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\settings\Dynamic_Page_Controller.php 66
DEBUG - 2023-01-03 02:10:39 --> Total execution time: 0.0640
DEBUG - 2023-01-03 02:10:41 --> Total execution time: 0.0732
DEBUG - 2023-01-03 02:10:43 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 02:10:43 --> Total execution time: 0.0584
DEBUG - 2023-01-03 02:10:45 --> Total execution time: 0.0628
DEBUG - 2023-01-03 02:10:50 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 02:10:50 --> Total execution time: 0.0618
DEBUG - 2023-01-03 02:11:46 --> Total execution time: 0.0916
DEBUG - 2023-01-03 02:11:48 --> Total execution time: 0.0579
DEBUG - 2023-01-03 02:11:56 --> Total execution time: 0.0846
DEBUG - 2023-01-03 02:11:57 --> Total execution time: 0.0627
DEBUG - 2023-01-03 02:12:02 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 02:12:02 --> Total execution time: 0.0627
DEBUG - 2023-01-03 03:01:20 --> Total execution time: 0.0599
DEBUG - 2023-01-03 03:02:03 --> Total execution time: 0.1116
DEBUG - 2023-01-03 03:03:52 --> Total execution time: 0.0872
DEBUG - 2023-01-03 03:09:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 03:09:12 --> Total execution time: 0.0639
DEBUG - 2023-01-03 03:09:21 --> Total execution time: 0.0590
DEBUG - 2023-01-03 03:09:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 03:09:39 --> Total execution time: 0.0634
DEBUG - 2023-01-03 03:09:41 --> Total execution time: 0.0612
DEBUG - 2023-01-03 03:09:53 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 03:09:54 --> Total execution time: 0.0644
DEBUG - 2023-01-03 03:17:52 --> Total execution time: 0.0860
DEBUG - 2023-01-03 03:18:02 --> Total execution time: 0.0813
DEBUG - 2023-01-03 03:18:13 --> Total execution time: 0.0642
DEBUG - 2023-01-03 03:25:01 --> Total execution time: 0.0860
DEBUG - 2023-01-03 03:27:28 --> Total execution time: 0.0849
DEBUG - 2023-01-03 03:28:46 --> Total execution time: 0.0657
DEBUG - 2023-01-03 03:31:27 --> Total execution time: 0.0932
DEBUG - 2023-01-03 03:33:21 --> Total execution time: 0.0831
DEBUG - 2023-01-03 03:33:33 --> Total execution time: 0.1031
DEBUG - 2023-01-03 03:36:11 --> Total execution time: 0.0926
DEBUG - 2023-01-03 03:36:19 --> Total execution time: 0.0767
DEBUG - 2023-01-03 03:36:28 --> Total execution time: 0.0867
DEBUG - 2023-01-03 03:36:36 --> Total execution time: 0.0826
DEBUG - 2023-01-03 03:36:45 --> Total execution time: 0.0798
DEBUG - 2023-01-03 03:37:10 --> Total execution time: 0.0710
DEBUG - 2023-01-03 03:39:29 --> Total execution time: 0.0819
DEBUG - 2023-01-03 03:39:32 --> Total execution time: 0.0655
DEBUG - 2023-01-03 03:46:36 --> Total execution time: 0.0949
DEBUG - 2023-01-03 03:47:11 --> Total execution time: 0.0817
DEBUG - 2023-01-03 03:47:21 --> Total execution time: 0.0795
DEBUG - 2023-01-03 03:47:28 --> Total execution time: 0.0644
DEBUG - 2023-01-03 03:48:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 03:48:35 --> Total execution time: 0.0621
DEBUG - 2023-01-03 03:49:11 --> Total execution time: 0.0676
DEBUG - 2023-01-03 03:49:43 --> Total execution time: 0.0676
DEBUG - 2023-01-03 03:52:26 --> Total execution time: 0.0801
ERROR - 2023-01-03 03:54:57 --> Severity: error --> Exception: syntax error, unexpected '<' C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\testimonial\testimonial_page.php 50
DEBUG - 2023-01-03 03:55:10 --> Total execution time: 0.0673
DEBUG - 2023-01-03 03:55:26 --> Total execution time: 0.0782
DEBUG - 2023-01-03 03:56:31 --> Total execution time: 0.0701
DEBUG - 2023-01-03 04:06:33 --> Total execution time: 0.0755
DEBUG - 2023-01-03 04:06:34 --> Total execution time: 0.0822
DEBUG - 2023-01-03 04:06:49 --> Total execution time: 0.0714
DEBUG - 2023-01-03 04:06:50 --> Total execution time: 0.0603
DEBUG - 2023-01-03 04:07:09 --> Total execution time: 0.0647
DEBUG - 2023-01-03 04:07:11 --> Total execution time: 0.0693
DEBUG - 2023-01-03 04:10:47 --> Total execution time: 0.0831
DEBUG - 2023-01-03 04:11:43 --> Total execution time: 0.0690
DEBUG - 2023-01-03 04:12:17 --> Total execution time: 0.0749
DEBUG - 2023-01-03 04:13:07 --> Total execution time: 0.0748
DEBUG - 2023-01-03 04:18:39 --> Total execution time: 0.0698
DEBUG - 2023-01-03 04:18:43 --> Total execution time: 0.1082
DEBUG - 2023-01-03 04:18:45 --> Total execution time: 0.0758
DEBUG - 2023-01-03 04:19:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 04:19:12 --> Total execution time: 0.0654
DEBUG - 2023-01-03 04:19:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 04:19:37 --> Total execution time: 0.0656
DEBUG - 2023-01-03 04:20:29 --> Total execution time: 0.0745
DEBUG - 2023-01-03 04:20:47 --> Total execution time: 0.0764
DEBUG - 2023-01-03 04:21:25 --> Total execution time: 0.0776
DEBUG - 2023-01-03 04:23:44 --> Total execution time: 0.0845
DEBUG - 2023-01-03 04:26:22 --> Total execution time: 0.0763
DEBUG - 2023-01-03 04:26:26 --> Total execution time: 0.0664
DEBUG - 2023-01-03 04:27:03 --> Total execution time: 0.0671
DEBUG - 2023-01-03 04:27:39 --> Total execution time: 0.0664
DEBUG - 2023-01-03 04:27:42 --> Total execution time: 0.0794
DEBUG - 2023-01-03 04:27:47 --> Total execution time: 0.0646
DEBUG - 2023-01-03 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:47:45 --> No URI present. Default controller set.
DEBUG - 2023-01-03 12:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:17:46 --> Total execution time: 0.8505
DEBUG - 2023-01-03 12:47:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:47:46 --> No URI present. Default controller set.
DEBUG - 2023-01-03 12:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:17:46 --> Total execution time: 0.0914
DEBUG - 2023-01-03 12:47:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:17:50 --> Total execution time: 0.1131
DEBUG - 2023-01-03 12:47:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:47:54 --> No URI present. Default controller set.
DEBUG - 2023-01-03 12:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:17:54 --> Total execution time: 0.0611
DEBUG - 2023-01-03 12:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:19:17 --> Total execution time: 0.1089
DEBUG - 2023-01-03 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 12:49:26 --> Total execution time: 0.1274
DEBUG - 2023-01-03 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 12:49:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:19:28 --> Total execution time: 0.0724
DEBUG - 2023-01-03 12:49:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 12:49:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:19:33 --> Total execution time: 0.1968
DEBUG - 2023-01-03 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 12:49:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 12:49:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:19:53 --> Total execution time: 0.0582
DEBUG - 2023-01-03 12:58:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 12:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 12:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 12:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:28:15 --> Total execution time: 0.0861
DEBUG - 2023-01-03 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:33:49 --> Total execution time: 0.0748
DEBUG - 2023-01-03 13:03:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:03:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:33:50 --> Total execution time: 0.0732
DEBUG - 2023-01-03 13:04:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:34:01 --> Total execution time: 0.0716
DEBUG - 2023-01-03 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:06 --> UTF-8 Support Enabled
ERROR - 2023-01-03 13:04:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:06 --> UTF-8 Support Enabled
ERROR - 2023-01-03 13:04:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:04:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:04:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:04:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:34:54 --> Total execution time: 0.0599
DEBUG - 2023-01-03 13:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 13:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:34:54 --> Total execution time: 0.0588
DEBUG - 2023-01-03 13:04:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:04:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:04:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:34:55 --> Total execution time: 0.0692
DEBUG - 2023-01-03 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:05:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:35:55 --> Total execution time: 0.0577
DEBUG - 2023-01-03 13:05:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:05:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:03 --> Total execution time: 0.0636
DEBUG - 2023-01-03 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:06:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:05 --> Total execution time: 0.0527
DEBUG - 2023-01-03 13:06:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 17:36:39 --> You did not select a file to upload.
DEBUG - 2023-01-03 13:06:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:40 --> Total execution time: 0.0556
DEBUG - 2023-01-03 13:06:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:06:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:43 --> Total execution time: 0.0523
DEBUG - 2023-01-03 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 17:36:48 --> You did not select a file to upload.
DEBUG - 2023-01-03 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:36:48 --> Total execution time: 0.0566
DEBUG - 2023-01-03 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:06:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:43 --> Total execution time: 0.0586
DEBUG - 2023-01-03 13:07:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:07:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:44 --> Total execution time: 0.0593
DEBUG - 2023-01-03 13:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 13:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:48 --> Total execution time: 0.0541
DEBUG - 2023-01-03 13:07:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:07:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:07:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:49 --> Total execution time: 0.0566
DEBUG - 2023-01-03 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-03 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:54 --> Total execution time: 0.0688
DEBUG - 2023-01-03 13:07:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:07:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:07:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:37:56 --> Total execution time: 0.0988
DEBUG - 2023-01-03 13:09:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:39:57 --> Total execution time: 0.0796
DEBUG - 2023-01-03 13:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:10:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:11:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:41:37 --> Total execution time: 0.0634
DEBUG - 2023-01-03 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:11:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:11:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:11:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:11:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:11:38 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:43:14 --> Total execution time: 0.0677
DEBUG - 2023-01-03 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:14 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:43:24 --> Total execution time: 0.0553
DEBUG - 2023-01-03 13:13:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:25 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:13:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:43:39 --> Total execution time: 0.1379
DEBUG - 2023-01-03 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:40 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:13:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:43:51 --> Total execution time: 0.0753
DEBUG - 2023-01-03 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:43:57 --> Total execution time: 0.0675
DEBUG - 2023-01-03 13:13:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:58 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:13:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:13:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:13:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:13:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:16:35 --> No URI present. Default controller set.
DEBUG - 2023-01-03 13:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:46:36 --> Total execution time: 0.1669
DEBUG - 2023-01-03 13:17:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:47:18 --> Total execution time: 0.0638
DEBUG - 2023-01-03 13:17:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:47:22 --> Total execution time: 0.0532
DEBUG - 2023-01-03 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:48:05 --> Total execution time: 0.0543
DEBUG - 2023-01-03 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:18:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:48:07 --> Total execution time: 0.0700
DEBUG - 2023-01-03 13:18:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:18:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:48:35 --> Total execution time: 0.0629
DEBUG - 2023-01-03 13:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:18:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:48:36 --> Total execution time: 0.0765
DEBUG - 2023-01-03 13:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:18:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:18:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:48:36 --> Total execution time: 0.0932
DEBUG - 2023-01-03 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:24 --> Total execution time: 0.0725
DEBUG - 2023-01-03 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:19:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:19:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:24 --> Total execution time: 0.1105
DEBUG - 2023-01-03 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:39 --> Total execution time: 0.0613
DEBUG - 2023-01-03 13:19:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:19:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:40 --> Total execution time: 0.0918
DEBUG - 2023-01-03 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:48 --> Total execution time: 0.0681
DEBUG - 2023-01-03 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:19:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:19:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:49:48 --> Total execution time: 0.0984
DEBUG - 2023-01-03 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:50:23 --> Total execution time: 0.0627
DEBUG - 2023-01-03 13:20:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:20:23 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-03 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:53:34 --> Total execution time: 0.0697
DEBUG - 2023-01-03 13:23:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:23:34 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-03 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:57:15 --> Total execution time: 0.0719
DEBUG - 2023-01-03 13:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:27:15 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-03 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:57:34 --> Total execution time: 0.0580
DEBUG - 2023-01-03 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:27:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:27:34 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-03 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:15 --> UTF-8 Support Enabled
ERROR - 2023-01-03 13:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:59:16 --> Total execution time: 0.0679
DEBUG - 2023-01-03 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:17 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-03 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:17 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:29:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:59:46 --> Total execution time: 0.0543
DEBUG - 2023-01-03 13:29:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:46 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:47 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:29:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:47 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 13:29:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:59:55 --> Total execution time: 0.0528
DEBUG - 2023-01-03 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:55 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:55 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:59:56 --> Total execution time: 0.0819
DEBUG - 2023-01-03 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:56 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:29:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:29:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:29:56 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:01:00 --> Total execution time: 0.0997
DEBUG - 2023-01-03 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:00 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:31:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:01:41 --> Total execution time: 0.0621
DEBUG - 2023-01-03 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:02:22 --> Total execution time: 0.0541
DEBUG - 2023-01-03 13:32:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:32:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:32:23 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-03 13:32:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:32:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:32:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:33:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:03:45 --> Total execution time: 0.0522
DEBUG - 2023-01-03 13:38:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:38:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:08:18 --> Total execution time: 0.0939
DEBUG - 2023-01-03 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:11:26 --> Unable to find validation rule: 
ERROR - 2023-01-03 18:11:26 --> Could not find the language line "form_validation_"
DEBUG - 2023-01-03 13:41:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:11:26 --> Total execution time: 0.0514
DEBUG - 2023-01-03 13:41:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:11:40 --> Total execution time: 0.0613
DEBUG - 2023-01-03 13:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 13:41:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:11:47 --> Total execution time: 0.0549
DEBUG - 2023-01-03 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:42:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:42:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:42:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:42:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:42:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-03 13:43:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:13:35 --> Total execution time: 0.0802
DEBUG - 2023-01-03 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:43:51 --> No URI present. Default controller set.
DEBUG - 2023-01-03 13:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:13:51 --> Total execution time: 0.1265
DEBUG - 2023-01-03 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:13:53 --> Total execution time: 0.0602
DEBUG - 2023-01-03 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:13:54 --> Total execution time: 0.0617
DEBUG - 2023-01-03 13:43:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:13:59 --> Total execution time: 0.0561
DEBUG - 2023-01-03 13:44:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:14:36 --> Total execution time: 0.0616
DEBUG - 2023-01-03 13:45:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:15:07 --> Total execution time: 0.0548
DEBUG - 2023-01-03 13:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:19:46 --> Total execution time: 0.0770
DEBUG - 2023-01-03 13:49:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:49:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:49:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:49:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:19:47 --> Total execution time: 0.1241
DEBUG - 2023-01-03 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:20:04 --> Total execution time: 0.0604
DEBUG - 2023-01-03 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:50:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:50:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:20:04 --> Total execution time: 0.0745
DEBUG - 2023-01-03 13:50:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:50:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 18:20:06 --> Severity: Notice --> Undefined property: DashboardController::$Contact_us C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\DashboardController.php 17
ERROR - 2023-01-03 18:20:06 --> Severity: error --> Exception: Call to a member function all() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\DashboardController.php 17
DEBUG - 2023-01-03 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:50:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_sl_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 56
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 57
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$cat_name C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 59
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_running C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 62
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_approve_status C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 65
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_status C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 69
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 69
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_slug C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 74
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_slug C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 75
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 76
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_campaign_from_date C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 80
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_campaign_to_date C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 89
ERROR - 2023-01-03 18:20:17 --> Severity: Notice --> Undefined property: stdClass::$p_created_by C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 97
DEBUG - 2023-01-03 18:20:17 --> Total execution time: 0.1101
DEBUG - 2023-01-03 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:50:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:56:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:56:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 18:26:12 --> Severity: Notice --> Undefined property: stdClass::$p_id C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\contact-list.php 55
DEBUG - 2023-01-03 18:26:12 --> Total execution time: 0.1023
DEBUG - 2023-01-03 13:56:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:56:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:26:31 --> Total execution time: 0.0593
DEBUG - 2023-01-03 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:56:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 13:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:26:53 --> Total execution time: 0.0720
DEBUG - 2023-01-03 13:56:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:56:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 13:56:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:30:39 --> Total execution time: 0.0660
DEBUG - 2023-01-03 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:00:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:30:41 --> Total execution time: 0.1019
DEBUG - 2023-01-03 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:30:42 --> Total execution time: 0.0572
DEBUG - 2023-01-03 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:00:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:31:00 --> Total execution time: 0.0738
DEBUG - 2023-01-03 14:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:01:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:01:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:01:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:31:01 --> Total execution time: 0.0887
DEBUG - 2023-01-03 14:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:31:07 --> Total execution time: 0.1020
DEBUG - 2023-01-03 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:34:50 --> Total execution time: 0.0842
DEBUG - 2023-01-03 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:04:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:04:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:04:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:34:52 --> Total execution time: 0.0556
DEBUG - 2023-01-03 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 14:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:34:59 --> Total execution time: 0.0580
DEBUG - 2023-01-03 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:35:01 --> Total execution time: 0.0645
DEBUG - 2023-01-03 14:05:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:05:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:35:06 --> Total execution time: 0.0862
DEBUG - 2023-01-03 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:35:08 --> Total execution time: 0.0846
DEBUG - 2023-01-03 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:05:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:35:53 --> Total execution time: 0.0682
DEBUG - 2023-01-03 14:05:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:58 --> UTF-8 Support Enabled
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:05:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:05:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:37:42 --> Total execution time: 0.0714
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:07:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:07:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:07:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:09:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:39:34 --> Total execution time: 0.0844
DEBUG - 2023-01-03 14:09:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:09:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:09:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:09:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:40:27 --> Total execution time: 0.0744
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:10:28 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:10:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:40:47 --> Total execution time: 0.0561
DEBUG - 2023-01-03 14:10:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:10:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:40:50 --> Total execution time: 0.0657
DEBUG - 2023-01-03 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:40:53 --> Total execution time: 0.1065
DEBUG - 2023-01-03 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:10:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:13 --> Total execution time: 0.0900
DEBUG - 2023-01-03 14:11:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:16 --> Total execution time: 0.0871
DEBUG - 2023-01-03 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:17 --> Total execution time: 0.0785
DEBUG - 2023-01-03 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:18 --> Total execution time: 0.0922
DEBUG - 2023-01-03 14:11:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:19 --> Total execution time: 0.0696
DEBUG - 2023-01-03 14:11:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:41:25 --> Total execution time: 0.0925
DEBUG - 2023-01-03 14:11:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:11:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:11:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:12:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:44:05 --> Total execution time: 0.0671
DEBUG - 2023-01-03 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:44:35 --> Total execution time: 0.0588
DEBUG - 2023-01-03 14:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:44:37 --> Total execution time: 0.0812
DEBUG - 2023-01-03 14:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:14:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:37 --> UTF-8 Support Enabled
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:14:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:14:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:14:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:45:00 --> Total execution time: 0.0603
DEBUG - 2023-01-03 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:45:03 --> Total execution time: 0.0582
DEBUG - 2023-01-03 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:47:48 --> Total execution time: 0.0802
DEBUG - 2023-01-03 14:25:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:55:40 --> Total execution time: 0.0889
DEBUG - 2023-01-03 14:27:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:57:27 --> Total execution time: 0.1056
DEBUG - 2023-01-03 14:27:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:57:37 --> Total execution time: 0.0720
DEBUG - 2023-01-03 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:58:45 --> Total execution time: 0.0866
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:44 --> UTF-8 Support Enabled
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:34:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:34:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:34:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 19:04:48 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\payout\pending-payout.php 61
DEBUG - 2023-01-03 14:34:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:34:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 19:04:50 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\payout\pending-payout.php 61
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 19:05:23 --> Total execution time: 0.0663
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:35:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:35:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:35:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:35:23 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:35:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:35:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:35:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:35:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:35:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:35:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 19:05:27 --> Total execution time: 0.0541
DEBUG - 2023-01-03 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 19:06:03 --> Total execution time: 0.0753
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 14:36:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 14:36:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 14:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 14:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 14:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 19:06:05 --> Total execution time: 0.0549
DEBUG - 2023-01-03 17:40:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:30 --> No URI present. Default controller set.
DEBUG - 2023-01-03 17:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:10:31 --> Total execution time: 1.0831
DEBUG - 2023-01-03 17:40:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:31 --> No URI present. Default controller set.
DEBUG - 2023-01-03 17:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:10:31 --> Total execution time: 0.1064
DEBUG - 2023-01-03 17:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:40:39 --> Total execution time: 0.1089
DEBUG - 2023-01-03 17:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:40:39 --> Total execution time: 0.0791
DEBUG - 2023-01-03 17:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:10:44 --> Total execution time: 0.1076
DEBUG - 2023-01-03 17:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:10:50 --> Total execution time: 0.1549
DEBUG - 2023-01-03 17:41:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:11:26 --> Total execution time: 0.0546
DEBUG - 2023-01-03 17:42:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:12:30 --> Total execution time: 0.0770
DEBUG - 2023-01-03 17:42:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:12:31 --> Total execution time: 0.0783
DEBUG - 2023-01-03 17:42:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:12:42 --> Total execution time: 0.0748
DEBUG - 2023-01-03 17:42:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:12:43 --> Total execution time: 0.0534
DEBUG - 2023-01-03 17:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:21:32 --> Total execution time: 0.1529
DEBUG - 2023-01-03 17:51:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:21:34 --> Total execution time: 0.1496
DEBUG - 2023-01-03 17:53:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:23:07 --> Total execution time: 0.1014
DEBUG - 2023-01-03 17:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:23:08 --> Total execution time: 0.0654
DEBUG - 2023-01-03 17:53:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:23:12 --> Total execution time: 0.1049
DEBUG - 2023-01-03 17:53:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:23:37 --> Total execution time: 0.1118
DEBUG - 2023-01-03 17:53:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:23:39 --> Total execution time: 0.0621
DEBUG - 2023-01-03 17:55:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 17:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 17:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 17:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:25:54 --> Total execution time: 0.0801
DEBUG - 2023-01-03 18:12:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:42:36 --> Total execution time: 0.0817
DEBUG - 2023-01-03 18:12:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:42:38 --> Total execution time: 0.0609
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:12:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:42:46 --> Total execution time: 0.0841
DEBUG - 2023-01-03 18:12:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:42:48 --> Total execution time: 0.0657
DEBUG - 2023-01-03 18:13:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:02 --> Total execution time: 0.0681
DEBUG - 2023-01-03 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:10 --> Total execution time: 0.0787
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:15 --> Total execution time: 0.0652
DEBUG - 2023-01-03 18:13:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:17 --> Total execution time: 0.0869
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:21 --> Total execution time: 0.0661
DEBUG - 2023-01-03 18:13:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:43:23 --> Total execution time: 0.0958
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:13:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:13:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:46:20 --> Total execution time: 0.0722
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:21 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:16:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:16:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:46:57 --> Total execution time: 0.0707
DEBUG - 2023-01-03 18:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:17:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-03 22:47:11 --> Severity: Notice --> Undefined property: Payout_Controller::$Wallets C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Payout_Controller.php 94
ERROR - 2023-01-03 22:47:11 --> Severity: error --> Exception: Call to a member function updateWhere() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Payout_Controller.php 94
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:47:25 --> Total execution time: 0.0834
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:47:42 --> Total execution time: 0.0772
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:42 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:47:51 --> Total execution time: 0.1545
DEBUG - 2023-01-03 18:17:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:47:53 --> Total execution time: 0.0922
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:17:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:17:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:48:13 --> Total execution time: 0.0764
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:18:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:18:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:48:50 --> Total execution time: 0.0740
DEBUG - 2023-01-03 18:19:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:49:26 --> Total execution time: 0.1019
DEBUG - 2023-01-03 18:22:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:52:31 --> Total execution time: 0.0935
DEBUG - 2023-01-03 18:22:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:52:40 --> Total execution time: 0.0863
DEBUG - 2023-01-03 18:23:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:23:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:53:34 --> Total execution time: 0.0873
DEBUG - 2023-01-03 18:23:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:53:36 --> Total execution time: 0.0663
DEBUG - 2023-01-03 18:23:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:53:54 --> Total execution time: 0.0691
DEBUG - 2023-01-03 18:23:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:53:58 --> Total execution time: 0.1009
DEBUG - 2023-01-03 18:24:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:54:01 --> Total execution time: 0.0743
DEBUG - 2023-01-03 18:24:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:54:01 --> Total execution time: 0.0656
DEBUG - 2023-01-03 18:25:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:55:46 --> Total execution time: 0.0779
DEBUG - 2023-01-03 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:56:04 --> Total execution time: 0.0729
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:56:56 --> Total execution time: 0.0718
DEBUG - 2023-01-03 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:26:57 --> UTF-8 Support Enabled
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:26:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:57:17 --> Total execution time: 0.0688
DEBUG - 2023-01-03 18:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:17 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:57:20 --> Total execution time: 0.0612
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:57:42 --> Total execution time: 0.0899
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-03 18:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-03 18:27:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:57:43 --> Total execution time: 0.0579
DEBUG - 2023-01-03 18:27:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:57:57 --> Total execution time: 0.0681
DEBUG - 2023-01-03 18:28:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:58:06 --> Total execution time: 0.0581
DEBUG - 2023-01-03 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:58:19 --> Total execution time: 0.0586
DEBUG - 2023-01-03 18:28:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 22:58:30 --> Total execution time: 0.0575
DEBUG - 2023-01-03 18:30:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:00:42 --> Total execution time: 0.0865
DEBUG - 2023-01-03 18:30:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:00:44 --> Total execution time: 0.0648
DEBUG - 2023-01-03 18:30:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:00:57 --> Total execution time: 0.0993
DEBUG - 2023-01-03 18:31:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:01:34 --> Total execution time: 0.0890
DEBUG - 2023-01-03 18:31:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:01:42 --> Total execution time: 0.0773
DEBUG - 2023-01-03 18:43:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 18:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 18:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 18:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 23:13:46 --> Total execution time: 0.0725
DEBUG - 2023-01-03 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:25:09 --> No URI present. Default controller set.
DEBUG - 2023-01-03 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:55:09 --> Total execution time: 0.0783
DEBUG - 2023-01-03 13:27:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 17:57:46 --> Total execution time: 0.0973
DEBUG - 2023-01-03 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-03 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-03 13:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-03 13:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-03 18:03:16 --> Total execution time: 0.0604
