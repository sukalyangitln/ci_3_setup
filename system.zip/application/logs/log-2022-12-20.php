<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-20 10:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 10:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 10:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:41:11 --> Total execution time: 0.0563
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:11:11 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:11:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:11:11 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:11:11 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:41:37 --> Total execution time: 0.0574
DEBUG - 2022-12-20 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:11:37 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:11:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:11:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:11:37 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:44:16 --> Total execution time: 0.0620
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:14:16 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:14:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:14:16 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:14:16 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:14:16 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:47:39 --> Total execution time: 0.0419
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:17:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:17:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:17:39 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:17:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:17:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:48:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 15:48:39 --> You did not select a file to upload.
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:48:39 --> Total execution time: 0.0415
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:18:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:18:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:18:39 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:18:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:18:39 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:49:18 --> Total execution time: 0.0625
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:18 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:19:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:18 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:49:26 --> Total execution time: 0.0650
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:26 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:19:26 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:26 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:26 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:19:30 --> UTF-8 Support Enabled
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:19:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:50:01 --> Total execution time: 0.0722
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:03 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:20:45 --> Query error: Table 'crowd_funding.ci_sessions' doesn't exist - Invalid query: SELECT 1
FROM `ci_sessions`
WHERE `id` = 'tv86qaohsohjgbje63m1nmkrkmgom46g'
ERROR - 2022-12-20 11:20:45 --> Severity: Warning --> session_write_close(): Cannot call session save handler in a recursive manner Unknown 0
DEBUG - 2022-12-20 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:51:43 --> Total execution time: 0.0576
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:44 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:51:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 15:51:52 --> You did not select a file to upload.
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:51:52 --> Total execution time: 0.0603
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:21:52 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:21:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:54:41 --> Total execution time: 0.0648
DEBUG - 2022-12-20 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:24:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:24:41 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:24:41 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:24:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:24:41 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:55:26 --> Total execution time: 0.0530
DEBUG - 2022-12-20 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:26 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:25:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:26 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:26 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:55:52 --> Total execution time: 0.0412
DEBUG - 2022-12-20 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:52 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:53 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:55:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 15:55:56 --> You did not select a file to upload.
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:55:56 --> Total execution time: 0.0384
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:56 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:25:56 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:56 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:25:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:25:56 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:56:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 15:56:28 --> You did not select a file to upload.
DEBUG - 2022-12-20 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:56:28 --> Total execution time: 0.0505
DEBUG - 2022-12-20 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:26:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:26:28 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:56:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 15:56:51 --> You did not select a file to upload.
DEBUG - 2022-12-20 15:56:51 --> You did not select a file to upload.
DEBUG - 2022-12-20 11:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:56:51 --> Total execution time: 0.0628
DEBUG - 2022-12-20 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:26:52 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:26:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:57:11 --> Total execution time: 0.0644
DEBUG - 2022-12-20 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:27:11 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:27:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:57:54 --> Total execution time: 0.0543
DEBUG - 2022-12-20 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:27:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:27:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:27:54 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:58:03 --> Total execution time: 0.0396
DEBUG - 2022-12-20 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:28:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:28:03 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:28:03 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:58:14 --> Total execution time: 0.0585
DEBUG - 2022-12-20 11:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:28:14 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:28:14 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 15:59:48 --> Total execution time: 0.0564
DEBUG - 2022-12-20 11:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:29:48 --> 404 Page Not Found: Assets/uploads
ERROR - 2022-12-20 11:29:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:00:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:00:13 --> Total execution time: 0.0407
DEBUG - 2022-12-20 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:30:13 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 11:30:13 --> 404 Page Not Found: Assets/uploads
DEBUG - 2022-12-20 11:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:00:52 --> Total execution time: 0.0541
DEBUG - 2022-12-20 11:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:30:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:30:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:02:32 --> Total execution time: 0.0643
DEBUG - 2022-12-20 11:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:32:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:32:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:02:43 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-20 16:02:43 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Profile_Controller.php 33
ERROR - 2022-12-20 16:02:43 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Profile_Controller.php 33
DEBUG - 2022-12-20 11:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:02:43 --> Total execution time: 0.0405
DEBUG - 2022-12-20 11:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:32:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:03:08 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-12-20 16:03:09 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image_Path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Profile_Controller.php 33
ERROR - 2022-12-20 16:03:09 --> Severity: Notice --> Trying to get property 'Admin_Profile_Image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\Profile_Controller.php 33
DEBUG - 2022-12-20 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:03:09 --> Total execution time: 0.0604
DEBUG - 2022-12-20 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:33:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:04:04 --> Total execution time: 0.0383
DEBUG - 2022-12-20 11:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:34:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:34:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:05:18 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 11:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:05:19 --> Total execution time: 0.0383
DEBUG - 2022-12-20 11:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:35:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:05:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-12-20 11:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:05:23 --> Total execution time: 0.0393
DEBUG - 2022-12-20 11:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:35:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 11:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 16:06:28 --> Total execution time: 0.0586
DEBUG - 2022-12-20 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 11:36:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 11:36:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:05:38 --> Total execution time: 0.5736
DEBUG - 2022-12-20 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:35:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:35:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:35:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:05:40 --> Query error: Table 'crowd_funding.home_page_banner' doesn't exist - Invalid query: SELECT *
FROM `home_page_banner`
ORDER BY `hpb_id` DESC
DEBUG - 2022-12-20 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:08:08 --> Total execution time: 0.0542
DEBUG - 2022-12-20 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:38:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:38:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:08:57 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
ERROR - 2022-12-20 17:08:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
DEBUG - 2022-12-20 17:08:57 --> Total execution time: 0.0676
DEBUG - 2022-12-20 12:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:38:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:38:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:10:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Home_page_banner C:\xampp\htdocs\gopal\crowd_funding\system\core\Loader.php 348
DEBUG - 2022-12-20 12:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:42:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:12:41 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
ERROR - 2022-12-20 17:12:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
DEBUG - 2022-12-20 17:12:41 --> Total execution time: 0.0625
DEBUG - 2022-12-20 12:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:42:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:45:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:15:04 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
ERROR - 2022-12-20 17:15:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 77
DEBUG - 2022-12-20 17:15:04 --> Total execution time: 0.0595
DEBUG - 2022-12-20 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:45:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:45:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:47:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:17:12 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 48
ERROR - 2022-12-20 17:17:12 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home_page.php 48
DEBUG - 2022-12-20 17:17:12 --> Total execution time: 0.0410
DEBUG - 2022-12-20 12:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:47:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:18:26 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home\home_page.php 48
ERROR - 2022-12-20 17:18:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home\home_page.php 48
DEBUG - 2022-12-20 17:18:26 --> Total execution time: 0.0444
DEBUG - 2022-12-20 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:48:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:49:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 17:19:14 --> Severity: Notice --> Undefined variable: banner_imgs C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home\home_page.php 49
ERROR - 2022-12-20 17:19:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\gopal\crowd_funding\application\views\Admin\dynamic_page\home\home_page.php 49
DEBUG - 2022-12-20 17:19:14 --> Total execution time: 0.0442
DEBUG - 2022-12-20 12:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:49:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:49:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:20:00 --> Total execution time: 0.0430
DEBUG - 2022-12-20 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:50:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:50:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:20:52 --> Total execution time: 0.0540
DEBUG - 2022-12-20 12:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:50:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:21:02 --> Total execution time: 0.0623
DEBUG - 2022-12-20 12:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:51:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:21:15 --> Total execution time: 0.0489
DEBUG - 2022-12-20 12:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:51:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:21:43 --> Total execution time: 0.0375
DEBUG - 2022-12-20 12:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:51:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:21:49 --> Total execution time: 0.0372
DEBUG - 2022-12-20 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:51:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:22:53 --> Total execution time: 0.0409
DEBUG - 2022-12-20 12:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:52:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:23:03 --> Total execution time: 0.0617
DEBUG - 2022-12-20 12:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:23:14 --> Total execution time: 0.0386
DEBUG - 2022-12-20 12:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:53:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:25:05 --> Total execution time: 0.0565
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:25:11 --> Total execution time: 0.0631
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:25:23 --> Total execution time: 0.0624
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:55:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:26:36 --> Total execution time: 0.0600
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:26:41 --> Total execution time: 0.0812
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:26:45 --> Total execution time: 0.0467
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:56:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:56:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:27:17 --> Total execution time: 0.0417
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:27:23 --> Total execution time: 0.0758
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:27:28 --> Total execution time: 0.0631
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:28 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:27:49 --> Total execution time: 0.0551
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:57:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:28:06 --> Total execution time: 0.0505
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 12:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 12:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:28:21 --> Total execution time: 0.0779
DEBUG - 2022-12-20 12:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 12:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 12:58:21 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:30:14 --> Total execution time: 0.0645
DEBUG - 2022-12-20 13:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:00:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:30:36 --> Total execution time: 0.0395
DEBUG - 2022-12-20 13:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:00:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:31:13 --> Total execution time: 0.0632
DEBUG - 2022-12-20 13:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:01:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:31:28 --> Total execution time: 0.0830
DEBUG - 2022-12-20 13:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:01:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:31:37 --> Total execution time: 0.0802
DEBUG - 2022-12-20 13:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:01:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:33:53 --> Total execution time: 0.0641
DEBUG - 2022-12-20 13:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:03:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:03:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:34:00 --> Total execution time: 0.1030
DEBUG - 2022-12-20 13:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:04:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:35:36 --> Total execution time: 0.0423
DEBUG - 2022-12-20 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:05:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:35:51 --> Total execution time: 0.0473
DEBUG - 2022-12-20 13:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:05:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:37:13 --> Total execution time: 0.0559
DEBUG - 2022-12-20 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:07:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:07:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:38:54 --> Total execution time: 0.0522
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:08:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:39:04 --> Total execution time: 0.0482
DEBUG - 2022-12-20 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:09:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:04 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:09:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:09:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:40:47 --> Total execution time: 0.0619
DEBUG - 2022-12-20 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:10:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:10:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:10:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:42:20 --> Total execution time: 0.0538
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:42:59 --> Total execution time: 0.0614
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:12:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:43:06 --> Total execution time: 0.0547
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:13:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:13:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:44:56 --> Total execution time: 0.0394
DEBUG - 2022-12-20 13:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:14:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:45:50 --> Total execution time: 0.0566
DEBUG - 2022-12-20 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:15:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:15:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:46:05 --> Total execution time: 0.0557
DEBUG - 2022-12-20 13:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:16:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:47:30 --> Total execution time: 0.0566
DEBUG - 2022-12-20 13:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:17:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:54:04 --> Total execution time: 0.0415
DEBUG - 2022-12-20 13:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:24:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:24:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:54:05 --> Total execution time: 0.0509
DEBUG - 2022-12-20 13:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:54:34 --> Total execution time: 0.0547
DEBUG - 2022-12-20 13:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:24:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:24:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:55:48 --> Total execution time: 0.0714
DEBUG - 2022-12-20 13:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:25:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:25:49 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 13:25:49 --> 404 Page Not Found: Defaultpng/index
DEBUG - 2022-12-20 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:57:22 --> Total execution time: 0.0409
DEBUG - 2022-12-20 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:27:22 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 13:27:22 --> 404 Page Not Found: Defaultpng/index
DEBUG - 2022-12-20 13:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:57:31 --> Total execution time: 0.0459
DEBUG - 2022-12-20 13:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:27:31 --> 404 Page Not Found: Defaultpng/index
ERROR - 2022-12-20 13:27:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:58:23 --> Total execution time: 0.0577
DEBUG - 2022-12-20 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:23 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:23 --> 404 Page Not Found: Defaultpng/index
DEBUG - 2022-12-20 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:58:37 --> Total execution time: 0.0591
DEBUG - 2022-12-20 13:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:28:38 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:28:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:38 --> 404 Page Not Found: Defaultpng/index
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:28:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:28:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 17:59:12 --> Total execution time: 0.0661
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:12 --> 404 Page Not Found: Defaultpng/index
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:29:12 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:29:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:12 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:29:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:29:13 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:29:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:29:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:29:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:00:49 --> Total execution time: 0.0541
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:30:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:30:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:01:50 --> Total execution time: 0.0534
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:31:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:02:01 --> Total execution time: 0.0391
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:32:01 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:32:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:32:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:44:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:44:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:17:57 --> Total execution time: 0.0600
DEBUG - 2022-12-20 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:47:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:19:42 --> Total execution time: 0.0640
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:19:48 --> Total execution time: 0.0521
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:49:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:20:27 --> Total execution time: 0.0566
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:50:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:50:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:23:17 --> Total execution time: 0.0576
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:23:59 --> Total execution time: 0.0515
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:53:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:27:15 --> Total execution time: 0.0573
DEBUG - 2022-12-20 13:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:57:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:57:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:28:27 --> Total execution time: 0.0631
DEBUG - 2022-12-20 13:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:58:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:58:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:29:11 --> Total execution time: 0.0733
DEBUG - 2022-12-20 13:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 13:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:29:48 --> Total execution time: 0.0507
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:30:52 --> Total execution time: 0.0589
DEBUG - 2022-12-20 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:00:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:31:07 --> Total execution time: 0.0732
DEBUG - 2022-12-20 14:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:01:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:31:43 --> Total execution time: 0.0785
DEBUG - 2022-12-20 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:01:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:32:00 --> Total execution time: 0.0434
DEBUG - 2022-12-20 14:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:32:28 --> Total execution time: 0.0625
DEBUG - 2022-12-20 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:02:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:02:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:33:21 --> Total execution time: 0.0536
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:33:32 --> Total execution time: 0.0409
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:33:52 --> Total execution time: 0.0463
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:03:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:03:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:35:32 --> Total execution time: 0.0654
DEBUG - 2022-12-20 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:35:59 --> Total execution time: 0.0400
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:05:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:36:47 --> Total execution time: 0.0613
DEBUG - 2022-12-20 14:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:06:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:06:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:37:25 --> Total execution time: 0.0719
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:25 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:07:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:26 --> UTF-8 Support Enabled
ERROR - 2022-12-20 14:07:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:37:37 --> Total execution time: 0.0585
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:37 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:07:53 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:38:03 --> Total execution time: 0.0578
DEBUG - 2022-12-20 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:08:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:39:13 --> Total execution time: 0.0569
DEBUG - 2022-12-20 14:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:39:31 --> Total execution time: 0.0567
DEBUG - 2022-12-20 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:39:41 --> Total execution time: 0.0390
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/website_esa
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:39:57 --> Total execution time: 0.0640
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:09:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:09:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:41:26 --> Total execution time: 0.0710
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:11:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:11:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:42:08 --> Total execution time: 0.0632
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:42:18 --> Total execution time: 0.0545
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:42:40 --> Total execution time: 0.0487
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:42:52 --> Total execution time: 0.0902
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:12:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 14:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:44:28 --> Total execution time: 0.0394
DEBUG - 2022-12-20 14:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:14:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:14:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:44:57 --> Total execution time: 0.0827
DEBUG - 2022-12-20 14:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:14:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:45:34 --> Total execution time: 0.0730
DEBUG - 2022-12-20 14:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:15:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:15 --> Total execution time: 0.0551
DEBUG - 2022-12-20 14:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:28 --> Total execution time: 0.0634
DEBUG - 2022-12-20 14:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:47 --> Total execution time: 0.0499
DEBUG - 2022-12-20 14:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:51 --> Total execution time: 0.0598
DEBUG - 2022-12-20 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:53 --> Total execution time: 0.0422
DEBUG - 2022-12-20 14:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:48:55 --> Total execution time: 0.0404
DEBUG - 2022-12-20 14:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:18:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:18:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:50:08 --> Total execution time: 0.0858
DEBUG - 2022-12-20 14:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:20:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:53:43 --> Total execution time: 0.0553
DEBUG - 2022-12-20 14:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:23:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:23:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:54:28 --> Total execution time: 0.0602
DEBUG - 2022-12-20 14:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:24:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:24:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:55:34 --> Total execution time: 0.0399
DEBUG - 2022-12-20 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:25:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:25:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:55:36 --> Total execution time: 0.0509
DEBUG - 2022-12-20 14:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:57:16 --> Total execution time: 0.0517
DEBUG - 2022-12-20 14:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:27:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:57:25 --> Total execution time: 0.0443
DEBUG - 2022-12-20 14:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:27:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:57:49 --> Total execution time: 0.0764
DEBUG - 2022-12-20 14:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:27:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:27:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 14:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 14:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 18:58:09 --> Total execution time: 0.0605
DEBUG - 2022-12-20 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 14:28:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 14:28:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:43:10 --> Total execution time: 0.0638
DEBUG - 2022-12-20 16:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:13:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:43:35 --> Total execution time: 0.0583
DEBUG - 2022-12-20 16:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:13:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:43:53 --> Total execution time: 0.0553
DEBUG - 2022-12-20 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:13:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:13:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:44:04 --> Total execution time: 0.0914
DEBUG - 2022-12-20 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:14:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:44:06 --> Total execution time: 0.0409
DEBUG - 2022-12-20 16:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:14:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:44:09 --> Total execution time: 0.0401
DEBUG - 2022-12-20 16:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:14:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:44:10 --> Total execution time: 0.0538
DEBUG - 2022-12-20 16:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:14:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:14:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:45:03 --> Total execution time: 0.0707
DEBUG - 2022-12-20 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:15:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:45:04 --> Total execution time: 0.0547
DEBUG - 2022-12-20 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:15:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:45:25 --> Total execution time: 0.0410
DEBUG - 2022-12-20 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:15:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:47:40 --> Total execution time: 0.0524
DEBUG - 2022-12-20 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:17:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:17:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:48:04 --> Total execution time: 0.0697
DEBUG - 2022-12-20 16:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:18:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:48:20 --> Total execution time: 0.0631
DEBUG - 2022-12-20 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:18:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:48:36 --> Total execution time: 0.0862
DEBUG - 2022-12-20 16:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:18:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:48:43 --> Total execution time: 0.0659
DEBUG - 2022-12-20 16:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:18:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:49:41 --> Total execution time: 0.0532
DEBUG - 2022-12-20 16:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:19:41 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:50:29 --> Total execution time: 0.0622
DEBUG - 2022-12-20 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:20:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:50:30 --> Total execution time: 0.0400
DEBUG - 2022-12-20 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:20:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:50:43 --> Total execution time: 0.0499
DEBUG - 2022-12-20 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:20:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:50:54 --> Total execution time: 0.0641
DEBUG - 2022-12-20 16:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:20:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:51:09 --> Total execution time: 0.0672
DEBUG - 2022-12-20 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:21:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:51:17 --> Total execution time: 0.0559
DEBUG - 2022-12-20 16:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:21:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:51:24 --> Total execution time: 0.0595
DEBUG - 2022-12-20 16:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:21:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:52:31 --> Total execution time: 0.0392
DEBUG - 2022-12-20 16:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:22:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:52:34 --> Total execution time: 0.0384
DEBUG - 2022-12-20 16:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:22:34 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:52:35 --> Total execution time: 0.0604
DEBUG - 2022-12-20 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:22:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:53:32 --> Total execution time: 0.7588
DEBUG - 2022-12-20 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:23:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:54:16 --> Total execution time: 0.0621
DEBUG - 2022-12-20 16:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:24:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:24:16 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:59:14 --> Total execution time: 0.0612
DEBUG - 2022-12-20 16:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:29:14 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:20 --> No URI present. Default controller set.
DEBUG - 2022-12-20 16:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-12-20 20:59:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Products C:\xampp\htdocs\gopal\crowd_funding\system\core\Loader.php 348
DEBUG - 2022-12-20 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:59:33 --> Total execution time: 0.0424
DEBUG - 2022-12-20 16:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:59:50 --> Total execution time: 0.0625
DEBUG - 2022-12-20 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:29:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:59:52 --> Total execution time: 0.0452
DEBUG - 2022-12-20 16:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 20:59:54 --> Total execution time: 0.0396
DEBUG - 2022-12-20 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:01:05 --> Total execution time: 0.0412
DEBUG - 2022-12-20 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:31:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:01:20 --> Total execution time: 0.0589
DEBUG - 2022-12-20 16:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:31:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:01:31 --> Total execution time: 0.0695
DEBUG - 2022-12-20 16:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:31:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:31:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:02:44 --> Total execution time: 0.0540
DEBUG - 2022-12-20 16:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:32:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:32:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:03:04 --> Total execution time: 0.0538
DEBUG - 2022-12-20 16:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:33:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:03:09 --> Total execution time: 0.0604
DEBUG - 2022-12-20 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:33:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:03:19 --> Total execution time: 0.0522
DEBUG - 2022-12-20 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:33:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:03:46 --> Total execution time: 0.0787
DEBUG - 2022-12-20 16:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:33:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:04:03 --> Total execution time: 0.0662
DEBUG - 2022-12-20 16:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:34:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:04:10 --> Total execution time: 0.0531
DEBUG - 2022-12-20 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:34:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:04:36 --> Total execution time: 0.0550
DEBUG - 2022-12-20 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:34:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:04:43 --> Total execution time: 0.0681
DEBUG - 2022-12-20 16:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:34:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:04:55 --> Total execution time: 0.0744
DEBUG - 2022-12-20 16:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:34:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:34:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:05:22 --> Total execution time: 0.0901
DEBUG - 2022-12-20 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:35:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:35:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:05:51 --> Total execution time: 0.0403
DEBUG - 2022-12-20 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:35:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:35:51 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:06:04 --> Total execution time: 0.0904
DEBUG - 2022-12-20 16:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:36:04 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:06:37 --> Total execution time: 0.0514
DEBUG - 2022-12-20 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:36:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:06:58 --> Total execution time: 0.0978
DEBUG - 2022-12-20 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:36:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:07:10 --> Total execution time: 0.0616
DEBUG - 2022-12-20 16:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:37:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:07:22 --> Total execution time: 0.0613
DEBUG - 2022-12-20 16:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:37:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:37:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:08:29 --> Total execution time: 0.0375
DEBUG - 2022-12-20 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:38:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:09:48 --> Total execution time: 0.0572
DEBUG - 2022-12-20 16:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:39:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:09:55 --> Total execution time: 0.0884
DEBUG - 2022-12-20 16:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:39:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:39:55 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:10:06 --> Total execution time: 0.0608
DEBUG - 2022-12-20 16:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:40:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:10:24 --> Total execution time: 0.0666
DEBUG - 2022-12-20 16:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:40:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:10:57 --> Total execution time: 0.0396
DEBUG - 2022-12-20 16:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:40:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:40:57 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:11:25 --> Total execution time: 0.0390
DEBUG - 2022-12-20 16:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:41:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:03 --> Total execution time: 0.0587
DEBUG - 2022-12-20 16:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:12 --> Total execution time: 0.0610
DEBUG - 2022-12-20 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:18 --> Total execution time: 0.0388
DEBUG - 2022-12-20 16:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:18 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:22 --> Total execution time: 0.0604
DEBUG - 2022-12-20 16:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:25 --> Total execution time: 0.0464
DEBUG - 2022-12-20 16:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:35 --> Total execution time: 0.0381
DEBUG - 2022-12-20 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:12:48 --> Total execution time: 0.0574
DEBUG - 2022-12-20 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:42:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:13:12 --> Total execution time: 0.0556
DEBUG - 2022-12-20 16:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:43:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:13:27 --> Total execution time: 0.0634
DEBUG - 2022-12-20 16:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:43:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:43:27 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:14:32 --> Total execution time: 0.0386
DEBUG - 2022-12-20 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:44:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:14:49 --> Total execution time: 0.0418
DEBUG - 2022-12-20 16:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:44:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:14:56 --> Total execution time: 0.0556
DEBUG - 2022-12-20 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:44:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:15:00 --> Total execution time: 0.0558
DEBUG - 2022-12-20 16:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:45:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:15:10 --> Total execution time: 0.0385
DEBUG - 2022-12-20 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:45:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 16:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 16:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 16:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:15:15 --> Total execution time: 0.0358
DEBUG - 2022-12-20 16:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 16:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 16:45:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:18:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:49:07 --> Total execution time: 0.0596
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:19:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:49:13 --> Total execution time: 0.0522
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:49:17 --> Total execution time: 0.0536
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:19:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-12-20 17:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:49:43 --> Total execution time: 0.0585
DEBUG - 2022-12-20 17:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:49:44 --> Total execution time: 0.0594
DEBUG - 2022-12-20 17:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-20 17:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-20 17:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-20 21:52:05 --> Total execution time: 0.0600
DEBUG - 2022-12-20 17:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-20 17:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-20 17:22:05 --> 404 Page Not Found: Assets/website_esa
