<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-02 00:01:21 --> Total execution time: 0.1054
DEBUG - 2023-01-02 00:02:17 --> Total execution time: 0.1100
DEBUG - 2023-01-02 00:02:28 --> Total execution time: 0.1006
DEBUG - 2023-01-02 00:03:18 --> Total execution time: 0.0777
DEBUG - 2023-01-02 00:03:30 --> Total execution time: 0.0730
DEBUG - 2023-01-02 00:03:33 --> Total execution time: 0.0763
DEBUG - 2023-01-02 00:03:54 --> Total execution time: 0.0820
DEBUG - 2023-01-02 00:03:55 --> Total execution time: 0.0778
DEBUG - 2023-01-02 00:03:58 --> Total execution time: 0.0794
DEBUG - 2023-01-02 00:04:03 --> Total execution time: 0.0867
DEBUG - 2023-01-02 00:04:05 --> Total execution time: 0.0790
ERROR - 2023-01-02 00:04:36 --> Query error: Column 'wt_note' cannot be null - Invalid query: INSERT INTO `wallet_transactions` (`wt_FK_ul_id`, `wt_txn_id`, `wt_type`, `wt_related`, `wt_related_id`, `wt_amount`, `wt_debit_amount`, `wt_tax`, `wt_status`, `wt_date`, `wt_note`, `wt_bank_name`, `wt_bank_acc_no`, `wt_bank_acc_branch_code`, `wt_bank_acc_holder_name`, `wt_bank_acc_phone`) VALUES ('1', '105851000845075', 'C', 0, '5', '5000', 0, 0, 'success', '2023-01-02 00:04:36', NULL, 'State Bank of India', '6587548787', 'PNB25487', 'Dinesh Barman', '9091982795')
ERROR - 2023-01-02 00:04:38 --> Query error: Column 'wt_note' cannot be null - Invalid query: INSERT INTO `wallet_transactions` (`wt_FK_ul_id`, `wt_txn_id`, `wt_type`, `wt_related`, `wt_related_id`, `wt_amount`, `wt_debit_amount`, `wt_tax`, `wt_status`, `wt_date`, `wt_note`, `wt_bank_name`, `wt_bank_acc_no`, `wt_bank_acc_branch_code`, `wt_bank_acc_holder_name`, `wt_bank_acc_phone`) VALUES ('1', '105851000845075', 'C', 0, '5', '5000', 0, 0, 'success', '2023-01-02 00:04:38', NULL, 'State Bank of India', '6587548787', 'PNB25487', 'Dinesh Barman', '9091982795')
DEBUG - 2023-01-02 00:05:13 --> Total execution time: 0.1704
DEBUG - 2023-01-02 00:06:48 --> Total execution time: 0.1014
DEBUG - 2023-01-02 00:07:06 --> Total execution time: 0.1309
DEBUG - 2023-01-02 00:08:42 --> Total execution time: 0.0932
DEBUG - 2023-01-02 00:08:51 --> Total execution time: 0.1479
DEBUG - 2023-01-02 00:09:01 --> Total execution time: 0.0889
DEBUG - 2023-01-02 00:09:04 --> Total execution time: 0.1794
DEBUG - 2023-01-02 00:11:14 --> Total execution time: 0.0845
DEBUG - 2023-01-02 00:13:04 --> Total execution time: 0.0858
DEBUG - 2023-01-02 00:13:10 --> Total execution time: 0.2118
DEBUG - 2023-01-02 00:13:12 --> Total execution time: 0.0878
DEBUG - 2023-01-02 00:13:49 --> Total execution time: 0.1040
DEBUG - 2023-01-02 00:13:56 --> Total execution time: 0.0731
DEBUG - 2023-01-02 00:14:00 --> Total execution time: 0.0802
DEBUG - 2023-01-02 00:28:09 --> Total execution time: 0.0803
ERROR - 2023-01-02 00:30:04 --> Severity: Notice --> Undefined variable: CI C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 190
ERROR - 2023-01-02 00:30:04 --> Severity: Notice --> Trying to get property 'db' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 190
ERROR - 2023-01-02 00:30:04 --> Severity: error --> Exception: Call to a member function select() on null C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 190
DEBUG - 2023-01-02 00:42:12 --> Total execution time: 0.1142
DEBUG - 2023-01-02 00:43:02 --> Total execution time: 0.0870
DEBUG - 2023-01-02 00:43:08 --> Total execution time: 0.0761
DEBUG - 2023-01-02 00:43:55 --> Total execution time: 0.0880
DEBUG - 2023-01-02 00:55:44 --> Total execution time: 0.1200
DEBUG - 2023-01-02 00:55:48 --> Total execution time: 0.0773
DEBUG - 2023-01-02 00:55:52 --> Total execution time: 0.0735
DEBUG - 2023-01-02 00:56:04 --> Total execution time: 0.0983
DEBUG - 2023-01-02 00:56:06 --> Total execution time: 0.0788
DEBUG - 2023-01-02 00:56:08 --> Total execution time: 0.0752
DEBUG - 2023-01-02 00:56:10 --> Total execution time: 0.0745
DEBUG - 2023-01-02 01:02:06 --> Total execution time: 0.0908
DEBUG - 2023-01-02 01:02:09 --> Total execution time: 0.0687
DEBUG - 2023-01-02 01:02:13 --> Total execution time: 0.0974
DEBUG - 2023-01-02 01:10:53 --> Total execution time: 0.0935
DEBUG - 2023-01-02 01:10:56 --> Total execution time: 0.0706
DEBUG - 2023-01-02 01:12:26 --> Total execution time: 0.0714
DEBUG - 2023-01-02 01:12:28 --> Total execution time: 0.0804
ERROR - 2023-01-02 01:12:30 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Account_Controller.php 299
ERROR - 2023-01-02 01:12:30 --> Severity: Notice --> Trying to get property 'wt_txn_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Account_Controller.php 299
DEBUG - 2023-01-02 01:12:30 --> Total execution time: 0.0960
ERROR - 2023-01-02 01:12:31 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Account_Controller.php 299
ERROR - 2023-01-02 01:12:31 --> Severity: Notice --> Trying to get property 'wt_txn_id' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Account_Controller.php 299
DEBUG - 2023-01-02 01:12:31 --> Total execution time: 0.0901
DEBUG - 2023-01-02 01:12:44 --> Total execution time: 0.0789
DEBUG - 2023-01-02 01:12:57 --> Total execution time: 0.0771
DEBUG - 2023-01-02 01:14:50 --> Total execution time: 0.0887
DEBUG - 2023-01-02 01:14:55 --> Total execution time: 0.0693
DEBUG - 2023-01-02 01:14:59 --> Total execution time: 0.0682
DEBUG - 2023-01-02 01:15:02 --> Total execution time: 0.0695
DEBUG - 2023-01-02 01:15:04 --> Total execution time: 0.0778
DEBUG - 2023-01-02 01:15:06 --> Total execution time: 0.0685
DEBUG - 2023-01-02 01:15:19 --> Total execution time: 0.0769
DEBUG - 2023-01-02 01:15:21 --> Total execution time: 0.0686
DEBUG - 2023-01-02 01:15:50 --> Total execution time: 0.0858
DEBUG - 2023-01-02 01:15:52 --> Total execution time: 0.0693
DEBUG - 2023-01-02 01:16:03 --> Total execution time: 0.0937
DEBUG - 2023-01-02 01:16:05 --> Total execution time: 0.0792
DEBUG - 2023-01-02 01:16:25 --> Total execution time: 0.1095
DEBUG - 2023-01-02 01:16:26 --> Total execution time: 0.0693
DEBUG - 2023-01-02 01:16:57 --> Total execution time: 0.0944
DEBUG - 2023-01-02 01:16:59 --> Total execution time: 0.0686
DEBUG - 2023-01-02 01:17:05 --> Total execution time: 0.0683
DEBUG - 2023-01-02 01:17:14 --> Total execution time: 0.0685
DEBUG - 2023-01-02 01:18:12 --> Total execution time: 0.1279
DEBUG - 2023-01-02 01:21:47 --> Total execution time: 0.0933
DEBUG - 2023-01-02 01:21:50 --> Total execution time: 0.0681
DEBUG - 2023-01-02 01:22:02 --> Total execution time: 0.0959
DEBUG - 2023-01-02 01:22:03 --> Total execution time: 0.0709
DEBUG - 2023-01-02 01:22:10 --> Total execution time: 0.1130
DEBUG - 2023-01-02 01:22:11 --> Total execution time: 0.1008
DEBUG - 2023-01-02 01:22:45 --> Total execution time: 0.0881
DEBUG - 2023-01-02 01:22:45 --> Total execution time: 0.0779
DEBUG - 2023-01-02 01:22:47 --> Total execution time: 0.0755
DEBUG - 2023-01-02 01:22:52 --> Total execution time: 0.0757
DEBUG - 2023-01-02 01:22:53 --> Total execution time: 0.0977
DEBUG - 2023-01-02 01:22:55 --> Total execution time: 0.0855
DEBUG - 2023-01-02 01:23:14 --> Total execution time: 0.0759
DEBUG - 2023-01-02 02:15:35 --> Total execution time: 0.0745
DEBUG - 2023-01-02 02:16:59 --> Total execution time: 0.0799
DEBUG - 2023-01-02 02:19:14 --> Total execution time: 0.0953
DEBUG - 2023-01-02 02:19:24 --> Total execution time: 0.1008
DEBUG - 2023-01-02 02:23:54 --> Total execution time: 0.0863
DEBUG - 2023-01-02 02:30:05 --> Total execution time: 0.0924
DEBUG - 2023-01-02 02:30:22 --> Total execution time: 0.0890
DEBUG - 2023-01-02 02:31:19 --> Total execution time: 0.0749
DEBUG - 2023-01-02 02:31:21 --> Total execution time: 0.0744
DEBUG - 2023-01-02 02:31:24 --> Total execution time: 0.0795
DEBUG - 2023-01-02 02:34:43 --> Total execution time: 0.0884
DEBUG - 2023-01-02 02:35:23 --> Total execution time: 0.0893
DEBUG - 2023-01-02 02:35:29 --> Total execution time: 0.0839
DEBUG - 2023-01-02 02:39:05 --> Total execution time: 0.1044
DEBUG - 2023-01-02 02:43:19 --> Total execution time: 0.0969
DEBUG - 2023-01-02 02:43:23 --> Total execution time: 0.0720
DEBUG - 2023-01-02 02:43:41 --> Total execution time: 0.0896
ERROR - 2023-01-02 02:43:43 --> Severity: Notice --> Undefined property: Fundraiser_Controller::$Wallet_transactions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:43 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: Notice --> Undefined property: Fundraiser_Controller::$Wallet_transactions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: Notice --> Undefined property: Fundraiser_Controller::$Wallet_transactions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: Notice --> Undefined property: Fundraiser_Controller::$Wallet_transactions C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
ERROR - 2023-01-02 02:43:45 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Admin\fundraiser\Fundraiser_Controller.php 410
DEBUG - 2023-01-02 02:44:07 --> Total execution time: 0.0942
DEBUG - 2023-01-02 02:44:10 --> Total execution time: 0.0716
DEBUG - 2023-01-02 02:44:12 --> Total execution time: 0.0713
DEBUG - 2023-01-02 02:44:30 --> Total execution time: 0.1018
DEBUG - 2023-01-02 02:44:33 --> Total execution time: 0.0855
DEBUG - 2023-01-02 02:44:36 --> Total execution time: 0.0811
DEBUG - 2023-01-02 02:44:37 --> Total execution time: 0.0777
DEBUG - 2023-01-02 02:44:38 --> Total execution time: 0.0889
DEBUG - 2023-01-02 02:45:02 --> Total execution time: 0.0785
DEBUG - 2023-01-02 02:45:04 --> Total execution time: 0.0922
DEBUG - 2023-01-02 02:45:32 --> Total execution time: 0.0938
DEBUG - 2023-01-02 02:45:43 --> Total execution time: 0.0855
DEBUG - 2023-01-02 02:47:06 --> Total execution time: 0.0967
DEBUG - 2023-01-02 02:48:05 --> Total execution time: 0.0814
DEBUG - 2023-01-02 02:48:10 --> Total execution time: 0.1234
DEBUG - 2023-01-02 02:52:30 --> Total execution time: 0.1009
DEBUG - 2023-01-02 02:52:44 --> Total execution time: 0.0902
DEBUG - 2023-01-02 02:52:48 --> Total execution time: 0.0754
DEBUG - 2023-01-02 02:52:51 --> Total execution time: 0.0775
DEBUG - 2023-01-02 02:52:53 --> Total execution time: 0.0748
DEBUG - 2023-01-02 02:54:09 --> Total execution time: 0.1188
DEBUG - 2023-01-02 02:54:13 --> Total execution time: 0.0742
DEBUG - 2023-01-02 02:54:14 --> Total execution time: 0.0985
DEBUG - 2023-01-02 02:55:16 --> Total execution time: 0.0846
DEBUG - 2023-01-02 02:55:22 --> Total execution time: 0.0907
DEBUG - 2023-01-02 02:56:44 --> Total execution time: 0.0911
DEBUG - 2023-01-02 02:56:52 --> Total execution time: 0.0897
ERROR - 2023-01-02 02:57:55 --> Severity: Notice --> Undefined variable: from_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\wallet-transaction.php 35
ERROR - 2023-01-02 02:57:55 --> Severity: Notice --> Undefined variable: to_date C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\wallet-transaction.php 41
ERROR - 2023-01-02 02:57:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\wallet-transaction.php 48
ERROR - 2023-01-02 02:57:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\wallet-transaction.php 49
ERROR - 2023-01-02 02:57:55 --> Severity: Notice --> Undefined variable: type C:\xampp\htdocs\gopal\crowd_funding\application\views\fundraiser\wallet-transaction.php 50
DEBUG - 2023-01-02 02:57:55 --> Total execution time: 0.1113
DEBUG - 2023-01-02 02:59:10 --> Total execution time: 0.1063
DEBUG - 2023-01-02 03:01:01 --> Total execution time: 0.0948
DEBUG - 2023-01-02 03:01:14 --> Total execution time: 0.0788
DEBUG - 2023-01-02 03:01:45 --> Total execution time: 0.0821
DEBUG - 2023-01-02 03:01:47 --> Total execution time: 0.0833
DEBUG - 2023-01-02 03:01:49 --> Total execution time: 0.0757
DEBUG - 2023-01-02 03:07:40 --> Total execution time: 0.0905
ERROR - 2023-01-02 03:11:17 --> Severity: error --> Exception: Too few arguments to function get_wallet_transaction(), 1 passed in C:\xampp\htdocs\gopal\crowd_funding\application\controllers\fundraiser\Account_Controller.php on line 372 and exactly 4 expected C:\xampp\htdocs\gopal\crowd_funding\application\helpers\project_helper.php 189
DEBUG - 2023-01-02 03:11:28 --> Total execution time: 0.0986
DEBUG - 2023-01-02 03:12:23 --> Total execution time: 0.0880
DEBUG - 2023-01-02 03:12:43 --> Total execution time: 0.0851
DEBUG - 2023-01-02 03:13:31 --> Total execution time: 0.1052
DEBUG - 2023-01-02 03:13:38 --> Total execution time: 0.0885
DEBUG - 2023-01-02 03:15:02 --> Total execution time: 0.0917
DEBUG - 2023-01-02 03:15:19 --> Total execution time: 0.0828
DEBUG - 2023-01-02 03:15:55 --> Total execution time: 0.1069
DEBUG - 2023-01-02 03:17:14 --> Total execution time: 0.0911
DEBUG - 2023-01-02 03:17:40 --> Total execution time: 0.0914
DEBUG - 2023-01-02 03:17:45 --> Total execution time: 0.1062
DEBUG - 2023-01-02 03:17:58 --> Total execution time: 0.0909
DEBUG - 2023-01-02 03:18:28 --> Total execution time: 0.0858
DEBUG - 2023-01-02 03:18:51 --> Total execution time: 0.0825
DEBUG - 2023-01-02 03:19:23 --> Total execution time: 0.1034
DEBUG - 2023-01-02 03:20:35 --> Total execution time: 0.1008
DEBUG - 2023-01-02 03:20:41 --> Total execution time: 0.1284
DEBUG - 2023-01-02 03:21:32 --> Total execution time: 0.0922
DEBUG - 2023-01-02 03:27:14 --> Total execution time: 0.0860
DEBUG - 2023-01-02 03:27:24 --> Total execution time: 0.0783
DEBUG - 2023-01-02 03:27:30 --> Total execution time: 0.1019
DEBUG - 2023-01-02 03:27:46 --> Total execution time: 0.0895
DEBUG - 2023-01-02 03:27:59 --> Total execution time: 0.0958
DEBUG - 2023-01-02 03:28:07 --> Total execution time: 0.0872
DEBUG - 2023-01-02 03:38:49 --> Total execution time: 0.1073
DEBUG - 2023-01-02 03:39:10 --> Total execution time: 0.1031
DEBUG - 2023-01-02 03:39:23 --> Total execution time: 0.0992
DEBUG - 2023-01-02 03:40:19 --> Total execution time: 0.0800
DEBUG - 2023-01-02 03:40:35 --> Total execution time: 0.0825
DEBUG - 2023-01-02 03:41:45 --> Total execution time: 0.1000
DEBUG - 2023-01-02 03:42:00 --> Total execution time: 0.0983
DEBUG - 2023-01-02 03:43:09 --> Total execution time: 0.0913
DEBUG - 2023-01-02 03:43:13 --> Total execution time: 0.0843
DEBUG - 2023-01-02 03:59:38 --> Total execution time: 0.0880
DEBUG - 2023-01-02 03:59:41 --> Total execution time: 0.0818
DEBUG - 2023-01-02 03:59:48 --> Total execution time: 0.0895
DEBUG - 2023-01-02 04:00:01 --> Total execution time: 0.1035
DEBUG - 2023-01-02 04:00:06 --> Total execution time: 0.0856
DEBUG - 2023-01-02 14:26:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:26:12 --> Total execution time: 1.6267
DEBUG - 2023-01-02 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:26:15 --> Total execution time: 0.0515
DEBUG - 2023-01-02 14:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:26:24 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 18:56:24 --> Total execution time: 0.3014
DEBUG - 2023-01-02 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:30:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:30:06 --> UTF-8 Support Enabled
ERROR - 2023-01-02 14:30:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:30:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:30:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:31:41 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:01:41 --> Total execution time: 0.0652
DEBUG - 2023-01-02 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:31:41 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:31:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:31:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:31:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:09 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:09 --> Total execution time: 0.0687
DEBUG - 2023-01-02 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:09 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:32:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:32:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:42 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:42 --> Total execution time: 0.0674
DEBUG - 2023-01-02 14:32:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:32:45 --> Total execution time: 0.0700
DEBUG - 2023-01-02 14:32:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:32:45 --> Total execution time: 0.0570
DEBUG - 2023-01-02 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:49 --> Total execution time: 0.0529
DEBUG - 2023-01-02 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 14:32:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:52 --> Total execution time: 0.0886
DEBUG - 2023-01-02 14:32:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-02 19:02:58 --> You did not select a file to upload.
DEBUG - 2023-01-02 19:02:58 --> You did not select a file to upload.
DEBUG - 2023-01-02 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:02:58 --> Total execution time: 0.0536
DEBUG - 2023-01-02 14:32:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:32:58 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:33:00 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:03:00 --> Total execution time: 0.0572
DEBUG - 2023-01-02 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:33:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:33:00 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:33:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:33:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:33:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:33:00 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:35:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:05:57 --> Total execution time: 0.0720
DEBUG - 2023-01-02 14:36:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:07 --> Total execution time: 0.0888
DEBUG - 2023-01-02 14:36:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:45 --> Total execution time: 0.0553
DEBUG - 2023-01-02 14:36:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:47 --> Total execution time: 0.0515
DEBUG - 2023-01-02 14:36:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:53 --> Total execution time: 0.0520
DEBUG - 2023-01-02 14:36:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:56 --> Total execution time: 0.0642
DEBUG - 2023-01-02 14:37:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:24 --> Total execution time: 0.0588
DEBUG - 2023-01-02 14:37:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:26 --> Total execution time: 0.0511
DEBUG - 2023-01-02 14:37:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:27 --> Total execution time: 0.0699
DEBUG - 2023-01-02 14:37:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:32 --> Total execution time: 0.0497
DEBUG - 2023-01-02 14:37:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:46 --> Total execution time: 0.0498
DEBUG - 2023-01-02 14:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:07:48 --> Total execution time: 0.0511
DEBUG - 2023-01-02 14:40:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:40:03 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:10:03 --> Total execution time: 0.0649
DEBUG - 2023-01-02 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:10:09 --> Total execution time: 0.0611
DEBUG - 2023-01-02 14:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:10:14 --> Total execution time: 0.0553
DEBUG - 2023-01-02 14:40:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:40:19 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:10:19 --> Total execution time: 0.0527
DEBUG - 2023-01-02 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:42:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:42:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:42:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:42:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:42:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:42:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:02 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:14:02 --> Total execution time: 0.0687
DEBUG - 2023-01-02 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:22 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:14:22 --> Total execution time: 0.0682
DEBUG - 2023-01-02 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:23 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:44:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:23 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:48 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:14:48 --> Total execution time: 0.0914
DEBUG - 2023-01-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:44:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:58 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:14:58 --> Total execution time: 0.0629
DEBUG - 2023-01-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:58 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:44:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:44:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:13 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:15:13 --> Total execution time: 0.0640
DEBUG - 2023-01-02 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:13 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:45:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:21 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:15:21 --> Total execution time: 0.0644
DEBUG - 2023-01-02 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:45:22 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:43 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:16:43 --> Total execution time: 0.0847
DEBUG - 2023-01-02 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:43 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:46:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:43 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:57 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:16:57 --> Total execution time: 0.0618
DEBUG - 2023-01-02 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:57 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:46:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:46:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:05 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:17:05 --> Total execution time: 0.0674
DEBUG - 2023-01-02 14:47:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:06 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:47:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:28 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:17:28 --> Total execution time: 0.0753
DEBUG - 2023-01-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:41 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:47:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:47:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:19:52 --> Total execution time: 0.0733
DEBUG - 2023-01-02 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:49:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:49:52 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:21:26 --> Total execution time: 0.0547
DEBUG - 2023-01-02 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:51:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:51:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 14:51:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:51:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 14:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:22:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-02 19:22:36 --> You did not select a file to upload.
DEBUG - 2023-01-02 14:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:22:36 --> Total execution time: 0.0676
DEBUG - 2023-01-02 14:52:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 14:52:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 14:57:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:27:12 --> Total execution time: 0.0773
DEBUG - 2023-01-02 14:58:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:58:27 --> No URI present. Default controller set.
DEBUG - 2023-01-02 14:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:28:27 --> Total execution time: 0.0860
DEBUG - 2023-01-02 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:28:45 --> Total execution time: 0.0890
DEBUG - 2023-01-02 14:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:29:34 --> Total execution time: 0.0621
DEBUG - 2023-01-02 14:59:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:29:36 --> Total execution time: 0.0545
DEBUG - 2023-01-02 14:59:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 14:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 14:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 14:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:29:41 --> Total execution time: 0.0604
DEBUG - 2023-01-02 15:00:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:00:39 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:30:39 --> Total execution time: 0.0645
DEBUG - 2023-01-02 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:01:07 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 15:01:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:01:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:01:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:01:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:09:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:09:11 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:39:12 --> Total execution time: 0.0726
DEBUG - 2023-01-02 15:09:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:09:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:09:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:09:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:09:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:09:13 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:09:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:09:45 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:39:45 --> Total execution time: 0.0571
DEBUG - 2023-01-02 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:10:01 --> UTF-8 Support Enabled
ERROR - 2023-01-02 15:10:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 15:10:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:09 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:40:09 --> Total execution time: 0.0920
DEBUG - 2023-01-02 15:10:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:15 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:40:15 --> Total execution time: 0.0779
DEBUG - 2023-01-02 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:10:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:10:58 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:40:58 --> Total execution time: 0.0561
DEBUG - 2023-01-02 15:11:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:11:44 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:41:45 --> Total execution time: 0.0935
DEBUG - 2023-01-02 15:11:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:11:54 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:41:54 --> Total execution time: 0.0732
DEBUG - 2023-01-02 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:12:03 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 15:12:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:12:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:12:03 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:12:24 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:42:24 --> Total execution time: 0.0628
DEBUG - 2023-01-02 15:15:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:15:27 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:45:27 --> Total execution time: 0.0765
DEBUG - 2023-01-02 15:16:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:16:45 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:46:45 --> Total execution time: 0.0744
DEBUG - 2023-01-02 15:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:17:25 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 15:17:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:17:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:17:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:17:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:17:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:50:08 --> Total execution time: 0.0747
DEBUG - 2023-01-02 15:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:20:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 15:20:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 15:20:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:20:55 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:50:55 --> Total execution time: 0.0622
DEBUG - 2023-01-02 15:22:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:52:29 --> Total execution time: 0.0549
DEBUG - 2023-01-02 15:26:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:56:17 --> Total execution time: 0.0686
DEBUG - 2023-01-02 15:27:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:57:11 --> Total execution time: 0.0572
DEBUG - 2023-01-02 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:58:27 --> Total execution time: 0.0612
DEBUG - 2023-01-02 15:29:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:59:11 --> Total execution time: 0.2694
DEBUG - 2023-01-02 15:30:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:30:06 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:00:06 --> Total execution time: 0.0609
DEBUG - 2023-01-02 15:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 15:30:33 --> No URI present. Default controller set.
DEBUG - 2023-01-02 15:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 15:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 15:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:00:33 --> Total execution time: 0.0692
DEBUG - 2023-01-02 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:11:45 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:11:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-02 14:41:45 --> Query error: Table 'ismartw1_crowd_funding.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2023-01-02 09:12:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:12:01 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:12:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-02 14:42:01 --> Query error: Table 'ismartw1_crowd_funding.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2023-01-02 09:12:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:12:04 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:12:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-02 14:42:04 --> Query error: Table 'ismartw1_crowd_funding.company_profile' doesn't exist - Invalid query: SELECT *
FROM `company_profile`
WHERE `comp_id` != 0
DEBUG - 2023-01-02 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:12:14 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:42:14 --> Total execution time: 0.1972
DEBUG - 2023-01-02 09:12:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:12:26 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:42:26 --> Total execution time: 0.1413
DEBUG - 2023-01-02 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:13:56 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:43:56 --> Total execution time: 0.0416
DEBUG - 2023-01-02 09:29:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:29:07 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:59:07 --> Total execution time: 0.0633
DEBUG - 2023-01-02 09:29:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:29:07 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 14:59:07 --> Total execution time: 0.0380
DEBUG - 2023-01-02 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:32:11 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:02:11 --> Total execution time: 0.0625
DEBUG - 2023-01-02 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:33:04 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:03:04 --> Total execution time: 0.0543
DEBUG - 2023-01-02 09:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:35:46 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:05:46 --> Total execution time: 0.0698
DEBUG - 2023-01-02 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:35:55 --> No URI present. Default controller set.
DEBUG - 2023-01-02 09:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:05:55 --> Total execution time: 0.0443
DEBUG - 2023-01-02 09:36:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:06:21 --> Total execution time: 0.0348
DEBUG - 2023-01-02 09:36:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 09:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 09:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 09:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:06:23 --> Total execution time: 0.0526
DEBUG - 2023-01-02 10:00:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:00:53 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:30:53 --> Total execution time: 0.1092
DEBUG - 2023-01-02 10:02:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:02:25 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:32:25 --> Total execution time: 0.1622
DEBUG - 2023-01-02 10:02:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:32:35 --> Total execution time: 0.0326
DEBUG - 2023-01-02 10:02:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:02:46 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:32:46 --> Total execution time: 0.1216
DEBUG - 2023-01-02 10:05:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:05:08 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:35:08 --> Total execution time: 0.0496
DEBUG - 2023-01-02 10:05:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:05:41 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:35:41 --> Total execution time: 0.0331
DEBUG - 2023-01-02 10:06:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:06:02 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:36:02 --> Total execution time: 0.0419
DEBUG - 2023-01-02 10:06:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:06:25 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:36:25 --> Total execution time: 0.0381
DEBUG - 2023-01-02 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:07:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:07:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:07:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:07:10 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:08:23 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:38:23 --> Total execution time: 0.0584
DEBUG - 2023-01-02 10:08:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:08:30 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:38:30 --> Total execution time: 0.0958
DEBUG - 2023-01-02 10:10:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:10:45 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:40:45 --> Total execution time: 0.0443
DEBUG - 2023-01-02 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:11:51 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:41:51 --> Total execution time: 0.0458
DEBUG - 2023-01-02 10:12:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:12:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:12:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:12:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:12:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 10:12:06 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 10:13:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:13:05 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:43:05 --> Total execution time: 0.1032
DEBUG - 2023-01-02 10:13:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:13:22 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:43:22 --> Total execution time: 0.0489
DEBUG - 2023-01-02 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:13:28 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:43:28 --> Total execution time: 0.0475
DEBUG - 2023-01-02 10:15:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:15:47 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:45:47 --> Total execution time: 0.0713
DEBUG - 2023-01-02 10:20:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:20:46 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:50:46 --> Total execution time: 0.0854
DEBUG - 2023-01-02 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:22:37 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:52:37 --> Total execution time: 0.0313
DEBUG - 2023-01-02 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:22:55 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:52:55 --> Total execution time: 0.0792
DEBUG - 2023-01-02 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:26:24 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:56:24 --> Total execution time: 0.0438
DEBUG - 2023-01-02 10:28:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:28:53 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 15:58:54 --> Total execution time: 0.0426
DEBUG - 2023-01-02 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:32:17 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:02:17 --> Total execution time: 0.0486
DEBUG - 2023-01-02 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:33:43 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:03:43 --> Total execution time: 0.0465
DEBUG - 2023-01-02 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:03:53 --> Total execution time: 0.0358
DEBUG - 2023-01-02 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:34:01 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:04:01 --> Total execution time: 0.0345
DEBUG - 2023-01-02 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:04:42 --> Total execution time: 0.0419
DEBUG - 2023-01-02 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:35:59 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:05:59 --> Total execution time: 0.0517
DEBUG - 2023-01-02 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:36:55 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:06:55 --> Total execution time: 0.0425
DEBUG - 2023-01-02 10:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:37:18 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:07:18 --> Total execution time: 0.0392
DEBUG - 2023-01-02 10:38:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:38:23 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:08:23 --> Total execution time: 0.0400
DEBUG - 2023-01-02 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:39:12 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:09:12 --> Total execution time: 0.0425
DEBUG - 2023-01-02 10:39:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:39:42 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:09:42 --> Total execution time: 0.0485
DEBUG - 2023-01-02 10:40:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:40:59 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:10:59 --> Total execution time: 0.0407
DEBUG - 2023-01-02 10:57:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:57:49 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:27:49 --> Total execution time: 0.2458
DEBUG - 2023-01-02 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:58:49 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:28:49 --> Total execution time: 0.0994
DEBUG - 2023-01-02 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:58:58 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:28:58 --> Total execution time: 0.0434
DEBUG - 2023-01-02 10:59:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 10:59:43 --> No URI present. Default controller set.
DEBUG - 2023-01-02 10:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 10:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 10:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:29:43 --> Total execution time: 0.0829
DEBUG - 2023-01-02 11:00:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:00:11 --> No URI present. Default controller set.
DEBUG - 2023-01-02 11:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:30:12 --> Total execution time: 0.0859
DEBUG - 2023-01-02 11:07:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:07:05 --> No URI present. Default controller set.
DEBUG - 2023-01-02 11:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:37:05 --> Total execution time: 0.0510
DEBUG - 2023-01-02 11:08:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:08:55 --> No URI present. Default controller set.
DEBUG - 2023-01-02 11:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:38:55 --> Total execution time: 0.0575
DEBUG - 2023-01-02 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:40:51 --> Total execution time: 0.0486
DEBUG - 2023-01-02 11:11:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:11:14 --> No URI present. Default controller set.
DEBUG - 2023-01-02 11:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:41:14 --> Total execution time: 0.0351
DEBUG - 2023-01-02 11:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:43:28 --> Total execution time: 0.0766
DEBUG - 2023-01-02 11:13:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:43:34 --> Total execution time: 0.1646
DEBUG - 2023-01-02 11:16:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:46:29 --> Total execution time: 0.1317
DEBUG - 2023-01-02 11:16:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:46:31 --> Total execution time: 0.0393
DEBUG - 2023-01-02 11:16:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 11:16:31 --> 404 Page Not Found: Assets/images
DEBUG - 2023-01-02 11:16:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 11:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 11:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 11:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 16:46:37 --> Total execution time: 0.1692
DEBUG - 2023-01-02 12:09:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:09:23 --> No URI present. Default controller set.
DEBUG - 2023-01-02 12:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:39:23 --> Total execution time: 0.0965
DEBUG - 2023-01-02 12:09:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:39:43 --> Total execution time: 0.0379
DEBUG - 2023-01-02 12:10:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:00 --> No URI present. Default controller set.
DEBUG - 2023-01-02 12:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:40:00 --> Total execution time: 0.0321
DEBUG - 2023-01-02 12:10:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 12:10:27 --> Total execution time: 0.0451
DEBUG - 2023-01-02 12:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 12:10:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:40:38 --> Total execution time: 0.0306
DEBUG - 2023-01-02 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:10:40 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 12:10:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:40:53 --> Total execution time: 0.1192
DEBUG - 2023-01-02 12:10:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:10:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:10:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:11:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:11:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:11:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 12:11:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:11:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 12:11:32 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 12:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:42:58 --> Total execution time: 0.0392
DEBUG - 2023-01-02 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:56:15 --> Total execution time: 0.0784
DEBUG - 2023-01-02 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 12:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 12:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 17:56:18 --> Total execution time: 0.0404
DEBUG - 2023-01-02 18:59:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 18:59:33 --> No URI present. Default controller set.
DEBUG - 2023-01-02 18:59:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 18:59:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'ismartw1_crowd_funding'@'localhost' (using password: YES) C:\xampp\htdocs\gopal\crowd_funding\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2023-01-02 18:59:33 --> Unable to connect to the database
DEBUG - 2023-01-02 19:00:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:00:06 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:30:06 --> Total execution time: 0.1023
DEBUG - 2023-01-02 19:00:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:30:57 --> Total execution time: 0.0831
DEBUG - 2023-01-02 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:06:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:06:45 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:36:45 --> Total execution time: 0.0602
DEBUG - 2023-01-02 19:06:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:09:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:39:29 --> Total execution time: 0.0897
DEBUG - 2023-01-02 19:11:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:41:59 --> Total execution time: 0.0881
DEBUG - 2023-01-02 19:12:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:42:24 --> Total execution time: 0.0591
DEBUG - 2023-01-02 19:13:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:43:55 --> Total execution time: 0.0794
DEBUG - 2023-01-02 19:13:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:43:57 --> Total execution time: 0.0674
DEBUG - 2023-01-02 19:14:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:44:32 --> Total execution time: 0.0705
DEBUG - 2023-01-02 19:15:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:45:01 --> Total execution time: 0.0751
DEBUG - 2023-01-02 19:15:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:45:40 --> Total execution time: 0.0758
DEBUG - 2023-01-02 19:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:16:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:16:05 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 19:16:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:16:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:16:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:16:05 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:48:48 --> Total execution time: 0.0755
DEBUG - 2023-01-02 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:18:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:18:48 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-02 19:18:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:18:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:18:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:49:45 --> Total execution time: 0.0764
DEBUG - 2023-01-02 19:21:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:21:35 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:51:36 --> Total execution time: 1.1217
DEBUG - 2023-01-02 19:21:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:21:37 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:51:37 --> Total execution time: 0.1001
DEBUG - 2023-01-02 19:21:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:51:46 --> Total execution time: 0.5976
DEBUG - 2023-01-02 19:23:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:23:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:53:49 --> Total execution time: 0.0655
DEBUG - 2023-01-02 19:26:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:26:01 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:56:01 --> Total execution time: 0.0657
DEBUG - 2023-01-02 19:26:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:26:15 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:56:15 --> Total execution time: 0.0660
DEBUG - 2023-01-02 19:27:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:27:31 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:31 --> Total execution time: 0.0664
DEBUG - 2023-01-02 19:28:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:28:48 --> Total execution time: 0.0792
DEBUG - 2023-01-02 19:28:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:28:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:58:52 --> Total execution time: 0.0991
DEBUG - 2023-01-02 19:28:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:28:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:28:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:29:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:29:52 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:59:52 --> Total execution time: 0.0694
DEBUG - 2023-01-02 19:30:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:30:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:30:05 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:30:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:35:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:35:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:45:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:46:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:46:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:46:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:46:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:46:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:46:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:46:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:46:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:47:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:48:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:48:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:48:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:49:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:49:50 --> No URI present. Default controller set.
DEBUG - 2023-01-02 19:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:49:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:49:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:49:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:51:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:51:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:51:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:51:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:51:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:51:38 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 19:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 19:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 19:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 19:51:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 19:51:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 19:51:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:03:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:04:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:04:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:04:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:20 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:04:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:04:59 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:04:59 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:00 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:00 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:05:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:05:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:05:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:05:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:05:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:00 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:00 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:06:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:06:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:06:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:14:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:14:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:14:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:51:37 --> 404 Page Not Found: Assets/uploads
ERROR - 2023-01-02 20:51:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:51:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:51:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:51:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:52:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:18 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:52:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:52:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:52:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:52:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:53:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:53:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:08 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:53:08 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:53:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:09 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:53:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:53:09 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:53:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:09 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:53:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:53:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:53:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:05 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:06 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:24 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/website_esa
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 20:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:48 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:55:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:48 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 20:55:49 --> UTF-8 Support Enabled
ERROR - 2023-01-02 20:55:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:49 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 20:55:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 20:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 20:55:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:05:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:05:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:05:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:05:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:05:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:05:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:05:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:05:24 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:36 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:06:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:06:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:06:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:07:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:07:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:08:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:08:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:26:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:26:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:26:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:26:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:27:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:27:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:29:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:29:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:29:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:38:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:38:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:39:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:26 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:39:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:39:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:39:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:39:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:39:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:39:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:39:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:14 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:39 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 21:40:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:51 --> UTF-8 Support Enabled
ERROR - 2023-01-02 21:40:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:40:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 21:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:41:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:41:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:41:48 --> 404 Page Not Found: admin/Dynamic-page/assets
DEBUG - 2023-01-02 21:41:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:41:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:41:56 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 21:41:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 21:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 21:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 21:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 21:42:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 21:42:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:31:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:32:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:32:03 --> No URI present. Default controller set.
DEBUG - 2023-01-02 22:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:33:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:33:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:33:53 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:39:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:39:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:39:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:39:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:39:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:39:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:39:54 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:47:52 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:48:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:48:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:48:02 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:48:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:48:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:48:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 22:48:13 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 22:55:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:55:01 --> No URI present. Default controller set.
DEBUG - 2023-01-02 22:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:57:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:57:28 --> No URI present. Default controller set.
DEBUG - 2023-01-02 22:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 22:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:01:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:01:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:03:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:03:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:03:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:06:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:06:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:06:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:06:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:06:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:06:19 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:06:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:06:28 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:06:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:06:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:06:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:06:46 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:07:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:07:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:07:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:09:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:09:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:09:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:09:32 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:16:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:16:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:16:36 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:17:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:17:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:17:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:21 --> No URI present. Default controller set.
DEBUG - 2023-01-02 23:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:17:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:17:36 --> UTF-8 Support Enabled
ERROR - 2023-01-02 23:17:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 23:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:17:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:17:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 23:17:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:17:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:17:36 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-02 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:18:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:18:35 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:19:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:19:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:19:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:19:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:19:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:22:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:22:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:22:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:24:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:25:10 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:25:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:25:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:25:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:25:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:26:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:26:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:26:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:26:31 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:36:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:36:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:36:33 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:36:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:36:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:36:49 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:36:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:37:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:37:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:37:09 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:37:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:40:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:40:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:40:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:41:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:41:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:41:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:41:43 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:42:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:42:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:42:17 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:42:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:43:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:07 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:43:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-02 23:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:48:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:48:39 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:48:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:48:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:48:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:49:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:49:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:49:12 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:49:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:49:37 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:50:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:50:29 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:50:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:50:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:50:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:50:47 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:51:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:51:25 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:53:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:53:45 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:56:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:56:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:56:22 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:56:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:56:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:56:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:56:26 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:57:03 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:57:42 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2023-01-02 23:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-02 23:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-02 23:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-02 23:57:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-02 23:57:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-02 23:57:47 --> 404 Page Not Found: Assets/website_esa
