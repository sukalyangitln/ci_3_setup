<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-31 00:00:59 --> Total execution time: 0.1182
DEBUG - 2022-05-31 00:01:16 --> Total execution time: 0.0356
DEBUG - 2022-05-31 00:03:17 --> Total execution time: 0.0767
DEBUG - 2022-05-31 00:03:26 --> Total execution time: 0.0330
DEBUG - 2022-05-31 00:03:51 --> Total execution time: 0.0315
DEBUG - 2022-05-31 00:04:06 --> Total execution time: 0.1125
DEBUG - 2022-05-31 00:04:25 --> Total execution time: 0.0521
DEBUG - 2022-05-31 00:04:33 --> Total execution time: 0.0314
DEBUG - 2022-05-31 00:04:38 --> Total execution time: 0.0358
DEBUG - 2022-05-31 00:05:04 --> Total execution time: 0.0277
DEBUG - 2022-05-31 00:05:40 --> Total execution time: 0.0324
DEBUG - 2022-05-31 00:05:49 --> Total execution time: 0.0316
DEBUG - 2022-05-31 00:08:05 --> Total execution time: 0.0707
DEBUG - 2022-05-31 00:08:05 --> Total execution time: 0.0354
DEBUG - 2022-05-31 00:08:06 --> Total execution time: 0.0282
DEBUG - 2022-05-31 00:09:15 --> Total execution time: 0.0282
DEBUG - 2022-05-31 00:14:17 --> Total execution time: 0.0833
DEBUG - 2022-05-31 00:30:03 --> Total execution time: 0.3758
DEBUG - 2022-05-31 00:34:20 --> Total execution time: 0.1306
DEBUG - 2022-05-31 00:34:37 --> Total execution time: 0.0234
DEBUG - 2022-05-31 00:34:47 --> Total execution time: 0.0258
DEBUG - 2022-05-31 00:34:57 --> Total execution time: 0.0231
DEBUG - 2022-05-31 00:35:20 --> Total execution time: 0.0337
DEBUG - 2022-05-31 00:35:46 --> Total execution time: 0.0492
DEBUG - 2022-05-31 00:35:51 --> Total execution time: 0.0485
DEBUG - 2022-05-31 00:36:10 --> Total execution time: 0.0311
DEBUG - 2022-05-31 00:36:15 --> Total execution time: 0.0247
DEBUG - 2022-05-31 00:36:26 --> Total execution time: 0.0216
DEBUG - 2022-05-31 00:36:30 --> Total execution time: 0.0294
DEBUG - 2022-05-31 00:36:32 --> Total execution time: 0.0353
DEBUG - 2022-05-31 00:36:36 --> Total execution time: 0.0222
DEBUG - 2022-05-31 00:37:04 --> Total execution time: 0.0404
DEBUG - 2022-05-31 00:37:35 --> Total execution time: 0.0242
DEBUG - 2022-05-31 00:39:09 --> Total execution time: 0.0384
DEBUG - 2022-05-31 00:39:16 --> Total execution time: 0.0296
DEBUG - 2022-05-31 00:39:22 --> Total execution time: 0.0237
DEBUG - 2022-05-31 00:39:24 --> Total execution time: 0.0551
DEBUG - 2022-05-31 00:39:40 --> Total execution time: 0.0295
DEBUG - 2022-05-31 00:39:41 --> Total execution time: 0.0292
DEBUG - 2022-05-31 00:39:45 --> Total execution time: 0.0357
DEBUG - 2022-05-31 00:39:57 --> Total execution time: 0.0397
DEBUG - 2022-05-31 00:40:08 --> Total execution time: 0.0416
DEBUG - 2022-05-31 00:41:38 --> Total execution time: 0.0594
DEBUG - 2022-05-31 00:44:05 --> Total execution time: 0.0785
DEBUG - 2022-05-31 00:45:05 --> Total execution time: 0.0248
DEBUG - 2022-05-31 00:46:54 --> Total execution time: 0.0290
DEBUG - 2022-05-31 00:48:02 --> Total execution time: 0.0273
DEBUG - 2022-05-31 00:49:30 --> Total execution time: 0.0239
DEBUG - 2022-05-31 00:52:07 --> Total execution time: 0.0821
DEBUG - 2022-05-31 00:52:16 --> Total execution time: 0.0442
DEBUG - 2022-05-31 00:52:28 --> Total execution time: 0.0299
DEBUG - 2022-05-31 00:52:32 --> Total execution time: 0.0292
DEBUG - 2022-05-31 00:52:34 --> Total execution time: 0.0246
DEBUG - 2022-05-31 00:52:47 --> Total execution time: 0.0435
DEBUG - 2022-05-31 00:52:58 --> Total execution time: 0.0278
DEBUG - 2022-05-31 00:53:09 --> Total execution time: 0.0268
DEBUG - 2022-05-31 00:53:25 --> Total execution time: 0.0384
DEBUG - 2022-05-31 00:55:14 --> Total execution time: 0.0796
DEBUG - 2022-05-31 00:55:14 --> Total execution time: 0.0271
DEBUG - 2022-05-31 00:55:24 --> Total execution time: 0.0530
DEBUG - 2022-05-31 00:55:26 --> Total execution time: 0.0567
DEBUG - 2022-05-31 00:55:40 --> Total execution time: 0.0271
DEBUG - 2022-05-31 00:57:52 --> Total execution time: 0.0950
DEBUG - 2022-05-31 00:57:58 --> Total execution time: 0.0328
DEBUG - 2022-05-31 00:59:15 --> Total execution time: 0.0485
DEBUG - 2022-05-31 00:59:49 --> Total execution time: 0.0425
DEBUG - 2022-05-31 00:59:54 --> Total execution time: 0.0427
DEBUG - 2022-05-31 01:00:02 --> Total execution time: 0.1306
DEBUG - 2022-05-31 01:00:41 --> Total execution time: 0.0284
DEBUG - 2022-05-31 01:00:50 --> Total execution time: 0.0474
DEBUG - 2022-05-31 01:01:02 --> Total execution time: 0.0296
DEBUG - 2022-05-31 01:02:07 --> Total execution time: 0.0539
DEBUG - 2022-05-31 01:03:07 --> Total execution time: 0.0223
DEBUG - 2022-05-31 01:30:03 --> Total execution time: 0.2376
DEBUG - 2022-05-31 01:36:47 --> Total execution time: 0.0696
DEBUG - 2022-05-31 01:36:57 --> Total execution time: 0.0338
DEBUG - 2022-05-31 01:37:09 --> Total execution time: 0.0487
DEBUG - 2022-05-31 01:37:21 --> Total execution time: 0.0274
DEBUG - 2022-05-31 01:37:34 --> Total execution time: 0.0695
DEBUG - 2022-05-31 01:38:13 --> Total execution time: 0.0353
DEBUG - 2022-05-31 01:38:18 --> Total execution time: 0.0360
DEBUG - 2022-05-31 01:38:25 --> Total execution time: 0.0317
DEBUG - 2022-05-31 01:38:32 --> Total execution time: 0.0353
DEBUG - 2022-05-31 01:38:45 --> Total execution time: 0.0287
DEBUG - 2022-05-31 01:40:27 --> Total execution time: 0.0264
DEBUG - 2022-05-31 01:40:27 --> Total execution time: 0.0346
DEBUG - 2022-05-31 01:40:27 --> Total execution time: 0.0205
DEBUG - 2022-05-31 01:40:27 --> Total execution time: 0.0203
DEBUG - 2022-05-31 01:56:40 --> Total execution time: 0.1353
DEBUG - 2022-05-31 01:56:41 --> Total execution time: 0.0218
DEBUG - 2022-05-31 01:57:04 --> Total execution time: 0.0255
DEBUG - 2022-05-31 01:57:17 --> Total execution time: 0.0287
DEBUG - 2022-05-31 01:57:28 --> Total execution time: 4.1162
DEBUG - 2022-05-31 01:58:03 --> Total execution time: 0.0363
DEBUG - 2022-05-31 01:58:27 --> Total execution time: 0.0759
DEBUG - 2022-05-31 02:11:21 --> Total execution time: 0.2627
DEBUG - 2022-05-31 02:11:24 --> Total execution time: 0.0278
DEBUG - 2022-05-31 02:11:44 --> Total execution time: 4.3632
DEBUG - 2022-05-31 02:12:32 --> Total execution time: 0.0370
DEBUG - 2022-05-31 02:14:08 --> Total execution time: 4.3284
DEBUG - 2022-05-31 02:15:20 --> Total execution time: 0.0515
DEBUG - 2022-05-31 02:15:45 --> Total execution time: 0.0272
DEBUG - 2022-05-31 02:16:09 --> Total execution time: 0.0274
DEBUG - 2022-05-31 02:16:25 --> Total execution time: 4.4169
DEBUG - 2022-05-31 02:27:56 --> Total execution time: 0.3020
DEBUG - 2022-05-31 02:29:37 --> Total execution time: 0.0698
DEBUG - 2022-05-31 02:30:02 --> Total execution time: 0.0509
DEBUG - 2022-05-31 02:30:26 --> Total execution time: 0.0896
DEBUG - 2022-05-31 02:30:30 --> Total execution time: 0.0361
DEBUG - 2022-05-31 02:30:44 --> Total execution time: 0.0328
DEBUG - 2022-05-31 02:30:53 --> Total execution time: 0.0740
DEBUG - 2022-05-31 02:31:00 --> Total execution time: 0.0402
DEBUG - 2022-05-31 02:31:15 --> Total execution time: 0.0348
DEBUG - 2022-05-31 02:31:42 --> Total execution time: 0.0318
DEBUG - 2022-05-31 02:31:45 --> Total execution time: 0.0314
DEBUG - 2022-05-31 02:32:08 --> Total execution time: 1.4886
DEBUG - 2022-05-31 02:32:15 --> Total execution time: 0.0286
DEBUG - 2022-05-31 02:32:22 --> Total execution time: 0.0642
DEBUG - 2022-05-31 02:32:28 --> Total execution time: 0.0312
DEBUG - 2022-05-31 02:32:33 --> Total execution time: 0.0350
DEBUG - 2022-05-31 02:44:53 --> Total execution time: 0.1589
DEBUG - 2022-05-31 02:45:45 --> Total execution time: 0.0254
DEBUG - 2022-05-31 02:48:27 --> Total execution time: 0.0865
DEBUG - 2022-05-31 02:55:53 --> Total execution time: 0.1104
DEBUG - 2022-05-31 02:56:19 --> Total execution time: 0.0287
DEBUG - 2022-05-31 02:57:02 --> Total execution time: 0.0232
DEBUG - 2022-05-31 02:58:59 --> Total execution time: 0.0252
DEBUG - 2022-05-31 02:59:20 --> Total execution time: 0.0422
DEBUG - 2022-05-31 03:00:32 --> Total execution time: 0.0305
DEBUG - 2022-05-31 03:00:40 --> Total execution time: 0.0246
DEBUG - 2022-05-31 03:01:19 --> Total execution time: 0.0509
DEBUG - 2022-05-31 03:01:27 --> Total execution time: 0.0686
DEBUG - 2022-05-31 03:01:32 --> Total execution time: 0.0388
DEBUG - 2022-05-31 03:01:36 --> Total execution time: 0.0452
DEBUG - 2022-05-31 03:01:51 --> Total execution time: 0.0299
DEBUG - 2022-05-31 03:01:53 --> Total execution time: 0.0286
DEBUG - 2022-05-31 03:01:57 --> Total execution time: 0.0304
DEBUG - 2022-05-31 03:02:08 --> Total execution time: 0.0323
DEBUG - 2022-05-31 03:02:10 --> Total execution time: 0.0396
DEBUG - 2022-05-31 03:02:13 --> Total execution time: 0.0353
DEBUG - 2022-05-31 03:02:22 --> Total execution time: 0.0290
DEBUG - 2022-05-31 03:02:24 --> Total execution time: 0.0294
DEBUG - 2022-05-31 03:05:29 --> Total execution time: 0.3567
DEBUG - 2022-05-31 03:05:34 --> Total execution time: 0.0352
DEBUG - 2022-05-31 03:05:44 --> Total execution time: 0.0357
DEBUG - 2022-05-31 03:05:47 --> Total execution time: 0.0455
DEBUG - 2022-05-31 03:06:02 --> Total execution time: 0.2613
DEBUG - 2022-05-31 03:06:05 --> Total execution time: 0.0274
DEBUG - 2022-05-31 03:06:08 --> Total execution time: 0.0316
DEBUG - 2022-05-31 03:06:11 --> Total execution time: 0.0407
DEBUG - 2022-05-31 03:06:26 --> Total execution time: 0.2561
DEBUG - 2022-05-31 03:06:44 --> Total execution time: 0.1040
DEBUG - 2022-05-31 03:06:55 --> Total execution time: 0.0453
DEBUG - 2022-05-31 03:07:02 --> Total execution time: 0.0536
DEBUG - 2022-05-31 03:07:06 --> Total execution time: 0.0407
DEBUG - 2022-05-31 03:07:11 --> Total execution time: 0.8135
DEBUG - 2022-05-31 03:07:38 --> Total execution time: 2.4796
DEBUG - 2022-05-31 03:08:14 --> Total execution time: 2.4769
DEBUG - 2022-05-31 03:08:54 --> Total execution time: 0.0331
DEBUG - 2022-05-31 03:09:11 --> Total execution time: 0.0366
DEBUG - 2022-05-31 03:09:51 --> Total execution time: 0.0290
DEBUG - 2022-05-31 03:10:56 --> Total execution time: 0.0458
DEBUG - 2022-05-31 03:11:11 --> Total execution time: 0.0705
DEBUG - 2022-05-31 03:13:22 --> Total execution time: 0.1012
DEBUG - 2022-05-31 03:19:56 --> Total execution time: 0.0316
DEBUG - 2022-05-31 03:20:10 --> Total execution time: 0.0397
DEBUG - 2022-05-31 03:20:14 --> Total execution time: 0.0510
DEBUG - 2022-05-31 03:20:19 --> Total execution time: 0.0425
DEBUG - 2022-05-31 03:30:03 --> Total execution time: 0.1204
DEBUG - 2022-05-31 03:45:14 --> Total execution time: 0.0836
DEBUG - 2022-05-31 03:45:14 --> Total execution time: 0.0211
DEBUG - 2022-05-31 03:49:45 --> Total execution time: 0.0912
DEBUG - 2022-05-31 04:30:03 --> Total execution time: 0.2718
DEBUG - 2022-05-31 04:52:17 --> Total execution time: 0.1389
DEBUG - 2022-05-31 05:25:36 --> Total execution time: 0.2010
DEBUG - 2022-05-31 05:30:03 --> Total execution time: 0.1531
DEBUG - 2022-05-31 06:30:02 --> Total execution time: 0.2823
DEBUG - 2022-05-31 06:37:02 --> Total execution time: 0.0326
DEBUG - 2022-05-31 06:37:11 --> Total execution time: 0.0245
DEBUG - 2022-05-31 06:37:15 --> Total execution time: 0.0312
DEBUG - 2022-05-31 06:39:59 --> Total execution time: 0.0252
DEBUG - 2022-05-31 06:40:22 --> Total execution time: 0.0691
DEBUG - 2022-05-31 06:40:36 --> Total execution time: 0.0455
DEBUG - 2022-05-31 06:40:41 --> Total execution time: 0.0388
DEBUG - 2022-05-31 06:40:53 --> Total execution time: 0.0182
DEBUG - 2022-05-31 06:40:55 --> Total execution time: 0.0244
DEBUG - 2022-05-31 06:49:23 --> Total execution time: 0.1231
DEBUG - 2022-05-31 06:49:30 --> Total execution time: 0.0222
DEBUG - 2022-05-31 06:52:51 --> Total execution time: 0.0304
DEBUG - 2022-05-31 06:53:16 --> Total execution time: 0.0456
DEBUG - 2022-05-31 06:53:33 --> Total execution time: 0.0330
DEBUG - 2022-05-31 06:57:02 --> Total execution time: 0.0635
DEBUG - 2022-05-31 07:03:34 --> Total execution time: 0.0831
DEBUG - 2022-05-31 07:03:37 --> Total execution time: 0.0294
DEBUG - 2022-05-31 07:03:50 --> Total execution time: 0.0312
DEBUG - 2022-05-31 07:03:56 --> Total execution time: 0.0637
DEBUG - 2022-05-31 07:04:34 --> Total execution time: 0.0380
DEBUG - 2022-05-31 07:06:10 --> Total execution time: 0.0347
DEBUG - 2022-05-31 07:06:13 --> Total execution time: 0.0130
DEBUG - 2022-05-31 07:06:22 --> Total execution time: 0.0308
DEBUG - 2022-05-31 07:06:29 --> Total execution time: 0.0315
DEBUG - 2022-05-31 07:06:37 --> Total execution time: 0.0353
DEBUG - 2022-05-31 07:06:48 --> Total execution time: 0.0280
DEBUG - 2022-05-31 07:06:51 --> Total execution time: 0.0272
DEBUG - 2022-05-31 07:06:55 --> Total execution time: 0.0286
DEBUG - 2022-05-31 07:06:57 --> Total execution time: 0.0362
DEBUG - 2022-05-31 07:07:13 --> Total execution time: 0.0341
DEBUG - 2022-05-31 07:07:15 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:07:23 --> Total execution time: 0.0266
DEBUG - 2022-05-31 07:07:30 --> Total execution time: 0.0444
DEBUG - 2022-05-31 07:07:48 --> Total execution time: 0.0494
DEBUG - 2022-05-31 07:20:58 --> Total execution time: 0.0785
DEBUG - 2022-05-31 07:21:06 --> Total execution time: 0.0420
DEBUG - 2022-05-31 07:30:04 --> Total execution time: 0.2051
DEBUG - 2022-05-31 07:38:51 --> Total execution time: 0.0760
DEBUG - 2022-05-31 07:39:16 --> Total execution time: 0.0265
DEBUG - 2022-05-31 07:40:47 --> Total execution time: 0.0539
DEBUG - 2022-05-31 07:48:31 --> Total execution time: 0.0198
DEBUG - 2022-05-31 07:48:31 --> Total execution time: 0.0191
DEBUG - 2022-05-31 07:48:38 --> Total execution time: 0.0181
DEBUG - 2022-05-31 07:48:49 --> Total execution time: 0.0547
DEBUG - 2022-05-31 07:48:56 --> Total execution time: 0.0406
DEBUG - 2022-05-31 07:49:03 --> Total execution time: 0.0462
DEBUG - 2022-05-31 07:49:16 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:49:23 --> Total execution time: 0.0391
DEBUG - 2022-05-31 07:49:41 --> Total execution time: 0.0418
DEBUG - 2022-05-31 07:49:49 --> Total execution time: 0.0420
DEBUG - 2022-05-31 07:50:09 --> Total execution time: 0.0260
DEBUG - 2022-05-31 07:51:34 --> Total execution time: 0.0257
DEBUG - 2022-05-31 07:51:46 --> Total execution time: 0.0230
DEBUG - 2022-05-31 07:51:50 --> Total execution time: 0.0366
DEBUG - 2022-05-31 07:51:53 --> Total execution time: 0.0208
DEBUG - 2022-05-31 07:52:05 --> Total execution time: 0.0237
DEBUG - 2022-05-31 07:52:24 --> Total execution time: 0.0216
DEBUG - 2022-05-31 07:52:34 --> Total execution time: 0.0267
DEBUG - 2022-05-31 07:52:36 --> Total execution time: 0.0228
DEBUG - 2022-05-31 07:52:50 --> Total execution time: 0.0309
DEBUG - 2022-05-31 07:52:50 --> Total execution time: 0.0251
DEBUG - 2022-05-31 07:52:53 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:52:56 --> Total execution time: 0.0423
DEBUG - 2022-05-31 07:53:02 --> Total execution time: 0.0569
DEBUG - 2022-05-31 07:53:07 --> Total execution time: 0.0286
DEBUG - 2022-05-31 07:53:13 --> Total execution time: 0.0453
DEBUG - 2022-05-31 07:53:28 --> Total execution time: 0.0654
DEBUG - 2022-05-31 07:54:07 --> Total execution time: 0.0212
DEBUG - 2022-05-31 07:54:40 --> Total execution time: 0.0325
DEBUG - 2022-05-31 07:55:11 --> Total execution time: 0.0230
DEBUG - 2022-05-31 07:55:30 --> Total execution time: 0.0302
DEBUG - 2022-05-31 07:55:48 --> Total execution time: 0.0213
DEBUG - 2022-05-31 07:56:07 --> Total execution time: 0.0281
DEBUG - 2022-05-31 07:56:26 --> Total execution time: 0.0285
DEBUG - 2022-05-31 07:58:27 --> Total execution time: 0.0421
DEBUG - 2022-05-31 07:58:37 --> Total execution time: 0.0262
DEBUG - 2022-05-31 07:58:43 --> Total execution time: 0.0304
DEBUG - 2022-05-31 07:58:46 --> Total execution time: 0.0376
DEBUG - 2022-05-31 07:58:51 --> Total execution time: 0.0255
DEBUG - 2022-05-31 07:59:25 --> Total execution time: 0.0249
DEBUG - 2022-05-31 07:59:43 --> Total execution time: 0.0354
DEBUG - 2022-05-31 07:59:43 --> Total execution time: 0.0203
DEBUG - 2022-05-31 07:59:50 --> Total execution time: 0.0196
DEBUG - 2022-05-31 07:59:58 --> Total execution time: 0.0286
DEBUG - 2022-05-31 08:00:10 --> Total execution time: 0.0354
DEBUG - 2022-05-31 08:00:13 --> Total execution time: 0.0376
DEBUG - 2022-05-31 08:00:13 --> Total execution time: 0.0435
DEBUG - 2022-05-31 08:00:20 --> Total execution time: 0.0239
DEBUG - 2022-05-31 08:00:23 --> Total execution time: 0.0307
DEBUG - 2022-05-31 08:00:23 --> Total execution time: 0.0309
DEBUG - 2022-05-31 08:00:26 --> Total execution time: 0.0372
DEBUG - 2022-05-31 08:00:31 --> Total execution time: 0.0239
DEBUG - 2022-05-31 08:00:41 --> Total execution time: 0.0459
DEBUG - 2022-05-31 08:00:51 --> Total execution time: 0.0243
DEBUG - 2022-05-31 08:01:22 --> Total execution time: 0.0506
DEBUG - 2022-05-31 08:04:48 --> Total execution time: 0.0262
DEBUG - 2022-05-31 08:04:52 --> Total execution time: 0.0198
DEBUG - 2022-05-31 08:04:52 --> Total execution time: 0.0185
DEBUG - 2022-05-31 08:04:54 --> Total execution time: 0.0184
DEBUG - 2022-05-31 08:04:54 --> Total execution time: 0.0197
DEBUG - 2022-05-31 08:04:54 --> Total execution time: 0.0253
DEBUG - 2022-05-31 08:05:24 --> Total execution time: 0.0283
DEBUG - 2022-05-31 08:05:25 --> Total execution time: 0.0254
DEBUG - 2022-05-31 08:05:26 --> Total execution time: 0.0248
DEBUG - 2022-05-31 08:05:33 --> Total execution time: 0.0565
DEBUG - 2022-05-31 08:05:34 --> Total execution time: 0.0188
DEBUG - 2022-05-31 08:05:35 --> Total execution time: 0.0186
DEBUG - 2022-05-31 08:05:41 --> Total execution time: 0.0517
DEBUG - 2022-05-31 08:05:41 --> Total execution time: 0.0178
DEBUG - 2022-05-31 08:05:43 --> Total execution time: 0.0159
DEBUG - 2022-05-31 08:06:20 --> Total execution time: 0.0407
DEBUG - 2022-05-31 08:08:04 --> Total execution time: 0.0572
DEBUG - 2022-05-31 08:08:23 --> Total execution time: 0.0465
DEBUG - 2022-05-31 08:08:23 --> Total execution time: 0.0479
DEBUG - 2022-05-31 08:08:25 --> Total execution time: 0.0184
DEBUG - 2022-05-31 08:08:32 --> Total execution time: 0.0224
DEBUG - 2022-05-31 08:08:33 --> Total execution time: 0.0581
DEBUG - 2022-05-31 08:08:39 --> Total execution time: 0.0299
DEBUG - 2022-05-31 08:08:39 --> Total execution time: 0.0233
DEBUG - 2022-05-31 08:08:41 --> Total execution time: 0.0185
DEBUG - 2022-05-31 08:09:05 --> Total execution time: 0.0286
DEBUG - 2022-05-31 08:09:14 --> Total execution time: 0.0272
DEBUG - 2022-05-31 08:10:19 --> Total execution time: 0.0746
DEBUG - 2022-05-31 08:10:36 --> Total execution time: 0.0250
DEBUG - 2022-05-31 08:11:50 --> Total execution time: 0.0338
DEBUG - 2022-05-31 08:12:26 --> Total execution time: 0.0346
DEBUG - 2022-05-31 08:15:10 --> Total execution time: 0.0747
DEBUG - 2022-05-31 08:17:41 --> Total execution time: 0.1204
DEBUG - 2022-05-31 08:19:42 --> Total execution time: 0.0633
DEBUG - 2022-05-31 08:21:14 --> Total execution time: 0.0357
DEBUG - 2022-05-31 08:24:49 --> Total execution time: 0.0826
DEBUG - 2022-05-31 08:24:49 --> Total execution time: 0.0309
DEBUG - 2022-05-31 08:25:11 --> Total execution time: 0.0254
DEBUG - 2022-05-31 08:27:11 --> Total execution time: 0.0284
DEBUG - 2022-05-31 08:27:12 --> Total execution time: 0.0223
DEBUG - 2022-05-31 08:27:16 --> Total execution time: 0.0337
DEBUG - 2022-05-31 08:28:14 --> Total execution time: 0.0337
DEBUG - 2022-05-31 08:28:22 --> Total execution time: 0.0537
DEBUG - 2022-05-31 08:28:44 --> Total execution time: 0.0674
DEBUG - 2022-05-31 08:28:52 --> Total execution time: 0.0266
DEBUG - 2022-05-31 08:29:06 --> Total execution time: 0.0428
DEBUG - 2022-05-31 08:30:02 --> Total execution time: 0.0346
DEBUG - 2022-05-31 08:30:50 --> Total execution time: 0.0306
DEBUG - 2022-05-31 08:30:56 --> Total execution time: 0.0279
DEBUG - 2022-05-31 08:31:03 --> Total execution time: 0.0351
DEBUG - 2022-05-31 08:31:05 --> Total execution time: 0.0362
DEBUG - 2022-05-31 08:31:08 --> Total execution time: 0.0330
DEBUG - 2022-05-31 08:31:10 --> Total execution time: 0.0328
DEBUG - 2022-05-31 08:31:11 --> Total execution time: 0.0291
DEBUG - 2022-05-31 08:31:13 --> Total execution time: 0.0588
DEBUG - 2022-05-31 08:31:15 --> Total execution time: 0.0349
DEBUG - 2022-05-31 08:32:13 --> Total execution time: 0.0497
DEBUG - 2022-05-31 08:32:17 --> Total execution time: 0.0300
DEBUG - 2022-05-31 08:32:44 --> Total execution time: 0.0281
DEBUG - 2022-05-31 08:32:56 --> Total execution time: 0.0517
DEBUG - 2022-05-31 08:33:11 --> Total execution time: 0.0269
DEBUG - 2022-05-31 08:33:31 --> Total execution time: 0.0243
DEBUG - 2022-05-31 08:34:11 --> Total execution time: 0.0434
DEBUG - 2022-05-31 08:34:27 --> Total execution time: 0.0434
DEBUG - 2022-05-31 08:34:34 --> Total execution time: 0.0327
DEBUG - 2022-05-31 08:37:08 --> Total execution time: 0.0282
DEBUG - 2022-05-31 08:37:11 --> Total execution time: 0.0306
DEBUG - 2022-05-31 08:37:15 --> Total execution time: 0.0317
DEBUG - 2022-05-31 08:37:21 --> Total execution time: 0.0568
DEBUG - 2022-05-31 08:37:31 --> Total execution time: 0.0330
DEBUG - 2022-05-31 08:37:35 --> Total execution time: 0.0310
DEBUG - 2022-05-31 08:38:04 --> Total execution time: 0.0366
DEBUG - 2022-05-31 08:38:52 --> Total execution time: 0.0391
DEBUG - 2022-05-31 08:40:29 --> Total execution time: 0.0390
DEBUG - 2022-05-31 08:40:39 --> Total execution time: 0.0279
DEBUG - 2022-05-31 08:41:12 --> Total execution time: 0.0318
DEBUG - 2022-05-31 08:41:22 --> Total execution time: 0.0352
DEBUG - 2022-05-31 08:41:48 --> Total execution time: 0.0384
DEBUG - 2022-05-31 08:42:17 --> Total execution time: 0.0641
DEBUG - 2022-05-31 08:42:21 --> Total execution time: 0.0419
DEBUG - 2022-05-31 08:42:34 --> Total execution time: 0.0280
DEBUG - 2022-05-31 08:45:06 --> Total execution time: 0.0938
DEBUG - 2022-05-31 08:45:07 --> Total execution time: 0.0325
DEBUG - 2022-05-31 08:45:12 --> Total execution time: 0.0144
DEBUG - 2022-05-31 08:45:21 --> Total execution time: 0.0338
DEBUG - 2022-05-31 08:45:27 --> Total execution time: 0.0456
DEBUG - 2022-05-31 08:46:28 --> Total execution time: 0.0500
DEBUG - 2022-05-31 08:46:32 --> Total execution time: 0.0330
DEBUG - 2022-05-31 08:46:34 --> Total execution time: 0.0373
DEBUG - 2022-05-31 08:46:58 --> Total execution time: 0.0263
DEBUG - 2022-05-31 08:47:05 --> Total execution time: 0.0267
DEBUG - 2022-05-31 08:47:27 --> Total execution time: 0.0273
DEBUG - 2022-05-31 08:47:32 --> Total execution time: 0.0384
DEBUG - 2022-05-31 08:47:36 --> Total execution time: 0.0784
DEBUG - 2022-05-31 08:48:13 --> Total execution time: 0.0702
DEBUG - 2022-05-31 08:53:15 --> Total execution time: 0.1274
DEBUG - 2022-05-31 08:53:15 --> Total execution time: 0.0273
DEBUG - 2022-05-31 08:53:16 --> Total execution time: 0.0252
DEBUG - 2022-05-31 08:53:18 --> Total execution time: 0.0266
DEBUG - 2022-05-31 08:53:20 --> Total execution time: 0.0255
DEBUG - 2022-05-31 08:53:30 --> Total execution time: 0.0306
DEBUG - 2022-05-31 08:53:31 --> Total execution time: 0.0252
DEBUG - 2022-05-31 08:53:32 --> Total execution time: 0.0254
DEBUG - 2022-05-31 08:56:29 --> Total execution time: 0.0829
DEBUG - 2022-05-31 08:56:37 --> Total execution time: 0.0247
DEBUG - 2022-05-31 08:59:21 --> Total execution time: 0.0889
DEBUG - 2022-05-31 08:59:25 --> Total execution time: 0.0250
DEBUG - 2022-05-31 08:59:29 --> Total execution time: 0.0318
DEBUG - 2022-05-31 08:59:31 --> Total execution time: 0.0545
DEBUG - 2022-05-31 08:59:45 --> Total execution time: 0.1364
DEBUG - 2022-05-31 09:00:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 09:00:57 --> Total execution time: 0.0742
DEBUG - 2022-05-31 09:01:20 --> Total execution time: 0.0313
DEBUG - 2022-05-31 09:01:27 --> Total execution time: 0.0441
DEBUG - 2022-05-31 09:08:39 --> Total execution time: 2.5450
DEBUG - 2022-05-31 09:16:52 --> Total execution time: 0.1206
DEBUG - 2022-05-31 09:21:59 --> Total execution time: 0.1396
DEBUG - 2022-05-31 09:22:14 --> Total execution time: 0.0272
DEBUG - 2022-05-31 09:22:24 --> Total execution time: 0.0241
DEBUG - 2022-05-31 09:22:37 --> Total execution time: 0.0498
DEBUG - 2022-05-31 09:23:01 --> Total execution time: 0.0450
DEBUG - 2022-05-31 09:23:10 --> Total execution time: 0.0393
DEBUG - 2022-05-31 09:23:34 --> Total execution time: 0.0255
DEBUG - 2022-05-31 09:25:20 --> Total execution time: 0.0223
DEBUG - 2022-05-31 09:30:02 --> Total execution time: 0.2126
DEBUG - 2022-05-31 09:30:32 --> Total execution time: 0.0309
DEBUG - 2022-05-31 09:31:40 --> Total execution time: 0.0536
DEBUG - 2022-05-31 09:31:46 --> Total execution time: 0.0348
DEBUG - 2022-05-31 09:31:55 --> Total execution time: 0.0320
DEBUG - 2022-05-31 09:32:02 --> Total execution time: 0.0477
DEBUG - 2022-05-31 09:32:14 --> Total execution time: 0.0252
DEBUG - 2022-05-31 09:38:18 --> Total execution time: 0.0688
DEBUG - 2022-05-31 09:43:04 --> Total execution time: 0.1007
DEBUG - 2022-05-31 09:48:11 --> Total execution time: 0.0850
DEBUG - 2022-05-31 09:48:16 --> Total execution time: 0.0380
DEBUG - 2022-05-31 09:48:38 --> Total execution time: 0.0619
DEBUG - 2022-05-31 09:48:44 --> Total execution time: 0.0370
DEBUG - 2022-05-31 09:48:48 --> Total execution time: 0.0305
DEBUG - 2022-05-31 09:50:24 --> Total execution time: 0.0441
DEBUG - 2022-05-31 09:50:27 --> Total execution time: 0.0315
DEBUG - 2022-05-31 09:50:41 --> Total execution time: 0.0344
DEBUG - 2022-05-31 09:51:03 --> Total execution time: 0.0404
DEBUG - 2022-05-31 09:51:04 --> Total execution time: 0.0247
DEBUG - 2022-05-31 09:55:02 --> Total execution time: 0.0842
DEBUG - 2022-05-31 09:55:59 --> Total execution time: 0.0225
DEBUG - 2022-05-31 09:56:07 --> Total execution time: 0.0197
DEBUG - 2022-05-31 09:56:33 --> Total execution time: 0.0244
DEBUG - 2022-05-31 09:56:51 --> Total execution time: 0.0243
DEBUG - 2022-05-31 09:57:03 --> Total execution time: 0.0232
DEBUG - 2022-05-31 09:57:41 --> Total execution time: 0.0306
DEBUG - 2022-05-31 09:57:41 --> Total execution time: 0.0370
DEBUG - 2022-05-31 09:57:41 --> Total execution time: 0.0224
DEBUG - 2022-05-31 09:57:42 --> Total execution time: 0.0200
DEBUG - 2022-05-31 09:57:44 --> Total execution time: 0.0245
DEBUG - 2022-05-31 09:57:50 --> Total execution time: 0.0192
DEBUG - 2022-05-31 09:58:02 --> Total execution time: 0.0309
DEBUG - 2022-05-31 09:58:43 --> Total execution time: 0.0264
DEBUG - 2022-05-31 09:58:43 --> Total execution time: 0.0164
DEBUG - 2022-05-31 09:59:04 --> Total execution time: 0.0272
DEBUG - 2022-05-31 09:59:07 --> Total execution time: 0.0344
DEBUG - 2022-05-31 09:59:09 --> Total execution time: 0.0255
DEBUG - 2022-05-31 09:59:23 --> Total execution time: 0.0385
DEBUG - 2022-05-31 09:59:27 --> Total execution time: 0.0248
DEBUG - 2022-05-31 09:59:35 --> Total execution time: 0.0376
DEBUG - 2022-05-31 09:59:39 --> Total execution time: 0.0260
DEBUG - 2022-05-31 10:00:41 --> Total execution time: 0.0321
DEBUG - 2022-05-31 10:00:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:00:42 --> Total execution time: 0.0248
DEBUG - 2022-05-31 10:00:50 --> Total execution time: 0.1843
DEBUG - 2022-05-31 10:01:46 --> Total execution time: 0.0239
DEBUG - 2022-05-31 10:01:48 --> Total execution time: 0.0285
DEBUG - 2022-05-31 10:02:06 --> Total execution time: 0.0740
DEBUG - 2022-05-31 10:02:20 --> Total execution time: 0.1030
DEBUG - 2022-05-31 10:02:27 --> Total execution time: 0.0565
DEBUG - 2022-05-31 10:02:32 --> Total execution time: 0.0691
DEBUG - 2022-05-31 10:02:35 --> Total execution time: 0.0282
DEBUG - 2022-05-31 10:03:35 --> Total execution time: 0.1689
DEBUG - 2022-05-31 10:03:40 --> Total execution time: 0.0330
DEBUG - 2022-05-31 10:03:42 --> Total execution time: 0.0299
DEBUG - 2022-05-31 10:04:17 --> Total execution time: 0.0292
DEBUG - 2022-05-31 10:04:50 --> Total execution time: 0.0331
DEBUG - 2022-05-31 10:09:06 --> Total execution time: 0.0296
DEBUG - 2022-05-31 10:09:25 --> Total execution time: 0.0285
DEBUG - 2022-05-31 10:09:28 --> Total execution time: 0.0339
DEBUG - 2022-05-31 10:09:31 --> Total execution time: 0.0316
DEBUG - 2022-05-31 10:09:36 --> Total execution time: 0.0720
DEBUG - 2022-05-31 10:09:44 --> Total execution time: 0.0743
DEBUG - 2022-05-31 10:10:37 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:10:37 --> Total execution time: 0.0561
DEBUG - 2022-05-31 10:11:00 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:11:01 --> Total execution time: 0.0707
DEBUG - 2022-05-31 10:11:13 --> Total execution time: 0.0642
DEBUG - 2022-05-31 10:11:17 --> Total execution time: 0.0596
DEBUG - 2022-05-31 10:11:20 --> Total execution time: 0.0591
DEBUG - 2022-05-31 10:11:25 --> Total execution time: 0.0393
DEBUG - 2022-05-31 10:11:32 --> Total execution time: 0.0336
DEBUG - 2022-05-31 10:11:47 --> Total execution time: 0.0407
DEBUG - 2022-05-31 10:13:48 --> Total execution time: 0.0843
DEBUG - 2022-05-31 10:13:53 --> Total execution time: 0.0387
DEBUG - 2022-05-31 10:14:13 --> Total execution time: 0.0291
DEBUG - 2022-05-31 10:16:33 --> Total execution time: 0.0278
DEBUG - 2022-05-31 10:17:20 --> Total execution time: 0.0398
DEBUG - 2022-05-31 10:17:51 --> Total execution time: 0.0411
DEBUG - 2022-05-31 10:20:58 --> Total execution time: 0.1177
DEBUG - 2022-05-31 10:21:09 --> Total execution time: 0.0366
DEBUG - 2022-05-31 10:21:35 --> Total execution time: 0.0225
DEBUG - 2022-05-31 10:21:36 --> Total execution time: 0.0233
DEBUG - 2022-05-31 10:21:44 --> Total execution time: 0.0337
DEBUG - 2022-05-31 10:21:55 --> Total execution time: 0.0337
DEBUG - 2022-05-31 10:22:14 --> Total execution time: 0.0181
DEBUG - 2022-05-31 10:22:19 --> Total execution time: 0.0306
DEBUG - 2022-05-31 10:22:43 --> Total execution time: 0.0227
DEBUG - 2022-05-31 10:23:04 --> Total execution time: 0.0307
DEBUG - 2022-05-31 10:23:08 --> Total execution time: 0.0350
DEBUG - 2022-05-31 10:23:23 --> Total execution time: 0.0247
DEBUG - 2022-05-31 10:24:29 --> Total execution time: 0.0293
DEBUG - 2022-05-31 10:24:40 --> Total execution time: 0.0521
DEBUG - 2022-05-31 10:24:42 --> Total execution time: 0.0684
DEBUG - 2022-05-31 10:24:44 --> Total execution time: 0.0661
DEBUG - 2022-05-31 10:24:58 --> Total execution time: 0.0301
DEBUG - 2022-05-31 10:27:42 --> Total execution time: 0.0287
DEBUG - 2022-05-31 10:28:06 --> Total execution time: 0.0245
DEBUG - 2022-05-31 10:28:23 --> Total execution time: 0.0263
DEBUG - 2022-05-31 10:28:27 --> Total execution time: 0.0260
DEBUG - 2022-05-31 10:28:56 --> Total execution time: 0.0287
DEBUG - 2022-05-31 10:28:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:28:57 --> Total execution time: 0.0255
DEBUG - 2022-05-31 10:29:50 --> Total execution time: 0.0266
DEBUG - 2022-05-31 10:29:52 --> Total execution time: 0.0342
DEBUG - 2022-05-31 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:02 --> Total execution time: 0.0337
DEBUG - 2022-05-31 00:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:10 --> Total execution time: 0.1118
DEBUG - 2022-05-31 00:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:24 --> Total execution time: 0.0386
DEBUG - 2022-05-31 00:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:25 --> Total execution time: 0.0446
DEBUG - 2022-05-31 00:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:43 --> Total execution time: 0.0710
DEBUG - 2022-05-31 00:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:44 --> Total execution time: 0.0276
DEBUG - 2022-05-31 00:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:48 --> Total execution time: 0.0585
DEBUG - 2022-05-31 00:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:30:59 --> Total execution time: 0.0519
DEBUG - 2022-05-31 00:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:31:48 --> Total execution time: 0.0485
DEBUG - 2022-05-31 00:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:01:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 00:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:31:54 --> Total execution time: 0.0712
DEBUG - 2022-05-31 00:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:01:54 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 00:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:31:56 --> Total execution time: 0.0222
DEBUG - 2022-05-31 00:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:02:02 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:32:02 --> Total execution time: 0.0230
DEBUG - 2022-05-31 00:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:32:17 --> Total execution time: 0.0337
DEBUG - 2022-05-31 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:02:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:32:32 --> Total execution time: 0.0270
DEBUG - 2022-05-31 00:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:02:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:32:36 --> Total execution time: 0.0328
DEBUG - 2022-05-31 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:32:45 --> Total execution time: 0.0273
DEBUG - 2022-05-31 00:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:33:50 --> Total execution time: 0.0269
DEBUG - 2022-05-31 00:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:07 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:07 --> Total execution time: 0.1622
DEBUG - 2022-05-31 00:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:11 --> Total execution time: 0.0267
DEBUG - 2022-05-31 00:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:14 --> Total execution time: 0.0212
DEBUG - 2022-05-31 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:20 --> Total execution time: 0.0416
DEBUG - 2022-05-31 00:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:22 --> Total execution time: 0.0383
DEBUG - 2022-05-31 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:26 --> Total execution time: 0.0308
DEBUG - 2022-05-31 00:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:29 --> Total execution time: 0.0607
DEBUG - 2022-05-31 00:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:32 --> Total execution time: 0.0279
DEBUG - 2022-05-31 00:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:37 --> Total execution time: 0.0490
DEBUG - 2022-05-31 00:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:57 --> Total execution time: 0.0345
DEBUG - 2022-05-31 00:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:36:59 --> Total execution time: 0.0271
DEBUG - 2022-05-31 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:38:45 --> Total execution time: 0.0254
DEBUG - 2022-05-31 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:43:30 --> Total execution time: 0.0363
DEBUG - 2022-05-31 00:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:43:51 --> Total execution time: 0.0282
DEBUG - 2022-05-31 00:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:43:54 --> Total execution time: 0.0291
DEBUG - 2022-05-31 00:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:43:56 --> Total execution time: 0.0346
DEBUG - 2022-05-31 00:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:43:59 --> Total execution time: 0.0349
DEBUG - 2022-05-31 00:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:04 --> Total execution time: 0.0513
DEBUG - 2022-05-31 00:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:07 --> Total execution time: 0.0397
DEBUG - 2022-05-31 00:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:10 --> Total execution time: 0.0345
DEBUG - 2022-05-31 00:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:12 --> Total execution time: 0.0305
DEBUG - 2022-05-31 00:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:16 --> Total execution time: 0.0524
DEBUG - 2022-05-31 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:19 --> Total execution time: 0.0323
DEBUG - 2022-05-31 00:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:21 --> Total execution time: 0.0292
DEBUG - 2022-05-31 00:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:28 --> Total execution time: 0.0429
DEBUG - 2022-05-31 00:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:36 --> Total execution time: 0.0303
DEBUG - 2022-05-31 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:45 --> Total execution time: 0.0355
DEBUG - 2022-05-31 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:45:09 --> Total execution time: 0.0527
DEBUG - 2022-05-31 00:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:45:57 --> Total execution time: 0.0532
DEBUG - 2022-05-31 00:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:05 --> Total execution time: 0.0470
DEBUG - 2022-05-31 00:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:12 --> Total execution time: 0.0284
DEBUG - 2022-05-31 00:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:16 --> Total execution time: 0.0748
DEBUG - 2022-05-31 00:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:35 --> Total execution time: 0.0272
DEBUG - 2022-05-31 00:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:42 --> Total execution time: 0.0383
DEBUG - 2022-05-31 00:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:46:57 --> Total execution time: 0.0278
DEBUG - 2022-05-31 00:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:47:05 --> Total execution time: 0.0585
DEBUG - 2022-05-31 00:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:47:09 --> Total execution time: 0.0343
DEBUG - 2022-05-31 00:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:47:16 --> Total execution time: 0.0849
DEBUG - 2022-05-31 00:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:48:30 --> Total execution time: 0.0265
DEBUG - 2022-05-31 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:48:33 --> Total execution time: 0.0303
DEBUG - 2022-05-31 00:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:48:41 --> Total execution time: 0.0270
DEBUG - 2022-05-31 00:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:18:41 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:48:41 --> Total execution time: 0.0557
DEBUG - 2022-05-31 00:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:49:03 --> Total execution time: 0.0313
DEBUG - 2022-05-31 00:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:49:10 --> Total execution time: 0.0289
DEBUG - 2022-05-31 00:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:49:12 --> Total execution time: 0.0290
DEBUG - 2022-05-31 00:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:49:17 --> Total execution time: 0.0266
DEBUG - 2022-05-31 00:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:21:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:51:26 --> Total execution time: 0.1260
DEBUG - 2022-05-31 00:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:25:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:55:22 --> Total execution time: 0.0901
DEBUG - 2022-05-31 00:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:26:30 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:56:30 --> Total execution time: 0.0291
DEBUG - 2022-05-31 00:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:27:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:09 --> Total execution time: 0.0211
DEBUG - 2022-05-31 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:36 --> Total execution time: 0.0211
DEBUG - 2022-05-31 00:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:27:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:43 --> Total execution time: 0.0225
DEBUG - 2022-05-31 00:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:28:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:58:25 --> Total execution time: 0.0540
DEBUG - 2022-05-31 00:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:28:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:58:31 --> Total execution time: 0.0503
DEBUG - 2022-05-31 00:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:58:40 --> Total execution time: 0.0237
DEBUG - 2022-05-31 00:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:30:14 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 00:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:30:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:30:26 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-05-31 00:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:37:10 --> 404 Page Not Found: Wp-sitemap-taxonomies-product_cat-1xml/index
DEBUG - 2022-05-31 00:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:08:03 --> Total execution time: 0.0339
DEBUG - 2022-05-31 00:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:08:36 --> Total execution time: 0.0255
DEBUG - 2022-05-31 00:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:39:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:09:43 --> Total execution time: 0.0352
DEBUG - 2022-05-31 00:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:09:44 --> Total execution time: 0.0951
DEBUG - 2022-05-31 00:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:10:37 --> Total execution time: 0.0203
DEBUG - 2022-05-31 00:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:12:01 --> Total execution time: 0.0293
DEBUG - 2022-05-31 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:42:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:12:12 --> Total execution time: 0.0329
DEBUG - 2022-05-31 00:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 00:42:29 --> 404 Page Not Found: Wp-content/index
DEBUG - 2022-05-31 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:45:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:15:33 --> Total execution time: 0.0662
DEBUG - 2022-05-31 00:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:46:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:16:49 --> Total execution time: 0.0230
DEBUG - 2022-05-31 00:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:07 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:17:07 --> Total execution time: 0.0873
DEBUG - 2022-05-31 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:47:19 --> Total execution time: 0.0412
DEBUG - 2022-05-31 00:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:17:19 --> Total execution time: 0.0353
DEBUG - 2022-05-31 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:47:21 --> Total execution time: 0.0627
DEBUG - 2022-05-31 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:47:21 --> Total execution time: 0.0745
DEBUG - 2022-05-31 00:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:17:35 --> Total execution time: 0.0303
DEBUG - 2022-05-31 00:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:17:50 --> Total execution time: 0.0346
DEBUG - 2022-05-31 00:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:03 --> Total execution time: 0.0948
DEBUG - 2022-05-31 00:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:12 --> Total execution time: 0.0512
DEBUG - 2022-05-31 00:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:19 --> Total execution time: 0.0324
DEBUG - 2022-05-31 00:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:28 --> Total execution time: 0.0326
DEBUG - 2022-05-31 00:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:31 --> Total execution time: 0.0381
DEBUG - 2022-05-31 00:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:38 --> Total execution time: 0.0485
DEBUG - 2022-05-31 00:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:41 --> Total execution time: 0.0318
DEBUG - 2022-05-31 00:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:18:57 --> Total execution time: 0.1118
DEBUG - 2022-05-31 00:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:03 --> Total execution time: 0.0291
DEBUG - 2022-05-31 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:04 --> Total execution time: 0.0380
DEBUG - 2022-05-31 00:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:06 --> Total execution time: 0.0675
DEBUG - 2022-05-31 00:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:08 --> Total execution time: 0.0467
DEBUG - 2022-05-31 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:10 --> Total execution time: 0.0367
DEBUG - 2022-05-31 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:12 --> Total execution time: 0.0313
DEBUG - 2022-05-31 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:19:17 --> Total execution time: 0.0534
DEBUG - 2022-05-31 00:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:19 --> No URI present. Default controller set.
DEBUG - 2022-05-31 00:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:28:19 --> Total execution time: 0.2122
DEBUG - 2022-05-31 00:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:28:38 --> Total execution time: 0.0595
DEBUG - 2022-05-31 00:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:28:43 --> Total execution time: 0.0819
DEBUG - 2022-05-31 00:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:28:45 --> Total execution time: 0.0434
DEBUG - 2022-05-31 00:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:28:56 --> Total execution time: 0.0297
DEBUG - 2022-05-31 00:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 00:59:06 --> Total execution time: 0.0291
DEBUG - 2022-05-31 00:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:29:10 --> Total execution time: 0.0403
DEBUG - 2022-05-31 00:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 00:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 00:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:29:53 --> Total execution time: 0.0289
DEBUG - 2022-05-31 01:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:00 --> Total execution time: 0.0357
DEBUG - 2022-05-31 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:02 --> Total execution time: 0.0782
DEBUG - 2022-05-31 01:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:04 --> Total execution time: 0.0479
DEBUG - 2022-05-31 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:15 --> Total execution time: 0.0296
DEBUG - 2022-05-31 01:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:16 --> Total execution time: 0.0530
DEBUG - 2022-05-31 01:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:18 --> Total execution time: 0.0538
DEBUG - 2022-05-31 01:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:00:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:30:22 --> Total execution time: 0.0512
DEBUG - 2022-05-31 01:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:31:52 --> Total execution time: 0.0729
DEBUG - 2022-05-31 01:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:01:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:31:57 --> Total execution time: 0.1035
DEBUG - 2022-05-31 01:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:32:31 --> Total execution time: 0.0808
DEBUG - 2022-05-31 01:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:34:48 --> Total execution time: 0.0317
DEBUG - 2022-05-31 01:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:35:03 --> Total execution time: 0.0242
DEBUG - 2022-05-31 01:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:35:11 --> Total execution time: 0.0334
DEBUG - 2022-05-31 01:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:35:20 --> Total execution time: 0.0249
DEBUG - 2022-05-31 01:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:05:50 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-05-31 01:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:35:52 --> Total execution time: 0.0314
DEBUG - 2022-05-31 01:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:36:19 --> Total execution time: 0.0725
DEBUG - 2022-05-31 01:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:36:29 --> Total execution time: 0.0274
DEBUG - 2022-05-31 01:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:36:34 --> Total execution time: 0.0458
DEBUG - 2022-05-31 01:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:36:48 --> Total execution time: 0.0622
DEBUG - 2022-05-31 01:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:37:11 --> Total execution time: 0.0352
DEBUG - 2022-05-31 01:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:37:15 --> Total execution time: 0.0198
DEBUG - 2022-05-31 01:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:07:30 --> Total execution time: 0.0304
DEBUG - 2022-05-31 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:07:40 --> Total execution time: 0.0487
DEBUG - 2022-05-31 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:07:40 --> Total execution time: 0.0794
DEBUG - 2022-05-31 01:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:08:02 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:38:02 --> Total execution time: 0.0456
DEBUG - 2022-05-31 01:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:38:15 --> Total execution time: 0.0194
DEBUG - 2022-05-31 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:38:25 --> Total execution time: 0.0432
DEBUG - 2022-05-31 01:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:39:16 --> Total execution time: 0.0378
DEBUG - 2022-05-31 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:40:16 --> Total execution time: 0.0377
DEBUG - 2022-05-31 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:10:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:40:17 --> Total execution time: 0.0363
DEBUG - 2022-05-31 01:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:41:17 --> Total execution time: 0.0268
DEBUG - 2022-05-31 01:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:43:55 --> Total execution time: 0.0362
DEBUG - 2022-05-31 01:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:43:56 --> Total execution time: 0.0943
DEBUG - 2022-05-31 01:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:15:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:45:44 --> Total execution time: 0.0282
DEBUG - 2022-05-31 01:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:46:20 --> Total execution time: 0.0274
DEBUG - 2022-05-31 01:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:46:45 --> Total execution time: 0.0205
DEBUG - 2022-05-31 01:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:46:55 --> Total execution time: 0.0361
DEBUG - 2022-05-31 01:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:46:57 --> Total execution time: 0.0536
DEBUG - 2022-05-31 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:47:31 --> Total execution time: 0.4250
DEBUG - 2022-05-31 01:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:47:43 --> Total execution time: 0.0285
DEBUG - 2022-05-31 01:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:18:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:21 --> Total execution time: 0.0924
DEBUG - 2022-05-31 01:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:50:37 --> Total execution time: 0.0373
DEBUG - 2022-05-31 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:20:53 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-05-31 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:20:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 01:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:20:58 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-05-31 01:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:21:00 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-05-31 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:10 --> Total execution time: 0.0472
DEBUG - 2022-05-31 01:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:30 --> Total execution time: 0.0962
DEBUG - 2022-05-31 01:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:47 --> Total execution time: 0.0429
DEBUG - 2022-05-31 01:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:48 --> Total execution time: 0.0252
DEBUG - 2022-05-31 01:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:49 --> Total execution time: 0.0354
DEBUG - 2022-05-31 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:50 --> Total execution time: 0.0256
DEBUG - 2022-05-31 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:51:52 --> Total execution time: 0.0846
DEBUG - 2022-05-31 01:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:22:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:52:04 --> Total execution time: 0.0258
DEBUG - 2022-05-31 01:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:26:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:56:42 --> Total execution time: 0.1129
DEBUG - 2022-05-31 01:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:56:47 --> Total execution time: 0.0295
DEBUG - 2022-05-31 01:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:57:02 --> Total execution time: 0.0606
DEBUG - 2022-05-31 01:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:57:19 --> Total execution time: 0.0618
DEBUG - 2022-05-31 01:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:57:31 --> Total execution time: 0.0794
DEBUG - 2022-05-31 01:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:57:43 --> Total execution time: 0.0261
DEBUG - 2022-05-31 01:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:04:46 --> Total execution time: 0.1980
DEBUG - 2022-05-31 01:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:36:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:06:35 --> Total execution time: 0.0370
DEBUG - 2022-05-31 01:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:07:05 --> Total execution time: 0.0992
DEBUG - 2022-05-31 01:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:07:05 --> Total execution time: 0.0283
DEBUG - 2022-05-31 01:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:19 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:07:19 --> Total execution time: 0.0216
DEBUG - 2022-05-31 01:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:37:37 --> Total execution time: 0.0341
DEBUG - 2022-05-31 01:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:37:40 --> Total execution time: 0.0463
DEBUG - 2022-05-31 01:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:37:40 --> Total execution time: 0.0616
DEBUG - 2022-05-31 01:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:07:52 --> Total execution time: 0.0341
DEBUG - 2022-05-31 01:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:38:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:08:11 --> Total execution time: 0.0406
DEBUG - 2022-05-31 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:38:21 --> Total execution time: 0.0308
DEBUG - 2022-05-31 01:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:38:23 --> Total execution time: 0.0286
DEBUG - 2022-05-31 01:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:38:23 --> Total execution time: 0.0432
DEBUG - 2022-05-31 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:40:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 01:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:10:07 --> Total execution time: 1.5331
DEBUG - 2022-05-31 01:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 01:40:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 01:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:10:15 --> Total execution time: 0.0332
DEBUG - 2022-05-31 01:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:24 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:10:24 --> Total execution time: 0.0268
DEBUG - 2022-05-31 01:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:10:49 --> Total execution time: 0.0512
DEBUG - 2022-05-31 01:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:41:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:11:06 --> Total execution time: 0.0413
DEBUG - 2022-05-31 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:11:38 --> Total execution time: 0.0390
DEBUG - 2022-05-31 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:12:12 --> Total execution time: 0.0438
DEBUG - 2022-05-31 01:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:12:36 --> Total execution time: 0.0335
DEBUG - 2022-05-31 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:12:41 --> Total execution time: 0.0782
DEBUG - 2022-05-31 01:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:43:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:13:10 --> Total execution time: 0.0263
DEBUG - 2022-05-31 01:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:44:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:09 --> Total execution time: 0.0496
DEBUG - 2022-05-31 01:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:44:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:22 --> Total execution time: 0.0337
DEBUG - 2022-05-31 01:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:45:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:15:35 --> Total execution time: 0.0422
DEBUG - 2022-05-31 01:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:15:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:16:00 --> Total execution time: 0.0411
DEBUG - 2022-05-31 01:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:16:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 12:16:02 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 12:16:02 --> Total execution time: 0.1574
DEBUG - 2022-05-31 01:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:16:16 --> Total execution time: 0.0410
DEBUG - 2022-05-31 01:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:16:52 --> Total execution time: 0.0545
DEBUG - 2022-05-31 01:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:16:54 --> Total execution time: 0.0421
DEBUG - 2022-05-31 01:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:17:00 --> Total execution time: 0.0337
DEBUG - 2022-05-31 01:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:17:12 --> Total execution time: 0.0239
DEBUG - 2022-05-31 01:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:47:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:17:47 --> Total execution time: 0.0262
DEBUG - 2022-05-31 01:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:17:59 --> Total execution time: 0.0208
DEBUG - 2022-05-31 01:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:18:42 --> Total execution time: 0.0191
DEBUG - 2022-05-31 01:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:18:48 --> Total execution time: 0.0302
DEBUG - 2022-05-31 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:18:52 --> Total execution time: 0.0288
DEBUG - 2022-05-31 01:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:18:57 --> Total execution time: 0.0256
DEBUG - 2022-05-31 01:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:18:59 --> Total execution time: 0.0327
DEBUG - 2022-05-31 01:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:19:12 --> Total execution time: 0.0338
DEBUG - 2022-05-31 01:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:49:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:19:14 --> Total execution time: 0.0217
DEBUG - 2022-05-31 01:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:16 --> Total execution time: 0.0211
DEBUG - 2022-05-31 01:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:20:18 --> Total execution time: 0.0247
DEBUG - 2022-05-31 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:23 --> Total execution time: 0.0235
DEBUG - 2022-05-31 01:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:27 --> Total execution time: 0.0280
DEBUG - 2022-05-31 01:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:29 --> Total execution time: 0.2277
DEBUG - 2022-05-31 01:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:31 --> Total execution time: 0.0779
DEBUG - 2022-05-31 01:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:50:40 --> Total execution time: 0.0242
DEBUG - 2022-05-31 01:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:20:49 --> Total execution time: 0.0232
DEBUG - 2022-05-31 01:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:20:50 --> Total execution time: 0.0232
DEBUG - 2022-05-31 01:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:20:53 --> Total execution time: 0.0275
DEBUG - 2022-05-31 01:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:20:56 --> Total execution time: 0.0470
DEBUG - 2022-05-31 01:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:02 --> Total execution time: 0.0632
DEBUG - 2022-05-31 01:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:10 --> Total execution time: 0.0380
DEBUG - 2022-05-31 01:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:11 --> Total execution time: 0.0373
DEBUG - 2022-05-31 01:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:21 --> Total execution time: 0.0335
DEBUG - 2022-05-31 01:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:23 --> Total execution time: 0.0448
DEBUG - 2022-05-31 01:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:27 --> Total execution time: 0.0443
DEBUG - 2022-05-31 01:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:50 --> Total execution time: 0.1016
DEBUG - 2022-05-31 01:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:06 --> Total execution time: 0.0383
DEBUG - 2022-05-31 01:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:09 --> Total execution time: 0.0322
DEBUG - 2022-05-31 01:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:33 --> Total execution time: 0.0380
DEBUG - 2022-05-31 01:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:34 --> Total execution time: 0.0355
DEBUG - 2022-05-31 01:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:39 --> Total execution time: 0.0344
DEBUG - 2022-05-31 01:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:52:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:43 --> Total execution time: 0.0276
DEBUG - 2022-05-31 01:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:11 --> Total execution time: 0.0344
DEBUG - 2022-05-31 01:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:30 --> Total execution time: 0.0588
DEBUG - 2022-05-31 01:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:49 --> Total execution time: 0.0329
DEBUG - 2022-05-31 01:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:50 --> Total execution time: 0.0682
DEBUG - 2022-05-31 01:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:56 --> Total execution time: 0.0267
DEBUG - 2022-05-31 01:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:23:58 --> Total execution time: 0.0281
DEBUG - 2022-05-31 01:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:02 --> Total execution time: 0.0438
DEBUG - 2022-05-31 01:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:05 --> Total execution time: 0.0634
DEBUG - 2022-05-31 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:08 --> Total execution time: 0.0293
DEBUG - 2022-05-31 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:09 --> Total execution time: 0.0275
DEBUG - 2022-05-31 01:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:09 --> Total execution time: 0.0417
DEBUG - 2022-05-31 01:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:10 --> Total execution time: 0.0433
DEBUG - 2022-05-31 01:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:32 --> Total execution time: 0.0256
DEBUG - 2022-05-31 01:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:56 --> Total execution time: 0.0358
DEBUG - 2022-05-31 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:25:10 --> Total execution time: 0.0277
DEBUG - 2022-05-31 01:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:25:20 --> Total execution time: 0.0449
DEBUG - 2022-05-31 01:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:25:28 --> Total execution time: 0.0222
DEBUG - 2022-05-31 01:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:55:34 --> Total execution time: 0.0649
DEBUG - 2022-05-31 01:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:55:36 --> Total execution time: 0.0312
DEBUG - 2022-05-31 01:55:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:55:36 --> Total execution time: 0.0537
DEBUG - 2022-05-31 01:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:55:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:25:53 --> Total execution time: 0.0534
DEBUG - 2022-05-31 01:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:26:04 --> Total execution time: 0.0602
DEBUG - 2022-05-31 01:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:26:08 --> Total execution time: 0.0760
DEBUG - 2022-05-31 01:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:56:14 --> Total execution time: 0.0249
DEBUG - 2022-05-31 01:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:56:15 --> Total execution time: 0.0442
DEBUG - 2022-05-31 01:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:56:15 --> Total execution time: 0.0657
DEBUG - 2022-05-31 01:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:26:16 --> Total execution time: 0.0329
DEBUG - 2022-05-31 01:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:26:52 --> Total execution time: 0.0477
DEBUG - 2022-05-31 01:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:57:04 --> Total execution time: 0.0279
DEBUG - 2022-05-31 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:57:05 --> Total execution time: 0.0351
DEBUG - 2022-05-31 01:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:57:05 --> Total execution time: 0.0321
DEBUG - 2022-05-31 01:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:57:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:27:14 --> Total execution time: 0.0273
DEBUG - 2022-05-31 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:57:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:27:54 --> Total execution time: 0.0475
DEBUG - 2022-05-31 01:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:03 --> Total execution time: 0.0267
DEBUG - 2022-05-31 01:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:04 --> Total execution time: 0.0283
DEBUG - 2022-05-31 01:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:04 --> Total execution time: 0.0390
DEBUG - 2022-05-31 01:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:38 --> Total execution time: 0.0387
DEBUG - 2022-05-31 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:39 --> Total execution time: 0.0469
DEBUG - 2022-05-31 01:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:58:39 --> Total execution time: 0.0950
DEBUG - 2022-05-31 01:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:58:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:28:43 --> Total execution time: 0.0312
DEBUG - 2022-05-31 01:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:29:20 --> Total execution time: 0.0348
DEBUG - 2022-05-31 01:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:29:29 --> Total execution time: 0.1270
DEBUG - 2022-05-31 01:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:29 --> No URI present. Default controller set.
DEBUG - 2022-05-31 01:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:29:29 --> Total execution time: 0.0270
DEBUG - 2022-05-31 01:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:59:42 --> Total execution time: 0.0259
DEBUG - 2022-05-31 01:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:59:44 --> Total execution time: 0.0292
DEBUG - 2022-05-31 01:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:59:44 --> Total execution time: 0.0551
DEBUG - 2022-05-31 01:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 01:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 01:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 01:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:29:57 --> Total execution time: 0.0651
DEBUG - 2022-05-31 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:30:03 --> Total execution time: 0.0455
DEBUG - 2022-05-31 02:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:30:11 --> Total execution time: 0.0853
DEBUG - 2022-05-31 02:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:30:28 --> Total execution time: 0.0801
DEBUG - 2022-05-31 02:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:31:40 --> Total execution time: 0.0304
DEBUG - 2022-05-31 02:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:35:47 --> Total execution time: 0.0658
DEBUG - 2022-05-31 02:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:37:06 --> Total execution time: 0.0378
DEBUG - 2022-05-31 02:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:37:09 --> Total execution time: 0.0294
DEBUG - 2022-05-31 02:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:37:15 --> Total execution time: 0.0403
DEBUG - 2022-05-31 02:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:37:47 --> Total execution time: 0.0374
DEBUG - 2022-05-31 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:37:56 --> Total execution time: 0.0357
DEBUG - 2022-05-31 02:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:03 --> Total execution time: 0.0278
DEBUG - 2022-05-31 02:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:09 --> Total execution time: 0.0283
DEBUG - 2022-05-31 02:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:10 --> Total execution time: 0.0280
DEBUG - 2022-05-31 02:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:11 --> Total execution time: 0.0554
DEBUG - 2022-05-31 02:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:13 --> Total execution time: 0.0315
DEBUG - 2022-05-31 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:15 --> Total execution time: 0.0320
DEBUG - 2022-05-31 02:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:26 --> Total execution time: 0.0277
DEBUG - 2022-05-31 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:26 --> Total execution time: 0.0306
DEBUG - 2022-05-31 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:29 --> Total execution time: 0.0280
DEBUG - 2022-05-31 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:29 --> Total execution time: 0.0235
DEBUG - 2022-05-31 02:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:30 --> Total execution time: 0.0239
DEBUG - 2022-05-31 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:42 --> Total execution time: 0.0235
DEBUG - 2022-05-31 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:47 --> Total execution time: 0.0284
DEBUG - 2022-05-31 02:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:07 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:40:07 --> Total execution time: 0.0464
DEBUG - 2022-05-31 02:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:10:12 --> Total execution time: 0.0290
DEBUG - 2022-05-31 02:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:13 --> Total execution time: 0.0287
DEBUG - 2022-05-31 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:10:13 --> Total execution time: 0.0343
DEBUG - 2022-05-31 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:40:35 --> Total execution time: 0.0610
DEBUG - 2022-05-31 02:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:41:25 --> Total execution time: 0.0647
DEBUG - 2022-05-31 02:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:11:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:41:44 --> Total execution time: 0.0275
DEBUG - 2022-05-31 02:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:41:47 --> Total execution time: 0.0267
DEBUG - 2022-05-31 02:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:11:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:41:54 --> Total execution time: 0.0430
DEBUG - 2022-05-31 02:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:09 --> Total execution time: 0.0285
DEBUG - 2022-05-31 02:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:18 --> Total execution time: 0.0681
DEBUG - 2022-05-31 02:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:27 --> Total execution time: 0.0368
DEBUG - 2022-05-31 02:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:35 --> Total execution time: 0.0343
DEBUG - 2022-05-31 02:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:53 --> Total execution time: 0.0303
DEBUG - 2022-05-31 02:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:42:54 --> Total execution time: 0.0304
DEBUG - 2022-05-31 02:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:17 --> Total execution time: 0.0364
DEBUG - 2022-05-31 02:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:18 --> Total execution time: 0.0323
DEBUG - 2022-05-31 02:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:37 --> Total execution time: 0.0313
DEBUG - 2022-05-31 02:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:38 --> Total execution time: 0.0234
DEBUG - 2022-05-31 02:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:53 --> Total execution time: 0.0280
DEBUG - 2022-05-31 02:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:13:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:57 --> Total execution time: 0.0260
DEBUG - 2022-05-31 02:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:08 --> Total execution time: 0.0268
DEBUG - 2022-05-31 02:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:12 --> Total execution time: 0.0288
DEBUG - 2022-05-31 02:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:14 --> Total execution time: 0.0300
DEBUG - 2022-05-31 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:18 --> Total execution time: 0.0568
DEBUG - 2022-05-31 02:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:40 --> Total execution time: 0.0215
DEBUG - 2022-05-31 02:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:50 --> Total execution time: 0.0228
DEBUG - 2022-05-31 02:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:56 --> Total execution time: 0.0656
DEBUG - 2022-05-31 02:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:47:24 --> Total execution time: 0.1406
DEBUG - 2022-05-31 02:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:47:32 --> Total execution time: 0.0357
DEBUG - 2022-05-31 02:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:50:14 --> Total execution time: 0.0557
DEBUG - 2022-05-31 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:51:38 --> Total execution time: 0.1050
DEBUG - 2022-05-31 02:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:52:14 --> Total execution time: 0.0949
DEBUG - 2022-05-31 02:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:02 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:02 --> Total execution time: 0.0697
DEBUG - 2022-05-31 02:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:04 --> Total execution time: 0.0653
DEBUG - 2022-05-31 02:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:07 --> Total execution time: 0.0241
DEBUG - 2022-05-31 02:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:20 --> Total execution time: 0.0252
DEBUG - 2022-05-31 02:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:52 --> Total execution time: 0.0444
DEBUG - 2022-05-31 02:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:54 --> Total execution time: 0.0354
DEBUG - 2022-05-31 02:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:55 --> Total execution time: 0.0277
DEBUG - 2022-05-31 02:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:55 --> Total execution time: 0.0276
DEBUG - 2022-05-31 02:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:56 --> Total execution time: 0.0289
DEBUG - 2022-05-31 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:54:59 --> Total execution time: 0.0239
DEBUG - 2022-05-31 02:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:55:16 --> Total execution time: 0.0277
DEBUG - 2022-05-31 02:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:55:24 --> Total execution time: 0.0265
DEBUG - 2022-05-31 02:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:56:11 --> Total execution time: 0.0275
DEBUG - 2022-05-31 02:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:59:47 --> Total execution time: 0.0777
DEBUG - 2022-05-31 02:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:33:08 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:03:08 --> Total execution time: 0.1040
DEBUG - 2022-05-31 02:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:33:31 --> Total execution time: 0.0351
DEBUG - 2022-05-31 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:33:33 --> Total execution time: 0.0422
DEBUG - 2022-05-31 02:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:33:33 --> Total execution time: 0.0879
DEBUG - 2022-05-31 02:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:33:45 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:03:45 --> Total execution time: 0.0304
DEBUG - 2022-05-31 02:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:34:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:04:17 --> Total execution time: 0.0531
DEBUG - 2022-05-31 02:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:04:19 --> Total execution time: 0.0765
DEBUG - 2022-05-31 02:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:04:23 --> Total execution time: 0.0370
DEBUG - 2022-05-31 02:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:04:45 --> Total execution time: 0.0290
DEBUG - 2022-05-31 02:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:10 --> Total execution time: 0.0663
DEBUG - 2022-05-31 02:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:14 --> Total execution time: 0.0284
DEBUG - 2022-05-31 02:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 02:35:26 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-05-31 02:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:39 --> Total execution time: 0.0415
DEBUG - 2022-05-31 02:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:40 --> Total execution time: 0.0334
DEBUG - 2022-05-31 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:41 --> Total execution time: 0.0258
DEBUG - 2022-05-31 02:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:41 --> Total execution time: 0.0232
DEBUG - 2022-05-31 02:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:43 --> Total execution time: 0.0414
DEBUG - 2022-05-31 02:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:43 --> Total execution time: 0.0320
DEBUG - 2022-05-31 02:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:05:44 --> Total execution time: 0.0269
DEBUG - 2022-05-31 02:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:35:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:05:47 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 02:35:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 02:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:06:04 --> Total execution time: 0.0284
DEBUG - 2022-05-31 02:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:06:09 --> Total execution time: 0.0339
DEBUG - 2022-05-31 02:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:36:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:06:17 --> Total execution time: 0.0222
DEBUG - 2022-05-31 02:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:36:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:06:20 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:07:50 --> Total execution time: 0.0190
DEBUG - 2022-05-31 02:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:39:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:09:18 --> Total execution time: 0.0589
DEBUG - 2022-05-31 02:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:09:20 --> Total execution time: 0.0647
DEBUG - 2022-05-31 02:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:10:06 --> Total execution time: 0.0293
DEBUG - 2022-05-31 02:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:10:12 --> Total execution time: 0.0254
DEBUG - 2022-05-31 02:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:10:48 --> Total execution time: 0.0550
DEBUG - 2022-05-31 02:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:11 --> Total execution time: 0.0238
DEBUG - 2022-05-31 02:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:16 --> Total execution time: 0.0247
DEBUG - 2022-05-31 02:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:17 --> Total execution time: 0.0622
DEBUG - 2022-05-31 02:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:17 --> Total execution time: 0.1309
DEBUG - 2022-05-31 02:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:19 --> Total execution time: 0.0430
DEBUG - 2022-05-31 02:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:21 --> Total execution time: 0.0377
DEBUG - 2022-05-31 02:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:21 --> Total execution time: 0.0344
DEBUG - 2022-05-31 02:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:22 --> Total execution time: 0.0280
DEBUG - 2022-05-31 02:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:22 --> Total execution time: 0.0374
DEBUG - 2022-05-31 02:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:22 --> Total execution time: 0.0337
DEBUG - 2022-05-31 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:23 --> Total execution time: 0.0285
DEBUG - 2022-05-31 02:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:24 --> Total execution time: 0.0333
DEBUG - 2022-05-31 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:24 --> Total execution time: 0.0240
DEBUG - 2022-05-31 02:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:24 --> Total execution time: 0.0278
DEBUG - 2022-05-31 02:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:11:37 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 02:41:38 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 02:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:40 --> Total execution time: 0.0248
DEBUG - 2022-05-31 02:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:42 --> Total execution time: 0.0284
DEBUG - 2022-05-31 02:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:43 --> Total execution time: 0.0286
DEBUG - 2022-05-31 02:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:41:43 --> Total execution time: 0.0459
DEBUG - 2022-05-31 02:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:11:54 --> Total execution time: 0.0245
DEBUG - 2022-05-31 02:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:49 --> Total execution time: 0.0617
DEBUG - 2022-05-31 02:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:49 --> Total execution time: 0.0303
DEBUG - 2022-05-31 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:50 --> Total execution time: 0.0254
DEBUG - 2022-05-31 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:50 --> Total execution time: 0.0503
DEBUG - 2022-05-31 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:54 --> Total execution time: 0.0284
DEBUG - 2022-05-31 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:12:55 --> Total execution time: 0.0208
DEBUG - 2022-05-31 02:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:07 --> Total execution time: 0.0242
DEBUG - 2022-05-31 02:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:16 --> Total execution time: 0.0684
DEBUG - 2022-05-31 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:20 --> Total execution time: 0.0288
DEBUG - 2022-05-31 02:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:13:23 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:27 --> Total execution time: 0.0241
DEBUG - 2022-05-31 02:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:27 --> Total execution time: 0.0420
DEBUG - 2022-05-31 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:30 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:30 --> Total execution time: 0.0228
DEBUG - 2022-05-31 02:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:32 --> Total execution time: 0.0325
DEBUG - 2022-05-31 02:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:44 --> Total execution time: 0.0277
DEBUG - 2022-05-31 02:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:43:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:13:54 --> Total execution time: 0.0228
DEBUG - 2022-05-31 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:08 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:17:08 --> Total execution time: 0.0791
DEBUG - 2022-05-31 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:17:08 --> Total execution time: 0.0519
DEBUG - 2022-05-31 02:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:17:13 --> Total execution time: 0.0592
DEBUG - 2022-05-31 02:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:47:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:17:30 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 02:47:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 02:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:47:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:17:33 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:18:09 --> Total execution time: 0.0503
DEBUG - 2022-05-31 02:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:48:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:18:33 --> Total execution time: 0.0335
DEBUG - 2022-05-31 02:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:18:37 --> Total execution time: 0.0259
DEBUG - 2022-05-31 02:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:19:06 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:11 --> Total execution time: 0.0539
DEBUG - 2022-05-31 02:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:23 --> Total execution time: 0.0291
DEBUG - 2022-05-31 02:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:35 --> Total execution time: 0.0265
DEBUG - 2022-05-31 02:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:43 --> Total execution time: 0.0439
DEBUG - 2022-05-31 02:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:45 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:45 --> Total execution time: 0.0279
DEBUG - 2022-05-31 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:46 --> Total execution time: 0.0261
DEBUG - 2022-05-31 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:47 --> Total execution time: 0.0515
DEBUG - 2022-05-31 02:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:48 --> Total execution time: 0.0432
DEBUG - 2022-05-31 02:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:49:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:19:58 --> Total execution time: 0.0330
DEBUG - 2022-05-31 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:20:05 --> Total execution time: 0.0244
DEBUG - 2022-05-31 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:50:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-31 13:20:23 --> Query error: Illegal mix of collations (utf8mb4_general_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT *
FROM `user_logins`
WHERE `ul_log_id` = 'http://👉vishnu1940sharma@gmail.com'
AND `ul_log_password` = 'e10adc3949ba59abbe56e057f20f883e'
DEBUG - 2022-05-31 02:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:51:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:21:39 --> Total execution time: 0.0410
DEBUG - 2022-05-31 02:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:21:46 --> Total execution time: 0.0297
DEBUG - 2022-05-31 02:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:23:08 --> Total execution time: 0.0404
DEBUG - 2022-05-31 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:23:20 --> Total execution time: 0.0528
DEBUG - 2022-05-31 02:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 02:54:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 02:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:54:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:24:03 --> Total execution time: 0.0267
DEBUG - 2022-05-31 02:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:55:34 --> Total execution time: 0.0434
DEBUG - 2022-05-31 02:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:55:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:25:39 --> Total execution time: 0.0501
DEBUG - 2022-05-31 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:55:42 --> Total execution time: 0.0808
DEBUG - 2022-05-31 02:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:25:42 --> Total execution time: 0.0526
DEBUG - 2022-05-31 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:26:15 --> Total execution time: 0.0406
DEBUG - 2022-05-31 02:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:00 --> Total execution time: 0.0487
DEBUG - 2022-05-31 02:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:10 --> Total execution time: 0.0695
DEBUG - 2022-05-31 02:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:31 --> Total execution time: 0.0468
DEBUG - 2022-05-31 02:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 13:27:33 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-31 02:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:34 --> Total execution time: 0.0721
DEBUG - 2022-05-31 02:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 02:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:38 --> Total execution time: 0.0991
DEBUG - 2022-05-31 02:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:52 --> Total execution time: 0.0887
DEBUG - 2022-05-31 02:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:27:59 --> Total execution time: 0.0309
DEBUG - 2022-05-31 02:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:28:15 --> Total execution time: 0.0392
DEBUG - 2022-05-31 02:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:28:29 --> Total execution time: 0.0392
DEBUG - 2022-05-31 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:59:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 02:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:29:12 --> Total execution time: 0.0851
DEBUG - 2022-05-31 02:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:29:13 --> Total execution time: 0.0351
DEBUG - 2022-05-31 02:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:29:19 --> Total execution time: 0.0384
DEBUG - 2022-05-31 02:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 02:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 02:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:29:46 --> Total execution time: 0.0404
DEBUG - 2022-05-31 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:02 --> Total execution time: 0.0509
DEBUG - 2022-05-31 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:03 --> Total execution time: 0.1563
DEBUG - 2022-05-31 03:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:10 --> Total execution time: 0.0651
DEBUG - 2022-05-31 03:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:28 --> Total execution time: 0.0405
DEBUG - 2022-05-31 03:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:35 --> Total execution time: 0.1872
DEBUG - 2022-05-31 03:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:30:51 --> Total execution time: 0.0355
DEBUG - 2022-05-31 03:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:00 --> Total execution time: 0.0568
DEBUG - 2022-05-31 03:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:04 --> Total execution time: 0.0753
DEBUG - 2022-05-31 03:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:17 --> Total execution time: 0.0793
DEBUG - 2022-05-31 03:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:22 --> Total execution time: 0.0316
DEBUG - 2022-05-31 03:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:31 --> Total execution time: 0.0501
DEBUG - 2022-05-31 03:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:32 --> Total execution time: 0.0338
DEBUG - 2022-05-31 03:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:39 --> Total execution time: 0.0304
DEBUG - 2022-05-31 03:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:31:39 --> Total execution time: 0.0569
DEBUG - 2022-05-31 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:32:43 --> Total execution time: 0.0438
DEBUG - 2022-05-31 03:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:32:51 --> Total execution time: 0.0340
DEBUG - 2022-05-31 03:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:32:56 --> Total execution time: 0.0296
DEBUG - 2022-05-31 03:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:01 --> Total execution time: 0.0479
DEBUG - 2022-05-31 03:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:05 --> Total execution time: 0.0248
DEBUG - 2022-05-31 03:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:07 --> Total execution time: 0.0244
DEBUG - 2022-05-31 03:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:09 --> Total execution time: 0.0309
DEBUG - 2022-05-31 03:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:10 --> Total execution time: 0.0327
DEBUG - 2022-05-31 03:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:14 --> Total execution time: 0.0282
DEBUG - 2022-05-31 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:33:17 --> Total execution time: 0.0255
DEBUG - 2022-05-31 03:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:05:39 --> Total execution time: 0.0256
DEBUG - 2022-05-31 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:06:57 --> Total execution time: 0.0183
DEBUG - 2022-05-31 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:18 --> Total execution time: 0.0186
DEBUG - 2022-05-31 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:29 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:37:29 --> Total execution time: 0.0206
DEBUG - 2022-05-31 03:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:32 --> Total execution time: 0.0180
DEBUG - 2022-05-31 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:36 --> Total execution time: 0.0196
DEBUG - 2022-05-31 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:45 --> Total execution time: 0.0292
DEBUG - 2022-05-31 03:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:47 --> Total execution time: 0.0236
DEBUG - 2022-05-31 03:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:50 --> Total execution time: 0.0246
DEBUG - 2022-05-31 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:51 --> Total execution time: 0.0180
DEBUG - 2022-05-31 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:37:51 --> Total execution time: 0.0405
DEBUG - 2022-05-31 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:52 --> Total execution time: 0.0301
DEBUG - 2022-05-31 03:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:07:52 --> Total execution time: 0.0374
DEBUG - 2022-05-31 03:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:37:58 --> Total execution time: 0.0316
DEBUG - 2022-05-31 03:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:08:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:38:01 --> Total execution time: 0.0499
DEBUG - 2022-05-31 03:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:38:13 --> Total execution time: 0.0372
DEBUG - 2022-05-31 03:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:38:22 --> Total execution time: 0.0354
DEBUG - 2022-05-31 03:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:38:40 --> Total execution time: 0.0361
DEBUG - 2022-05-31 03:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:38:48 --> Total execution time: 0.0348
DEBUG - 2022-05-31 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:03 --> Total execution time: 0.0916
DEBUG - 2022-05-31 13:40:03 --> Total execution time: 0.0844
DEBUG - 2022-05-31 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:03 --> Total execution time: 0.0236
DEBUG - 2022-05-31 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:07 --> Total execution time: 0.0246
DEBUG - 2022-05-31 03:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:11 --> Total execution time: 0.0400
DEBUG - 2022-05-31 03:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:13 --> Total execution time: 0.0321
DEBUG - 2022-05-31 03:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:14 --> Total execution time: 0.0238
DEBUG - 2022-05-31 03:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:21 --> Total execution time: 0.0323
DEBUG - 2022-05-31 03:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:40:31 --> Total execution time: 0.0458
DEBUG - 2022-05-31 03:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:41:02 --> Total execution time: 0.0296
DEBUG - 2022-05-31 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:41:14 --> Total execution time: 0.0447
DEBUG - 2022-05-31 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:29 --> Total execution time: 0.0248
DEBUG - 2022-05-31 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:30 --> Total execution time: 0.0303
DEBUG - 2022-05-31 03:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:41:31 --> Total execution time: 0.0371
DEBUG - 2022-05-31 03:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:41:38 --> Total execution time: 0.0324
DEBUG - 2022-05-31 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:11:53 --> Total execution time: 0.0227
DEBUG - 2022-05-31 03:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:42:06 --> Total execution time: 0.0463
DEBUG - 2022-05-31 03:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:42:11 --> Total execution time: 0.0602
DEBUG - 2022-05-31 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:17 --> Total execution time: 0.0272
DEBUG - 2022-05-31 03:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:39 --> Total execution time: 0.0230
DEBUG - 2022-05-31 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:43 --> Total execution time: 0.0244
DEBUG - 2022-05-31 03:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:46 --> Total execution time: 0.0294
DEBUG - 2022-05-31 03:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:12:48 --> Total execution time: 0.0261
DEBUG - 2022-05-31 03:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:42:50 --> Total execution time: 0.0429
DEBUG - 2022-05-31 03:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:42:56 --> Total execution time: 0.0385
DEBUG - 2022-05-31 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:10 --> Total execution time: 0.0251
DEBUG - 2022-05-31 03:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:13 --> Total execution time: 0.0319
DEBUG - 2022-05-31 03:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:25 --> Total execution time: 0.0298
DEBUG - 2022-05-31 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:30 --> Total execution time: 0.0275
DEBUG - 2022-05-31 03:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:37 --> Total execution time: 0.0281
DEBUG - 2022-05-31 03:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:40 --> Total execution time: 0.0574
DEBUG - 2022-05-31 03:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:43 --> Total execution time: 0.0320
DEBUG - 2022-05-31 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:58 --> Total execution time: 0.0512
DEBUG - 2022-05-31 03:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:43:59 --> Total execution time: 0.0362
DEBUG - 2022-05-31 03:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:14:29 --> Total execution time: 0.0260
DEBUG - 2022-05-31 03:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:14:30 --> Total execution time: 0.0446
DEBUG - 2022-05-31 03:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:14:30 --> Total execution time: 0.0378
DEBUG - 2022-05-31 03:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:14:52 --> Total execution time: 0.0351
DEBUG - 2022-05-31 03:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:15:00 --> Total execution time: 0.0934
DEBUG - 2022-05-31 03:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:15:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 03:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:45:08 --> Total execution time: 1.5205
DEBUG - 2022-05-31 03:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 03:15:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 03:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:45:48 --> Total execution time: 0.0702
DEBUG - 2022-05-31 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:10 --> Total execution time: 0.0653
DEBUG - 2022-05-31 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:32 --> Total execution time: 0.0586
DEBUG - 2022-05-31 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:32 --> Total execution time: 0.0476
DEBUG - 2022-05-31 03:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:35 --> Total execution time: 0.0294
DEBUG - 2022-05-31 03:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:40 --> Total execution time: 0.0630
DEBUG - 2022-05-31 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:41 --> Total execution time: 0.0620
DEBUG - 2022-05-31 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:41 --> Total execution time: 0.0296
DEBUG - 2022-05-31 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:42 --> Total execution time: 0.0197
DEBUG - 2022-05-31 03:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:48 --> Total execution time: 0.0288
DEBUG - 2022-05-31 03:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:49 --> Total execution time: 0.0290
DEBUG - 2022-05-31 03:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:46:57 --> Total execution time: 0.0363
DEBUG - 2022-05-31 03:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:03 --> Total execution time: 0.0292
DEBUG - 2022-05-31 03:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:04 --> Total execution time: 0.0275
DEBUG - 2022-05-31 03:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:04 --> Total execution time: 0.0273
DEBUG - 2022-05-31 03:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:17 --> Total execution time: 0.0379
DEBUG - 2022-05-31 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:23 --> Total execution time: 0.0262
DEBUG - 2022-05-31 03:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:28 --> Total execution time: 0.0491
DEBUG - 2022-05-31 03:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:54 --> Total execution time: 0.0735
DEBUG - 2022-05-31 03:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:47:59 --> Total execution time: 0.0463
DEBUG - 2022-05-31 03:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:17 --> Total execution time: 0.0485
DEBUG - 2022-05-31 03:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:22 --> Total execution time: 0.0401
DEBUG - 2022-05-31 03:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:27 --> Total execution time: 0.0882
DEBUG - 2022-05-31 03:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:28 --> Total execution time: 0.0802
DEBUG - 2022-05-31 03:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:28 --> Total execution time: 0.0319
DEBUG - 2022-05-31 03:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:29 --> Total execution time: 0.0581
DEBUG - 2022-05-31 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:29 --> Total execution time: 0.0484
DEBUG - 2022-05-31 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:29 --> Total execution time: 0.0318
DEBUG - 2022-05-31 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:30 --> Total execution time: 0.0281
DEBUG - 2022-05-31 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:37 --> Total execution time: 0.0301
DEBUG - 2022-05-31 03:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:40 --> Total execution time: 0.0316
DEBUG - 2022-05-31 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:41 --> Total execution time: 0.0302
DEBUG - 2022-05-31 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:43 --> Total execution time: 0.0234
DEBUG - 2022-05-31 03:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:48 --> Total execution time: 0.0243
DEBUG - 2022-05-31 03:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:48:57 --> Total execution time: 0.0303
DEBUG - 2022-05-31 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:49:01 --> Total execution time: 0.0415
DEBUG - 2022-05-31 03:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:49:46 --> Total execution time: 0.0384
DEBUG - 2022-05-31 03:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:50:08 --> Total execution time: 0.0320
DEBUG - 2022-05-31 03:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:20:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:50:11 --> Total execution time: 0.0281
DEBUG - 2022-05-31 03:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:50:16 --> Total execution time: 0.0365
DEBUG - 2022-05-31 03:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:52:28 --> Total execution time: 0.1155
DEBUG - 2022-05-31 03:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:52:49 --> Total execution time: 0.0290
DEBUG - 2022-05-31 03:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:52:56 --> Total execution time: 0.0332
DEBUG - 2022-05-31 03:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:00 --> Total execution time: 0.0244
DEBUG - 2022-05-31 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:16 --> Total execution time: 0.0256
DEBUG - 2022-05-31 03:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:31 --> Total execution time: 0.0349
DEBUG - 2022-05-31 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:32 --> Total execution time: 0.0446
DEBUG - 2022-05-31 03:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:36 --> Total execution time: 0.0193
DEBUG - 2022-05-31 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:23:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:53:48 --> Total execution time: 0.0317
DEBUG - 2022-05-31 03:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:11 --> Total execution time: 0.0314
DEBUG - 2022-05-31 03:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:28 --> Total execution time: 0.0421
DEBUG - 2022-05-31 03:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:34 --> Total execution time: 0.0261
DEBUG - 2022-05-31 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:47 --> Total execution time: 0.0446
DEBUG - 2022-05-31 03:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:50 --> Total execution time: 0.0273
DEBUG - 2022-05-31 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:54:53 --> Total execution time: 0.0355
DEBUG - 2022-05-31 03:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:03 --> Total execution time: 0.0275
DEBUG - 2022-05-31 03:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:03 --> Total execution time: 0.0297
DEBUG - 2022-05-31 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:05 --> Total execution time: 0.0342
DEBUG - 2022-05-31 03:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:14 --> Total execution time: 0.0302
DEBUG - 2022-05-31 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:24 --> Total execution time: 0.0256
DEBUG - 2022-05-31 03:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:26 --> Total execution time: 0.0406
DEBUG - 2022-05-31 03:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:55:45 --> Total execution time: 0.0395
DEBUG - 2022-05-31 03:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:21 --> Total execution time: 0.0424
DEBUG - 2022-05-31 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:25 --> Total execution time: 0.0256
DEBUG - 2022-05-31 03:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:36 --> Total execution time: 0.0323
DEBUG - 2022-05-31 03:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:48 --> Total execution time: 0.0289
DEBUG - 2022-05-31 03:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:51 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:51 --> Total execution time: 0.0339
DEBUG - 2022-05-31 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:53 --> Total execution time: 0.0287
DEBUG - 2022-05-31 03:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:56:56 --> Total execution time: 0.0379
DEBUG - 2022-05-31 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:06 --> Total execution time: 0.0260
DEBUG - 2022-05-31 03:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:17 --> Total execution time: 0.0373
DEBUG - 2022-05-31 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:18 --> Total execution time: 0.0426
DEBUG - 2022-05-31 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:23 --> Total execution time: 0.0624
DEBUG - 2022-05-31 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:23 --> Total execution time: 0.0332
DEBUG - 2022-05-31 03:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:57:49 --> Total execution time: 0.0430
DEBUG - 2022-05-31 03:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:58:02 --> Total execution time: 0.0694
DEBUG - 2022-05-31 03:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:58:12 --> Total execution time: 0.0302
DEBUG - 2022-05-31 03:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:58:31 --> Total execution time: 0.0511
DEBUG - 2022-05-31 03:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:58:50 --> Total execution time: 0.0389
DEBUG - 2022-05-31 03:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:59:46 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 03:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:59:46 --> Total execution time: 0.0332
DEBUG - 2022-05-31 03:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:30:10 --> Total execution time: 0.0380
DEBUG - 2022-05-31 03:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:30:17 --> Total execution time: 0.1145
DEBUG - 2022-05-31 03:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:01:20 --> Total execution time: 0.0377
DEBUG - 2022-05-31 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:01:21 --> Total execution time: 0.0477
DEBUG - 2022-05-31 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:01:53 --> Total execution time: 0.0554
DEBUG - 2022-05-31 03:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:02:48 --> Total execution time: 0.0362
DEBUG - 2022-05-31 03:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:02:57 --> Total execution time: 0.0297
DEBUG - 2022-05-31 03:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:38 --> Total execution time: 0.0300
DEBUG - 2022-05-31 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:46 --> Total execution time: 0.0433
DEBUG - 2022-05-31 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:46 --> Total execution time: 0.0296
DEBUG - 2022-05-31 03:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:47 --> Total execution time: 0.0424
DEBUG - 2022-05-31 03:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:48 --> Total execution time: 0.0313
DEBUG - 2022-05-31 03:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:49 --> Total execution time: 0.0293
DEBUG - 2022-05-31 03:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:33:51 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:03:51 --> Total execution time: 0.0296
DEBUG - 2022-05-31 03:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:06:44 --> Total execution time: 0.1397
DEBUG - 2022-05-31 03:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:06:50 --> Total execution time: 0.0531
DEBUG - 2022-05-31 03:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:39:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:09:39 --> Total execution time: 0.0804
DEBUG - 2022-05-31 03:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:09:48 --> Total execution time: 0.0269
DEBUG - 2022-05-31 03:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:09:54 --> Total execution time: 0.0443
DEBUG - 2022-05-31 03:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:10:29 --> Total execution time: 0.0499
DEBUG - 2022-05-31 03:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:10:38 --> Total execution time: 0.0443
DEBUG - 2022-05-31 03:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:11:04 --> Total execution time: 0.0403
DEBUG - 2022-05-31 03:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:11:08 --> Total execution time: 0.0293
DEBUG - 2022-05-31 03:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:11:16 --> Total execution time: 0.0549
DEBUG - 2022-05-31 03:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:11:30 --> Total execution time: 0.0388
DEBUG - 2022-05-31 03:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:11:42 --> Total execution time: 0.0329
DEBUG - 2022-05-31 03:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:05 --> Total execution time: 0.1214
DEBUG - 2022-05-31 03:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:29 --> Total execution time: 0.0304
DEBUG - 2022-05-31 03:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:35 --> Total execution time: 0.0495
DEBUG - 2022-05-31 03:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:40 --> Total execution time: 0.0315
DEBUG - 2022-05-31 03:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:48 --> Total execution time: 0.0295
DEBUG - 2022-05-31 03:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:53 --> Total execution time: 0.0284
DEBUG - 2022-05-31 03:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:58 --> Total execution time: 0.0235
DEBUG - 2022-05-31 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:05 --> Total execution time: 0.0239
DEBUG - 2022-05-31 03:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:10 --> Total execution time: 0.0338
DEBUG - 2022-05-31 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:11 --> Total execution time: 0.0240
DEBUG - 2022-05-31 03:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:13 --> Total execution time: 0.0255
DEBUG - 2022-05-31 03:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:46 --> Total execution time: 0.0228
DEBUG - 2022-05-31 03:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:13:50 --> Total execution time: 0.0192
DEBUG - 2022-05-31 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:23 --> Total execution time: 0.0288
DEBUG - 2022-05-31 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:25 --> Total execution time: 0.0308
DEBUG - 2022-05-31 03:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:32 --> Total execution time: 0.0291
DEBUG - 2022-05-31 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:45 --> Total execution time: 0.0778
DEBUG - 2022-05-31 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:45 --> Total execution time: 0.0714
DEBUG - 2022-05-31 03:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:15:38 --> Total execution time: 0.0674
DEBUG - 2022-05-31 03:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:46:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:16:15 --> Total execution time: 0.0324
DEBUG - 2022-05-31 03:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:49:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:19:24 --> Total execution time: 0.1193
DEBUG - 2022-05-31 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:53:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:23:34 --> Total execution time: 0.1075
DEBUG - 2022-05-31 03:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:53:41 --> Total execution time: 0.0381
DEBUG - 2022-05-31 03:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:53:51 --> Total execution time: 0.0540
DEBUG - 2022-05-31 03:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:53:51 --> Total execution time: 0.0827
DEBUG - 2022-05-31 03:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 03:55:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 03:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:55:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:25:35 --> Total execution time: 1.5735
DEBUG - 2022-05-31 03:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:55:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 03:55:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 03:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 03:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:26:17 --> Total execution time: 0.0214
DEBUG - 2022-05-31 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:30:02 --> Total execution time: 0.2441
DEBUG - 2022-05-31 04:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:00:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:30:34 --> Total execution time: 0.0310
DEBUG - 2022-05-31 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:30:38 --> Total execution time: 0.0338
DEBUG - 2022-05-31 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:31:45 --> Total execution time: 0.0380
DEBUG - 2022-05-31 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:31:55 --> Total execution time: 0.1320
DEBUG - 2022-05-31 04:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:08 --> Total execution time: 0.0814
DEBUG - 2022-05-31 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:18 --> Total execution time: 0.0305
DEBUG - 2022-05-31 04:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:25 --> Total execution time: 0.0416
DEBUG - 2022-05-31 04:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:31 --> Total execution time: 0.0287
DEBUG - 2022-05-31 04:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:32 --> Total execution time: 0.0270
DEBUG - 2022-05-31 04:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:32:37 --> Total execution time: 0.0254
DEBUG - 2022-05-31 04:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:33:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:33:19 --> Total execution time: 0.0295
DEBUG - 2022-05-31 04:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:34:59 --> Total execution time: 0.0647
DEBUG - 2022-05-31 04:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:34:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 14:34:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 14:34:59 --> Total execution time: 0.2568
DEBUG - 2022-05-31 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:05:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:35:11 --> Total execution time: 0.0405
DEBUG - 2022-05-31 04:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:05:22 --> Total execution time: 0.0290
DEBUG - 2022-05-31 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:05:24 --> Total execution time: 0.0352
DEBUG - 2022-05-31 04:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:05:24 --> Total execution time: 0.0705
DEBUG - 2022-05-31 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:06:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:36:49 --> Total execution time: 1.6498
DEBUG - 2022-05-31 04:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:06:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:37:21 --> Total execution time: 0.0256
DEBUG - 2022-05-31 04:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:37:26 --> Total execution time: 0.0217
DEBUG - 2022-05-31 04:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:37:38 --> Total execution time: 0.0245
DEBUG - 2022-05-31 04:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:37:54 --> Total execution time: 0.0190
DEBUG - 2022-05-31 04:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:37:58 --> Total execution time: 0.0217
DEBUG - 2022-05-31 04:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:00 --> Total execution time: 0.0220
DEBUG - 2022-05-31 14:38:01 --> Total execution time: 1.5130
DEBUG - 2022-05-31 04:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:03 --> Total execution time: 0.0438
DEBUG - 2022-05-31 04:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:08:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:17 --> Total execution time: 0.0339
DEBUG - 2022-05-31 04:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:19 --> Total execution time: 0.0387
DEBUG - 2022-05-31 04:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:23 --> Total execution time: 0.0421
DEBUG - 2022-05-31 04:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:24 --> Total execution time: 0.0349
DEBUG - 2022-05-31 04:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:28 --> Total execution time: 0.0853
DEBUG - 2022-05-31 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:38:31 --> Total execution time: 0.0332
DEBUG - 2022-05-31 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:39:18 --> Total execution time: 1.5531
DEBUG - 2022-05-31 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:09:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:09:19 --> 404 Page Not Found: Lost-password/index
DEBUG - 2022-05-31 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:09:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:40:05 --> Total execution time: 3.3450
DEBUG - 2022-05-31 04:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:40:24 --> Total execution time: 0.0861
DEBUG - 2022-05-31 04:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:40:28 --> Total execution time: 0.0428
DEBUG - 2022-05-31 04:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:40:31 --> Total execution time: 0.0271
DEBUG - 2022-05-31 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:40:54 --> Total execution time: 0.0384
DEBUG - 2022-05-31 04:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:41:12 --> Total execution time: 0.0282
DEBUG - 2022-05-31 04:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:11:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:41:18 --> Total execution time: 0.0203
DEBUG - 2022-05-31 04:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:41:21 --> Total execution time: 0.0615
DEBUG - 2022-05-31 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:12:23 --> Total execution time: 0.0548
DEBUG - 2022-05-31 04:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:42:29 --> Total execution time: 0.0350
DEBUG - 2022-05-31 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:43:03 --> Total execution time: 4.9005
DEBUG - 2022-05-31 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:32 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:33 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:33 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:13:33 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:44:41 --> Total execution time: 0.0264
DEBUG - 2022-05-31 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:44:54 --> Total execution time: 0.0397
DEBUG - 2022-05-31 04:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:44:59 --> Total execution time: 0.0588
DEBUG - 2022-05-31 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:03 --> Total execution time: 0.0317
DEBUG - 2022-05-31 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:06 --> Total execution time: 0.0356
DEBUG - 2022-05-31 04:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:08 --> Total execution time: 0.0266
DEBUG - 2022-05-31 14:45:08 --> Total execution time: 4.6476
DEBUG - 2022-05-31 04:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:14 --> Total execution time: 0.0397
DEBUG - 2022-05-31 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:16 --> Total execution time: 0.0302
DEBUG - 2022-05-31 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:19 --> Total execution time: 0.0530
DEBUG - 2022-05-31 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:23 --> Total execution time: 0.0364
DEBUG - 2022-05-31 04:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:25 --> Total execution time: 0.0617
DEBUG - 2022-05-31 04:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:31 --> Total execution time: 0.0582
DEBUG - 2022-05-31 04:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:45:46 --> Total execution time: 4.8529
DEBUG - 2022-05-31 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:17 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:17 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:32 --> 404 Page Not Found: Wp-admin/index
DEBUG - 2022-05-31 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:16:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:05 --> Total execution time: 0.0464
DEBUG - 2022-05-31 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:06 --> Total execution time: 0.0307
DEBUG - 2022-05-31 04:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:12 --> Total execution time: 0.0221
DEBUG - 2022-05-31 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:13 --> Total execution time: 0.0205
DEBUG - 2022-05-31 04:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:24 --> Total execution time: 0.0435
DEBUG - 2022-05-31 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:36 --> Total execution time: 0.0391
DEBUG - 2022-05-31 04:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:41 --> Total execution time: 0.0253
DEBUG - 2022-05-31 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 14:47:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 14:47:42 --> Total execution time: 0.1914
DEBUG - 2022-05-31 04:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:44 --> Total execution time: 0.0320
DEBUG - 2022-05-31 04:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:50 --> Total execution time: 4.4769
DEBUG - 2022-05-31 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:47:56 --> Total execution time: 0.0698
DEBUG - 2022-05-31 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:48:01 --> Total execution time: 0.0576
DEBUG - 2022-05-31 04:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:48:13 --> Total execution time: 0.0245
DEBUG - 2022-05-31 04:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:26 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:18:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:18:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:48:54 --> Total execution time: 0.0281
DEBUG - 2022-05-31 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:07 --> Total execution time: 0.0424
DEBUG - 2022-05-31 04:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:20 --> Total execution time: 0.0289
DEBUG - 2022-05-31 04:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:22 --> Total execution time: 0.0361
DEBUG - 2022-05-31 04:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:28 --> Total execution time: 0.0511
DEBUG - 2022-05-31 04:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:38 --> Total execution time: 0.0316
DEBUG - 2022-05-31 04:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:48 --> Total execution time: 0.0463
DEBUG - 2022-05-31 04:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:55 --> Total execution time: 0.0242
DEBUG - 2022-05-31 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:49:58 --> Total execution time: 0.0273
DEBUG - 2022-05-31 04:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:20:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:50:03 --> Total execution time: 0.0214
DEBUG - 2022-05-31 04:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:50:43 --> Total execution time: 0.0300
DEBUG - 2022-05-31 04:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:20:53 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-31 04:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:20:55 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:50:55 --> Total execution time: 0.0223
DEBUG - 2022-05-31 04:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:51:28 --> Total execution time: 0.0306
DEBUG - 2022-05-31 04:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:52:26 --> Total execution time: 0.0281
DEBUG - 2022-05-31 04:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:52:39 --> Total execution time: 0.0293
DEBUG - 2022-05-31 04:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:52:47 --> Total execution time: 0.0306
DEBUG - 2022-05-31 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:00 --> Total execution time: 0.0569
DEBUG - 2022-05-31 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:01 --> Total execution time: 0.0333
DEBUG - 2022-05-31 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:05 --> Total execution time: 0.0246
DEBUG - 2022-05-31 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:06 --> Total execution time: 0.0481
DEBUG - 2022-05-31 04:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:17 --> Total execution time: 0.1121
DEBUG - 2022-05-31 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:27 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:27 --> Total execution time: 0.0282
DEBUG - 2022-05-31 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:53:39 --> Total execution time: 0.0248
DEBUG - 2022-05-31 04:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:24:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:54:01 --> Total execution time: 0.0360
DEBUG - 2022-05-31 04:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:55:41 --> Total execution time: 0.0546
DEBUG - 2022-05-31 04:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:55:59 --> Total execution time: 0.0323
DEBUG - 2022-05-31 04:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:10 --> Total execution time: 0.0473
DEBUG - 2022-05-31 04:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:26:19 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:19 --> Total execution time: 0.0449
DEBUG - 2022-05-31 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:26:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:26 --> Total execution time: 0.0400
DEBUG - 2022-05-31 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:26:37 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:37 --> Total execution time: 0.0430
DEBUG - 2022-05-31 04:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:00 --> Total execution time: 0.0335
DEBUG - 2022-05-31 04:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:05 --> Total execution time: 0.0636
DEBUG - 2022-05-31 04:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:05 --> Total execution time: 0.0229
DEBUG - 2022-05-31 04:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:17 --> Total execution time: 0.0807
DEBUG - 2022-05-31 04:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:29:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:29:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:59:28 --> Total execution time: 0.0698
DEBUG - 2022-05-31 04:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:30:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:00:28 --> Total execution time: 0.0324
DEBUG - 2022-05-31 04:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:00:45 --> Total execution time: 0.0258
DEBUG - 2022-05-31 04:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:31:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:01:43 --> Total execution time: 0.0571
DEBUG - 2022-05-31 04:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:31:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-31 04:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:01:56 --> Total execution time: 0.0533
DEBUG - 2022-05-31 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:02:11 --> Total execution time: 0.1229
DEBUG - 2022-05-31 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:32:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:02:11 --> Total execution time: 0.1937
DEBUG - 2022-05-31 04:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:03:01 --> Total execution time: 0.0349
DEBUG - 2022-05-31 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:06 --> Total execution time: 0.0222
DEBUG - 2022-05-31 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:07 --> Total execution time: 0.0376
DEBUG - 2022-05-31 04:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:07 --> Total execution time: 0.0539
DEBUG - 2022-05-31 04:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:08 --> Total execution time: 0.0439
DEBUG - 2022-05-31 04:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:10 --> Total execution time: 0.0326
DEBUG - 2022-05-31 04:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:10 --> Total execution time: 0.0452
DEBUG - 2022-05-31 04:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:03:33 --> Total execution time: 0.0442
DEBUG - 2022-05-31 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:41 --> Total execution time: 0.0323
DEBUG - 2022-05-31 04:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:43 --> Total execution time: 0.0484
DEBUG - 2022-05-31 04:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:33:43 --> Total execution time: 0.0634
DEBUG - 2022-05-31 04:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:34:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:04:09 --> Total execution time: 0.0292
DEBUG - 2022-05-31 04:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:34:51 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:04:51 --> Total execution time: 0.0384
DEBUG - 2022-05-31 04:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:36:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:06:20 --> Total execution time: 0.0357
DEBUG - 2022-05-31 04:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:36:36 --> Total execution time: 0.0282
DEBUG - 2022-05-31 04:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:36:37 --> Total execution time: 0.0289
DEBUG - 2022-05-31 04:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:36:37 --> Total execution time: 0.0419
DEBUG - 2022-05-31 04:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:39:41 --> Total execution time: 0.0609
DEBUG - 2022-05-31 04:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:39:48 --> Total execution time: 0.0808
DEBUG - 2022-05-31 04:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:40:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:40:59 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-31 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:41:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:11:04 --> Total execution time: 0.0696
DEBUG - 2022-05-31 04:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:41:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:11:25 --> Total execution time: 1.5477
DEBUG - 2022-05-31 04:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:41:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:41:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:11:39 --> Total execution time: 0.0519
DEBUG - 2022-05-31 04:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:06 --> Total execution time: 0.0272
DEBUG - 2022-05-31 04:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:16 --> Total execution time: 0.0278
DEBUG - 2022-05-31 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:37 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:37 --> Total execution time: 0.0307
DEBUG - 2022-05-31 04:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:12:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:12:38 --> Total execution time: 0.1591
DEBUG - 2022-05-31 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:47 --> Total execution time: 0.0420
DEBUG - 2022-05-31 04:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:42:55 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:12:55 --> Total execution time: 0.0330
DEBUG - 2022-05-31 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:43:03 --> Total execution time: 0.0436
DEBUG - 2022-05-31 04:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:43:04 --> Total execution time: 0.0340
DEBUG - 2022-05-31 04:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:43:04 --> Total execution time: 0.0567
DEBUG - 2022-05-31 04:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:13:13 --> Total execution time: 0.0422
DEBUG - 2022-05-31 04:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:13:15 --> Total execution time: 0.0279
DEBUG - 2022-05-31 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:13:21 --> Total execution time: 0.0244
DEBUG - 2022-05-31 04:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:44:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:14:09 --> Total execution time: 0.0228
DEBUG - 2022-05-31 04:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:44:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:14:12 --> Total execution time: 0.0371
DEBUG - 2022-05-31 04:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:14:19 --> Total execution time: 0.0303
DEBUG - 2022-05-31 04:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:14:33 --> Total execution time: 0.0253
DEBUG - 2022-05-31 04:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:05 --> Total execution time: 0.0483
DEBUG - 2022-05-31 04:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:10 --> Total execution time: 0.0614
DEBUG - 2022-05-31 04:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:13 --> Total execution time: 0.0371
DEBUG - 2022-05-31 04:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:33 --> Total execution time: 0.0278
DEBUG - 2022-05-31 04:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:45:40 --> Total execution time: 0.0374
DEBUG - 2022-05-31 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:45:41 --> Total execution time: 0.0410
DEBUG - 2022-05-31 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:45:41 --> Total execution time: 0.0264
DEBUG - 2022-05-31 04:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:43 --> Total execution time: 0.0423
DEBUG - 2022-05-31 04:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:15:46 --> Total execution time: 0.0520
DEBUG - 2022-05-31 04:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:01 --> Total execution time: 0.0273
DEBUG - 2022-05-31 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:04 --> Total execution time: 0.0267
DEBUG - 2022-05-31 04:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:13 --> Total execution time: 0.0699
DEBUG - 2022-05-31 04:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:18 --> Total execution time: 0.0296
DEBUG - 2022-05-31 04:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:27 --> Total execution time: 0.0272
DEBUG - 2022-05-31 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:30 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:30 --> Total execution time: 0.0584
DEBUG - 2022-05-31 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:35 --> Total execution time: 0.0260
DEBUG - 2022-05-31 04:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:36 --> Total execution time: 0.0262
DEBUG - 2022-05-31 04:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:36 --> Total execution time: 0.0585
DEBUG - 2022-05-31 04:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:43 --> Total execution time: 0.0580
DEBUG - 2022-05-31 04:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:46 --> Total execution time: 0.0318
DEBUG - 2022-05-31 04:46:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:46 --> Total execution time: 0.0418
DEBUG - 2022-05-31 04:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:16:49 --> Total execution time: 0.0180
DEBUG - 2022-05-31 04:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:17:14 --> Total execution time: 0.0298
DEBUG - 2022-05-31 04:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:17:20 --> Total execution time: 0.0476
DEBUG - 2022-05-31 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:17:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:17:21 --> Total execution time: 0.0468
DEBUG - 2022-05-31 04:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:17:25 --> Total execution time: 0.0516
DEBUG - 2022-05-31 04:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:15 --> Total execution time: 0.1979
DEBUG - 2022-05-31 04:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:17 --> Total execution time: 0.0621
DEBUG - 2022-05-31 04:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:18 --> Total execution time: 0.0495
DEBUG - 2022-05-31 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:24 --> Total execution time: 0.0790
DEBUG - 2022-05-31 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:27 --> Total execution time: 0.0385
DEBUG - 2022-05-31 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:29 --> Total execution time: 0.0345
DEBUG - 2022-05-31 04:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:33 --> Total execution time: 0.0396
DEBUG - 2022-05-31 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:38 --> Total execution time: 0.0545
DEBUG - 2022-05-31 04:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:18:47 --> Total execution time: 0.0288
DEBUG - 2022-05-31 04:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:19:08 --> Total execution time: 0.0321
DEBUG - 2022-05-31 04:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:19:33 --> Total execution time: 0.0478
DEBUG - 2022-05-31 04:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:49:37 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-05-31 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:49:43 --> Total execution time: 0.0385
DEBUG - 2022-05-31 04:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:49:45 --> Total execution time: 0.0427
DEBUG - 2022-05-31 04:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:49:45 --> Total execution time: 0.0780
DEBUG - 2022-05-31 04:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:20:09 --> Total execution time: 0.0779
DEBUG - 2022-05-31 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:50:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:20:10 --> Total execution time: 0.0549
DEBUG - 2022-05-31 04:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:20:14 --> Total execution time: 0.0345
DEBUG - 2022-05-31 04:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:20:47 --> Total execution time: 0.0810
DEBUG - 2022-05-31 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:21:35 --> Total execution time: 0.0866
DEBUG - 2022-05-31 04:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:21:38 --> Total execution time: 0.0996
DEBUG - 2022-05-31 04:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:51:42 --> Total execution time: 0.0261
DEBUG - 2022-05-31 04:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:51:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:51:44 --> Total execution time: 0.0242
DEBUG - 2022-05-31 04:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:51:44 --> Total execution time: 0.0189
DEBUG - 2022-05-31 04:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:21:45 --> Total execution time: 1.4588
DEBUG - 2022-05-31 04:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:51:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:51:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 04:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:22:23 --> Total execution time: 0.0361
DEBUG - 2022-05-31 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:40 --> Total execution time: 0.0294
DEBUG - 2022-05-31 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:43 --> Total execution time: 0.0307
DEBUG - 2022-05-31 04:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:23:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:23:45 --> Total execution time: 0.1838
DEBUG - 2022-05-31 04:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:47 --> Total execution time: 0.0478
DEBUG - 2022-05-31 04:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:53:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:23:56 --> Total execution time: 0.0499
DEBUG - 2022-05-31 15:23:57 --> Total execution time: 1.5701
DEBUG - 2022-05-31 04:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:24:23 --> Total execution time: 0.0622
DEBUG - 2022-05-31 04:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:24:23 --> Total execution time: 0.0494
DEBUG - 2022-05-31 04:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:24:29 --> Total execution time: 0.0778
DEBUG - 2022-05-31 04:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:54:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:24:41 --> Total execution time: 0.0533
DEBUG - 2022-05-31 04:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:25:23 --> Total execution time: 0.0928
DEBUG - 2022-05-31 04:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:25:42 --> Total execution time: 0.0333
DEBUG - 2022-05-31 04:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:25:54 --> Total execution time: 0.0449
DEBUG - 2022-05-31 04:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:25:59 --> Total execution time: 0.0409
DEBUG - 2022-05-31 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:26:16 --> Total execution time: 0.0262
DEBUG - 2022-05-31 04:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:26:26 --> Total execution time: 0.0510
DEBUG - 2022-05-31 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:26:33 --> Total execution time: 0.0325
DEBUG - 2022-05-31 04:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:26:56 --> Total execution time: 0.0580
DEBUG - 2022-05-31 04:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:27:01 --> Total execution time: 0.0247
DEBUG - 2022-05-31 04:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:57:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 04:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:27:16 --> Total execution time: 0.0384
DEBUG - 2022-05-31 04:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:57:33 --> Total execution time: 0.0335
DEBUG - 2022-05-31 04:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:57:34 --> Total execution time: 0.0555
DEBUG - 2022-05-31 04:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:57:34 --> Total execution time: 0.0488
DEBUG - 2022-05-31 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 04:59:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:29:25 --> Total execution time: 1.4725
DEBUG - 2022-05-31 04:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 04:59:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 04:59:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:30:02 --> Total execution time: 0.0533
DEBUG - 2022-05-31 05:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:00:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:30:14 --> Total execution time: 0.0396
DEBUG - 2022-05-31 05:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:30:56 --> Total execution time: 0.0722
DEBUG - 2022-05-31 05:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:31:11 --> Total execution time: 0.0485
DEBUG - 2022-05-31 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:31:13 --> Total execution time: 0.0561
DEBUG - 2022-05-31 05:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:31:39 --> Total execution time: 0.0514
DEBUG - 2022-05-31 05:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:31:56 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:31:57 --> Total execution time: 0.0277
DEBUG - 2022-05-31 05:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:32:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:32:00 --> Total execution time: 0.1849
DEBUG - 2022-05-31 05:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:05 --> Total execution time: 0.0332
DEBUG - 2022-05-31 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:13 --> Total execution time: 0.0288
DEBUG - 2022-05-31 05:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:25 --> Total execution time: 0.0253
DEBUG - 2022-05-31 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:28 --> Total execution time: 0.0231
DEBUG - 2022-05-31 05:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:34 --> Total execution time: 0.0282
DEBUG - 2022-05-31 05:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:46 --> Total execution time: 0.0715
DEBUG - 2022-05-31 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:50 --> Total execution time: 0.0219
DEBUG - 2022-05-31 05:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:32:57 --> Total execution time: 0.0339
DEBUG - 2022-05-31 05:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:03 --> Total execution time: 0.0281
DEBUG - 2022-05-31 05:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:04 --> Total execution time: 0.0216
DEBUG - 2022-05-31 05:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:11 --> Total execution time: 0.0439
DEBUG - 2022-05-31 05:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:19 --> Total execution time: 0.0532
DEBUG - 2022-05-31 05:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:22 --> Total execution time: 0.0422
DEBUG - 2022-05-31 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:25 --> Total execution time: 0.0303
DEBUG - 2022-05-31 05:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:28 --> Total execution time: 0.0316
DEBUG - 2022-05-31 05:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:32 --> Total execution time: 0.0483
DEBUG - 2022-05-31 05:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:40 --> Total execution time: 0.0250
DEBUG - 2022-05-31 05:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:44 --> Total execution time: 0.0401
DEBUG - 2022-05-31 05:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:46 --> Total execution time: 0.0390
DEBUG - 2022-05-31 05:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:03:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:48 --> Total execution time: 0.0389
DEBUG - 2022-05-31 05:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:49 --> Total execution time: 0.0784
DEBUG - 2022-05-31 05:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:33:53 --> Total execution time: 0.0286
DEBUG - 2022-05-31 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:04:04 --> Total execution time: 0.0244
DEBUG - 2022-05-31 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:04 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:34:04 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-05-31 05:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:04 --> Total execution time: 0.0355
DEBUG - 2022-05-31 05:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:05 --> Total execution time: 0.0590
DEBUG - 2022-05-31 05:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:04:08 --> Total execution time: 0.0331
DEBUG - 2022-05-31 05:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:04:08 --> Total execution time: 0.0263
DEBUG - 2022-05-31 05:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:09 --> Total execution time: 0.0441
DEBUG - 2022-05-31 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:11 --> Total execution time: 0.0336
DEBUG - 2022-05-31 05:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:14 --> Total execution time: 0.0355
DEBUG - 2022-05-31 05:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:19 --> Total execution time: 0.0341
DEBUG - 2022-05-31 05:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:24 --> Total execution time: 0.0503
DEBUG - 2022-05-31 05:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:29 --> Total execution time: 0.0287
DEBUG - 2022-05-31 05:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:31 --> Total execution time: 0.0327
DEBUG - 2022-05-31 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:35 --> Total execution time: 0.0247
DEBUG - 2022-05-31 05:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:35 --> Total execution time: 0.0275
DEBUG - 2022-05-31 05:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:36 --> Total execution time: 0.0283
DEBUG - 2022-05-31 05:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:40 --> Total execution time: 0.0465
DEBUG - 2022-05-31 05:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:49 --> Total execution time: 0.0568
DEBUG - 2022-05-31 05:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:53 --> Total execution time: 0.0473
DEBUG - 2022-05-31 05:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:34:58 --> Total execution time: 0.0300
DEBUG - 2022-05-31 05:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:15 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:15 --> Total execution time: 0.0334
DEBUG - 2022-05-31 05:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:21 --> Total execution time: 0.0810
DEBUG - 2022-05-31 05:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:23 --> Total execution time: 0.0299
DEBUG - 2022-05-31 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:28 --> Total execution time: 0.0582
DEBUG - 2022-05-31 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:30 --> Total execution time: 0.0446
DEBUG - 2022-05-31 05:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:32 --> Total execution time: 0.0368
DEBUG - 2022-05-31 05:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:36 --> Total execution time: 0.0277
DEBUG - 2022-05-31 05:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:37 --> Total execution time: 0.0326
DEBUG - 2022-05-31 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:39 --> Total execution time: 0.0479
DEBUG - 2022-05-31 05:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:40 --> Total execution time: 0.0341
DEBUG - 2022-05-31 05:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:45 --> Total execution time: 0.0356
DEBUG - 2022-05-31 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:54 --> Total execution time: 0.0441
DEBUG - 2022-05-31 05:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:57 --> Total execution time: 0.0287
DEBUG - 2022-05-31 05:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:35:57 --> Total execution time: 0.0286
DEBUG - 2022-05-31 05:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:00 --> Total execution time: 0.0596
DEBUG - 2022-05-31 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:02 --> Total execution time: 0.0667
DEBUG - 2022-05-31 05:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:05 --> Total execution time: 0.0404
DEBUG - 2022-05-31 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:19 --> Total execution time: 0.0351
DEBUG - 2022-05-31 05:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:26 --> Total execution time: 0.0351
DEBUG - 2022-05-31 05:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:26 --> Total execution time: 0.0256
DEBUG - 2022-05-31 05:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:28 --> Total execution time: 0.0336
DEBUG - 2022-05-31 05:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:35 --> Total execution time: 0.0423
DEBUG - 2022-05-31 05:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:36:39 --> Total execution time: 0.1173
DEBUG - 2022-05-31 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:28 --> Total execution time: 0.0246
DEBUG - 2022-05-31 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:48 --> Total execution time: 0.0292
DEBUG - 2022-05-31 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:52 --> Total execution time: 0.1055
DEBUG - 2022-05-31 05:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:54 --> Total execution time: 0.0441
DEBUG - 2022-05-31 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:55 --> Total execution time: 0.0503
DEBUG - 2022-05-31 05:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:37:58 --> Total execution time: 0.0573
DEBUG - 2022-05-31 05:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:12 --> Total execution time: 0.0800
DEBUG - 2022-05-31 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:28 --> Total execution time: 0.0331
DEBUG - 2022-05-31 05:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:35 --> Total execution time: 0.0564
DEBUG - 2022-05-31 05:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:38 --> Total execution time: 0.0425
DEBUG - 2022-05-31 05:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:47 --> Total execution time: 0.0294
DEBUG - 2022-05-31 05:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:49 --> Total execution time: 0.0317
DEBUG - 2022-05-31 05:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:52 --> Total execution time: 0.0510
DEBUG - 2022-05-31 05:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:38:58 --> Total execution time: 0.0267
DEBUG - 2022-05-31 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:39:24 --> Total execution time: 0.0260
DEBUG - 2022-05-31 05:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:39:29 --> Total execution time: 0.0323
DEBUG - 2022-05-31 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:14 --> Total execution time: 0.0537
DEBUG - 2022-05-31 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:31 --> Total execution time: 0.0493
DEBUG - 2022-05-31 15:40:35 --> Total execution time: 4.6709
DEBUG - 2022-05-31 05:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:38 --> Total execution time: 0.0517
DEBUG - 2022-05-31 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:40 --> Total execution time: 0.0332
DEBUG - 2022-05-31 05:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:45 --> Total execution time: 0.1571
DEBUG - 2022-05-31 05:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:48 --> Total execution time: 0.0247
DEBUG - 2022-05-31 05:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:51 --> Total execution time: 0.0248
DEBUG - 2022-05-31 05:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:40:52 --> Total execution time: 0.0330
DEBUG - 2022-05-31 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:10:53 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:10:53 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:10:53 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:03 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:04 --> Total execution time: 0.0422
DEBUG - 2022-05-31 05:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:06 --> Total execution time: 0.0301
DEBUG - 2022-05-31 15:41:08 --> Total execution time: 4.5816
DEBUG - 2022-05-31 05:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:13 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:15 --> UTF-8 Support Enabled
ERROR - 2022-05-31 05:11:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:19 --> Total execution time: 0.0253
DEBUG - 2022-05-31 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:22 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:22 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:28 --> Total execution time: 0.0534
DEBUG - 2022-05-31 05:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:29 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:32 --> Total execution time: 0.0644
DEBUG - 2022-05-31 05:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:40 --> Total execution time: 0.0408
DEBUG - 2022-05-31 05:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:41:51 --> Total execution time: 0.0599
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> UTF-8 Support Enabled
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:11:58 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:42:15 --> Total execution time: 0.0505
DEBUG - 2022-05-31 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:42:19 --> Total execution time: 0.0267
DEBUG - 2022-05-31 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:42:25 --> Total execution time: 4.5514
DEBUG - 2022-05-31 05:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:42:29 --> Total execution time: 4.7632
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:13:19 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:43:20 --> Total execution time: 0.0346
DEBUG - 2022-05-31 05:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:44:03 --> Total execution time: 0.0185
DEBUG - 2022-05-31 05:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:15:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:45:18 --> Total execution time: 0.0308
DEBUG - 2022-05-31 05:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:15:19 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:45:19 --> Total execution time: 0.0352
DEBUG - 2022-05-31 05:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:15:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:45:26 --> Total execution time: 0.0320
DEBUG - 2022-05-31 05:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:46:04 --> Total execution time: 0.0278
DEBUG - 2022-05-31 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:46:33 --> Total execution time: 0.0251
DEBUG - 2022-05-31 05:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:46:46 --> Total execution time: 0.0292
DEBUG - 2022-05-31 05:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:14 --> Total execution time: 0.0688
DEBUG - 2022-05-31 05:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:16 --> Total execution time: 0.0339
DEBUG - 2022-05-31 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:20 --> Total execution time: 0.0240
DEBUG - 2022-05-31 05:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:26 --> Total execution time: 0.0566
DEBUG - 2022-05-31 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:43 --> Total execution time: 0.0886
DEBUG - 2022-05-31 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:44 --> Total execution time: 0.0215
DEBUG - 2022-05-31 05:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:47:52 --> Total execution time: 0.0241
DEBUG - 2022-05-31 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:05 --> Total execution time: 0.0552
DEBUG - 2022-05-31 05:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:13 --> Total execution time: 0.0712
DEBUG - 2022-05-31 05:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:16 --> Total execution time: 0.0277
DEBUG - 2022-05-31 05:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:21 --> Total execution time: 0.0276
DEBUG - 2022-05-31 05:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:32 --> Total execution time: 0.0279
DEBUG - 2022-05-31 05:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:34 --> Total execution time: 0.0328
DEBUG - 2022-05-31 05:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:38 --> Total execution time: 0.0315
DEBUG - 2022-05-31 05:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:39 --> Total execution time: 0.0426
DEBUG - 2022-05-31 05:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:40 --> Total execution time: 0.0301
DEBUG - 2022-05-31 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:48:53 --> Total execution time: 0.0324
DEBUG - 2022-05-31 05:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:03 --> Total execution time: 0.0320
DEBUG - 2022-05-31 05:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:25 --> Total execution time: 0.0414
DEBUG - 2022-05-31 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:28 --> Total execution time: 0.0380
DEBUG - 2022-05-31 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:28 --> Total execution time: 0.0288
DEBUG - 2022-05-31 05:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:31 --> Total execution time: 0.0338
DEBUG - 2022-05-31 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:35 --> Total execution time: 0.0361
DEBUG - 2022-05-31 05:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:42 --> Total execution time: 0.0389
DEBUG - 2022-05-31 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:45 --> Total execution time: 0.0362
DEBUG - 2022-05-31 05:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:49:50 --> Total execution time: 0.0397
DEBUG - 2022-05-31 05:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:01 --> Total execution time: 0.0642
DEBUG - 2022-05-31 05:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:04 --> Total execution time: 0.0376
DEBUG - 2022-05-31 05:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:08 --> Total execution time: 0.0362
DEBUG - 2022-05-31 05:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:50:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 15:50:10 --> Total execution time: 0.1808
DEBUG - 2022-05-31 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:11 --> Total execution time: 0.0330
DEBUG - 2022-05-31 05:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:30 --> Total execution time: 4.8205
DEBUG - 2022-05-31 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:20:33 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:50:40 --> Total execution time: 0.0444
DEBUG - 2022-05-31 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:05 --> Total execution time: 0.0313
DEBUG - 2022-05-31 05:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:06 --> Total execution time: 0.1061
DEBUG - 2022-05-31 05:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:08 --> Total execution time: 0.1047
DEBUG - 2022-05-31 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:10 --> Total execution time: 0.0471
DEBUG - 2022-05-31 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:18 --> UTF-8 Support Enabled
ERROR - 2022-05-31 05:21:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:20 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:20 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:20 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:21:21 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:46 --> Total execution time: 0.0254
DEBUG - 2022-05-31 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:47 --> Total execution time: 0.0299
DEBUG - 2022-05-31 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:51 --> Total execution time: 0.0223
DEBUG - 2022-05-31 05:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:21:52 --> Total execution time: 0.0329
DEBUG - 2022-05-31 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:51:57 --> Total execution time: 0.0249
DEBUG - 2022-05-31 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:22:02 --> Total execution time: 0.0264
DEBUG - 2022-05-31 05:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:52:26 --> Total execution time: 0.0284
DEBUG - 2022-05-31 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:52:32 --> Total execution time: 0.0297
DEBUG - 2022-05-31 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:22:38 --> Total execution time: 0.0417
DEBUG - 2022-05-31 05:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:52:46 --> Total execution time: 0.0318
DEBUG - 2022-05-31 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:52:50 --> Total execution time: 0.0806
DEBUG - 2022-05-31 05:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:54:26 --> Total execution time: 0.0602
DEBUG - 2022-05-31 05:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:54:42 --> Total execution time: 0.0749
DEBUG - 2022-05-31 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:47 --> Total execution time: 0.0257
DEBUG - 2022-05-31 05:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:24:58 --> Total execution time: 0.0191
DEBUG - 2022-05-31 05:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:03 --> Total execution time: 0.0253
DEBUG - 2022-05-31 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:10 --> Total execution time: 0.0294
DEBUG - 2022-05-31 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:12 --> Total execution time: 0.0315
DEBUG - 2022-05-31 05:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:14 --> Total execution time: 0.0286
DEBUG - 2022-05-31 05:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:25:16 --> Total execution time: 0.0211
DEBUG - 2022-05-31 05:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:55:17 --> Total execution time: 0.0596
DEBUG - 2022-05-31 05:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:55:30 --> Total execution time: 0.0281
DEBUG - 2022-05-31 05:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:55:38 --> Total execution time: 0.0465
DEBUG - 2022-05-31 05:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:55:41 --> Total execution time: 0.0479
DEBUG - 2022-05-31 05:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:56:12 --> Total execution time: 0.0775
DEBUG - 2022-05-31 05:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:26:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:56:26 --> Total execution time: 0.0669
DEBUG - 2022-05-31 05:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:26:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:56:34 --> Total execution time: 0.0577
DEBUG - 2022-05-31 05:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:56:56 --> Total execution time: 0.0370
DEBUG - 2022-05-31 05:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:57:02 --> Total execution time: 0.0675
DEBUG - 2022-05-31 05:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:57:08 --> Total execution time: 0.0641
DEBUG - 2022-05-31 05:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:57:28 --> Total execution time: 0.0279
DEBUG - 2022-05-31 05:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:57:32 --> Total execution time: 0.0324
DEBUG - 2022-05-31 05:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:57:36 --> Total execution time: 0.0720
DEBUG - 2022-05-31 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:58:09 --> Total execution time: 0.0725
DEBUG - 2022-05-31 05:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:28:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:58:44 --> Total execution time: 0.0548
DEBUG - 2022-05-31 05:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:29:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:59:16 --> Total execution time: 0.0217
DEBUG - 2022-05-31 05:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:29:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:59:22 --> Total execution time: 0.0286
DEBUG - 2022-05-31 05:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:59:44 --> Total execution time: 0.0195
DEBUG - 2022-05-31 05:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:59:57 --> Total execution time: 0.0588
DEBUG - 2022-05-31 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:08 --> Total execution time: 0.0334
DEBUG - 2022-05-31 05:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:14 --> Total execution time: 0.0304
DEBUG - 2022-05-31 05:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:22 --> Total execution time: 0.0394
DEBUG - 2022-05-31 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:29 --> Total execution time: 0.0479
DEBUG - 2022-05-31 05:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:50 --> Total execution time: 0.0458
DEBUG - 2022-05-31 05:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:54 --> Total execution time: 0.0669
DEBUG - 2022-05-31 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:03 --> Total execution time: 0.0224
DEBUG - 2022-05-31 05:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:05 --> Total execution time: 0.0977
DEBUG - 2022-05-31 05:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:16 --> Total execution time: 0.0434
DEBUG - 2022-05-31 05:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:29 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:29 --> Total execution time: 0.0705
DEBUG - 2022-05-31 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:39 --> Total execution time: 0.0313
DEBUG - 2022-05-31 05:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:48 --> Total execution time: 0.0406
DEBUG - 2022-05-31 05:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:31:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:01:56 --> Total execution time: 0.0260
DEBUG - 2022-05-31 05:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:02:11 --> Total execution time: 0.0307
DEBUG - 2022-05-31 05:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:32:13 --> Total execution time: 0.0392
DEBUG - 2022-05-31 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:32:14 --> Total execution time: 0.0363
DEBUG - 2022-05-31 05:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:32:14 --> Total execution time: 0.0547
DEBUG - 2022-05-31 05:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:02:22 --> Total execution time: 0.0637
DEBUG - 2022-05-31 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:03:50 --> Total execution time: 0.0620
DEBUG - 2022-05-31 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:34:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:04:35 --> Total execution time: 0.0543
DEBUG - 2022-05-31 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:04:57 --> Total execution time: 0.0576
DEBUG - 2022-05-31 05:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:12 --> Total execution time: 0.0583
DEBUG - 2022-05-31 05:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:16 --> Total execution time: 0.0444
DEBUG - 2022-05-31 05:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:35 --> Total execution time: 0.0369
DEBUG - 2022-05-31 05:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:35:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:38 --> Total execution time: 1.5230
DEBUG - 2022-05-31 05:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:35:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:46 --> Total execution time: 0.0564
DEBUG - 2022-05-31 05:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:48 --> Total execution time: 0.0324
DEBUG - 2022-05-31 05:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:05:58 --> Total execution time: 0.0395
DEBUG - 2022-05-31 05:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:18 --> Total execution time: 0.0369
DEBUG - 2022-05-31 05:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 16:06:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 16:06:20 --> Total execution time: 0.1848
DEBUG - 2022-05-31 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:29 --> Total execution time: 0.0297
DEBUG - 2022-05-31 05:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:33 --> Total execution time: 0.0342
DEBUG - 2022-05-31 05:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:38 --> Total execution time: 0.0421
DEBUG - 2022-05-31 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:57 --> Total execution time: 0.0271
DEBUG - 2022-05-31 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:36:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:36:57 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-05-31 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 05:40:14 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-31 05:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:22 --> Total execution time: 0.0211
DEBUG - 2022-05-31 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:43 --> Total execution time: 0.0312
DEBUG - 2022-05-31 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:46 --> Total execution time: 0.0248
DEBUG - 2022-05-31 05:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:47 --> Total execution time: 0.0307
DEBUG - 2022-05-31 05:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:52 --> Total execution time: 0.0785
DEBUG - 2022-05-31 05:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:11:00 --> Total execution time: 0.0258
DEBUG - 2022-05-31 05:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:41:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:11:10 --> Total execution time: 0.0462
DEBUG - 2022-05-31 05:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:41:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:11:57 --> Total execution time: 0.0774
DEBUG - 2022-05-31 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:42:37 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:12:37 --> Total execution time: 0.0314
DEBUG - 2022-05-31 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:12:45 --> Total execution time: 0.0331
DEBUG - 2022-05-31 05:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:43:21 --> Total execution time: 0.0420
DEBUG - 2022-05-31 05:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:43:21 --> Total execution time: 0.0300
DEBUG - 2022-05-31 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:43:24 --> Total execution time: 0.0540
DEBUG - 2022-05-31 05:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:43:24 --> Total execution time: 0.0669
DEBUG - 2022-05-31 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:36 --> Total execution time: 0.0511
DEBUG - 2022-05-31 05:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:44 --> Total execution time: 0.0342
DEBUG - 2022-05-31 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:49 --> Total execution time: 0.0773
DEBUG - 2022-05-31 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:43:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:54 --> Total execution time: 0.0347
DEBUG - 2022-05-31 05:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:11 --> Total execution time: 0.0266
DEBUG - 2022-05-31 05:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:31 --> Total execution time: 0.0350
DEBUG - 2022-05-31 05:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:15:36 --> Total execution time: 0.0704
DEBUG - 2022-05-31 05:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:45:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:15:51 --> Total execution time: 0.0240
DEBUG - 2022-05-31 05:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:16:25 --> Total execution time: 0.0367
DEBUG - 2022-05-31 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:47:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:17:06 --> Total execution time: 0.0332
DEBUG - 2022-05-31 05:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:47:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:17:50 --> Total execution time: 0.0806
DEBUG - 2022-05-31 05:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:18:02 --> Total execution time: 0.0581
DEBUG - 2022-05-31 05:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:18:06 --> Total execution time: 0.0481
DEBUG - 2022-05-31 05:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:18:12 --> Total execution time: 0.0457
DEBUG - 2022-05-31 05:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:18:40 --> Total execution time: 0.0348
DEBUG - 2022-05-31 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:19:30 --> Total execution time: 0.0285
DEBUG - 2022-05-31 05:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:19:41 --> Total execution time: 0.0826
DEBUG - 2022-05-31 05:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:19:59 --> Total execution time: 0.1145
DEBUG - 2022-05-31 16:19:59 --> Total execution time: 0.0655
DEBUG - 2022-05-31 05:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:20:22 --> Total execution time: 0.0312
DEBUG - 2022-05-31 05:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:20:42 --> Total execution time: 0.0432
DEBUG - 2022-05-31 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:20:50 --> Total execution time: 0.0289
DEBUG - 2022-05-31 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:20:53 --> Total execution time: 0.0361
DEBUG - 2022-05-31 05:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:21:52 --> Total execution time: 0.0334
DEBUG - 2022-05-31 05:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:22:06 --> Total execution time: 0.0206
DEBUG - 2022-05-31 05:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:22:40 --> Total execution time: 0.0495
DEBUG - 2022-05-31 05:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:22:52 --> Total execution time: 0.0420
DEBUG - 2022-05-31 05:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:23:10 --> Total execution time: 0.0245
DEBUG - 2022-05-31 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:54:15 --> Total execution time: 0.0399
DEBUG - 2022-05-31 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:54:26 --> Total execution time: 0.0856
DEBUG - 2022-05-31 05:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:25:33 --> Total execution time: 0.0546
DEBUG - 2022-05-31 05:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:55:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 05:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:25:56 --> Total execution time: 0.0278
DEBUG - 2022-05-31 05:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:07 --> Total execution time: 0.0235
DEBUG - 2022-05-31 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 05:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:15 --> Total execution time: 0.0314
DEBUG - 2022-05-31 05:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:42 --> Total execution time: 0.0360
DEBUG - 2022-05-31 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:47 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:47 --> Total execution time: 0.0670
DEBUG - 2022-05-31 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:56 --> Total execution time: 0.0287
DEBUG - 2022-05-31 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:27:03 --> Total execution time: 0.0350
DEBUG - 2022-05-31 05:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:28:06 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 05:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 05:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 05:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:28:07 --> Total execution time: 0.0630
DEBUG - 2022-05-31 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:02 --> Total execution time: 0.0585
DEBUG - 2022-05-31 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:00:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:46 --> Total execution time: 0.0300
DEBUG - 2022-05-31 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:00:52 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:52 --> Total execution time: 0.0347
DEBUG - 2022-05-31 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:00:55 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:55 --> Total execution time: 0.0225
DEBUG - 2022-05-31 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:00:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:57 --> Total execution time: 0.0252
DEBUG - 2022-05-31 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:17 --> Total execution time: 0.0280
DEBUG - 2022-05-31 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:17 --> Total execution time: 0.0250
DEBUG - 2022-05-31 06:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:19 --> Total execution time: 0.0292
DEBUG - 2022-05-31 06:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:19 --> Total execution time: 0.0524
DEBUG - 2022-05-31 06:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:25 --> Total execution time: 0.0319
DEBUG - 2022-05-31 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:37 --> Total execution time: 0.0493
DEBUG - 2022-05-31 06:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:39 --> Total execution time: 0.0286
DEBUG - 2022-05-31 06:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:01:39 --> Total execution time: 0.0321
DEBUG - 2022-05-31 06:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:41 --> Total execution time: 0.0627
DEBUG - 2022-05-31 06:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:47 --> Total execution time: 0.0513
DEBUG - 2022-05-31 06:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:01:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:54 --> Total execution time: 0.0283
DEBUG - 2022-05-31 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:02 --> Total execution time: 0.0349
DEBUG - 2022-05-31 06:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:03 --> Total execution time: 0.0246
DEBUG - 2022-05-31 06:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:03 --> Total execution time: 0.0383
DEBUG - 2022-05-31 06:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:08 --> Total execution time: 0.0335
DEBUG - 2022-05-31 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:10 --> Total execution time: 0.0275
DEBUG - 2022-05-31 06:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:10 --> Total execution time: 0.0517
DEBUG - 2022-05-31 06:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:32:13 --> Total execution time: 0.0403
DEBUG - 2022-05-31 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:32:16 --> Total execution time: 0.0692
DEBUG - 2022-05-31 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:19 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:32:20 --> Total execution time: 0.0485
DEBUG - 2022-05-31 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:32:25 --> Total execution time: 0.0926
DEBUG - 2022-05-31 06:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:34 --> Total execution time: 0.0361
DEBUG - 2022-05-31 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:39 --> Total execution time: 0.0305
DEBUG - 2022-05-31 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:41 --> Total execution time: 0.0267
DEBUG - 2022-05-31 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:41 --> Total execution time: 0.0516
DEBUG - 2022-05-31 06:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:41 --> Total execution time: 0.0527
DEBUG - 2022-05-31 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:02:42 --> Total execution time: 0.0259
DEBUG - 2022-05-31 06:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:03:51 --> Total execution time: 0.0578
DEBUG - 2022-05-31 06:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:03:52 --> Total execution time: 0.0303
DEBUG - 2022-05-31 06:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:03:52 --> Total execution time: 0.0516
DEBUG - 2022-05-31 06:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:04:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:34:04 --> Total execution time: 0.0392
DEBUG - 2022-05-31 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:34:06 --> Total execution time: 0.0467
DEBUG - 2022-05-31 06:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:04:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 06:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:04:14 --> Total execution time: 0.0260
DEBUG - 2022-05-31 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:04:15 --> Total execution time: 0.0361
DEBUG - 2022-05-31 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:04:15 --> Total execution time: 0.0352
DEBUG - 2022-05-31 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:35:09 --> Total execution time: 0.0329
DEBUG - 2022-05-31 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:35:10 --> Total execution time: 0.0318
DEBUG - 2022-05-31 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:12 --> Total execution time: 0.0468
DEBUG - 2022-05-31 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:21 --> Total execution time: 0.0309
DEBUG - 2022-05-31 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:37 --> Total execution time: 0.0257
DEBUG - 2022-05-31 06:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:35:50 --> Total execution time: 0.0253
DEBUG - 2022-05-31 06:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:52 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:35:52 --> Total execution time: 0.0419
DEBUG - 2022-05-31 06:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:05:55 --> Total execution time: 0.0289
DEBUG - 2022-05-31 06:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:06:04 --> Total execution time: 0.0278
DEBUG - 2022-05-31 06:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:06:11 --> Total execution time: 0.0238
DEBUG - 2022-05-31 06:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:06:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:36:32 --> Total execution time: 0.0604
DEBUG - 2022-05-31 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:37:03 --> Total execution time: 0.1124
DEBUG - 2022-05-31 06:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:07:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:37:16 --> Total execution time: 0.0250
DEBUG - 2022-05-31 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:37:52 --> Total execution time: 0.0325
DEBUG - 2022-05-31 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:38:20 --> Total execution time: 0.0727
DEBUG - 2022-05-31 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:38:33 --> Total execution time: 0.0409
DEBUG - 2022-05-31 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:38:46 --> Total execution time: 0.0535
DEBUG - 2022-05-31 06:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:39:32 --> Total execution time: 0.0861
DEBUG - 2022-05-31 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:39:37 --> Total execution time: 0.0341
DEBUG - 2022-05-31 06:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:39:46 --> Total execution time: 0.0858
DEBUG - 2022-05-31 06:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:40:16 --> Total execution time: 0.0739
DEBUG - 2022-05-31 06:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:40:36 --> Total execution time: 0.0366
DEBUG - 2022-05-31 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:41:54 --> Total execution time: 0.0311
DEBUG - 2022-05-31 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:41:58 --> Total execution time: 0.0698
DEBUG - 2022-05-31 06:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:42:05 --> Total execution time: 0.0331
DEBUG - 2022-05-31 06:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:42:09 --> Total execution time: 0.0340
DEBUG - 2022-05-31 06:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:42:15 --> Total execution time: 0.0289
DEBUG - 2022-05-31 06:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:42:18 --> Total execution time: 0.0746
DEBUG - 2022-05-31 06:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:43:09 --> Total execution time: 0.0593
DEBUG - 2022-05-31 06:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:13:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:43:38 --> Total execution time: 0.0979
DEBUG - 2022-05-31 06:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:10 --> Total execution time: 0.0373
DEBUG - 2022-05-31 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:52 --> Total execution time: 0.0346
DEBUG - 2022-05-31 06:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:15:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:56 --> Total execution time: 0.0273
DEBUG - 2022-05-31 06:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:59 --> Total execution time: 0.0705
DEBUG - 2022-05-31 06:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:02 --> Total execution time: 0.0531
DEBUG - 2022-05-31 06:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:10 --> Total execution time: 0.0374
DEBUG - 2022-05-31 06:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:18 --> Total execution time: 0.0641
DEBUG - 2022-05-31 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:22 --> Total execution time: 0.0295
DEBUG - 2022-05-31 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:24 --> Total execution time: 0.0331
DEBUG - 2022-05-31 06:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:24 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:24 --> Total execution time: 0.0225
DEBUG - 2022-05-31 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:46:27 --> Total execution time: 0.0314
DEBUG - 2022-05-31 06:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:22:44 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-31 06:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:54:41 --> Total execution time: 0.1561
DEBUG - 2022-05-31 06:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:54:51 --> Total execution time: 0.0825
DEBUG - 2022-05-31 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:56:10 --> Total execution time: 0.0310
DEBUG - 2022-05-31 06:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:57:12 --> Total execution time: 0.0302
DEBUG - 2022-05-31 06:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:57:13 --> Total execution time: 0.0601
DEBUG - 2022-05-31 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:27:40 --> Total execution time: 0.0234
DEBUG - 2022-05-31 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:41 --> Total execution time: 0.0188
DEBUG - 2022-05-31 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:27:41 --> Total execution time: 0.0393
DEBUG - 2022-05-31 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:27:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:57:42 --> Total execution time: 0.0235
DEBUG - 2022-05-31 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:28:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 06:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:28:13 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:28:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:58:25 --> Total execution time: 0.0219
DEBUG - 2022-05-31 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:29:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:29:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:29:48 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:02 --> Total execution time: 0.0292
DEBUG - 2022-05-31 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:09 --> Total execution time: 0.0674
DEBUG - 2022-05-31 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:11 --> Total execution time: 0.0467
DEBUG - 2022-05-31 06:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:32 --> Total execution time: 0.0274
DEBUG - 2022-05-31 06:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:34 --> Total execution time: 0.0564
DEBUG - 2022-05-31 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:03:53 --> Total execution time: 0.0598
DEBUG - 2022-05-31 06:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:07 --> Total execution time: 0.0257
DEBUG - 2022-05-31 06:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:08 --> Total execution time: 0.0579
DEBUG - 2022-05-31 06:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:24 --> Total execution time: 0.0488
DEBUG - 2022-05-31 06:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:26 --> Total execution time: 0.0282
DEBUG - 2022-05-31 06:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:30 --> Total execution time: 0.0491
DEBUG - 2022-05-31 06:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:32 --> Total execution time: 0.0563
DEBUG - 2022-05-31 06:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:41 --> Total execution time: 0.0523
DEBUG - 2022-05-31 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:43 --> Total execution time: 0.0277
DEBUG - 2022-05-31 06:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:34:59 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:59 --> Total execution time: 0.0348
DEBUG - 2022-05-31 06:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:00 --> Total execution time: 0.0283
DEBUG - 2022-05-31 06:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:22 --> Total execution time: 0.0193
DEBUG - 2022-05-31 06:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:25 --> Total execution time: 0.0916
DEBUG - 2022-05-31 06:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:25 --> Total execution time: 0.0561
DEBUG - 2022-05-31 06:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:27 --> Total execution time: 0.0352
DEBUG - 2022-05-31 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:33 --> Total execution time: 0.0603
DEBUG - 2022-05-31 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:33 --> Total execution time: 0.0518
DEBUG - 2022-05-31 06:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:38 --> Total execution time: 0.0451
DEBUG - 2022-05-31 06:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:42 --> Total execution time: 0.0312
DEBUG - 2022-05-31 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:35:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:05:53 --> Total execution time: 0.0638
DEBUG - 2022-05-31 06:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:04 --> Total execution time: 0.0518
DEBUG - 2022-05-31 06:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:18 --> Total execution time: 0.0687
DEBUG - 2022-05-31 06:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:25 --> Total execution time: 0.0333
DEBUG - 2022-05-31 06:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:27 --> Total execution time: 0.0539
DEBUG - 2022-05-31 06:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:32 --> Total execution time: 0.0325
DEBUG - 2022-05-31 06:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:33 --> Total execution time: 0.0298
DEBUG - 2022-05-31 06:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:38 --> Total execution time: 0.0260
DEBUG - 2022-05-31 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:48 --> Total execution time: 0.0332
DEBUG - 2022-05-31 06:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:06:55 --> Total execution time: 0.0630
DEBUG - 2022-05-31 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:15:47 --> Total execution time: 1.8279
DEBUG - 2022-05-31 06:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:48:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:18:13 --> Total execution time: 0.1014
DEBUG - 2022-05-31 06:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:48:23 --> Total execution time: 0.0282
DEBUG - 2022-05-31 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:48:25 --> Total execution time: 0.0539
DEBUG - 2022-05-31 06:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:48:25 --> Total execution time: 0.0645
DEBUG - 2022-05-31 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:19:18 --> Total execution time: 0.0507
DEBUG - 2022-05-31 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:50:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:20:07 --> Total execution time: 1.5831
DEBUG - 2022-05-31 06:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 06:50:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 06:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 06:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:16 --> Total execution time: 0.0364
DEBUG - 2022-05-31 06:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 17:21:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 17:21:18 --> Total execution time: 0.2005
DEBUG - 2022-05-31 06:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:30 --> Total execution time: 0.0591
DEBUG - 2022-05-31 06:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:34 --> Total execution time: 0.0459
DEBUG - 2022-05-31 06:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:21:41 --> Total execution time: 0.0632
DEBUG - 2022-05-31 06:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:01 --> Total execution time: 0.0537
DEBUG - 2022-05-31 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:05 --> Total execution time: 0.0526
DEBUG - 2022-05-31 06:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:31 --> Total execution time: 0.0386
DEBUG - 2022-05-31 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:43 --> Total execution time: 0.0505
DEBUG - 2022-05-31 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:22:43 --> Total execution time: 0.0249
DEBUG - 2022-05-31 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:23:39 --> Total execution time: 0.0264
DEBUG - 2022-05-31 06:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:23:40 --> Total execution time: 0.0403
DEBUG - 2022-05-31 06:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:23:53 --> Total execution time: 0.0480
DEBUG - 2022-05-31 06:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:13 --> Total execution time: 0.0373
DEBUG - 2022-05-31 06:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:22 --> Total execution time: 0.0616
DEBUG - 2022-05-31 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:52 --> Total execution time: 0.0325
DEBUG - 2022-05-31 06:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:00 --> Total execution time: 0.0572
DEBUG - 2022-05-31 06:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:08 --> Total execution time: 0.0520
DEBUG - 2022-05-31 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:44 --> Total execution time: 0.0622
DEBUG - 2022-05-31 06:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:45 --> Total execution time: 0.0332
DEBUG - 2022-05-31 06:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:59 --> Total execution time: 0.0383
DEBUG - 2022-05-31 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:02 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:02 --> Total execution time: 0.0275
DEBUG - 2022-05-31 06:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:05 --> Total execution time: 0.0190
DEBUG - 2022-05-31 06:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:11 --> Total execution time: 0.0460
DEBUG - 2022-05-31 06:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:19 --> Total execution time: 0.0480
DEBUG - 2022-05-31 06:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:28 --> Total execution time: 0.0201
DEBUG - 2022-05-31 06:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:48 --> Total execution time: 0.0455
DEBUG - 2022-05-31 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 06:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:27:36 --> Total execution time: 0.0299
DEBUG - 2022-05-31 06:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:28:00 --> Total execution time: 0.0427
DEBUG - 2022-05-31 06:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 06:59:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 06:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 06:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:29:54 --> Total execution time: 0.0240
DEBUG - 2022-05-31 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:30:03 --> Total execution time: 0.0421
DEBUG - 2022-05-31 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:00:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:30:12 --> Total execution time: 0.0334
DEBUG - 2022-05-31 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:00:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:30:12 --> Total execution time: 0.0351
DEBUG - 2022-05-31 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 07:00:52 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:03:35 --> Total execution time: 0.0927
DEBUG - 2022-05-31 07:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:03:46 --> Total execution time: 0.0810
DEBUG - 2022-05-31 07:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:34:33 --> Total execution time: 0.0760
DEBUG - 2022-05-31 07:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:34:48 --> Total execution time: 0.0706
DEBUG - 2022-05-31 07:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:35:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 07:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:35:50 --> Total execution time: 0.0688
DEBUG - 2022-05-31 07:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:36:10 --> Total execution time: 0.0357
DEBUG - 2022-05-31 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:37:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:38:13 --> Total execution time: 0.0425
DEBUG - 2022-05-31 07:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:38:28 --> Total execution time: 0.0339
DEBUG - 2022-05-31 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:11:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:41:56 --> Total execution time: 0.0993
DEBUG - 2022-05-31 07:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:11:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:41:57 --> Total execution time: 0.0500
DEBUG - 2022-05-31 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:01 --> Total execution time: 0.0299
DEBUG - 2022-05-31 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:04 --> Total execution time: 0.0307
DEBUG - 2022-05-31 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:05 --> Total execution time: 0.0422
DEBUG - 2022-05-31 07:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:05 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:05 --> Total execution time: 0.0219
DEBUG - 2022-05-31 07:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:06 --> Total execution time: 0.0220
DEBUG - 2022-05-31 07:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:23 --> Total execution time: 0.0235
DEBUG - 2022-05-31 07:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:42:55 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:43:26 --> Total execution time: 0.0296
DEBUG - 2022-05-31 07:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:43:33 --> Total execution time: 0.0248
DEBUG - 2022-05-31 07:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:13:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 07:13:43 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-05-31 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:43:59 --> Total execution time: 0.0278
DEBUG - 2022-05-31 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:44:08 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:44:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 07:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:44:09 --> Total execution time: 0.0380
DEBUG - 2022-05-31 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:46:23 --> Total execution time: 0.0639
DEBUG - 2022-05-31 07:16:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:46:23 --> Total execution time: 0.0281
DEBUG - 2022-05-31 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:46:24 --> Total execution time: 0.0429
DEBUG - 2022-05-31 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:46:32 --> Total execution time: 0.0252
DEBUG - 2022-05-31 07:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:46:48 --> Total execution time: 0.0487
DEBUG - 2022-05-31 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:46:54 --> Total execution time: 0.0245
DEBUG - 2022-05-31 07:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:01 --> Total execution time: 0.0413
DEBUG - 2022-05-31 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:06 --> Total execution time: 0.0290
DEBUG - 2022-05-31 07:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:08 --> Total execution time: 0.0657
DEBUG - 2022-05-31 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:12 --> Total execution time: 0.0200
DEBUG - 2022-05-31 07:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:24 --> Total execution time: 0.0356
DEBUG - 2022-05-31 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:30 --> Total execution time: 0.0228
DEBUG - 2022-05-31 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:30 --> Total execution time: 0.0210
DEBUG - 2022-05-31 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:42 --> Total execution time: 0.0575
DEBUG - 2022-05-31 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:46 --> Total execution time: 0.0198
DEBUG - 2022-05-31 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:47 --> Total execution time: 0.0293
DEBUG - 2022-05-31 07:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:17:47 --> Total execution time: 0.0406
DEBUG - 2022-05-31 07:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:49 --> Total execution time: 0.0221
DEBUG - 2022-05-31 07:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:47:51 --> Total execution time: 0.0363
DEBUG - 2022-05-31 07:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:00 --> Total execution time: 0.0243
DEBUG - 2022-05-31 07:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:01 --> Total execution time: 0.0467
DEBUG - 2022-05-31 07:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:05 --> Total execution time: 0.0232
DEBUG - 2022-05-31 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:11 --> Total execution time: 0.0275
DEBUG - 2022-05-31 07:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:12 --> Total execution time: 0.0186
DEBUG - 2022-05-31 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:20 --> Total execution time: 0.0438
DEBUG - 2022-05-31 07:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:20 --> Total execution time: 0.0349
DEBUG - 2022-05-31 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 07:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:21 --> Total execution time: 0.0192
DEBUG - 2022-05-31 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:48:50 --> Total execution time: 0.0476
DEBUG - 2022-05-31 07:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:49:08 --> Total execution time: 0.0421
DEBUG - 2022-05-31 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:49:28 --> Total execution time: 0.0376
DEBUG - 2022-05-31 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:49:38 --> Total execution time: 0.0253
DEBUG - 2022-05-31 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:49:40 --> Total execution time: 0.0347
DEBUG - 2022-05-31 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:49:54 --> Total execution time: 0.0341
DEBUG - 2022-05-31 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:20:04 --> Total execution time: 0.0256
DEBUG - 2022-05-31 07:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:50:23 --> Total execution time: 0.0296
DEBUG - 2022-05-31 07:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:50:31 --> Total execution time: 0.0420
DEBUG - 2022-05-31 07:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:50:51 --> Total execution time: 0.0724
DEBUG - 2022-05-31 07:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:51:11 --> Total execution time: 0.0780
DEBUG - 2022-05-31 07:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:51:44 --> Total execution time: 0.0836
DEBUG - 2022-05-31 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:51:54 --> Total execution time: 0.0675
DEBUG - 2022-05-31 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:54:12 --> Total execution time: 0.0301
DEBUG - 2022-05-31 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:25:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:55:33 --> Total execution time: 0.0418
DEBUG - 2022-05-31 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:55:41 --> Total execution time: 0.0470
DEBUG - 2022-05-31 07:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:55:51 --> Total execution time: 0.0431
DEBUG - 2022-05-31 07:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:55:58 --> Total execution time: 0.0467
DEBUG - 2022-05-31 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:28:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:58:00 --> Total execution time: 0.0864
DEBUG - 2022-05-31 07:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:28:21 --> Total execution time: 0.0340
DEBUG - 2022-05-31 07:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:28:28 --> Total execution time: 0.0660
DEBUG - 2022-05-31 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:28:42 --> Total execution time: 0.0380
DEBUG - 2022-05-31 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:00:06 --> Total execution time: 0.0676
DEBUG - 2022-05-31 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:00:18 --> Total execution time: 0.0847
DEBUG - 2022-05-31 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:00:34 --> Total execution time: 0.0589
DEBUG - 2022-05-31 07:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:00:48 --> Total execution time: 0.0475
DEBUG - 2022-05-31 07:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:04 --> Total execution time: 0.0502
DEBUG - 2022-05-31 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:14 --> Total execution time: 0.0210
DEBUG - 2022-05-31 07:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:15 --> Total execution time: 0.0568
DEBUG - 2022-05-31 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:19 --> Total execution time: 0.0368
DEBUG - 2022-05-31 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:20 --> Total execution time: 0.0295
DEBUG - 2022-05-31 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:31:23 --> Total execution time: 0.0363
DEBUG - 2022-05-31 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:24 --> Total execution time: 0.0244
DEBUG - 2022-05-31 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:28 --> Total execution time: 0.0187
DEBUG - 2022-05-31 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:31 --> Total execution time: 0.0519
DEBUG - 2022-05-31 07:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:31 --> Total execution time: 0.0347
DEBUG - 2022-05-31 07:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:36 --> Total execution time: 0.0353
DEBUG - 2022-05-31 07:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:39 --> Total execution time: 0.0453
DEBUG - 2022-05-31 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:39 --> Total execution time: 0.0442
DEBUG - 2022-05-31 07:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:01:41 --> Total execution time: 0.0448
DEBUG - 2022-05-31 07:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:02:04 --> Total execution time: 0.0324
DEBUG - 2022-05-31 07:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:02:17 --> Total execution time: 0.0480
DEBUG - 2022-05-31 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:16 --> Total execution time: 0.0248
DEBUG - 2022-05-31 07:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:21 --> Total execution time: 0.0306
DEBUG - 2022-05-31 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:24 --> Total execution time: 0.0600
DEBUG - 2022-05-31 07:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:28 --> Total execution time: 0.0938
DEBUG - 2022-05-31 07:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:36 --> Total execution time: 0.0428
DEBUG - 2022-05-31 07:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:40 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:50 --> Total execution time: 0.0288
DEBUG - 2022-05-31 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:53 --> Total execution time: 0.0279
DEBUG - 2022-05-31 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:54 --> Total execution time: 0.0661
DEBUG - 2022-05-31 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:03:59 --> Total execution time: 0.0338
DEBUG - 2022-05-31 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:05 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:05 --> Total execution time: 0.0367
DEBUG - 2022-05-31 07:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:06 --> Total execution time: 0.0483
DEBUG - 2022-05-31 07:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:24 --> Total execution time: 0.0303
DEBUG - 2022-05-31 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:37 --> Total execution time: 0.0491
DEBUG - 2022-05-31 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:44 --> Total execution time: 0.0548
DEBUG - 2022-05-31 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:04:45 --> Total execution time: 0.0507
DEBUG - 2022-05-31 07:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:05:10 --> Total execution time: 0.0907
DEBUG - 2022-05-31 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:35:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:05:20 --> Total execution time: 0.0445
DEBUG - 2022-05-31 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:05:30 --> Total execution time: 0.0485
DEBUG - 2022-05-31 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:05:34 --> Total execution time: 0.0775
DEBUG - 2022-05-31 07:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:36:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:06:22 --> Total execution time: 0.0246
DEBUG - 2022-05-31 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:43:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:43:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:13:57 --> Total execution time: 0.0778
DEBUG - 2022-05-31 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:44:24 --> Total execution time: 0.0292
DEBUG - 2022-05-31 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:44:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:14:25 --> Total execution time: 0.0377
DEBUG - 2022-05-31 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:44:25 --> Total execution time: 0.0369
DEBUG - 2022-05-31 07:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:44:25 --> Total execution time: 0.0467
DEBUG - 2022-05-31 07:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:05 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:05 --> Total execution time: 0.0268
DEBUG - 2022-05-31 07:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:11 --> Total execution time: 0.0247
DEBUG - 2022-05-31 07:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 07:46:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 07:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:27 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:27 --> Total execution time: 0.0216
DEBUG - 2022-05-31 07:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:34 --> Total execution time: 0.0402
DEBUG - 2022-05-31 07:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:53 --> Total execution time: 0.0463
DEBUG - 2022-05-31 07:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:16:59 --> Total execution time: 0.0285
DEBUG - 2022-05-31 07:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:17:02 --> Total execution time: 0.0328
DEBUG - 2022-05-31 07:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:17:07 --> Total execution time: 0.0650
DEBUG - 2022-05-31 07:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:17:12 --> Total execution time: 0.0407
DEBUG - 2022-05-31 07:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:48:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:18:01 --> Total execution time: 0.0446
DEBUG - 2022-05-31 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:49:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:19:58 --> Total execution time: 0.0225
DEBUG - 2022-05-31 07:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:20:02 --> Total execution time: 0.0947
DEBUG - 2022-05-31 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:20:52 --> Total execution time: 0.0358
DEBUG - 2022-05-31 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:23:15 --> Total execution time: 0.1115
DEBUG - 2022-05-31 07:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:53:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:23:16 --> Total execution time: 0.0231
DEBUG - 2022-05-31 07:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:53:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:23:23 --> Total execution time: 0.0214
DEBUG - 2022-05-31 07:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:00 --> Total execution time: 0.0269
DEBUG - 2022-05-31 07:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:09 --> Total execution time: 0.0346
DEBUG - 2022-05-31 07:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:19 --> Total execution time: 0.0272
DEBUG - 2022-05-31 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:29 --> Total execution time: 0.0285
DEBUG - 2022-05-31 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:31 --> Total execution time: 0.0287
DEBUG - 2022-05-31 07:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 07:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:38 --> Total execution time: 0.0325
DEBUG - 2022-05-31 07:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:56 --> Total execution time: 0.0264
DEBUG - 2022-05-31 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:24:58 --> Total execution time: 0.0299
DEBUG - 2022-05-31 07:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:58 --> Total execution time: 0.0274
DEBUG - 2022-05-31 07:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:54:58 --> Total execution time: 0.0463
DEBUG - 2022-05-31 07:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:01 --> Total execution time: 0.0437
DEBUG - 2022-05-31 07:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:05 --> Total execution time: 0.0262
DEBUG - 2022-05-31 07:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:17 --> Total execution time: 0.0259
DEBUG - 2022-05-31 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:31 --> Total execution time: 0.0291
DEBUG - 2022-05-31 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:31 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 07:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:25:32 --> Total execution time: 0.0257
DEBUG - 2022-05-31 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:26:43 --> Total execution time: 0.0261
DEBUG - 2022-05-31 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:26:44 --> Total execution time: 0.0290
DEBUG - 2022-05-31 07:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:57:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 07:57:01 --> 404 Page Not Found: Event/inspiration-memento-live-commission-art-2
DEBUG - 2022-05-31 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:27:13 --> Total execution time: 0.0719
DEBUG - 2022-05-31 07:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:27:37 --> Total execution time: 0.0373
DEBUG - 2022-05-31 07:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 07:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 07:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:27:56 --> Total execution time: 0.0588
DEBUG - 2022-05-31 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:03 --> Total execution time: 0.1505
DEBUG - 2022-05-31 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:22 --> Total execution time: 0.0673
DEBUG - 2022-05-31 08:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:22 --> Total execution time: 0.0410
DEBUG - 2022-05-31 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:31 --> Total execution time: 0.0325
DEBUG - 2022-05-31 08:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:34 --> Total execution time: 0.0666
DEBUG - 2022-05-31 08:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:43 --> Total execution time: 0.0477
DEBUG - 2022-05-31 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:30:48 --> Total execution time: 0.0569
DEBUG - 2022-05-31 08:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:31:23 --> Total execution time: 0.0388
DEBUG - 2022-05-31 08:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:31:25 --> Total execution time: 0.0383
DEBUG - 2022-05-31 08:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:01:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:31:56 --> Total execution time: 0.0238
DEBUG - 2022-05-31 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:02:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:32:06 --> Total execution time: 0.0371
DEBUG - 2022-05-31 18:32:06 --> Total execution time: 0.1031
DEBUG - 2022-05-31 08:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:03:53 --> Total execution time: 0.0501
DEBUG - 2022-05-31 08:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:04:00 --> Total execution time: 0.1110
DEBUG - 2022-05-31 08:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:34:07 --> Total execution time: 0.0800
DEBUG - 2022-05-31 08:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:34:38 --> Total execution time: 0.0446
DEBUG - 2022-05-31 08:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:34:41 --> Total execution time: 0.0406
DEBUG - 2022-05-31 08:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:34:44 --> Total execution time: 0.0418
DEBUG - 2022-05-31 08:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:34:52 --> Total execution time: 0.0352
DEBUG - 2022-05-31 08:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:35:16 --> Total execution time: 0.0688
DEBUG - 2022-05-31 08:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:35:42 --> Total execution time: 0.0382
DEBUG - 2022-05-31 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:36:41 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 08:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:36:43 --> Total execution time: 0.0284
DEBUG - 2022-05-31 08:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:36:43 --> Total execution time: 0.0694
DEBUG - 2022-05-31 08:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:36:49 --> Total execution time: 0.0672
DEBUG - 2022-05-31 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:37:02 --> Total execution time: 0.0298
DEBUG - 2022-05-31 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:37:18 --> Total execution time: 0.0333
DEBUG - 2022-05-31 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:37:39 --> Total execution time: 0.0288
DEBUG - 2022-05-31 08:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:37:50 --> Total execution time: 0.0456
DEBUG - 2022-05-31 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:38:01 --> Total execution time: 0.0551
DEBUG - 2022-05-31 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:38:10 --> Total execution time: 0.0428
DEBUG - 2022-05-31 08:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:38:16 --> Total execution time: 0.0414
DEBUG - 2022-05-31 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:38:45 --> Total execution time: 0.0423
DEBUG - 2022-05-31 08:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:43:55 --> Total execution time: 0.0981
DEBUG - 2022-05-31 08:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:46:47 --> Total execution time: 0.0341
DEBUG - 2022-05-31 08:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:17:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:47:12 --> Total execution time: 0.0376
DEBUG - 2022-05-31 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:49:19 --> Total execution time: 0.0875
DEBUG - 2022-05-31 08:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:50:35 --> Total execution time: 0.0241
DEBUG - 2022-05-31 08:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:50:38 --> Total execution time: 0.0256
DEBUG - 2022-05-31 08:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:50:43 --> Total execution time: 0.0611
DEBUG - 2022-05-31 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:50:47 --> Total execution time: 0.0344
DEBUG - 2022-05-31 08:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:50:55 --> Total execution time: 0.0352
DEBUG - 2022-05-31 08:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:51:05 --> Total execution time: 0.0263
DEBUG - 2022-05-31 08:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:25:02 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:55:02 --> Total execution time: 0.0743
DEBUG - 2022-05-31 08:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:25:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:55:31 --> Total execution time: 0.0463
DEBUG - 2022-05-31 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:56:33 --> Total execution time: 0.0259
DEBUG - 2022-05-31 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:08 --> Total execution time: 0.0256
DEBUG - 2022-05-31 08:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:23 --> Total execution time: 0.0229
DEBUG - 2022-05-31 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:29 --> Total execution time: 0.0245
DEBUG - 2022-05-31 08:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:46 --> Total execution time: 0.0236
DEBUG - 2022-05-31 08:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:52 --> Total execution time: 0.0192
DEBUG - 2022-05-31 08:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:27:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:57:56 --> Total execution time: 0.0256
DEBUG - 2022-05-31 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:00 --> Total execution time: 0.0182
DEBUG - 2022-05-31 08:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:03 --> Total execution time: 0.0204
DEBUG - 2022-05-31 08:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:08 --> Total execution time: 0.0305
DEBUG - 2022-05-31 08:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:23 --> Total execution time: 0.0731
DEBUG - 2022-05-31 08:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:45 --> Total execution time: 0.0330
DEBUG - 2022-05-31 08:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:47 --> Total execution time: 0.0301
DEBUG - 2022-05-31 08:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:52 --> Total execution time: 0.0299
DEBUG - 2022-05-31 08:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:58:56 --> Total execution time: 0.0524
DEBUG - 2022-05-31 08:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:59:16 --> Total execution time: 0.0295
DEBUG - 2022-05-31 08:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:59:34 --> Total execution time: 0.0287
DEBUG - 2022-05-31 08:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:59:47 --> Total execution time: 0.0347
DEBUG - 2022-05-31 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:00:09 --> Total execution time: 0.0327
DEBUG - 2022-05-31 08:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:30:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:00:35 --> Total execution time: 0.0206
DEBUG - 2022-05-31 08:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:00:52 --> Total execution time: 0.0646
DEBUG - 2022-05-31 08:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:01:34 --> Total execution time: 0.0789
DEBUG - 2022-05-31 08:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:31:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:01:44 --> Total execution time: 0.0208
DEBUG - 2022-05-31 08:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:02:28 --> Total execution time: 0.0350
DEBUG - 2022-05-31 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:32:59 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:02:59 --> Total execution time: 0.0211
DEBUG - 2022-05-31 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:33:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:03:34 --> Total execution time: 0.0237
DEBUG - 2022-05-31 08:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:33:38 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:03:38 --> Total execution time: 0.0210
DEBUG - 2022-05-31 08:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:34:09 --> Total execution time: 0.0271
DEBUG - 2022-05-31 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:34:11 --> Total execution time: 0.0265
DEBUG - 2022-05-31 08:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:34:11 --> Total execution time: 0.0663
DEBUG - 2022-05-31 08:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:35:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 08:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:05:11 --> Total execution time: 1.5306
DEBUG - 2022-05-31 08:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:35:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 08:35:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:35:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:05:35 --> Total execution time: 0.0521
DEBUG - 2022-05-31 08:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:36:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:06:16 --> Total execution time: 0.0207
DEBUG - 2022-05-31 08:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:36:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:06:47 --> Total execution time: 0.0323
DEBUG - 2022-05-31 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:38:21 --> Total execution time: 0.0195
DEBUG - 2022-05-31 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:38:22 --> Total execution time: 0.0298
DEBUG - 2022-05-31 08:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:38:22 --> Total execution time: 0.0458
DEBUG - 2022-05-31 08:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:40:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:10:15 --> Total execution time: 0.0274
DEBUG - 2022-05-31 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:41:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:11:21 --> Total execution time: 0.0560
DEBUG - 2022-05-31 08:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:41:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:11:36 --> Total execution time: 0.0215
DEBUG - 2022-05-31 08:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:11:37 --> Total execution time: 0.0238
DEBUG - 2022-05-31 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:41:52 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:11:52 --> Total execution time: 0.0270
DEBUG - 2022-05-31 08:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:12:08 --> Total execution time: 0.0373
DEBUG - 2022-05-31 08:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:12:32 --> Total execution time: 0.0331
DEBUG - 2022-05-31 08:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:42:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:12:53 --> Total execution time: 0.0229
DEBUG - 2022-05-31 08:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:43:23 --> Total execution time: 0.0481
DEBUG - 2022-05-31 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:43:25 --> Total execution time: 0.0342
DEBUG - 2022-05-31 08:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:43:25 --> Total execution time: 0.0600
DEBUG - 2022-05-31 08:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:13:42 --> Total execution time: 0.0874
DEBUG - 2022-05-31 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:13:55 --> Total execution time: 0.0654
DEBUG - 2022-05-31 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:13:55 --> Total execution time: 0.0377
DEBUG - 2022-05-31 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:13:59 --> Total execution time: 0.0263
DEBUG - 2022-05-31 08:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:14:00 --> Total execution time: 0.0348
DEBUG - 2022-05-31 08:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:14:48 --> Total execution time: 0.0321
DEBUG - 2022-05-31 08:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:14:49 --> Total execution time: 0.0280
DEBUG - 2022-05-31 08:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:14:53 --> Total execution time: 0.0353
DEBUG - 2022-05-31 08:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:15:12 --> Total execution time: 0.0371
DEBUG - 2022-05-31 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:15:22 --> Total execution time: 0.0671
DEBUG - 2022-05-31 08:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:16:51 --> Total execution time: 0.1077
DEBUG - 2022-05-31 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:17:11 --> Total execution time: 0.0444
DEBUG - 2022-05-31 08:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:03 --> Total execution time: 0.0616
DEBUG - 2022-05-31 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:20 --> Total execution time: 0.0441
DEBUG - 2022-05-31 08:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:20 --> Total execution time: 0.0374
DEBUG - 2022-05-31 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:43 --> Total execution time: 0.0288
DEBUG - 2022-05-31 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:57 --> Total execution time: 0.0292
DEBUG - 2022-05-31 08:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:57 --> Total execution time: 0.0287
DEBUG - 2022-05-31 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:58 --> Total execution time: 0.0283
DEBUG - 2022-05-31 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:58 --> Total execution time: 0.0358
DEBUG - 2022-05-31 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:18:58 --> Total execution time: 0.0276
DEBUG - 2022-05-31 08:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:19:40 --> Total execution time: 0.0303
DEBUG - 2022-05-31 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:19:45 --> Total execution time: 0.0285
DEBUG - 2022-05-31 08:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:23:41 --> Total execution time: 0.1354
DEBUG - 2022-05-31 08:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 08:56:45 --> No URI present. Default controller set.
DEBUG - 2022-05-31 08:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 08:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:26:45 --> Total execution time: 0.1335
DEBUG - 2022-05-31 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:30:02 --> Total execution time: 0.1234
DEBUG - 2022-05-31 09:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:12 --> Total execution time: 0.0292
DEBUG - 2022-05-31 09:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:14 --> Total execution time: 0.0214
DEBUG - 2022-05-31 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:21 --> Total execution time: 0.0388
DEBUG - 2022-05-31 09:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:24 --> Total execution time: 0.0441
DEBUG - 2022-05-31 09:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:26 --> Total execution time: 0.0465
DEBUG - 2022-05-31 09:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:31 --> Total execution time: 0.0449
DEBUG - 2022-05-31 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:01:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:31:49 --> Total execution time: 0.0284
DEBUG - 2022-05-31 09:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:32:30 --> Total execution time: 0.1069
DEBUG - 2022-05-31 09:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:02:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:32:42 --> Total execution time: 0.0517
DEBUG - 2022-05-31 09:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:33:12 --> Total execution time: 0.0501
DEBUG - 2022-05-31 09:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:03:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:33:18 --> Total execution time: 0.0272
DEBUG - 2022-05-31 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:37:24 --> Total execution time: 0.0249
DEBUG - 2022-05-31 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:37:25 --> Total execution time: 0.0247
DEBUG - 2022-05-31 09:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:38:29 --> Total execution time: 0.0270
DEBUG - 2022-05-31 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:08:37 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:38:37 --> Total execution time: 0.0307
DEBUG - 2022-05-31 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:38:39 --> Total execution time: 0.0185
DEBUG - 2022-05-31 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:39 --> Total execution time: 0.0286
DEBUG - 2022-05-31 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:44 --> Total execution time: 0.0308
DEBUG - 2022-05-31 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:56 --> Total execution time: 0.0366
DEBUG - 2022-05-31 09:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:00 --> Total execution time: 0.0359
DEBUG - 2022-05-31 09:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:14:02 --> Total execution time: 0.0691
DEBUG - 2022-05-31 09:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:03 --> Total execution time: 0.0343
DEBUG - 2022-05-31 09:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:14:05 --> Total execution time: 0.0305
DEBUG - 2022-05-31 09:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:14:05 --> Total execution time: 0.0295
DEBUG - 2022-05-31 09:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:45:09 --> Total execution time: 0.0291
DEBUG - 2022-05-31 09:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:45:14 --> Total execution time: 0.0361
DEBUG - 2022-05-31 09:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:45:34 --> Total execution time: 0.0281
DEBUG - 2022-05-31 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:15:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 09:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:45:49 --> Total execution time: 1.5760
DEBUG - 2022-05-31 09:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:15:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:15:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 09:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:46:28 --> Total execution time: 0.0262
DEBUG - 2022-05-31 09:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:46:33 --> Total execution time: 0.0259
DEBUG - 2022-05-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:46:45 --> Total execution time: 0.0309
DEBUG - 2022-05-31 09:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:46:55 --> Total execution time: 0.0299
DEBUG - 2022-05-31 09:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:46:55 --> Total execution time: 0.0294
DEBUG - 2022-05-31 09:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:17:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:47:02 --> Total execution time: 0.0522
DEBUG - 2022-05-31 09:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:18:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:48:33 --> Total execution time: 0.0417
DEBUG - 2022-05-31 09:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:18:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:48:36 --> Total execution time: 0.0296
DEBUG - 2022-05-31 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:49:23 --> Total execution time: 0.0379
DEBUG - 2022-05-31 09:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:49:29 --> Total execution time: 0.0411
DEBUG - 2022-05-31 09:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:49:33 --> Total execution time: 0.0246
DEBUG - 2022-05-31 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:49:43 --> Total execution time: 0.0378
DEBUG - 2022-05-31 09:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:50:16 --> Total execution time: 0.0275
DEBUG - 2022-05-31 09:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:50:16 --> Total execution time: 0.0271
DEBUG - 2022-05-31 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:50:20 --> Total execution time: 0.0499
DEBUG - 2022-05-31 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:37 --> Total execution time: 0.0256
DEBUG - 2022-05-31 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:47 --> Total execution time: 0.0304
DEBUG - 2022-05-31 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:50 --> Total execution time: 0.0245
DEBUG - 2022-05-31 09:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:52 --> Total execution time: 0.0228
DEBUG - 2022-05-31 09:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:20:57 --> Total execution time: 0.0231
DEBUG - 2022-05-31 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:21:02 --> Total execution time: 0.0341
DEBUG - 2022-05-31 09:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:51:09 --> Total execution time: 0.0272
DEBUG - 2022-05-31 09:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:51:15 --> Total execution time: 0.0239
DEBUG - 2022-05-31 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:51:25 --> Total execution time: 0.0268
DEBUG - 2022-05-31 09:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:51:43 --> Total execution time: 0.0367
DEBUG - 2022-05-31 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:52:06 --> Total execution time: 0.0399
DEBUG - 2022-05-31 09:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:22:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:52:11 --> Total execution time: 0.0160
DEBUG - 2022-05-31 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:53:57 --> Total execution time: 0.0293
DEBUG - 2022-05-31 09:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:02 --> Total execution time: 0.0337
DEBUG - 2022-05-31 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:11 --> Total execution time: 0.0319
DEBUG - 2022-05-31 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:19 --> Total execution time: 0.0303
DEBUG - 2022-05-31 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:22 --> Total execution time: 0.0302
DEBUG - 2022-05-31 09:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:26 --> Total execution time: 0.0290
DEBUG - 2022-05-31 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:54:35 --> Total execution time: 0.0603
DEBUG - 2022-05-31 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:00 --> Total execution time: 0.1495
DEBUG - 2022-05-31 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:00 --> Total execution time: 0.0727
DEBUG - 2022-05-31 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:25:01 --> Total execution time: 0.0423
DEBUG - 2022-05-31 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:01 --> Total execution time: 0.0753
DEBUG - 2022-05-31 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:09 --> Total execution time: 0.0271
DEBUG - 2022-05-31 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:25:10 --> Total execution time: 0.0266
DEBUG - 2022-05-31 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:25:12 --> Total execution time: 0.0261
DEBUG - 2022-05-31 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:25:12 --> Total execution time: 0.0398
DEBUG - 2022-05-31 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:15 --> Total execution time: 0.0260
DEBUG - 2022-05-31 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:27:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:57:17 --> Total execution time: 1.4969
DEBUG - 2022-05-31 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:27:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 09:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:57:57 --> Total execution time: 0.0321
DEBUG - 2022-05-31 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:58:13 --> Total execution time: 4.4795
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:37 --> UTF-8 Support Enabled
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:37 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:38 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:38 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:28:38 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 09:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:00 --> Total execution time: 0.0302
DEBUG - 2022-05-31 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:03 --> Total execution time: 0.0404
DEBUG - 2022-05-31 09:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:12 --> Total execution time: 0.0338
DEBUG - 2022-05-31 09:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 09:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:15 --> Total execution time: 0.0499
DEBUG - 2022-05-31 09:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:59:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 19:59:16 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 19:59:16 --> Total execution time: 0.2798
DEBUG - 2022-05-31 09:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:32:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:32:24 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-31 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:35:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:35:35 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-31 09:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:37:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:07:21 --> Total execution time: 0.0875
DEBUG - 2022-05-31 09:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:39:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:09:06 --> Total execution time: 0.0257
DEBUG - 2022-05-31 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:09:12 --> Total execution time: 0.0370
DEBUG - 2022-05-31 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:48:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:22 --> Total execution time: 0.1585
DEBUG - 2022-05-31 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:29 --> Total execution time: 0.0326
DEBUG - 2022-05-31 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:29 --> Total execution time: 0.0273
DEBUG - 2022-05-31 09:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:42 --> Total execution time: 0.0663
DEBUG - 2022-05-31 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:04 --> Total execution time: 0.0375
DEBUG - 2022-05-31 09:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:16 --> Total execution time: 0.0316
DEBUG - 2022-05-31 09:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:17 --> Total execution time: 0.0320
DEBUG - 2022-05-31 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:26 --> Total execution time: 0.0319
DEBUG - 2022-05-31 09:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:43 --> Total execution time: 0.0231
DEBUG - 2022-05-31 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:52 --> Total execution time: 0.0736
DEBUG - 2022-05-31 09:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:52 --> Total execution time: 0.0153
DEBUG - 2022-05-31 09:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:19:53 --> Total execution time: 0.0261
DEBUG - 2022-05-31 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:20:15 --> Total execution time: 0.0936
DEBUG - 2022-05-31 09:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:20:22 --> Total execution time: 0.0254
DEBUG - 2022-05-31 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:20:35 --> Total execution time: 0.0505
DEBUG - 2022-05-31 09:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:01 --> Total execution time: 0.0278
DEBUG - 2022-05-31 09:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:03 --> Total execution time: 0.0325
DEBUG - 2022-05-31 09:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:08 --> Total execution time: 0.0393
DEBUG - 2022-05-31 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:12 --> Total execution time: 0.0301
DEBUG - 2022-05-31 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:14 --> Total execution time: 0.0239
DEBUG - 2022-05-31 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:28 --> Total execution time: 0.0370
DEBUG - 2022-05-31 09:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:34 --> Total execution time: 0.0234
DEBUG - 2022-05-31 09:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:35 --> Total execution time: 0.0236
DEBUG - 2022-05-31 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:37 --> Total execution time: 0.0243
DEBUG - 2022-05-31 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:51:38 --> Total execution time: 0.0233
DEBUG - 2022-05-31 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:38 --> Total execution time: 0.0298
DEBUG - 2022-05-31 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:38 --> Total execution time: 0.0421
DEBUG - 2022-05-31 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:01 --> Total execution time: 0.0504
DEBUG - 2022-05-31 09:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:52:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:33 --> Total execution time: 0.0254
DEBUG - 2022-05-31 09:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:52:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:58 --> Total execution time: 0.0430
DEBUG - 2022-05-31 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:25:02 --> Total execution time: 0.0764
DEBUG - 2022-05-31 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:56:04 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-05-31 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 09:56:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 09:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:26:09 --> Total execution time: 0.0555
DEBUG - 2022-05-31 09:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:56:15 --> Total execution time: 0.0257
DEBUG - 2022-05-31 09:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:56:17 --> Total execution time: 0.0452
DEBUG - 2022-05-31 09:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:56:17 --> Total execution time: 0.0433
DEBUG - 2022-05-31 09:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:27:23 --> Total execution time: 0.0286
DEBUG - 2022-05-31 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:57:31 --> Total execution time: 0.0258
DEBUG - 2022-05-31 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:32 --> Total execution time: 0.0453
DEBUG - 2022-05-31 09:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:57:32 --> Total execution time: 0.0324
DEBUG - 2022-05-31 09:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:27:34 --> Total execution time: 0.0258
DEBUG - 2022-05-31 09:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:29:50 --> Total execution time: 0.0210
DEBUG - 2022-05-31 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 09:59:59 --> No URI present. Default controller set.
DEBUG - 2022-05-31 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 09:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:29:59 --> Total execution time: 0.0248
DEBUG - 2022-05-31 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:30:02 --> Total execution time: 0.0601
DEBUG - 2022-05-31 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:30:18 --> Total execution time: 0.0588
DEBUG - 2022-05-31 10:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:30:31 --> Total execution time: 0.0304
DEBUG - 2022-05-31 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:30:40 --> Total execution time: 0.0529
DEBUG - 2022-05-31 10:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:23 --> Total execution time: 0.0573
DEBUG - 2022-05-31 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:25 --> Total execution time: 0.0354
DEBUG - 2022-05-31 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:25 --> Total execution time: 0.0330
DEBUG - 2022-05-31 10:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:31:32 --> Total execution time: 0.0255
DEBUG - 2022-05-31 10:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:31:39 --> Total execution time: 0.0212
DEBUG - 2022-05-31 10:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:52 --> Total execution time: 0.0547
DEBUG - 2022-05-31 10:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:54 --> Total execution time: 0.0319
DEBUG - 2022-05-31 10:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:01:54 --> Total execution time: 0.0242
DEBUG - 2022-05-31 10:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:08 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:08 --> Total execution time: 0.0274
DEBUG - 2022-05-31 10:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:11 --> Total execution time: 0.0264
DEBUG - 2022-05-31 10:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:23 --> Total execution time: 0.0243
DEBUG - 2022-05-31 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:37 --> Total execution time: 0.0247
DEBUG - 2022-05-31 10:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:46 --> Total execution time: 0.0820
DEBUG - 2022-05-31 10:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:33:04 --> Total execution time: 0.0312
DEBUG - 2022-05-31 10:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:33:08 --> Total execution time: 0.0742
DEBUG - 2022-05-31 10:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:33:18 --> Total execution time: 0.0297
DEBUG - 2022-05-31 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:03:19 --> Total execution time: 0.0255
DEBUG - 2022-05-31 10:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:03:21 --> Total execution time: 0.0290
DEBUG - 2022-05-31 10:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:03:21 --> Total execution time: 0.0440
DEBUG - 2022-05-31 10:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:04:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:34:01 --> Total execution time: 0.0483
DEBUG - 2022-05-31 10:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:04:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:34:22 --> Total execution time: 0.0276
DEBUG - 2022-05-31 10:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:34:32 --> Total execution time: 0.0343
DEBUG - 2022-05-31 10:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:34:45 --> Total execution time: 0.0424
DEBUG - 2022-05-31 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:35:03 --> Total execution time: 0.0944
DEBUG - 2022-05-31 10:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:35:03 --> Total execution time: 0.0926
DEBUG - 2022-05-31 10:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:35:25 --> Total execution time: 0.0806
DEBUG - 2022-05-31 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:35:56 --> Total execution time: 0.0287
DEBUG - 2022-05-31 10:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:36:28 --> Total execution time: 0.0294
DEBUG - 2022-05-31 10:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:36:38 --> Total execution time: 0.0296
DEBUG - 2022-05-31 10:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:36:48 --> Total execution time: 0.0510
DEBUG - 2022-05-31 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:37:11 --> Total execution time: 0.0284
DEBUG - 2022-05-31 10:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:37:33 --> Total execution time: 0.0343
DEBUG - 2022-05-31 10:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:05 --> Total execution time: 0.0650
DEBUG - 2022-05-31 10:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:10:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:40:20 --> Total execution time: 0.0253
DEBUG - 2022-05-31 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:45:34 --> Total execution time: 0.1158
DEBUG - 2022-05-31 10:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:47:41 --> Total execution time: 0.0753
DEBUG - 2022-05-31 10:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:50:33 --> Total execution time: 0.0501
DEBUG - 2022-05-31 10:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:50:39 --> Total execution time: 0.0482
DEBUG - 2022-05-31 10:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:50:41 --> Total execution time: 0.0257
DEBUG - 2022-05-31 10:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:21:07 --> Total execution time: 0.0583
DEBUG - 2022-05-31 10:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:07 --> Total execution time: 0.0528
DEBUG - 2022-05-31 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:09 --> Total execution time: 0.0338
DEBUG - 2022-05-31 10:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:21:09 --> Total execution time: 0.0464
DEBUG - 2022-05-31 10:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:10 --> Total execution time: 0.0378
DEBUG - 2022-05-31 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:11 --> Total execution time: 0.0246
DEBUG - 2022-05-31 10:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:13 --> Total execution time: 0.0466
DEBUG - 2022-05-31 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:18 --> Total execution time: 0.0356
DEBUG - 2022-05-31 10:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:19 --> Total execution time: 0.0633
DEBUG - 2022-05-31 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:51:58 --> Total execution time: 0.0269
DEBUG - 2022-05-31 10:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:52:05 --> Total execution time: 0.0511
DEBUG - 2022-05-31 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:52:12 --> Total execution time: 0.0284
DEBUG - 2022-05-31 10:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:52:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:52:13 --> Total execution time: 0.0413
DEBUG - 2022-05-31 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:52:57 --> Total execution time: 0.0252
DEBUG - 2022-05-31 10:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:13 --> Total execution time: 0.0246
DEBUG - 2022-05-31 10:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:16 --> Total execution time: 0.0285
DEBUG - 2022-05-31 10:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:17 --> Total execution time: 0.0243
DEBUG - 2022-05-31 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:47 --> Total execution time: 0.0457
DEBUG - 2022-05-31 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:53:55 --> Total execution time: 0.0217
DEBUG - 2022-05-31 10:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:54:14 --> Total execution time: 0.0250
DEBUG - 2022-05-31 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:54:20 --> Total execution time: 0.0285
DEBUG - 2022-05-31 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:54:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:54:21 --> Total execution time: 0.0244
DEBUG - 2022-05-31 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:24:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:54:43 --> Total execution time: 0.0291
DEBUG - 2022-05-31 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:17 --> Total execution time: 0.0248
DEBUG - 2022-05-31 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:24 --> Total execution time: 0.0273
DEBUG - 2022-05-31 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:32 --> Total execution time: 0.0339
DEBUG - 2022-05-31 10:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:35 --> Total execution time: 0.0562
DEBUG - 2022-05-31 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:40 --> Total execution time: 0.0334
DEBUG - 2022-05-31 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:47 --> Total execution time: 0.0289
DEBUG - 2022-05-31 10:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:52 --> Total execution time: 0.0212
DEBUG - 2022-05-31 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:04 --> Total execution time: 0.0300
DEBUG - 2022-05-31 10:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:11 --> Total execution time: 0.0414
DEBUG - 2022-05-31 10:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:16 --> Total execution time: 0.0258
DEBUG - 2022-05-31 10:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:43 --> Total execution time: 0.0494
DEBUG - 2022-05-31 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:45 --> Total execution time: 0.0373
DEBUG - 2022-05-31 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:45 --> Total execution time: 0.0287
DEBUG - 2022-05-31 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:51 --> Total execution time: 0.0350
DEBUG - 2022-05-31 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:52 --> Total execution time: 0.0449
DEBUG - 2022-05-31 10:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:56:54 --> Total execution time: 0.0357
DEBUG - 2022-05-31 10:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:57:00 --> Total execution time: 0.0625
DEBUG - 2022-05-31 10:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:57:05 --> Total execution time: 0.0331
DEBUG - 2022-05-31 10:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:01:02 --> Total execution time: 0.0897
DEBUG - 2022-05-31 10:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:32 --> Total execution time: 0.1015
DEBUG - 2022-05-31 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:38 --> Total execution time: 0.0328
DEBUG - 2022-05-31 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:39 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:39 --> Total execution time: 0.0292
DEBUG - 2022-05-31 10:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:49 --> Total execution time: 0.0250
DEBUG - 2022-05-31 10:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:33:51 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:03:51 --> Total execution time: 0.0245
DEBUG - 2022-05-31 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:04:14 --> Total execution time: 0.0341
DEBUG - 2022-05-31 10:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:04:23 --> Total execution time: 0.0262
DEBUG - 2022-05-31 10:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:04:44 --> Total execution time: 0.0319
DEBUG - 2022-05-31 10:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:05:08 --> Total execution time: 0.0266
DEBUG - 2022-05-31 10:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:05:13 --> Total execution time: 0.0290
DEBUG - 2022-05-31 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:35:22 --> Total execution time: 0.0372
DEBUG - 2022-05-31 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:35:23 --> Total execution time: 0.0312
DEBUG - 2022-05-31 10:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:35:23 --> Total execution time: 0.0575
DEBUG - 2022-05-31 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:05:38 --> Total execution time: 0.0241
DEBUG - 2022-05-31 10:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:05:46 --> Total execution time: 0.0243
DEBUG - 2022-05-31 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:05:58 --> Total execution time: 0.0653
DEBUG - 2022-05-31 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:09 --> Total execution time: 0.0461
DEBUG - 2022-05-31 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:17 --> Total execution time: 0.0280
DEBUG - 2022-05-31 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:18 --> Total execution time: 0.0466
DEBUG - 2022-05-31 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:30 --> Total execution time: 0.0252
DEBUG - 2022-05-31 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:37 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-05-31 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:37 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:37 --> 404 Page Not Found: Course/freelancing
DEBUG - 2022-05-31 10:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:38 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:39 --> Total execution time: 0.0215
DEBUG - 2022-05-31 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:40 --> Total execution time: 0.0299
DEBUG - 2022-05-31 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 10:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:42 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 10:36:43 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-05-31 10:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:56 --> Total execution time: 0.0518
DEBUG - 2022-05-31 10:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:37:25 --> Total execution time: 0.0467
DEBUG - 2022-05-31 10:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:37:27 --> Total execution time: 0.0411
DEBUG - 2022-05-31 10:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:37:27 --> Total execution time: 0.0354
DEBUG - 2022-05-31 10:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:44 --> Total execution time: 0.0421
DEBUG - 2022-05-31 10:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:48 --> Total execution time: 0.0253
DEBUG - 2022-05-31 10:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:49 --> Total execution time: 0.0219
DEBUG - 2022-05-31 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:08:00 --> Total execution time: 0.0348
DEBUG - 2022-05-31 10:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:10:04 --> Total execution time: 0.0344
DEBUG - 2022-05-31 10:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:18 --> Total execution time: 0.0288
DEBUG - 2022-05-31 10:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:24 --> Total execution time: 0.0668
DEBUG - 2022-05-31 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:51 --> Total execution time: 0.0301
DEBUG - 2022-05-31 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:53 --> Total execution time: 0.0365
DEBUG - 2022-05-31 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:58 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 10:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:11:59 --> Total execution time: 0.0337
DEBUG - 2022-05-31 10:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:42:07 --> Total execution time: 0.0340
DEBUG - 2022-05-31 10:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:42:09 --> Total execution time: 0.0464
DEBUG - 2022-05-31 10:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:42:09 --> Total execution time: 0.0740
DEBUG - 2022-05-31 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:42:45 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:12:46 --> Total execution time: 0.0338
DEBUG - 2022-05-31 10:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:13:10 --> Total execution time: 0.0799
DEBUG - 2022-05-31 10:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:16 --> Total execution time: 0.0390
DEBUG - 2022-05-31 10:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:44:24 --> Total execution time: 0.1112
DEBUG - 2022-05-31 10:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:12 --> Total execution time: 0.0747
DEBUG - 2022-05-31 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:27 --> Total execution time: 0.0346
DEBUG - 2022-05-31 10:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:30 --> Total execution time: 0.0603
DEBUG - 2022-05-31 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:53 --> Total execution time: 0.0895
DEBUG - 2022-05-31 10:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:53:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 10:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:49 --> Total execution time: 0.1357
DEBUG - 2022-05-31 10:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:09 --> Total execution time: 0.0252
DEBUG - 2022-05-31 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:10 --> Total execution time: 0.0331
DEBUG - 2022-05-31 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:39 --> Total execution time: 0.0329
DEBUG - 2022-05-31 10:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:50 --> Total execution time: 0.0395
DEBUG - 2022-05-31 10:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:27:02 --> Total execution time: 0.0623
DEBUG - 2022-05-31 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:26 --> Total execution time: 0.0300
DEBUG - 2022-05-31 10:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:27:33 --> Total execution time: 0.0331
DEBUG - 2022-05-31 10:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 10:57:39 --> Total execution time: 0.0549
DEBUG - 2022-05-31 10:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:27:54 --> Total execution time: 0.0323
DEBUG - 2022-05-31 10:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 10:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 10:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:29:55 --> Total execution time: 0.0404
DEBUG - 2022-05-31 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:02 --> Total execution time: 0.0562
DEBUG - 2022-05-31 11:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:51 --> Total execution time: 0.0593
DEBUG - 2022-05-31 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:33:16 --> Total execution time: 0.1597
DEBUG - 2022-05-31 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:33:20 --> Total execution time: 0.0460
DEBUG - 2022-05-31 11:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:37:50 --> Total execution time: 0.0854
DEBUG - 2022-05-31 11:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:08:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:38:11 --> Total execution time: 0.0317
DEBUG - 2022-05-31 11:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:38:32 --> Total execution time: 0.0201
DEBUG - 2022-05-31 11:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:05 --> Total execution time: 0.0459
DEBUG - 2022-05-31 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:09 --> Total execution time: 0.0386
DEBUG - 2022-05-31 11:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:14 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:14 --> Total execution time: 0.0301
DEBUG - 2022-05-31 11:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:31 --> Total execution time: 0.0402
DEBUG - 2022-05-31 11:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:33 --> Total execution time: 0.0400
DEBUG - 2022-05-31 11:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:34 --> Total execution time: 0.0316
DEBUG - 2022-05-31 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:35 --> Total execution time: 0.0257
DEBUG - 2022-05-31 11:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:09:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:53 --> Total execution time: 0.0289
DEBUG - 2022-05-31 11:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:00 --> Total execution time: 0.0267
DEBUG - 2022-05-31 11:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:08 --> Total execution time: 0.0186
DEBUG - 2022-05-31 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:39 --> Total execution time: 0.0262
DEBUG - 2022-05-31 11:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:10:43 --> Total execution time: 0.0280
DEBUG - 2022-05-31 11:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:44 --> Total execution time: 0.0244
DEBUG - 2022-05-31 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:10:45 --> Total execution time: 0.0201
DEBUG - 2022-05-31 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:10:45 --> Total execution time: 0.0448
DEBUG - 2022-05-31 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:10:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:46 --> Total execution time: 0.0262
DEBUG - 2022-05-31 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:06 --> Total execution time: 0.0268
DEBUG - 2022-05-31 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:17 --> Total execution time: 0.0273
DEBUG - 2022-05-31 11:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:18 --> Total execution time: 0.0442
DEBUG - 2022-05-31 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:23 --> Total execution time: 0.0320
DEBUG - 2022-05-31 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:24 --> Total execution time: 0.0635
DEBUG - 2022-05-31 11:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:32 --> Total execution time: 0.0345
DEBUG - 2022-05-31 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:36 --> Total execution time: 0.0306
DEBUG - 2022-05-31 11:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:36 --> Total execution time: 0.0305
DEBUG - 2022-05-31 11:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:39 --> Total execution time: 0.0728
DEBUG - 2022-05-31 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:42 --> Total execution time: 0.0584
DEBUG - 2022-05-31 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:45 --> Total execution time: 0.0420
DEBUG - 2022-05-31 11:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:41:52 --> Total execution time: 0.0455
DEBUG - 2022-05-31 11:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:00 --> Total execution time: 0.0372
DEBUG - 2022-05-31 11:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:06 --> Total execution time: 0.0273
DEBUG - 2022-05-31 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:09 --> Total execution time: 0.0359
DEBUG - 2022-05-31 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:14 --> Total execution time: 0.0331
DEBUG - 2022-05-31 11:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:16 --> Total execution time: 0.0338
DEBUG - 2022-05-31 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:19 --> Total execution time: 0.0441
DEBUG - 2022-05-31 11:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:23 --> Total execution time: 0.0814
DEBUG - 2022-05-31 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:26 --> Total execution time: 0.0478
DEBUG - 2022-05-31 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:31 --> Total execution time: 0.0606
DEBUG - 2022-05-31 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:36 --> Total execution time: 0.0402
DEBUG - 2022-05-31 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:12:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:42:54 --> Total execution time: 0.0303
DEBUG - 2022-05-31 11:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:43:04 --> Total execution time: 0.0374
DEBUG - 2022-05-31 11:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:43:12 --> Total execution time: 0.0315
DEBUG - 2022-05-31 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:43:15 --> Total execution time: 0.0433
DEBUG - 2022-05-31 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:16:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:46:32 --> Total execution time: 0.0794
DEBUG - 2022-05-31 11:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:16:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:46:46 --> Total execution time: 0.0338
DEBUG - 2022-05-31 11:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:46:46 --> Total execution time: 0.0605
DEBUG - 2022-05-31 11:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:46:53 --> Total execution time: 0.0428
DEBUG - 2022-05-31 11:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:47:01 --> Total execution time: 0.0543
DEBUG - 2022-05-31 11:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:47:24 --> Total execution time: 0.0516
DEBUG - 2022-05-31 11:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:47:29 --> Total execution time: 0.0323
DEBUG - 2022-05-31 11:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:48:01 --> Total execution time: 0.2602
DEBUG - 2022-05-31 11:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:48:28 --> Total execution time: 0.0296
DEBUG - 2022-05-31 11:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:48:29 --> Total execution time: 0.0276
DEBUG - 2022-05-31 11:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:48:32 --> Total execution time: 0.0446
DEBUG - 2022-05-31 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:08 --> Total execution time: 0.0347
DEBUG - 2022-05-31 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:08 --> Total execution time: 0.0293
DEBUG - 2022-05-31 11:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:17 --> Total execution time: 0.0300
DEBUG - 2022-05-31 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:35 --> Total execution time: 0.0283
DEBUG - 2022-05-31 11:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:40 --> Total execution time: 0.0194
DEBUG - 2022-05-31 11:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:19:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:49:44 --> Total execution time: 0.0216
DEBUG - 2022-05-31 11:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:14 --> Total execution time: 0.0307
DEBUG - 2022-05-31 11:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:30 --> Total execution time: 0.0579
DEBUG - 2022-05-31 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:35 --> Total execution time: 0.0201
DEBUG - 2022-05-31 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:40 --> Total execution time: 0.0569
DEBUG - 2022-05-31 11:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:46 --> Total execution time: 0.0222
DEBUG - 2022-05-31 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:50:48 --> Total execution time: 0.0285
DEBUG - 2022-05-31 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:51:33 --> Total execution time: 0.0255
DEBUG - 2022-05-31 11:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:52:17 --> Total execution time: 0.0348
DEBUG - 2022-05-31 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:52:26 --> Total execution time: 0.0657
DEBUG - 2022-05-31 11:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:52:33 --> Total execution time: 0.0325
DEBUG - 2022-05-31 11:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:22:39 --> Total execution time: 0.0260
DEBUG - 2022-05-31 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:52:51 --> Total execution time: 0.0324
DEBUG - 2022-05-31 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:52:59 --> Total execution time: 0.0313
DEBUG - 2022-05-31 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:10 --> Total execution time: 0.0396
DEBUG - 2022-05-31 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:11 --> Total execution time: 0.0315
DEBUG - 2022-05-31 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:43 --> Total execution time: 0.0296
DEBUG - 2022-05-31 11:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:59 --> Total execution time: 0.0578
DEBUG - 2022-05-31 11:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:54:33 --> Total execution time: 0.0401
DEBUG - 2022-05-31 11:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:54:38 --> Total execution time: 0.0280
DEBUG - 2022-05-31 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:55:04 --> Total execution time: 0.0287
DEBUG - 2022-05-31 11:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:55:08 --> Total execution time: 0.0583
DEBUG - 2022-05-31 11:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:55:11 --> Total execution time: 0.0318
DEBUG - 2022-05-31 11:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:56:00 --> Total execution time: 0.0281
DEBUG - 2022-05-31 11:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:27:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 11:27:49 --> 404 Page Not Found: Category/sports
DEBUG - 2022-05-31 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:27 --> Total execution time: 0.0260
DEBUG - 2022-05-31 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:20 --> Total execution time: 0.0527
DEBUG - 2022-05-31 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:31 --> Total execution time: 0.0238
DEBUG - 2022-05-31 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:29:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:44 --> Total execution time: 0.0304
DEBUG - 2022-05-31 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:30:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:00:03 --> Total execution time: 0.0264
DEBUG - 2022-05-31 11:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:30:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:00:04 --> Total execution time: 0.0240
DEBUG - 2022-05-31 11:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:13 --> Total execution time: 0.1240
DEBUG - 2022-05-31 11:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:18 --> Total execution time: 0.0294
DEBUG - 2022-05-31 11:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:34 --> Total execution time: 0.0526
DEBUG - 2022-05-31 11:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:34 --> Total execution time: 0.0220
DEBUG - 2022-05-31 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:35 --> Total execution time: 0.0233
DEBUG - 2022-05-31 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:35 --> Total execution time: 0.0250
DEBUG - 2022-05-31 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:35 --> Total execution time: 0.0511
DEBUG - 2022-05-31 11:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:44 --> Total execution time: 0.0444
DEBUG - 2022-05-31 11:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:53 --> Total execution time: 0.0751
DEBUG - 2022-05-31 11:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:00 --> Total execution time: 0.0259
DEBUG - 2022-05-31 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:15 --> Total execution time: 0.0315
DEBUG - 2022-05-31 11:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:16 --> Total execution time: 0.0253
DEBUG - 2022-05-31 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:34:53 --> Total execution time: 0.0276
DEBUG - 2022-05-31 11:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:34:55 --> Total execution time: 0.0246
DEBUG - 2022-05-31 11:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:34:55 --> Total execution time: 0.0501
DEBUG - 2022-05-31 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:15 --> Total execution time: 0.0244
DEBUG - 2022-05-31 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:20 --> Total execution time: 0.0300
DEBUG - 2022-05-31 11:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:00 --> Total execution time: 0.0315
DEBUG - 2022-05-31 11:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:37:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:28 --> Total execution time: 0.0355
DEBUG - 2022-05-31 11:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:34 --> Total execution time: 0.0256
DEBUG - 2022-05-31 11:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:44 --> Total execution time: 0.0244
DEBUG - 2022-05-31 11:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:04 --> Total execution time: 0.0369
DEBUG - 2022-05-31 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:25 --> Total execution time: 0.0286
DEBUG - 2022-05-31 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:26 --> Total execution time: 0.0405
DEBUG - 2022-05-31 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:30 --> Total execution time: 0.0242
DEBUG - 2022-05-31 11:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:09:40 --> Total execution time: 0.0491
DEBUG - 2022-05-31 11:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:09:43 --> Total execution time: 0.0288
DEBUG - 2022-05-31 11:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:10:04 --> Total execution time: 0.0329
DEBUG - 2022-05-31 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:10:37 --> Total execution time: 0.0333
DEBUG - 2022-05-31 11:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:11:31 --> Total execution time: 0.0371
DEBUG - 2022-05-31 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:42:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:12:09 --> Total execution time: 0.0225
DEBUG - 2022-05-31 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:12:38 --> Total execution time: 0.0301
DEBUG - 2022-05-31 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:13:44 --> Total execution time: 0.0687
DEBUG - 2022-05-31 11:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:13 --> Total execution time: 0.0542
DEBUG - 2022-05-31 11:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:45:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 11:45:17 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-31 11:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:26 --> Total execution time: 0.0513
DEBUG - 2022-05-31 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:46 --> Total execution time: 0.0676
DEBUG - 2022-05-31 11:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:47 --> Total execution time: 0.0554
DEBUG - 2022-05-31 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:46:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:09 --> Total execution time: 0.0533
DEBUG - 2022-05-31 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:51 --> Total execution time: 0.0193
DEBUG - 2022-05-31 11:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:17 --> Total execution time: 0.0487
DEBUG - 2022-05-31 11:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:47:46 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:46 --> Total execution time: 0.0241
DEBUG - 2022-05-31 11:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:52 --> Total execution time: 0.0278
DEBUG - 2022-05-31 11:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:57 --> Total execution time: 0.0389
DEBUG - 2022-05-31 11:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:06 --> Total execution time: 0.0306
DEBUG - 2022-05-31 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:17 --> Total execution time: 0.0249
DEBUG - 2022-05-31 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:27 --> Total execution time: 0.0321
DEBUG - 2022-05-31 11:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:48:31 --> Total execution time: 0.0260
DEBUG - 2022-05-31 11:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:33 --> Total execution time: 0.0515
DEBUG - 2022-05-31 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:37 --> Total execution time: 0.0507
DEBUG - 2022-05-31 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:52:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:10 --> Total execution time: 0.1190
DEBUG - 2022-05-31 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:53:55 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:55 --> Total execution time: 0.0327
DEBUG - 2022-05-31 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:53:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:58 --> Total execution time: 0.0502
DEBUG - 2022-05-31 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:08 --> Total execution time: 0.0337
DEBUG - 2022-05-31 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:15 --> Total execution time: 0.0247
DEBUG - 2022-05-31 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:20 --> Total execution time: 0.1077
DEBUG - 2022-05-31 11:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:25 --> Total execution time: 0.0301
DEBUG - 2022-05-31 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:28 --> Total execution time: 0.0319
DEBUG - 2022-05-31 11:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:32 --> Total execution time: 0.0289
DEBUG - 2022-05-31 11:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:39 --> Total execution time: 0.0347
DEBUG - 2022-05-31 11:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:44 --> Total execution time: 0.0295
DEBUG - 2022-05-31 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:47 --> Total execution time: 0.0278
DEBUG - 2022-05-31 11:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:53 --> Total execution time: 0.0555
DEBUG - 2022-05-31 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:57 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:57 --> Total execution time: 0.0301
DEBUG - 2022-05-31 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:59 --> Total execution time: 0.0352
DEBUG - 2022-05-31 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:03 --> Total execution time: 0.0460
DEBUG - 2022-05-31 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:55:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:20 --> Total execution time: 0.0254
DEBUG - 2022-05-31 11:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 11:56:33 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-31 11:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:26:59 --> Total execution time: 0.0827
DEBUG - 2022-05-31 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:27:01 --> Total execution time: 0.0283
DEBUG - 2022-05-31 11:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 11:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 11:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 11:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:27:02 --> Total execution time: 0.0288
DEBUG - 2022-05-31 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:04 --> Total execution time: 0.1173
DEBUG - 2022-05-31 12:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:25 --> Total execution time: 0.1656
DEBUG - 2022-05-31 12:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:40 --> Total execution time: 0.0347
DEBUG - 2022-05-31 12:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:49 --> Total execution time: 0.0775
DEBUG - 2022-05-31 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:53 --> Total execution time: 0.0427
DEBUG - 2022-05-31 12:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:57 --> Total execution time: 0.0315
DEBUG - 2022-05-31 12:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:06:11 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-31 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:15 --> Total execution time: 0.0303
DEBUG - 2022-05-31 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:25 --> Total execution time: 0.0330
DEBUG - 2022-05-31 12:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:28 --> Total execution time: 0.0385
DEBUG - 2022-05-31 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:31 --> Total execution time: 0.0334
DEBUG - 2022-05-31 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:49 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:49 --> Total execution time: 0.0219
DEBUG - 2022-05-31 12:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:51 --> Total execution time: 0.0202
DEBUG - 2022-05-31 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:01 --> Total execution time: 0.0329
DEBUG - 2022-05-31 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:07:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:40 --> Total execution time: 0.0277
DEBUG - 2022-05-31 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:43 --> Total execution time: 0.0296
DEBUG - 2022-05-31 12:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:48 --> Total execution time: 0.0453
DEBUG - 2022-05-31 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:15 --> Total execution time: 0.0193
DEBUG - 2022-05-31 12:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:18 --> Total execution time: 0.0411
DEBUG - 2022-05-31 12:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:02 --> Total execution time: 0.0254
DEBUG - 2022-05-31 12:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:44:11 --> Total execution time: 0.0314
DEBUG - 2022-05-31 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:14:24 --> Total execution time: 0.0258
DEBUG - 2022-05-31 12:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:15:02 --> Total execution time: 0.0610
DEBUG - 2022-05-31 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:15:08 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:08 --> Total execution time: 0.0268
DEBUG - 2022-05-31 12:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:42 --> Total execution time: 0.0302
DEBUG - 2022-05-31 12:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:59 --> Total execution time: 4.7608
DEBUG - 2022-05-31 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:16:40 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:16:40 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:18:25 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:18:40 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:19:27 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:19:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:19:27 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:19:35 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:49:35 --> Total execution time: 0.0833
DEBUG - 2022-05-31 12:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:49:44 --> Total execution time: 0.0263
DEBUG - 2022-05-31 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:49:59 --> Total execution time: 0.0277
DEBUG - 2022-05-31 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:19:59 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:50:00 --> Total execution time: 0.0259
DEBUG - 2022-05-31 12:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:20:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:20:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:50:30 --> Total execution time: 0.0605
DEBUG - 2022-05-31 12:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:20:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:20:35 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 12:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:50:44 --> Total execution time: 0.0344
DEBUG - 2022-05-31 12:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:20:50 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-05-31 12:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:01 --> Total execution time: 0.0388
DEBUG - 2022-05-31 12:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:03 --> Total execution time: 0.0262
DEBUG - 2022-05-31 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:07 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:07 --> Total execution time: 0.0373
DEBUG - 2022-05-31 12:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:09 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:09 --> Total execution time: 0.0242
DEBUG - 2022-05-31 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:13 --> Total execution time: 0.0306
DEBUG - 2022-05-31 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:32 --> Total execution time: 0.0320
DEBUG - 2022-05-31 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:34 --> Total execution time: 0.0268
DEBUG - 2022-05-31 12:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:34 --> Total execution time: 0.0507
DEBUG - 2022-05-31 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:40 --> Total execution time: 0.0299
DEBUG - 2022-05-31 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:43 --> Total execution time: 0.0273
DEBUG - 2022-05-31 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:51:51 --> Total execution time: 0.0246
DEBUG - 2022-05-31 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:52:06 --> Total execution time: 0.0302
DEBUG - 2022-05-31 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:52:13 --> Total execution time: 4.5144
DEBUG - 2022-05-31 12:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:52:25 --> Total execution time: 0.0574
DEBUG - 2022-05-31 12:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:22:46 --> 404 Page Not Found: Login/index
DEBUG - 2022-05-31 12:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:52:57 --> Total execution time: 0.0464
DEBUG - 2022-05-31 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:06 --> Total execution time: 0.0382
DEBUG - 2022-05-31 12:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:14 --> Total execution time: 0.0348
DEBUG - 2022-05-31 12:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:20 --> Total execution time: 0.0294
DEBUG - 2022-05-31 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:24 --> Total execution time: 0.0294
DEBUG - 2022-05-31 12:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:28 --> Total execution time: 0.0475
DEBUG - 2022-05-31 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:33 --> Total execution time: 0.0328
DEBUG - 2022-05-31 12:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:53:38 --> Total execution time: 0.0251
DEBUG - 2022-05-31 12:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:24:03 --> Total execution time: 0.0314
DEBUG - 2022-05-31 12:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:54:07 --> Total execution time: 0.0400
DEBUG - 2022-05-31 12:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:54:15 --> Total execution time: 0.0366
DEBUG - 2022-05-31 12:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:54:20 --> Total execution time: 0.0390
DEBUG - 2022-05-31 12:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:27 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:56:27 --> Total execution time: 0.0440
DEBUG - 2022-05-31 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:56:36 --> Total execution time: 0.0201
DEBUG - 2022-05-31 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:56:51 --> Total execution time: 0.0276
DEBUG - 2022-05-31 12:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:56:53 --> Total execution time: 0.0432
DEBUG - 2022-05-31 12:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:56:56 --> Total execution time: 0.0319
DEBUG - 2022-05-31 12:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:30:25 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:00:25 --> Total execution time: 0.0914
DEBUG - 2022-05-31 12:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:03:36 --> Total execution time: 0.0779
DEBUG - 2022-05-31 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:23 --> Total execution time: 0.0554
DEBUG - 2022-05-31 12:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 12:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:28 --> Total execution time: 0.0274
DEBUG - 2022-05-31 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:41 --> Total execution time: 0.0270
DEBUG - 2022-05-31 12:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:42 --> Total execution time: 0.0336
DEBUG - 2022-05-31 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:47 --> Total execution time: 0.0240
DEBUG - 2022-05-31 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:05:59 --> Total execution time: 0.0447
DEBUG - 2022-05-31 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:06:24 --> Total execution time: 0.0391
DEBUG - 2022-05-31 12:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:06:26 --> Total execution time: 0.0255
DEBUG - 2022-05-31 12:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:05 --> Total execution time: 0.0249
DEBUG - 2022-05-31 12:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:08:05 --> Total execution time: 0.0275
DEBUG - 2022-05-31 12:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:09 --> Total execution time: 0.0317
DEBUG - 2022-05-31 12:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:38:14 --> Total execution time: 0.0880
DEBUG - 2022-05-31 12:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:09:04 --> Total execution time: 0.0297
DEBUG - 2022-05-31 12:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:09:27 --> Total execution time: 0.0279
DEBUG - 2022-05-31 12:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:09:39 --> Total execution time: 0.0663
DEBUG - 2022-05-31 12:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:10:10 --> Total execution time: 0.0376
DEBUG - 2022-05-31 12:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:10:19 --> Total execution time: 0.0652
DEBUG - 2022-05-31 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:10:28 --> Total execution time: 0.0595
DEBUG - 2022-05-31 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:10:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 12:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:10:55 --> Total execution time: 0.0761
DEBUG - 2022-05-31 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:00 --> Total execution time: 0.0558
DEBUG - 2022-05-31 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:02 --> Total execution time: 0.0689
DEBUG - 2022-05-31 12:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:10 --> Total execution time: 0.0302
DEBUG - 2022-05-31 12:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:15 --> Total execution time: 0.0265
DEBUG - 2022-05-31 12:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:47 --> Total execution time: 0.0283
DEBUG - 2022-05-31 12:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:13 --> Total execution time: 0.0624
DEBUG - 2022-05-31 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:26 --> Total execution time: 0.0248
DEBUG - 2022-05-31 12:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:37 --> Total execution time: 0.0317
DEBUG - 2022-05-31 12:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:41 --> Total execution time: 0.0245
DEBUG - 2022-05-31 12:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:44 --> Total execution time: 0.0402
DEBUG - 2022-05-31 12:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:55 --> Total execution time: 0.0258
DEBUG - 2022-05-31 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:02 --> Total execution time: 0.0303
DEBUG - 2022-05-31 12:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:06 --> Total execution time: 0.0668
DEBUG - 2022-05-31 12:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:08 --> Total execution time: 0.0585
DEBUG - 2022-05-31 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-05-31 23:14:11 --> You did not select a file to upload.
DEBUG - 2022-05-31 12:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:11 --> Total execution time: 0.0278
DEBUG - 2022-05-31 12:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:15:28 --> Total execution time: 0.0432
DEBUG - 2022-05-31 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:27 --> Total execution time: 0.0574
DEBUG - 2022-05-31 12:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:43 --> Total execution time: 0.0293
DEBUG - 2022-05-31 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:43 --> Total execution time: 0.0313
DEBUG - 2022-05-31 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:00 --> Total execution time: 4.4832
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:13 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:50 --> Total execution time: 0.1170
DEBUG - 2022-05-31 12:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:47:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:47:54 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:00 --> Total execution time: 0.0862
DEBUG - 2022-05-31 12:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:55 --> Total execution time: 4.4148
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:00 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:02 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:49:02 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:51:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 12:51:18 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 12:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:24:15 --> Total execution time: 0.1373
DEBUG - 2022-05-31 12:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:26:01 --> Total execution time: 0.0555
DEBUG - 2022-05-31 12:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:26:48 --> Total execution time: 0.0289
DEBUG - 2022-05-31 12:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 12:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:27:40 --> Total execution time: 0.0457
DEBUG - 2022-05-31 12:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:27:51 --> Total execution time: 0.0361
DEBUG - 2022-05-31 12:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:28:01 --> Total execution time: 0.0623
DEBUG - 2022-05-31 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:28:08 --> Total execution time: 0.0530
DEBUG - 2022-05-31 12:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:28:16 --> Total execution time: 0.0604
DEBUG - 2022-05-31 12:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:28:23 --> Total execution time: 0.0478
DEBUG - 2022-05-31 12:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:28:38 --> Total execution time: 0.0851
DEBUG - 2022-05-31 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 12:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 12:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:29:59 --> Total execution time: 0.0550
DEBUG - 2022-05-31 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:30:02 --> Total execution time: 0.0418
DEBUG - 2022-05-31 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:30:02 --> Total execution time: 0.0845
DEBUG - 2022-05-31 13:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:30:09 --> Total execution time: 0.0543
DEBUG - 2022-05-31 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:30:30 --> Total execution time: 0.0322
DEBUG - 2022-05-31 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:30:53 --> Total execution time: 0.0258
DEBUG - 2022-05-31 13:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:31:23 --> Total execution time: 0.0318
DEBUG - 2022-05-31 13:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:31:36 --> Total execution time: 0.0250
DEBUG - 2022-05-31 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:01:56 --> No URI present. Default controller set.
DEBUG - 2022-05-31 13:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:31:56 --> Total execution time: 0.0340
DEBUG - 2022-05-31 13:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:47:57 --> Total execution time: 0.0978
DEBUG - 2022-05-31 13:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:48:03 --> Total execution time: 0.0322
DEBUG - 2022-05-31 13:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:23:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 13:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:53:48 --> Total execution time: 0.0848
DEBUG - 2022-05-31 13:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:29:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 13:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:59:44 --> Total execution time: 0.0751
DEBUG - 2022-05-31 13:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:37:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 13:37:05 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-05-31 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:46:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 13:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 13:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 13:50:18 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-31 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:00:39 --> No URI present. Default controller set.
DEBUG - 2022-05-31 14:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 14:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:28 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:28 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:28 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:29 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:29 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:12:29 --> 404 Page Not Found: User/login
DEBUG - 2022-05-31 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:36:11 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 14:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 14:36:11 --> 404 Page Not Found: Wp-sitemap-taxonomies-teacher_cat-1xml/index
DEBUG - 2022-05-31 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 14:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 14:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 14:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:01:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 15:01:18 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 15:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:01:22 --> No URI present. Default controller set.
DEBUG - 2022-05-31 15:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:01:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 15:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 15:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 15:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 15:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:06:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 16:06:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:06:26 --> No URI present. Default controller set.
DEBUG - 2022-05-31 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 16:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 16:07:22 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 16:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:24 --> No URI present. Default controller set.
DEBUG - 2022-05-31 16:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 16:07:27 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:07:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 16:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:43 --> Total execution time: 0.0324
DEBUG - 2022-05-31 16:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:46 --> Total execution time: 0.0517
DEBUG - 2022-05-31 16:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:46 --> Total execution time: 0.0471
DEBUG - 2022-05-31 16:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:13:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:14:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 16:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 16:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 16:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 16:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:23:48 --> Total execution time: 0.1030
DEBUG - 2022-05-31 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:01 --> Total execution time: 0.0281
DEBUG - 2022-05-31 17:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 17:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 17:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 17:31:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:09:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 18:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:09:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 18:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:39:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 18:39:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 18:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:39:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 18:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:39:03 --> No URI present. Default controller set.
DEBUG - 2022-05-31 18:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 18:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 18:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 18:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 18:39:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 19:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:02:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:10:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 19:10:23 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-31 19:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 19:12:43 --> 404 Page Not Found: Affiliate-register-page/index
DEBUG - 2022-05-31 19:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:21:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 19:21:20 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-05-31 19:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:31:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 19:31:28 --> 404 Page Not Found: Category/business
DEBUG - 2022-05-31 19:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:34:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:41:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:50 --> Total execution time: 0.0247
DEBUG - 2022-05-31 19:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:43:54 --> Total execution time: 0.0233
DEBUG - 2022-05-31 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:04 --> Total execution time: 0.0251
DEBUG - 2022-05-31 19:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:18 --> Total execution time: 0.0255
DEBUG - 2022-05-31 19:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:21 --> Total execution time: 0.0251
DEBUG - 2022-05-31 19:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:22 --> Total execution time: 0.0256
DEBUG - 2022-05-31 19:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:23 --> Total execution time: 0.0244
DEBUG - 2022-05-31 19:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:53:55 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:55:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:55:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 19:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 19:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 19:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 19:56:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 19:56:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:12:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 20:12:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 20:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:12:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 20:12:43 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-05-31 20:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:18:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:18:47 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:28:52 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:30:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:32:07 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:37:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:43:44 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:46:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 20:47:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 20:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 20:47:29 --> 404 Page Not Found: Course/bright-future-personal-banding
DEBUG - 2022-05-31 20:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:48:21 --> No URI present. Default controller set.
DEBUG - 2022-05-31 20:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:48:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 20:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 20:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 20:55:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 20:55:41 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-05-31 21:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:12:09 --> 404 Page Not Found: Feed/index
DEBUG - 2022-05-31 21:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:23 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:20:52 --> Total execution time: 0.0267
DEBUG - 2022-05-31 21:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:10 --> Total execution time: 0.0251
DEBUG - 2022-05-31 21:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:28 --> Total execution time: 0.0286
DEBUG - 2022-05-31 21:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:31 --> Total execution time: 0.0306
DEBUG - 2022-05-31 21:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:21:51 --> Total execution time: 0.0242
DEBUG - 2022-05-31 21:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:27 --> Total execution time: 0.0484
DEBUG - 2022-05-31 21:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:48 --> Total execution time: 0.0267
DEBUG - 2022-05-31 21:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:23:53 --> Total execution time: 0.0386
DEBUG - 2022-05-31 21:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:07 --> Total execution time: 0.0417
DEBUG - 2022-05-31 21:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:09 --> Total execution time: 0.0340
DEBUG - 2022-05-31 21:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:24:53 --> Total execution time: 0.0234
DEBUG - 2022-05-31 21:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:25:14 --> 404 Page Not Found: Wp-sitemapxml/index
DEBUG - 2022-05-31 21:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:28:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:30:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:39:52 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:40:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:44:41 --> Total execution time: 0.0227
DEBUG - 2022-05-31 21:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:45:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:47:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:48:12 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:53:54 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:54:54 --> Total execution time: 0.0238
DEBUG - 2022-05-31 21:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:54:54 --> Total execution time: 0.0249
DEBUG - 2022-05-31 21:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:55:37 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:57:10 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:57:11 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:57:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:57:17 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:16 --> No URI present. Default controller set.
DEBUG - 2022-05-31 21:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:36 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:42 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:42 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:43 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 21:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:50 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:50 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 21:59:50 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-05-31 21:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 21:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 21:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:18 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:06:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-31 22:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:14:32 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:34 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:15:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:40 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:49 --> Total execution time: 0.0251
DEBUG - 2022-05-31 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:51 --> Total execution time: 0.0313
DEBUG - 2022-05-31 22:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:51 --> Total execution time: 0.0559
DEBUG - 2022-05-31 22:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:05 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:23:43 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:24:51 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:00 --> Total execution time: 0.0489
DEBUG - 2022-05-31 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:01 --> Total execution time: 0.0302
DEBUG - 2022-05-31 22:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:01 --> Total execution time: 0.0520
DEBUG - 2022-05-31 22:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:31 --> Total execution time: 0.0210
DEBUG - 2022-05-31 22:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:33 --> Total execution time: 0.0402
DEBUG - 2022-05-31 22:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:33 --> Total execution time: 0.0359
DEBUG - 2022-05-31 22:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:26 --> 404 Page Not Found: User/User_crud_controller/GetUserList
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:38 --> 404 Page Not Found: User/User_crud_controller/GetUserList
DEBUG - 2022-05-31 22:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:28:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:28:42 --> 404 Page Not Found: User/User_crud_controller/GetUserList
DEBUG - 2022-05-31 22:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:27 --> 404 Page Not Found: Admin/Users/User_crud_controller
DEBUG - 2022-05-31 22:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:28 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-05-31 22:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:29:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:29:36 --> 404 Page Not Found: Admin/Users/User_crud_controller
DEBUG - 2022-05-31 22:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-31 22:30:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:30:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:30:44 --> 404 Page Not Found: Admin/Users/User_crud_controller
DEBUG - 2022-05-31 22:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:31:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:32:39 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:33:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:33:48 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:35:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-05-31 22:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:05 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:06 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:15 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:42 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:40:13 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:31 --> No URI present. Default controller set.
DEBUG - 2022-05-31 22:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:45:33 --> 404 Page Not Found: Product/reselling-course-without-paid-ads
DEBUG - 2022-05-31 22:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 22:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 22:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 22:52:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 22:52:37 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-05-31 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:01:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-31 23:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:01:58 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:02:05 --> 404 Page Not Found: Category/health
DEBUG - 2022-05-31 23:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:04:15 --> 404 Page Not Found: Category/culture
DEBUG - 2022-05-31 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:06:24 --> 404 Page Not Found: Well-known/traffic-advice
ERROR - 2022-05-31 23:06:24 --> 404 Page Not Found: Well-known/traffic-advice
DEBUG - 2022-05-31 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:06:24 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:20 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:30 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:08:41 --> 404 Page Not Found: Login/index
DEBUG - 2022-05-31 23:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:12:53 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:13:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:13:50 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:14:00 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:14:04 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:01 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:37 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:18:36 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:20:12 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-05-31 23:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:23:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:23:52 --> 404 Page Not Found: Author/admin
DEBUG - 2022-05-31 23:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:34:35 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:37:33 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:39:22 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-05-31 23:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:28 --> No URI present. Default controller set.
DEBUG - 2022-05-31 23:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:47:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-31 23:47:59 --> 404 Page Not Found: Courses/index
DEBUG - 2022-05-31 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-31 23:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-31 23:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-31 23:52:21 --> Encryption: Auto-configured driver 'openssl'.
