<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-09 00:01:49 --> Total execution time: 0.1059
DEBUG - 2022-08-09 00:03:19 --> Total execution time: 0.0761
DEBUG - 2022-08-09 00:03:38 --> Total execution time: 0.0898
DEBUG - 2022-08-09 00:03:46 --> Total execution time: 0.1107
DEBUG - 2022-08-09 00:04:06 --> Total execution time: 0.0865
DEBUG - 2022-08-09 00:14:10 --> Total execution time: 0.1926
DEBUG - 2022-08-09 00:14:51 --> Total execution time: 0.0779
DEBUG - 2022-08-09 00:15:01 --> Total execution time: 0.1026
DEBUG - 2022-08-09 00:16:56 --> Total execution time: 0.0783
DEBUG - 2022-08-09 00:17:14 --> Total execution time: 0.0736
DEBUG - 2022-08-09 00:17:15 --> Total execution time: 0.0855
DEBUG - 2022-08-09 00:17:25 --> Total execution time: 0.1014
DEBUG - 2022-08-09 00:17:26 --> Total execution time: 0.0985
DEBUG - 2022-08-09 00:17:36 --> Total execution time: 0.0787
DEBUG - 2022-08-09 00:18:27 --> Total execution time: 0.0808
DEBUG - 2022-08-09 00:18:40 --> Total execution time: 0.0856
DEBUG - 2022-08-09 00:28:57 --> Total execution time: 0.1555
DEBUG - 2022-08-09 00:29:26 --> Total execution time: 0.0796
DEBUG - 2022-08-09 00:29:31 --> Total execution time: 0.1137
DEBUG - 2022-08-09 00:29:41 --> Total execution time: 0.0536
DEBUG - 2022-08-09 00:29:41 --> Total execution time: 0.0490
DEBUG - 2022-08-09 00:29:43 --> Total execution time: 0.0764
DEBUG - 2022-08-09 00:29:54 --> Total execution time: 0.0512
DEBUG - 2022-08-09 00:30:02 --> Total execution time: 0.3506
DEBUG - 2022-08-09 00:35:37 --> Total execution time: 0.1566
DEBUG - 2022-08-09 00:36:20 --> Total execution time: 0.0572
DEBUG - 2022-08-09 00:37:34 --> Total execution time: 0.2688
DEBUG - 2022-08-09 00:41:38 --> Total execution time: 0.1194
DEBUG - 2022-08-09 00:42:23 --> Total execution time: 0.0563
DEBUG - 2022-08-09 00:44:37 --> Total execution time: 0.2417
DEBUG - 2022-08-09 00:44:40 --> Total execution time: 0.0819
DEBUG - 2022-08-09 00:44:43 --> Total execution time: 0.1146
DEBUG - 2022-08-09 00:45:22 --> Total execution time: 0.1828
DEBUG - 2022-08-09 00:45:49 --> Total execution time: 0.0883
DEBUG - 2022-08-09 00:45:52 --> Total execution time: 0.0732
DEBUG - 2022-08-09 00:53:17 --> Total execution time: 0.2712
DEBUG - 2022-08-09 00:53:23 --> Total execution time: 0.0910
DEBUG - 2022-08-09 00:53:26 --> Total execution time: 0.0832
DEBUG - 2022-08-09 00:53:28 --> Total execution time: 0.0849
DEBUG - 2022-08-09 00:56:36 --> Total execution time: 0.1095
DEBUG - 2022-08-09 01:07:22 --> Total execution time: 0.1263
DEBUG - 2022-08-09 01:07:30 --> Total execution time: 0.0761
DEBUG - 2022-08-09 01:11:16 --> Total execution time: 0.1075
DEBUG - 2022-08-09 01:12:35 --> Total execution time: 0.0500
DEBUG - 2022-08-09 01:26:13 --> Total execution time: 0.1211
DEBUG - 2022-08-09 01:30:02 --> Total execution time: 0.1213
DEBUG - 2022-08-09 01:30:49 --> Total execution time: 0.1937
DEBUG - 2022-08-09 01:33:51 --> Total execution time: 0.0984
DEBUG - 2022-08-09 01:35:59 --> Total execution time: 0.0988
DEBUG - 2022-08-09 01:36:00 --> Total execution time: 0.0839
DEBUG - 2022-08-09 01:37:36 --> Total execution time: 0.0508
DEBUG - 2022-08-09 01:44:23 --> Total execution time: 0.2489
DEBUG - 2022-08-09 01:56:35 --> Total execution time: 0.1442
DEBUG - 2022-08-09 02:00:43 --> Total execution time: 0.1186
DEBUG - 2022-08-09 02:02:57 --> Total execution time: 0.1002
DEBUG - 2022-08-09 02:04:59 --> Total execution time: 0.1410
DEBUG - 2022-08-09 02:05:01 --> Total execution time: 0.0959
DEBUG - 2022-08-09 02:05:02 --> Total execution time: 0.0859
DEBUG - 2022-08-09 02:29:30 --> Total execution time: 0.2420
DEBUG - 2022-08-09 02:30:03 --> Total execution time: 0.0740
DEBUG - 2022-08-09 02:32:45 --> Total execution time: 0.1044
DEBUG - 2022-08-09 02:32:49 --> Total execution time: 0.0781
DEBUG - 2022-08-09 02:33:00 --> Total execution time: 0.1097
DEBUG - 2022-08-09 02:33:05 --> Total execution time: 0.1313
DEBUG - 2022-08-09 02:33:16 --> Total execution time: 0.0785
DEBUG - 2022-08-09 02:41:20 --> Total execution time: 0.2630
DEBUG - 2022-08-09 02:44:40 --> Total execution time: 0.1243
DEBUG - 2022-08-09 03:27:07 --> Total execution time: 0.2994
DEBUG - 2022-08-09 03:30:03 --> Total execution time: 0.1109
DEBUG - 2022-08-09 03:49:31 --> Total execution time: 0.1288
DEBUG - 2022-08-09 03:49:32 --> Total execution time: 0.0515
DEBUG - 2022-08-09 03:49:34 --> Total execution time: 0.0777
DEBUG - 2022-08-09 03:49:37 --> Total execution time: 0.0816
DEBUG - 2022-08-09 03:49:38 --> Total execution time: 0.2361
DEBUG - 2022-08-09 03:49:39 --> Total execution time: 0.0761
DEBUG - 2022-08-09 03:49:40 --> Total execution time: 0.4252
DEBUG - 2022-08-09 03:49:41 --> Total execution time: 0.0826
DEBUG - 2022-08-09 03:49:42 --> Total execution time: 0.0764
DEBUG - 2022-08-09 03:49:44 --> Total execution time: 0.0781
DEBUG - 2022-08-09 03:49:45 --> Total execution time: 0.0756
DEBUG - 2022-08-09 03:49:46 --> Total execution time: 0.0849
DEBUG - 2022-08-09 03:49:47 --> Total execution time: 0.0538
DEBUG - 2022-08-09 03:49:54 --> Total execution time: 0.0518
DEBUG - 2022-08-09 03:55:59 --> Total execution time: 0.0954
DEBUG - 2022-08-09 03:56:00 --> Total execution time: 0.0734
DEBUG - 2022-08-09 04:30:03 --> Total execution time: 0.6255
DEBUG - 2022-08-09 04:32:46 --> Total execution time: 0.1117
DEBUG - 2022-08-09 04:37:51 --> Total execution time: 0.0754
DEBUG - 2022-08-09 04:38:30 --> Total execution time: 0.0513
DEBUG - 2022-08-09 04:38:47 --> Total execution time: 0.0756
DEBUG - 2022-08-09 04:39:15 --> Total execution time: 0.1136
DEBUG - 2022-08-09 04:39:23 --> Total execution time: 0.1034
DEBUG - 2022-08-09 04:39:27 --> Total execution time: 0.0977
DEBUG - 2022-08-09 04:39:55 --> Total execution time: 0.0835
DEBUG - 2022-08-09 04:40:07 --> Total execution time: 0.0676
DEBUG - 2022-08-09 04:40:17 --> Total execution time: 0.0822
DEBUG - 2022-08-09 04:40:24 --> Total execution time: 0.0753
DEBUG - 2022-08-09 04:40:37 --> Total execution time: 0.0717
DEBUG - 2022-08-09 04:40:48 --> Total execution time: 0.0757
DEBUG - 2022-08-09 04:41:12 --> Total execution time: 0.1133
DEBUG - 2022-08-09 04:41:17 --> Total execution time: 0.0718
DEBUG - 2022-08-09 04:41:43 --> Total execution time: 0.0813
DEBUG - 2022-08-09 04:41:46 --> Total execution time: 0.0509
DEBUG - 2022-08-09 04:41:55 --> Total execution time: 0.1104
DEBUG - 2022-08-09 04:41:56 --> Total execution time: 0.1006
DEBUG - 2022-08-09 04:42:19 --> Total execution time: 0.0836
DEBUG - 2022-08-09 04:42:23 --> Total execution time: 0.0844
DEBUG - 2022-08-09 04:46:18 --> Total execution time: 0.1320
DEBUG - 2022-08-09 04:46:28 --> Total execution time: 0.0757
DEBUG - 2022-08-09 04:47:43 --> Total execution time: 0.0520
DEBUG - 2022-08-09 04:51:07 --> Total execution time: 0.1260
DEBUG - 2022-08-09 04:54:02 --> Total execution time: 0.1361
DEBUG - 2022-08-09 04:56:27 --> Total execution time: 0.2406
DEBUG - 2022-08-09 04:56:52 --> Total execution time: 0.0697
DEBUG - 2022-08-09 04:57:43 --> Total execution time: 0.1083
DEBUG - 2022-08-09 04:58:02 --> Total execution time: 0.0989
DEBUG - 2022-08-09 04:58:08 --> Total execution time: 0.0877
DEBUG - 2022-08-09 04:58:16 --> Total execution time: 0.0850
DEBUG - 2022-08-09 04:58:34 --> Total execution time: 0.0810
DEBUG - 2022-08-09 04:58:48 --> Total execution time: 0.0808
DEBUG - 2022-08-09 05:11:38 --> Total execution time: 0.1124
DEBUG - 2022-08-09 05:15:40 --> Total execution time: 0.1136
DEBUG - 2022-08-09 05:20:22 --> Total execution time: 0.1066
DEBUG - 2022-08-09 05:20:22 --> Total execution time: 0.0506
DEBUG - 2022-08-09 05:22:59 --> Total execution time: 0.2335
DEBUG - 2022-08-09 05:30:02 --> Total execution time: 0.1341
DEBUG - 2022-08-09 05:37:41 --> Total execution time: 0.1355
DEBUG - 2022-08-09 05:52:26 --> Total execution time: 0.1622
DEBUG - 2022-08-09 05:55:57 --> Total execution time: 0.0897
DEBUG - 2022-08-09 05:56:55 --> Total execution time: 0.0530
DEBUG - 2022-08-09 05:57:21 --> Total execution time: 0.0828
DEBUG - 2022-08-09 06:01:27 --> Total execution time: 0.0775
DEBUG - 2022-08-09 06:07:24 --> Total execution time: 0.1025
DEBUG - 2022-08-09 06:13:17 --> Total execution time: 0.1558
DEBUG - 2022-08-09 06:16:49 --> Total execution time: 0.1165
DEBUG - 2022-08-09 06:16:51 --> Total execution time: 0.0732
DEBUG - 2022-08-09 06:17:15 --> Total execution time: 0.0568
DEBUG - 2022-08-09 06:17:18 --> Total execution time: 0.0710
DEBUG - 2022-08-09 06:17:35 --> Total execution time: 0.1186
DEBUG - 2022-08-09 06:17:46 --> Total execution time: 0.1000
DEBUG - 2022-08-09 06:17:49 --> Total execution time: 0.0982
DEBUG - 2022-08-09 06:17:56 --> Total execution time: 0.0797
DEBUG - 2022-08-09 06:18:01 --> Total execution time: 0.1123
DEBUG - 2022-08-09 06:18:07 --> Total execution time: 0.0854
DEBUG - 2022-08-09 06:30:03 --> Total execution time: 0.1291
DEBUG - 2022-08-09 06:31:41 --> Total execution time: 0.0853
DEBUG - 2022-08-09 06:31:47 --> Total execution time: 0.1067
DEBUG - 2022-08-09 06:31:51 --> Total execution time: 0.0840
DEBUG - 2022-08-09 06:32:25 --> Total execution time: 0.0576
DEBUG - 2022-08-09 06:41:49 --> Total execution time: 0.5105
DEBUG - 2022-08-09 06:41:52 --> Total execution time: 0.0889
DEBUG - 2022-08-09 06:42:01 --> Total execution time: 0.1253
DEBUG - 2022-08-09 06:48:14 --> Total execution time: 0.1411
DEBUG - 2022-08-09 06:51:10 --> Total execution time: 0.1139
DEBUG - 2022-08-09 06:55:31 --> Total execution time: 0.0782
DEBUG - 2022-08-09 06:57:39 --> Total execution time: 0.0750
DEBUG - 2022-08-09 07:03:22 --> Total execution time: 0.1337
DEBUG - 2022-08-09 07:06:47 --> Total execution time: 0.0750
DEBUG - 2022-08-09 07:06:49 --> Total execution time: 0.0680
DEBUG - 2022-08-09 07:07:21 --> Total execution time: 0.1482
DEBUG - 2022-08-09 07:07:28 --> Total execution time: 0.1201
DEBUG - 2022-08-09 07:08:15 --> Total execution time: 0.0793
DEBUG - 2022-08-09 07:08:41 --> Total execution time: 0.0791
DEBUG - 2022-08-09 07:08:51 --> Total execution time: 0.0771
DEBUG - 2022-08-09 07:09:01 --> Total execution time: 0.0768
DEBUG - 2022-08-09 07:09:16 --> Total execution time: 0.0768
DEBUG - 2022-08-09 07:09:20 --> Total execution time: 0.0804
DEBUG - 2022-08-09 07:09:26 --> Total execution time: 0.0866
DEBUG - 2022-08-09 07:09:50 --> Total execution time: 0.0802
DEBUG - 2022-08-09 07:09:53 --> Total execution time: 0.1043
DEBUG - 2022-08-09 07:10:01 --> Total execution time: 0.1289
DEBUG - 2022-08-09 07:10:10 --> Total execution time: 0.2010
DEBUG - 2022-08-09 07:10:15 --> Total execution time: 0.1000
DEBUG - 2022-08-09 07:10:19 --> Total execution time: 0.0868
DEBUG - 2022-08-09 07:10:25 --> Total execution time: 0.0816
DEBUG - 2022-08-09 07:10:28 --> Total execution time: 0.0914
DEBUG - 2022-08-09 07:10:32 --> Total execution time: 0.0934
DEBUG - 2022-08-09 07:10:34 --> Total execution time: 0.0868
DEBUG - 2022-08-09 07:10:43 --> Total execution time: 0.0764
DEBUG - 2022-08-09 07:11:36 --> Total execution time: 0.0886
DEBUG - 2022-08-09 07:11:37 --> Total execution time: 0.0760
DEBUG - 2022-08-09 07:12:02 --> Total execution time: 0.1156
DEBUG - 2022-08-09 07:16:37 --> Total execution time: 0.1105
DEBUG - 2022-08-09 07:16:51 --> Total execution time: 0.0751
DEBUG - 2022-08-09 07:17:01 --> Total execution time: 0.0901
DEBUG - 2022-08-09 07:17:07 --> Total execution time: 0.0993
DEBUG - 2022-08-09 07:17:16 --> Total execution time: 0.0782
DEBUG - 2022-08-09 07:17:19 --> Total execution time: 0.0848
DEBUG - 2022-08-09 07:17:22 --> Total execution time: 0.0822
DEBUG - 2022-08-09 07:19:42 --> Total execution time: 0.0971
DEBUG - 2022-08-09 07:22:50 --> Total execution time: 0.2878
DEBUG - 2022-08-09 07:23:15 --> Total execution time: 0.0914
DEBUG - 2022-08-09 07:24:13 --> Total execution time: 0.0547
DEBUG - 2022-08-09 07:27:29 --> Total execution time: 0.1231
DEBUG - 2022-08-09 07:28:23 --> Total execution time: 0.0750
DEBUG - 2022-08-09 07:29:32 --> Total execution time: 0.0600
DEBUG - 2022-08-09 07:30:02 --> Total execution time: 0.1140
DEBUG - 2022-08-09 07:33:26 --> Total execution time: 0.3057
DEBUG - 2022-08-09 07:34:11 --> Total execution time: 0.0811
DEBUG - 2022-08-09 07:34:14 --> Total execution time: 0.1947
DEBUG - 2022-08-09 07:38:09 --> Total execution time: 0.1303
DEBUG - 2022-08-09 07:43:45 --> Total execution time: 0.2539
DEBUG - 2022-08-09 07:43:54 --> Total execution time: 0.0759
DEBUG - 2022-08-09 07:46:37 --> Total execution time: 0.1450
DEBUG - 2022-08-09 07:48:35 --> Total execution time: 0.2055
DEBUG - 2022-08-09 07:48:42 --> Total execution time: 0.0764
DEBUG - 2022-08-09 07:56:17 --> Total execution time: 0.1340
DEBUG - 2022-08-09 07:56:30 --> Total execution time: 0.0925
DEBUG - 2022-08-09 07:56:35 --> Total execution time: 0.1309
DEBUG - 2022-08-09 07:57:31 --> Total execution time: 0.0809
DEBUG - 2022-08-09 07:59:27 --> Total execution time: 0.0779
DEBUG - 2022-08-09 07:59:53 --> Total execution time: 0.2432
DEBUG - 2022-08-09 07:59:58 --> Total execution time: 0.0739
DEBUG - 2022-08-09 08:00:00 --> Total execution time: 0.0767
DEBUG - 2022-08-09 08:00:34 --> Total execution time: 0.0978
DEBUG - 2022-08-09 08:00:54 --> Total execution time: 0.0778
DEBUG - 2022-08-09 08:01:00 --> Total execution time: 0.1232
DEBUG - 2022-08-09 08:01:08 --> Total execution time: 0.1605
DEBUG - 2022-08-09 08:02:37 --> Total execution time: 0.1202
DEBUG - 2022-08-09 08:05:04 --> Total execution time: 0.1124
DEBUG - 2022-08-09 08:05:10 --> Total execution time: 0.0586
DEBUG - 2022-08-09 08:05:17 --> Total execution time: 0.0974
DEBUG - 2022-08-09 08:05:21 --> Total execution time: 0.0995
DEBUG - 2022-08-09 08:05:40 --> Total execution time: 0.1321
DEBUG - 2022-08-09 08:06:00 --> Total execution time: 0.0854
DEBUG - 2022-08-09 08:06:29 --> Total execution time: 0.1455
DEBUG - 2022-08-09 08:06:38 --> Total execution time: 0.1548
DEBUG - 2022-08-09 08:06:42 --> Total execution time: 0.1028
DEBUG - 2022-08-09 08:07:05 --> Total execution time: 0.0871
DEBUG - 2022-08-09 08:10:11 --> Total execution time: 0.1083
DEBUG - 2022-08-09 08:10:27 --> Total execution time: 0.0812
DEBUG - 2022-08-09 08:11:25 --> Total execution time: 0.0764
DEBUG - 2022-08-09 08:13:30 --> Total execution time: 0.1345
DEBUG - 2022-08-09 08:13:43 --> Total execution time: 0.0791
DEBUG - 2022-08-09 08:14:06 --> Total execution time: 0.0823
DEBUG - 2022-08-09 08:14:43 --> Total execution time: 0.0887
DEBUG - 2022-08-09 08:16:46 --> Total execution time: 0.0744
DEBUG - 2022-08-09 08:16:58 --> Total execution time: 0.0829
DEBUG - 2022-08-09 08:17:09 --> Total execution time: 0.0837
DEBUG - 2022-08-09 08:17:10 --> Total execution time: 0.1935
DEBUG - 2022-08-09 08:17:15 --> Total execution time: 0.1112
DEBUG - 2022-08-09 08:17:22 --> Total execution time: 0.0821
DEBUG - 2022-08-09 08:17:25 --> Total execution time: 0.0786
DEBUG - 2022-08-09 08:17:29 --> Total execution time: 0.0847
DEBUG - 2022-08-09 08:17:36 --> Total execution time: 0.0739
DEBUG - 2022-08-09 08:18:31 --> Total execution time: 0.0756
DEBUG - 2022-08-09 08:19:14 --> Total execution time: 0.0570
DEBUG - 2022-08-09 08:19:42 --> Total execution time: 0.1010
DEBUG - 2022-08-09 08:19:59 --> Total execution time: 0.0949
DEBUG - 2022-08-09 08:20:13 --> Total execution time: 0.0944
DEBUG - 2022-08-09 08:20:18 --> Total execution time: 0.0873
DEBUG - 2022-08-09 08:20:26 --> Total execution time: 0.0738
DEBUG - 2022-08-09 08:20:33 --> Total execution time: 0.0493
DEBUG - 2022-08-09 08:22:43 --> Total execution time: 0.1261
DEBUG - 2022-08-09 08:23:17 --> Total execution time: 0.0559
DEBUG - 2022-08-09 08:24:52 --> Total execution time: 0.0710
DEBUG - 2022-08-09 08:25:21 --> Total execution time: 0.0905
DEBUG - 2022-08-09 08:25:34 --> Total execution time: 0.0833
DEBUG - 2022-08-09 08:25:46 --> Total execution time: 0.0504
DEBUG - 2022-08-09 08:27:03 --> Total execution time: 0.0870
DEBUG - 2022-08-09 08:27:05 --> Total execution time: 0.0771
DEBUG - 2022-08-09 08:27:17 --> Total execution time: 0.0539
DEBUG - 2022-08-09 08:29:09 --> Total execution time: 0.2032
DEBUG - 2022-08-09 08:30:02 --> Total execution time: 0.0789
DEBUG - 2022-08-09 08:30:12 --> Total execution time: 1.9887
DEBUG - 2022-08-09 08:32:15 --> Total execution time: 0.1067
DEBUG - 2022-08-09 08:34:16 --> Total execution time: 0.0522
DEBUG - 2022-08-09 08:34:30 --> Total execution time: 0.0935
DEBUG - 2022-08-09 08:34:49 --> Total execution time: 0.2534
DEBUG - 2022-08-09 08:35:04 --> Total execution time: 0.0936
DEBUG - 2022-08-09 08:35:27 --> Total execution time: 0.2152
DEBUG - 2022-08-09 08:35:33 --> Total execution time: 0.0867
DEBUG - 2022-08-09 08:35:33 --> Total execution time: 0.0950
DEBUG - 2022-08-09 08:35:34 --> Total execution time: 0.0810
DEBUG - 2022-08-09 08:35:43 --> Total execution time: 0.0826
DEBUG - 2022-08-09 08:35:49 --> Total execution time: 0.1122
DEBUG - 2022-08-09 08:35:53 --> Total execution time: 0.0827
DEBUG - 2022-08-09 08:35:55 --> Total execution time: 0.0980
DEBUG - 2022-08-09 08:36:03 --> Total execution time: 0.0934
DEBUG - 2022-08-09 08:36:05 --> Total execution time: 0.0647
DEBUG - 2022-08-09 08:36:06 --> Total execution time: 0.0916
DEBUG - 2022-08-09 08:36:12 --> Total execution time: 0.0754
DEBUG - 2022-08-09 08:36:16 --> Total execution time: 0.0817
DEBUG - 2022-08-09 08:38:37 --> Total execution time: 0.1443
DEBUG - 2022-08-09 08:38:40 --> Total execution time: 0.0497
DEBUG - 2022-08-09 08:38:42 --> Total execution time: 0.0762
DEBUG - 2022-08-09 08:39:24 --> Total execution time: 0.0797
DEBUG - 2022-08-09 08:41:20 --> Total execution time: 0.0526
DEBUG - 2022-08-09 08:41:58 --> Total execution time: 0.0869
DEBUG - 2022-08-09 08:42:17 --> Total execution time: 0.0742
DEBUG - 2022-08-09 08:42:20 --> Total execution time: 0.0846
DEBUG - 2022-08-09 08:42:20 --> Total execution time: 0.0937
DEBUG - 2022-08-09 08:42:23 --> Total execution time: 0.1025
DEBUG - 2022-08-09 08:42:36 --> Total execution time: 0.0840
DEBUG - 2022-08-09 08:42:39 --> Total execution time: 0.0751
DEBUG - 2022-08-09 08:42:44 --> Total execution time: 0.2054
DEBUG - 2022-08-09 08:42:45 --> Total execution time: 0.1036
DEBUG - 2022-08-09 08:42:55 --> Total execution time: 0.1086
DEBUG - 2022-08-09 08:43:00 --> Total execution time: 0.0813
DEBUG - 2022-08-09 08:43:04 --> Total execution time: 0.0809
DEBUG - 2022-08-09 08:43:11 --> Total execution time: 0.0759
DEBUG - 2022-08-09 08:43:16 --> Total execution time: 0.0871
DEBUG - 2022-08-09 08:43:36 --> Total execution time: 0.0508
DEBUG - 2022-08-09 08:43:44 --> Total execution time: 0.0904
DEBUG - 2022-08-09 08:43:57 --> Total execution time: 0.0894
DEBUG - 2022-08-09 08:44:03 --> Total execution time: 0.0821
DEBUG - 2022-08-09 08:44:11 --> Total execution time: 0.0748
DEBUG - 2022-08-09 08:44:18 --> Total execution time: 0.0500
DEBUG - 2022-08-09 08:44:23 --> Total execution time: 0.0485
DEBUG - 2022-08-09 08:44:59 --> Total execution time: 0.0783
DEBUG - 2022-08-09 08:45:15 --> Total execution time: 0.0487
DEBUG - 2022-08-09 08:46:58 --> Total execution time: 0.0509
DEBUG - 2022-08-09 08:49:46 --> Total execution time: 0.1336
DEBUG - 2022-08-09 08:51:30 --> Total execution time: 0.0618
DEBUG - 2022-08-09 08:51:32 --> Total execution time: 0.0496
DEBUG - 2022-08-09 08:52:40 --> Total execution time: 0.0829
DEBUG - 2022-08-09 08:52:41 --> Total execution time: 0.0922
DEBUG - 2022-08-09 08:52:56 --> Total execution time: 0.0504
DEBUG - 2022-08-09 08:53:46 --> Total execution time: 0.0735
DEBUG - 2022-08-09 08:53:54 --> Total execution time: 0.0477
DEBUG - 2022-08-09 08:54:03 --> Total execution time: 0.0809
DEBUG - 2022-08-09 08:54:17 --> Total execution time: 0.0863
DEBUG - 2022-08-09 08:54:21 --> Total execution time: 0.0867
DEBUG - 2022-08-09 08:54:31 --> Total execution time: 0.0750
DEBUG - 2022-08-09 08:57:13 --> Total execution time: 0.0973
DEBUG - 2022-08-09 08:58:11 --> Total execution time: 0.0490
DEBUG - 2022-08-09 09:01:38 --> Total execution time: 0.2463
DEBUG - 2022-08-09 09:01:45 --> Total execution time: 0.1208
DEBUG - 2022-08-09 09:01:49 --> Total execution time: 0.0841
DEBUG - 2022-08-09 09:02:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:02:29 --> Total execution time: 0.0830
DEBUG - 2022-08-09 09:04:34 --> Total execution time: 0.0750
DEBUG - 2022-08-09 09:05:35 --> Total execution time: 0.0932
DEBUG - 2022-08-09 09:10:27 --> Total execution time: 0.2935
DEBUG - 2022-08-09 09:10:34 --> Total execution time: 0.0858
DEBUG - 2022-08-09 09:11:09 --> Total execution time: 0.0712
DEBUG - 2022-08-09 09:11:50 --> Total execution time: 0.1983
DEBUG - 2022-08-09 09:11:57 --> Total execution time: 0.0965
DEBUG - 2022-08-09 09:12:42 --> Total execution time: 0.1181
DEBUG - 2022-08-09 09:13:26 --> Total execution time: 0.0791
DEBUG - 2022-08-09 09:13:44 --> Total execution time: 0.0884
DEBUG - 2022-08-09 09:14:15 --> Total execution time: 0.1125
DEBUG - 2022-08-09 09:14:28 --> Total execution time: 0.1079
DEBUG - 2022-08-09 09:14:29 --> Total execution time: 0.0843
DEBUG - 2022-08-09 09:14:40 --> Total execution time: 0.1409
DEBUG - 2022-08-09 09:14:58 --> Total execution time: 0.0888
DEBUG - 2022-08-09 09:14:59 --> Total execution time: 0.0835
DEBUG - 2022-08-09 09:15:21 --> Total execution time: 0.0836
DEBUG - 2022-08-09 09:15:37 --> Total execution time: 0.0911
DEBUG - 2022-08-09 09:15:49 --> Total execution time: 0.0685
DEBUG - 2022-08-09 09:15:51 --> Total execution time: 0.0898
DEBUG - 2022-08-09 09:15:53 --> Total execution time: 0.0749
DEBUG - 2022-08-09 09:15:54 --> Total execution time: 0.0733
DEBUG - 2022-08-09 09:15:59 --> Total execution time: 0.0720
DEBUG - 2022-08-09 09:16:02 --> Total execution time: 0.0983
DEBUG - 2022-08-09 09:16:18 --> Total execution time: 0.0819
DEBUG - 2022-08-09 09:16:26 --> Total execution time: 0.0554
DEBUG - 2022-08-09 09:16:26 --> Total execution time: 0.0775
DEBUG - 2022-08-09 09:16:34 --> Total execution time: 0.1056
DEBUG - 2022-08-09 09:16:34 --> Total execution time: 0.0538
DEBUG - 2022-08-09 09:16:39 --> Total execution time: 0.0861
DEBUG - 2022-08-09 09:16:44 --> Total execution time: 0.1964
DEBUG - 2022-08-09 09:16:50 --> Total execution time: 0.0772
DEBUG - 2022-08-09 09:16:53 --> Total execution time: 0.2592
DEBUG - 2022-08-09 09:17:03 --> Total execution time: 0.1052
DEBUG - 2022-08-09 09:17:16 --> Total execution time: 0.0820
DEBUG - 2022-08-09 09:17:36 --> Total execution time: 0.0949
DEBUG - 2022-08-09 09:17:39 --> Total execution time: 0.0822
DEBUG - 2022-08-09 09:17:44 --> Total execution time: 0.2155
DEBUG - 2022-08-09 09:17:54 --> Total execution time: 0.0764
DEBUG - 2022-08-09 09:17:56 --> Total execution time: 0.1042
DEBUG - 2022-08-09 09:18:00 --> Total execution time: 0.0875
DEBUG - 2022-08-09 09:18:23 --> Total execution time: 0.0780
DEBUG - 2022-08-09 09:18:28 --> Total execution time: 0.0810
DEBUG - 2022-08-09 09:18:33 --> Total execution time: 0.0517
DEBUG - 2022-08-09 09:18:41 --> Total execution time: 0.0991
DEBUG - 2022-08-09 09:18:44 --> Total execution time: 0.1213
DEBUG - 2022-08-09 09:18:58 --> Total execution time: 0.1084
DEBUG - 2022-08-09 09:19:08 --> Total execution time: 0.0815
DEBUG - 2022-08-09 09:19:39 --> Total execution time: 0.0746
DEBUG - 2022-08-09 09:19:43 --> Total execution time: 0.0508
DEBUG - 2022-08-09 09:19:56 --> Total execution time: 0.0592
DEBUG - 2022-08-09 09:21:20 --> Total execution time: 0.0775
DEBUG - 2022-08-09 09:21:34 --> Total execution time: 0.0879
DEBUG - 2022-08-09 09:21:40 --> Total execution time: 0.0502
DEBUG - 2022-08-09 09:22:01 --> Total execution time: 0.0514
DEBUG - 2022-08-09 09:22:15 --> Total execution time: 0.0848
DEBUG - 2022-08-09 09:24:07 --> Total execution time: 0.0692
DEBUG - 2022-08-09 09:26:30 --> Total execution time: 0.1226
DEBUG - 2022-08-09 09:28:05 --> Total execution time: 0.0645
DEBUG - 2022-08-09 09:29:21 --> Total execution time: 0.1997
DEBUG - 2022-08-09 09:29:27 --> Total execution time: 0.0863
DEBUG - 2022-08-09 09:29:50 --> Total execution time: 0.1180
DEBUG - 2022-08-09 09:29:59 --> Total execution time: 0.1083
DEBUG - 2022-08-09 09:30:02 --> Total execution time: 0.1050
DEBUG - 2022-08-09 09:30:48 --> Total execution time: 0.1460
DEBUG - 2022-08-09 09:30:55 --> Total execution time: 0.0890
DEBUG - 2022-08-09 09:31:20 --> Total execution time: 0.1538
DEBUG - 2022-08-09 09:31:24 --> Total execution time: 0.0871
DEBUG - 2022-08-09 09:31:30 --> Total execution time: 0.0791
DEBUG - 2022-08-09 09:31:34 --> Total execution time: 0.0815
DEBUG - 2022-08-09 09:31:54 --> Total execution time: 0.0846
DEBUG - 2022-08-09 09:32:01 --> Total execution time: 0.0905
DEBUG - 2022-08-09 09:32:05 --> Total execution time: 0.0820
DEBUG - 2022-08-09 09:32:11 --> Total execution time: 0.1030
DEBUG - 2022-08-09 09:32:19 --> Total execution time: 0.1458
DEBUG - 2022-08-09 09:32:26 --> Total execution time: 0.0727
DEBUG - 2022-08-09 09:33:12 --> Total execution time: 0.0808
DEBUG - 2022-08-09 09:33:33 --> Total execution time: 0.0880
DEBUG - 2022-08-09 09:33:37 --> Total execution time: 0.1511
DEBUG - 2022-08-09 09:33:39 --> Total execution time: 0.0825
DEBUG - 2022-08-09 09:33:45 --> Total execution time: 0.0779
DEBUG - 2022-08-09 09:34:32 --> Total execution time: 0.0535
DEBUG - 2022-08-09 09:36:32 --> Total execution time: 0.0918
DEBUG - 2022-08-09 09:36:41 --> Total execution time: 0.0803
DEBUG - 2022-08-09 09:37:01 --> Total execution time: 0.1250
DEBUG - 2022-08-09 09:37:18 --> Total execution time: 0.1999
DEBUG - 2022-08-09 09:37:41 --> Total execution time: 0.0551
DEBUG - 2022-08-09 09:38:00 --> Total execution time: 0.0845
DEBUG - 2022-08-09 09:38:13 --> Total execution time: 0.0835
DEBUG - 2022-08-09 09:38:15 --> Total execution time: 0.1153
DEBUG - 2022-08-09 09:38:18 --> Total execution time: 0.0834
DEBUG - 2022-08-09 09:38:20 --> Total execution time: 0.0896
DEBUG - 2022-08-09 09:38:27 --> Total execution time: 0.0757
DEBUG - 2022-08-09 09:38:31 --> Total execution time: 0.1021
DEBUG - 2022-08-09 09:38:40 --> Total execution time: 0.1043
DEBUG - 2022-08-09 09:38:55 --> Total execution time: 0.1137
DEBUG - 2022-08-09 09:38:56 --> Total execution time: 0.1082
DEBUG - 2022-08-09 09:38:59 --> Total execution time: 0.1086
DEBUG - 2022-08-09 09:39:17 --> Total execution time: 0.1386
DEBUG - 2022-08-09 09:39:27 --> Total execution time: 0.0986
DEBUG - 2022-08-09 09:39:41 --> Total execution time: 0.1413
DEBUG - 2022-08-09 09:39:42 --> Total execution time: 0.0785
DEBUG - 2022-08-09 09:39:47 --> Total execution time: 0.1057
DEBUG - 2022-08-09 09:39:50 --> Total execution time: 0.2011
DEBUG - 2022-08-09 09:40:00 --> Total execution time: 0.0807
DEBUG - 2022-08-09 09:40:03 --> Total execution time: 0.1017
DEBUG - 2022-08-09 09:40:06 --> Total execution time: 0.0832
DEBUG - 2022-08-09 09:42:37 --> Total execution time: 0.2867
DEBUG - 2022-08-09 09:42:45 --> Total execution time: 0.0774
DEBUG - 2022-08-09 09:42:56 --> Total execution time: 0.0868
DEBUG - 2022-08-09 09:44:26 --> Total execution time: 0.0531
DEBUG - 2022-08-09 09:46:40 --> Total execution time: 0.0596
DEBUG - 2022-08-09 09:46:45 --> Total execution time: 0.0764
DEBUG - 2022-08-09 09:46:54 --> Total execution time: 0.0830
DEBUG - 2022-08-09 09:47:04 --> Total execution time: 0.1177
DEBUG - 2022-08-09 09:47:09 --> Total execution time: 0.0855
DEBUG - 2022-08-09 09:47:11 --> Total execution time: 0.1081
DEBUG - 2022-08-09 09:47:16 --> Total execution time: 0.0488
DEBUG - 2022-08-09 09:47:33 --> Total execution time: 0.0531
DEBUG - 2022-08-09 09:47:42 --> Total execution time: 0.1125
DEBUG - 2022-08-09 09:48:02 --> Total execution time: 0.0840
DEBUG - 2022-08-09 09:48:13 --> Total execution time: 0.0900
DEBUG - 2022-08-09 09:48:36 --> Total execution time: 0.0799
DEBUG - 2022-08-09 09:48:50 --> Total execution time: 0.0741
DEBUG - 2022-08-09 09:48:53 --> Total execution time: 0.2301
DEBUG - 2022-08-09 09:48:58 --> Total execution time: 0.1074
DEBUG - 2022-08-09 09:49:10 --> Total execution time: 0.0837
DEBUG - 2022-08-09 09:49:13 --> Total execution time: 0.1022
DEBUG - 2022-08-09 09:49:17 --> Total execution time: 0.0996
DEBUG - 2022-08-09 09:49:25 --> Total execution time: 0.1051
DEBUG - 2022-08-09 09:49:31 --> Total execution time: 0.1094
DEBUG - 2022-08-09 09:49:33 --> Total execution time: 0.0824
DEBUG - 2022-08-09 09:49:43 --> Total execution time: 0.0855
DEBUG - 2022-08-09 09:50:39 --> Total execution time: 0.0824
DEBUG - 2022-08-09 09:51:51 --> Total execution time: 0.1074
DEBUG - 2022-08-09 09:52:01 --> Total execution time: 0.1087
DEBUG - 2022-08-09 09:52:02 --> Total execution time: 0.1143
DEBUG - 2022-08-09 09:52:02 --> Total execution time: 0.0610
DEBUG - 2022-08-09 09:52:11 --> Total execution time: 0.0490
DEBUG - 2022-08-09 09:52:16 --> Total execution time: 0.0780
DEBUG - 2022-08-09 09:52:28 --> Total execution time: 0.0868
DEBUG - 2022-08-09 09:52:49 --> Total execution time: 0.0786
DEBUG - 2022-08-09 09:52:50 --> Total execution time: 0.0830
DEBUG - 2022-08-09 09:52:57 --> Total execution time: 0.1255
DEBUG - 2022-08-09 09:53:04 --> Total execution time: 0.0843
DEBUG - 2022-08-09 09:53:07 --> Total execution time: 0.1002
DEBUG - 2022-08-09 09:53:21 --> Total execution time: 0.0778
DEBUG - 2022-08-09 09:53:31 --> Total execution time: 0.1063
DEBUG - 2022-08-09 09:53:45 --> Total execution time: 0.1337
DEBUG - 2022-08-09 09:54:24 --> Total execution time: 2.1978
DEBUG - 2022-08-09 09:54:55 --> Total execution time: 1.6418
DEBUG - 2022-08-09 09:55:23 --> Total execution time: 0.0548
DEBUG - 2022-08-09 09:56:02 --> Total execution time: 0.0599
DEBUG - 2022-08-09 09:56:03 --> Total execution time: 0.0544
DEBUG - 2022-08-09 09:56:07 --> Total execution time: 0.0782
DEBUG - 2022-08-09 09:56:11 --> Total execution time: 0.1083
DEBUG - 2022-08-09 09:57:07 --> Total execution time: 0.0935
DEBUG - 2022-08-09 09:57:12 --> Total execution time: 0.0572
DEBUG - 2022-08-09 09:57:15 --> Total execution time: 0.2284
DEBUG - 2022-08-09 09:58:02 --> Total execution time: 0.2241
DEBUG - 2022-08-09 09:58:07 --> Total execution time: 0.0776
DEBUG - 2022-08-09 09:58:16 --> Total execution time: 0.0812
DEBUG - 2022-08-09 09:58:26 --> Total execution time: 0.1049
DEBUG - 2022-08-09 09:58:54 --> Total execution time: 0.1067
DEBUG - 2022-08-09 09:59:00 --> Total execution time: 0.0754
DEBUG - 2022-08-09 09:59:07 --> Total execution time: 0.0787
DEBUG - 2022-08-09 09:59:15 --> Total execution time: 0.1054
DEBUG - 2022-08-09 10:02:01 --> Total execution time: 0.1166
DEBUG - 2022-08-09 10:02:05 --> Total execution time: 0.0773
DEBUG - 2022-08-09 10:02:07 --> Total execution time: 0.0509
DEBUG - 2022-08-09 10:02:08 --> Total execution time: 0.0874
DEBUG - 2022-08-09 10:02:13 --> Total execution time: 0.0785
DEBUG - 2022-08-09 10:02:20 --> Total execution time: 0.0869
DEBUG - 2022-08-09 10:02:27 --> Total execution time: 0.1969
DEBUG - 2022-08-09 10:02:32 --> Total execution time: 0.0759
DEBUG - 2022-08-09 10:02:47 --> Total execution time: 0.0601
DEBUG - 2022-08-09 10:02:52 --> Total execution time: 0.2541
DEBUG - 2022-08-09 10:02:58 --> Total execution time: 0.1020
DEBUG - 2022-08-09 10:03:04 --> Total execution time: 0.0772
DEBUG - 2022-08-09 10:03:15 --> Total execution time: 0.0809
DEBUG - 2022-08-09 10:03:16 --> Total execution time: 0.1994
DEBUG - 2022-08-09 10:03:21 --> Total execution time: 0.0424
DEBUG - 2022-08-09 10:03:23 --> Total execution time: 0.0852
DEBUG - 2022-08-09 10:03:27 --> Total execution time: 0.0943
DEBUG - 2022-08-09 10:03:28 --> Total execution time: 0.0862
DEBUG - 2022-08-09 10:03:30 --> Total execution time: 0.1016
DEBUG - 2022-08-09 10:03:38 --> Total execution time: 0.1085
DEBUG - 2022-08-09 10:03:49 --> Total execution time: 0.0893
DEBUG - 2022-08-09 10:03:54 --> Total execution time: 0.0877
DEBUG - 2022-08-09 10:04:43 --> Total execution time: 0.0477
DEBUG - 2022-08-09 10:04:48 --> Total execution time: 0.0807
DEBUG - 2022-08-09 10:04:49 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:04:50 --> Total execution time: 0.0838
DEBUG - 2022-08-09 10:04:51 --> Total execution time: 0.0817
DEBUG - 2022-08-09 10:04:54 --> Total execution time: 0.1097
DEBUG - 2022-08-09 10:04:55 --> Total execution time: 0.0741
DEBUG - 2022-08-09 10:05:01 --> Total execution time: 0.1222
DEBUG - 2022-08-09 10:05:03 --> Total execution time: 0.0993
DEBUG - 2022-08-09 10:05:03 --> Total execution time: 0.0901
DEBUG - 2022-08-09 10:05:07 --> Total execution time: 0.1071
DEBUG - 2022-08-09 10:05:07 --> Total execution time: 0.0935
DEBUG - 2022-08-09 10:05:12 --> Total execution time: 0.1137
DEBUG - 2022-08-09 10:05:14 --> Total execution time: 0.1112
DEBUG - 2022-08-09 10:05:21 --> Total execution time: 0.0824
DEBUG - 2022-08-09 10:05:39 --> Total execution time: 0.0822
DEBUG - 2022-08-09 10:05:41 --> Total execution time: 0.0986
DEBUG - 2022-08-09 10:05:45 --> Total execution time: 0.1124
DEBUG - 2022-08-09 10:05:53 --> Total execution time: 0.1358
DEBUG - 2022-08-09 10:06:03 --> Total execution time: 0.1033
DEBUG - 2022-08-09 10:06:04 --> Total execution time: 0.0805
DEBUG - 2022-08-09 10:06:12 --> Total execution time: 0.0799
DEBUG - 2022-08-09 10:06:13 --> Total execution time: 0.0788
DEBUG - 2022-08-09 10:06:14 --> Total execution time: 0.0808
DEBUG - 2022-08-09 10:06:14 --> Total execution time: 0.1074
DEBUG - 2022-08-09 10:06:20 --> Total execution time: 0.0763
DEBUG - 2022-08-09 10:06:21 --> Total execution time: 0.0914
DEBUG - 2022-08-09 10:06:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:06:24 --> Total execution time: 0.1004
DEBUG - 2022-08-09 10:06:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:06:26 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:06:26 --> Total execution time: 0.2336
DEBUG - 2022-08-09 10:06:31 --> Total execution time: 0.0834
DEBUG - 2022-08-09 10:06:39 --> Total execution time: 0.1021
DEBUG - 2022-08-09 10:06:42 --> Total execution time: 0.1004
DEBUG - 2022-08-09 10:06:55 --> Total execution time: 0.0591
DEBUG - 2022-08-09 10:06:59 --> Total execution time: 0.1311
DEBUG - 2022-08-09 10:07:00 --> Total execution time: 0.0518
DEBUG - 2022-08-09 10:07:09 --> Total execution time: 0.1175
DEBUG - 2022-08-09 10:07:32 --> Total execution time: 0.1920
DEBUG - 2022-08-09 10:07:36 --> Total execution time: 0.0858
DEBUG - 2022-08-09 10:07:37 --> Total execution time: 0.1069
DEBUG - 2022-08-09 10:07:37 --> Total execution time: 0.0736
DEBUG - 2022-08-09 10:07:39 --> Total execution time: 0.1070
DEBUG - 2022-08-09 10:07:43 --> Total execution time: 0.0947
DEBUG - 2022-08-09 10:07:45 --> Total execution time: 0.1037
DEBUG - 2022-08-09 10:07:47 --> Total execution time: 0.0895
DEBUG - 2022-08-09 10:07:50 --> Total execution time: 0.1088
DEBUG - 2022-08-09 10:07:52 --> Total execution time: 0.1052
DEBUG - 2022-08-09 10:07:56 --> Total execution time: 0.0780
DEBUG - 2022-08-09 10:07:59 --> Total execution time: 0.1316
DEBUG - 2022-08-09 10:07:59 --> Total execution time: 0.1085
DEBUG - 2022-08-09 10:08:09 --> Total execution time: 0.0778
DEBUG - 2022-08-09 10:08:13 --> Total execution time: 0.1085
DEBUG - 2022-08-09 10:08:15 --> Total execution time: 0.2292
DEBUG - 2022-08-09 10:08:17 --> Total execution time: 0.1017
DEBUG - 2022-08-09 10:08:49 --> Total execution time: 0.1064
DEBUG - 2022-08-09 10:09:10 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:09:11 --> Total execution time: 0.1097
DEBUG - 2022-08-09 10:09:16 --> Total execution time: 0.1385
DEBUG - 2022-08-09 10:09:16 --> Total execution time: 0.1860
DEBUG - 2022-08-09 10:09:22 --> Total execution time: 0.1361
DEBUG - 2022-08-09 10:09:29 --> Total execution time: 0.1036
DEBUG - 2022-08-09 10:09:38 --> Total execution time: 0.1033
DEBUG - 2022-08-09 10:09:52 --> Total execution time: 0.0843
DEBUG - 2022-08-09 10:09:54 --> Total execution time: 0.1002
DEBUG - 2022-08-09 10:10:00 --> Total execution time: 0.1051
DEBUG - 2022-08-09 10:10:02 --> Total execution time: 0.1090
DEBUG - 2022-08-09 10:10:17 --> Total execution time: 0.0843
DEBUG - 2022-08-09 10:10:20 --> Total execution time: 0.0815
DEBUG - 2022-08-09 10:10:36 --> Total execution time: 0.0982
DEBUG - 2022-08-09 10:10:43 --> Total execution time: 0.0816
DEBUG - 2022-08-09 10:10:44 --> Total execution time: 0.0793
DEBUG - 2022-08-09 10:11:37 --> Total execution time: 0.2383
DEBUG - 2022-08-09 10:11:41 --> Total execution time: 0.0773
DEBUG - 2022-08-09 10:11:46 --> Total execution time: 0.0801
DEBUG - 2022-08-09 10:12:05 --> Total execution time: 0.1114
DEBUG - 2022-08-09 10:12:47 --> Total execution time: 0.2013
DEBUG - 2022-08-09 10:12:51 --> Total execution time: 0.0838
DEBUG - 2022-08-09 10:13:30 --> Total execution time: 0.1175
DEBUG - 2022-08-09 10:13:42 --> Total execution time: 0.2861
DEBUG - 2022-08-09 10:13:48 --> Total execution time: 0.0745
DEBUG - 2022-08-09 10:14:01 --> Total execution time: 0.1066
DEBUG - 2022-08-09 10:14:03 --> Total execution time: 0.1049
DEBUG - 2022-08-09 10:14:18 --> Total execution time: 0.1309
DEBUG - 2022-08-09 10:14:18 --> Total execution time: 0.0724
DEBUG - 2022-08-09 10:14:35 --> Total execution time: 0.0960
DEBUG - 2022-08-09 10:14:46 --> Total execution time: 0.0878
DEBUG - 2022-08-09 10:15:02 --> Total execution time: 0.0986
DEBUG - 2022-08-09 10:15:05 --> Total execution time: 0.0816
DEBUG - 2022-08-09 10:15:15 --> Total execution time: 0.0795
DEBUG - 2022-08-09 10:15:25 --> Total execution time: 0.0536
DEBUG - 2022-08-09 10:15:58 --> Total execution time: 0.0519
DEBUG - 2022-08-09 10:16:13 --> Total execution time: 0.0801
DEBUG - 2022-08-09 10:16:23 --> Total execution time: 0.0794
DEBUG - 2022-08-09 10:16:32 --> Total execution time: 0.0853
DEBUG - 2022-08-09 10:16:37 --> Total execution time: 0.0850
DEBUG - 2022-08-09 10:16:39 --> Total execution time: 0.0789
DEBUG - 2022-08-09 10:16:47 --> Total execution time: 0.1066
DEBUG - 2022-08-09 10:16:56 --> Total execution time: 0.0966
DEBUG - 2022-08-09 10:17:03 --> Total execution time: 0.0819
DEBUG - 2022-08-09 10:17:07 --> Total execution time: 0.1011
DEBUG - 2022-08-09 10:17:11 --> Total execution time: 0.1006
DEBUG - 2022-08-09 10:17:24 --> Total execution time: 0.0978
DEBUG - 2022-08-09 10:17:28 --> Total execution time: 0.1030
DEBUG - 2022-08-09 10:17:33 --> Total execution time: 0.1001
DEBUG - 2022-08-09 10:17:37 --> Total execution time: 0.1055
DEBUG - 2022-08-09 10:17:47 --> Total execution time: 0.1125
DEBUG - 2022-08-09 10:18:13 --> Total execution time: 0.0772
DEBUG - 2022-08-09 10:18:24 --> Total execution time: 0.0857
DEBUG - 2022-08-09 10:18:33 --> Total execution time: 0.1357
DEBUG - 2022-08-09 10:19:09 --> Total execution time: 0.0922
DEBUG - 2022-08-09 10:19:11 --> Total execution time: 0.2483
DEBUG - 2022-08-09 10:19:16 --> Total execution time: 0.0885
DEBUG - 2022-08-09 10:19:20 --> Total execution time: 0.0824
DEBUG - 2022-08-09 10:19:25 --> Total execution time: 0.0794
DEBUG - 2022-08-09 10:19:27 --> Total execution time: 0.0845
DEBUG - 2022-08-09 10:19:29 --> Total execution time: 0.0503
DEBUG - 2022-08-09 10:19:30 --> Total execution time: 0.0788
DEBUG - 2022-08-09 10:19:31 --> Total execution time: 0.0762
DEBUG - 2022-08-09 10:19:33 --> Total execution time: 0.0766
DEBUG - 2022-08-09 10:19:35 --> Total execution time: 0.0782
DEBUG - 2022-08-09 10:19:41 --> Total execution time: 0.0805
DEBUG - 2022-08-09 10:19:44 --> Total execution time: 0.0875
DEBUG - 2022-08-09 10:19:54 --> Total execution time: 0.0812
DEBUG - 2022-08-09 10:20:00 --> Total execution time: 0.0529
DEBUG - 2022-08-09 10:20:07 --> Total execution time: 0.0796
DEBUG - 2022-08-09 10:20:11 --> Total execution time: 0.0795
DEBUG - 2022-08-09 10:20:16 --> Total execution time: 0.0811
DEBUG - 2022-08-09 10:20:19 --> Total execution time: 0.0898
DEBUG - 2022-08-09 10:20:21 --> Total execution time: 0.0742
DEBUG - 2022-08-09 10:20:21 --> Total execution time: 0.0743
DEBUG - 2022-08-09 10:20:25 --> Total execution time: 0.0831
DEBUG - 2022-08-09 10:20:41 --> Total execution time: 0.1070
DEBUG - 2022-08-09 10:20:45 --> Total execution time: 0.0742
DEBUG - 2022-08-09 10:20:49 --> Total execution time: 0.1030
DEBUG - 2022-08-09 10:20:53 --> Total execution time: 1.3579
DEBUG - 2022-08-09 10:21:11 --> Total execution time: 0.0834
DEBUG - 2022-08-09 10:22:19 --> Total execution time: 0.0867
DEBUG - 2022-08-09 10:22:21 --> Total execution time: 0.0837
DEBUG - 2022-08-09 10:22:21 --> Total execution time: 0.0823
DEBUG - 2022-08-09 10:23:26 --> Total execution time: 0.2024
DEBUG - 2022-08-09 10:24:12 --> Total execution time: 0.0583
DEBUG - 2022-08-09 10:26:30 --> Total execution time: 0.1460
DEBUG - 2022-08-09 10:26:30 --> Total execution time: 0.0756
DEBUG - 2022-08-09 10:26:36 --> Total execution time: 0.0749
DEBUG - 2022-08-09 10:26:48 --> Total execution time: 0.0772
DEBUG - 2022-08-09 10:27:49 --> Total execution time: 0.0914
DEBUG - 2022-08-09 10:28:14 --> Total execution time: 0.0995
DEBUG - 2022-08-09 10:28:23 --> Total execution time: 0.0892
DEBUG - 2022-08-09 10:28:35 --> Total execution time: 0.0774
DEBUG - 2022-08-09 10:28:59 --> Total execution time: 0.1996
DEBUG - 2022-08-09 00:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:01 --> Total execution time: 0.1196
DEBUG - 2022-08-09 00:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:06 --> Total execution time: 0.1165
DEBUG - 2022-08-09 00:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:00:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:06 --> Total execution time: 0.1105
DEBUG - 2022-08-09 00:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:14 --> Total execution time: 0.0927
DEBUG - 2022-08-09 00:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:18 --> Total execution time: 0.0886
DEBUG - 2022-08-09 00:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:32:12 --> Total execution time: 0.0752
DEBUG - 2022-08-09 00:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:02:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:32:34 --> Total execution time: 0.0514
DEBUG - 2022-08-09 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:28 --> Total execution time: 0.1949
DEBUG - 2022-08-09 00:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:03:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:31 --> Total execution time: 0.2107
DEBUG - 2022-08-09 00:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:33 --> Total execution time: 0.1324
DEBUG - 2022-08-09 00:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:46 --> Total execution time: 0.0802
DEBUG - 2022-08-09 00:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:57 --> Total execution time: 0.1125
DEBUG - 2022-08-09 00:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:00 --> Total execution time: 0.0787
DEBUG - 2022-08-09 00:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:10 --> Total execution time: 0.1828
DEBUG - 2022-08-09 00:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:13 --> Total execution time: 0.0965
DEBUG - 2022-08-09 00:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:24 --> Total execution time: 0.0574
DEBUG - 2022-08-09 00:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:24 --> Total execution time: 0.0839
DEBUG - 2022-08-09 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:28 --> Total execution time: 0.0913
DEBUG - 2022-08-09 00:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:28 --> Total execution time: 0.0507
DEBUG - 2022-08-09 00:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:41 --> Total execution time: 0.0987
DEBUG - 2022-08-09 00:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:42 --> Total execution time: 0.0983
DEBUG - 2022-08-09 00:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:34:48 --> Total execution time: 0.1204
DEBUG - 2022-08-09 00:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:35:04 --> Total execution time: 0.0941
DEBUG - 2022-08-09 00:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:35:09 --> Total execution time: 0.1555
DEBUG - 2022-08-09 00:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:05:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:35:42 --> Total execution time: 0.0567
DEBUG - 2022-08-09 00:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:31 --> Total execution time: 0.0901
DEBUG - 2022-08-09 00:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:41 --> Total execution time: 0.0525
DEBUG - 2022-08-09 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:47 --> Total execution time: 0.1084
DEBUG - 2022-08-09 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:55 --> Total execution time: 0.0837
DEBUG - 2022-08-09 00:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:56 --> Total execution time: 0.0742
DEBUG - 2022-08-09 00:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:01 --> Total execution time: 0.2001
DEBUG - 2022-08-09 00:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:05 --> Total execution time: 0.0950
DEBUG - 2022-08-09 00:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:06 --> Total execution time: 0.0756
DEBUG - 2022-08-09 00:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:07 --> Total execution time: 0.0902
DEBUG - 2022-08-09 00:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:09 --> Total execution time: 0.0796
DEBUG - 2022-08-09 00:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:11 --> Total execution time: 0.0891
DEBUG - 2022-08-09 00:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:13 --> Total execution time: 0.0799
DEBUG - 2022-08-09 00:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:16 --> Total execution time: 0.0965
DEBUG - 2022-08-09 00:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:29 --> Total execution time: 0.0970
DEBUG - 2022-08-09 00:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:39 --> Total execution time: 0.0946
DEBUG - 2022-08-09 00:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:40 --> Total execution time: 0.0796
DEBUG - 2022-08-09 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:43 --> Total execution time: 0.1582
DEBUG - 2022-08-09 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:04 --> Total execution time: 0.0841
DEBUG - 2022-08-09 00:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:13 --> Total execution time: 0.0880
DEBUG - 2022-08-09 00:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:17 --> Total execution time: 0.1129
DEBUG - 2022-08-09 00:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:19 --> Total execution time: 0.0870
DEBUG - 2022-08-09 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:23 --> Total execution time: 0.0528
DEBUG - 2022-08-09 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:23 --> Total execution time: 0.0933
DEBUG - 2022-08-09 00:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:01 --> Total execution time: 0.1960
DEBUG - 2022-08-09 00:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:04 --> Total execution time: 0.0794
DEBUG - 2022-08-09 00:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:09 --> Total execution time: 0.0907
DEBUG - 2022-08-09 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:16 --> Total execution time: 0.0822
DEBUG - 2022-08-09 00:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:18 --> Total execution time: 0.0793
DEBUG - 2022-08-09 00:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:19 --> Total execution time: 0.1960
DEBUG - 2022-08-09 00:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:22 --> Total execution time: 0.1075
DEBUG - 2022-08-09 00:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:35 --> Total execution time: 0.0813
DEBUG - 2022-08-09 00:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:42:24 --> Total execution time: 0.2066
DEBUG - 2022-08-09 00:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:42:50 --> Total execution time: 0.1390
DEBUG - 2022-08-09 00:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:42:50 --> Total execution time: 0.1164
DEBUG - 2022-08-09 00:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:43:24 --> Total execution time: 0.0756
DEBUG - 2022-08-09 00:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:43:36 --> Total execution time: 0.0896
DEBUG - 2022-08-09 00:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:43:40 --> Total execution time: 0.0948
DEBUG - 2022-08-09 00:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:43:44 --> Total execution time: 0.0839
DEBUG - 2022-08-09 00:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:46:48 --> Total execution time: 0.1438
DEBUG - 2022-08-09 00:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:46:59 --> Total execution time: 0.0969
DEBUG - 2022-08-09 00:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:47:04 --> Total execution time: 0.1413
DEBUG - 2022-08-09 00:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:47:08 --> Total execution time: 0.0824
DEBUG - 2022-08-09 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:47:18 --> Total execution time: 0.1087
DEBUG - 2022-08-09 00:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:47:55 --> Total execution time: 0.2042
DEBUG - 2022-08-09 00:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:48:02 --> Total execution time: 0.0892
DEBUG - 2022-08-09 00:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:48:04 --> Total execution time: 0.0757
DEBUG - 2022-08-09 00:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:49 --> Total execution time: 0.1555
DEBUG - 2022-08-09 00:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:09 --> Total execution time: 0.0752
DEBUG - 2022-08-09 00:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:11 --> Total execution time: 0.0676
DEBUG - 2022-08-09 00:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:13 --> Total execution time: 0.0854
DEBUG - 2022-08-09 00:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:17 --> Total execution time: 0.0949
DEBUG - 2022-08-09 00:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:28 --> Total execution time: 0.0813
DEBUG - 2022-08-09 00:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:28 --> Total execution time: 0.0758
DEBUG - 2022-08-09 00:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:34 --> Total execution time: 0.0781
DEBUG - 2022-08-09 00:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:43 --> Total execution time: 0.2086
DEBUG - 2022-08-09 00:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:43 --> Total execution time: 0.0814
DEBUG - 2022-08-09 00:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:46 --> Total execution time: 0.1038
DEBUG - 2022-08-09 00:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:48 --> Total execution time: 0.1086
DEBUG - 2022-08-09 00:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:50 --> Total execution time: 0.1075
DEBUG - 2022-08-09 00:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:00 --> Total execution time: 0.0759
DEBUG - 2022-08-09 00:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:18 --> Total execution time: 0.1166
DEBUG - 2022-08-09 00:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:28 --> Total execution time: 0.0754
DEBUG - 2022-08-09 00:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:36 --> Total execution time: 0.1043
DEBUG - 2022-08-09 00:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:45 --> Total execution time: 0.0806
DEBUG - 2022-08-09 00:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:08 --> Total execution time: 0.1056
DEBUG - 2022-08-09 00:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:17 --> Total execution time: 0.0934
DEBUG - 2022-08-09 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:31 --> Total execution time: 0.0810
DEBUG - 2022-08-09 00:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:48 --> Total execution time: 0.1030
DEBUG - 2022-08-09 00:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:50 --> Total execution time: 0.0782
DEBUG - 2022-08-09 00:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:50 --> Total execution time: 0.1054
DEBUG - 2022-08-09 00:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:52 --> Total execution time: 0.0948
DEBUG - 2022-08-09 00:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:54:53 --> Total execution time: 0.1086
DEBUG - 2022-08-09 00:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:55:09 --> Total execution time: 0.0927
DEBUG - 2022-08-09 00:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:55:26 --> Total execution time: 0.0825
DEBUG - 2022-08-09 00:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:18 --> Total execution time: 0.0821
DEBUG - 2022-08-09 00:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:27 --> Total execution time: 0.0894
DEBUG - 2022-08-09 00:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:36 --> Total execution time: 0.1462
DEBUG - 2022-08-09 00:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:37 --> Total execution time: 0.1777
DEBUG - 2022-08-09 00:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:41 --> Total execution time: 0.1298
DEBUG - 2022-08-09 00:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:56 --> Total execution time: 0.0557
DEBUG - 2022-08-09 00:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:56:58 --> Total execution time: 0.0893
DEBUG - 2022-08-09 00:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:27:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:57:04 --> Total execution time: 0.0807
DEBUG - 2022-08-09 00:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:27:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:57:35 --> Total execution time: 0.0499
DEBUG - 2022-08-09 00:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:28:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:28:06 --> Total execution time: 0.0777
DEBUG - 2022-08-09 00:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:28:08 --> Total execution time: 0.0749
DEBUG - 2022-08-09 00:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:28:08 --> Total execution time: 0.1565
DEBUG - 2022-08-09 00:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:29:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:59:32 --> Total execution time: 0.3681
DEBUG - 2022-08-09 00:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:59:36 --> Total execution time: 0.1228
DEBUG - 2022-08-09 00:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:29:46 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 00:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:59:49 --> Total execution time: 2.1723
DEBUG - 2022-08-09 00:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 00:29:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 00:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:06 --> Total execution time: 0.1228
DEBUG - 2022-08-09 00:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:10 --> Total execution time: 0.1225
DEBUG - 2022-08-09 00:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:12 --> Total execution time: 0.1245
DEBUG - 2022-08-09 00:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:13 --> Total execution time: 0.1000
DEBUG - 2022-08-09 00:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:34 --> Total execution time: 0.2067
DEBUG - 2022-08-09 00:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:00:57 --> Total execution time: 0.0775
DEBUG - 2022-08-09 00:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:02:30 --> Total execution time: 0.2080
DEBUG - 2022-08-09 00:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:02:52 --> Total execution time: 0.1057
DEBUG - 2022-08-09 00:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:05:06 --> Total execution time: 0.2092
DEBUG - 2022-08-09 00:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:05:14 --> Total execution time: 0.0855
DEBUG - 2022-08-09 00:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:08:55 --> Total execution time: 0.0817
DEBUG - 2022-08-09 00:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:08:59 --> Total execution time: 0.0708
DEBUG - 2022-08-09 00:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:23 --> Total execution time: 0.1453
DEBUG - 2022-08-09 00:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:28 --> Total execution time: 0.1280
DEBUG - 2022-08-09 00:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:10:15 --> Total execution time: 0.0746
DEBUG - 2022-08-09 00:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:10:32 --> Total execution time: 0.0803
DEBUG - 2022-08-09 00:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:12:02 --> Total execution time: 0.2032
DEBUG - 2022-08-09 00:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:12:39 --> Total execution time: 0.0894
DEBUG - 2022-08-09 00:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:12:45 --> Total execution time: 0.1016
DEBUG - 2022-08-09 00:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:13:25 --> Total execution time: 0.0819
DEBUG - 2022-08-09 00:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:43:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:13:32 --> Total execution time: 0.0532
DEBUG - 2022-08-09 00:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:43:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:13:36 --> Total execution time: 0.0821
DEBUG - 2022-08-09 00:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:43:58 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:13:58 --> Total execution time: 0.0529
DEBUG - 2022-08-09 00:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:14:20 --> Total execution time: 0.2235
DEBUG - 2022-08-09 00:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:14:27 --> Total execution time: 0.0762
DEBUG - 2022-08-09 00:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:15:15 --> Total execution time: 0.1928
DEBUG - 2022-08-09 00:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:15:21 --> Total execution time: 0.0722
DEBUG - 2022-08-09 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:46:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:16:45 --> Total execution time: 0.2265
DEBUG - 2022-08-09 00:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:16:47 --> Total execution time: 0.0856
DEBUG - 2022-08-09 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:16:50 --> Total execution time: 0.0899
DEBUG - 2022-08-09 00:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:11 --> Total execution time: 0.0948
DEBUG - 2022-08-09 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:15 --> Total execution time: 0.0736
DEBUG - 2022-08-09 00:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:21 --> Total execution time: 0.0844
DEBUG - 2022-08-09 00:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:24 --> Total execution time: 0.3870
DEBUG - 2022-08-09 00:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:43 --> Total execution time: 0.0895
DEBUG - 2022-08-09 00:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:17:53 --> Total execution time: 0.0983
DEBUG - 2022-08-09 00:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:18:58 --> Total execution time: 0.0799
DEBUG - 2022-08-09 00:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 00:50:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 00:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:50:46 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:20:46 --> Total execution time: 0.0584
DEBUG - 2022-08-09 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:22:48 --> Total execution time: 0.0774
DEBUG - 2022-08-09 00:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:53:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 00:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:23:31 --> Total execution time: 0.0778
DEBUG - 2022-08-09 00:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:23:31 --> Total execution time: 0.1120
DEBUG - 2022-08-09 00:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:25:35 --> Total execution time: 0.3013
DEBUG - 2022-08-09 00:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:25:40 --> Total execution time: 0.1041
DEBUG - 2022-08-09 00:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:25:52 --> Total execution time: 0.0938
DEBUG - 2022-08-09 00:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:56:04 --> Total execution time: 0.0562
DEBUG - 2022-08-09 00:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 00:56:04 --> Total execution time: 0.0658
DEBUG - 2022-08-09 00:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:26:05 --> Total execution time: 0.0794
DEBUG - 2022-08-09 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:26:12 --> Total execution time: 0.1079
DEBUG - 2022-08-09 00:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:57:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:27:03 --> Total execution time: 0.1051
DEBUG - 2022-08-09 00:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 00:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 00:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:28:31 --> Total execution time: 0.0481
DEBUG - 2022-08-09 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:30:02 --> Total execution time: 0.1057
DEBUG - 2022-08-09 01:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:00:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:30:39 --> Total execution time: 0.1612
DEBUG - 2022-08-09 01:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:32:36 --> Total execution time: 0.0763
DEBUG - 2022-08-09 01:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:32:41 --> Total execution time: 0.2248
DEBUG - 2022-08-09 01:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:32:49 --> Total execution time: 0.0969
DEBUG - 2022-08-09 01:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:32:54 --> Total execution time: 0.0923
DEBUG - 2022-08-09 01:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:33:48 --> Total execution time: 0.0844
DEBUG - 2022-08-09 01:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:06 --> Total execution time: 0.0818
DEBUG - 2022-08-09 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:09 --> Total execution time: 0.1952
DEBUG - 2022-08-09 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:13 --> Total execution time: 0.1484
DEBUG - 2022-08-09 01:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:32 --> Total execution time: 0.1078
DEBUG - 2022-08-09 01:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:36 --> Total execution time: 0.0964
DEBUG - 2022-08-09 01:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:04:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:34:43 --> Total execution time: 0.0538
DEBUG - 2022-08-09 01:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:08 --> Total execution time: 0.0855
DEBUG - 2022-08-09 01:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:19 --> Total execution time: 0.0860
DEBUG - 2022-08-09 01:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:31 --> Total execution time: 0.1091
DEBUG - 2022-08-09 01:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:40 --> Total execution time: 0.1032
DEBUG - 2022-08-09 01:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:44 --> Total execution time: 0.0850
DEBUG - 2022-08-09 01:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:47 --> Total execution time: 0.1272
DEBUG - 2022-08-09 01:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:51 --> Total execution time: 0.1434
DEBUG - 2022-08-09 01:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:35:54 --> Total execution time: 0.0902
DEBUG - 2022-08-09 01:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:36:02 --> Total execution time: 0.1007
DEBUG - 2022-08-09 01:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:36:03 --> Total execution time: 0.1157
DEBUG - 2022-08-09 01:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:36:23 --> Total execution time: 0.0774
DEBUG - 2022-08-09 01:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:36:34 --> Total execution time: 0.0921
DEBUG - 2022-08-09 01:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:07:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:07:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:37:40 --> Total execution time: 0.0809
DEBUG - 2022-08-09 01:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:07:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:37:41 --> Total execution time: 0.0816
DEBUG - 2022-08-09 01:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:07:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:37:48 --> Total execution time: 0.0620
DEBUG - 2022-08-09 01:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:38:10 --> Total execution time: 0.0805
DEBUG - 2022-08-09 01:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:38:22 --> Total execution time: 0.0530
DEBUG - 2022-08-09 01:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:38:24 --> Total execution time: 0.0480
DEBUG - 2022-08-09 01:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:08:56 --> Total execution time: 0.0550
DEBUG - 2022-08-09 01:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:08:58 --> Total execution time: 0.0927
DEBUG - 2022-08-09 01:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:08:58 --> Total execution time: 0.1725
DEBUG - 2022-08-09 01:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:09:12 --> Total execution time: 0.1006
DEBUG - 2022-08-09 01:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:09:14 --> Total execution time: 0.0961
DEBUG - 2022-08-09 01:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:09:24 --> Total execution time: 0.0788
DEBUG - 2022-08-09 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:09:25 --> Total execution time: 0.1004
DEBUG - 2022-08-09 01:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:09:25 --> Total execution time: 0.1635
DEBUG - 2022-08-09 01:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:39:39 --> Total execution time: 0.0766
DEBUG - 2022-08-09 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:40:53 --> Total execution time: 0.0940
DEBUG - 2022-08-09 01:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:11:00 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:41:00 --> Total execution time: 0.0765
DEBUG - 2022-08-09 01:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:12:38 --> Total execution time: 0.0785
DEBUG - 2022-08-09 01:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:12:40 --> Total execution time: 0.0786
DEBUG - 2022-08-09 01:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:12:40 --> Total execution time: 0.1766
DEBUG - 2022-08-09 01:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:12:47 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:42:47 --> Total execution time: 0.0767
DEBUG - 2022-08-09 01:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:13:09 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 01:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:13:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:43:12 --> Total execution time: 1.9399
DEBUG - 2022-08-09 01:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 01:13:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 01:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:16:20 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:16:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:46:20 --> Total execution time: 0.2148
DEBUG - 2022-08-09 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:17:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:47:31 --> Total execution time: 0.0513
DEBUG - 2022-08-09 01:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:47:40 --> Total execution time: 0.0748
DEBUG - 2022-08-09 01:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:17:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 01:17:56 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 01:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 01:18:00 --> 404 Page Not Found: Lessons/how-to-start-reselling
DEBUG - 2022-08-09 01:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:03 --> Total execution time: 0.0908
DEBUG - 2022-08-09 01:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:10 --> Total execution time: 0.0958
DEBUG - 2022-08-09 01:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:15 --> Total execution time: 0.0900
DEBUG - 2022-08-09 01:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:15 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 01:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:16 --> Total execution time: 0.0757
DEBUG - 2022-08-09 01:18:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:48:46 --> Total execution time: 0.0829
DEBUG - 2022-08-09 01:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:49:03 --> Total execution time: 0.0847
DEBUG - 2022-08-09 01:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:49:12 --> Total execution time: 0.0878
DEBUG - 2022-08-09 01:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:49:16 --> Total execution time: 0.0927
DEBUG - 2022-08-09 01:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:49:28 --> Total execution time: 0.0930
DEBUG - 2022-08-09 01:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:49:33 --> Total execution time: 0.0904
DEBUG - 2022-08-09 01:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:02 --> Total execution time: 0.2586
DEBUG - 2022-08-09 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:39 --> Total execution time: 0.0766
DEBUG - 2022-08-09 01:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:40 --> Total execution time: 0.0798
DEBUG - 2022-08-09 01:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:45 --> Total execution time: 0.0811
DEBUG - 2022-08-09 01:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:52 --> Total execution time: 0.0849
DEBUG - 2022-08-09 01:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 01:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:50:53 --> Total execution time: 0.0786
DEBUG - 2022-08-09 01:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:51:39 --> Total execution time: 0.0786
DEBUG - 2022-08-09 01:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:22:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:52:43 --> Total execution time: 0.0599
DEBUG - 2022-08-09 01:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:22:54 --> Total execution time: 0.0807
DEBUG - 2022-08-09 01:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:22:56 --> Total execution time: 0.0808
DEBUG - 2022-08-09 01:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:22:56 --> Total execution time: 0.1611
DEBUG - 2022-08-09 01:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:23:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:53:22 --> Total execution time: 0.1274
DEBUG - 2022-08-09 01:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:23 --> Total execution time: 0.0594
DEBUG - 2022-08-09 01:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:23 --> Total execution time: 0.0440
DEBUG - 2022-08-09 01:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:30 --> Total execution time: 0.0562
DEBUG - 2022-08-09 01:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:38 --> Total execution time: 0.0864
DEBUG - 2022-08-09 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:46 --> Total execution time: 0.0800
DEBUG - 2022-08-09 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:55:49 --> Total execution time: 0.1060
DEBUG - 2022-08-09 01:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:56:19 --> Total execution time: 0.1135
DEBUG - 2022-08-09 01:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:57:21 --> Total execution time: 0.0785
DEBUG - 2022-08-09 01:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:57:31 --> Total execution time: 0.2366
DEBUG - 2022-08-09 01:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:57:37 --> Total execution time: 0.1298
DEBUG - 2022-08-09 01:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:57:51 --> Total execution time: 0.1139
DEBUG - 2022-08-09 01:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:57:55 --> Total execution time: 0.1220
DEBUG - 2022-08-09 01:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:02 --> Total execution time: 0.1448
DEBUG - 2022-08-09 01:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:42 --> Total execution time: 0.1063
DEBUG - 2022-08-09 01:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:58:43 --> Total execution time: 0.1685
DEBUG - 2022-08-09 01:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:43 --> Total execution time: 0.1750
DEBUG - 2022-08-09 01:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:43 --> Total execution time: 0.1034
DEBUG - 2022-08-09 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:44 --> Total execution time: 0.0841
DEBUG - 2022-08-09 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:44 --> Total execution time: 0.0819
DEBUG - 2022-08-09 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:58:44 --> Total execution time: 0.1983
DEBUG - 2022-08-09 01:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:00:33 --> Total execution time: 0.0782
DEBUG - 2022-08-09 01:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:00:46 --> Total execution time: 0.0806
DEBUG - 2022-08-09 01:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:35:59 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:05:59 --> Total execution time: 0.1508
DEBUG - 2022-08-09 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:05 --> Total execution time: 0.0832
DEBUG - 2022-08-09 01:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:15 --> Total execution time: 0.0991
DEBUG - 2022-08-09 01:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:27 --> Total execution time: 0.1397
DEBUG - 2022-08-09 01:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:35 --> Total execution time: 0.1319
DEBUG - 2022-08-09 01:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:46 --> Total execution time: 0.0856
DEBUG - 2022-08-09 01:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:37:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:07:27 --> Total execution time: 0.1540
DEBUG - 2022-08-09 01:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:07:41 --> Total execution time: 0.0923
DEBUG - 2022-08-09 01:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:38:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:08:06 --> Total execution time: 0.0516
DEBUG - 2022-08-09 01:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:08:26 --> Total execution time: 0.0892
DEBUG - 2022-08-09 01:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:09:07 --> Total execution time: 0.2517
DEBUG - 2022-08-09 01:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:09:54 --> Total execution time: 0.1315
DEBUG - 2022-08-09 01:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:10:44 --> Total execution time: 0.0770
DEBUG - 2022-08-09 01:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:14:39 --> Total execution time: 0.1938
DEBUG - 2022-08-09 01:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:45:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:15:02 --> Total execution time: 0.0871
DEBUG - 2022-08-09 01:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:46:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:16:54 --> Total execution time: 0.0551
DEBUG - 2022-08-09 01:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:47:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:17:33 --> Total execution time: 0.0712
DEBUG - 2022-08-09 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:18:52 --> Total execution time: 0.0763
DEBUG - 2022-08-09 01:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:18:59 --> Total execution time: 0.0957
DEBUG - 2022-08-09 01:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:19:05 --> Total execution time: 0.0835
DEBUG - 2022-08-09 01:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:52:59 --> No URI present. Default controller set.
DEBUG - 2022-08-09 01:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:22:59 --> Total execution time: 0.1753
DEBUG - 2022-08-09 01:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:24:33 --> Total execution time: 0.2481
DEBUG - 2022-08-09 01:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:24:55 --> Total execution time: 0.0974
DEBUG - 2022-08-09 01:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:25:09 --> Total execution time: 0.0811
DEBUG - 2022-08-09 01:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:25:27 --> Total execution time: 0.0820
DEBUG - 2022-08-09 01:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:00 --> Total execution time: 0.0762
DEBUG - 2022-08-09 01:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:05 --> Total execution time: 0.0880
DEBUG - 2022-08-09 01:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:19 --> Total execution time: 0.1257
DEBUG - 2022-08-09 01:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:26 --> Total execution time: 0.0818
DEBUG - 2022-08-09 01:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:31 --> Total execution time: 0.2649
DEBUG - 2022-08-09 01:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:51 --> Total execution time: 0.0823
DEBUG - 2022-08-09 01:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:56 --> Total execution time: 0.0898
DEBUG - 2022-08-09 01:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:26:57 --> Total execution time: 0.2885
DEBUG - 2022-08-09 01:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:27:28 --> Total execution time: 0.1397
DEBUG - 2022-08-09 01:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:27:39 --> Total execution time: 0.1115
DEBUG - 2022-08-09 01:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:27:43 --> Total execution time: 0.0463
DEBUG - 2022-08-09 01:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 01:57:46 --> 404 Page Not Found: Teacher/aleksejs-petenko
DEBUG - 2022-08-09 01:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:27:54 --> Total execution time: 0.0809
DEBUG - 2022-08-09 01:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:28:09 --> Total execution time: 0.1098
DEBUG - 2022-08-09 01:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:28:28 --> Total execution time: 0.0830
DEBUG - 2022-08-09 01:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 01:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 01:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 01:59:29 --> Total execution time: 0.0603
DEBUG - 2022-08-09 02:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:30:03 --> Total execution time: 0.1422
DEBUG - 2022-08-09 02:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:32:00 --> Total execution time: 0.1250
DEBUG - 2022-08-09 02:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:34:42 --> Total execution time: 0.1614
DEBUG - 2022-08-09 02:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:36:44 --> Total execution time: 0.0874
DEBUG - 2022-08-09 02:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:04 --> Total execution time: 0.0986
DEBUG - 2022-08-09 02:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:16 --> Total execution time: 0.0912
DEBUG - 2022-08-09 02:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:22 --> Total execution time: 0.1121
DEBUG - 2022-08-09 02:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:44 --> Total execution time: 0.0943
DEBUG - 2022-08-09 02:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:51 --> Total execution time: 0.0801
DEBUG - 2022-08-09 02:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:37:56 --> Total execution time: 0.0747
DEBUG - 2022-08-09 02:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:02 --> Total execution time: 0.1927
DEBUG - 2022-08-09 02:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:07 --> Total execution time: 0.0872
DEBUG - 2022-08-09 02:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:10 --> Total execution time: 0.1030
DEBUG - 2022-08-09 02:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:15 --> Total execution time: 0.0981
DEBUG - 2022-08-09 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:26 --> Total execution time: 0.0874
DEBUG - 2022-08-09 02:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:29 --> Total execution time: 0.1404
DEBUG - 2022-08-09 02:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:38:55 --> Total execution time: 0.1157
DEBUG - 2022-08-09 02:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:05 --> Total execution time: 0.0962
DEBUG - 2022-08-09 02:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:14 --> Total execution time: 0.0909
DEBUG - 2022-08-09 02:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:19 --> Total execution time: 0.0676
DEBUG - 2022-08-09 02:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:20 --> Total execution time: 0.0903
DEBUG - 2022-08-09 02:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:32 --> Total execution time: 0.1449
DEBUG - 2022-08-09 02:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:38 --> Total execution time: 0.0560
DEBUG - 2022-08-09 02:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:39 --> Total execution time: 0.0968
DEBUG - 2022-08-09 02:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:40 --> Total execution time: 0.1075
DEBUG - 2022-08-09 02:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:41 --> Total execution time: 0.0799
DEBUG - 2022-08-09 02:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:45 --> Total execution time: 0.0748
DEBUG - 2022-08-09 02:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:46 --> Total execution time: 0.0856
DEBUG - 2022-08-09 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:50 --> Total execution time: 0.0745
DEBUG - 2022-08-09 02:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:09:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:39:59 --> Total execution time: 0.0877
DEBUG - 2022-08-09 02:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:08 --> Total execution time: 0.1037
DEBUG - 2022-08-09 02:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:11 --> Total execution time: 0.1005
DEBUG - 2022-08-09 02:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:18 --> Total execution time: 0.0901
DEBUG - 2022-08-09 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:23 --> Total execution time: 0.0929
DEBUG - 2022-08-09 02:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:30 --> Total execution time: 0.1084
DEBUG - 2022-08-09 02:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:34 --> Total execution time: 0.0802
DEBUG - 2022-08-09 02:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:37 --> Total execution time: 0.0892
DEBUG - 2022-08-09 02:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:44 --> Total execution time: 0.1214
DEBUG - 2022-08-09 02:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:47 --> Total execution time: 0.0817
DEBUG - 2022-08-09 02:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:49 --> Total execution time: 0.0828
DEBUG - 2022-08-09 02:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:40:51 --> Total execution time: 0.1091
DEBUG - 2022-08-09 02:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:41:55 --> Total execution time: 0.2446
DEBUG - 2022-08-09 02:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:13:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:43:50 --> Total execution time: 0.0765
DEBUG - 2022-08-09 02:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:44:35 --> Total execution time: 0.1035
DEBUG - 2022-08-09 02:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:44:45 --> Total execution time: 0.0893
DEBUG - 2022-08-09 02:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:44:50 --> Total execution time: 0.0828
DEBUG - 2022-08-09 02:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:44:53 --> Total execution time: 0.0919
DEBUG - 2022-08-09 02:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:17:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:47:12 --> Total execution time: 0.2122
DEBUG - 2022-08-09 02:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:18:37 --> Total execution time: 0.2149
DEBUG - 2022-08-09 02:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:48:37 --> Total execution time: 0.0759
DEBUG - 2022-08-09 02:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:18:38 --> Total execution time: 0.0829
DEBUG - 2022-08-09 02:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:48:55 --> Total execution time: 0.0520
DEBUG - 2022-08-09 02:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:48:57 --> Total execution time: 0.0802
DEBUG - 2022-08-09 02:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:21:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:51:16 --> Total execution time: 0.1366
DEBUG - 2022-08-09 02:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:23:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:53:15 --> Total execution time: 0.0562
DEBUG - 2022-08-09 02:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:53:21 --> Total execution time: 0.0514
DEBUG - 2022-08-09 02:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:53:40 --> Total execution time: 0.0977
DEBUG - 2022-08-09 02:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:53:55 --> Total execution time: 0.0948
DEBUG - 2022-08-09 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:24:14 --> Total execution time: 0.2169
DEBUG - 2022-08-09 02:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:54:15 --> Total execution time: 0.1089
DEBUG - 2022-08-09 02:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:54:21 --> Total execution time: 0.1121
DEBUG - 2022-08-09 02:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:54:27 --> Total execution time: 0.1158
DEBUG - 2022-08-09 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:54:59 --> Total execution time: 0.1608
DEBUG - 2022-08-09 02:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:55:49 --> Total execution time: 0.0862
DEBUG - 2022-08-09 02:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:55:59 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 02:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:00 --> Total execution time: 0.1284
DEBUG - 2022-08-09 02:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:13 --> Total execution time: 0.0869
DEBUG - 2022-08-09 02:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:15 --> Total execution time: 0.0810
DEBUG - 2022-08-09 02:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:56:46 --> Total execution time: 0.1441
DEBUG - 2022-08-09 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:47 --> Total execution time: 0.1743
DEBUG - 2022-08-09 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:56:47 --> Total execution time: 0.1647
DEBUG - 2022-08-09 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:56:47 --> Total execution time: 0.1127
DEBUG - 2022-08-09 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:47 --> Total execution time: 0.1177
DEBUG - 2022-08-09 02:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:48 --> Total execution time: 0.0775
DEBUG - 2022-08-09 02:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:49 --> Total execution time: 0.0899
DEBUG - 2022-08-09 02:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:26:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:56:50 --> Total execution time: 0.0818
DEBUG - 2022-08-09 02:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:01 --> Total execution time: 0.0906
DEBUG - 2022-08-09 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 02:27:15 --> 404 Page Not Found: Product/premium-membership
DEBUG - 2022-08-09 02:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:18 --> Total execution time: 0.0850
DEBUG - 2022-08-09 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:26 --> Total execution time: 0.0818
DEBUG - 2022-08-09 02:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:37 --> Total execution time: 0.0876
DEBUG - 2022-08-09 02:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:45 --> Total execution time: 0.0777
DEBUG - 2022-08-09 02:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:57:51 --> Total execution time: 0.0725
DEBUG - 2022-08-09 02:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:58:13 --> Total execution time: 0.0773
DEBUG - 2022-08-09 02:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:28:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:58:15 --> Total execution time: 0.0945
DEBUG - 2022-08-09 02:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:28:20 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:58:20 --> Total execution time: 0.2208
DEBUG - 2022-08-09 02:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:09 --> Total execution time: 0.0830
DEBUG - 2022-08-09 02:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:18 --> Total execution time: 0.0906
DEBUG - 2022-08-09 02:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:27 --> Total execution time: 0.1194
DEBUG - 2022-08-09 02:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:42 --> Total execution time: 0.0863
DEBUG - 2022-08-09 02:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:42 --> Total execution time: 0.1437
DEBUG - 2022-08-09 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:43 --> Total execution time: 0.0920
DEBUG - 2022-08-09 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:43 --> Total execution time: 0.0996
DEBUG - 2022-08-09 02:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:01:43 --> Total execution time: 0.1242
DEBUG - 2022-08-09 02:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:32:26 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:02:26 --> Total execution time: 0.0629
DEBUG - 2022-08-09 02:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 02:32:27 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-08-09 02:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:02:28 --> Total execution time: 0.0489
DEBUG - 2022-08-09 02:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:36:45 --> Total execution time: 0.1378
DEBUG - 2022-08-09 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:36:47 --> Total execution time: 0.0840
DEBUG - 2022-08-09 02:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:36:47 --> Total execution time: 0.1360
DEBUG - 2022-08-09 02:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:38:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:08:37 --> Total execution time: 0.0723
DEBUG - 2022-08-09 02:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:40:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:10:21 --> Total execution time: 0.0767
DEBUG - 2022-08-09 02:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:40:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:40:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:10:37 --> Total execution time: 0.0585
DEBUG - 2022-08-09 02:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:40:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:10:38 --> Total execution time: 0.0517
DEBUG - 2022-08-09 02:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:10:51 --> Total execution time: 0.0491
DEBUG - 2022-08-09 02:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:00 --> Total execution time: 0.0562
DEBUG - 2022-08-09 02:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:06 --> Total execution time: 0.0757
DEBUG - 2022-08-09 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:14 --> Total execution time: 0.0869
DEBUG - 2022-08-09 02:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:18 --> Total execution time: 0.1535
DEBUG - 2022-08-09 02:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:32 --> Total execution time: 0.0541
DEBUG - 2022-08-09 02:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:37 --> Total execution time: 0.0945
DEBUG - 2022-08-09 02:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:42 --> Total execution time: 0.1042
DEBUG - 2022-08-09 02:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:42 --> Total execution time: 0.1024
DEBUG - 2022-08-09 02:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:47 --> Total execution time: 0.0831
DEBUG - 2022-08-09 02:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:04 --> Total execution time: 0.1130
DEBUG - 2022-08-09 02:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:04 --> Total execution time: 0.1194
DEBUG - 2022-08-09 02:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:08 --> Total execution time: 0.1085
DEBUG - 2022-08-09 02:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:15 --> Total execution time: 0.0931
DEBUG - 2022-08-09 02:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:25 --> Total execution time: 0.0997
DEBUG - 2022-08-09 02:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:28 --> Total execution time: 0.1020
DEBUG - 2022-08-09 02:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:39 --> Total execution time: 0.1085
DEBUG - 2022-08-09 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:47 --> Total execution time: 0.0773
DEBUG - 2022-08-09 02:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:48 --> Total execution time: 0.0859
DEBUG - 2022-08-09 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:56 --> Total execution time: 0.0891
DEBUG - 2022-08-09 02:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:12:59 --> Total execution time: 0.1197
DEBUG - 2022-08-09 02:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:13:43 --> Total execution time: 0.0774
DEBUG - 2022-08-09 02:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:13:54 --> Total execution time: 0.2389
DEBUG - 2022-08-09 02:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:05 --> Total execution time: 0.1498
DEBUG - 2022-08-09 02:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:18 --> Total execution time: 0.0553
DEBUG - 2022-08-09 02:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:25 --> Total execution time: 0.0946
DEBUG - 2022-08-09 02:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:25 --> Total execution time: 0.0781
DEBUG - 2022-08-09 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:32 --> Total execution time: 0.0855
DEBUG - 2022-08-09 02:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:36 --> Total execution time: 0.0823
DEBUG - 2022-08-09 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:49 --> Total execution time: 0.0856
DEBUG - 2022-08-09 02:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:56 --> Total execution time: 0.0877
DEBUG - 2022-08-09 02:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:14:59 --> Total execution time: 0.1131
DEBUG - 2022-08-09 02:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:15:09 --> Total execution time: 0.0828
DEBUG - 2022-08-09 02:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:15:11 --> Total execution time: 0.0806
DEBUG - 2022-08-09 02:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:45:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:15:14 --> Total execution time: 0.0766
DEBUG - 2022-08-09 02:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:00 --> Total execution time: 0.0964
DEBUG - 2022-08-09 02:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:17 --> Total execution time: 0.0798
DEBUG - 2022-08-09 02:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:23 --> Total execution time: 0.1043
DEBUG - 2022-08-09 02:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:30 --> Total execution time: 0.2401
DEBUG - 2022-08-09 02:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:33 --> Total execution time: 0.0863
DEBUG - 2022-08-09 02:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:34 --> Total execution time: 0.0802
DEBUG - 2022-08-09 02:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:36 --> Total execution time: 0.0501
DEBUG - 2022-08-09 02:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:38 --> Total execution time: 0.0866
DEBUG - 2022-08-09 02:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:39 --> Total execution time: 0.0846
DEBUG - 2022-08-09 02:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:50 --> Total execution time: 0.0733
DEBUG - 2022-08-09 02:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:16:53 --> Total execution time: 0.0812
DEBUG - 2022-08-09 02:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:17:02 --> Total execution time: 0.1370
DEBUG - 2022-08-09 02:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:17:08 --> Total execution time: 0.1339
DEBUG - 2022-08-09 02:47:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:47:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:47:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:17:10 --> Total execution time: 0.0571
DEBUG - 2022-08-09 02:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:18:36 --> Total execution time: 0.0776
DEBUG - 2022-08-09 02:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:18:52 --> Total execution time: 0.0856
DEBUG - 2022-08-09 02:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:19:03 --> Total execution time: 0.0832
DEBUG - 2022-08-09 02:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:19:05 --> Total execution time: 0.2279
DEBUG - 2022-08-09 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:19:47 --> Total execution time: 0.0825
DEBUG - 2022-08-09 02:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:20:22 --> Total execution time: 0.0796
DEBUG - 2022-08-09 02:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:22:35 --> Total execution time: 0.0863
DEBUG - 2022-08-09 02:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:22:37 --> Total execution time: 0.1035
DEBUG - 2022-08-09 02:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:22:49 --> Total execution time: 0.0849
DEBUG - 2022-08-09 02:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:23:37 --> Total execution time: 0.1988
DEBUG - 2022-08-09 02:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:23:47 --> Total execution time: 0.0864
DEBUG - 2022-08-09 02:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:53:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:23:50 --> Total execution time: 0.0807
DEBUG - 2022-08-09 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:23:56 --> Total execution time: 0.1035
DEBUG - 2022-08-09 02:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:24:01 --> Total execution time: 0.2173
DEBUG - 2022-08-09 02:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:02 --> Total execution time: 0.0888
DEBUG - 2022-08-09 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:14 --> Total execution time: 0.0766
DEBUG - 2022-08-09 02:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:20 --> Total execution time: 0.0778
DEBUG - 2022-08-09 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:24 --> Total execution time: 0.0772
DEBUG - 2022-08-09 02:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:24:29 --> Total execution time: 0.1767
DEBUG - 2022-08-09 02:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:30 --> Total execution time: 0.2708
DEBUG - 2022-08-09 02:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:24:33 --> Total execution time: 0.1101
DEBUG - 2022-08-09 02:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:24:49 --> Total execution time: 0.1113
DEBUG - 2022-08-09 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:24:58 --> Total execution time: 0.0766
DEBUG - 2022-08-09 02:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:06 --> Total execution time: 0.1070
DEBUG - 2022-08-09 02:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:11 --> Total execution time: 0.0539
DEBUG - 2022-08-09 02:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:12 --> Total execution time: 0.0679
DEBUG - 2022-08-09 02:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:12 --> Total execution time: 0.0810
DEBUG - 2022-08-09 02:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:15 --> Total execution time: 0.0956
DEBUG - 2022-08-09 02:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:17 --> Total execution time: 0.1014
DEBUG - 2022-08-09 02:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:26 --> Total execution time: 0.1131
DEBUG - 2022-08-09 02:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:55:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:25:31 --> Total execution time: 0.0788
DEBUG - 2022-08-09 02:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:21 --> Total execution time: 0.0770
DEBUG - 2022-08-09 02:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:30 --> Total execution time: 0.0744
DEBUG - 2022-08-09 02:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:30 --> Total execution time: 0.0639
DEBUG - 2022-08-09 02:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:37 --> Total execution time: 0.0942
DEBUG - 2022-08-09 02:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:39 --> Total execution time: 0.0742
DEBUG - 2022-08-09 02:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 02:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:55 --> Total execution time: 0.0927
DEBUG - 2022-08-09 02:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:27:05 --> Total execution time: 0.0903
DEBUG - 2022-08-09 02:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:27:16 --> Total execution time: 0.0814
DEBUG - 2022-08-09 02:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:27:30 --> Total execution time: 0.0891
DEBUG - 2022-08-09 02:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:27:53 --> Total execution time: 0.0788
DEBUG - 2022-08-09 02:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 02:59:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 02:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 02:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:29:44 --> Total execution time: 0.0640
DEBUG - 2022-08-09 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:30:02 --> Total execution time: 0.1247
DEBUG - 2022-08-09 03:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:32:24 --> Total execution time: 0.0924
DEBUG - 2022-08-09 03:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:33:38 --> Total execution time: 0.0799
DEBUG - 2022-08-09 03:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:09:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:39:21 --> Total execution time: 0.1275
DEBUG - 2022-08-09 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:10:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 03:10:00 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 03:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:04 --> Total execution time: 0.0530
DEBUG - 2022-08-09 03:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:06 --> Total execution time: 0.0508
DEBUG - 2022-08-09 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:29 --> Total execution time: 0.0509
DEBUG - 2022-08-09 03:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:30 --> Total execution time: 0.0513
DEBUG - 2022-08-09 03:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:35 --> Total execution time: 0.0789
DEBUG - 2022-08-09 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:43 --> Total execution time: 0.0596
DEBUG - 2022-08-09 03:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:44 --> Total execution time: 0.0540
DEBUG - 2022-08-09 03:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:11:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:41:57 --> Total execution time: 0.0565
DEBUG - 2022-08-09 03:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:02 --> Total execution time: 0.0535
DEBUG - 2022-08-09 03:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:03 --> Total execution time: 0.0773
DEBUG - 2022-08-09 03:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:12:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:12 --> Total execution time: 0.0979
DEBUG - 2022-08-09 13:42:12 --> Total execution time: 0.0988
DEBUG - 2022-08-09 03:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:19 --> Total execution time: 0.0881
DEBUG - 2022-08-09 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:23 --> Total execution time: 0.1026
DEBUG - 2022-08-09 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:27 --> Total execution time: 0.0989
DEBUG - 2022-08-09 13:42:27 --> Total execution time: 0.1352
DEBUG - 2022-08-09 03:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:33 --> Total execution time: 0.0918
DEBUG - 2022-08-09 03:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:34 --> Total execution time: 0.0987
DEBUG - 2022-08-09 03:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:36 --> Total execution time: 0.0974
DEBUG - 2022-08-09 03:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:46 --> Total execution time: 0.0998
DEBUG - 2022-08-09 03:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:42:58 --> Total execution time: 0.0750
DEBUG - 2022-08-09 03:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:07 --> Total execution time: 0.0488
DEBUG - 2022-08-09 03:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:16 --> Total execution time: 0.0778
DEBUG - 2022-08-09 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:18 --> Total execution time: 0.0811
DEBUG - 2022-08-09 03:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:18 --> Total execution time: 0.0785
DEBUG - 2022-08-09 03:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:33 --> Total execution time: 0.0874
DEBUG - 2022-08-09 03:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:45 --> Total execution time: 0.0880
DEBUG - 2022-08-09 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:55 --> Total execution time: 0.1011
DEBUG - 2022-08-09 03:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:09 --> Total execution time: 0.1477
DEBUG - 2022-08-09 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:24 --> Total execution time: 0.0909
DEBUG - 2022-08-09 03:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:24 --> Total execution time: 0.0822
DEBUG - 2022-08-09 03:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:32 --> Total execution time: 0.0790
DEBUG - 2022-08-09 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:43 --> Total execution time: 0.1372
DEBUG - 2022-08-09 03:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:14:52 --> Total execution time: 0.0787
DEBUG - 2022-08-09 03:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:57 --> Total execution time: 0.0796
DEBUG - 2022-08-09 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:13 --> Total execution time: 0.1259
DEBUG - 2022-08-09 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:31 --> Total execution time: 0.1153
DEBUG - 2022-08-09 03:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:40 --> Total execution time: 0.0885
DEBUG - 2022-08-09 03:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:46 --> Total execution time: 0.0809
DEBUG - 2022-08-09 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:45:55 --> Total execution time: 0.1160
DEBUG - 2022-08-09 03:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:46:11 --> Total execution time: 0.1248
DEBUG - 2022-08-09 03:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:46:29 --> Total execution time: 0.0824
DEBUG - 2022-08-09 03:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:46:35 --> Total execution time: 0.0821
DEBUG - 2022-08-09 03:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:46:49 --> Total execution time: 0.1521
DEBUG - 2022-08-09 03:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:17:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:47:06 --> Total execution time: 0.0542
DEBUG - 2022-08-09 03:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:47:52 --> Total execution time: 0.1134
DEBUG - 2022-08-09 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:17:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:47:57 --> Total execution time: 0.0498
DEBUG - 2022-08-09 03:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:17:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:47:57 --> Total execution time: 0.0464
DEBUG - 2022-08-09 03:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:09 --> Total execution time: 0.0548
DEBUG - 2022-08-09 03:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:33 --> Total execution time: 0.0558
DEBUG - 2022-08-09 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:42 --> Total execution time: 0.2386
DEBUG - 2022-08-09 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:43 --> Total execution time: 0.0744
DEBUG - 2022-08-09 03:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:57 --> Total execution time: 0.0819
DEBUG - 2022-08-09 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:00 --> Total execution time: 0.0513
DEBUG - 2022-08-09 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:01 --> Total execution time: 0.0728
DEBUG - 2022-08-09 03:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:12 --> Total execution time: 0.0765
DEBUG - 2022-08-09 03:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:20 --> Total execution time: 0.0779
DEBUG - 2022-08-09 03:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:49:21 --> Total execution time: 0.0699
DEBUG - 2022-08-09 03:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:50:31 --> Total execution time: 0.0589
DEBUG - 2022-08-09 03:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:44 --> Total execution time: 0.0563
DEBUG - 2022-08-09 03:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:46 --> Total execution time: 0.0785
DEBUG - 2022-08-09 03:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:48 --> Total execution time: 0.0551
DEBUG - 2022-08-09 03:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:49 --> Total execution time: 0.0759
DEBUG - 2022-08-09 03:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:55 --> Total execution time: 0.0868
DEBUG - 2022-08-09 03:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:21:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:51:56 --> Total execution time: 0.0757
DEBUG - 2022-08-09 03:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:22:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:52:03 --> Total execution time: 0.0918
DEBUG - 2022-08-09 03:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:52:06 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:52:06 --> Total execution time: 0.0749
DEBUG - 2022-08-09 03:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:22:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:52:24 --> Total execution time: 0.0515
DEBUG - 2022-08-09 03:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:52:52 --> Total execution time: 0.1277
DEBUG - 2022-08-09 03:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:54:43 --> Total execution time: 0.2011
DEBUG - 2022-08-09 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:04 --> Total execution time: 0.0874
DEBUG - 2022-08-09 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:07 --> Total execution time: 0.0836
DEBUG - 2022-08-09 03:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:15 --> Total execution time: 0.0838
DEBUG - 2022-08-09 03:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:20 --> Total execution time: 0.0798
DEBUG - 2022-08-09 03:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:39 --> Total execution time: 0.0843
DEBUG - 2022-08-09 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:42 --> Total execution time: 0.1025
DEBUG - 2022-08-09 03:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:48 --> Total execution time: 0.0793
DEBUG - 2022-08-09 03:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:55:53 --> Total execution time: 0.1159
DEBUG - 2022-08-09 03:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:56:28 --> Total execution time: 0.0805
DEBUG - 2022-08-09 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:57:42 --> Total execution time: 0.0830
DEBUG - 2022-08-09 03:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:31:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:01:44 --> Total execution time: 0.3113
DEBUG - 2022-08-09 03:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:31:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:01:45 --> Total execution time: 0.0745
DEBUG - 2022-08-09 03:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:01:48 --> Total execution time: 0.1974
DEBUG - 2022-08-09 03:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:01:55 --> Total execution time: 0.0890
DEBUG - 2022-08-09 03:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:02:00 --> Total execution time: 0.1105
DEBUG - 2022-08-09 03:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:03:18 --> Total execution time: 0.0807
DEBUG - 2022-08-09 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:03:20 --> Total execution time: 0.0833
DEBUG - 2022-08-09 03:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:33:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:03:21 --> Total execution time: 0.0869
DEBUG - 2022-08-09 03:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:02 --> Total execution time: 0.2715
DEBUG - 2022-08-09 03:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 03:40:22 --> 404 Page Not Found: Home-1/index
DEBUG - 2022-08-09 03:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:40 --> Total execution time: 0.0572
DEBUG - 2022-08-09 03:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:54 --> Total execution time: 0.0775
DEBUG - 2022-08-09 03:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:55 --> Total execution time: 0.0788
DEBUG - 2022-08-09 03:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:59 --> Total execution time: 0.0825
DEBUG - 2022-08-09 03:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:11:42 --> Total execution time: 0.0770
DEBUG - 2022-08-09 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:42:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:12:02 --> Total execution time: 0.2026
DEBUG - 2022-08-09 03:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:42:07 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:12:07 --> Total execution time: 0.0616
DEBUG - 2022-08-09 03:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:42:26 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:12:26 --> Total execution time: 0.0778
DEBUG - 2022-08-09 03:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:12 --> Total execution time: 0.0507
DEBUG - 2022-08-09 03:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:16 --> Total execution time: 0.0970
DEBUG - 2022-08-09 03:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:23 --> Total execution time: 0.0856
DEBUG - 2022-08-09 03:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:29 --> Total execution time: 0.1078
DEBUG - 2022-08-09 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:31 --> Total execution time: 0.0917
DEBUG - 2022-08-09 03:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:34 --> Total execution time: 0.1121
DEBUG - 2022-08-09 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:38 --> Total execution time: 0.1074
DEBUG - 2022-08-09 03:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:44:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:14:39 --> Total execution time: 0.0919
DEBUG - 2022-08-09 03:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:07 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:07 --> Total execution time: 0.0544
DEBUG - 2022-08-09 03:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:08 --> Total execution time: 0.0851
DEBUG - 2022-08-09 03:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:13 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:13 --> Total execution time: 0.0869
DEBUG - 2022-08-09 03:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:19 --> Total execution time: 0.0758
DEBUG - 2022-08-09 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:26 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:26 --> Total execution time: 0.0752
DEBUG - 2022-08-09 03:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:31 --> Total execution time: 0.0484
DEBUG - 2022-08-09 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:33 --> Total execution time: 0.0764
DEBUG - 2022-08-09 03:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:15:43 --> Total execution time: 0.2004
DEBUG - 2022-08-09 03:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:16:12 --> Total execution time: 0.0750
DEBUG - 2022-08-09 03:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:16:27 --> Total execution time: 0.0850
DEBUG - 2022-08-09 03:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:16:35 --> Total execution time: 0.0799
DEBUG - 2022-08-09 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:16:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:16:36 --> Total execution time: 0.0867
DEBUG - 2022-08-09 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:17:04 --> Total execution time: 0.0803
DEBUG - 2022-08-09 03:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:17:26 --> Total execution time: 0.0812
DEBUG - 2022-08-09 03:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:48:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:18:51 --> Total execution time: 0.0645
DEBUG - 2022-08-09 03:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:19:05 --> Total execution time: 0.0787
DEBUG - 2022-08-09 03:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:19:16 --> Total execution time: 0.1239
DEBUG - 2022-08-09 03:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:49:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:19:35 --> Total execution time: 0.1108
DEBUG - 2022-08-09 03:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:19:48 --> Total execution time: 0.0841
DEBUG - 2022-08-09 03:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:08 --> Total execution time: 0.0923
DEBUG - 2022-08-09 03:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:37 --> Total execution time: 0.0765
DEBUG - 2022-08-09 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:47 --> Total execution time: 0.1995
DEBUG - 2022-08-09 03:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:48 --> Total execution time: 0.0877
DEBUG - 2022-08-09 03:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:49 --> Total execution time: 0.0714
DEBUG - 2022-08-09 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:20:58 --> Total execution time: 0.0760
DEBUG - 2022-08-09 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:21:16 --> Total execution time: 0.0930
DEBUG - 2022-08-09 03:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:21:57 --> Total execution time: 0.0807
DEBUG - 2022-08-09 03:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:06 --> Total execution time: 0.0827
DEBUG - 2022-08-09 03:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:13 --> Total execution time: 0.0828
DEBUG - 2022-08-09 03:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:14 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:14 --> Total execution time: 0.0809
DEBUG - 2022-08-09 03:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:26 --> Total execution time: 0.0765
DEBUG - 2022-08-09 03:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:50 --> Total execution time: 0.0948
DEBUG - 2022-08-09 03:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:22:53 --> Total execution time: 0.0802
DEBUG - 2022-08-09 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:53:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:23:33 --> Total execution time: 0.0536
DEBUG - 2022-08-09 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:23:33 --> Total execution time: 0.0529
DEBUG - 2022-08-09 03:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:23:49 --> Total execution time: 0.0856
DEBUG - 2022-08-09 03:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:23:54 --> Total execution time: 0.0967
DEBUG - 2022-08-09 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:04 --> Total execution time: 0.1130
DEBUG - 2022-08-09 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 03:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:05 --> Total execution time: 0.0792
DEBUG - 2022-08-09 03:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:53 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:53 --> Total execution time: 0.0500
DEBUG - 2022-08-09 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:56 --> Total execution time: 0.0775
DEBUG - 2022-08-09 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:54:59 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:00 --> Total execution time: 0.0699
DEBUG - 2022-08-09 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:18 --> Total execution time: 0.0830
DEBUG - 2022-08-09 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:20 --> Total execution time: 0.1021
DEBUG - 2022-08-09 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:55:22 --> Total execution time: 0.0760
DEBUG - 2022-08-09 03:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:55:24 --> Total execution time: 0.1160
DEBUG - 2022-08-09 03:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:55:24 --> Total execution time: 0.1817
DEBUG - 2022-08-09 03:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:43 --> Total execution time: 0.0907
DEBUG - 2022-08-09 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:47 --> Total execution time: 0.0787
DEBUG - 2022-08-09 03:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:50 --> Total execution time: 0.0945
DEBUG - 2022-08-09 03:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:52 --> Total execution time: 0.0806
DEBUG - 2022-08-09 03:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:54 --> Total execution time: 0.0514
DEBUG - 2022-08-09 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:57 --> Total execution time: 0.2062
DEBUG - 2022-08-09 03:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:57 --> Total execution time: 0.0747
DEBUG - 2022-08-09 03:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:06 --> Total execution time: 0.0594
DEBUG - 2022-08-09 03:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:28 --> Total execution time: 0.1298
DEBUG - 2022-08-09 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:39 --> Total execution time: 0.0811
DEBUG - 2022-08-09 03:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:53 --> Total execution time: 0.0896
DEBUG - 2022-08-09 03:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:27:00 --> Total execution time: 0.0982
DEBUG - 2022-08-09 03:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:27:14 --> Total execution time: 0.0790
DEBUG - 2022-08-09 03:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:27:27 --> Total execution time: 0.0522
DEBUG - 2022-08-09 03:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:27:35 --> Total execution time: 0.0901
DEBUG - 2022-08-09 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:27:58 --> Total execution time: 0.0748
DEBUG - 2022-08-09 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:20 --> Total execution time: 0.2279
DEBUG - 2022-08-09 03:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:37 --> Total execution time: 0.0777
DEBUG - 2022-08-09 03:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:37 --> Total execution time: 0.0657
DEBUG - 2022-08-09 03:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:38 --> Total execution time: 0.0459
DEBUG - 2022-08-09 03:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:39 --> Total execution time: 0.0620
DEBUG - 2022-08-09 03:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:40 --> Total execution time: 0.0557
DEBUG - 2022-08-09 03:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:40 --> Total execution time: 0.0534
DEBUG - 2022-08-09 03:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:41 --> Total execution time: 0.0501
DEBUG - 2022-08-09 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:42 --> Total execution time: 0.0760
DEBUG - 2022-08-09 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:42 --> Total execution time: 0.0503
DEBUG - 2022-08-09 03:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:42 --> Total execution time: 0.0515
DEBUG - 2022-08-09 03:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:42 --> Total execution time: 0.0469
DEBUG - 2022-08-09 03:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 03:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:29:43 --> Total execution time: 0.0578
DEBUG - 2022-08-09 03:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 03:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 03:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 03:59:58 --> Total execution time: 0.0726
DEBUG - 2022-08-09 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:30:02 --> Total execution time: 0.1474
DEBUG - 2022-08-09 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:00:04 --> Total execution time: 0.0946
DEBUG - 2022-08-09 04:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:00:04 --> Total execution time: 0.2426
DEBUG - 2022-08-09 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:00:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:00:49 --> Total execution time: 0.0877
DEBUG - 2022-08-09 04:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:30:52 --> Total execution time: 2.2799
DEBUG - 2022-08-09 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:00:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 04:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:00:56 --> Total execution time: 0.1781
DEBUG - 2022-08-09 04:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:01:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:31:44 --> Total execution time: 0.2095
DEBUG - 2022-08-09 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:31:45 --> Total execution time: 0.2078
DEBUG - 2022-08-09 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:31:48 --> Total execution time: 0.0852
DEBUG - 2022-08-09 04:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:32:17 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:32:17 --> Total execution time: 0.0866
DEBUG - 2022-08-09 04:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:02:53 --> Total execution time: 0.0788
DEBUG - 2022-08-09 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:03:01 --> Total execution time: 0.1340
DEBUG - 2022-08-09 04:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:33:30 --> Total execution time: 0.0789
DEBUG - 2022-08-09 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:33:57 --> Total execution time: 0.1091
DEBUG - 2022-08-09 04:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:34:10 --> Total execution time: 0.0772
DEBUG - 2022-08-09 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:04:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 04:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:04:13 --> 404 Page Not Found: Login/index
DEBUG - 2022-08-09 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:34:24 --> Total execution time: 0.0825
DEBUG - 2022-08-09 04:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:34:25 --> Total execution time: 0.0847
DEBUG - 2022-08-09 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:34:51 --> Total execution time: 0.1082
DEBUG - 2022-08-09 04:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:34:52 --> Total execution time: 0.2557
DEBUG - 2022-08-09 04:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:01 --> Total execution time: 0.2839
DEBUG - 2022-08-09 04:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:08 --> Total execution time: 0.1196
DEBUG - 2022-08-09 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:16 --> Total execution time: 0.1156
DEBUG - 2022-08-09 04:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:17 --> Total execution time: 0.0680
DEBUG - 2022-08-09 04:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:20 --> Total execution time: 0.0905
DEBUG - 2022-08-09 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:34 --> Total execution time: 0.0773
DEBUG - 2022-08-09 04:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:39 --> Total execution time: 0.0483
DEBUG - 2022-08-09 04:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:49 --> Total execution time: 0.0921
DEBUG - 2022-08-09 04:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:52 --> Total execution time: 0.1437
DEBUG - 2022-08-09 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:35:53 --> Total execution time: 0.1071
DEBUG - 2022-08-09 04:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:00 --> Total execution time: 0.0867
DEBUG - 2022-08-09 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:31 --> Total execution time: 0.0854
DEBUG - 2022-08-09 04:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:43 --> Total execution time: 0.0794
DEBUG - 2022-08-09 04:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:47 --> Total execution time: 0.1030
DEBUG - 2022-08-09 04:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:50 --> Total execution time: 0.1015
DEBUG - 2022-08-09 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:36:58 --> Total execution time: 0.0768
DEBUG - 2022-08-09 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:39:39 --> Total execution time: 0.1473
DEBUG - 2022-08-09 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:43:38 --> Total execution time: 0.3088
DEBUG - 2022-08-09 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:43:38 --> Total execution time: 0.1022
DEBUG - 2022-08-09 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:43:43 --> Total execution time: 0.0875
DEBUG - 2022-08-09 04:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:43:56 --> Total execution time: 0.0832
DEBUG - 2022-08-09 04:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:09 --> Total execution time: 0.1045
DEBUG - 2022-08-09 04:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:16 --> Total execution time: 0.0952
DEBUG - 2022-08-09 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:22 --> Total execution time: 0.0555
DEBUG - 2022-08-09 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:30 --> Total execution time: 0.0529
DEBUG - 2022-08-09 04:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:30 --> Total execution time: 0.0748
DEBUG - 2022-08-09 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:31 --> Total execution time: 0.0764
DEBUG - 2022-08-09 04:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:48:52 --> Total execution time: 0.3268
DEBUG - 2022-08-09 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:49:53 --> Total execution time: 0.0861
DEBUG - 2022-08-09 04:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:49:58 --> Total execution time: 0.1056
DEBUG - 2022-08-09 04:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:54:05 --> Total execution time: 0.5069
DEBUG - 2022-08-09 04:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:57:00 --> Total execution time: 0.2747
DEBUG - 2022-08-09 04:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:57:37 --> Total execution time: 0.0978
DEBUG - 2022-08-09 04:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:57:52 --> Total execution time: 0.0890
DEBUG - 2022-08-09 04:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:59:09 --> Total execution time: 0.0954
DEBUG - 2022-08-09 04:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:00:26 --> Total execution time: 0.0846
DEBUG - 2022-08-09 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:00:44 --> Total execution time: 0.0953
DEBUG - 2022-08-09 04:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:01:02 --> Total execution time: 0.0857
DEBUG - 2022-08-09 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:02:32 --> Total execution time: 0.1036
DEBUG - 2022-08-09 04:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:02:38 --> Total execution time: 0.0751
DEBUG - 2022-08-09 04:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:02:46 --> Total execution time: 0.0827
DEBUG - 2022-08-09 04:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:02:59 --> Total execution time: 0.1165
DEBUG - 2022-08-09 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:06 --> Total execution time: 0.1195
DEBUG - 2022-08-09 04:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:33:20 --> Total execution time: 0.0903
DEBUG - 2022-08-09 04:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:25 --> Total execution time: 0.0804
DEBUG - 2022-08-09 04:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:30 --> Total execution time: 0.1193
DEBUG - 2022-08-09 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:31 --> Total execution time: 0.1522
DEBUG - 2022-08-09 04:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:35 --> Total execution time: 0.1117
DEBUG - 2022-08-09 04:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:39 --> Total execution time: 0.1890
DEBUG - 2022-08-09 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:03:54 --> Total execution time: 0.0769
DEBUG - 2022-08-09 04:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:00 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:04:00 --> Total execution time: 0.0594
DEBUG - 2022-08-09 04:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:04:39 --> Total execution time: 0.1653
DEBUG - 2022-08-09 04:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:04:39 --> Total execution time: 0.0797
DEBUG - 2022-08-09 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:05:19 --> Total execution time: 0.2525
DEBUG - 2022-08-09 04:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:05:34 --> Total execution time: 0.1145
DEBUG - 2022-08-09 04:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:05:39 --> Total execution time: 0.0865
DEBUG - 2022-08-09 04:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:05:49 --> Total execution time: 0.0825
DEBUG - 2022-08-09 04:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:05:53 --> Total execution time: 0.0825
DEBUG - 2022-08-09 04:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:06:00 --> Total execution time: 0.1698
DEBUG - 2022-08-09 04:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:06:56 --> Total execution time: 0.0803
DEBUG - 2022-08-09 04:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:07:15 --> Total execution time: 0.0880
DEBUG - 2022-08-09 04:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:07:21 --> Total execution time: 0.0883
DEBUG - 2022-08-09 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:08:07 --> Total execution time: 0.0908
DEBUG - 2022-08-09 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:08:17 --> Total execution time: 0.1145
DEBUG - 2022-08-09 04:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:08:19 --> Total execution time: 0.0813
DEBUG - 2022-08-09 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:08:24 --> Total execution time: 0.0767
DEBUG - 2022-08-09 04:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:08:43 --> Total execution time: 0.0780
DEBUG - 2022-08-09 04:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:01 --> Total execution time: 0.1211
DEBUG - 2022-08-09 04:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:39 --> Total execution time: 0.0789
DEBUG - 2022-08-09 04:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:42 --> Total execution time: 0.0896
DEBUG - 2022-08-09 04:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:45 --> Total execution time: 0.0886
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:56 --> Total execution time: 0.0974
DEBUG - 2022-08-09 04:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:11:40 --> Total execution time: 0.0563
DEBUG - 2022-08-09 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:12:46 --> Total execution time: 0.0760
DEBUG - 2022-08-09 04:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:13:01 --> Total execution time: 0.0807
DEBUG - 2022-08-09 04:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:13:04 --> Total execution time: 0.0863
DEBUG - 2022-08-09 04:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:13:06 --> Total execution time: 0.0892
DEBUG - 2022-08-09 04:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:13:13 --> Total execution time: 0.0779
DEBUG - 2022-08-09 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:18:29 --> Total execution time: 0.1637
DEBUG - 2022-08-09 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:18:39 --> Total execution time: 0.0839
DEBUG - 2022-08-09 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:18:40 --> Total execution time: 0.0618
DEBUG - 2022-08-09 04:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:18:47 --> Total execution time: 0.0669
DEBUG - 2022-08-09 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:18:59 --> Total execution time: 0.0752
DEBUG - 2022-08-09 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:19:23 --> Total execution time: 0.0718
DEBUG - 2022-08-09 04:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:19:29 --> Total execution time: 0.0646
DEBUG - 2022-08-09 04:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:19:31 --> Total execution time: 0.0901
DEBUG - 2022-08-09 04:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:19:44 --> Total execution time: 0.0854
DEBUG - 2022-08-09 04:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:19:49 --> Total execution time: 0.0917
DEBUG - 2022-08-09 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:20:01 --> Total execution time: 0.0774
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:28 --> Total execution time: 0.1336
DEBUG - 2022-08-09 04:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:36 --> Total execution time: 0.0828
DEBUG - 2022-08-09 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:41 --> Total execution time: 0.0898
DEBUG - 2022-08-09 04:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:47 --> Total execution time: 0.1379
DEBUG - 2022-08-09 04:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:51 --> Total execution time: 0.0973
DEBUG - 2022-08-09 04:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:56 --> Total execution time: 0.0944
DEBUG - 2022-08-09 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:22:57 --> Total execution time: 0.0866
DEBUG - 2022-08-09 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:26:15 --> Total execution time: 0.2843
DEBUG - 2022-08-09 04:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:26:22 --> Total execution time: 0.0750
DEBUG - 2022-08-09 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:30:02 --> Total execution time: 0.2293
DEBUG - 2022-08-09 05:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:30:55 --> Total execution time: 0.0820
DEBUG - 2022-08-09 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:32:05 --> Total execution time: 0.0836
DEBUG - 2022-08-09 05:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:32:48 --> Total execution time: 0.0847
DEBUG - 2022-08-09 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:32:50 --> Total execution time: 0.0819
DEBUG - 2022-08-09 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:01 --> Total execution time: 0.1086
DEBUG - 2022-08-09 05:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:14 --> Total execution time: 0.0932
DEBUG - 2022-08-09 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:20 --> Total execution time: 0.0853
DEBUG - 2022-08-09 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:25 --> Total execution time: 0.1139
DEBUG - 2022-08-09 05:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:42 --> Total execution time: 0.0812
DEBUG - 2022-08-09 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:05:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:35:38 --> Total execution time: 0.0558
DEBUG - 2022-08-09 05:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:05:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:35:39 --> Total execution time: 0.0490
DEBUG - 2022-08-09 05:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:35:44 --> Total execution time: 0.0529
DEBUG - 2022-08-09 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:35:54 --> Total execution time: 0.0819
DEBUG - 2022-08-09 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:02 --> Total execution time: 0.1052
DEBUG - 2022-08-09 05:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:10 --> Total execution time: 0.1042
DEBUG - 2022-08-09 05:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:10 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:11 --> Total execution time: 0.0798
DEBUG - 2022-08-09 05:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:17 --> Total execution time: 0.0492
DEBUG - 2022-08-09 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:36:19 --> Total execution time: 0.0757
DEBUG - 2022-08-09 05:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:09:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:39:35 --> Total execution time: 0.3180
DEBUG - 2022-08-09 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:39:37 --> Total execution time: 0.1745
DEBUG - 2022-08-09 05:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:40:37 --> Total execution time: 0.1164
DEBUG - 2022-08-09 05:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:40:51 --> Total execution time: 0.1114
DEBUG - 2022-08-09 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:40:59 --> Total execution time: 0.2893
DEBUG - 2022-08-09 05:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:01 --> Total execution time: 0.0959
DEBUG - 2022-08-09 05:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:03 --> Total execution time: 0.1134
DEBUG - 2022-08-09 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:06 --> Total execution time: 0.0814
DEBUG - 2022-08-09 05:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:08 --> Total execution time: 0.1069
DEBUG - 2022-08-09 05:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:11 --> Total execution time: 0.1177
DEBUG - 2022-08-09 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:17 --> Total execution time: 0.0939
DEBUG - 2022-08-09 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:21 --> Total execution time: 0.0819
DEBUG - 2022-08-09 05:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:34 --> Total execution time: 0.0940
DEBUG - 2022-08-09 05:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:40 --> Total execution time: 0.0813
DEBUG - 2022-08-09 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:41 --> Total execution time: 0.1556
DEBUG - 2022-08-09 05:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:41:53 --> Total execution time: 0.0955
DEBUG - 2022-08-09 05:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:02 --> Total execution time: 0.1084
DEBUG - 2022-08-09 05:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:04 --> Total execution time: 0.0876
DEBUG - 2022-08-09 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:10 --> Total execution time: 0.0994
DEBUG - 2022-08-09 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:10 --> Total execution time: 0.0854
DEBUG - 2022-08-09 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:19 --> Total execution time: 0.0802
DEBUG - 2022-08-09 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:20 --> Total execution time: 0.0828
DEBUG - 2022-08-09 05:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:28 --> Total execution time: 0.0954
DEBUG - 2022-08-09 05:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:35 --> Total execution time: 0.0881
DEBUG - 2022-08-09 05:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:42 --> Total execution time: 0.1060
DEBUG - 2022-08-09 05:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:48 --> Total execution time: 0.0831
DEBUG - 2022-08-09 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:42:53 --> Total execution time: 0.1015
DEBUG - 2022-08-09 05:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:12 --> Total execution time: 0.0811
DEBUG - 2022-08-09 05:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:15 --> Total execution time: 0.0845
DEBUG - 2022-08-09 05:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:30 --> Total execution time: 0.0909
DEBUG - 2022-08-09 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:30 --> Total execution time: 0.0770
DEBUG - 2022-08-09 05:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:32 --> Total execution time: 0.0816
DEBUG - 2022-08-09 05:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:41 --> Total execution time: 0.1204
DEBUG - 2022-08-09 05:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:45 --> Total execution time: 0.0856
DEBUG - 2022-08-09 05:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:48 --> Total execution time: 0.1090
DEBUG - 2022-08-09 05:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:51 --> Total execution time: 0.0774
DEBUG - 2022-08-09 05:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:53 --> Total execution time: 0.1231
DEBUG - 2022-08-09 05:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:43:58 --> Total execution time: 0.1495
DEBUG - 2022-08-09 05:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:44:03 --> Total execution time: 0.0899
DEBUG - 2022-08-09 05:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:47:41 --> Total execution time: 3.3698
DEBUG - 2022-08-09 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:17:53 --> Total execution time: 0.1417
DEBUG - 2022-08-09 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:17:55 --> Total execution time: 0.2840
DEBUG - 2022-08-09 05:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:17:56 --> Total execution time: 1.4798
DEBUG - 2022-08-09 05:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:49:44 --> Total execution time: 0.0517
DEBUG - 2022-08-09 05:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:20:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:08 --> Total execution time: 1.9356
DEBUG - 2022-08-09 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:20:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:23 --> Total execution time: 0.0581
DEBUG - 2022-08-09 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:23 --> Total execution time: 0.0547
DEBUG - 2022-08-09 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:33 --> Total execution time: 0.0812
DEBUG - 2022-08-09 05:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 15:50:35 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 15:50:35 --> Total execution time: 0.2642
DEBUG - 2022-08-09 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:44 --> Total execution time: 0.0757
DEBUG - 2022-08-09 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:50:45 --> Total execution time: 0.0854
DEBUG - 2022-08-09 05:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:51:30 --> Total execution time: 0.0571
DEBUG - 2022-08-09 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:51:47 --> Total execution time: 0.0856
DEBUG - 2022-08-09 05:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:51:49 --> Total execution time: 0.0925
DEBUG - 2022-08-09 05:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:51:58 --> Total execution time: 1.6787
DEBUG - 2022-08-09 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:01 --> Total execution time: 0.0825
DEBUG - 2022-08-09 05:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:06 --> Total execution time: 0.1077
DEBUG - 2022-08-09 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:09 --> Total execution time: 0.0796
DEBUG - 2022-08-09 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:11 --> Total execution time: 0.1050
DEBUG - 2022-08-09 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:15 --> Total execution time: 0.0880
DEBUG - 2022-08-09 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:16 --> Total execution time: 0.1295
DEBUG - 2022-08-09 05:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:17 --> Total execution time: 0.1179
DEBUG - 2022-08-09 05:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:52:18 --> Total execution time: 0.1131
DEBUG - 2022-08-09 05:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:53:09 --> Total execution time: 0.0906
DEBUG - 2022-08-09 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:53:10 --> Total execution time: 0.2187
DEBUG - 2022-08-09 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:53:13 --> Total execution time: 0.0753
DEBUG - 2022-08-09 05:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:53:20 --> Total execution time: 0.0856
DEBUG - 2022-08-09 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:53:27 --> Total execution time: 0.1019
DEBUG - 2022-08-09 05:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:54:20 --> Total execution time: 0.0928
DEBUG - 2022-08-09 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:54:25 --> Total execution time: 0.1203
DEBUG - 2022-08-09 05:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:24:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:54:27 --> Total execution time: 0.0913
DEBUG - 2022-08-09 05:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:25:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:55:19 --> Total execution time: 0.2116
DEBUG - 2022-08-09 05:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:00 --> Total execution time: 0.2363
DEBUG - 2022-08-09 05:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:05 --> Total execution time: 0.1028
DEBUG - 2022-08-09 05:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:10 --> Total execution time: 0.0711
DEBUG - 2022-08-09 05:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:13 --> Total execution time: 0.0797
DEBUG - 2022-08-09 05:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:16 --> Total execution time: 0.0794
DEBUG - 2022-08-09 05:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:24 --> Total execution time: 0.0737
DEBUG - 2022-08-09 05:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:29 --> Total execution time: 0.2034
DEBUG - 2022-08-09 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:37 --> Total execution time: 0.1355
DEBUG - 2022-08-09 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:41 --> Total execution time: 0.1062
DEBUG - 2022-08-09 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:41 --> Total execution time: 0.0931
DEBUG - 2022-08-09 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:42 --> Total execution time: 0.0782
DEBUG - 2022-08-09 05:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:43 --> Total execution time: 0.1585
DEBUG - 2022-08-09 05:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:46 --> Total execution time: 0.1073
DEBUG - 2022-08-09 05:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:48 --> Total execution time: 0.0885
DEBUG - 2022-08-09 05:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:50 --> Total execution time: 0.1084
DEBUG - 2022-08-09 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:56:52 --> Total execution time: 0.0907
DEBUG - 2022-08-09 05:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:59:30 --> Total execution time: 0.0771
DEBUG - 2022-08-09 05:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:59:31 --> Total execution time: 0.0876
DEBUG - 2022-08-09 05:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:29:46 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:59:46 --> Total execution time: 0.0874
DEBUG - 2022-08-09 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:00:27 --> Total execution time: 0.1160
DEBUG - 2022-08-09 05:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:00:38 --> Total execution time: 0.2135
DEBUG - 2022-08-09 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:30:53 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:00:53 --> Total execution time: 0.0552
DEBUG - 2022-08-09 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:30:53 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:00:53 --> Total execution time: 0.0505
DEBUG - 2022-08-09 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:03 --> Total execution time: 0.0495
DEBUG - 2022-08-09 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:12 --> Total execution time: 0.0796
DEBUG - 2022-08-09 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:27 --> Total execution time: 0.0900
DEBUG - 2022-08-09 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:47 --> Total execution time: 0.1417
DEBUG - 2022-08-09 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:52 --> Total execution time: 0.1089
DEBUG - 2022-08-09 05:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:31:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:01:59 --> Total execution time: 0.0744
DEBUG - 2022-08-09 05:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:33:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:03:00 --> Total execution time: 0.5421
DEBUG - 2022-08-09 05:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:05:03 --> Total execution time: 0.1796
DEBUG - 2022-08-09 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:42:03 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:12:03 --> Total execution time: 0.1521
DEBUG - 2022-08-09 05:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:42:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:12:39 --> Total execution time: 0.0611
DEBUG - 2022-08-09 05:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:44:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:14:57 --> Total execution time: 0.1170
DEBUG - 2022-08-09 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:17:52 --> Total execution time: 0.3123
DEBUG - 2022-08-09 05:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:20:14 --> Total execution time: 0.1082
DEBUG - 2022-08-09 05:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:20:36 --> Total execution time: 0.0778
DEBUG - 2022-08-09 05:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:20:40 --> Total execution time: 0.1018
DEBUG - 2022-08-09 05:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:20:51 --> Total execution time: 0.0854
DEBUG - 2022-08-09 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:21:00 --> Total execution time: 0.1366
DEBUG - 2022-08-09 05:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:21:50 --> Total execution time: 0.0992
DEBUG - 2022-08-09 05:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:21:57 --> Total execution time: 0.0922
DEBUG - 2022-08-09 05:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:22:00 --> Total execution time: 0.0997
DEBUG - 2022-08-09 05:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:22:17 --> Total execution time: 0.1019
DEBUG - 2022-08-09 05:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:52:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:22:18 --> Total execution time: 0.0525
DEBUG - 2022-08-09 05:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:22:20 --> Total execution time: 0.1261
DEBUG - 2022-08-09 05:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:52:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:22:43 --> Total execution time: 0.1703
DEBUG - 2022-08-09 05:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:36 --> Total execution time: 0.0798
DEBUG - 2022-08-09 05:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:44 --> Total execution time: 0.0828
DEBUG - 2022-08-09 05:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:46 --> Total execution time: 0.1161
DEBUG - 2022-08-09 05:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:49 --> Total execution time: 0.1132
DEBUG - 2022-08-09 05:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:52 --> Total execution time: 0.0808
DEBUG - 2022-08-09 05:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:55 --> Total execution time: 0.1585
DEBUG - 2022-08-09 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:57 --> Total execution time: 0.1124
DEBUG - 2022-08-09 05:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:00 --> Total execution time: 0.1518
DEBUG - 2022-08-09 05:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:02 --> Total execution time: 0.0915
DEBUG - 2022-08-09 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:04 --> Total execution time: 0.0793
DEBUG - 2022-08-09 05:54:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:05 --> Total execution time: 0.0986
DEBUG - 2022-08-09 05:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:09 --> Total execution time: 0.0910
DEBUG - 2022-08-09 05:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 05:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:09 --> Total execution time: 0.0811
DEBUG - 2022-08-09 05:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:12 --> Total execution time: 0.0831
DEBUG - 2022-08-09 05:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:17 --> Total execution time: 0.0967
DEBUG - 2022-08-09 05:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:56 --> Total execution time: 1.9108
DEBUG - 2022-08-09 05:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:55:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 05:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:55:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 05:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:25:06 --> Total execution time: 0.0757
DEBUG - 2022-08-09 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:29:30 --> Total execution time: 0.2797
DEBUG - 2022-08-09 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:30:03 --> Total execution time: 0.0819
DEBUG - 2022-08-09 06:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:31:14 --> Total execution time: 0.2144
DEBUG - 2022-08-09 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:31:31 --> Total execution time: 0.1084
DEBUG - 2022-08-09 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:32:01 --> Total execution time: 0.4952
DEBUG - 2022-08-09 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:32:07 --> Total execution time: 0.1291
DEBUG - 2022-08-09 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:32:09 --> Total execution time: 0.0826
DEBUG - 2022-08-09 06:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:00 --> Total execution time: 0.0485
DEBUG - 2022-08-09 06:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:50 --> Total execution time: 0.0497
DEBUG - 2022-08-09 06:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:57 --> Total execution time: 0.0837
DEBUG - 2022-08-09 06:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:07 --> Total execution time: 0.1176
DEBUG - 2022-08-09 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:12 --> Total execution time: 0.0881
DEBUG - 2022-08-09 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:15 --> Total execution time: 0.0950
DEBUG - 2022-08-09 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:19 --> Total execution time: 0.1170
DEBUG - 2022-08-09 06:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:25 --> Total execution time: 0.1054
DEBUG - 2022-08-09 06:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:37 --> Total execution time: 0.0563
DEBUG - 2022-08-09 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:38 --> Total execution time: 0.0518
DEBUG - 2022-08-09 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:41 --> Total execution time: 0.0515
DEBUG - 2022-08-09 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:41 --> Total execution time: 0.0516
DEBUG - 2022-08-09 06:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:42 --> Total execution time: 0.0556
DEBUG - 2022-08-09 06:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:04:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:43 --> Total execution time: 0.0825
DEBUG - 2022-08-09 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:05:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:35:02 --> Total execution time: 0.0674
DEBUG - 2022-08-09 06:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:36:59 --> Total execution time: 0.0502
DEBUG - 2022-08-09 06:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:02 --> Total execution time: 0.0765
DEBUG - 2022-08-09 06:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:10 --> Total execution time: 0.1220
DEBUG - 2022-08-09 06:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:16 --> Total execution time: 0.1264
DEBUG - 2022-08-09 06:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:35 --> Total execution time: 0.0632
DEBUG - 2022-08-09 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:07:46 --> Total execution time: 0.0769
DEBUG - 2022-08-09 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:07:47 --> Total execution time: 0.0848
DEBUG - 2022-08-09 06:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:07:47 --> Total execution time: 0.1860
DEBUG - 2022-08-09 06:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:10:02 --> Total execution time: 0.1740
DEBUG - 2022-08-09 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:10:03 --> Total execution time: 0.0825
DEBUG - 2022-08-09 06:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:10:03 --> Total execution time: 0.1794
DEBUG - 2022-08-09 06:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:10:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:40:27 --> Total execution time: 0.0821
DEBUG - 2022-08-09 06:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:01 --> Total execution time: 0.0849
DEBUG - 2022-08-09 06:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:03 --> Total execution time: 0.0887
DEBUG - 2022-08-09 06:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:03 --> Total execution time: 0.1948
DEBUG - 2022-08-09 06:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:08 --> Total execution time: 0.0809
DEBUG - 2022-08-09 06:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:10 --> Total execution time: 0.0851
DEBUG - 2022-08-09 06:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:11:10 --> Total execution time: 0.1613
DEBUG - 2022-08-09 06:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:13 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:41:13 --> Total execution time: 0.2121
DEBUG - 2022-08-09 06:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:11:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:41:27 --> Total execution time: 0.0803
DEBUG - 2022-08-09 06:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:14:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:44:35 --> Total execution time: 0.1276
DEBUG - 2022-08-09 06:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:44:43 --> Total execution time: 0.0529
DEBUG - 2022-08-09 06:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:44:49 --> Total execution time: 0.1058
DEBUG - 2022-08-09 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:44:55 --> Total execution time: 0.1144
DEBUG - 2022-08-09 06:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:10 --> Total execution time: 0.0839
DEBUG - 2022-08-09 06:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:11 --> Total execution time: 0.0851
DEBUG - 2022-08-09 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:18 --> Total execution time: 0.0969
DEBUG - 2022-08-09 06:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:19 --> Total execution time: 0.0799
DEBUG - 2022-08-09 06:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:23 --> Total execution time: 0.0991
DEBUG - 2022-08-09 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:27 --> Total execution time: 0.0844
DEBUG - 2022-08-09 06:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:28 --> Total execution time: 0.2048
DEBUG - 2022-08-09 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:29 --> Total execution time: 0.2249
DEBUG - 2022-08-09 06:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:42 --> Total execution time: 0.0907
DEBUG - 2022-08-09 06:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:45:52 --> Total execution time: 0.0944
DEBUG - 2022-08-09 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:00 --> Total execution time: 0.1114
DEBUG - 2022-08-09 06:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:00 --> Total execution time: 0.0901
DEBUG - 2022-08-09 06:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:04 --> Total execution time: 0.0969
DEBUG - 2022-08-09 06:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:06 --> Total execution time: 0.1436
DEBUG - 2022-08-09 06:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:09 --> Total execution time: 0.1010
DEBUG - 2022-08-09 06:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:11 --> Total execution time: 0.0950
DEBUG - 2022-08-09 06:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:14 --> Total execution time: 0.0549
DEBUG - 2022-08-09 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:18 --> Total execution time: 0.1991
DEBUG - 2022-08-09 06:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:18 --> Total execution time: 0.2469
DEBUG - 2022-08-09 06:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:22 --> Total execution time: 0.0994
DEBUG - 2022-08-09 06:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:25 --> Total execution time: 0.0754
DEBUG - 2022-08-09 06:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:27 --> Total execution time: 0.0857
DEBUG - 2022-08-09 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:31 --> Total execution time: 0.1541
DEBUG - 2022-08-09 06:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:54 --> Total execution time: 0.0806
DEBUG - 2022-08-09 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:46:57 --> Total execution time: 0.0788
DEBUG - 2022-08-09 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:04 --> Total execution time: 0.0900
DEBUG - 2022-08-09 06:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:08 --> Total execution time: 0.1107
DEBUG - 2022-08-09 06:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:41 --> Total execution time: 0.0838
DEBUG - 2022-08-09 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:42 --> Total execution time: 0.0634
DEBUG - 2022-08-09 06:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:43 --> Total execution time: 0.0920
DEBUG - 2022-08-09 06:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:17:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:47:44 --> Total execution time: 0.0800
DEBUG - 2022-08-09 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:21:32 --> Total execution time: 0.2596
DEBUG - 2022-08-09 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:21:33 --> Total execution time: 0.0861
DEBUG - 2022-08-09 06:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:21:33 --> Total execution time: 0.1884
DEBUG - 2022-08-09 06:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:22:05 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 06:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:22:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:52:48 --> Total execution time: 0.1152
DEBUG - 2022-08-09 06:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:54:02 --> Total execution time: 0.1183
DEBUG - 2022-08-09 06:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:24:28 --> Total execution time: 0.0769
DEBUG - 2022-08-09 06:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:24:29 --> Total execution time: 0.0866
DEBUG - 2022-08-09 06:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:24:29 --> Total execution time: 0.1872
DEBUG - 2022-08-09 06:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:13 --> Total execution time: 0.0757
DEBUG - 2022-08-09 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:14 --> Total execution time: 0.0907
DEBUG - 2022-08-09 06:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:14 --> Total execution time: 0.1414
DEBUG - 2022-08-09 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:16 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:55:16 --> Total execution time: 0.0862
DEBUG - 2022-08-09 06:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:57 --> Total execution time: 0.0790
DEBUG - 2022-08-09 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:58 --> Total execution time: 0.0947
DEBUG - 2022-08-09 06:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:25:59 --> Total execution time: 0.1773
DEBUG - 2022-08-09 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:14 --> Total execution time: 0.0812
DEBUG - 2022-08-09 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:19 --> Total execution time: 0.0739
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:22 --> Total execution time: 0.0783
DEBUG - 2022-08-09 06:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:36 --> Total execution time: 0.0909
DEBUG - 2022-08-09 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:42 --> Total execution time: 0.0994
DEBUG - 2022-08-09 06:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:43 --> Total execution time: 0.2049
DEBUG - 2022-08-09 06:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:56:50 --> Total execution time: 0.1301
DEBUG - 2022-08-09 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:27:05 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:57:05 --> Total execution time: 0.0569
DEBUG - 2022-08-09 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:27:41 --> Total execution time: 0.0848
DEBUG - 2022-08-09 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:27:43 --> Total execution time: 0.0872
DEBUG - 2022-08-09 06:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:27:43 --> Total execution time: 0.1802
DEBUG - 2022-08-09 06:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:58:23 --> Total execution time: 0.0770
DEBUG - 2022-08-09 06:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:58:29 --> Total execution time: 0.0804
DEBUG - 2022-08-09 06:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:29:16 --> Total execution time: 0.0837
DEBUG - 2022-08-09 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:29:18 --> Total execution time: 0.0903
DEBUG - 2022-08-09 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:29:18 --> Total execution time: 0.1859
DEBUG - 2022-08-09 06:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:30:50 --> Total execution time: 0.1815
DEBUG - 2022-08-09 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:30:52 --> Total execution time: 0.1007
DEBUG - 2022-08-09 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:30:52 --> Total execution time: 0.1017
DEBUG - 2022-08-09 06:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:06 --> Total execution time: 0.0758
DEBUG - 2022-08-09 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:07 --> Total execution time: 0.1211
DEBUG - 2022-08-09 06:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:08 --> Total execution time: 0.1753
DEBUG - 2022-08-09 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:29 --> Total execution time: 0.0891
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:31 --> Total execution time: 0.0922
DEBUG - 2022-08-09 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:31 --> Total execution time: 0.2107
DEBUG - 2022-08-09 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:46 --> Total execution time: 0.2173
DEBUG - 2022-08-09 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:47 --> Total execution time: 0.0830
DEBUG - 2022-08-09 06:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:31:48 --> Total execution time: 0.1636
DEBUG - 2022-08-09 06:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:18 --> Total execution time: 0.0887
DEBUG - 2022-08-09 06:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:19 --> Total execution time: 0.0926
DEBUG - 2022-08-09 06:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:19 --> Total execution time: 0.1842
DEBUG - 2022-08-09 06:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:51 --> Total execution time: 0.0793
DEBUG - 2022-08-09 06:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:52 --> Total execution time: 0.0834
DEBUG - 2022-08-09 06:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:32:52 --> Total execution time: 0.1789
DEBUG - 2022-08-09 06:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:03:52 --> Total execution time: 0.1151
DEBUG - 2022-08-09 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:03:56 --> Total execution time: 0.0714
DEBUG - 2022-08-09 06:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:34:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:34:30 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 06:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:27 --> Total execution time: 0.1963
DEBUG - 2022-08-09 06:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:34 --> Total execution time: 0.0522
DEBUG - 2022-08-09 06:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:37 --> Total execution time: 0.0525
DEBUG - 2022-08-09 06:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:39 --> Total execution time: 0.2075
DEBUG - 2022-08-09 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:46 --> Total execution time: 0.0851
DEBUG - 2022-08-09 06:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:50 --> Total execution time: 0.0744
DEBUG - 2022-08-09 06:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:54 --> Total execution time: 0.0525
DEBUG - 2022-08-09 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:35:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:05:55 --> Total execution time: 0.0497
DEBUG - 2022-08-09 06:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:06:07 --> Total execution time: 0.0517
DEBUG - 2022-08-09 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:06:35 --> Total execution time: 0.1917
DEBUG - 2022-08-09 06:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:06:39 --> Total execution time: 0.0645
DEBUG - 2022-08-09 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:47 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:06:47 --> Total execution time: 0.0759
DEBUG - 2022-08-09 06:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:36:51 --> Total execution time: 0.0878
DEBUG - 2022-08-09 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:36:52 --> Total execution time: 0.0756
DEBUG - 2022-08-09 06:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:36:52 --> Total execution time: 0.1735
DEBUG - 2022-08-09 06:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:37:11 --> Total execution time: 0.0893
DEBUG - 2022-08-09 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:37:13 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:07:13 --> Total execution time: 0.0787
DEBUG - 2022-08-09 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:37:13 --> Total execution time: 0.0915
DEBUG - 2022-08-09 06:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:37:13 --> Total execution time: 0.1917
DEBUG - 2022-08-09 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:27 --> Total execution time: 0.6327
DEBUG - 2022-08-09 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:31 --> Total execution time: 0.0896
DEBUG - 2022-08-09 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:35 --> Total execution time: 0.3589
DEBUG - 2022-08-09 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:37 --> Total execution time: 0.0555
DEBUG - 2022-08-09 06:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:43 --> Total execution time: 0.0828
DEBUG - 2022-08-09 06:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:10:04 --> Total execution time: 0.0957
DEBUG - 2022-08-09 06:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:40:08 --> Total execution time: 0.0918
DEBUG - 2022-08-09 06:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:40:10 --> Total execution time: 0.0978
DEBUG - 2022-08-09 06:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:40:10 --> Total execution time: 0.2158
DEBUG - 2022-08-09 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:42:24 --> 404 Page Not Found: Courses/esalestrix.in
DEBUG - 2022-08-09 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:13:02 --> Total execution time: 0.2549
DEBUG - 2022-08-09 06:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:45:07 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:15:07 --> Total execution time: 0.0728
DEBUG - 2022-08-09 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:45:47 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:15:47 --> Total execution time: 0.1602
DEBUG - 2022-08-09 06:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:15:47 --> Total execution time: 0.2391
DEBUG - 2022-08-09 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:02 --> Total execution time: 0.0912
DEBUG - 2022-08-09 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:02 --> Total execution time: 0.1762
DEBUG - 2022-08-09 06:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:03 --> Total execution time: 0.2270
DEBUG - 2022-08-09 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:09 --> Total execution time: 0.0926
DEBUG - 2022-08-09 06:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:13 --> Total execution time: 0.0838
DEBUG - 2022-08-09 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:14 --> Total execution time: 0.1517
DEBUG - 2022-08-09 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:14 --> Total execution time: 0.0845
DEBUG - 2022-08-09 06:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:14 --> Total execution time: 0.1684
DEBUG - 2022-08-09 06:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:15 --> Total execution time: 0.1023
DEBUG - 2022-08-09 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:46:15 --> Total execution time: 0.0902
DEBUG - 2022-08-09 06:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:42 --> Total execution time: 0.1154
DEBUG - 2022-08-09 06:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:51 --> Total execution time: 0.0979
DEBUG - 2022-08-09 06:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:16:58 --> Total execution time: 0.1291
DEBUG - 2022-08-09 06:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:27 --> Total execution time: 0.0937
DEBUG - 2022-08-09 06:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:29 --> Total execution time: 0.0972
DEBUG - 2022-08-09 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:31 --> Total execution time: 0.1118
DEBUG - 2022-08-09 06:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:39 --> Total execution time: 0.1243
DEBUG - 2022-08-09 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:43 --> Total execution time: 0.1266
DEBUG - 2022-08-09 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:47 --> Total execution time: 0.0954
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:49 --> Total execution time: 0.1008
DEBUG - 2022-08-09 06:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:17:52 --> Total execution time: 0.0885
DEBUG - 2022-08-09 06:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:21:46 --> Total execution time: 0.0791
DEBUG - 2022-08-09 06:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:21:51 --> Total execution time: 0.0759
DEBUG - 2022-08-09 06:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:51:59 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:21:59 --> Total execution time: 0.0568
DEBUG - 2022-08-09 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:52:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:22:02 --> Total execution time: 0.0543
DEBUG - 2022-08-09 06:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:06 --> Total execution time: 0.2502
DEBUG - 2022-08-09 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:20 --> Total execution time: 0.0872
DEBUG - 2022-08-09 06:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:49 --> Total execution time: 0.2229
DEBUG - 2022-08-09 06:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:25:14 --> Total execution time: 0.0800
DEBUG - 2022-08-09 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:26:02 --> Total execution time: 0.1284
DEBUG - 2022-08-09 06:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:26:13 --> Total execution time: 0.0760
DEBUG - 2022-08-09 06:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 06:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:29:31 --> Total execution time: 0.1182
DEBUG - 2022-08-09 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:59:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:29:43 --> Total execution time: 0.0901
DEBUG - 2022-08-09 06:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 06:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:29:48 --> Total execution time: 0.0850
DEBUG - 2022-08-09 06:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:29:53 --> Total execution time: 0.0874
DEBUG - 2022-08-09 06:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:00 --> Total execution time: 0.2212
DEBUG - 2022-08-09 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:02 --> Total execution time: 0.1056
DEBUG - 2022-08-09 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:03 --> Total execution time: 0.0792
DEBUG - 2022-08-09 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:11 --> Total execution time: 0.1186
DEBUG - 2022-08-09 07:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:11 --> Total execution time: 0.1256
DEBUG - 2022-08-09 07:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:26 --> Total execution time: 0.1671
DEBUG - 2022-08-09 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:30:46 --> Total execution time: 0.0838
DEBUG - 2022-08-09 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:01:13 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:31:13 --> Total execution time: 0.0890
DEBUG - 2022-08-09 07:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:33:37 --> Total execution time: 0.1385
DEBUG - 2022-08-09 07:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:16 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:34:16 --> Total execution time: 0.0565
DEBUG - 2022-08-09 07:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:34:42 --> Total execution time: 0.0560
DEBUG - 2022-08-09 07:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:04:47 --> Total execution time: 0.0815
DEBUG - 2022-08-09 07:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:04:48 --> Total execution time: 0.0761
DEBUG - 2022-08-09 07:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:04:49 --> Total execution time: 0.1748
DEBUG - 2022-08-09 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:35:11 --> Total execution time: 0.0846
DEBUG - 2022-08-09 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:40:05 --> Total execution time: 0.1364
DEBUG - 2022-08-09 07:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:43:17 --> Total execution time: 0.1204
DEBUG - 2022-08-09 07:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:43:38 --> Total execution time: 0.0751
DEBUG - 2022-08-09 07:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:43:39 --> Total execution time: 0.0974
DEBUG - 2022-08-09 07:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:52:32 --> Total execution time: 0.0865
DEBUG - 2022-08-09 07:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:52:48 --> Total execution time: 0.0896
DEBUG - 2022-08-09 07:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:52:53 --> Total execution time: 0.0864
DEBUG - 2022-08-09 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:52:56 --> Total execution time: 0.1086
DEBUG - 2022-08-09 07:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:53:04 --> Total execution time: 0.0932
DEBUG - 2022-08-09 07:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:53:07 --> Total execution time: 0.0871
DEBUG - 2022-08-09 07:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:53:31 --> Total execution time: 0.0881
DEBUG - 2022-08-09 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:53:32 --> Total execution time: 0.1345
DEBUG - 2022-08-09 07:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:53:35 --> Total execution time: 0.0811
DEBUG - 2022-08-09 07:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:12 --> Total execution time: 0.2433
DEBUG - 2022-08-09 07:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:16 --> Total execution time: 0.0791
DEBUG - 2022-08-09 07:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:29 --> Total execution time: 0.0868
DEBUG - 2022-08-09 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:33 --> Total execution time: 0.0790
DEBUG - 2022-08-09 07:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:39 --> Total execution time: 0.0852
DEBUG - 2022-08-09 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:42 --> Total execution time: 0.0821
DEBUG - 2022-08-09 07:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:45 --> Total execution time: 0.0553
DEBUG - 2022-08-09 07:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:46 --> Total execution time: 0.0807
DEBUG - 2022-08-09 07:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:49 --> Total execution time: 0.0984
DEBUG - 2022-08-09 07:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:55 --> Total execution time: 0.1073
DEBUG - 2022-08-09 07:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:55:58 --> Total execution time: 0.0863
DEBUG - 2022-08-09 07:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:00 --> Total execution time: 0.0701
DEBUG - 2022-08-09 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:06 --> Total execution time: 0.0751
DEBUG - 2022-08-09 07:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:18 --> Total execution time: 0.0844
DEBUG - 2022-08-09 07:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:22 --> Total execution time: 0.1112
DEBUG - 2022-08-09 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:30 --> Total execution time: 0.0813
DEBUG - 2022-08-09 07:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:34 --> Total execution time: 0.1191
DEBUG - 2022-08-09 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:56:38 --> Total execution time: 0.0883
DEBUG - 2022-08-09 07:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:14 --> Total execution time: 0.1071
DEBUG - 2022-08-09 07:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:26 --> Total execution time: 0.1031
DEBUG - 2022-08-09 07:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:27 --> Total execution time: 0.0818
DEBUG - 2022-08-09 07:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:31 --> Total execution time: 0.0805
DEBUG - 2022-08-09 07:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:53 --> Total execution time: 0.0565
DEBUG - 2022-08-09 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:55 --> Total execution time: 0.0774
DEBUG - 2022-08-09 07:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:57:59 --> Total execution time: 0.0820
DEBUG - 2022-08-09 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:00 --> Total execution time: 0.0808
DEBUG - 2022-08-09 07:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:02 --> Total execution time: 0.0692
DEBUG - 2022-08-09 07:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:09 --> Total execution time: 0.0749
DEBUG - 2022-08-09 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:11 --> Total execution time: 0.0773
DEBUG - 2022-08-09 07:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:17 --> Total execution time: 0.0878
DEBUG - 2022-08-09 07:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:20 --> Total execution time: 0.0784
DEBUG - 2022-08-09 07:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:24 --> Total execution time: 0.1082
DEBUG - 2022-08-09 07:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:34 --> Total execution time: 0.0759
DEBUG - 2022-08-09 07:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:36 --> Total execution time: 0.0771
DEBUG - 2022-08-09 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:40 --> Total execution time: 0.0878
DEBUG - 2022-08-09 07:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:42 --> Total execution time: 0.0894
DEBUG - 2022-08-09 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:51 --> Total execution time: 0.0510
DEBUG - 2022-08-09 07:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:52 --> Total execution time: 0.0944
DEBUG - 2022-08-09 07:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:57 --> Total execution time: 0.0887
DEBUG - 2022-08-09 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:58:58 --> Total execution time: 0.0736
DEBUG - 2022-08-09 07:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:01 --> Total execution time: 0.1028
DEBUG - 2022-08-09 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:02 --> Total execution time: 0.0981
DEBUG - 2022-08-09 07:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:06 --> Total execution time: 0.0867
DEBUG - 2022-08-09 07:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:08 --> Total execution time: 0.0901
DEBUG - 2022-08-09 07:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:10 --> Total execution time: 0.1187
DEBUG - 2022-08-09 07:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:16 --> Total execution time: 0.0885
DEBUG - 2022-08-09 07:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:26 --> Total execution time: 0.0864
DEBUG - 2022-08-09 07:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:43 --> Total execution time: 0.0562
DEBUG - 2022-08-09 07:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:49 --> Total execution time: 0.0750
DEBUG - 2022-08-09 07:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:53 --> Total execution time: 0.1091
DEBUG - 2022-08-09 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:54 --> Total execution time: 0.0940
DEBUG - 2022-08-09 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:54 --> Total execution time: 0.0575
DEBUG - 2022-08-09 07:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:59:55 --> Total execution time: 0.2107
DEBUG - 2022-08-09 07:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:00 --> Total execution time: 0.0491
DEBUG - 2022-08-09 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:02 --> Total execution time: 0.1147
DEBUG - 2022-08-09 07:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:06 --> Total execution time: 0.0849
DEBUG - 2022-08-09 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:06 --> Total execution time: 0.0935
DEBUG - 2022-08-09 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:08 --> Total execution time: 0.0668
DEBUG - 2022-08-09 07:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:10 --> Total execution time: 0.0850
DEBUG - 2022-08-09 07:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:13 --> Total execution time: 0.0904
DEBUG - 2022-08-09 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:14 --> Total execution time: 0.0882
DEBUG - 2022-08-09 07:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:15 --> Total execution time: 0.2124
DEBUG - 2022-08-09 07:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:19 --> Total execution time: 0.0832
DEBUG - 2022-08-09 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:24 --> Total execution time: 0.0913
DEBUG - 2022-08-09 07:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:28 --> Total execution time: 0.0844
DEBUG - 2022-08-09 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:34 --> Total execution time: 0.1190
DEBUG - 2022-08-09 07:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:35 --> Total execution time: 0.1065
DEBUG - 2022-08-09 07:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:37 --> Total execution time: 0.0825
DEBUG - 2022-08-09 07:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:01 --> Total execution time: 0.0893
DEBUG - 2022-08-09 07:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:08 --> Total execution time: 0.0974
DEBUG - 2022-08-09 07:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:09 --> Total execution time: 0.0966
DEBUG - 2022-08-09 07:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:10 --> Total execution time: 0.0762
DEBUG - 2022-08-09 07:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:14 --> Total execution time: 0.1035
DEBUG - 2022-08-09 07:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:24 --> Total execution time: 0.2451
DEBUG - 2022-08-09 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:28 --> Total execution time: 0.0828
DEBUG - 2022-08-09 07:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:37 --> Total execution time: 0.0855
DEBUG - 2022-08-09 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:01:39 --> Total execution time: 0.0914
DEBUG - 2022-08-09 07:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:03:01 --> Total execution time: 0.1837
DEBUG - 2022-08-09 07:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:04:46 --> Total execution time: 0.0757
DEBUG - 2022-08-09 07:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:04:52 --> Total execution time: 0.0749
DEBUG - 2022-08-09 07:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:05:17 --> Total execution time: 0.2038
DEBUG - 2022-08-09 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:05:32 --> Total execution time: 0.0810
DEBUG - 2022-08-09 07:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:05:43 --> Total execution time: 0.0753
DEBUG - 2022-08-09 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:05:51 --> Total execution time: 0.0848
DEBUG - 2022-08-09 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:05:55 --> Total execution time: 0.0505
DEBUG - 2022-08-09 07:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:07:13 --> Total execution time: 0.0809
DEBUG - 2022-08-09 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:37:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:07:19 --> Total execution time: 0.0814
DEBUG - 2022-08-09 07:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:37:45 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:07:45 --> Total execution time: 0.2063
DEBUG - 2022-08-09 07:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:38:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:08:08 --> Total execution time: 0.0788
DEBUG - 2022-08-09 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:38:39 --> Total execution time: 0.0996
DEBUG - 2022-08-09 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:38:48 --> Total execution time: 0.0971
DEBUG - 2022-08-09 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:38:48 --> Total execution time: 0.1946
DEBUG - 2022-08-09 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:40:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:40:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:10:31 --> Total execution time: 2.1148
DEBUG - 2022-08-09 07:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:10:31 --> Total execution time: 0.0785
DEBUG - 2022-08-09 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:10:42 --> Total execution time: 0.0765
DEBUG - 2022-08-09 07:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:40:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:40:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:11:40 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:11:41 --> Total execution time: 0.0812
DEBUG - 2022-08-09 07:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:11:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 18:11:43 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 18:11:43 --> Total execution time: 0.2278
DEBUG - 2022-08-09 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:11:53 --> Total execution time: 0.0831
DEBUG - 2022-08-09 07:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:11:56 --> Total execution time: 0.2057
DEBUG - 2022-08-09 07:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:01 --> Total execution time: 1.8677
DEBUG - 2022-08-09 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:02 --> Total execution time: 0.0830
DEBUG - 2022-08-09 07:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:15 --> Total execution time: 0.1104
DEBUG - 2022-08-09 07:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:28 --> Total execution time: 0.1962
DEBUG - 2022-08-09 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:28 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:28 --> Total execution time: 0.1244
DEBUG - 2022-08-09 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:36 --> Total execution time: 0.0801
DEBUG - 2022-08-09 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:42 --> Total execution time: 0.1068
DEBUG - 2022-08-09 07:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:12:49 --> Total execution time: 0.2378
DEBUG - 2022-08-09 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:13:03 --> Total execution time: 0.0759
DEBUG - 2022-08-09 07:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:13:16 --> Total execution time: 0.0814
DEBUG - 2022-08-09 07:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:13:26 --> Total execution time: 0.1178
DEBUG - 2022-08-09 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:13:55 --> Total execution time: 0.1205
DEBUG - 2022-08-09 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:14:09 --> Total execution time: 0.1197
DEBUG - 2022-08-09 07:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:14:12 --> Total execution time: 0.0987
DEBUG - 2022-08-09 07:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:16 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:14:16 --> Total execution time: 0.0796
DEBUG - 2022-08-09 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:14:29 --> Total execution time: 0.0959
DEBUG - 2022-08-09 07:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:44:36 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:14:36 --> Total execution time: 0.0904
DEBUG - 2022-08-09 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:15:03 --> Total execution time: 0.0967
DEBUG - 2022-08-09 07:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:16:36 --> Total execution time: 0.0559
DEBUG - 2022-08-09 07:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:18:51 --> Total execution time: 0.1234
DEBUG - 2022-08-09 07:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:50:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:20:09 --> Total execution time: 0.0508
DEBUG - 2022-08-09 07:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:20:55 --> Total execution time: 0.0509
DEBUG - 2022-08-09 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:20:56 --> Total execution time: 0.0625
DEBUG - 2022-08-09 07:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:20:56 --> Total execution time: 0.0518
DEBUG - 2022-08-09 07:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:51:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:21:09 --> Total execution time: 0.0580
DEBUG - 2022-08-09 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:51:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:21:14 --> Total execution time: 0.1215
DEBUG - 2022-08-09 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:21:24 --> Total execution time: 0.0490
DEBUG - 2022-08-09 07:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 07:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:21:32 --> Total execution time: 0.1031
DEBUG - 2022-08-09 07:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:22:00 --> Total execution time: 0.1252
DEBUG - 2022-08-09 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:26:14 --> Total execution time: 0.3229
DEBUG - 2022-08-09 07:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:26:19 --> Total execution time: 0.0852
DEBUG - 2022-08-09 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:26:21 --> Total execution time: 0.0866
DEBUG - 2022-08-09 07:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:26:25 --> Total execution time: 0.0750
DEBUG - 2022-08-09 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:30:02 --> Total execution time: 0.1947
DEBUG - 2022-08-09 08:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:31:58 --> Total execution time: 0.2123
DEBUG - 2022-08-09 08:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:09:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:39:22 --> Total execution time: 0.1447
DEBUG - 2022-08-09 08:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:39:32 --> Total execution time: 0.0794
DEBUG - 2022-08-09 08:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:09:53 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:39:54 --> Total execution time: 0.1976
DEBUG - 2022-08-09 08:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:39:56 --> Total execution time: 0.0978
DEBUG - 2022-08-09 08:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:06 --> Total execution time: 0.1329
DEBUG - 2022-08-09 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:18 --> Total execution time: 0.0692
DEBUG - 2022-08-09 08:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:18 --> Total execution time: 0.0832
DEBUG - 2022-08-09 08:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:19 --> Total execution time: 0.0810
DEBUG - 2022-08-09 08:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:22 --> Total execution time: 0.0910
DEBUG - 2022-08-09 08:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:10:35 --> Total execution time: 0.0529
DEBUG - 2022-08-09 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:10:37 --> Total execution time: 0.1039
DEBUG - 2022-08-09 08:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:10:37 --> Total execution time: 0.2078
DEBUG - 2022-08-09 08:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:47 --> Total execution time: 0.0799
DEBUG - 2022-08-09 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:54 --> Total execution time: 0.0724
DEBUG - 2022-08-09 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:00 --> Total execution time: 0.1073
DEBUG - 2022-08-09 08:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:13 --> Total execution time: 0.1065
DEBUG - 2022-08-09 08:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:25 --> Total execution time: 0.1052
DEBUG - 2022-08-09 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:28 --> Total execution time: 0.1186
DEBUG - 2022-08-09 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:11:28 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:30 --> Total execution time: 0.0817
DEBUG - 2022-08-09 18:41:31 --> Total execution time: 1.9561
DEBUG - 2022-08-09 08:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:32 --> Total execution time: 0.1108
DEBUG - 2022-08-09 08:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:11:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:12:12 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 08:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:12:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:12:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:42:32 --> Total execution time: 0.0863
DEBUG - 2022-08-09 08:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:12:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:42:32 --> Total execution time: 0.0877
DEBUG - 2022-08-09 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:14:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:44:08 --> Total execution time: 0.0991
DEBUG - 2022-08-09 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:45:46 --> Total execution time: 0.0898
DEBUG - 2022-08-09 08:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:15:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:45:55 --> Total execution time: 0.0589
DEBUG - 2022-08-09 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:45:57 --> Total execution time: 0.0989
DEBUG - 2022-08-09 08:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:00 --> Total execution time: 0.0825
DEBUG - 2022-08-09 08:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:03 --> Total execution time: 0.0913
DEBUG - 2022-08-09 08:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:06 --> Total execution time: 0.0492
DEBUG - 2022-08-09 08:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:09 --> Total execution time: 0.0898
DEBUG - 2022-08-09 08:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:12 --> Total execution time: 0.1106
DEBUG - 2022-08-09 08:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:34 --> Total execution time: 0.0840
DEBUG - 2022-08-09 08:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:46:57 --> Total execution time: 0.0741
DEBUG - 2022-08-09 08:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:47:04 --> Total execution time: 0.0935
DEBUG - 2022-08-09 08:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:47:23 --> Total execution time: 0.0957
DEBUG - 2022-08-09 08:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:47:39 --> Total execution time: 0.0996
DEBUG - 2022-08-09 08:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:47:51 --> Total execution time: 0.1019
DEBUG - 2022-08-09 08:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:47:58 --> Total execution time: 0.0832
DEBUG - 2022-08-09 08:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:48:05 --> Total execution time: 0.0942
DEBUG - 2022-08-09 08:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:48:06 --> Total execution time: 0.0538
DEBUG - 2022-08-09 08:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:48:08 --> Total execution time: 0.0791
DEBUG - 2022-08-09 08:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:48:10 --> Total execution time: 0.1477
DEBUG - 2022-08-09 08:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:48:15 --> Total execution time: 0.0817
DEBUG - 2022-08-09 08:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:22:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:52:50 --> Total execution time: 0.1299
DEBUG - 2022-08-09 08:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:23:26 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:53:26 --> Total execution time: 0.0898
DEBUG - 2022-08-09 08:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:54:18 --> Total execution time: 0.1275
DEBUG - 2022-08-09 08:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:54:27 --> Total execution time: 0.0798
DEBUG - 2022-08-09 08:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:24:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:54:52 --> Total execution time: 0.0543
DEBUG - 2022-08-09 08:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:55:10 --> Total execution time: 0.2382
DEBUG - 2022-08-09 08:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:25:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:55:59 --> Total execution time: 0.3384
DEBUG - 2022-08-09 08:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:56:52 --> Total execution time: 0.2191
DEBUG - 2022-08-09 08:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:27:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:57:24 --> Total execution time: 0.2248
DEBUG - 2022-08-09 08:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:58:16 --> Total execution time: 0.1034
DEBUG - 2022-08-09 08:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:58:39 --> Total execution time: 0.0922
DEBUG - 2022-08-09 08:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:00:32 --> Total execution time: 0.1025
DEBUG - 2022-08-09 08:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:00:46 --> Total execution time: 0.0954
DEBUG - 2022-08-09 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:02:04 --> Total execution time: 0.0885
DEBUG - 2022-08-09 08:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:02:12 --> Total execution time: 0.0849
DEBUG - 2022-08-09 08:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:32:37 --> Total execution time: 0.0773
DEBUG - 2022-08-09 08:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:02:41 --> Total execution time: 0.0525
DEBUG - 2022-08-09 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:32:54 --> Total execution time: 0.0998
DEBUG - 2022-08-09 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:33:05 --> Total execution time: 0.0758
DEBUG - 2022-08-09 08:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:33:06 --> Total execution time: 0.1697
DEBUG - 2022-08-09 08:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:35:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:13 --> Total execution time: 2.0848
DEBUG - 2022-08-09 08:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:35:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 08:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:19 --> Total execution time: 0.0597
DEBUG - 2022-08-09 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:35:30 --> Total execution time: 0.0504
DEBUG - 2022-08-09 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:35 --> Total execution time: 0.0746
DEBUG - 2022-08-09 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:38 --> Total execution time: 0.1468
DEBUG - 2022-08-09 08:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:39 --> Total execution time: 0.1528
DEBUG - 2022-08-09 08:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:48 --> Total execution time: 0.1133
DEBUG - 2022-08-09 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:11 --> Total execution time: 0.0990
DEBUG - 2022-08-09 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:13 --> Total execution time: 0.0874
DEBUG - 2022-08-09 08:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:20 --> Total execution time: 0.1041
DEBUG - 2022-08-09 08:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:22 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:23 --> Total execution time: 0.0927
DEBUG - 2022-08-09 08:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 19:06:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 19:06:24 --> Total execution time: 0.2445
DEBUG - 2022-08-09 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:06:50 --> Total execution time: 0.0970
DEBUG - 2022-08-09 08:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:01 --> Total execution time: 0.1145
DEBUG - 2022-08-09 08:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:06 --> Total execution time: 0.1271
DEBUG - 2022-08-09 08:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:11 --> Total execution time: 0.0552
DEBUG - 2022-08-09 08:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:11 --> Total execution time: 0.0508
DEBUG - 2022-08-09 08:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:14 --> Total execution time: 0.1970
DEBUG - 2022-08-09 08:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:19 --> Total execution time: 0.1972
DEBUG - 2022-08-09 08:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:25 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:25 --> Total execution time: 0.0661
DEBUG - 2022-08-09 08:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:25 --> Total execution time: 0.0904
DEBUG - 2022-08-09 08:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:28 --> Total execution time: 0.0998
DEBUG - 2022-08-09 08:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:34 --> Total execution time: 0.0698
DEBUG - 2022-08-09 08:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:34 --> Total execution time: 0.1143
DEBUG - 2022-08-09 08:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:37 --> Total execution time: 0.0820
DEBUG - 2022-08-09 08:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:46 --> Total execution time: 0.1696
DEBUG - 2022-08-09 08:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:50 --> Total execution time: 0.1177
DEBUG - 2022-08-09 08:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:51 --> Total execution time: 0.0807
DEBUG - 2022-08-09 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:07:56 --> Total execution time: 0.1069
DEBUG - 2022-08-09 08:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:08:00 --> Total execution time: 0.0952
DEBUG - 2022-08-09 08:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:08:02 --> Total execution time: 0.0933
DEBUG - 2022-08-09 08:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:08:51 --> Total execution time: 0.1966
DEBUG - 2022-08-09 08:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:09:06 --> Total execution time: 0.0699
DEBUG - 2022-08-09 08:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:09:13 --> Total execution time: 0.0752
DEBUG - 2022-08-09 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:03 --> Total execution time: 0.0514
DEBUG - 2022-08-09 08:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:03 --> Total execution time: 0.2010
DEBUG - 2022-08-09 08:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:08 --> Total execution time: 0.0532
DEBUG - 2022-08-09 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:14 --> Total execution time: 0.0916
DEBUG - 2022-08-09 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:16 --> Total execution time: 0.0834
DEBUG - 2022-08-09 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:19 --> Total execution time: 0.0498
DEBUG - 2022-08-09 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:21 --> Total execution time: 0.0576
DEBUG - 2022-08-09 08:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:24 --> Total execution time: 0.0838
DEBUG - 2022-08-09 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:26 --> Total execution time: 0.1130
DEBUG - 2022-08-09 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:28 --> Total execution time: 0.0869
DEBUG - 2022-08-09 08:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:35 --> Total execution time: 0.1219
DEBUG - 2022-08-09 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:45 --> Total execution time: 0.0833
DEBUG - 2022-08-09 08:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:49 --> Total execution time: 0.0682
DEBUG - 2022-08-09 08:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:49 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:49 --> Total execution time: 0.0810
DEBUG - 2022-08-09 08:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:41:58 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:58 --> Total execution time: 0.0747
DEBUG - 2022-08-09 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:12:44 --> Total execution time: 0.0546
DEBUG - 2022-08-09 08:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:12:45 --> Total execution time: 0.0942
DEBUG - 2022-08-09 08:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:12:48 --> Total execution time: 0.0853
DEBUG - 2022-08-09 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:43:00 --> Total execution time: 0.0840
DEBUG - 2022-08-09 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:43:02 --> Total execution time: 0.0954
DEBUG - 2022-08-09 08:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:43:02 --> Total execution time: 0.1839
DEBUG - 2022-08-09 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:13:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:13:12 --> Total execution time: 0.0857
DEBUG - 2022-08-09 08:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:13:20 --> Total execution time: 0.1465
DEBUG - 2022-08-09 08:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:43:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:13:28 --> Total execution time: 0.0873
DEBUG - 2022-08-09 08:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:44:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:14:06 --> Total execution time: 0.1044
DEBUG - 2022-08-09 08:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:14:08 --> Total execution time: 0.0782
DEBUG - 2022-08-09 08:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:44:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:14:11 --> Total execution time: 0.0679
DEBUG - 2022-08-09 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:45:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 08:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:45:30 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 08:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:15:39 --> Total execution time: 0.0880
DEBUG - 2022-08-09 08:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:15:50 --> Total execution time: 0.1003
DEBUG - 2022-08-09 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:15:51 --> Total execution time: 0.1020
DEBUG - 2022-08-09 08:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:46:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:16:08 --> Total execution time: 0.1949
DEBUG - 2022-08-09 08:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:16:13 --> Total execution time: 0.1932
DEBUG - 2022-08-09 08:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:46:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:16:42 --> Total execution time: 0.2002
DEBUG - 2022-08-09 08:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:17:11 --> Total execution time: 0.0548
DEBUG - 2022-08-09 08:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:47:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:17:32 --> Total execution time: 0.0955
DEBUG - 2022-08-09 08:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:18:25 --> Total execution time: 0.0483
DEBUG - 2022-08-09 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:18:40 --> Total execution time: 0.0901
DEBUG - 2022-08-09 08:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:18:44 --> Total execution time: 0.0826
DEBUG - 2022-08-09 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:18:59 --> Total execution time: 0.1811
DEBUG - 2022-08-09 08:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:19:12 --> Total execution time: 0.1336
DEBUG - 2022-08-09 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:19:15 --> Total execution time: 0.4773
DEBUG - 2022-08-09 08:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:51:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:21:52 --> Total execution time: 0.1296
DEBUG - 2022-08-09 08:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:52:01 --> Total execution time: 0.1515
DEBUG - 2022-08-09 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:52:05 --> Total execution time: 0.0845
DEBUG - 2022-08-09 08:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:52:05 --> Total execution time: 0.1848
DEBUG - 2022-08-09 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:23:11 --> Total execution time: 0.0539
DEBUG - 2022-08-09 08:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:23:25 --> Total execution time: 0.0909
DEBUG - 2022-08-09 08:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:23:27 --> Total execution time: 0.1514
DEBUG - 2022-08-09 08:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:23:43 --> Total execution time: 0.0786
DEBUG - 2022-08-09 08:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:23:46 --> Total execution time: 0.0812
DEBUG - 2022-08-09 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:25:17 --> Total execution time: 0.2244
DEBUG - 2022-08-09 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:25:30 --> Total execution time: 0.0876
DEBUG - 2022-08-09 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:25:40 --> Total execution time: 0.0759
DEBUG - 2022-08-09 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:07 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:26:07 --> Total execution time: 0.2133
DEBUG - 2022-08-09 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:26:28 --> Total execution time: 0.0529
DEBUG - 2022-08-09 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 08:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:26:44 --> Total execution time: 0.0814
DEBUG - 2022-08-09 08:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:26:56 --> Total execution time: 0.0995
DEBUG - 2022-08-09 08:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 08:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:27:27 --> Total execution time: 0.1024
DEBUG - 2022-08-09 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:27:55 --> Total execution time: 0.1502
DEBUG - 2022-08-09 08:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:14 --> Total execution time: 0.0832
DEBUG - 2022-08-09 08:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:30 --> Total execution time: 0.0886
DEBUG - 2022-08-09 08:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:43 --> Total execution time: 0.0996
DEBUG - 2022-08-09 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:48 --> Total execution time: 0.0778
DEBUG - 2022-08-09 08:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:51 --> Total execution time: 0.0851
DEBUG - 2022-08-09 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:28:54 --> Total execution time: 0.1372
DEBUG - 2022-08-09 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:30:02 --> Total execution time: 0.0748
DEBUG - 2022-08-09 09:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:31:25 --> Total execution time: 0.2180
DEBUG - 2022-08-09 09:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:32:00 --> Total execution time: 0.2070
DEBUG - 2022-08-09 09:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:32:12 --> Total execution time: 0.1298
DEBUG - 2022-08-09 09:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:32:30 --> Total execution time: 0.1762
DEBUG - 2022-08-09 09:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:02:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:32:51 --> Total execution time: 0.0779
DEBUG - 2022-08-09 09:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:33:09 --> Total execution time: 0.2022
DEBUG - 2022-08-09 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:04:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:04:25 --> Total execution time: 0.0751
DEBUG - 2022-08-09 09:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:04:28 --> Total execution time: 0.0847
DEBUG - 2022-08-09 09:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:04:28 --> Total execution time: 0.1747
DEBUG - 2022-08-09 09:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:35:21 --> Total execution time: 0.0528
DEBUG - 2022-08-09 09:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:06:07 --> Total execution time: 0.0735
DEBUG - 2022-08-09 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:06:09 --> Total execution time: 0.0754
DEBUG - 2022-08-09 09:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:06:10 --> Total execution time: 0.1801
DEBUG - 2022-08-09 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:37:32 --> Total execution time: 0.0532
DEBUG - 2022-08-09 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:33 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-09 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:37:33 --> Total execution time: 0.0517
DEBUG - 2022-08-09 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:34 --> 404 Page Not Found: Debuglog/index
DEBUG - 2022-08-09 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:34 --> 404 Page Not Found: Errorlog/index
DEBUG - 2022-08-09 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:34 --> 404 Page Not Found: Accesslog/index
DEBUG - 2022-08-09 09:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:38:30 --> Total execution time: 0.1135
DEBUG - 2022-08-09 09:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:38:57 --> Total execution time: 0.2041
DEBUG - 2022-08-09 09:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:09:43 --> Total execution time: 0.0503
DEBUG - 2022-08-09 09:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:42:39 --> Total execution time: 0.0604
DEBUG - 2022-08-09 09:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:43:55 --> Total execution time: 0.0744
DEBUG - 2022-08-09 09:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:43:57 --> Total execution time: 0.0783
DEBUG - 2022-08-09 09:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:43:58 --> Total execution time: 0.0760
DEBUG - 2022-08-09 09:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:44:16 --> Total execution time: 0.1269
DEBUG - 2022-08-09 09:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:44:53 --> Total execution time: 0.0794
DEBUG - 2022-08-09 09:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:44:59 --> Total execution time: 0.0929
DEBUG - 2022-08-09 09:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:07 --> Total execution time: 0.0840
DEBUG - 2022-08-09 09:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:13 --> Total execution time: 0.0523
DEBUG - 2022-08-09 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:29 --> Total execution time: 0.0489
DEBUG - 2022-08-09 09:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:33 --> Total execution time: 0.0847
DEBUG - 2022-08-09 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:37 --> Total execution time: 0.0520
DEBUG - 2022-08-09 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:42 --> Total execution time: 0.0837
DEBUG - 2022-08-09 09:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:45:52 --> Total execution time: 0.0815
DEBUG - 2022-08-09 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:16:08 --> 404 Page Not Found: Teacher/index
DEBUG - 2022-08-09 09:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:09 --> Total execution time: 0.0814
DEBUG - 2022-08-09 09:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:09 --> Total execution time: 0.0502
DEBUG - 2022-08-09 09:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:35 --> Total execution time: 0.0496
DEBUG - 2022-08-09 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:43 --> Total execution time: 0.0786
DEBUG - 2022-08-09 09:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:46 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:46 --> Total execution time: 0.0616
DEBUG - 2022-08-09 09:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:51 --> Total execution time: 0.0503
DEBUG - 2022-08-09 09:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:46:56 --> Total execution time: 0.0858
DEBUG - 2022-08-09 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:04 --> Total execution time: 0.1166
DEBUG - 2022-08-09 09:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:13 --> Total execution time: 0.0787
DEBUG - 2022-08-09 09:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:29 --> Total execution time: 0.0759
DEBUG - 2022-08-09 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:35 --> Total execution time: 0.0559
DEBUG - 2022-08-09 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:53 --> Total execution time: 0.0740
DEBUG - 2022-08-09 09:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:48:07 --> Total execution time: 0.0838
DEBUG - 2022-08-09 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:48:19 --> Total execution time: 0.0788
DEBUG - 2022-08-09 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:48:19 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:48:27 --> Total execution time: 0.0577
DEBUG - 2022-08-09 09:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:48:34 --> Total execution time: 0.0790
DEBUG - 2022-08-09 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:18:48 --> Total execution time: 0.0749
DEBUG - 2022-08-09 09:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:18:49 --> Total execution time: 0.0849
DEBUG - 2022-08-09 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:18:50 --> Total execution time: 0.0770
DEBUG - 2022-08-09 09:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:19:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:49:09 --> Total execution time: 0.0511
DEBUG - 2022-08-09 09:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:03 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:03 --> Total execution time: 0.0786
DEBUG - 2022-08-09 09:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:13 --> Total execution time: 0.1040
DEBUG - 2022-08-09 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:15 --> Total execution time: 0.0810
DEBUG - 2022-08-09 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:15 --> Total execution time: 0.1790
DEBUG - 2022-08-09 09:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:18 --> Total execution time: 0.0839
DEBUG - 2022-08-09 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:20 --> Total execution time: 0.0861
DEBUG - 2022-08-09 09:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:37 --> Total execution time: 0.2089
DEBUG - 2022-08-09 09:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:41 --> Total execution time: 0.1017
DEBUG - 2022-08-09 09:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:43 --> Total execution time: 0.0786
DEBUG - 2022-08-09 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:44 --> Total execution time: 0.0932
DEBUG - 2022-08-09 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:44 --> Total execution time: 0.0805
DEBUG - 2022-08-09 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:20:44 --> Total execution time: 0.1692
DEBUG - 2022-08-09 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:45 --> Total execution time: 0.0813
DEBUG - 2022-08-09 09:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:50:45 --> Total execution time: 0.1636
DEBUG - 2022-08-09 09:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:04 --> Total execution time: 0.2010
DEBUG - 2022-08-09 09:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:14 --> Total execution time: 0.1069
DEBUG - 2022-08-09 09:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:21:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:21 --> Total execution time: 0.1063
DEBUG - 2022-08-09 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:22 --> Total execution time: 0.0807
DEBUG - 2022-08-09 09:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:32 --> Total execution time: 0.0849
DEBUG - 2022-08-09 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:52:47 --> Total execution time: 0.0750
DEBUG - 2022-08-09 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:53:28 --> Total execution time: 0.0749
DEBUG - 2022-08-09 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:54:31 --> Total execution time: 0.2035
DEBUG - 2022-08-09 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:24:55 --> 404 Page Not Found: Category/education
DEBUG - 2022-08-09 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:55:57 --> Total execution time: 0.0747
DEBUG - 2022-08-09 09:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:56:05 --> Total execution time: 0.0790
DEBUG - 2022-08-09 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:58:13 --> Total execution time: 0.2804
DEBUG - 2022-08-09 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:58:31 --> Total execution time: 0.0869
DEBUG - 2022-08-09 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:53 --> Total execution time: 0.0886
DEBUG - 2022-08-09 09:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:55 --> Total execution time: 0.1041
DEBUG - 2022-08-09 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:57 --> Total execution time: 0.0884
DEBUG - 2022-08-09 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:02:42 --> Total execution time: 0.2035
DEBUG - 2022-08-09 09:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:02:46 --> Total execution time: 0.0944
DEBUG - 2022-08-09 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:02:49 --> Total execution time: 0.0992
DEBUG - 2022-08-09 09:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:03:04 --> Total execution time: 1.3203
DEBUG - 2022-08-09 09:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:33:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:03:16 --> Total execution time: 1.2745
DEBUG - 2022-08-09 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:03:17 --> Total execution time: 0.0929
DEBUG - 2022-08-09 09:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:03:18 --> Total execution time: 0.0813
DEBUG - 2022-08-09 09:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:34:30 --> Total execution time: 0.0980
DEBUG - 2022-08-09 09:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:34:49 --> Total execution time: 0.1396
DEBUG - 2022-08-09 09:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:06:34 --> Total execution time: 0.0802
DEBUG - 2022-08-09 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:07:09 --> Total execution time: 0.1064
DEBUG - 2022-08-09 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:07:53 --> Total execution time: 0.1121
DEBUG - 2022-08-09 09:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:08:33 --> Total execution time: 0.0825
DEBUG - 2022-08-09 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:08:43 --> Total execution time: 0.1224
DEBUG - 2022-08-09 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:08:45 --> Total execution time: 0.1083
DEBUG - 2022-08-09 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:09:48 --> Total execution time: 0.1266
DEBUG - 2022-08-09 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:09:56 --> Total execution time: 0.0823
DEBUG - 2022-08-09 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:12:15 --> Total execution time: 0.0856
DEBUG - 2022-08-09 09:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:12:39 --> Total execution time: 0.1945
DEBUG - 2022-08-09 09:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:12:55 --> Total execution time: 0.0852
DEBUG - 2022-08-09 09:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:12:55 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:12:56 --> Total execution time: 0.0875
DEBUG - 2022-08-09 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:13:26 --> Total execution time: 0.0885
DEBUG - 2022-08-09 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:13:40 --> Total execution time: 0.0906
DEBUG - 2022-08-09 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:13:52 --> Total execution time: 0.0674
DEBUG - 2022-08-09 09:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:45:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:45:44 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-09 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:45:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:45:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:45:49 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-09 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:13 --> Total execution time: 0.0908
DEBUG - 2022-08-09 09:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:25 --> Total execution time: 0.0497
DEBUG - 2022-08-09 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:35 --> Total execution time: 0.0735
DEBUG - 2022-08-09 09:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:44 --> Total execution time: 0.0744
DEBUG - 2022-08-09 09:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:51 --> Total execution time: 0.0852
DEBUG - 2022-08-09 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:16:54 --> Total execution time: 0.0947
DEBUG - 2022-08-09 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:47:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:47:35 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-09 09:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:17:55 --> Total execution time: 0.0617
DEBUG - 2022-08-09 09:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:17:56 --> Total execution time: 0.0742
DEBUG - 2022-08-09 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:48:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:18:17 --> Total execution time: 0.0550
DEBUG - 2022-08-09 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:19:15 --> Total execution time: 0.2153
DEBUG - 2022-08-09 09:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:20:51 --> Total execution time: 0.0788
DEBUG - 2022-08-09 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:21:48 --> Total execution time: 0.0905
DEBUG - 2022-08-09 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:51:51 --> Total execution time: 0.0780
DEBUG - 2022-08-09 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:08 --> Total execution time: 0.0766
DEBUG - 2022-08-09 09:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:24 --> Total execution time: 0.0760
DEBUG - 2022-08-09 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:27 --> Total execution time: 0.0791
DEBUG - 2022-08-09 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:28 --> Total execution time: 0.0843
DEBUG - 2022-08-09 09:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:52:28 --> Total execution time: 0.0739
DEBUG - 2022-08-09 09:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:22:30 --> Total execution time: 0.0840
DEBUG - 2022-08-09 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:26:06 --> Total execution time: 0.0795
DEBUG - 2022-08-09 09:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:27:47 --> Total execution time: 0.0920
DEBUG - 2022-08-09 09:57:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:57:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:00 --> Total execution time: 0.0581
DEBUG - 2022-08-09 09:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:11 --> Total execution time: 0.0510
DEBUG - 2022-08-09 09:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:14 --> Total execution time: 0.0755
DEBUG - 2022-08-09 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 09:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:23 --> Total execution time: 0.1024
DEBUG - 2022-08-09 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:27 --> Total execution time: 0.2218
DEBUG - 2022-08-09 09:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:27 --> Total execution time: 0.0851
DEBUG - 2022-08-09 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:30 --> Total execution time: 0.0920
DEBUG - 2022-08-09 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:35 --> Total execution time: 0.0853
DEBUG - 2022-08-09 09:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:28:39 --> Total execution time: 0.0747
DEBUG - 2022-08-09 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:30:02 --> Total execution time: 0.0665
DEBUG - 2022-08-09 10:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:01:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:31:05 --> Total execution time: 0.0585
DEBUG - 2022-08-09 10:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:31:12 --> Total execution time: 0.0645
DEBUG - 2022-08-09 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:31:53 --> Total execution time: 0.1052
DEBUG - 2022-08-09 10:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:32:03 --> Total execution time: 0.1048
DEBUG - 2022-08-09 10:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:32:14 --> Total execution time: 0.0845
DEBUG - 2022-08-09 10:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:32:33 --> Total execution time: 0.1640
DEBUG - 2022-08-09 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:33:05 --> Total execution time: 0.0881
DEBUG - 2022-08-09 10:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:33:42 --> Total execution time: 0.0891
DEBUG - 2022-08-09 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:12 --> Total execution time: 0.0514
DEBUG - 2022-08-09 10:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:22 --> Total execution time: 0.2038
DEBUG - 2022-08-09 10:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:25 --> Total execution time: 0.0480
DEBUG - 2022-08-09 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:48 --> Total execution time: 0.0841
DEBUG - 2022-08-09 10:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:54 --> Total execution time: 0.1096
DEBUG - 2022-08-09 10:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:05:59 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:35:59 --> Total execution time: 0.0614
DEBUG - 2022-08-09 10:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:36:00 --> Total execution time: 0.0569
DEBUG - 2022-08-09 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:36:13 --> Total execution time: 0.0813
DEBUG - 2022-08-09 10:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:36:33 --> Total execution time: 0.0536
DEBUG - 2022-08-09 10:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:36:52 --> Total execution time: 0.0835
DEBUG - 2022-08-09 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:37:01 --> Total execution time: 0.0826
DEBUG - 2022-08-09 10:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:37:02 --> Total execution time: 0.0831
DEBUG - 2022-08-09 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:07 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:37:07 --> Total execution time: 0.0724
DEBUG - 2022-08-09 10:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:37:07 --> Total execution time: 0.0820
DEBUG - 2022-08-09 10:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:37:23 --> Total execution time: 0.0806
DEBUG - 2022-08-09 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:03 --> Total execution time: 0.0880
DEBUG - 2022-08-09 10:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:08 --> Total execution time: 0.0979
DEBUG - 2022-08-09 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:22 --> Total execution time: 0.2127
DEBUG - 2022-08-09 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:08:31 --> Total execution time: 0.0821
DEBUG - 2022-08-09 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:08:34 --> Total execution time: 0.0779
DEBUG - 2022-08-09 10:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:08:34 --> Total execution time: 0.1704
DEBUG - 2022-08-09 10:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:36 --> Total execution time: 0.1031
DEBUG - 2022-08-09 10:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:44 --> Total execution time: 0.1022
DEBUG - 2022-08-09 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:49 --> Total execution time: 0.0802
DEBUG - 2022-08-09 10:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:38:56 --> Total execution time: 0.1218
DEBUG - 2022-08-09 10:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:09:16 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:39:16 --> Total execution time: 0.0521
DEBUG - 2022-08-09 10:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:40:10 --> Total execution time: 0.0796
DEBUG - 2022-08-09 10:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:40:22 --> Total execution time: 0.0796
DEBUG - 2022-08-09 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:40:36 --> Total execution time: 0.2299
DEBUG - 2022-08-09 10:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:40:53 --> Total execution time: 0.0774
DEBUG - 2022-08-09 10:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:10:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:40:54 --> Total execution time: 0.0511
DEBUG - 2022-08-09 10:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:11:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:41:01 --> Total execution time: 0.0620
DEBUG - 2022-08-09 10:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:11:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:41:06 --> Total execution time: 0.0775
DEBUG - 2022-08-09 10:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:11:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:41:50 --> Total execution time: 0.0963
DEBUG - 2022-08-09 10:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:15 --> Total execution time: 0.0757
DEBUG - 2022-08-09 10:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:18 --> Total execution time: 0.1980
DEBUG - 2022-08-09 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:25 --> Total execution time: 0.0809
DEBUG - 2022-08-09 10:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:46 --> Total execution time: 0.0747
DEBUG - 2022-08-09 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:53 --> Total execution time: 0.2261
DEBUG - 2022-08-09 10:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:53 --> Total execution time: 0.0800
DEBUG - 2022-08-09 10:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:55 --> Total execution time: 0.0884
DEBUG - 2022-08-09 10:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:19 --> Total execution time: 0.0528
DEBUG - 2022-08-09 10:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:23 --> Total execution time: 0.2109
DEBUG - 2022-08-09 10:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:25 --> Total execution time: 0.0810
DEBUG - 2022-08-09 10:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:30 --> Total execution time: 0.1960
DEBUG - 2022-08-09 10:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:32 --> Total execution time: 0.0795
DEBUG - 2022-08-09 10:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:14:37 --> Total execution time: 0.2138
DEBUG - 2022-08-09 10:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:42 --> Total execution time: 0.1082
DEBUG - 2022-08-09 10:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:46 --> Total execution time: 0.1107
DEBUG - 2022-08-09 20:44:46 --> Total execution time: 0.1033
DEBUG - 2022-08-09 10:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:47 --> Total execution time: 0.1166
DEBUG - 2022-08-09 10:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:55 --> Total execution time: 0.0827
DEBUG - 2022-08-09 10:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:14:58 --> Total execution time: 0.0784
DEBUG - 2022-08-09 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:44:59 --> Total execution time: 0.0763
DEBUG - 2022-08-09 10:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:15:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:45:02 --> Total execution time: 0.1081
DEBUG - 2022-08-09 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:15:03 --> Total execution time: 0.0859
DEBUG - 2022-08-09 10:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:15:03 --> Total execution time: 0.1977
DEBUG - 2022-08-09 10:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:45:11 --> Total execution time: 0.0774
DEBUG - 2022-08-09 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:45:37 --> Total execution time: 0.0797
DEBUG - 2022-08-09 10:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:16:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:46:51 --> Total execution time: 1.9854
DEBUG - 2022-08-09 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:16:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:16:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 10:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:06 --> Total execution time: 0.0497
DEBUG - 2022-08-09 10:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:15 --> Total execution time: 1.6249
DEBUG - 2022-08-09 10:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:18:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:19 --> Total execution time: 0.0498
DEBUG - 2022-08-09 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:43 --> Total execution time: 0.0739
DEBUG - 2022-08-09 10:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:47 --> Total execution time: 0.0776
DEBUG - 2022-08-09 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:48:55 --> Total execution time: 0.0889
DEBUG - 2022-08-09 10:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:00 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:02 --> Total execution time: 0.0946
DEBUG - 2022-08-09 10:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:07 --> Total execution time: 0.0817
DEBUG - 2022-08-09 10:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:10 --> Total execution time: 0.0841
DEBUG - 2022-08-09 10:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:11 --> Total execution time: 0.2030
DEBUG - 2022-08-09 10:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:12 --> Total execution time: 0.1208
DEBUG - 2022-08-09 10:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:17 --> Total execution time: 0.0845
DEBUG - 2022-08-09 10:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:17 --> Total execution time: 0.0916
DEBUG - 2022-08-09 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:23 --> Total execution time: 0.0885
DEBUG - 2022-08-09 10:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:24 --> Total execution time: 0.0761
DEBUG - 2022-08-09 10:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:28 --> Total execution time: 0.1038
DEBUG - 2022-08-09 10:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:28 --> Total execution time: 0.1968
DEBUG - 2022-08-09 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:31 --> Total execution time: 0.0827
DEBUG - 2022-08-09 10:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:36 --> Total execution time: 0.0745
DEBUG - 2022-08-09 10:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:52 --> Total execution time: 0.0791
DEBUG - 2022-08-09 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:49:59 --> Total execution time: 0.0973
DEBUG - 2022-08-09 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:04 --> Total execution time: 0.0779
DEBUG - 2022-08-09 10:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:12 --> Total execution time: 0.0754
DEBUG - 2022-08-09 10:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:42 --> Total execution time: 0.1063
DEBUG - 2022-08-09 10:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:44 --> Total execution time: 0.0951
DEBUG - 2022-08-09 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:50 --> Total execution time: 0.0835
DEBUG - 2022-08-09 10:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:53 --> Total execution time: 0.0907
DEBUG - 2022-08-09 10:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:50:58 --> Total execution time: 0.0885
DEBUG - 2022-08-09 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:00 --> Total execution time: 0.0708
DEBUG - 2022-08-09 10:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:02 --> Total execution time: 0.0848
DEBUG - 2022-08-09 10:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:02 --> Total execution time: 0.1873
DEBUG - 2022-08-09 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:05 --> Total execution time: 0.0814
DEBUG - 2022-08-09 10:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:08 --> Total execution time: 0.0923
DEBUG - 2022-08-09 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:14 --> Total execution time: 0.0831
DEBUG - 2022-08-09 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:17 --> Total execution time: 0.0952
DEBUG - 2022-08-09 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:21 --> Total execution time: 0.0803
DEBUG - 2022-08-09 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:23 --> Total execution time: 0.0860
DEBUG - 2022-08-09 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:23 --> Total execution time: 0.0762
DEBUG - 2022-08-09 10:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:26 --> Total execution time: 0.0850
DEBUG - 2022-08-09 10:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:30 --> Total execution time: 0.0820
DEBUG - 2022-08-09 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:35 --> Total execution time: 0.0860
DEBUG - 2022-08-09 10:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:41 --> Total execution time: 0.0799
DEBUG - 2022-08-09 10:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:47 --> Total execution time: 0.0847
DEBUG - 2022-08-09 10:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:54 --> Total execution time: 0.0746
DEBUG - 2022-08-09 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:52:09 --> Total execution time: 0.0788
DEBUG - 2022-08-09 10:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:52:18 --> Total execution time: 0.1040
DEBUG - 2022-08-09 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:52:23 --> Total execution time: 0.0962
DEBUG - 2022-08-09 10:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:52:26 --> Total execution time: 0.0998
DEBUG - 2022-08-09 10:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:52:33 --> Total execution time: 0.0990
DEBUG - 2022-08-09 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:00 --> Total execution time: 0.0773
DEBUG - 2022-08-09 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:08 --> Total execution time: 0.0757
DEBUG - 2022-08-09 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:23 --> Total execution time: 0.1021
DEBUG - 2022-08-09 10:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:33 --> Total execution time: 0.0802
DEBUG - 2022-08-09 10:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:37 --> Total execution time: 0.0747
DEBUG - 2022-08-09 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:52 --> Total execution time: 0.0780
DEBUG - 2022-08-09 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:52 --> Total execution time: 0.0754
DEBUG - 2022-08-09 10:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:59 --> Total execution time: 0.1008
DEBUG - 2022-08-09 10:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:00 --> Total execution time: 0.0817
DEBUG - 2022-08-09 10:24:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:04 --> Total execution time: 0.0839
DEBUG - 2022-08-09 10:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:12 --> Total execution time: 0.0740
DEBUG - 2022-08-09 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:35 --> Total execution time: 0.0778
DEBUG - 2022-08-09 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:40 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:43 --> Total execution time: 0.0802
DEBUG - 2022-08-09 10:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:46 --> Total execution time: 0.1219
DEBUG - 2022-08-09 10:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:05 --> Total execution time: 0.0852
DEBUG - 2022-08-09 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:15 --> Total execution time: 0.0866
DEBUG - 2022-08-09 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:29 --> Total execution time: 0.1965
DEBUG - 2022-08-09 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:33 --> Total execution time: 0.0810
DEBUG - 2022-08-09 10:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:33 --> Total execution time: 0.0745
DEBUG - 2022-08-09 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:36 --> Total execution time: 0.0996
DEBUG - 2022-08-09 10:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:40 --> Total execution time: 0.0819
DEBUG - 2022-08-09 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:42 --> Total execution time: 0.0855
DEBUG - 2022-08-09 10:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:48 --> Total execution time: 0.0822
DEBUG - 2022-08-09 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:49 --> Total execution time: 0.1106
DEBUG - 2022-08-09 10:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:52 --> Total execution time: 0.0859
DEBUG - 2022-08-09 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:54 --> Total execution time: 0.0487
DEBUG - 2022-08-09 10:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:58 --> Total execution time: 0.0895
DEBUG - 2022-08-09 10:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:26:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:56:57 --> Total execution time: 0.0827
DEBUG - 2022-08-09 10:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:27:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:57:53 --> Total execution time: 0.0556
DEBUG - 2022-08-09 10:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:58:49 --> Total execution time: 0.2080
DEBUG - 2022-08-09 10:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:29:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:08 --> Total execution time: 0.0549
DEBUG - 2022-08-09 10:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:11 --> Total execution time: 0.2207
DEBUG - 2022-08-09 10:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:29:21 --> Total execution time: 0.0502
DEBUG - 2022-08-09 10:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:46 --> Total execution time: 0.0840
DEBUG - 2022-08-09 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:06 --> Total execution time: 0.0826
DEBUG - 2022-08-09 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:30:08 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-08-09 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:30:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 10:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:30:10 --> 404 Page Not Found: Admin-login/index
DEBUG - 2022-08-09 10:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:13 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:26 --> Total execution time: 0.1065
DEBUG - 2022-08-09 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:28 --> Total execution time: 0.1310
DEBUG - 2022-08-09 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:30 --> Total execution time: 0.0856
DEBUG - 2022-08-09 10:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:31 --> Total execution time: 0.1135
DEBUG - 2022-08-09 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:32 --> Total execution time: 0.1272
DEBUG - 2022-08-09 10:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:35 --> Total execution time: 0.0845
DEBUG - 2022-08-09 10:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:30:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:43 --> Total execution time: 0.1335
DEBUG - 2022-08-09 10:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:07 --> Total execution time: 0.0754
DEBUG - 2022-08-09 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:25 --> Total execution time: 0.0851
DEBUG - 2022-08-09 10:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:25 --> Total execution time: 0.0828
DEBUG - 2022-08-09 10:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:26 --> Total execution time: 0.0835
DEBUG - 2022-08-09 10:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:39 --> Total execution time: 0.0832
DEBUG - 2022-08-09 10:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:52 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:52 --> Total execution time: 0.0841
DEBUG - 2022-08-09 10:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 21:01:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 21:01:54 --> Total execution time: 0.2815
DEBUG - 2022-08-09 10:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:02:05 --> Total execution time: 0.0833
DEBUG - 2022-08-09 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:39 --> Total execution time: 0.0529
DEBUG - 2022-08-09 10:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:52 --> Total execution time: 0.0820
DEBUG - 2022-08-09 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:53 --> Total execution time: 0.0839
DEBUG - 2022-08-09 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:57 --> Total execution time: 0.0979
DEBUG - 2022-08-09 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:33:59 --> Total execution time: 0.1741
DEBUG - 2022-08-09 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:04:39 --> Total execution time: 0.0878
DEBUG - 2022-08-09 10:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:04:46 --> Total execution time: 0.0847
DEBUG - 2022-08-09 10:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:05:25 --> Total execution time: 0.0866
DEBUG - 2022-08-09 10:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:05:31 --> Total execution time: 0.0742
DEBUG - 2022-08-09 10:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:05:49 --> Total execution time: 0.0872
DEBUG - 2022-08-09 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:03 --> Total execution time: 0.1057
DEBUG - 2022-08-09 10:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:16 --> Total execution time: 0.0844
DEBUG - 2022-08-09 10:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:16 --> Total execution time: 0.0764
DEBUG - 2022-08-09 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:18 --> Total execution time: 0.0511
DEBUG - 2022-08-09 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:18 --> Total execution time: 0.0499
DEBUG - 2022-08-09 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:31 --> Total execution time: 0.0743
DEBUG - 2022-08-09 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:36 --> Total execution time: 0.0844
DEBUG - 2022-08-09 10:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:48 --> Total execution time: 0.0747
DEBUG - 2022-08-09 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:54 --> Total execution time: 0.2222
DEBUG - 2022-08-09 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:58 --> Total execution time: 0.0817
DEBUG - 2022-08-09 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:07:24 --> Total execution time: 0.0853
DEBUG - 2022-08-09 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:07:56 --> Total execution time: 0.0529
DEBUG - 2022-08-09 10:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:01 --> Total execution time: 0.0964
DEBUG - 2022-08-09 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:04 --> Total execution time: 0.0970
DEBUG - 2022-08-09 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:12 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:17 --> Total execution time: 0.0756
DEBUG - 2022-08-09 10:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:28 --> Total execution time: 0.0768
DEBUG - 2022-08-09 10:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:53 --> Total execution time: 0.1997
DEBUG - 2022-08-09 10:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:12 --> Total execution time: 0.1185
DEBUG - 2022-08-09 10:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:18 --> Total execution time: 0.0829
DEBUG - 2022-08-09 10:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:31 --> Total execution time: 0.0823
DEBUG - 2022-08-09 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:41 --> Total execution time: 0.0877
DEBUG - 2022-08-09 10:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:50 --> Total execution time: 0.1026
DEBUG - 2022-08-09 10:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:09:53 --> Total execution time: 0.0884
DEBUG - 2022-08-09 10:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:06 --> Total execution time: 0.0797
DEBUG - 2022-08-09 10:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:07 --> Total execution time: 0.1081
DEBUG - 2022-08-09 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:13 --> Total execution time: 0.1107
DEBUG - 2022-08-09 10:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:31 --> Total execution time: 0.1976
DEBUG - 2022-08-09 10:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:45 --> Total execution time: 0.0899
DEBUG - 2022-08-09 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:52 --> Total execution time: 0.0746
DEBUG - 2022-08-09 10:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:55 --> Total execution time: 0.0516
DEBUG - 2022-08-09 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:57 --> Total execution time: 0.0805
DEBUG - 2022-08-09 10:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:11:03 --> Total execution time: 0.2348
DEBUG - 2022-08-09 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:10 --> Total execution time: 0.0993
DEBUG - 2022-08-09 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:12 --> Total execution time: 0.0819
DEBUG - 2022-08-09 10:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:12 --> Total execution time: 0.1567
DEBUG - 2022-08-09 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:11:25 --> Total execution time: 0.1415
DEBUG - 2022-08-09 10:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:11:30 --> Total execution time: 0.2203
DEBUG - 2022-08-09 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:11:49 --> Total execution time: 0.0795
DEBUG - 2022-08-09 10:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:12:13 --> Total execution time: 0.0740
DEBUG - 2022-08-09 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:13:22 --> Total execution time: 0.0618
DEBUG - 2022-08-09 10:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:45:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:15:06 --> Total execution time: 0.0547
DEBUG - 2022-08-09 10:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:47:05 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:17:08 --> Total execution time: 2.1263
DEBUG - 2022-08-09 10:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:47:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 10:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:18:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 10:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:18:18 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:18:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 21:18:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 21:18:20 --> Total execution time: 0.2629
DEBUG - 2022-08-09 10:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:20 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:20 --> Total execution time: 0.0510
DEBUG - 2022-08-09 10:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:27 --> Total execution time: 0.0508
DEBUG - 2022-08-09 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:34 --> Total execution time: 0.0759
DEBUG - 2022-08-09 10:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:37 --> Total execution time: 0.1288
DEBUG - 2022-08-09 10:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:49:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:39 --> Total execution time: 0.0798
DEBUG - 2022-08-09 10:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:43 --> Total execution time: 0.0718
DEBUG - 2022-08-09 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:46 --> Total execution time: 0.0508
DEBUG - 2022-08-09 10:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:49 --> Total execution time: 0.0803
DEBUG - 2022-08-09 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:52 --> Total execution time: 0.1046
DEBUG - 2022-08-09 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:19:54 --> Total execution time: 0.1015
DEBUG - 2022-08-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:01 --> Total execution time: 0.1522
DEBUG - 2022-08-09 21:20:01 --> Total execution time: 0.2252
DEBUG - 2022-08-09 10:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:02 --> Total execution time: 0.0872
DEBUG - 2022-08-09 10:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:06 --> Total execution time: 0.0804
DEBUG - 2022-08-09 10:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:07 --> Total execution time: 0.0791
DEBUG - 2022-08-09 10:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:08 --> Total execution time: 0.1230
DEBUG - 2022-08-09 10:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:09 --> Total execution time: 0.0984
DEBUG - 2022-08-09 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:10 --> Total execution time: 0.0783
DEBUG - 2022-08-09 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:12 --> Total execution time: 0.0949
DEBUG - 2022-08-09 10:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:14 --> Total execution time: 0.0843
DEBUG - 2022-08-09 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:18 --> Total execution time: 0.0892
DEBUG - 2022-08-09 10:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:19 --> Total execution time: 0.1129
DEBUG - 2022-08-09 10:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:23 --> Total execution time: 0.0815
DEBUG - 2022-08-09 10:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:23 --> Total execution time: 0.0822
DEBUG - 2022-08-09 10:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:25 --> Total execution time: 0.0832
DEBUG - 2022-08-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:28 --> Total execution time: 0.0995
DEBUG - 2022-08-09 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:28 --> Total execution time: 0.0831
DEBUG - 2022-08-09 10:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:29 --> Total execution time: 0.0742
DEBUG - 2022-08-09 10:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:30 --> Total execution time: 0.0803
DEBUG - 2022-08-09 10:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:33 --> Total execution time: 0.1167
DEBUG - 2022-08-09 10:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:40 --> Total execution time: 0.0787
DEBUG - 2022-08-09 10:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:43 --> Total execution time: 0.0801
DEBUG - 2022-08-09 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:53 --> Total execution time: 0.1281
DEBUG - 2022-08-09 10:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:57 --> Total execution time: 0.0764
DEBUG - 2022-08-09 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:50:58 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:20:58 --> Total execution time: 0.0571
DEBUG - 2022-08-09 10:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:03 --> Total execution time: 0.0783
DEBUG - 2022-08-09 10:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:06 --> No URI present. Default controller set.
DEBUG - 2022-08-09 10:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:06 --> Total execution time: 0.0771
DEBUG - 2022-08-09 10:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:11 --> Total execution time: 0.0769
DEBUG - 2022-08-09 10:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:25 --> Total execution time: 0.0982
DEBUG - 2022-08-09 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:32 --> Total execution time: 0.0761
DEBUG - 2022-08-09 10:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:39 --> Total execution time: 0.0865
DEBUG - 2022-08-09 10:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:44 --> Total execution time: 0.0799
DEBUG - 2022-08-09 10:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:49 --> Total execution time: 0.0844
DEBUG - 2022-08-09 10:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:21:55 --> Total execution time: 0.0879
DEBUG - 2022-08-09 10:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:22:14 --> Total execution time: 0.0907
DEBUG - 2022-08-09 10:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:22:15 --> Total execution time: 0.0761
DEBUG - 2022-08-09 10:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:22:17 --> Total execution time: 0.0755
DEBUG - 2022-08-09 10:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:22:35 --> Total execution time: 0.1103
DEBUG - 2022-08-09 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:23:26 --> Total execution time: 0.0736
DEBUG - 2022-08-09 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 10:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:23:35 --> Total execution time: 0.0762
DEBUG - 2022-08-09 10:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:24:38 --> Total execution time: 0.1106
DEBUG - 2022-08-09 10:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:24:43 --> Total execution time: 0.0824
DEBUG - 2022-08-09 10:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:24:48 --> Total execution time: 0.0818
DEBUG - 2022-08-09 10:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:25:51 --> Total execution time: 0.1960
DEBUG - 2022-08-09 10:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:25:56 --> Total execution time: 0.0859
DEBUG - 2022-08-09 10:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:26:02 --> Total execution time: 0.1584
DEBUG - 2022-08-09 10:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:26:03 --> Total execution time: 0.1029
DEBUG - 2022-08-09 10:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 10:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:26:25 --> Total execution time: 0.0847
DEBUG - 2022-08-09 10:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:58:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:58:53 --> 404 Page Not Found: Wp-clearlinephp/index
DEBUG - 2022-08-09 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:59:13 --> 404 Page Not Found: Wp-blockdownphp/index
DEBUG - 2022-08-09 10:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 10:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 10:59:13 --> 404 Page Not Found: Wp-blockupphp/index
DEBUG - 2022-08-09 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:02 --> Total execution time: 0.1453
DEBUG - 2022-08-09 11:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:35 --> Total execution time: 0.1319
DEBUG - 2022-08-09 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:02:35 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:32:35 --> Total execution time: 0.0635
DEBUG - 2022-08-09 11:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:32:43 --> Total execution time: 0.0784
DEBUG - 2022-08-09 11:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:34:42 --> Total execution time: 0.0771
DEBUG - 2022-08-09 11:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:31 --> Total execution time: 0.0846
DEBUG - 2022-08-09 11:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:50 --> Total execution time: 0.0881
DEBUG - 2022-08-09 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:36:08 --> Total execution time: 0.0967
DEBUG - 2022-08-09 11:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:37:45 --> Total execution time: 0.0762
DEBUG - 2022-08-09 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:07:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:37:48 --> Total execution time: 0.0540
DEBUG - 2022-08-09 11:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:37:58 --> Total execution time: 0.0808
DEBUG - 2022-08-09 11:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:39:43 --> Total execution time: 0.0535
DEBUG - 2022-08-09 11:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:56 --> Total execution time: 0.0764
DEBUG - 2022-08-09 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:57 --> Total execution time: 0.1141
DEBUG - 2022-08-09 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:09:57 --> Total execution time: 0.2142
DEBUG - 2022-08-09 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:39:57 --> Total execution time: 0.2813
DEBUG - 2022-08-09 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:40:46 --> Total execution time: 0.0759
DEBUG - 2022-08-09 11:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 11:10:50 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-09 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:41:02 --> Total execution time: 0.0771
DEBUG - 2022-08-09 11:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:20 --> Total execution time: 0.0897
DEBUG - 2022-08-09 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:37 --> Total execution time: 0.0879
DEBUG - 2022-08-09 11:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:45 --> Total execution time: 0.0799
DEBUG - 2022-08-09 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:47 --> Total execution time: 0.0817
DEBUG - 2022-08-09 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:53 --> Total execution time: 0.1173
DEBUG - 2022-08-09 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:53 --> Total execution time: 0.1146
DEBUG - 2022-08-09 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:42:54 --> Total execution time: 0.1393
DEBUG - 2022-08-09 11:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:43:03 --> Total execution time: 0.0800
DEBUG - 2022-08-09 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:43:17 --> Total execution time: 0.0989
DEBUG - 2022-08-09 11:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:04 --> Total execution time: 0.2262
DEBUG - 2022-08-09 11:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:07 --> Total execution time: 0.0805
DEBUG - 2022-08-09 11:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:11 --> Total execution time: 0.0821
DEBUG - 2022-08-09 11:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:14 --> Total execution time: 0.0827
DEBUG - 2022-08-09 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:16 --> Total execution time: 0.0797
DEBUG - 2022-08-09 11:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:19 --> Total execution time: 0.1258
DEBUG - 2022-08-09 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:27 --> Total execution time: 0.0824
DEBUG - 2022-08-09 11:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:28 --> Total execution time: 0.0747
DEBUG - 2022-08-09 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:45:33 --> Total execution time: 0.0819
DEBUG - 2022-08-09 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:46:05 --> Total execution time: 0.0838
DEBUG - 2022-08-09 11:16:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:46:07 --> Total execution time: 0.0797
DEBUG - 2022-08-09 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:46:49 --> Total execution time: 0.0482
DEBUG - 2022-08-09 11:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:46:56 --> Total execution time: 0.0872
DEBUG - 2022-08-09 11:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:17:11 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:47:11 --> Total execution time: 0.0978
DEBUG - 2022-08-09 11:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:47:18 --> Total execution time: 0.0852
DEBUG - 2022-08-09 11:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:47:21 --> Total execution time: 0.0910
DEBUG - 2022-08-09 11:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:47:31 --> Total execution time: 0.0765
DEBUG - 2022-08-09 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:49:41 --> Total execution time: 0.0744
DEBUG - 2022-08-09 11:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:49:46 --> Total execution time: 0.2233
DEBUG - 2022-08-09 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:19:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:49:53 --> Total execution time: 0.0855
DEBUG - 2022-08-09 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:50:03 --> Total execution time: 0.1400
DEBUG - 2022-08-09 11:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:50:06 --> Total execution time: 0.0592
DEBUG - 2022-08-09 11:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:50:23 --> Total execution time: 0.1259
DEBUG - 2022-08-09 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:50:38 --> Total execution time: 0.0944
DEBUG - 2022-08-09 11:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:50:47 --> Total execution time: 0.0940
DEBUG - 2022-08-09 11:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:51:20 --> Total execution time: 0.0825
DEBUG - 2022-08-09 11:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:51:40 --> Total execution time: 0.2470
DEBUG - 2022-08-09 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:52:27 --> Total execution time: 0.0981
DEBUG - 2022-08-09 11:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:52:46 --> Total execution time: 0.2114
DEBUG - 2022-08-09 11:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:23:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:53:43 --> Total execution time: 0.2334
DEBUG - 2022-08-09 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:53:46 --> Total execution time: 0.0940
DEBUG - 2022-08-09 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:21 --> Total execution time: 0.0906
DEBUG - 2022-08-09 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:26 --> Total execution time: 0.0812
DEBUG - 2022-08-09 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:26 --> Total execution time: 0.0764
DEBUG - 2022-08-09 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:30 --> Total execution time: 0.0857
DEBUG - 2022-08-09 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:34 --> Total execution time: 0.0740
DEBUG - 2022-08-09 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:39 --> Total execution time: 0.0745
DEBUG - 2022-08-09 11:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:39 --> Total execution time: 0.0886
DEBUG - 2022-08-09 11:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:43 --> Total execution time: 0.2239
DEBUG - 2022-08-09 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:24:44 --> Total execution time: 0.0762
DEBUG - 2022-08-09 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:01 --> Total execution time: 0.0869
DEBUG - 2022-08-09 11:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:50 --> Total execution time: 0.2781
DEBUG - 2022-08-09 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:53 --> Total execution time: 0.1072
DEBUG - 2022-08-09 11:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:58 --> Total execution time: 0.0839
DEBUG - 2022-08-09 11:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:59:01 --> Total execution time: 0.1253
DEBUG - 2022-08-09 11:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:59:06 --> Total execution time: 0.1145
DEBUG - 2022-08-09 11:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:29:25 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:59:25 --> Total execution time: 0.0567
DEBUG - 2022-08-09 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:26 --> Total execution time: 0.0900
DEBUG - 2022-08-09 11:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:29 --> Total execution time: 0.1236
DEBUG - 2022-08-09 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:30 --> Total execution time: 0.0876
DEBUG - 2022-08-09 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:46 --> Total execution time: 0.1189
DEBUG - 2022-08-09 11:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:50 --> Total execution time: 0.0908
DEBUG - 2022-08-09 11:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:31:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:01:42 --> Total execution time: 0.1064
DEBUG - 2022-08-09 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:01:49 --> Total execution time: 0.0839
DEBUG - 2022-08-09 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:00 --> Total execution time: 0.0880
DEBUG - 2022-08-09 11:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:04 --> Total execution time: 0.0804
DEBUG - 2022-08-09 11:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:06 --> Total execution time: 0.0896
DEBUG - 2022-08-09 11:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:09 --> Total execution time: 0.0759
DEBUG - 2022-08-09 11:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:14 --> Total execution time: 0.1084
DEBUG - 2022-08-09 11:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:20 --> Total execution time: 0.0776
DEBUG - 2022-08-09 11:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:32:21 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:02:21 --> Total execution time: 0.0717
DEBUG - 2022-08-09 11:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:03:18 --> Total execution time: 0.1016
DEBUG - 2022-08-09 11:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:03:24 --> Total execution time: 0.1971
DEBUG - 2022-08-09 11:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:03:28 --> Total execution time: 0.0787
DEBUG - 2022-08-09 11:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:03:35 --> Total execution time: 0.0805
DEBUG - 2022-08-09 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:03:39 --> Total execution time: 0.0928
DEBUG - 2022-08-09 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:04:19 --> Total execution time: 0.0745
DEBUG - 2022-08-09 11:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:04:22 --> Total execution time: 0.1951
DEBUG - 2022-08-09 11:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:04:27 --> Total execution time: 0.1059
DEBUG - 2022-08-09 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:06:50 --> Total execution time: 0.0833
DEBUG - 2022-08-09 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:07 --> Total execution time: 0.0844
DEBUG - 2022-08-09 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:16 --> Total execution time: 0.1190
DEBUG - 2022-08-09 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:20 --> Total execution time: 0.0777
DEBUG - 2022-08-09 11:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:25 --> Total execution time: 0.0848
DEBUG - 2022-08-09 11:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:29 --> Total execution time: 0.1092
DEBUG - 2022-08-09 11:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:33 --> Total execution time: 0.0787
DEBUG - 2022-08-09 11:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:36 --> Total execution time: 0.1431
DEBUG - 2022-08-09 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:37:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:52 --> Total execution time: 0.0593
DEBUG - 2022-08-09 11:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:08:12 --> Total execution time: 0.0497
DEBUG - 2022-08-09 11:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:08:23 --> Total execution time: 0.2044
DEBUG - 2022-08-09 11:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:38:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:08:32 --> Total execution time: 0.0910
DEBUG - 2022-08-09 11:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:08:57 --> Total execution time: 0.0821
DEBUG - 2022-08-09 11:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:04 --> Total execution time: 0.1220
DEBUG - 2022-08-09 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:13 --> Total execution time: 0.0828
DEBUG - 2022-08-09 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:53 --> Total execution time: 0.0794
DEBUG - 2022-08-09 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:07 --> Total execution time: 0.0905
DEBUG - 2022-08-09 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:12 --> Total execution time: 0.0808
DEBUG - 2022-08-09 11:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:17 --> Total execution time: 0.1017
DEBUG - 2022-08-09 11:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:24 --> Total execution time: 0.0940
DEBUG - 2022-08-09 11:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:30 --> Total execution time: 0.0858
DEBUG - 2022-08-09 11:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:30 --> Total execution time: 0.0997
DEBUG - 2022-08-09 11:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:31 --> Total execution time: 0.0790
DEBUG - 2022-08-09 11:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:51 --> Total execution time: 0.0774
DEBUG - 2022-08-09 11:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:52 --> Total execution time: 0.0763
DEBUG - 2022-08-09 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:56 --> Total execution time: 0.1056
DEBUG - 2022-08-09 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:11:02 --> Total execution time: 0.0731
DEBUG - 2022-08-09 11:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:11:17 --> Total execution time: 0.0901
DEBUG - 2022-08-09 11:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:11:39 --> Total execution time: 0.0934
DEBUG - 2022-08-09 11:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:11:59 --> Total execution time: 0.1212
DEBUG - 2022-08-09 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:09 --> Total execution time: 0.0531
DEBUG - 2022-08-09 11:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:14 --> Total execution time: 0.0912
DEBUG - 2022-08-09 11:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:28 --> Total execution time: 0.2100
DEBUG - 2022-08-09 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:29 --> Total execution time: 0.0887
DEBUG - 2022-08-09 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:39 --> Total execution time: 0.0994
DEBUG - 2022-08-09 11:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:42 --> Total execution time: 0.1000
DEBUG - 2022-08-09 11:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:42:51 --> Total execution time: 0.1027
DEBUG - 2022-08-09 11:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:54 --> Total execution time: 0.1049
DEBUG - 2022-08-09 11:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:13:01 --> Total execution time: 0.1042
DEBUG - 2022-08-09 11:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:13:04 --> Total execution time: 0.1069
DEBUG - 2022-08-09 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:13:26 --> Total execution time: 0.0977
DEBUG - 2022-08-09 11:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:43:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 11:43:34 --> 404 Page Not Found: Wp-sidphp/index
DEBUG - 2022-08-09 11:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:01 --> Total execution time: 0.0513
DEBUG - 2022-08-09 11:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:09 --> Total execution time: 0.0847
DEBUG - 2022-08-09 11:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:22 --> Total execution time: 0.0798
DEBUG - 2022-08-09 11:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:53 --> Total execution time: 0.0909
DEBUG - 2022-08-09 11:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:17:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 11:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:17:24 --> Total execution time: 0.0847
DEBUG - 2022-08-09 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:17:37 --> Total execution time: 0.2179
DEBUG - 2022-08-09 11:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:49:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:19:34 --> Total execution time: 0.0559
DEBUG - 2022-08-09 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:19:42 --> Total execution time: 0.0756
DEBUG - 2022-08-09 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:53:00 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:23:00 --> Total execution time: 0.1218
DEBUG - 2022-08-09 11:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:53:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:23:01 --> Total execution time: 0.0709
DEBUG - 2022-08-09 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:23:17 --> Total execution time: 0.2231
DEBUG - 2022-08-09 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:23:26 --> Total execution time: 0.0870
DEBUG - 2022-08-09 11:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:26:12 --> Total execution time: 0.3062
DEBUG - 2022-08-09 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:26:46 --> Total execution time: 0.0956
DEBUG - 2022-08-09 11:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:27:08 --> Total execution time: 0.0850
DEBUG - 2022-08-09 11:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:27:12 --> Total execution time: 0.0799
DEBUG - 2022-08-09 11:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:27:26 --> Total execution time: 0.0861
DEBUG - 2022-08-09 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:27:30 --> Total execution time: 0.0890
DEBUG - 2022-08-09 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:27:33 --> Total execution time: 0.0886
DEBUG - 2022-08-09 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:58:17 --> Total execution time: 0.0881
DEBUG - 2022-08-09 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:58:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:28:50 --> Total execution time: 0.0553
DEBUG - 2022-08-09 11:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:58:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 11:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:28:52 --> Total execution time: 0.0877
DEBUG - 2022-08-09 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 11:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 11:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 11:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:29:58 --> Total execution time: 0.0628
DEBUG - 2022-08-09 12:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:01 --> Total execution time: 0.0859
DEBUG - 2022-08-09 12:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:00:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:31 --> Total execution time: 0.0512
DEBUG - 2022-08-09 12:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:01:26 --> Total execution time: 0.1365
DEBUG - 2022-08-09 12:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:32:08 --> Total execution time: 0.1108
DEBUG - 2022-08-09 12:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:32:19 --> Total execution time: 0.1096
DEBUG - 2022-08-09 12:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:32:24 --> Total execution time: 0.1095
DEBUG - 2022-08-09 12:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:32:26 --> Total execution time: 0.1168
DEBUG - 2022-08-09 12:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:32:28 --> Total execution time: 0.0793
DEBUG - 2022-08-09 12:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:03:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:33:15 --> Total execution time: 0.0545
DEBUG - 2022-08-09 12:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:35:06 --> Total execution time: 0.0536
DEBUG - 2022-08-09 12:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:35:51 --> Total execution time: 0.0750
DEBUG - 2022-08-09 12:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:04 --> Total execution time: 0.0943
DEBUG - 2022-08-09 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:23 --> Total execution time: 0.0782
DEBUG - 2022-08-09 12:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:49 --> Total execution time: 0.0567
DEBUG - 2022-08-09 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:51 --> Total execution time: 0.0686
DEBUG - 2022-08-09 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:37:03 --> Total execution time: 0.0817
DEBUG - 2022-08-09 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:07:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:37:42 --> Total execution time: 0.0536
DEBUG - 2022-08-09 12:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:08:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:38:57 --> Total execution time: 0.0713
DEBUG - 2022-08-09 12:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:38:59 --> Total execution time: 0.0846
DEBUG - 2022-08-09 12:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:15 --> Total execution time: 0.0720
DEBUG - 2022-08-09 12:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:33 --> Total execution time: 0.0960
DEBUG - 2022-08-09 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:38 --> Total execution time: 0.0851
DEBUG - 2022-08-09 12:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:43 --> Total execution time: 0.0927
DEBUG - 2022-08-09 12:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:48 --> Total execution time: 0.1055
DEBUG - 2022-08-09 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:57 --> Total execution time: 0.1166
DEBUG - 2022-08-09 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:40:02 --> Total execution time: 0.1073
DEBUG - 2022-08-09 12:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:40:10 --> Total execution time: 0.1154
DEBUG - 2022-08-09 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:40:30 --> Total execution time: 0.2086
DEBUG - 2022-08-09 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:40:46 --> Total execution time: 0.0929
DEBUG - 2022-08-09 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:40:47 --> Total execution time: 0.0867
DEBUG - 2022-08-09 12:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:02 --> Total execution time: 0.0761
DEBUG - 2022-08-09 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:58 --> Total execution time: 0.0936
DEBUG - 2022-08-09 12:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:01 --> Total execution time: 0.1615
DEBUG - 2022-08-09 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:07 --> Total execution time: 0.1120
DEBUG - 2022-08-09 12:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:07 --> Total execution time: 0.0845
DEBUG - 2022-08-09 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:27 --> Total execution time: 0.0934
DEBUG - 2022-08-09 12:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:21 --> Total execution time: 0.0954
DEBUG - 2022-08-09 12:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:44:40 --> Total execution time: 0.0813
DEBUG - 2022-08-09 12:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:45:15 --> Total execution time: 0.0919
DEBUG - 2022-08-09 12:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:01 --> Total execution time: 0.1097
DEBUG - 2022-08-09 12:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:47:24 --> Total execution time: 0.0835
DEBUG - 2022-08-09 12:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:47:57 --> Total execution time: 0.0980
DEBUG - 2022-08-09 12:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:48:30 --> Total execution time: 0.0985
DEBUG - 2022-08-09 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:18:30 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:48:30 --> Total execution time: 0.0529
DEBUG - 2022-08-09 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:48:38 --> Total execution time: 0.0610
DEBUG - 2022-08-09 12:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:00 --> Total execution time: 0.0759
DEBUG - 2022-08-09 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:01 --> Total execution time: 0.0895
DEBUG - 2022-08-09 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:04 --> Total execution time: 0.0545
DEBUG - 2022-08-09 12:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:18 --> Total execution time: 0.1034
DEBUG - 2022-08-09 12:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:21 --> Total execution time: 0.0858
DEBUG - 2022-08-09 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:32 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:32 --> Total execution time: 0.0526
DEBUG - 2022-08-09 12:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:32 --> Total execution time: 0.0820
DEBUG - 2022-08-09 12:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:38 --> Total execution time: 0.1002
DEBUG - 2022-08-09 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:41 --> Total execution time: 0.0820
DEBUG - 2022-08-09 12:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:49 --> Total execution time: 0.1026
DEBUG - 2022-08-09 12:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:50 --> Total execution time: 0.0810
DEBUG - 2022-08-09 12:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:49:55 --> Total execution time: 0.0849
DEBUG - 2022-08-09 12:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:50:00 --> Total execution time: 0.0865
DEBUG - 2022-08-09 12:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:50:08 --> Total execution time: 0.0781
DEBUG - 2022-08-09 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:50:48 --> Total execution time: 0.0783
DEBUG - 2022-08-09 12:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:53:17 --> Total execution time: 0.3786
DEBUG - 2022-08-09 12:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:54:23 --> Total execution time: 0.0822
DEBUG - 2022-08-09 12:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:24:49 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:24:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:54:49 --> Total execution time: 0.0840
DEBUG - 2022-08-09 12:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:55:02 --> Total execution time: 0.0833
DEBUG - 2022-08-09 12:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:55:28 --> Total execution time: 0.0856
DEBUG - 2022-08-09 12:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:55:34 --> Total execution time: 0.1096
DEBUG - 2022-08-09 12:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:55:46 --> Total execution time: 0.0817
DEBUG - 2022-08-09 12:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:55:51 --> Total execution time: 0.0931
DEBUG - 2022-08-09 12:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:56:10 --> Total execution time: 0.0760
DEBUG - 2022-08-09 12:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:41 --> Total execution time: 0.0755
DEBUG - 2022-08-09 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:57 --> Total execution time: 0.0759
DEBUG - 2022-08-09 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:59:57 --> Total execution time: 0.0798
DEBUG - 2022-08-09 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:00 --> Total execution time: 0.0766
DEBUG - 2022-08-09 12:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:33 --> Total execution time: 0.0783
DEBUG - 2022-08-09 12:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:00 --> Total execution time: 0.0774
DEBUG - 2022-08-09 12:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:09 --> Total execution time: 0.0745
DEBUG - 2022-08-09 12:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:18 --> Total execution time: 0.0794
DEBUG - 2022-08-09 12:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:30 --> Total execution time: 0.0798
DEBUG - 2022-08-09 12:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:33 --> Total execution time: 0.2007
DEBUG - 2022-08-09 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:37 --> Total execution time: 0.1505
DEBUG - 2022-08-09 12:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:47 --> Total execution time: 0.1081
DEBUG - 2022-08-09 12:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:22 --> Total execution time: 2.0371
DEBUG - 2022-08-09 12:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:32:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 12:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 12:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:27 --> Total execution time: 0.1045
DEBUG - 2022-08-09 12:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:37 --> Total execution time: 0.0792
DEBUG - 2022-08-09 12:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:45 --> Total execution time: 0.1057
DEBUG - 2022-08-09 12:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:46 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:46 --> Total execution time: 0.0879
DEBUG - 2022-08-09 12:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:55 --> Total execution time: 1.5165
DEBUG - 2022-08-09 12:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:32:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:57 --> Total execution time: 0.0758
DEBUG - 2022-08-09 12:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:03:18 --> Total execution time: 1.5216
DEBUG - 2022-08-09 12:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:33:25 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:03:25 --> Total execution time: 0.0899
DEBUG - 2022-08-09 12:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:34:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:04:51 --> Total execution time: 0.0536
DEBUG - 2022-08-09 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:35:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:23 --> Total execution time: 0.0526
DEBUG - 2022-08-09 12:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:35:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:23 --> Total execution time: 0.0503
DEBUG - 2022-08-09 12:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:29 --> Total execution time: 0.0500
DEBUG - 2022-08-09 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:31 --> Total execution time: 0.0870
DEBUG - 2022-08-09 12:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:41 --> Total execution time: 0.0980
DEBUG - 2022-08-09 12:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:06:24 --> Total execution time: 0.0869
DEBUG - 2022-08-09 12:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:36:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:06:37 --> Total execution time: 0.0741
DEBUG - 2022-08-09 12:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:37:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:07:57 --> Total execution time: 0.0652
DEBUG - 2022-08-09 12:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:38:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:08:28 --> Total execution time: 0.2164
DEBUG - 2022-08-09 12:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:08:44 --> Total execution time: 0.0932
DEBUG - 2022-08-09 12:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:10:01 --> Total execution time: 0.2922
DEBUG - 2022-08-09 12:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:41:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 12:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:11:34 --> Total execution time: 0.0617
DEBUG - 2022-08-09 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:11:51 --> Total execution time: 0.0494
DEBUG - 2022-08-09 12:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:12:06 --> Total execution time: 0.0875
DEBUG - 2022-08-09 12:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:43:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:04 --> Total execution time: 0.0813
DEBUG - 2022-08-09 12:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:44 --> Total execution time: 0.0788
DEBUG - 2022-08-09 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:08 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:11 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 12:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:15 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:35 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 12:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 12:45:54 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-08-09 12:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:16:08 --> Total execution time: 0.0534
DEBUG - 2022-08-09 12:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:16:27 --> Total execution time: 0.0804
DEBUG - 2022-08-09 12:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:00 --> Total execution time: 0.2371
DEBUG - 2022-08-09 12:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:08 --> Total execution time: 0.0878
DEBUG - 2022-08-09 12:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:18 --> Total execution time: 0.0818
DEBUG - 2022-08-09 12:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:25 --> Total execution time: 0.0776
DEBUG - 2022-08-09 12:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:41 --> Total execution time: 0.4616
DEBUG - 2022-08-09 12:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:18:57 --> Total execution time: 0.0825
DEBUG - 2022-08-09 12:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:19:09 --> Total execution time: 0.0855
DEBUG - 2022-08-09 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:19:54 --> Total execution time: 0.0768
DEBUG - 2022-08-09 12:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:20:20 --> Total execution time: 0.0760
DEBUG - 2022-08-09 12:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:20:57 --> Total execution time: 0.0860
DEBUG - 2022-08-09 12:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:21:06 --> Total execution time: 0.0745
DEBUG - 2022-08-09 12:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:21:30 --> Total execution time: 0.2332
DEBUG - 2022-08-09 12:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:21:37 --> Total execution time: 0.2466
DEBUG - 2022-08-09 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 12:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:21:49 --> Total execution time: 0.0821
DEBUG - 2022-08-09 12:52:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:52:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:22:23 --> Total execution time: 0.0753
DEBUG - 2022-08-09 12:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:22:40 --> Total execution time: 0.1010
DEBUG - 2022-08-09 12:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 12:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 12:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:22:50 --> Total execution time: 0.0747
DEBUG - 2022-08-09 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:30:02 --> Total execution time: 0.1541
DEBUG - 2022-08-09 13:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:31:03 --> Total execution time: 0.0910
DEBUG - 2022-08-09 13:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:03:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:33:10 --> Total execution time: 0.0613
DEBUG - 2022-08-09 13:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:03:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:33:10 --> Total execution time: 0.0504
DEBUG - 2022-08-09 13:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:36:48 --> Total execution time: 0.2774
DEBUG - 2022-08-09 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:07:32 --> Total execution time: 0.0555
DEBUG - 2022-08-09 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:07:34 --> Total execution time: 0.0740
DEBUG - 2022-08-09 13:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:07:35 --> Total execution time: 0.1668
DEBUG - 2022-08-09 13:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:07:47 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:37:47 --> Total execution time: 0.0951
DEBUG - 2022-08-09 13:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:38:55 --> Total execution time: 0.2292
DEBUG - 2022-08-09 13:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:16 --> Total execution time: 0.0924
DEBUG - 2022-08-09 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:19 --> Total execution time: 0.1082
DEBUG - 2022-08-09 13:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:21 --> Total execution time: 0.0847
DEBUG - 2022-08-09 13:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:23 --> Total execution time: 0.0959
DEBUG - 2022-08-09 13:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:25 --> Total execution time: 0.1076
DEBUG - 2022-08-09 13:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:10:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:40:29 --> Total execution time: 0.0583
DEBUG - 2022-08-09 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:41:21 --> Total execution time: 0.0495
DEBUG - 2022-08-09 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:11:29 --> Total execution time: 0.0755
DEBUG - 2022-08-09 13:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:11:29 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:41:29 --> Total execution time: 0.0720
DEBUG - 2022-08-09 13:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:11:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 13:11:29 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-08-09 13:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:44:54 --> Total execution time: 0.1590
DEBUG - 2022-08-09 13:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:19:50 --> Total execution time: 0.0839
DEBUG - 2022-08-09 13:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:50:19 --> Total execution time: 0.0919
DEBUG - 2022-08-09 13:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:50:27 --> Total execution time: 0.0758
DEBUG - 2022-08-09 13:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:21 --> Total execution time: 0.1470
DEBUG - 2022-08-09 13:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:07 --> Total execution time: 0.2133
DEBUG - 2022-08-09 13:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:12 --> Total execution time: 0.1222
DEBUG - 2022-08-09 13:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:18 --> Total execution time: 0.1280
DEBUG - 2022-08-09 13:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:23 --> Total execution time: 0.0859
DEBUG - 2022-08-09 13:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:33 --> Total execution time: 0.0837
DEBUG - 2022-08-09 13:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:41 --> Total execution time: 0.2028
DEBUG - 2022-08-09 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:46 --> Total execution time: 0.0789
DEBUG - 2022-08-09 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:46 --> Total execution time: 0.1893
DEBUG - 2022-08-09 13:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:47 --> Total execution time: 0.0759
DEBUG - 2022-08-09 13:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:51 --> Total execution time: 0.1196
DEBUG - 2022-08-09 13:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:58 --> Total execution time: 0.0966
DEBUG - 2022-08-09 13:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:03 --> Total execution time: 0.0896
DEBUG - 2022-08-09 13:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:03 --> Total execution time: 0.1012
DEBUG - 2022-08-09 13:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:11 --> Total execution time: 0.0893
DEBUG - 2022-08-09 13:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:18 --> Total execution time: 0.0788
DEBUG - 2022-08-09 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:27 --> Total execution time: 0.1041
DEBUG - 2022-08-09 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:33 --> Total execution time: 0.0857
DEBUG - 2022-08-09 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:34 --> Total execution time: 0.0807
DEBUG - 2022-08-09 13:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:36 --> Total execution time: 0.0929
DEBUG - 2022-08-09 13:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:43 --> Total execution time: 0.0869
DEBUG - 2022-08-09 13:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:47 --> Total execution time: 0.0808
DEBUG - 2022-08-09 13:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:48 --> Total execution time: 0.0787
DEBUG - 2022-08-09 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:49 --> Total execution time: 0.0780
DEBUG - 2022-08-09 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:49 --> Total execution time: 0.1108
DEBUG - 2022-08-09 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:49 --> Total execution time: 0.0860
DEBUG - 2022-08-09 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:49 --> Total execution time: 0.0878
DEBUG - 2022-08-09 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:50 --> Total execution time: 0.1072
DEBUG - 2022-08-09 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:50 --> Total execution time: 0.0814
DEBUG - 2022-08-09 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:59:23 --> Total execution time: 0.0492
DEBUG - 2022-08-09 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 13:40:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 13:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:40:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:43:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 13:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 13:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 13:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 13:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 14:10:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 14:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 14:10:10 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-08-09 14:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:22:13 --> No URI present. Default controller set.
DEBUG - 2022-08-09 14:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:40:41 --> No URI present. Default controller set.
DEBUG - 2022-08-09 14:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 14:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:45:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 14:45:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 14:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 14:45:41 --> 404 Page Not Found: Product/super-gold-membership
DEBUG - 2022-08-09 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:53:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 14:53:23 --> 404 Page Not Found: Learning-friendship-and-fun-for-everyone/index
DEBUG - 2022-08-09 14:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 14:53:55 --> No URI present. Default controller set.
DEBUG - 2022-08-09 14:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 14:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:10:44 --> No URI present. Default controller set.
DEBUG - 2022-08-09 15:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:22 --> Total execution time: 0.0790
DEBUG - 2022-08-09 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:33:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 15:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:47:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 15:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:51 --> No URI present. Default controller set.
DEBUG - 2022-08-09 15:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 15:48:53 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-09 15:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 15:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 15:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 15:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 15:48:56 --> 404 Page Not Found: Debuglog/index
DEBUG - 2022-08-09 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 15:48:57 --> 404 Page Not Found: Errorlog/index
DEBUG - 2022-08-09 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 15:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 15:48:57 --> 404 Page Not Found: Accesslog/index
DEBUG - 2022-08-09 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:10 --> No URI present. Default controller set.
DEBUG - 2022-08-09 16:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 16:23:40 --> 404 Page Not Found: Phpinfohtml/index
DEBUG - 2022-08-09 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:33:34 --> No URI present. Default controller set.
DEBUG - 2022-08-09 16:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:33:49 --> No URI present. Default controller set.
DEBUG - 2022-08-09 16:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 16:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:36:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:38:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:51:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 16:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 16:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 16:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 17:03:58 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-08-09 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:12:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 17:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 17:12:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 17:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:12:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 17:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:12:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 17:15:21 --> 404 Page Not Found: Login/index
DEBUG - 2022-08-09 17:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 17:15:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 17:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:16:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 17:16:29 --> 404 Page Not Found: My-account/index
DEBUG - 2022-08-09 17:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:34:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:38:12 --> No URI present. Default controller set.
DEBUG - 2022-08-09 17:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 17:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 17:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 17:44:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:20:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 18:20:34 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 18:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:34:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 18:34:17 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 18:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:36:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 18:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:41:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 18:41:33 --> 404 Page Not Found: Lessons/single-message-hack
DEBUG - 2022-08-09 18:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:44:56 --> No URI present. Default controller set.
DEBUG - 2022-08-09 18:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 18:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 18:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 18:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:05:19 --> No URI present. Default controller set.
DEBUG - 2022-08-09 19:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:11:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 19:11:42 --> 404 Page Not Found: Lessons/colum-customization
DEBUG - 2022-08-09 19:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:47:05 --> No URI present. Default controller set.
DEBUG - 2022-08-09 19:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:51:01 --> No URI present. Default controller set.
DEBUG - 2022-08-09 19:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 19:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 19:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 19:59:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:01:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:01:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:01:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 20:01:24 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-09 20:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:05:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:05:40 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:06:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:14:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:14:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 20:25:44 --> 404 Page Not Found: Affiliate-account-page/esalestrix.in
DEBUG - 2022-08-09 20:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:51:16 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:53:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:55:54 --> No URI present. Default controller set.
DEBUG - 2022-08-09 20:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:56:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 20:56:24 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 20:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 20:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 20:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 20:59:33 --> Total execution time: 0.0803
DEBUG - 2022-08-09 21:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:30 --> Total execution time: 0.0738
DEBUG - 2022-08-09 21:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:00:58 --> Total execution time: 0.0791
DEBUG - 2022-08-09 21:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:12 --> Total execution time: 0.0853
DEBUG - 2022-08-09 21:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:19 --> Total execution time: 0.1075
DEBUG - 2022-08-09 21:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:01:36 --> Total execution time: 0.0753
DEBUG - 2022-08-09 21:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:08:20 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 21:12:06 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-08-09 21:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 21:12:06 --> 404 Page Not Found: Apple-app-site-association/index
DEBUG - 2022-08-09 21:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 21:12:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-08-09 21:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:03 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:31:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:35:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:39:36 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:47:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 21:47:38 --> 404 Page Not Found: Awsyml/index
DEBUG - 2022-08-09 21:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:52:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:53:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:54:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:56:39 --> Total execution time: 0.1045
DEBUG - 2022-08-09 21:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 21:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:36 --> Total execution time: 0.0862
DEBUG - 2022-08-09 21:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:38 --> Total execution time: 0.1024
DEBUG - 2022-08-09 21:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:38 --> Total execution time: 0.1983
DEBUG - 2022-08-09 21:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 21:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 21:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 21:58:50 --> Total execution time: 0.1132
DEBUG - 2022-08-09 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:01:08 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 22:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:01:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 22:01:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 22:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:04:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:04:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:05:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:06:58 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:00 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:24 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:30:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:36:38 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:36:39 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:39:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:39:15 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:20 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:43 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:54 --> Total execution time: 0.0897
DEBUG - 2022-08-09 22:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:55 --> Total execution time: 0.0873
DEBUG - 2022-08-09 22:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:43:55 --> Total execution time: 0.1930
DEBUG - 2022-08-09 22:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:45:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:48:47 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:56:36 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:56:37 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 22:56:38 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-08-09 22:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:18 --> No URI present. Default controller set.
DEBUG - 2022-08-09 22:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 22:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 22:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 22:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:00:11 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 23:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:01:17 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:09:14 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:10:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:25:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:25:43 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-08-09 23:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:27:31 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:31:36 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:31:48 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:32:36 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:32:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:48:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:48:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:48:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:48:57 --> Unable to connect to the database
ERROR - 2022-08-09 23:48:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:48:57 --> Unable to connect to the database
ERROR - 2022-08-09 23:48:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
ERROR - 2022-08-09 23:48:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:48:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:48:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:02 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:08 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:08 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:22 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:23 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:23 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:25 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:25 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:49:33 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:49:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-08-09 23:49:33 --> Unable to connect to the database
ERROR - 2022-08-09 23:49:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-08-09 23:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:50:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:04 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:09 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:53:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:53:22 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 23:53:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-08-09 23:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:53:52 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:54:57 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:54:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:55:42 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:56:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:02 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:27 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:57:50 --> No URI present. Default controller set.
DEBUG - 2022-08-09 23:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-08-09 23:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 23:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 23:59:50 --> Encryption: Auto-configured driver 'openssl'.
