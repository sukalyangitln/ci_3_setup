<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-13 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 12:49:27 --> Total execution time: 0.6942
DEBUG - 2023-01-13 12:49:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 12:49:41 --> Total execution time: 0.0927
DEBUG - 2023-01-13 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 12:50:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:01 --> Total execution time: 0.1242
DEBUG - 2023-01-13 12:50:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:12 --> Total execution time: 0.1431
DEBUG - 2023-01-13 12:50:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:22 --> No URI present. Default controller set.
DEBUG - 2023-01-13 12:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:22 --> Total execution time: 0.1329
DEBUG - 2023-01-13 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:25 --> Total execution time: 0.0916
DEBUG - 2023-01-13 12:50:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:28 --> Total execution time: 0.1071
DEBUG - 2023-01-13 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:20:55 --> Total execution time: 0.1185
DEBUG - 2023-01-13 12:51:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:21:04 --> Total execution time: 0.1701
DEBUG - 2023-01-13 12:51:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:21:26 --> Total execution time: 0.0906
DEBUG - 2023-01-13 12:51:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:21:32 --> Total execution time: 0.1148
DEBUG - 2023-01-13 12:57:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:57:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:27:26 --> Total execution time: 0.0449
DEBUG - 2023-01-13 12:57:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 12:57:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:27:48 --> Total execution time: 0.0441
DEBUG - 2023-01-13 12:57:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:27:48 --> Total execution time: 0.0484
DEBUG - 2023-01-13 12:58:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:28:50 --> Total execution time: 0.0563
DEBUG - 2023-01-13 12:58:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:28:50 --> Total execution time: 0.0509
DEBUG - 2023-01-13 12:59:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:29:51 --> Total execution time: 0.0660
DEBUG - 2023-01-13 12:59:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 12:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 12:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 12:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:29:51 --> Total execution time: 0.0478
DEBUG - 2023-01-13 13:00:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:30:05 --> Total execution time: 0.0527
DEBUG - 2023-01-13 13:00:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:30:05 --> Total execution time: 0.0498
DEBUG - 2023-01-13 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:11 --> Total execution time: 0.0601
DEBUG - 2023-01-13 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:12 --> Total execution time: 0.0495
DEBUG - 2023-01-13 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:37 --> Total execution time: 0.0743
DEBUG - 2023-01-13 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:38 --> Total execution time: 0.0473
DEBUG - 2023-01-13 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:49 --> Total execution time: 0.0513
DEBUG - 2023-01-13 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:32:49 --> Total execution time: 0.0453
DEBUG - 2023-01-13 13:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:33:50 --> Total execution time: 0.0684
DEBUG - 2023-01-13 13:03:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:33:50 --> Total execution time: 0.0473
DEBUG - 2023-01-13 13:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:34:43 --> Total execution time: 0.0450
DEBUG - 2023-01-13 13:04:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:34:43 --> Total execution time: 0.0502
DEBUG - 2023-01-13 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:35:05 --> Total execution time: 0.0602
DEBUG - 2023-01-13 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:35:05 --> Total execution time: 0.0500
DEBUG - 2023-01-13 13:05:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:35:17 --> Total execution time: 0.1598
DEBUG - 2023-01-13 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 17:36:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:13 --> Total execution time: 0.0458
DEBUG - 2023-01-13 13:06:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:14 --> Total execution time: 0.0728
DEBUG - 2023-01-13 13:06:15 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:15 --> Total execution time: 0.0763
DEBUG - 2023-01-13 13:06:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:43 --> Total execution time: 0.0647
DEBUG - 2023-01-13 13:06:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:36:52 --> Total execution time: 0.0490
DEBUG - 2023-01-13 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:41:26 --> Total execution time: 0.0462
DEBUG - 2023-01-13 13:13:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:43:28 --> Total execution time: 0.0486
DEBUG - 2023-01-13 13:13:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:13:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-13 17:43:29 --> Query error: Unknown column 'FR_ID' in 'where clause' - Invalid query: SELECT *
FROM `posts`
WHERE `p_slug` = 'testing-campaign-1'
AND `FR_ID` = '1'
DEBUG - 2023-01-13 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:43:40 --> Total execution time: 0.0489
DEBUG - 2023-01-13 13:13:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:43:40 --> Total execution time: 0.0541
DEBUG - 2023-01-13 13:14:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:44:50 --> Total execution time: 0.0473
DEBUG - 2023-01-13 13:14:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:44:50 --> Total execution time: 0.0492
DEBUG - 2023-01-13 13:15:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:45:16 --> Total execution time: 0.0583
DEBUG - 2023-01-13 13:15:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:15:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:45:16 --> Total execution time: 0.0436
DEBUG - 2023-01-13 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:45:50 --> Total execution time: 0.0575
DEBUG - 2023-01-13 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:45:50 --> Total execution time: 0.0590
DEBUG - 2023-01-13 13:16:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:46:08 --> Total execution time: 0.0797
DEBUG - 2023-01-13 13:16:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:46:09 --> Total execution time: 0.0754
DEBUG - 2023-01-13 13:16:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:46:27 --> Total execution time: 0.0707
DEBUG - 2023-01-13 13:16:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:46:28 --> Total execution time: 0.0618
DEBUG - 2023-01-13 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:48:05 --> Total execution time: 0.0427
DEBUG - 2023-01-13 13:18:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:48:05 --> Total execution time: 0.0500
DEBUG - 2023-01-13 13:18:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:48:37 --> Total execution time: 0.0553
DEBUG - 2023-01-13 13:18:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:48:38 --> Total execution time: 0.0670
DEBUG - 2023-01-13 13:18:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:48:38 --> Total execution time: 0.0477
DEBUG - 2023-01-13 13:19:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:49:28 --> Total execution time: 0.0584
DEBUG - 2023-01-13 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:49:29 --> Total execution time: 0.0553
DEBUG - 2023-01-13 13:19:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:49:29 --> Total execution time: 0.0467
DEBUG - 2023-01-13 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:49:32 --> Total execution time: 0.0429
DEBUG - 2023-01-13 13:20:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:08 --> Total execution time: 0.0454
DEBUG - 2023-01-13 13:20:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:09 --> Total execution time: 0.0526
DEBUG - 2023-01-13 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 17:50:11 --> You did not select a file to upload.
DEBUG - 2023-01-13 17:50:11 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 17:50:11 --> You did not select a file to upload.
DEBUG - 2023-01-13 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:11 --> Total execution time: 0.0451
DEBUG - 2023-01-13 13:20:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:11 --> Total execution time: 0.0466
DEBUG - 2023-01-13 13:20:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:50:28 --> Total execution time: 0.0541
DEBUG - 2023-01-13 13:21:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:51:13 --> Total execution time: 0.0603
DEBUG - 2023-01-13 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:51:14 --> Total execution time: 0.0496
DEBUG - 2023-01-13 13:22:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:52:00 --> Total execution time: 0.0614
DEBUG - 2023-01-13 13:22:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:52:05 --> Total execution time: 0.0908
DEBUG - 2023-01-13 13:24:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:54:02 --> Total execution time: 0.0461
DEBUG - 2023-01-13 13:24:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:54:59 --> Total execution time: 0.0416
DEBUG - 2023-01-13 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:25:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:55:07 --> Total execution time: 0.0459
DEBUG - 2023-01-13 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:55:11 --> Total execution time: 0.0459
DEBUG - 2023-01-13 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:55:11 --> Total execution time: 0.0540
DEBUG - 2023-01-13 13:26:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:56:42 --> Total execution time: 0.0452
DEBUG - 2023-01-13 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:56:59 --> Total execution time: 0.0995
DEBUG - 2023-01-13 13:27:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:57:47 --> Total execution time: 0.0469
DEBUG - 2023-01-13 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:57:50 --> Total execution time: 0.0540
DEBUG - 2023-01-13 13:27:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:57:50 --> Total execution time: 0.0470
DEBUG - 2023-01-13 13:27:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:27:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-13 17:57:56 --> Query error: Unknown column 'don_FK_donate_id' in 'field list' - Invalid query: INSERT INTO `donations` (`don_payment_type`, `don_FK_donate_id`, `don_FK_p_id`, `don_order_id`, `don_txn_id`, `don_amount`, `don_status`, `don_date`, `don_settlement`, `don_note`, `don_name`, `don_phone`, `don_email`, `don_address`) VALUES ('offline', 0, '5', 'CF585108522', '', '12', 'success', '2023-01-13 17:57:56', 'N', '', '', '', '', '')
DEBUG - 2023-01-13 13:28:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:58:51 --> Total execution time: 0.0619
DEBUG - 2023-01-13 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:58:55 --> Total execution time: 0.0396
DEBUG - 2023-01-13 13:28:55 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:58:56 --> Total execution time: 0.0395
DEBUG - 2023-01-13 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:59:00 --> Total execution time: 0.0428
DEBUG - 2023-01-13 13:29:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:59:02 --> Total execution time: 0.0838
DEBUG - 2023-01-13 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 17:59:08 --> Total execution time: 0.0630
DEBUG - 2023-01-13 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:00:31 --> Total execution time: 0.1130
DEBUG - 2023-01-13 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:00:48 --> Total execution time: 0.0445
DEBUG - 2023-01-13 13:30:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:00:50 --> Total execution time: 0.1205
DEBUG - 2023-01-13 13:33:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:03:23 --> Total execution time: 0.0680
DEBUG - 2023-01-13 13:34:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:34:38 --> No URI present. Default controller set.
DEBUG - 2023-01-13 13:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:04:38 --> Total execution time: 0.0491
DEBUG - 2023-01-13 13:34:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:04:46 --> Total execution time: 0.0908
DEBUG - 2023-01-13 13:36:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:06:27 --> Total execution time: 0.0682
DEBUG - 2023-01-13 13:36:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:06:29 --> Total execution time: 0.0499
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:07:35 --> Total execution time: 0.0687
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:36 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:07:46 --> Total execution time: 0.0681
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:37:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:37:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 13:37:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 13:44:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:14:30 --> Total execution time: 0.0679
DEBUG - 2023-01-13 13:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:14:53 --> Total execution time: 0.0593
DEBUG - 2023-01-13 13:45:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:15:06 --> Total execution time: 0.0417
DEBUG - 2023-01-13 13:45:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:15:48 --> Total execution time: 0.0846
DEBUG - 2023-01-13 13:46:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:16:11 --> Total execution time: 0.0865
DEBUG - 2023-01-13 13:47:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:17:23 --> Total execution time: 0.0630
DEBUG - 2023-01-13 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:18:11 --> Total execution time: 0.0533
DEBUG - 2023-01-13 13:48:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:18:23 --> Total execution time: 0.0456
DEBUG - 2023-01-13 13:51:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:21:16 --> Total execution time: 0.0476
DEBUG - 2023-01-13 13:51:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:21:31 --> Total execution time: 0.0722
DEBUG - 2023-01-13 13:51:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:21:37 --> Total execution time: 0.0656
DEBUG - 2023-01-13 13:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:22:02 --> Total execution time: 0.0843
DEBUG - 2023-01-13 13:52:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:22:14 --> Total execution time: 0.0910
DEBUG - 2023-01-13 13:52:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:22:25 --> Total execution time: 0.0516
DEBUG - 2023-01-13 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:22:39 --> Total execution time: 0.0748
DEBUG - 2023-01-13 13:53:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:23:01 --> Total execution time: 0.0534
DEBUG - 2023-01-13 13:53:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:23:08 --> Total execution time: 0.0406
DEBUG - 2023-01-13 13:53:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:23:35 --> Total execution time: 0.0636
DEBUG - 2023-01-13 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:01 --> Total execution time: 0.0808
DEBUG - 2023-01-13 13:54:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:06 --> Total execution time: 0.0737
DEBUG - 2023-01-13 13:54:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:17 --> Total execution time: 0.1084
DEBUG - 2023-01-13 13:54:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:28 --> Total execution time: 0.0960
DEBUG - 2023-01-13 13:54:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:42 --> Total execution time: 0.0719
DEBUG - 2023-01-13 13:54:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:24:54 --> Total execution time: 0.0697
DEBUG - 2023-01-13 13:55:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:25:39 --> Total execution time: 0.0650
DEBUG - 2023-01-13 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:25:48 --> Total execution time: 0.1036
DEBUG - 2023-01-13 13:56:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:26:11 --> Total execution time: 0.0631
DEBUG - 2023-01-13 13:56:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:26:29 --> Total execution time: 0.0456
DEBUG - 2023-01-13 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:26:47 --> Total execution time: 0.0726
DEBUG - 2023-01-13 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:26:56 --> Total execution time: 0.1051
DEBUG - 2023-01-13 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:27:11 --> Total execution time: 0.0796
DEBUG - 2023-01-13 13:57:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:27:23 --> Total execution time: 0.0758
DEBUG - 2023-01-13 13:57:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:27:42 --> Total execution time: 0.0714
DEBUG - 2023-01-13 13:58:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:28:20 --> Total execution time: 0.0736
DEBUG - 2023-01-13 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:28:33 --> Total execution time: 0.0570
DEBUG - 2023-01-13 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 13:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 13:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:28:57 --> Total execution time: 0.0592
DEBUG - 2023-01-13 14:00:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:00:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:30:32 --> Total execution time: 0.0897
DEBUG - 2023-01-13 14:00:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:30:39 --> Total execution time: 0.0524
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:32:21 --> Total execution time: 0.0579
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:02:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:04:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:34:39 --> Total execution time: 0.0766
DEBUG - 2023-01-13 14:04:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:34:46 --> Total execution time: 0.0466
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:35:38 --> Total execution time: 0.0550
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:05:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-13 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:35:51 --> Total execution time: 0.0750
DEBUG - 2023-01-13 14:09:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:39:01 --> Total execution time: 0.0425
DEBUG - 2023-01-13 14:13:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 18:43:25 --> Total execution time: 0.0651
DEBUG - 2023-01-13 14:31:32 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:01:32 --> Total execution time: 0.0686
DEBUG - 2023-01-13 14:31:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 14:31:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:01:57 --> Total execution time: 0.0577
DEBUG - 2023-01-13 14:32:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 14:32:01 --> Total execution time: 0.0512
DEBUG - 2023-01-13 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:02:05 --> Total execution time: 0.0630
DEBUG - 2023-01-13 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:03:47 --> Total execution time: 0.0414
DEBUG - 2023-01-13 14:34:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:04:12 --> Total execution time: 0.0425
DEBUG - 2023-01-13 14:35:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:05:46 --> Total execution time: 0.0527
DEBUG - 2023-01-13 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:06:43 --> Total execution time: 0.0616
DEBUG - 2023-01-13 14:37:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:07:33 --> Total execution time: 0.0631
DEBUG - 2023-01-13 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:10:23 --> Total execution time: 0.0603
DEBUG - 2023-01-13 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:40:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:10:45 --> Total execution time: 0.0661
DEBUG - 2023-01-13 14:40:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:40:48 --> No URI present. Default controller set.
DEBUG - 2023-01-13 14:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:10:48 --> Total execution time: 0.0434
DEBUG - 2023-01-13 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:10:56 --> Total execution time: 0.0431
DEBUG - 2023-01-13 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:10:56 --> Total execution time: 0.0546
DEBUG - 2023-01-13 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:03 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:03 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:03 --> You did not select a file to upload.
DEBUG - 2023-01-13 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:03 --> Total execution time: 0.0435
DEBUG - 2023-01-13 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:03 --> Total execution time: 0.0577
DEBUG - 2023-01-13 14:41:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:05 --> No URI present. Default controller set.
DEBUG - 2023-01-13 14:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:05 --> Total execution time: 0.0440
DEBUG - 2023-01-13 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:19 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:19 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:19 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:19 --> You did not select a file to upload.
DEBUG - 2023-01-13 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:19 --> Total execution time: 0.0662
DEBUG - 2023-01-13 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:19 --> Total execution time: 0.0474
DEBUG - 2023-01-13 14:41:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:20 --> No URI present. Default controller set.
DEBUG - 2023-01-13 14:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:20 --> Total execution time: 0.0651
DEBUG - 2023-01-13 14:41:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:28 --> Total execution time: 0.0703
DEBUG - 2023-01-13 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:45 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:45 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:45 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:45 --> You did not select a file to upload.
DEBUG - 2023-01-13 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:45 --> Total execution time: 0.0647
DEBUG - 2023-01-13 14:41:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:45 --> Total execution time: 0.0465
DEBUG - 2023-01-13 14:41:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:46 --> Total execution time: 0.0644
DEBUG - 2023-01-13 14:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:52 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:52 --> You did not select a file to upload.
DEBUG - 2023-01-13 19:11:52 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2023-01-13 19:11:52 --> You did not select a file to upload.
DEBUG - 2023-01-13 14:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:52 --> Total execution time: 0.0452
DEBUG - 2023-01-13 14:41:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:52 --> Total execution time: 0.0523
DEBUG - 2023-01-13 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:11:53 --> Total execution time: 0.0742
DEBUG - 2023-01-13 14:49:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:49:13 --> No URI present. Default controller set.
DEBUG - 2023-01-13 14:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:19:13 --> Total execution time: 0.0460
DEBUG - 2023-01-13 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:19:16 --> Total execution time: 0.0468
DEBUG - 2023-01-13 14:49:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:19:17 --> Total execution time: 0.0484
DEBUG - 2023-01-13 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:29 --> Total execution time: 0.0434
DEBUG - 2023-01-13 14:50:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:30 --> Total execution time: 0.0493
DEBUG - 2023-01-13 14:50:43 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:43 --> Total execution time: 0.0470
DEBUG - 2023-01-13 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:44 --> Total execution time: 0.0450
DEBUG - 2023-01-13 14:50:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:45 --> Total execution time: 0.0563
DEBUG - 2023-01-13 14:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:52 --> Total execution time: 0.0442
DEBUG - 2023-01-13 14:50:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:20:52 --> Total execution time: 0.0453
DEBUG - 2023-01-13 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:21:17 --> Total execution time: 0.0445
DEBUG - 2023-01-13 14:51:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:21:17 --> Total execution time: 0.0594
DEBUG - 2023-01-13 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:21:24 --> Total execution time: 0.0430
DEBUG - 2023-01-13 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:21:25 --> Total execution time: 0.0521
DEBUG - 2023-01-13 14:54:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:24:57 --> Total execution time: 0.0647
DEBUG - 2023-01-13 14:55:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:25:50 --> Total execution time: 0.0464
DEBUG - 2023-01-13 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:56:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:56:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:56:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:56:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:56:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:56:28 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-13 14:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-13 19:28:21 --> Total execution time: 0.0559
DEBUG - 2023-01-13 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:58:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-13 14:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:58:21 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-13 14:58:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-13 14:58:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-13 14:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-13 14:58:21 --> 404 Page Not Found: Assets/website
