<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-07 00:00:12 --> Total execution time: 0.0576
DEBUG - 2022-05-07 00:00:45 --> Total execution time: 0.0518
DEBUG - 2022-05-07 00:01:14 --> Total execution time: 0.0712
DEBUG - 2022-05-07 00:01:40 --> Total execution time: 0.0297
DEBUG - 2022-05-07 00:02:10 --> Total execution time: 0.0525
DEBUG - 2022-05-07 00:02:43 --> Total execution time: 0.0513
DEBUG - 2022-05-07 00:03:12 --> Total execution time: 0.0300
DEBUG - 2022-05-07 00:06:19 --> Total execution time: 0.0543
DEBUG - 2022-05-07 00:06:57 --> Total execution time: 0.0298
DEBUG - 2022-05-07 00:07:21 --> Total execution time: 0.0305
DEBUG - 2022-05-07 00:07:49 --> Total execution time: 0.0558
DEBUG - 2022-05-07 00:08:16 --> Total execution time: 0.0311
DEBUG - 2022-05-07 00:08:50 --> Total execution time: 0.0293
DEBUG - 2022-05-07 00:09:22 --> Total execution time: 0.0304
DEBUG - 2022-05-07 00:09:57 --> Total execution time: 0.0307
DEBUG - 2022-05-07 00:10:34 --> Total execution time: 0.0306
DEBUG - 2022-05-07 00:11:09 --> Total execution time: 0.0310
DEBUG - 2022-05-07 00:11:46 --> Total execution time: 0.0320
DEBUG - 2022-05-07 00:12:18 --> Total execution time: 0.0320
DEBUG - 2022-05-07 00:12:52 --> Total execution time: 0.0294
DEBUG - 2022-05-07 00:13:20 --> Total execution time: 0.0322
DEBUG - 2022-05-07 00:13:57 --> Total execution time: 0.0315
DEBUG - 2022-05-07 00:14:23 --> Total execution time: 0.0306
DEBUG - 2022-05-07 00:14:48 --> Total execution time: 0.0331
DEBUG - 2022-05-07 00:15:16 --> Total execution time: 0.0319
DEBUG - 2022-05-07 00:15:45 --> Total execution time: 0.0322
DEBUG - 2022-05-07 00:16:21 --> Total execution time: 0.0307
DEBUG - 2022-05-07 00:16:50 --> Total execution time: 0.0328
DEBUG - 2022-05-07 00:17:29 --> Total execution time: 0.0317
DEBUG - 2022-05-07 00:18:00 --> Total execution time: 0.0314
DEBUG - 2022-05-07 00:18:56 --> Total execution time: 0.0300
DEBUG - 2022-05-07 00:19:23 --> Total execution time: 0.0310
DEBUG - 2022-05-07 00:19:52 --> Total execution time: 0.0318
DEBUG - 2022-05-07 00:20:25 --> Total execution time: 0.0300
DEBUG - 2022-05-07 00:20:54 --> Total execution time: 0.0484
DEBUG - 2022-05-07 00:21:38 --> Total execution time: 0.0310
DEBUG - 2022-05-07 00:22:06 --> Total execution time: 0.0293
DEBUG - 2022-05-07 00:22:37 --> Total execution time: 0.0312
DEBUG - 2022-05-07 00:23:07 --> Total execution time: 0.0311
DEBUG - 2022-05-07 00:23:53 --> Total execution time: 0.0319
DEBUG - 2022-05-07 00:24:44 --> Total execution time: 0.0302
DEBUG - 2022-05-07 00:27:43 --> Total execution time: 0.0540
DEBUG - 2022-05-07 00:28:10 --> Total execution time: 0.0309
DEBUG - 2022-05-07 00:28:40 --> Total execution time: 0.0291
DEBUG - 2022-05-07 00:29:17 --> Total execution time: 0.0427
DEBUG - 2022-05-07 00:29:42 --> Total execution time: 0.0285
DEBUG - 2022-05-07 00:30:17 --> Total execution time: 0.0537
DEBUG - 2022-05-07 00:30:58 --> Total execution time: 0.0861
DEBUG - 2022-05-07 00:31:36 --> Total execution time: 0.0530
DEBUG - 2022-05-07 00:32:06 --> Total execution time: 0.0556
DEBUG - 2022-05-07 00:33:03 --> Total execution time: 0.0594
DEBUG - 2022-05-07 00:33:33 --> Total execution time: 0.0303
DEBUG - 2022-05-07 00:34:05 --> Total execution time: 0.0525
DEBUG - 2022-05-07 00:35:11 --> Total execution time: 0.1131
DEBUG - 2022-05-07 06:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:56:08 --> Total execution time: 1.2810
DEBUG - 2022-05-07 06:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:56:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:26:19 --> Total execution time: 0.2028
DEBUG - 2022-05-07 06:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:26:33 --> Total execution time: 2.5468
DEBUG - 2022-05-07 06:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:26:33 --> Total execution time: 6.8436
DEBUG - 2022-05-07 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:27:14 --> Total execution time: 0.0299
DEBUG - 2022-05-07 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:27:41 --> Total execution time: 0.0306
DEBUG - 2022-05-07 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:28:08 --> Total execution time: 0.0311
DEBUG - 2022-05-07 06:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:28:58 --> Total execution time: 0.0299
DEBUG - 2022-05-07 06:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:29:23 --> Total execution time: 0.0290
DEBUG - 2022-05-07 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 06:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 06:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 06:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:29:56 --> Total execution time: 0.0293
DEBUG - 2022-05-07 07:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:30:21 --> Total execution time: 0.0298
DEBUG - 2022-05-07 07:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:31:56 --> Total execution time: 0.0297
DEBUG - 2022-05-07 07:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:02:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:32:33 --> Total execution time: 0.0550
DEBUG - 2022-05-07 07:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:32:56 --> Total execution time: 0.0305
DEBUG - 2022-05-07 07:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:33:39 --> Total execution time: 0.0312
DEBUG - 2022-05-07 07:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:34:09 --> Total execution time: 0.0433
DEBUG - 2022-05-07 07:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:34:50 --> Total execution time: 0.0305
DEBUG - 2022-05-07 07:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:36:48 --> Total execution time: 0.0517
DEBUG - 2022-05-07 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:37:19 --> Total execution time: 0.0305
DEBUG - 2022-05-07 07:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:37:50 --> Total execution time: 0.0286
DEBUG - 2022-05-07 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:38:11 --> Total execution time: 0.0299
DEBUG - 2022-05-07 07:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:38:36 --> Total execution time: 0.0321
DEBUG - 2022-05-07 07:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:38:58 --> Total execution time: 0.0289
DEBUG - 2022-05-07 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:39:21 --> Total execution time: 0.0308
DEBUG - 2022-05-07 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:39:42 --> Total execution time: 0.0309
DEBUG - 2022-05-07 07:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:40:03 --> Total execution time: 0.0291
DEBUG - 2022-05-07 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:40:28 --> Total execution time: 0.0293
DEBUG - 2022-05-07 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:40:49 --> Total execution time: 0.0307
DEBUG - 2022-05-07 07:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:41:16 --> Total execution time: 0.0309
DEBUG - 2022-05-07 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:41:45 --> Total execution time: 0.0298
DEBUG - 2022-05-07 07:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:12:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:42:09 --> Total execution time: 0.0290
DEBUG - 2022-05-07 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:42:43 --> Total execution time: 0.0294
DEBUG - 2022-05-07 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:43:09 --> Total execution time: 0.0308
DEBUG - 2022-05-07 07:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:55:25 --> Total execution time: 0.1421
DEBUG - 2022-05-07 07:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:56:06 --> Total execution time: 0.0328
DEBUG - 2022-05-07 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:56:39 --> Total execution time: 0.0293
DEBUG - 2022-05-07 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:57:06 --> Total execution time: 0.0301
DEBUG - 2022-05-07 07:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:57:34 --> Total execution time: 0.0301
DEBUG - 2022-05-07 07:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:58:00 --> Total execution time: 0.0283
DEBUG - 2022-05-07 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:58:26 --> Total execution time: 0.0334
DEBUG - 2022-05-07 07:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:58:58 --> Total execution time: 0.0294
DEBUG - 2022-05-07 07:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:59:22 --> Total execution time: 0.0304
DEBUG - 2022-05-07 07:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:29:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:59:51 --> Total execution time: 0.0301
DEBUG - 2022-05-07 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:00:17 --> Total execution time: 0.0318
DEBUG - 2022-05-07 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:00:50 --> Total execution time: 0.0307
DEBUG - 2022-05-07 07:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:01:21 --> Total execution time: 0.0302
DEBUG - 2022-05-07 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:31:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:01:44 --> Total execution time: 0.0290
DEBUG - 2022-05-07 07:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:02:21 --> Total execution time: 0.5633
DEBUG - 2022-05-07 07:32:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:32:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:02:46 --> Total execution time: 0.0297
DEBUG - 2022-05-07 07:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:03:11 --> Total execution time: 3.3016
DEBUG - 2022-05-07 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:03:45 --> Total execution time: 0.0295
DEBUG - 2022-05-07 07:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:04:12 --> Total execution time: 0.0326
DEBUG - 2022-05-07 07:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:36:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:06:55 --> Total execution time: 0.0517
DEBUG - 2022-05-07 07:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:07:13 --> Total execution time: 0.0293
DEBUG - 2022-05-07 07:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:07:40 --> Total execution time: 0.0309
DEBUG - 2022-05-07 07:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:08:08 --> Total execution time: 0.0537
DEBUG - 2022-05-07 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:08:31 --> Total execution time: 0.0298
DEBUG - 2022-05-07 07:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:08:53 --> Total execution time: 0.0305
DEBUG - 2022-05-07 07:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:09:16 --> Total execution time: 0.0558
DEBUG - 2022-05-07 07:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:09:45 --> Total execution time: 0.0560
DEBUG - 2022-05-07 07:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:10:05 --> Total execution time: 0.0545
DEBUG - 2022-05-07 07:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:10:56 --> Total execution time: 0.0526
DEBUG - 2022-05-07 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:11:15 --> Total execution time: 0.0340
DEBUG - 2022-05-07 07:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:11:40 --> Total execution time: 0.1385
DEBUG - 2022-05-07 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:02 --> Total execution time: 0.0954
DEBUG - 2022-05-07 07:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:28 --> Total execution time: 0.0719
DEBUG - 2022-05-07 07:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:56 --> Total execution time: 0.1553
DEBUG - 2022-05-07 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:13:20 --> Total execution time: 0.7447
DEBUG - 2022-05-07 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:13:39 --> Total execution time: 0.0577
DEBUG - 2022-05-07 07:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:54:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:24:22 --> Total execution time: 0.0777
DEBUG - 2022-05-07 07:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:24:48 --> Total execution time: 0.0516
DEBUG - 2022-05-07 07:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:25:10 --> Total execution time: 0.0593
DEBUG - 2022-05-07 07:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:25:41 --> Total execution time: 0.0559
DEBUG - 2022-05-07 07:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:01 --> Total execution time: 0.0312
DEBUG - 2022-05-07 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:22 --> Total execution time: 0.0525
DEBUG - 2022-05-07 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:44 --> Total execution time: 0.0611
DEBUG - 2022-05-07 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:08 --> Total execution time: 0.0581
DEBUG - 2022-05-07 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:29 --> Total execution time: 0.0541
DEBUG - 2022-05-07 07:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:54 --> Total execution time: 0.0749
DEBUG - 2022-05-07 07:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:28:45 --> Total execution time: 0.0577
DEBUG - 2022-05-07 07:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:29:12 --> Total execution time: 0.0346
DEBUG - 2022-05-07 07:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 07:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 07:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 07:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:29:37 --> Total execution time: 0.0312
DEBUG - 2022-05-07 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:12 --> Total execution time: 0.0549
DEBUG - 2022-05-07 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:35 --> Total execution time: 0.0310
DEBUG - 2022-05-07 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:59 --> Total execution time: 0.0544
DEBUG - 2022-05-07 08:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:23 --> Total execution time: 0.0294
DEBUG - 2022-05-07 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:46 --> Total execution time: 0.1159
DEBUG - 2022-05-07 08:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:38:27 --> Total execution time: 0.0718
DEBUG - 2022-05-07 08:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:39:37 --> Total execution time: 0.0659
DEBUG - 2022-05-07 08:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:40:10 --> Total execution time: 0.2493
DEBUG - 2022-05-07 08:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:40:34 --> Total execution time: 0.0305
DEBUG - 2022-05-07 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:41:00 --> Total execution time: 0.0293
DEBUG - 2022-05-07 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:41:22 --> Total execution time: 0.0299
DEBUG - 2022-05-07 08:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:41:43 --> Total execution time: 0.0528
DEBUG - 2022-05-07 08:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:12:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:42:20 --> Total execution time: 0.0520
DEBUG - 2022-05-07 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:42:56 --> Total execution time: 0.0750
DEBUG - 2022-05-07 08:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:43:22 --> Total execution time: 0.0682
DEBUG - 2022-05-07 08:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:43:52 --> Total execution time: 0.0560
DEBUG - 2022-05-07 08:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:44:33 --> Total execution time: 0.0565
DEBUG - 2022-05-07 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:45:01 --> Total execution time: 0.0524
DEBUG - 2022-05-07 08:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:45:41 --> Total execution time: 0.0551
DEBUG - 2022-05-07 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:05 --> Total execution time: 0.0295
DEBUG - 2022-05-07 08:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:36 --> Total execution time: 0.0313
DEBUG - 2022-05-07 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:54 --> Total execution time: 0.0288
DEBUG - 2022-05-07 08:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:47:21 --> Total execution time: 0.0539
DEBUG - 2022-05-07 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:47:55 --> Total execution time: 0.0294
DEBUG - 2022-05-07 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:49:28 --> Total execution time: 0.0518
DEBUG - 2022-05-07 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:49:48 --> Total execution time: 0.0366
DEBUG - 2022-05-07 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:50:10 --> Total execution time: 0.0315
DEBUG - 2022-05-07 08:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:50:31 --> Total execution time: 0.0544
DEBUG - 2022-05-07 08:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:50:48 --> Total execution time: 0.0315
DEBUG - 2022-05-07 08:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:51:12 --> Total execution time: 0.0288
DEBUG - 2022-05-07 08:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:52:08 --> Total execution time: 0.0544
DEBUG - 2022-05-07 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:52:21 --> Total execution time: 0.0297
DEBUG - 2022-05-07 08:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:52:48 --> Total execution time: 0.0356
DEBUG - 2022-05-07 08:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:16:31 --> Total execution time: 0.0806
DEBUG - 2022-05-07 08:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:16:51 --> Total execution time: 0.0302
DEBUG - 2022-05-07 08:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:17:15 --> Total execution time: 0.0291
DEBUG - 2022-05-07 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:17:37 --> Total execution time: 0.0315
DEBUG - 2022-05-07 08:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:18:01 --> Total execution time: 0.0317
DEBUG - 2022-05-07 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:18:24 --> Total execution time: 0.0304
DEBUG - 2022-05-07 08:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:18:51 --> Total execution time: 0.0302
DEBUG - 2022-05-07 08:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:49:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 08:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:19:14 --> Total execution time: 0.0293
DEBUG - 2022-05-07 11:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:16 --> Total execution time: 0.0735
DEBUG - 2022-05-07 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:23 --> Total execution time: 0.0920
DEBUG - 2022-05-07 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:27 --> Total execution time: 0.0538
DEBUG - 2022-05-07 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:30 --> Total execution time: 0.0382
DEBUG - 2022-05-07 11:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 11:28:45 --> Total execution time: 0.0523
DEBUG - 2022-05-07 11:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 11:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:46 --> Total execution time: 0.0297
DEBUG - 2022-05-07 11:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:28:59 --> No URI present. Default controller set.
DEBUG - 2022-05-07 11:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:58:59 --> Total execution time: 0.0692
DEBUG - 2022-05-07 11:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:59:03 --> Total execution time: 0.0385
DEBUG - 2022-05-07 11:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 11:29:20 --> No URI present. Default controller set.
DEBUG - 2022-05-07 11:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 11:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 16:59:20 --> Total execution time: 0.0327
DEBUG - 2022-05-07 12:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:56:48 --> No URI present. Default controller set.
DEBUG - 2022-05-07 12:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:26:48 --> Total execution time: 0.8624
DEBUG - 2022-05-07 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:56:54 --> Total execution time: 0.0360
DEBUG - 2022-05-07 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:56:54 --> Total execution time: 0.0286
DEBUG - 2022-05-07 12:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 12:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:27:07 --> Total execution time: 0.1080
DEBUG - 2022-05-07 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:27:13 --> Total execution time: 0.0776
DEBUG - 2022-05-07 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 12:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 12:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:27:22 --> Total execution time: 2.3757
DEBUG - 2022-05-07 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:38:24 --> Total execution time: 1.0048
DEBUG - 2022-05-07 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:38:39 --> Total execution time: 0.0308
DEBUG - 2022-05-07 13:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:39:01 --> Total execution time: 0.0327
DEBUG - 2022-05-07 13:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:39:25 --> Total execution time: 0.0551
DEBUG - 2022-05-07 13:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:39:49 --> Total execution time: 0.0304
DEBUG - 2022-05-07 13:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:40:18 --> Total execution time: 0.0532
DEBUG - 2022-05-07 13:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:10:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:40:41 --> Total execution time: 0.0533
DEBUG - 2022-05-07 13:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:41:06 --> Total execution time: 0.0383
DEBUG - 2022-05-07 13:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:41:30 --> Total execution time: 0.0556
DEBUG - 2022-05-07 13:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:42:01 --> Total execution time: 0.0589
DEBUG - 2022-05-07 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:42:26 --> Total execution time: 0.0606
DEBUG - 2022-05-07 13:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:42:52 --> Total execution time: 0.8316
DEBUG - 2022-05-07 13:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:43:17 --> Total execution time: 0.0582
DEBUG - 2022-05-07 13:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:43:41 --> Total execution time: 0.0600
DEBUG - 2022-05-07 13:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:44:11 --> Total execution time: 0.0525
DEBUG - 2022-05-07 13:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:44:40 --> Total execution time: 0.0346
DEBUG - 2022-05-07 13:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:45:22 --> Total execution time: 0.0324
DEBUG - 2022-05-07 13:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:15:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:45:56 --> Total execution time: 0.0527
DEBUG - 2022-05-07 13:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:46:15 --> Total execution time: 0.0308
DEBUG - 2022-05-07 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:16:29 --> No URI present. Default controller set.
DEBUG - 2022-05-07 13:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:46:29 --> Total execution time: 0.2867
DEBUG - 2022-05-07 13:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:17:48 --> Total execution time: 0.0485
DEBUG - 2022-05-07 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:48:04 --> Total execution time: 0.0334
DEBUG - 2022-05-07 13:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:49:16 --> Total execution time: 0.0586
DEBUG - 2022-05-07 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:50:24 --> Total execution time: 0.8626
DEBUG - 2022-05-07 13:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:50:40 --> Total execution time: 0.0318
DEBUG - 2022-05-07 13:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:51:47 --> Total execution time: 0.8466
DEBUG - 2022-05-07 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:52:18 --> Total execution time: 1.2236
DEBUG - 2022-05-07 18:52:30 --> Total execution time: 3.7268
DEBUG - 2022-05-07 13:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:54:47 --> Total execution time: 0.0525
DEBUG - 2022-05-07 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:55:12 --> Total execution time: 0.0439
DEBUG - 2022-05-07 13:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:56:06 --> Total execution time: 0.0312
DEBUG - 2022-05-07 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:56:30 --> Total execution time: 0.0303
DEBUG - 2022-05-07 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:56:52 --> Total execution time: 0.0298
DEBUG - 2022-05-07 13:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:07 --> Total execution time: 0.0366
DEBUG - 2022-05-07 13:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:13 --> Total execution time: 0.0307
DEBUG - 2022-05-07 13:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:17 --> Total execution time: 0.0980
DEBUG - 2022-05-07 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:34 --> Total execution time: 0.0309
DEBUG - 2022-05-07 13:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:49 --> Total execution time: 0.0298
DEBUG - 2022-05-07 13:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:57:56 --> Total execution time: 0.0292
DEBUG - 2022-05-07 13:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:28:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:58:17 --> Total execution time: 0.0298
DEBUG - 2022-05-07 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:58:59 --> Total execution time: 0.0300
DEBUG - 2022-05-07 13:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:59:02 --> Total execution time: 0.0341
DEBUG - 2022-05-07 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:59:24 --> Total execution time: 0.0304
DEBUG - 2022-05-07 13:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:29:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 18:59:45 --> Total execution time: 0.0317
DEBUG - 2022-05-07 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:00:04 --> Total execution time: 0.0337
DEBUG - 2022-05-07 13:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:00:06 --> Total execution time: 0.0308
DEBUG - 2022-05-07 13:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:00:27 --> Total execution time: 0.0304
DEBUG - 2022-05-07 13:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:00:39 --> Total execution time: 0.5201
DEBUG - 2022-05-07 13:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:00:49 --> Total execution time: 0.0309
DEBUG - 2022-05-07 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:01:06 --> Total execution time: 0.0319
DEBUG - 2022-05-07 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:01:13 --> Total execution time: 0.0297
DEBUG - 2022-05-07 13:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:01:36 --> Total execution time: 0.0569
DEBUG - 2022-05-07 13:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:01:39 --> Total execution time: 0.0300
DEBUG - 2022-05-07 13:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:02:17 --> Total execution time: 0.0308
DEBUG - 2022-05-07 13:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:03:52 --> Total execution time: 0.0542
DEBUG - 2022-05-07 13:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:08:59 --> Total execution time: 0.1243
DEBUG - 2022-05-07 13:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:09:20 --> Total execution time: 0.0363
DEBUG - 2022-05-07 13:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:10:19 --> Total execution time: 0.0662
DEBUG - 2022-05-07 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:10:51 --> Total execution time: 0.0321
DEBUG - 2022-05-07 13:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:41:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:11:23 --> Total execution time: 0.0527
DEBUG - 2022-05-07 13:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:11:43 --> Total execution time: 0.1101
DEBUG - 2022-05-07 13:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:12:01 --> Total execution time: 0.0766
DEBUG - 2022-05-07 13:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:12:21 --> Total execution time: 0.0525
DEBUG - 2022-05-07 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:12:39 --> Total execution time: 0.0524
DEBUG - 2022-05-07 13:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:13:13 --> Total execution time: 0.0543
DEBUG - 2022-05-07 13:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:13:32 --> Total execution time: 0.0305
DEBUG - 2022-05-07 13:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:14:28 --> Total execution time: 0.1581
DEBUG - 2022-05-07 13:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:14:53 --> Total execution time: 0.0322
DEBUG - 2022-05-07 13:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:45:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:15:20 --> Total execution time: 0.0800
DEBUG - 2022-05-07 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:15:37 --> Total execution time: 0.0310
DEBUG - 2022-05-07 13:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:16:06 --> Total execution time: 0.0547
DEBUG - 2022-05-07 13:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:16:25 --> Total execution time: 0.0617
DEBUG - 2022-05-07 13:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:16:47 --> Total execution time: 0.0569
DEBUG - 2022-05-07 13:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:19:33 --> Total execution time: 0.0545
DEBUG - 2022-05-07 13:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:49:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:19:55 --> Total execution time: 0.0297
DEBUG - 2022-05-07 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:20:19 --> Total execution time: 0.0287
DEBUG - 2022-05-07 13:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:20:44 --> Total execution time: 0.0295
DEBUG - 2022-05-07 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:21:03 --> Total execution time: 0.0330
DEBUG - 2022-05-07 13:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:23:49 --> Total execution time: 0.0299
DEBUG - 2022-05-07 13:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:24:10 --> Total execution time: 0.0310
DEBUG - 2022-05-07 13:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:24:29 --> Total execution time: 0.0420
DEBUG - 2022-05-07 13:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:24:47 --> Total execution time: 0.0288
DEBUG - 2022-05-07 13:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:25:13 --> Total execution time: 0.0285
DEBUG - 2022-05-07 13:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:25:33 --> Total execution time: 0.0297
DEBUG - 2022-05-07 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:26:00 --> Total execution time: 0.0285
DEBUG - 2022-05-07 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:27:07 --> Total execution time: 0.0526
DEBUG - 2022-05-07 13:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:27:25 --> Total execution time: 0.0403
DEBUG - 2022-05-07 13:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:27:46 --> Total execution time: 0.0292
DEBUG - 2022-05-07 13:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:28:14 --> Total execution time: 0.0291
DEBUG - 2022-05-07 13:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:28:45 --> Total execution time: 0.0309
DEBUG - 2022-05-07 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:29:04 --> Total execution time: 0.0287
DEBUG - 2022-05-07 13:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 13:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 13:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 13:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:29:32 --> Total execution time: 0.0299
DEBUG - 2022-05-07 14:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:40:12 --> Total execution time: 0.0570
DEBUG - 2022-05-07 14:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:40:32 --> Total execution time: 0.0301
DEBUG - 2022-05-07 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:41:00 --> Total execution time: 0.0310
DEBUG - 2022-05-07 14:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:41:21 --> Total execution time: 0.0306
DEBUG - 2022-05-07 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:41:39 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:41:56 --> Total execution time: 0.0290
DEBUG - 2022-05-07 14:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:42:27 --> Total execution time: 0.0316
DEBUG - 2022-05-07 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:42:57 --> Total execution time: 0.0299
DEBUG - 2022-05-07 14:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:43:22 --> Total execution time: 0.0291
DEBUG - 2022-05-07 14:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:13:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:43:42 --> Total execution time: 0.0309
DEBUG - 2022-05-07 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:44:07 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:44:27 --> Total execution time: 0.0311
DEBUG - 2022-05-07 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:15:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:15:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:45:01 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:45:34 --> Total execution time: 0.0289
DEBUG - 2022-05-07 14:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:46:04 --> Total execution time: 0.0305
DEBUG - 2022-05-07 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:46:22 --> Total execution time: 0.0300
DEBUG - 2022-05-07 14:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:16:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:46:49 --> Total execution time: 0.0296
DEBUG - 2022-05-07 14:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:47:08 --> Total execution time: 0.0329
DEBUG - 2022-05-07 14:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:47:26 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:56:50 --> Total execution time: 0.1179
DEBUG - 2022-05-07 14:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:57:23 --> Total execution time: 0.0324
DEBUG - 2022-05-07 14:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:58:04 --> Total execution time: 0.0295
DEBUG - 2022-05-07 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 19:58:38 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:04:23 --> Total execution time: 0.8156
DEBUG - 2022-05-07 14:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:07:24 --> Total execution time: 0.0315
DEBUG - 2022-05-07 14:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:37:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-05-07 20:07:46 --> Query error: Unknown column 'ul_gud' in 'where clause' - Invalid query: SELECT *
FROM `user_joins`
WHERE `ul_gud` = 'Vishnusinghdigital'
DEBUG - 2022-05-07 14:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:08:15 --> Total execution time: 0.0315
DEBUG - 2022-05-07 14:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:08:37 --> Total execution time: 0.0287
DEBUG - 2022-05-07 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:08:50 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:09:02 --> Total execution time: 0.0291
DEBUG - 2022-05-07 14:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:09:20 --> Total execution time: 0.0450
DEBUG - 2022-05-07 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:09:31 --> Total execution time: 0.0302
DEBUG - 2022-05-07 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:09:58 --> Total execution time: 0.0294
DEBUG - 2022-05-07 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:10:10 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:10:24 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:10:34 --> Total execution time: 0.0318
DEBUG - 2022-05-07 14:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:10:44 --> Total execution time: 0.0304
DEBUG - 2022-05-07 14:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:10:54 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:11:04 --> Total execution time: 0.0316
DEBUG - 2022-05-07 14:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:11:21 --> Total execution time: 0.0293
DEBUG - 2022-05-07 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:11:31 --> Total execution time: 0.0319
DEBUG - 2022-05-07 14:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:11:42 --> Total execution time: 0.0296
DEBUG - 2022-05-07 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:11:59 --> Total execution time: 0.0301
DEBUG - 2022-05-07 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:12:26 --> Total execution time: 0.0289
DEBUG - 2022-05-07 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:14:16 --> Total execution time: 0.0290
DEBUG - 2022-05-07 14:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:14:27 --> Total execution time: 0.0293
DEBUG - 2022-05-07 14:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:14:37 --> Total execution time: 0.0294
DEBUG - 2022-05-07 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:14:47 --> Total execution time: 0.0301
DEBUG - 2022-05-07 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:14:58 --> Total execution time: 0.0317
DEBUG - 2022-05-07 14:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:15:11 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:15:24 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:15:37 --> Total execution time: 0.0294
DEBUG - 2022-05-07 14:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:15:52 --> Total execution time: 0.0293
DEBUG - 2022-05-07 14:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:16:03 --> Total execution time: 0.0294
DEBUG - 2022-05-07 14:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:16:14 --> Total execution time: 0.0297
DEBUG - 2022-05-07 14:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:16:25 --> Total execution time: 0.0295
DEBUG - 2022-05-07 14:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:16:38 --> Total execution time: 0.0303
DEBUG - 2022-05-07 14:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:16:51 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:17:17 --> Total execution time: 0.0279
DEBUG - 2022-05-07 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:17:29 --> Total execution time: 0.0298
DEBUG - 2022-05-07 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:17:46 --> Total execution time: 0.0313
DEBUG - 2022-05-07 14:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:17:58 --> Total execution time: 0.0304
DEBUG - 2022-05-07 14:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:18:09 --> Total execution time: 0.0302
DEBUG - 2022-05-07 14:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:18:23 --> Total execution time: 0.0297
DEBUG - 2022-05-07 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:19:33 --> Total execution time: 0.0298
DEBUG - 2022-05-07 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:19:44 --> Total execution time: 0.0311
DEBUG - 2022-05-07 14:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:19:58 --> Total execution time: 0.0297
DEBUG - 2022-05-07 14:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:20:13 --> Total execution time: 0.0300
DEBUG - 2022-05-07 14:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:20:26 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:20:43 --> Total execution time: 0.0299
DEBUG - 2022-05-07 14:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:20:56 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:21:13 --> Total execution time: 0.0295
DEBUG - 2022-05-07 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:21:24 --> Total execution time: 0.0296
DEBUG - 2022-05-07 14:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:21:35 --> Total execution time: 0.0312
DEBUG - 2022-05-07 14:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:21:47 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:22:01 --> Total execution time: 0.0301
DEBUG - 2022-05-07 14:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:22:25 --> Total execution time: 0.0317
DEBUG - 2022-05-07 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:22:35 --> Total execution time: 0.0315
DEBUG - 2022-05-07 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:22:46 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:22:58 --> Total execution time: 0.0310
DEBUG - 2022-05-07 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:23:10 --> Total execution time: 0.0299
DEBUG - 2022-05-07 14:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:23:20 --> Total execution time: 0.5154
DEBUG - 2022-05-07 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:53:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:23:31 --> Total execution time: 0.0294
DEBUG - 2022-05-07 14:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:26:22 --> Total execution time: 0.0295
DEBUG - 2022-05-07 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:26:30 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:26:42 --> Total execution time: 0.0324
DEBUG - 2022-05-07 14:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:26:55 --> Total execution time: 0.0296
DEBUG - 2022-05-07 14:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:27:05 --> Total execution time: 0.0299
DEBUG - 2022-05-07 14:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:27:16 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:27:30 --> Total execution time: 0.0298
DEBUG - 2022-05-07 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:27:40 --> Total execution time: 0.0310
DEBUG - 2022-05-07 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:27:51 --> Total execution time: 0.0297
DEBUG - 2022-05-07 14:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:02 --> Total execution time: 0.0310
DEBUG - 2022-05-07 14:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:11 --> Total execution time: 0.0296
DEBUG - 2022-05-07 14:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:23 --> Total execution time: 0.0290
DEBUG - 2022-05-07 14:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:33 --> Total execution time: 0.0302
DEBUG - 2022-05-07 14:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:45 --> Total execution time: 0.0300
DEBUG - 2022-05-07 14:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:28:56 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:29:07 --> Total execution time: 0.0292
DEBUG - 2022-05-07 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:29:24 --> Total execution time: 0.0317
DEBUG - 2022-05-07 14:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:29:31 --> Total execution time: 0.0288
DEBUG - 2022-05-07 14:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 14:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 14:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 14:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:29:42 --> Total execution time: 0.0293
DEBUG - 2022-05-07 15:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:34:48 --> Total execution time: 0.0541
DEBUG - 2022-05-07 15:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:34:57 --> Total execution time: 0.0309
DEBUG - 2022-05-07 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:35:07 --> Total execution time: 0.0305
DEBUG - 2022-05-07 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:35:23 --> Total execution time: 0.0316
DEBUG - 2022-05-07 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:35:33 --> Total execution time: 0.0326
DEBUG - 2022-05-07 15:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:35:53 --> Total execution time: 0.0321
DEBUG - 2022-05-07 15:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:36:03 --> Total execution time: 0.0286
DEBUG - 2022-05-07 15:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:36:17 --> Total execution time: 0.0295
DEBUG - 2022-05-07 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:36:31 --> Total execution time: 0.0292
DEBUG - 2022-05-07 15:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:36:46 --> Total execution time: 0.0356
DEBUG - 2022-05-07 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:36:57 --> Total execution time: 0.0323
DEBUG - 2022-05-07 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:05 --> Total execution time: 0.0321
DEBUG - 2022-05-07 15:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:15 --> Total execution time: 0.0293
DEBUG - 2022-05-07 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:25 --> Total execution time: 0.0322
DEBUG - 2022-05-07 15:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:35 --> Total execution time: 0.0317
DEBUG - 2022-05-07 15:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:46 --> Total execution time: 0.0567
DEBUG - 2022-05-07 15:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:37:57 --> Total execution time: 0.0295
DEBUG - 2022-05-07 15:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:38:08 --> Total execution time: 0.0295
DEBUG - 2022-05-07 15:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 15:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 15:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 15:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-05-07 20:38:19 --> Total execution time: 0.0328
