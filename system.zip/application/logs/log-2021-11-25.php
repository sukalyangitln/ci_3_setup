<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-25 12:26:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:26:54 --> No URI present. Default controller set.
DEBUG - 2021-11-25 12:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:26:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 16:56:55 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-25 12:27:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 12:27:08 --> Total execution time: 0.0708
DEBUG - 2021-11-25 12:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 12:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 16:57:11 --> Total execution time: 0.1049
DEBUG - 2021-11-25 12:27:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:27:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 29
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_id' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 29
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 32
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_name' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 32
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 36
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_show_name' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 36
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 40
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_contact_no' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 40
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 44
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_whats_app_no' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 44
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 48
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_email' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 48
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 52
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 52
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_logo_path' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Undefined variable: profile C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
ERROR - 2021-11-25 16:57:15 --> Severity: Notice --> Trying to get property 'comp_logo' of non-object C:\xampp\htdocs\soumya\loan\application\views\Admin\settings\admin-company-profile.php 53
DEBUG - 2021-11-25 16:57:15 --> Total execution time: 0.1109
DEBUG - 2021-11-25 12:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:31:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:01:32 --> Total execution time: 0.0538
DEBUG - 2021-11-25 12:34:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:04:31 --> Total execution time: 0.0545
DEBUG - 2021-11-25 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:34:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:34:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:34:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:34:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:34:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:34:59 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:34:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:07:14 --> Total execution time: 0.7786
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:37:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:07:18 --> Total execution time: 0.0661
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:37:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:37:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:08:40 --> Total execution time: 0.0534
DEBUG - 2021-11-25 12:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:09:01 --> Total execution time: 0.0507
DEBUG - 2021-11-25 12:40:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:10:14 --> Total execution time: 0.0497
DEBUG - 2021-11-25 12:47:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:17:28 --> Total execution time: 0.0495
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:47:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:17:58 --> Total execution time: 0.0703
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:47:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:47:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:47:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:18:19 --> Total execution time: 0.0642
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:20 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:48:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:18:28 --> Total execution time: 0.0475
DEBUG - 2021-11-25 12:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:18:40 --> Total execution time: 0.0530
DEBUG - 2021-11-25 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:48:51 --> 404 Page Not Found: Admin-company-profile/index
DEBUG - 2021-11-25 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:19:33 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 12:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:19:33 --> Total execution time: 0.0451
DEBUG - 2021-11-25 12:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:19:53 --> Total execution time: 0.0611
DEBUG - 2021-11-25 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:19:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:19:54 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:19:54 --> Total execution time: 0.0491
DEBUG - 2021-11-25 12:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:20:12 --> Total execution time: 0.0560
DEBUG - 2021-11-25 12:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:20:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:20:13 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:20:13 --> Total execution time: 0.0443
DEBUG - 2021-11-25 12:53:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:23:22 --> Total execution time: 0.0592
DEBUG - 2021-11-25 12:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:23:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:23:24 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:23:24 --> Total execution time: 0.0451
DEBUG - 2021-11-25 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:23:29 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:23:29 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:23:29 --> Total execution time: 0.0451
DEBUG - 2021-11-25 12:54:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:24:49 --> Total execution time: 0.0428
DEBUG - 2021-11-25 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:24:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:24:51 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:54:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:24:51 --> Total execution time: 0.0447
DEBUG - 2021-11-25 12:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:25:30 --> Total execution time: 0.0492
DEBUG - 2021-11-25 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:25:31 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:25:31 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:55:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:25:31 --> Total execution time: 0.0474
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:55:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:55:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:57:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:57:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:27:23 --> Total execution time: 0.0442
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:05 --> Total execution time: 0.0518
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:58:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:07 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:28:07 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:07 --> Total execution time: 0.0452
DEBUG - 2021-11-25 12:58:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:35 --> Total execution time: 0.0854
DEBUG - 2021-11-25 12:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:36 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:28:36 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:28:36 --> Total execution time: 0.0439
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 12:58:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 12:59:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:29:23 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:59:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:23 --> Total execution time: 0.0450
DEBUG - 2021-11-25 12:59:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:25 --> Total execution time: 0.0426
DEBUG - 2021-11-25 12:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:26 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:29:26 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:26 --> Total execution time: 0.0501
DEBUG - 2021-11-25 12:59:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:54 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:29:54 --> You did not select a file to upload.
DEBUG - 2021-11-25 12:59:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 12:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 12:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:29:54 --> Total execution time: 0.0444
DEBUG - 2021-11-25 13:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:30:24 --> Total execution time: 0.0466
DEBUG - 2021-11-25 13:00:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:30:53 --> Total execution time: 0.3058
DEBUG - 2021-11-25 13:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:32:37 --> Total execution time: 0.0558
DEBUG - 2021-11-25 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:32:45 --> Total execution time: 0.0723
DEBUG - 2021-11-25 13:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:34:14 --> Total execution time: 0.0753
DEBUG - 2021-11-25 13:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:34:59 --> Total execution time: 0.0469
DEBUG - 2021-11-25 13:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:35:03 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:35:03 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:35:03 --> Total execution time: 0.0473
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:05:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:05:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:36:24 --> Total execution time: 0.0755
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:36:25 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:36:25 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:36:25 --> Total execution time: 0.0638
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:06:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:36:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:36:35 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:36:35 --> Total execution time: 0.0454
DEBUG - 2021-11-25 13:09:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:39:31 --> Total execution time: 0.0512
DEBUG - 2021-11-25 13:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:40:21 --> Total execution time: 0.0688
DEBUG - 2021-11-25 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:40:23 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:40:23 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:40:23 --> Total execution time: 0.0438
DEBUG - 2021-11-25 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:40:28 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:40:28 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:40:28 --> Total execution time: 0.0438
DEBUG - 2021-11-25 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:41:29 --> Total execution time: 0.0698
DEBUG - 2021-11-25 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:41:43 --> Total execution time: 0.0496
DEBUG - 2021-11-25 13:13:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:43:18 --> Total execution time: 0.0481
DEBUG - 2021-11-25 13:15:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:45:44 --> Total execution time: 0.0503
DEBUG - 2021-11-25 13:16:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:46:51 --> Total execution time: 0.0477
DEBUG - 2021-11-25 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:47:38 --> Total execution time: 0.0468
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:17:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:18:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:48:17 --> Total execution time: 0.0617
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:18:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:18:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:49:31 --> Total execution time: 0.0451
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:19:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:49:40 --> Total execution time: 0.0583
DEBUG - 2021-11-25 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:19:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:19:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:19:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:19:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:06 --> Total execution time: 0.0484
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:06 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:12 --> Total execution time: 0.0473
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:12 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:16 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:50:16 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:16 --> Total execution time: 0.0524
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:33 --> Total execution time: 0.0824
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:20:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2021-11-25 17:50:38 --> You did not select a file to upload.
DEBUG - 2021-11-25 13:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:20:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:50:38 --> Total execution time: 0.0459
DEBUG - 2021-11-25 13:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:52:08 --> Total execution time: 0.0601
DEBUG - 2021-11-25 13:23:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:53:05 --> Total execution time: 0.0478
DEBUG - 2021-11-25 13:23:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:53:13 --> Total execution time: 0.0441
DEBUG - 2021-11-25 13:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:53:18 --> Total execution time: 0.0451
DEBUG - 2021-11-25 13:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:54:17 --> Total execution time: 0.0690
DEBUG - 2021-11-25 13:25:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:55:20 --> Total execution time: 0.0507
DEBUG - 2021-11-25 13:25:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:25:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:25:23 --> 404 Page Not Found: Admin-user-list/index
DEBUG - 2021-11-25 13:27:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:27:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 17:57:52 --> Severity: error --> Exception: Unable to locate the model you have specified: User_wallet C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-25 13:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:28:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 17:58:06 --> Severity: Notice --> Undefined property: UserController::$User_logins C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 57
ERROR - 2021-11-25 17:58:06 --> Severity: error --> Exception: Call to a member function GetUserList() on null C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 57
DEBUG - 2021-11-25 13:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:28:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:28:31 --> 404 Page Not Found: Admin/user/UserController/List
DEBUG - 2021-11-25 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:58:58 --> Total execution time: 0.0440
DEBUG - 2021-11-25 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:29:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:29:00 --> 404 Page Not Found: Admin/user/UserController/List
DEBUG - 2021-11-25 13:32:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 13:36:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:06:09 --> Total execution time: 0.0659
DEBUG - 2021-11-25 13:37:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:07:03 --> Total execution time: 0.0668
DEBUG - 2021-11-25 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:07:20 --> Total execution time: 0.0581
DEBUG - 2021-11-25 13:38:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:38:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_id C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 51
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_id C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 52
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_log_id C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 54
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_user_first_name C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 55
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_user_last_name C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 55
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_log_p_read C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 56
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_user_email C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 57
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_user_mobile_no C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 58
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_user_whatsapp_no C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 59
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$ul_id C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 61
ERROR - 2021-11-25 18:08:14 --> Severity: Notice --> Undefined property: stdClass::$uw_recharge_wallet C:\xampp\htdocs\soumya\loan\application\views\Admin\user\admin-user-list.php 61
DEBUG - 2021-11-25 18:08:14 --> Total execution time: 0.0630
DEBUG - 2021-11-25 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:09:46 --> Total execution time: 0.0687
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:40:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:40:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:14:16 --> Total execution time: 0.0493
DEBUG - 2021-11-25 13:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:14:17 --> Total execution time: 0.0630
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:44:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:44:19 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:15:35 --> Total execution time: 0.0497
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:45:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:16:10 --> Total execution time: 0.0457
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:46:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:46:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:17:18 --> Total execution time: 0.0502
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:47:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:18:10 --> Total execution time: 0.0593
DEBUG - 2021-11-25 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:48:10 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:48:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:48:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:48:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:48:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:48:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:48:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:49:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:19:57 --> Total execution time: 0.0653
DEBUG - 2021-11-25 13:49:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendjs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendlibs
DEBUG - 2021-11-25 13:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:49:58 --> 404 Page Not Found: Assets/backendjs
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:20:14 --> Total execution time: 0.0625
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:50:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:20:54 --> Total execution time: 0.0461
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:50:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:21:46 --> Total execution time: 0.0457
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:51:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:22:27 --> Total execution time: 0.0709
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:28 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:28 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:52:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:52:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:24:23 --> Total execution time: 0.0480
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:54:24 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:54:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:54:24 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:25:14 --> Total execution time: 0.0467
DEBUG - 2021-11-25 13:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:26:10 --> Total execution time: 0.0594
DEBUG - 2021-11-25 13:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:28:13 --> Total execution time: 0.0467
DEBUG - 2021-11-25 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:28:32 --> Total execution time: 0.0644
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 13:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 13:59:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:30:13 --> Total execution time: 0.0720
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:30:22 --> Total execution time: 0.0542
DEBUG - 2021-11-25 14:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:30:41 --> Total execution time: 0.0901
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:30:52 --> Total execution time: 0.0439
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> UTF-8 Support Enabled
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:30:59 --> Total execution time: 0.0793
DEBUG - 2021-11-25 14:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:00:59 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:00:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:01:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:00 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:01:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:31:52 --> Total execution time: 0.0741
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:01:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:32:05 --> Total execution time: 0.0588
DEBUG - 2021-11-25 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:32:15 --> Total execution time: 0.0730
DEBUG - 2021-11-25 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:32:19 --> Total execution time: 0.0682
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:02:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:33:15 --> Total execution time: 0.0463
DEBUG - 2021-11-25 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:33:52 --> Total execution time: 0.0580
DEBUG - 2021-11-25 14:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:48:37 --> Total execution time: 0.0544
DEBUG - 2021-11-25 14:18:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:48:38 --> Total execution time: 0.0496
DEBUG - 2021-11-25 14:18:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:48:48 --> Total execution time: 0.0476
DEBUG - 2021-11-25 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:48:51 --> Total execution time: 0.0469
DEBUG - 2021-11-25 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:49:07 --> Total execution time: 0.0496
DEBUG - 2021-11-25 14:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:49:19 --> Total execution time: 0.0597
DEBUG - 2021-11-25 14:20:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:50:12 --> Total execution time: 0.0449
DEBUG - 2021-11-25 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:50:22 --> Total execution time: 0.0527
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:20:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:20:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:50:39 --> Total execution time: 0.0479
DEBUG - 2021-11-25 14:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:52:08 --> Total execution time: 0.0640
DEBUG - 2021-11-25 14:22:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:22:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:52:13 --> Total execution time: 0.0490
DEBUG - 2021-11-25 14:28:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:58:27 --> Total execution time: 0.0660
DEBUG - 2021-11-25 14:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:29:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:59:00 --> Total execution time: 0.0477
DEBUG - 2021-11-25 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:59:16 --> Total execution time: 0.0576
DEBUG - 2021-11-25 14:29:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 18:59:37 --> Total execution time: 0.0767
DEBUG - 2021-11-25 14:30:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:00:16 --> Total execution time: 0.0660
DEBUG - 2021-11-25 14:30:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:00:33 --> Total execution time: 0.0563
DEBUG - 2021-11-25 14:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:00:51 --> Total execution time: 0.0456
DEBUG - 2021-11-25 14:31:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:01:24 --> Total execution time: 0.0807
DEBUG - 2021-11-25 14:31:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:01:38 --> Total execution time: 0.0507
DEBUG - 2021-11-25 14:31:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:01:40 --> Total execution time: 0.0569
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 14:31:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 14:31:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:01:55 --> Total execution time: 0.0495
DEBUG - 2021-11-25 14:32:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:32:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 19:02:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '! 'A'' at line 3 - Invalid query: SELECT *
FROM `admins`
WHERE Admin_Type ! 'A'
DEBUG - 2021-11-25 14:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:02:06 --> Total execution time: 0.0823
DEBUG - 2021-11-25 14:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:02:09 --> Total execution time: 0.0440
DEBUG - 2021-11-25 14:36:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:06:14 --> Total execution time: 0.0685
DEBUG - 2021-11-25 14:46:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:16:30 --> Total execution time: 0.0502
DEBUG - 2021-11-25 14:49:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:19:09 --> Total execution time: 0.0476
DEBUG - 2021-11-25 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 14:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 14:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:20:49 --> Total execution time: 0.0582
DEBUG - 2021-11-25 15:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:00:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:30:59 --> Total execution time: 0.0671
DEBUG - 2021-11-25 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:01:07 --> 404 Page Not Found: Admin/user/UserController/Edit
DEBUG - 2021-11-25 15:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:01:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 19:31:54 --> Severity: Notice --> Undefined property: UserController::$User_logins C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 58
ERROR - 2021-11-25 19:31:54 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 58
DEBUG - 2021-11-25 15:02:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:32:20 --> Total execution time: 0.0462
DEBUG - 2021-11-25 15:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:32:36 --> Total execution time: 0.0603
DEBUG - 2021-11-25 15:03:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:33:29 --> Total execution time: 0.0477
DEBUG - 2021-11-25 15:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:33:41 --> Total execution time: 0.0666
DEBUG - 2021-11-25 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:03:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:33:46 --> Total execution time: 0.0431
DEBUG - 2021-11-25 15:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:33:53 --> Total execution time: 0.0576
DEBUG - 2021-11-25 15:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:36:23 --> Total execution time: 0.0497
DEBUG - 2021-11-25 15:12:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:42:42 --> Total execution time: 0.0508
DEBUG - 2021-11-25 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:42:44 --> Total execution time: 0.0466
DEBUG - 2021-11-25 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:44:48 --> Total execution time: 0.0465
DEBUG - 2021-11-25 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:44:51 --> Total execution time: 0.0437
DEBUG - 2021-11-25 15:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:45:06 --> Total execution time: 0.0664
DEBUG - 2021-11-25 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:45:07 --> Total execution time: 0.0437
DEBUG - 2021-11-25 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:45:22 --> Total execution time: 0.0448
DEBUG - 2021-11-25 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:45:52 --> Total execution time: 0.0462
DEBUG - 2021-11-25 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:45:58 --> Total execution time: 0.0453
DEBUG - 2021-11-25 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:46:08 --> Total execution time: 0.0453
DEBUG - 2021-11-25 15:16:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:46:15 --> Total execution time: 0.0481
DEBUG - 2021-11-25 15:16:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:46:29 --> Total execution time: 0.0490
DEBUG - 2021-11-25 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:16:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:46:57 --> Total execution time: 0.0605
DEBUG - 2021-11-25 15:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:56:46 --> Total execution time: 0.0494
DEBUG - 2021-11-25 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 19:57:05 --> Total execution time: 0.0628
DEBUG - 2021-11-25 15:34:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:04:03 --> Total execution time: 0.0554
DEBUG - 2021-11-25 15:34:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:04:27 --> Total execution time: 0.0606
DEBUG - 2021-11-25 15:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:04:38 --> Total execution time: 0.0470
DEBUG - 2021-11-25 15:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:08:34 --> Total execution time: 0.0573
DEBUG - 2021-11-25 15:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:10:09 --> Total execution time: 0.0504
DEBUG - 2021-11-25 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 20:10:13 --> Severity: Notice --> Undefined variable: Admins C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 109
ERROR - 2021-11-25 20:10:13 --> Query error: Unknown column 'Admins' in 'where clause' - Invalid query: SELECT *
FROM `admins`
WHERE `Admins` IS NULL
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 20:10:26 --> Severity: Notice --> Undefined variable: Admins C:\xampp\htdocs\soumya\loan\application\controllers\Admin\user\UserController.php 109
ERROR - 2021-11-25 20:10:26 --> Query error: Unknown column 'Admins' in 'where clause' - Invalid query: SELECT *
FROM `admins`
WHERE `Admins` IS NULL
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:10:40 --> Total execution time: 0.0501
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:10:43 --> Total execution time: 0.0739
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:10:44 --> Total execution time: 0.0588
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 15:40:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 15:40:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:10:50 --> Total execution time: 0.0570
DEBUG - 2021-11-25 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:41:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:11:11 --> Total execution time: 0.0677
DEBUG - 2021-11-25 15:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:11:21 --> Total execution time: 0.0475
DEBUG - 2021-11-25 15:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 15:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:11:44 --> Total execution time: 0.0671
DEBUG - 2021-11-25 15:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 15:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 15:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:12:20 --> Total execution time: 0.0558
DEBUG - 2021-11-25 16:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:30:24 --> Total execution time: 0.0697
DEBUG - 2021-11-25 16:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:31:19 --> Total execution time: 0.0797
DEBUG - 2021-11-25 16:01:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:31:26 --> Total execution time: 0.0806
DEBUG - 2021-11-25 16:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:31:49 --> Total execution time: 0.0483
DEBUG - 2021-11-25 16:14:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:44:29 --> Total execution time: 0.0781
DEBUG - 2021-11-25 16:29:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 20:59:49 --> Total execution time: 0.0706
DEBUG - 2021-11-25 16:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:00:35 --> Total execution time: 0.0476
DEBUG - 2021-11-25 16:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:00:51 --> Total execution time: 0.0703
DEBUG - 2021-11-25 16:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:30:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:30:55 --> Severity: error --> Exception: Class 'UD_Controller' not found C:\xampp\htdocs\soumya\loan\application\controllers\Admin\department\Department_Controller.php 3
DEBUG - 2021-11-25 16:30:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:00:57 --> Total execution time: 0.0483
DEBUG - 2021-11-25 16:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:01:03 --> Total execution time: 0.0656
DEBUG - 2021-11-25 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:01:30 --> Total execution time: 0.0784
DEBUG - 2021-11-25 16:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:31:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:01:32 --> Severity: error --> Exception: Call to undefined function PERMIT_RECORD_ONLY_ADMIN() C:\xampp\htdocs\soumya\loan\application\controllers\Admin\department\Department_Controller.php 8
DEBUG - 2021-11-25 16:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:31:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:01:47 --> Severity: error --> Exception: Unable to locate the model you have specified: Departments_permission C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-25 16:31:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:31:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:01:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Departments_permission C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-25 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:32:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:02:11 --> Severity: error --> Exception: Unable to locate the model you have specified: Departments_permission C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-11-25 16:32:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:02:58 --> Total execution time: 0.0442
DEBUG - 2021-11-25 16:36:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:36:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:06:12 --> Severity: Notice --> Undefined variable: PERMIT_WRITE C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-list.php 56
ERROR - 2021-11-25 21:06:12 --> Severity: Notice --> Undefined variable: PERMIT_WRITE C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-list.php 56
DEBUG - 2021-11-25 21:06:12 --> Total execution time: 0.0685
DEBUG - 2021-11-25 16:36:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:06:37 --> Total execution time: 0.0561
DEBUG - 2021-11-25 16:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:07:12 --> Total execution time: 0.0490
DEBUG - 2021-11-25 16:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:08:29 --> Total execution time: 0.0475
DEBUG - 2021-11-25 16:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:10:22 --> Total execution time: 0.0489
DEBUG - 2021-11-25 16:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:03 --> Total execution time: 0.0533
DEBUG - 2021-11-25 16:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:05 --> Total execution time: 0.0633
DEBUG - 2021-11-25 16:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:05 --> Total execution time: 0.0436
DEBUG - 2021-11-25 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:06 --> Total execution time: 0.0422
DEBUG - 2021-11-25 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:06 --> Total execution time: 0.0432
DEBUG - 2021-11-25 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:08 --> Total execution time: 0.0454
DEBUG - 2021-11-25 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:08 --> Total execution time: 0.0427
DEBUG - 2021-11-25 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:09 --> Total execution time: 0.0417
DEBUG - 2021-11-25 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:09 --> Total execution time: 0.0670
DEBUG - 2021-11-25 16:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:30 --> Total execution time: 0.0425
DEBUG - 2021-11-25 16:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:30 --> Total execution time: 0.0529
DEBUG - 2021-11-25 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:31 --> Total execution time: 0.0546
DEBUG - 2021-11-25 16:56:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:31 --> Total execution time: 0.0651
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:56:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:44 --> Total execution time: 0.0432
DEBUG - 2021-11-25 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:44 --> Total execution time: 0.0442
DEBUG - 2021-11-25 16:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:45 --> Total execution time: 0.0647
DEBUG - 2021-11-25 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:45 --> Total execution time: 0.0518
DEBUG - 2021-11-25 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:45 --> Total execution time: 0.0567
DEBUG - 2021-11-25 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:45 --> Total execution time: 0.0536
DEBUG - 2021-11-25 16:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:47 --> Total execution time: 0.0484
DEBUG - 2021-11-25 16:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:50 --> Total execution time: 0.0437
DEBUG - 2021-11-25 16:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:51 --> Total execution time: 0.0740
DEBUG - 2021-11-25 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:52 --> Total execution time: 0.0620
DEBUG - 2021-11-25 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:52 --> Total execution time: 0.0426
DEBUG - 2021-11-25 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:26:55 --> Total execution time: 0.0633
DEBUG - 2021-11-25 16:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:14 --> Total execution time: 0.0723
DEBUG - 2021-11-25 16:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:15 --> Total execution time: 0.0470
DEBUG - 2021-11-25 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:16 --> Total execution time: 0.0665
DEBUG - 2021-11-25 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:16 --> Total execution time: 0.0523
DEBUG - 2021-11-25 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:17 --> Total execution time: 0.0631
DEBUG - 2021-11-25 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:17 --> Total execution time: 0.0530
DEBUG - 2021-11-25 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:19 --> Total execution time: 0.0599
DEBUG - 2021-11-25 16:57:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:20 --> Total execution time: 0.0439
DEBUG - 2021-11-25 16:57:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:21 --> Total execution time: 0.0474
DEBUG - 2021-11-25 16:57:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:22 --> Total execution time: 0.0448
DEBUG - 2021-11-25 16:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:24 --> Total execution time: 0.0472
DEBUG - 2021-11-25 16:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:25 --> Total execution time: 0.0532
DEBUG - 2021-11-25 16:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:25 --> Total execution time: 0.0542
DEBUG - 2021-11-25 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:31 --> Total execution time: 0.0468
DEBUG - 2021-11-25 16:57:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:33 --> Total execution time: 0.0614
DEBUG - 2021-11-25 16:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:39 --> Total execution time: 0.0479
DEBUG - 2021-11-25 16:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:40 --> Total execution time: 0.0498
DEBUG - 2021-11-25 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:42 --> Total execution time: 0.0474
DEBUG - 2021-11-25 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:42 --> Total execution time: 0.0545
DEBUG - 2021-11-25 16:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:42 --> Total execution time: 0.0446
DEBUG - 2021-11-25 16:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:43 --> Total execution time: 0.0618
DEBUG - 2021-11-25 16:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:43 --> Total execution time: 0.0661
DEBUG - 2021-11-25 16:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:43 --> Total execution time: 0.0543
DEBUG - 2021-11-25 16:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:27:43 --> Total execution time: 0.0525
DEBUG - 2021-11-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:10 --> UTF-8 Support Enabled
ERROR - 2021-11-25 16:58:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:11 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 16:58:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:19 --> Total execution time: 0.0436
DEBUG - 2021-11-25 16:58:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:19 --> Total execution time: 0.0645
DEBUG - 2021-11-25 16:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:21 --> Total execution time: 0.0647
DEBUG - 2021-11-25 16:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:21 --> Total execution time: 0.0535
DEBUG - 2021-11-25 16:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:22 --> Total execution time: 0.0677
DEBUG - 2021-11-25 16:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:22 --> Total execution time: 0.0684
DEBUG - 2021-11-25 16:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:30 --> Total execution time: 0.0416
DEBUG - 2021-11-25 16:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:30 --> Total execution time: 0.0422
DEBUG - 2021-11-25 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:31 --> Total execution time: 0.0647
DEBUG - 2021-11-25 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:31 --> Total execution time: 0.0423
DEBUG - 2021-11-25 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:31 --> Total execution time: 0.0411
DEBUG - 2021-11-25 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:31 --> Total execution time: 0.0426
DEBUG - 2021-11-25 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:32 --> Total execution time: 0.0544
DEBUG - 2021-11-25 16:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:32 --> Total execution time: 0.0676
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:44 --> Total execution time: 0.0492
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:58:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:45 --> Total execution time: 0.0455
DEBUG - 2021-11-25 16:58:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:46 --> Total execution time: 0.0624
DEBUG - 2021-11-25 16:58:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:46 --> Total execution time: 0.0658
DEBUG - 2021-11-25 16:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:47 --> Total execution time: 0.0436
DEBUG - 2021-11-25 16:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:47 --> Total execution time: 0.0636
DEBUG - 2021-11-25 16:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:47 --> Total execution time: 0.0609
DEBUG - 2021-11-25 16:58:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:28:47 --> Total execution time: 0.0431
DEBUG - 2021-11-25 16:59:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:29:27 --> Total execution time: 0.0506
DEBUG - 2021-11-25 16:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:29:29 --> Total execution time: 0.0607
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:29:58 --> Total execution time: 0.0559
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 16:59:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 16:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 16:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 16:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:29:59 --> Total execution time: 0.0584
DEBUG - 2021-11-25 17:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:00 --> Total execution time: 0.0560
DEBUG - 2021-11-25 17:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:00 --> Total execution time: 0.0439
DEBUG - 2021-11-25 17:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:00 --> Total execution time: 0.0606
DEBUG - 2021-11-25 17:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:00 --> Total execution time: 0.0520
DEBUG - 2021-11-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:01 --> Total execution time: 0.0420
DEBUG - 2021-11-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:01 --> Total execution time: 0.0639
DEBUG - 2021-11-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:01 --> Total execution time: 0.0452
DEBUG - 2021-11-25 17:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:01 --> Total execution time: 0.0416
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0564
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0406
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0562
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0403
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0537
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:21 --> Total execution time: 0.0419
DEBUG - 2021-11-25 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0607
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0646
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0635
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0679
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0620
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0664
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0653
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:22 --> Total execution time: 0.0666
DEBUG - 2021-11-25 17:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0526
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0519
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0420
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0429
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0633
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0411
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0418
DEBUG - 2021-11-25 17:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:23 --> Total execution time: 0.0426
DEBUG - 2021-11-25 17:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:42 --> Total execution time: 0.0534
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:43 --> Total execution time: 0.0628
DEBUG - 2021-11-25 17:00:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:44 --> Total execution time: 0.0811
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:00:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:00:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:47 --> Total execution time: 0.0664
DEBUG - 2021-11-25 17:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:30:48 --> Total execution time: 0.0468
DEBUG - 2021-11-25 17:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:31:41 --> Total execution time: 0.0619
DEBUG - 2021-11-25 17:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:01:41 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:01:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:01:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:31:42 --> Total execution time: 0.0430
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:25 --> Total execution time: 0.0721
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:25 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:26 --> Total execution time: 0.0641
DEBUG - 2021-11-25 17:02:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:29 --> Total execution time: 0.0521
DEBUG - 2021-11-25 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:54 --> Total execution time: 0.0479
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:56 --> Total execution time: 0.0482
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:57 --> Total execution time: 0.0749
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:57 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:02:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:02:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:58 --> Total execution time: 0.0418
DEBUG - 2021-11-25 17:02:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:32:58 --> Total execution time: 0.0451
DEBUG - 2021-11-25 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:33 --> Total execution time: 0.0740
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:03:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:35 --> Total execution time: 0.0480
DEBUG - 2021-11-25 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:36 --> Total execution time: 0.0434
DEBUG - 2021-11-25 17:03:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:36 --> Total execution time: 0.0557
DEBUG - 2021-11-25 17:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:37 --> Total execution time: 0.0630
DEBUG - 2021-11-25 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:38 --> Total execution time: 0.0568
DEBUG - 2021-11-25 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:38 --> Total execution time: 0.0690
DEBUG - 2021-11-25 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:38 --> Total execution time: 0.0447
DEBUG - 2021-11-25 17:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:39 --> Total execution time: 0.0552
DEBUG - 2021-11-25 17:03:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:33:39 --> Total execution time: 0.0686
DEBUG - 2021-11-25 17:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:34:17 --> Total execution time: 0.0481
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:04:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:34:18 --> Total execution time: 0.0462
DEBUG - 2021-11-25 17:04:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:34:19 --> Total execution time: 0.0596
DEBUG - 2021-11-25 17:04:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:34:19 --> Total execution time: 0.0648
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:23 --> Total execution time: 0.0618
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:24 --> Total execution time: 0.0452
DEBUG - 2021-11-25 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:24 --> Total execution time: 0.0593
DEBUG - 2021-11-25 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:25 --> Total execution time: 0.0665
DEBUG - 2021-11-25 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:26 --> Total execution time: 0.0586
DEBUG - 2021-11-25 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:26 --> Total execution time: 0.0575
DEBUG - 2021-11-25 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:26 --> Total execution time: 0.0677
DEBUG - 2021-11-25 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:35 --> Total execution time: 0.0753
DEBUG - 2021-11-25 17:05:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:36 --> Total execution time: 0.0454
DEBUG - 2021-11-25 17:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:37 --> Total execution time: 0.0584
DEBUG - 2021-11-25 17:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:45 --> Total execution time: 0.0434
DEBUG - 2021-11-25 17:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:35:47 --> Total execution time: 0.0639
DEBUG - 2021-11-25 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:17 --> Total execution time: 0.0683
DEBUG - 2021-11-25 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:18 --> Total execution time: 0.0702
DEBUG - 2021-11-25 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:19 --> Total execution time: 0.0511
DEBUG - 2021-11-25 17:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:22 --> Total execution time: 0.0572
DEBUG - 2021-11-25 17:06:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:53 --> Total execution time: 0.0893
DEBUG - 2021-11-25 17:06:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:54 --> Total execution time: 0.0622
DEBUG - 2021-11-25 17:06:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:55 --> Total execution time: 0.0774
DEBUG - 2021-11-25 17:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:56 --> Total execution time: 0.0674
DEBUG - 2021-11-25 17:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:36:57 --> Total execution time: 0.0743
DEBUG - 2021-11-25 17:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:22 --> Total execution time: 0.0682
DEBUG - 2021-11-25 17:08:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:23 --> Total execution time: 0.0450
DEBUG - 2021-11-25 17:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:24 --> Total execution time: 0.0735
DEBUG - 2021-11-25 17:08:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:25 --> Total execution time: 0.0575
DEBUG - 2021-11-25 17:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:29 --> Total execution time: 0.0404
DEBUG - 2021-11-25 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:33 --> Total execution time: 0.0667
DEBUG - 2021-11-25 17:08:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:38:34 --> Total execution time: 0.0656
DEBUG - 2021-11-25 17:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:39:06 --> Total execution time: 0.0612
DEBUG - 2021-11-25 17:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:39:08 --> Total execution time: 0.0407
DEBUG - 2021-11-25 17:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:39:14 --> Total execution time: 0.0490
DEBUG - 2021-11-25 17:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:39:35 --> Total execution time: 0.0637
DEBUG - 2021-11-25 17:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:39:37 --> Total execution time: 0.0481
DEBUG - 2021-11-25 17:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:40:10 --> Total execution time: 0.0576
DEBUG - 2021-11-25 17:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:40:14 --> Total execution time: 0.0588
DEBUG - 2021-11-25 17:10:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:40:17 --> Total execution time: 0.0654
DEBUG - 2021-11-25 17:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:40:18 --> Severity: error --> Exception: Call to undefined function PERMIT_RECORD() C:\xampp\htdocs\soumya\loan\application\controllers\Admin\department\Department_Controller.php 20
DEBUG - 2021-11-25 17:10:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:40:32 --> Severity: error --> Exception: Call to undefined method Department_Controller::user_view() C:\xampp\htdocs\soumya\loan\application\controllers\Admin\department\Department_Controller.php 23
DEBUG - 2021-11-25 17:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:40:39 --> Total execution time: 0.0440
DEBUG - 2021-11-25 17:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:41:45 --> Total execution time: 0.0699
DEBUG - 2021-11-25 17:14:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:14:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:44:43 --> Severity: error --> Exception: Call to undefined function GetBy_ModuleInstanceList() C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-add.php 46
DEBUG - 2021-11-25 17:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:15:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:45:05 --> Severity: error --> Exception: Call to undefined function ModuleList() C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-add.php 59
DEBUG - 2021-11-25 17:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:46:02 --> Total execution time: 0.0695
DEBUG - 2021-11-25 17:16:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:46:17 --> Total execution time: 0.0491
DEBUG - 2021-11-25 17:16:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:46:59 --> Total execution time: 0.0644
DEBUG - 2021-11-25 17:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:47:15 --> Total execution time: 0.0626
DEBUG - 2021-11-25 17:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:47:27 --> Total execution time: 0.0562
DEBUG - 2021-11-25 17:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:19:45 --> 404 Page Not Found: Department-add/index
DEBUG - 2021-11-25 17:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:49:47 --> Total execution time: 0.2155
DEBUG - 2021-11-25 17:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:50:07 --> Total execution time: 0.0458
DEBUG - 2021-11-25 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:20:16 --> 404 Page Not Found: Department-add/index
DEBUG - 2021-11-25 17:20:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:50:18 --> Total execution time: 0.0470
DEBUG - 2021-11-25 17:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:50:19 --> Total execution time: 0.0463
DEBUG - 2021-11-25 17:20:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:50:29 --> Total execution time: 0.4196
DEBUG - 2021-11-25 17:20:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:20:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:20:32 --> 404 Page Not Found: Department-add/index
DEBUG - 2021-11-25 17:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:50:58 --> Total execution time: 0.0714
DEBUG - 2021-11-25 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:03 --> Total execution time: 0.0479
DEBUG - 2021-11-25 17:21:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:06 --> Total execution time: 0.0459
DEBUG - 2021-11-25 17:21:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:09 --> Total execution time: 0.0459
DEBUG - 2021-11-25 17:21:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:09 --> Total execution time: 0.0439
DEBUG - 2021-11-25 17:21:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:11 --> Total execution time: 0.0451
DEBUG - 2021-11-25 17:21:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:13 --> Total execution time: 0.0479
DEBUG - 2021-11-25 17:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:14 --> Total execution time: 0.0483
DEBUG - 2021-11-25 17:21:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:51 --> Total execution time: 0.0460
DEBUG - 2021-11-25 17:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:52 --> Total execution time: 0.0450
DEBUG - 2021-11-25 17:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:54 --> Total execution time: 0.0617
DEBUG - 2021-11-25 17:21:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:57 --> Total execution time: 0.0464
DEBUG - 2021-11-25 17:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:51:58 --> Total execution time: 0.0704
DEBUG - 2021-11-25 17:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:22:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:52:12 --> Total execution time: 0.0488
DEBUG - 2021-11-25 17:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:22:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:22:17 --> 404 Page Not Found: Department-edit/index
DEBUG - 2021-11-25 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:52:21 --> Total execution time: 0.0458
DEBUG - 2021-11-25 17:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:52:48 --> Total execution time: 0.0607
DEBUG - 2021-11-25 17:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:22:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:52:49 --> Severity: error --> Exception: Call to undefined method Department_Controller::user_view() C:\xampp\htdocs\soumya\loan\application\controllers\Admin\department\Department_Controller.php 79
DEBUG - 2021-11-25 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:53:15 --> Total execution time: 0.0428
DEBUG - 2021-11-25 17:23:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:53:28 --> Total execution time: 0.0878
DEBUG - 2021-11-25 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:25:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:55:01 --> Severity: Notice --> Undefined property: stdClass::$dep_instance C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-edit.php 47
ERROR - 2021-11-25 21:55:01 --> Severity: error --> Exception: Call to undefined function GetBy_ModuleInstanceList() C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-edit.php 49
DEBUG - 2021-11-25 17:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:25:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:55:16 --> Severity: error --> Exception: Call to undefined function ModuleActive() C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-edit.php 69
DEBUG - 2021-11-25 17:25:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:25:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-11-25 21:55:47 --> Severity: error --> Exception: Call to undefined function ModuleNameById() C:\xampp\htdocs\soumya\loan\application\views\Admin\department\department-edit.php 71
DEBUG - 2021-11-25 17:26:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:56:03 --> Total execution time: 0.0690
DEBUG - 2021-11-25 17:27:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:57:25 --> Total execution time: 0.0726
DEBUG - 2021-11-25 17:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 21:59:43 --> Total execution time: 0.0703
DEBUG - 2021-11-25 17:31:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:01:46 --> Total execution time: 0.0661
DEBUG - 2021-11-25 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:31:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:01:49 --> Total execution time: 0.0474
DEBUG - 2021-11-25 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 17:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:01:51 --> Total execution time: 0.0463
DEBUG - 2021-11-25 17:32:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:02:13 --> Total execution time: 0.0743
DEBUG - 2021-11-25 17:32:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:02:17 --> Total execution time: 0.0478
DEBUG - 2021-11-25 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:03:44 --> Total execution time: 0.0476
DEBUG - 2021-11-25 17:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:04:13 --> Total execution time: 0.0511
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-25 17:34:34 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-11-25 17:34:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:04:46 --> Total execution time: 0.0630
DEBUG - 2021-11-25 17:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:05:03 --> Total execution time: 0.0852
DEBUG - 2021-11-25 17:35:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:05:07 --> Total execution time: 0.0483
DEBUG - 2021-11-25 17:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:17:02 --> Total execution time: 0.0785
DEBUG - 2021-11-25 17:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:17:08 --> Total execution time: 0.0496
DEBUG - 2021-11-25 17:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:17:41 --> Total execution time: 0.0683
DEBUG - 2021-11-25 17:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:18:06 --> Total execution time: 0.0676
DEBUG - 2021-11-25 17:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:18:32 --> Total execution time: 0.0480
DEBUG - 2021-11-25 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:19:23 --> Total execution time: 0.0497
DEBUG - 2021-11-25 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:19:36 --> Total execution time: 0.0479
DEBUG - 2021-11-25 17:49:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:19:48 --> Total execution time: 0.0730
DEBUG - 2021-11-25 17:49:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:19:49 --> Total execution time: 0.0686
DEBUG - 2021-11-25 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:20:07 --> Total execution time: 0.0495
DEBUG - 2021-11-25 17:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-25 17:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-25 17:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-11-25 22:21:04 --> Total execution time: 0.0610
