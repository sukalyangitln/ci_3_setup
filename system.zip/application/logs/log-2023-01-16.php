<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-01-16 12:50:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:50:35 --> No URI present. Default controller set.
DEBUG - 2023-01-16 12:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:20:35 --> Total execution time: 0.7509
DEBUG - 2023-01-16 12:50:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 12:50:46 --> Total execution time: 0.0630
DEBUG - 2023-01-16 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 12:50:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:20:48 --> Total execution time: 0.1102
DEBUG - 2023-01-16 12:52:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:22:02 --> Total execution time: 0.1375
DEBUG - 2023-01-16 12:52:06 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:22:06 --> Total execution time: 0.1538
DEBUG - 2023-01-16 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:22:14 --> Total execution time: 0.1966
DEBUG - 2023-01-16 12:52:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:52:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:22:19 --> Total execution time: 0.0604
DEBUG - 2023-01-16 12:57:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:27:57 --> Total execution time: 0.0734
DEBUG - 2023-01-16 12:58:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:28:34 --> Total execution time: 0.0702
DEBUG - 2023-01-16 12:58:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:28:40 --> Total execution time: 0.1292
DEBUG - 2023-01-16 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 12:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:28:53 --> Total execution time: 0.0898
DEBUG - 2023-01-16 13:03:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:33:47 --> Total execution time: 0.0529
DEBUG - 2023-01-16 13:04:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:04:05 --> No URI present. Default controller set.
DEBUG - 2023-01-16 13:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:34:05 --> Total execution time: 0.0480
DEBUG - 2023-01-16 13:04:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:34:08 --> Total execution time: 0.0764
DEBUG - 2023-01-16 13:04:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:34:11 --> Total execution time: 0.1111
DEBUG - 2023-01-16 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 13:04:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:34:16 --> Total execution time: 0.0986
DEBUG - 2023-01-16 13:05:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 13:05:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 13:05:54 --> Total execution time: 0.0388
DEBUG - 2023-01-16 13:06:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:36:40 --> Total execution time: 0.0591
DEBUG - 2023-01-16 13:06:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:06:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:36:57 --> Total execution time: 0.0534
DEBUG - 2023-01-16 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:38:07 --> Total execution time: 0.0661
DEBUG - 2023-01-16 13:08:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:08:26 --> No URI present. Default controller set.
DEBUG - 2023-01-16 13:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:38:26 --> Total execution time: 0.0522
DEBUG - 2023-01-16 13:12:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:42:54 --> Total execution time: 0.1687
DEBUG - 2023-01-16 13:13:56 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:43:56 --> Total execution time: 0.0724
DEBUG - 2023-01-16 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:15:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Undefined variable: banner C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 43
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Trying to get property 'hb_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 43
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Undefined variable: banner C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 43
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Trying to get property 'hb_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 43
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Undefined variable: banner C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 46
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Trying to get property 'hb_image_path' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 46
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Undefined variable: banner C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 46
ERROR - 2023-01-16 17:45:26 --> Severity: Notice --> Trying to get property 'hb_image' of non-object C:\xampp\htdocs\gopal\crowd_funding\application\views\website\donate-view.php 46
DEBUG - 2023-01-16 17:45:26 --> Total execution time: 0.0947
DEBUG - 2023-01-16 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:15:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:45:39 --> Total execution time: 0.0818
DEBUG - 2023-01-16 13:15:51 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:45:51 --> Total execution time: 0.0819
DEBUG - 2023-01-16 13:18:23 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:48:23 --> Total execution time: 0.0597
DEBUG - 2023-01-16 13:20:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:50:54 --> Total execution time: 0.0582
DEBUG - 2023-01-16 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:51:11 --> Total execution time: 0.0598
DEBUG - 2023-01-16 13:21:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:51:49 --> Total execution time: 0.1582
DEBUG - 2023-01-16 13:24:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:54:07 --> Total execution time: 0.0641
DEBUG - 2023-01-16 13:29:47 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 17:59:47 --> Total execution time: 0.0732
DEBUG - 2023-01-16 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:02:44 --> Total execution time: 0.0820
DEBUG - 2023-01-16 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:39:08 --> UTF-8 Support Enabled
ERROR - 2023-01-16 13:39:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:39:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:39:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:39:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:39:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:39:08 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 13:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 13:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:12:11 --> Total execution time: 0.0834
DEBUG - 2023-01-16 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:42:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:42:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:42:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 13:42:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 13:42:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 13:42:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:42:58 --> Total execution time: 0.0715
DEBUG - 2023-01-16 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:12:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:12:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:12:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:12:58 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 14:12:58 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:12:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:12:59 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:43:16 --> Total execution time: 0.0791
DEBUG - 2023-01-16 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:13:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:13:16 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 14:13:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:13:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:13:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:13:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:44:45 --> Total execution time: 0.0725
DEBUG - 2023-01-16 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:14:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:14:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:14:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:14:45 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:46:07 --> Total execution time: 0.0596
DEBUG - 2023-01-16 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:16:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:16:07 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 14:16:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:16:07 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:48:24 --> Total execution time: 0.0594
DEBUG - 2023-01-16 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:18:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:18:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:18:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:18:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:18:24 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:49:02 --> Total execution time: 0.0997
DEBUG - 2023-01-16 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:19:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:19:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:19:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:19:02 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:21:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:51:22 --> Total execution time: 0.0685
DEBUG - 2023-01-16 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:24:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:24:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:24:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:24:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:24:25 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:25:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:55:48 --> Total execution time: 0.0735
DEBUG - 2023-01-16 14:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:25:57 --> UTF-8 Support Enabled
ERROR - 2023-01-16 14:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:57:41 --> Total execution time: 0.0774
DEBUG - 2023-01-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:27:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:27:41 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 14:27:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:27:41 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:27:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:57:49 --> Total execution time: 0.0653
DEBUG - 2023-01-16 14:28:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:58:14 --> Total execution time: 0.0904
DEBUG - 2023-01-16 14:28:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:58:19 --> Total execution time: 0.0706
DEBUG - 2023-01-16 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 14:28:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:58:57 --> Total execution time: 0.0579
DEBUG - 2023-01-16 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 18:58:59 --> Total execution time: 0.0440
DEBUG - 2023-01-16 14:32:54 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:02:54 --> Total execution time: 0.0612
DEBUG - 2023-01-16 14:33:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:03:11 --> Total execution time: 0.0738
DEBUG - 2023-01-16 14:33:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:03:30 --> Total execution time: 0.0654
DEBUG - 2023-01-16 14:33:58 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:03:58 --> Total execution time: 0.0480
DEBUG - 2023-01-16 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:34:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:34:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 14:35:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:05:17 --> Total execution time: 0.0603
DEBUG - 2023-01-16 14:35:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 14:35:20 --> 404 Page Not Found: fundraiser/Forgot-password/index
DEBUG - 2023-01-16 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:07:18 --> Total execution time: 0.0410
DEBUG - 2023-01-16 14:41:29 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:11:29 --> Total execution time: 0.0484
DEBUG - 2023-01-16 14:41:42 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:11:43 --> Total execution time: 0.0701
DEBUG - 2023-01-16 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:12:02 --> Total execution time: 0.0634
DEBUG - 2023-01-16 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 14:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 14:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 14:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:12:24 --> Total execution time: 0.0533
DEBUG - 2023-01-16 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:31 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:38:34 --> Total execution time: 0.0672
DEBUG - 2023-01-16 15:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:34 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:08:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:08:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:08:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:08:34 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:40:20 --> Total execution time: 0.0653
DEBUG - 2023-01-16 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:20 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:10:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:40:22 --> Total execution time: 0.0426
DEBUG - 2023-01-16 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:40:26 --> Total execution time: 0.0413
DEBUG - 2023-01-16 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:26 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:26 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:40:49 --> Total execution time: 0.0564
DEBUG - 2023-01-16 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:49 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:10:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:10:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:10:49 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:41:35 --> Total execution time: 0.0596
DEBUG - 2023-01-16 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:11:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:11:35 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:11:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:11:35 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:11:46 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:41:46 --> Total execution time: 0.0422
DEBUG - 2023-01-16 15:25:49 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:55:49 --> Total execution time: 0.0545
DEBUG - 2023-01-16 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:25:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:25:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:57:48 --> Total execution time: 0.0687
DEBUG - 2023-01-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:27:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:27:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:27:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:27:48 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:58:07 --> Total execution time: 0.0487
DEBUG - 2023-01-16 15:28:14 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:58:14 --> Total execution time: 0.0447
DEBUG - 2023-01-16 15:29:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:59:05 --> Total execution time: 0.0630
DEBUG - 2023-01-16 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 19:59:08 --> Total execution time: 0.0684
DEBUG - 2023-01-16 15:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:29:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:29:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:29:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:29:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:29:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:09 --> Total execution time: 0.0666
DEBUG - 2023-01-16 15:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:09 --> UTF-8 Support Enabled
ERROR - 2023-01-16 15:32:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:09 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:16 --> Total execution time: 0.0569
DEBUG - 2023-01-16 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:16 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:21 --> Total execution time: 0.0431
DEBUG - 2023-01-16 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:37 --> Total execution time: 0.0659
DEBUG - 2023-01-16 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:37 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:32:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:37 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:32:37 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:39 --> Total execution time: 0.0432
DEBUG - 2023-01-16 15:32:48 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:02:48 --> Total execution time: 0.0438
DEBUG - 2023-01-16 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:03:01 --> Total execution time: 0.0694
DEBUG - 2023-01-16 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:33:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:33:01 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:33:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:33:01 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:33:03 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:03:03 --> Total execution time: 0.0417
DEBUG - 2023-01-16 15:33:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:03:12 --> Total execution time: 0.0434
DEBUG - 2023-01-16 15:33:18 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:03:18 --> Total execution time: 0.0461
DEBUG - 2023-01-16 15:39:16 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:09:16 --> Total execution time: 0.0463
DEBUG - 2023-01-16 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:39:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:39:17 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:39:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:39:17 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:39:17 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:39:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:09:20 --> Total execution time: 0.0564
DEBUG - 2023-01-16 15:39:27 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:39:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:09:27 --> Total execution time: 0.0446
DEBUG - 2023-01-16 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:09:30 --> Total execution time: 0.0435
DEBUG - 2023-01-16 15:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:10:12 --> Total execution time: 0.0642
DEBUG - 2023-01-16 15:40:12 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:10:13 --> Total execution time: 0.0490
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:13 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:40:13 --> 404 Page Not Found: Assets/backend
DEBUG - 2023-01-16 15:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 15:40:26 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:10:26 --> Total execution time: 0.0432
DEBUG - 2023-01-16 15:44:44 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:14:44 --> Total execution time: 0.0775
DEBUG - 2023-01-16 15:44:50 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:14:50 --> Total execution time: 0.0440
DEBUG - 2023-01-16 15:44:53 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:44:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:44:53 --> 404 Page Not Found: website/auth/Donater_Registration/forgot_password
DEBUG - 2023-01-16 15:45:04 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:15:05 --> Total execution time: 0.0522
DEBUG - 2023-01-16 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:17:34 --> Total execution time: 0.0428
DEBUG - 2023-01-16 15:47:52 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:17:52 --> Total execution time: 0.0608
DEBUG - 2023-01-16 15:57:09 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:10 --> Total execution time: 0.0638
DEBUG - 2023-01-16 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:19 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:19 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:20 --> Total execution time: 0.0476
DEBUG - 2023-01-16 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:20 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:20 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:21 --> 404 Page Not Found: Assets/website
ERROR - 2023-01-16 15:57:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:21 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:21 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:28 --> Total execution time: 0.0449
DEBUG - 2023-01-16 15:57:36 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:36 --> Total execution time: 0.0434
DEBUG - 2023-01-16 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:39 --> Total execution time: 0.0688
DEBUG - 2023-01-16 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:27:39 --> Total execution time: 0.0896
DEBUG - 2023-01-16 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:57:40 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:57:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-01-16 15:57:40 --> 404 Page Not Found: Assets/website
DEBUG - 2023-01-16 15:58:05 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 15:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 15:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 15:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 20:28:05 --> Total execution time: 0.0643
DEBUG - 2023-01-16 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 16:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 16:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 16:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 16:44:34 --> UTF-8 Support Enabled
DEBUG - 2023-01-16 16:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-01-16 16:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-01-16 16:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-01-16 21:14:34 --> Total execution time: 0.0496
