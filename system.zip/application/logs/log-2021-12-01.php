<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-01 14:23:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:23:45 --> No URI present. Default controller set.
DEBUG - 2021-12-01 14:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:23:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-01 18:53:46 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-12-01 14:23:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:23:48 --> No URI present. Default controller set.
DEBUG - 2021-12-01 14:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:23:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-12-01 18:53:48 --> Severity: error --> Exception: Unable to locate the model you have specified: User_logins C:\xampp\htdocs\soumya\loan\system\core\Loader.php 348
DEBUG - 2021-12-01 14:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 14:23:52 --> Total execution time: 0.0782
DEBUG - 2021-12-01 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 14:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 18:53:56 --> Total execution time: 0.1246
DEBUG - 2021-12-01 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:14:56 --> Total execution time: 0.1044
DEBUG - 2021-12-01 14:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:24:20 --> Total execution time: 0.0721
DEBUG - 2021-12-01 14:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:28:27 --> Total execution time: 0.0671
DEBUG - 2021-12-01 14:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:28:36 --> Total execution time: 0.1155
DEBUG - 2021-12-01 14:58:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:58:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 14:58:39 --> 404 Page Not Found: Admin-n-user-list/index
DEBUG - 2021-12-01 14:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 14:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 14:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:28:55 --> Total execution time: 0.0535
DEBUG - 2021-12-01 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:00:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:30:34 --> Total execution time: 0.0573
DEBUG - 2021-12-01 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:30:56 --> Total execution time: 0.0753
DEBUG - 2021-12-01 15:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:32:06 --> Total execution time: 0.0757
DEBUG - 2021-12-01 15:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:32:47 --> Total execution time: 0.0687
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:03:04 --> 404 Page Not Found: Assets/backend
DEBUG - 2021-12-01 15:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:33:47 --> Total execution time: 0.0760
DEBUG - 2021-12-01 15:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:04:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:34:03 --> Total execution time: 0.0696
DEBUG - 2021-12-01 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 19:34:05 --> Total execution time: 0.0509
DEBUG - 2021-12-01 15:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:03:21 --> Total execution time: 0.0741
DEBUG - 2021-12-01 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:33:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:03:29 --> Total execution time: 0.0546
DEBUG - 2021-12-01 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:03:31 --> Total execution time: 0.0524
DEBUG - 2021-12-01 15:33:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:03:45 --> Total execution time: 0.0558
DEBUG - 2021-12-01 15:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 15:33:49 --> 404 Page Not Found: Admin/normal_user/UserController/index
DEBUG - 2021-12-01 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:03:59 --> Total execution time: 0.0526
DEBUG - 2021-12-01 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 15:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 15:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-12-01 20:05:49 --> Total execution time: 0.0534
