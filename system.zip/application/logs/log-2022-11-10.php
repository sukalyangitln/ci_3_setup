<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-10 00:00:49 --> Total execution time: 0.1762
DEBUG - 2022-11-10 00:00:55 --> Total execution time: 0.1664
DEBUG - 2022-11-10 00:01:04 --> Total execution time: 0.1622
DEBUG - 2022-11-10 00:01:49 --> Total execution time: 0.1631
DEBUG - 2022-11-10 00:02:18 --> Total execution time: 0.1695
DEBUG - 2022-11-10 00:02:26 --> Total execution time: 0.1720
DEBUG - 2022-11-10 00:02:55 --> Total execution time: 0.1697
DEBUG - 2022-11-10 00:03:00 --> Total execution time: 0.4762
DEBUG - 2022-11-10 00:03:16 --> Total execution time: 0.2003
DEBUG - 2022-11-10 00:03:19 --> Total execution time: 0.1980
DEBUG - 2022-11-10 00:03:20 --> Total execution time: 0.2167
DEBUG - 2022-11-10 00:03:55 --> Total execution time: 0.2154
DEBUG - 2022-11-10 00:04:16 --> Total execution time: 0.1635
DEBUG - 2022-11-10 00:04:41 --> Total execution time: 0.1687
DEBUG - 2022-11-10 00:05:23 --> Total execution time: 0.4376
DEBUG - 2022-11-10 00:05:29 --> Total execution time: 0.2502
DEBUG - 2022-11-10 00:05:29 --> Total execution time: 0.1664
DEBUG - 2022-11-10 00:05:44 --> Total execution time: 0.1726
DEBUG - 2022-11-10 00:05:47 --> Total execution time: 0.1659
DEBUG - 2022-11-10 00:05:53 --> Total execution time: 0.1892
DEBUG - 2022-11-10 00:06:23 --> Total execution time: 0.1722
DEBUG - 2022-11-10 00:06:31 --> Total execution time: 0.1738
DEBUG - 2022-11-10 00:06:36 --> Total execution time: 0.1675
DEBUG - 2022-11-10 00:06:52 --> Total execution time: 0.1678
DEBUG - 2022-11-10 00:06:53 --> Total execution time: 0.1704
DEBUG - 2022-11-10 00:08:13 --> Total execution time: 0.1755
DEBUG - 2022-11-10 00:08:18 --> Total execution time: 0.1696
DEBUG - 2022-11-10 00:09:56 --> Total execution time: 0.1647
DEBUG - 2022-11-10 00:10:29 --> Total execution time: 0.1737
DEBUG - 2022-11-10 00:11:29 --> Total execution time: 0.1765
DEBUG - 2022-11-10 00:11:48 --> Total execution time: 0.1634
DEBUG - 2022-11-10 00:12:41 --> Total execution time: 0.1648
DEBUG - 2022-11-10 00:13:13 --> Total execution time: 0.1659
DEBUG - 2022-11-10 00:13:37 --> Total execution time: 0.1645
DEBUG - 2022-11-10 00:14:36 --> Total execution time: 0.1746
DEBUG - 2022-11-10 00:14:40 --> Total execution time: 0.1605
DEBUG - 2022-11-10 00:14:56 --> Total execution time: 0.1787
DEBUG - 2022-11-10 00:14:58 --> Total execution time: 0.4386
DEBUG - 2022-11-10 00:15:54 --> Total execution time: 0.1684
DEBUG - 2022-11-10 00:16:20 --> Total execution time: 0.1643
DEBUG - 2022-11-10 00:17:23 --> Total execution time: 0.1611
DEBUG - 2022-11-10 00:18:15 --> Total execution time: 0.1731
DEBUG - 2022-11-10 00:18:45 --> Total execution time: 0.1704
DEBUG - 2022-11-10 00:19:36 --> Total execution time: 0.1678
DEBUG - 2022-11-10 00:20:56 --> Total execution time: 0.1666
DEBUG - 2022-11-10 00:21:48 --> Total execution time: 0.1636
DEBUG - 2022-11-10 00:22:13 --> Total execution time: 0.1731
DEBUG - 2022-11-10 00:22:19 --> Total execution time: 0.1607
DEBUG - 2022-11-10 00:24:14 --> Total execution time: 0.1724
DEBUG - 2022-11-10 00:25:07 --> Total execution time: 0.1779
DEBUG - 2022-11-10 00:25:38 --> Total execution time: 0.1695
DEBUG - 2022-11-10 00:27:00 --> Total execution time: 0.1667
DEBUG - 2022-11-10 00:27:31 --> Total execution time: 0.1639
DEBUG - 2022-11-10 00:29:43 --> Total execution time: 0.2347
DEBUG - 2022-11-10 00:30:02 --> Total execution time: 0.3135
DEBUG - 2022-11-10 00:30:12 --> Total execution time: 0.1727
DEBUG - 2022-11-10 00:31:28 --> Total execution time: 0.1811
DEBUG - 2022-11-10 00:31:57 --> Total execution time: 0.4421
DEBUG - 2022-11-10 00:32:41 --> Total execution time: 0.1692
DEBUG - 2022-11-10 00:33:15 --> Total execution time: 0.1109
DEBUG - 2022-11-10 00:34:20 --> Total execution time: 0.1619
DEBUG - 2022-11-10 00:35:35 --> Total execution time: 0.1607
DEBUG - 2022-11-10 00:39:04 --> Total execution time: 0.2497
DEBUG - 2022-11-10 00:40:15 --> Total execution time: 2.2195
DEBUG - 2022-11-10 00:41:07 --> Total execution time: 0.4130
DEBUG - 2022-11-10 00:41:35 --> Total execution time: 0.4091
DEBUG - 2022-11-10 00:42:06 --> Total execution time: 0.3939
DEBUG - 2022-11-10 00:42:47 --> Total execution time: 0.1681
DEBUG - 2022-11-10 00:43:55 --> Total execution time: 0.1712
DEBUG - 2022-11-10 00:44:35 --> Total execution time: 0.1619
DEBUG - 2022-11-10 00:45:21 --> Total execution time: 0.1685
DEBUG - 2022-11-10 00:46:45 --> Total execution time: 0.2109
DEBUG - 2022-11-10 00:48:09 --> Total execution time: 0.1812
DEBUG - 2022-11-10 00:49:46 --> Total execution time: 0.1608
DEBUG - 2022-11-10 00:50:20 --> Total execution time: 0.1110
DEBUG - 2022-11-10 00:52:04 --> Total execution time: 0.1886
DEBUG - 2022-11-10 00:53:51 --> Total execution time: 3.4299
DEBUG - 2022-11-10 00:54:43 --> Total execution time: 2.3136
DEBUG - 2022-11-10 00:55:06 --> Total execution time: 0.7330
DEBUG - 2022-11-10 00:55:52 --> Total execution time: 0.4203
DEBUG - 2022-11-10 00:56:08 --> Total execution time: 0.1866
DEBUG - 2022-11-10 00:57:08 --> Total execution time: 0.1636
DEBUG - 2022-11-10 00:57:56 --> Total execution time: 0.1678
DEBUG - 2022-11-10 00:59:02 --> Total execution time: 0.2622
DEBUG - 2022-11-10 01:00:02 --> Total execution time: 0.1836
DEBUG - 2022-11-10 01:02:11 --> Total execution time: 0.2342
DEBUG - 2022-11-10 01:03:25 --> Total execution time: 0.1844
DEBUG - 2022-11-10 01:15:52 --> Total execution time: 0.9353
DEBUG - 2022-11-10 01:16:14 --> Total execution time: 0.1732
DEBUG - 2022-11-10 01:16:27 --> Total execution time: 0.1757
DEBUG - 2022-11-10 01:16:40 --> Total execution time: 0.1635
DEBUG - 2022-11-10 01:16:46 --> Total execution time: 0.1633
DEBUG - 2022-11-10 01:17:10 --> Total execution time: 0.1631
DEBUG - 2022-11-10 01:17:38 --> Total execution time: 0.1646
DEBUG - 2022-11-10 01:19:01 --> Total execution time: 0.1244
DEBUG - 2022-11-10 01:19:39 --> Total execution time: 0.1612
DEBUG - 2022-11-10 01:20:31 --> Total execution time: 0.1749
DEBUG - 2022-11-10 01:20:45 --> Total execution time: 0.1687
DEBUG - 2022-11-10 01:21:50 --> Total execution time: 0.1092
DEBUG - 2022-11-10 01:21:51 --> Total execution time: 0.1033
DEBUG - 2022-11-10 01:22:49 --> Total execution time: 0.1630
DEBUG - 2022-11-10 01:23:16 --> Total execution time: 0.1657
DEBUG - 2022-11-10 01:23:26 --> Total execution time: 0.1697
DEBUG - 2022-11-10 01:23:31 --> Total execution time: 0.4413
DEBUG - 2022-11-10 01:24:44 --> Total execution time: 0.1595
DEBUG - 2022-11-10 01:25:01 --> Total execution time: 0.2102
DEBUG - 2022-11-10 01:27:43 --> Total execution time: 0.2186
DEBUG - 2022-11-10 01:27:54 --> Total execution time: 0.1701
DEBUG - 2022-11-10 01:29:02 --> Total execution time: 0.4488
DEBUG - 2022-11-10 01:30:02 --> Total execution time: 0.2004
DEBUG - 2022-11-10 01:31:38 --> Total execution time: 0.1367
DEBUG - 2022-11-10 01:32:26 --> Total execution time: 0.1049
DEBUG - 2022-11-10 01:32:31 --> Total execution time: 0.1070
DEBUG - 2022-11-10 01:33:13 --> Total execution time: 0.1606
DEBUG - 2022-11-10 01:33:59 --> Total execution time: 0.1935
DEBUG - 2022-11-10 01:34:15 --> Total execution time: 0.2097
DEBUG - 2022-11-10 01:34:20 --> Total execution time: 0.1716
DEBUG - 2022-11-10 01:34:40 --> Total execution time: 0.1742
DEBUG - 2022-11-10 01:40:53 --> Total execution time: 0.1933
DEBUG - 2022-11-10 01:40:55 --> Total execution time: 0.1577
DEBUG - 2022-11-10 01:46:22 --> Total execution time: 0.2678
DEBUG - 2022-11-10 01:51:01 --> Total execution time: 0.1732
DEBUG - 2022-11-10 01:54:19 --> Total execution time: 0.2154
DEBUG - 2022-11-10 01:55:08 --> Total execution time: 0.1669
DEBUG - 2022-11-10 02:08:21 --> Total execution time: 0.8699
DEBUG - 2022-11-10 02:08:22 --> Total execution time: 0.1723
DEBUG - 2022-11-10 02:08:26 --> Total execution time: 0.1707
DEBUG - 2022-11-10 02:10:32 --> Total execution time: 0.1562
DEBUG - 2022-11-10 02:10:32 --> Total execution time: 0.1045
DEBUG - 2022-11-10 02:22:37 --> Total execution time: 0.4439
DEBUG - 2022-11-10 02:22:47 --> Total execution time: 0.1875
DEBUG - 2022-11-10 02:23:23 --> Total execution time: 0.2742
DEBUG - 2022-11-10 02:30:04 --> Total execution time: 0.6577
DEBUG - 2022-11-10 02:30:27 --> Total execution time: 0.1441
DEBUG - 2022-11-10 03:21:28 --> Total execution time: 0.5685
DEBUG - 2022-11-10 03:30:03 --> Total execution time: 1.3733
DEBUG - 2022-11-10 03:34:19 --> Total execution time: 0.1966
DEBUG - 2022-11-10 03:34:26 --> Total execution time: 0.1622
DEBUG - 2022-11-10 03:34:44 --> Total execution time: 0.1705
DEBUG - 2022-11-10 03:34:44 --> Total execution time: 0.1144
DEBUG - 2022-11-10 03:34:50 --> Total execution time: 0.1631
DEBUG - 2022-11-10 03:34:54 --> Total execution time: 0.1718
DEBUG - 2022-11-10 03:35:13 --> Total execution time: 0.1943
DEBUG - 2022-11-10 03:35:23 --> Total execution time: 0.1949
DEBUG - 2022-11-10 03:35:40 --> Total execution time: 0.1739
DEBUG - 2022-11-10 03:35:51 --> Total execution time: 0.1771
DEBUG - 2022-11-10 03:36:19 --> Total execution time: 0.1124
DEBUG - 2022-11-10 03:36:34 --> Total execution time: 0.1130
DEBUG - 2022-11-10 03:36:35 --> Total execution time: 0.1049
DEBUG - 2022-11-10 04:14:46 --> Total execution time: 0.9612
DEBUG - 2022-11-10 04:30:03 --> Total execution time: 0.7358
DEBUG - 2022-11-10 04:32:45 --> Total execution time: 0.6167
DEBUG - 2022-11-10 04:50:45 --> Total execution time: 0.6939
DEBUG - 2022-11-10 05:10:42 --> Total execution time: 0.4589
DEBUG - 2022-11-10 05:13:06 --> Total execution time: 0.1795
DEBUG - 2022-11-10 05:14:01 --> Total execution time: 0.1309
DEBUG - 2022-11-10 05:14:02 --> Total execution time: 0.1682
DEBUG - 2022-11-10 05:22:49 --> Total execution time: 0.1772
DEBUG - 2022-11-10 05:22:56 --> Total execution time: 0.1205
DEBUG - 2022-11-10 05:23:03 --> Total execution time: 0.1155
DEBUG - 2022-11-10 05:23:12 --> Total execution time: 0.0993
DEBUG - 2022-11-10 05:23:21 --> Total execution time: 0.1026
DEBUG - 2022-11-10 05:23:21 --> Total execution time: 0.2064
DEBUG - 2022-11-10 05:23:29 --> Total execution time: 0.2304
DEBUG - 2022-11-10 05:23:35 --> Total execution time: 0.1029
DEBUG - 2022-11-10 05:23:42 --> Total execution time: 0.1021
DEBUG - 2022-11-10 05:23:53 --> Total execution time: 0.1090
DEBUG - 2022-11-10 05:24:50 --> Total execution time: 0.1018
DEBUG - 2022-11-10 05:24:53 --> Total execution time: 0.1025
DEBUG - 2022-11-10 05:24:56 --> Total execution time: 0.1019
DEBUG - 2022-11-10 05:24:58 --> Total execution time: 0.1035
DEBUG - 2022-11-10 05:25:01 --> Total execution time: 0.1021
DEBUG - 2022-11-10 05:25:14 --> Total execution time: 0.2090
DEBUG - 2022-11-10 05:26:45 --> Total execution time: 0.1049
DEBUG - 2022-11-10 05:26:46 --> Total execution time: 0.1086
DEBUG - 2022-11-10 05:30:04 --> Total execution time: 0.6617
DEBUG - 2022-11-10 05:44:46 --> Total execution time: 0.6054
DEBUG - 2022-11-10 05:45:31 --> Total execution time: 0.5177
DEBUG - 2022-11-10 05:58:51 --> Total execution time: 0.5736
DEBUG - 2022-11-10 05:59:46 --> Total execution time: 0.1673
DEBUG - 2022-11-10 05:59:55 --> Total execution time: 0.1036
DEBUG - 2022-11-10 06:00:54 --> Total execution time: 0.1098
DEBUG - 2022-11-10 06:02:37 --> Total execution time: 0.5584
DEBUG - 2022-11-10 06:09:44 --> Total execution time: 0.5733
DEBUG - 2022-11-10 06:10:35 --> Total execution time: 0.1079
DEBUG - 2022-11-10 06:11:05 --> Total execution time: 0.1693
DEBUG - 2022-11-10 06:11:48 --> Total execution time: 0.1616
DEBUG - 2022-11-10 06:11:55 --> Total execution time: 0.1926
DEBUG - 2022-11-10 06:12:08 --> Total execution time: 0.1958
DEBUG - 2022-11-10 06:12:20 --> Total execution time: 0.1654
DEBUG - 2022-11-10 06:12:29 --> Total execution time: 0.1631
DEBUG - 2022-11-10 06:12:30 --> Total execution time: 0.1682
DEBUG - 2022-11-10 06:12:39 --> Total execution time: 0.1762
DEBUG - 2022-11-10 06:13:26 --> Total execution time: 0.3548
DEBUG - 2022-11-10 06:13:32 --> Total execution time: 0.1745
DEBUG - 2022-11-10 06:14:00 --> Total execution time: 0.1641
DEBUG - 2022-11-10 06:15:13 --> Total execution time: 0.1120
DEBUG - 2022-11-10 06:15:50 --> Total execution time: 0.4546
DEBUG - 2022-11-10 06:16:19 --> Total execution time: 0.1550
DEBUG - 2022-11-10 06:16:27 --> Total execution time: 0.1757
DEBUG - 2022-11-10 06:17:06 --> Total execution time: 0.1676
DEBUG - 2022-11-10 06:17:07 --> Total execution time: 0.1620
DEBUG - 2022-11-10 06:17:13 --> Total execution time: 0.1958
DEBUG - 2022-11-10 06:17:21 --> Total execution time: 0.2401
DEBUG - 2022-11-10 06:18:08 --> Total execution time: 0.1965
DEBUG - 2022-11-10 06:18:44 --> Total execution time: 0.1877
DEBUG - 2022-11-10 06:23:30 --> Total execution time: 0.9517
DEBUG - 2022-11-10 06:25:02 --> Total execution time: 0.1239
DEBUG - 2022-11-10 06:25:12 --> Total execution time: 0.1074
DEBUG - 2022-11-10 06:25:52 --> Total execution time: 0.1805
DEBUG - 2022-11-10 06:26:15 --> Total execution time: 0.2315
DEBUG - 2022-11-10 06:26:26 --> Total execution time: 0.1725
DEBUG - 2022-11-10 06:26:49 --> Total execution time: 0.2244
DEBUG - 2022-11-10 06:29:27 --> Total execution time: 0.1973
DEBUG - 2022-11-10 06:30:03 --> Total execution time: 0.1587
DEBUG - 2022-11-10 06:30:09 --> Total execution time: 0.4701
DEBUG - 2022-11-10 06:30:23 --> Total execution time: 0.1684
DEBUG - 2022-11-10 06:30:41 --> Total execution time: 0.1649
DEBUG - 2022-11-10 06:30:55 --> Total execution time: 0.1704
DEBUG - 2022-11-10 06:31:05 --> Total execution time: 0.1870
DEBUG - 2022-11-10 06:31:22 --> Total execution time: 0.1627
DEBUG - 2022-11-10 06:31:39 --> Total execution time: 0.1637
DEBUG - 2022-11-10 06:31:45 --> Total execution time: 0.1605
DEBUG - 2022-11-10 06:32:24 --> Total execution time: 0.1918
DEBUG - 2022-11-10 06:32:36 --> Total execution time: 0.2190
DEBUG - 2022-11-10 06:32:53 --> Total execution time: 0.1087
DEBUG - 2022-11-10 06:33:16 --> Total execution time: 0.1078
DEBUG - 2022-11-10 06:33:41 --> Total execution time: 0.1696
DEBUG - 2022-11-10 06:33:57 --> Total execution time: 0.2240
DEBUG - 2022-11-10 06:34:18 --> Total execution time: 0.2424
DEBUG - 2022-11-10 06:35:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 06:35:24 --> Total execution time: 0.1989
DEBUG - 2022-11-10 06:36:33 --> Total execution time: 0.1038
DEBUG - 2022-11-10 06:36:35 --> Total execution time: 0.1652
DEBUG - 2022-11-10 06:36:49 --> Total execution time: 0.4405
DEBUG - 2022-11-10 06:36:57 --> Total execution time: 0.1719
DEBUG - 2022-11-10 06:36:59 --> Total execution time: 0.1692
DEBUG - 2022-11-10 06:37:08 --> Total execution time: 0.2077
DEBUG - 2022-11-10 06:37:10 --> Total execution time: 0.1656
DEBUG - 2022-11-10 06:37:15 --> Total execution time: 0.1654
DEBUG - 2022-11-10 06:37:20 --> Total execution time: 0.1955
DEBUG - 2022-11-10 06:37:26 --> Total execution time: 0.2056
DEBUG - 2022-11-10 06:37:36 --> Total execution time: 0.1802
DEBUG - 2022-11-10 06:37:45 --> Total execution time: 0.1708
DEBUG - 2022-11-10 06:38:00 --> Total execution time: 0.1841
DEBUG - 2022-11-10 06:44:46 --> Total execution time: 0.1775
DEBUG - 2022-11-10 06:44:57 --> Total execution time: 0.1837
DEBUG - 2022-11-10 06:44:58 --> Total execution time: 0.4502
DEBUG - 2022-11-10 06:45:12 --> Total execution time: 0.4312
DEBUG - 2022-11-10 06:45:33 --> Total execution time: 0.1644
DEBUG - 2022-11-10 06:46:10 --> Total execution time: 0.1668
DEBUG - 2022-11-10 06:46:49 --> Total execution time: 0.1654
DEBUG - 2022-11-10 06:47:51 --> Total execution time: 0.0999
DEBUG - 2022-11-10 06:57:14 --> Total execution time: 0.1768
DEBUG - 2022-11-10 06:57:19 --> Total execution time: 0.1920
DEBUG - 2022-11-10 06:57:21 --> Total execution time: 0.1618
DEBUG - 2022-11-10 06:57:28 --> Total execution time: 0.2417
DEBUG - 2022-11-10 06:59:58 --> Total execution time: 0.1676
DEBUG - 2022-11-10 07:04:59 --> Total execution time: 0.9664
DEBUG - 2022-11-10 07:08:09 --> Total execution time: 0.5347
DEBUG - 2022-11-10 07:08:19 --> Total execution time: 0.1837
DEBUG - 2022-11-10 07:08:20 --> Total execution time: 0.1641
DEBUG - 2022-11-10 07:08:29 --> Total execution time: 0.2351
DEBUG - 2022-11-10 07:08:38 --> Total execution time: 0.1024
DEBUG - 2022-11-10 07:08:51 --> Total execution time: 0.4403
DEBUG - 2022-11-10 07:09:01 --> Total execution time: 0.2211
DEBUG - 2022-11-10 07:09:02 --> Total execution time: 0.1733
DEBUG - 2022-11-10 07:09:11 --> Total execution time: 0.1620
DEBUG - 2022-11-10 07:09:18 --> Total execution time: 0.1602
DEBUG - 2022-11-10 07:09:26 --> Total execution time: 0.1582
DEBUG - 2022-11-10 07:09:33 --> Total execution time: 0.1620
DEBUG - 2022-11-10 07:25:27 --> Total execution time: 0.1733
DEBUG - 2022-11-10 07:25:58 --> Total execution time: 0.2120
DEBUG - 2022-11-10 07:26:08 --> Total execution time: 0.1900
DEBUG - 2022-11-10 07:26:17 --> Total execution time: 0.1775
DEBUG - 2022-11-10 07:26:45 --> Total execution time: 0.1610
DEBUG - 2022-11-10 07:29:30 --> Total execution time: 0.1720
DEBUG - 2022-11-10 07:29:38 --> Total execution time: 0.1715
DEBUG - 2022-11-10 07:29:45 --> Total execution time: 0.1733
DEBUG - 2022-11-10 07:29:48 --> Total execution time: 0.1675
DEBUG - 2022-11-10 07:30:03 --> Total execution time: 0.1220
DEBUG - 2022-11-10 07:30:36 --> Total execution time: 0.5098
DEBUG - 2022-11-10 07:30:45 --> Total execution time: 0.1664
DEBUG - 2022-11-10 07:31:23 --> Total execution time: 0.1607
DEBUG - 2022-11-10 07:32:03 --> Total execution time: 0.1855
DEBUG - 2022-11-10 07:32:09 --> Total execution time: 0.2430
DEBUG - 2022-11-10 07:32:10 --> Total execution time: 0.3311
DEBUG - 2022-11-10 07:35:22 --> Total execution time: 0.6481
DEBUG - 2022-11-10 07:35:52 --> Total execution time: 0.7806
DEBUG - 2022-11-10 07:35:53 --> Total execution time: 0.1020
DEBUG - 2022-11-10 07:35:54 --> Total execution time: 0.2416
DEBUG - 2022-11-10 07:36:03 --> Total execution time: 0.1681
DEBUG - 2022-11-10 07:38:41 --> Total execution time: 0.1520
DEBUG - 2022-11-10 07:39:21 --> Total execution time: 0.1610
DEBUG - 2022-11-10 07:39:54 --> Total execution time: 0.1627
DEBUG - 2022-11-10 07:40:03 --> Total execution time: 0.1711
DEBUG - 2022-11-10 07:40:10 --> Total execution time: 0.1676
DEBUG - 2022-11-10 07:40:11 --> Total execution time: 0.1659
DEBUG - 2022-11-10 07:41:20 --> Total execution time: 0.1639
DEBUG - 2022-11-10 07:41:22 --> Total execution time: 0.1677
DEBUG - 2022-11-10 07:41:39 --> Total execution time: 0.4394
DEBUG - 2022-11-10 07:41:39 --> Total execution time: 0.1845
DEBUG - 2022-11-10 07:41:47 --> Total execution time: 0.1636
DEBUG - 2022-11-10 07:42:00 --> Total execution time: 0.2380
DEBUG - 2022-11-10 07:42:18 --> Total execution time: 0.1727
DEBUG - 2022-11-10 07:42:21 --> Total execution time: 0.1605
DEBUG - 2022-11-10 07:44:08 --> Total execution time: 0.1075
DEBUG - 2022-11-10 07:45:34 --> Total execution time: 0.1211
DEBUG - 2022-11-10 07:45:35 --> Total execution time: 0.1035
DEBUG - 2022-11-10 07:45:41 --> Total execution time: 0.1052
DEBUG - 2022-11-10 07:45:44 --> Total execution time: 0.1697
DEBUG - 2022-11-10 07:46:04 --> Total execution time: 0.1685
DEBUG - 2022-11-10 07:46:20 --> Total execution time: 0.1852
DEBUG - 2022-11-10 07:47:51 --> Total execution time: 0.1022
DEBUG - 2022-11-10 07:47:58 --> Total execution time: 0.1653
DEBUG - 2022-11-10 07:48:10 --> Total execution time: 0.1680
DEBUG - 2022-11-10 07:48:17 --> Total execution time: 0.1954
DEBUG - 2022-11-10 07:48:20 --> Total execution time: 0.2024
DEBUG - 2022-11-10 07:48:21 --> Total execution time: 0.1705
DEBUG - 2022-11-10 07:48:52 --> Total execution time: 0.1569
DEBUG - 2022-11-10 07:48:59 --> Total execution time: 0.1679
DEBUG - 2022-11-10 07:49:21 --> Total execution time: 0.2072
DEBUG - 2022-11-10 07:50:31 --> Total execution time: 0.1634
DEBUG - 2022-11-10 07:50:38 --> Total execution time: 0.1695
DEBUG - 2022-11-10 07:50:44 --> Total execution time: 0.1672
DEBUG - 2022-11-10 07:50:49 --> Total execution time: 0.1753
DEBUG - 2022-11-10 07:50:53 --> Total execution time: 0.1651
DEBUG - 2022-11-10 07:51:10 --> Total execution time: 0.2345
DEBUG - 2022-11-10 07:52:36 --> Total execution time: 0.1611
DEBUG - 2022-11-10 07:54:06 --> Total execution time: 0.1615
DEBUG - 2022-11-10 07:54:14 --> Total execution time: 0.2342
DEBUG - 2022-11-10 07:54:14 --> Total execution time: 0.4722
DEBUG - 2022-11-10 07:54:15 --> Total execution time: 0.7692
DEBUG - 2022-11-10 07:55:47 --> Total execution time: 0.4472
DEBUG - 2022-11-10 07:55:55 --> Total execution time: 0.4558
DEBUG - 2022-11-10 07:56:05 --> Total execution time: 0.1770
DEBUG - 2022-11-10 07:56:09 --> Total execution time: 0.1717
DEBUG - 2022-11-10 07:56:11 --> Total execution time: 0.1687
DEBUG - 2022-11-10 07:56:14 --> Total execution time: 0.1980
DEBUG - 2022-11-10 07:56:19 --> Total execution time: 0.2111
DEBUG - 2022-11-10 07:56:19 --> Total execution time: 0.1773
DEBUG - 2022-11-10 07:56:19 --> Total execution time: 0.5129
DEBUG - 2022-11-10 07:56:20 --> Total execution time: 0.6288
DEBUG - 2022-11-10 07:56:20 --> Total execution time: 0.4837
DEBUG - 2022-11-10 07:56:47 --> Total execution time: 0.1709
DEBUG - 2022-11-10 07:56:48 --> Total execution time: 0.1026
DEBUG - 2022-11-10 07:57:04 --> Total execution time: 0.1769
DEBUG - 2022-11-10 07:57:31 --> Total execution time: 0.1630
DEBUG - 2022-11-10 08:02:01 --> Total execution time: 0.5635
DEBUG - 2022-11-10 08:05:58 --> Total execution time: 1.0213
DEBUG - 2022-11-10 08:10:04 --> Total execution time: 0.1786
DEBUG - 2022-11-10 08:10:05 --> Total execution time: 0.1615
DEBUG - 2022-11-10 08:10:17 --> Total execution time: 0.1908
DEBUG - 2022-11-10 08:10:24 --> Total execution time: 0.2451
DEBUG - 2022-11-10 08:15:38 --> Total execution time: 0.4828
DEBUG - 2022-11-10 08:18:34 --> Total execution time: 0.8520
DEBUG - 2022-11-10 08:24:51 --> Total execution time: 0.8495
DEBUG - 2022-11-10 08:25:34 --> Total execution time: 0.4381
DEBUG - 2022-11-10 08:27:44 --> Total execution time: 0.1613
DEBUG - 2022-11-10 08:27:52 --> Total execution time: 0.1070
DEBUG - 2022-11-10 08:27:58 --> Total execution time: 0.1701
DEBUG - 2022-11-10 08:27:58 --> Total execution time: 0.1050
DEBUG - 2022-11-10 08:28:07 --> Total execution time: 0.1907
DEBUG - 2022-11-10 08:28:10 --> Total execution time: 0.1015
DEBUG - 2022-11-10 08:28:10 --> Total execution time: 0.1001
DEBUG - 2022-11-10 08:28:11 --> Total execution time: 0.1022
DEBUG - 2022-11-10 08:28:12 --> Total execution time: 0.1625
DEBUG - 2022-11-10 08:28:18 --> Total execution time: 0.2390
DEBUG - 2022-11-10 08:28:18 --> Total execution time: 0.2091
DEBUG - 2022-11-10 08:28:21 --> Total execution time: 0.1026
DEBUG - 2022-11-10 08:28:32 --> Total execution time: 0.1672
DEBUG - 2022-11-10 08:28:38 --> Total execution time: 0.1677
DEBUG - 2022-11-10 08:28:43 --> Total execution time: 0.1628
DEBUG - 2022-11-10 08:28:47 --> Total execution time: 0.1598
DEBUG - 2022-11-10 08:28:50 --> Total execution time: 0.1687
DEBUG - 2022-11-10 08:28:51 --> Total execution time: 0.1627
DEBUG - 2022-11-10 08:29:03 --> Total execution time: 0.1652
DEBUG - 2022-11-10 08:29:24 --> Total execution time: 0.1072
DEBUG - 2022-11-10 08:29:31 --> Total execution time: 0.1672
DEBUG - 2022-11-10 08:29:40 --> Total execution time: 0.1614
DEBUG - 2022-11-10 08:30:01 --> Total execution time: 0.3112
DEBUG - 2022-11-10 08:30:02 --> Total execution time: 0.1584
DEBUG - 2022-11-10 08:30:07 --> Total execution time: 0.1607
DEBUG - 2022-11-10 08:30:11 --> Total execution time: 0.1724
DEBUG - 2022-11-10 08:30:12 --> Total execution time: 0.1638
DEBUG - 2022-11-10 08:32:43 --> Total execution time: 0.5776
DEBUG - 2022-11-10 08:32:46 --> Total execution time: 0.1665
DEBUG - 2022-11-10 08:33:02 --> Total execution time: 0.1083
DEBUG - 2022-11-10 08:33:07 --> Total execution time: 0.1825
DEBUG - 2022-11-10 08:33:15 --> Total execution time: 0.1333
DEBUG - 2022-11-10 08:33:22 --> Total execution time: 0.1646
DEBUG - 2022-11-10 08:33:28 --> Total execution time: 0.2034
DEBUG - 2022-11-10 08:33:38 --> Total execution time: 0.2506
DEBUG - 2022-11-10 08:33:53 --> Total execution time: 0.1617
DEBUG - 2022-11-10 08:33:58 --> Total execution time: 0.1898
DEBUG - 2022-11-10 08:34:05 --> Total execution time: 0.1647
DEBUG - 2022-11-10 08:34:09 --> Total execution time: 0.1643
DEBUG - 2022-11-10 08:34:42 --> Total execution time: 0.2444
DEBUG - 2022-11-10 08:34:43 --> Total execution time: 0.1654
DEBUG - 2022-11-10 08:34:45 --> Total execution time: 0.1715
DEBUG - 2022-11-10 08:34:51 --> Total execution time: 0.1796
DEBUG - 2022-11-10 08:34:58 --> Total execution time: 0.1775
DEBUG - 2022-11-10 08:35:00 --> Total execution time: 0.1751
DEBUG - 2022-11-10 08:36:12 --> Total execution time: 0.1172
DEBUG - 2022-11-10 08:36:13 --> Total execution time: 0.0996
DEBUG - 2022-11-10 08:36:31 --> Total execution time: 0.1605
DEBUG - 2022-11-10 08:36:33 --> Total execution time: 0.2189
DEBUG - 2022-11-10 08:36:46 --> Total execution time: 0.1309
DEBUG - 2022-11-10 08:36:49 --> Total execution time: 0.1878
DEBUG - 2022-11-10 08:36:55 --> Total execution time: 0.1809
DEBUG - 2022-11-10 08:36:58 --> Total execution time: 0.1825
DEBUG - 2022-11-10 08:37:04 --> Total execution time: 0.1889
DEBUG - 2022-11-10 08:37:13 --> Total execution time: 0.1994
DEBUG - 2022-11-10 08:37:26 --> Total execution time: 0.1919
DEBUG - 2022-11-10 08:44:17 --> Total execution time: 0.8626
DEBUG - 2022-11-10 08:44:25 --> Total execution time: 0.1903
DEBUG - 2022-11-10 08:44:54 --> Total execution time: 0.2435
DEBUG - 2022-11-10 08:46:20 --> Total execution time: 0.1819
DEBUG - 2022-11-10 08:48:06 --> Total execution time: 0.1704
DEBUG - 2022-11-10 08:48:19 --> Total execution time: 0.2749
DEBUG - 2022-11-10 08:48:28 --> Total execution time: 0.3612
DEBUG - 2022-11-10 08:48:37 --> Total execution time: 0.2343
DEBUG - 2022-11-10 08:50:11 --> Total execution time: 0.2340
DEBUG - 2022-11-10 08:51:26 --> Total execution time: 0.1063
DEBUG - 2022-11-10 08:58:56 --> Total execution time: 0.5415
DEBUG - 2022-11-10 09:07:23 --> Total execution time: 0.1683
DEBUG - 2022-11-10 09:07:36 --> Total execution time: 0.1608
DEBUG - 2022-11-10 09:07:52 --> Total execution time: 0.1935
DEBUG - 2022-11-10 09:07:53 --> Total execution time: 0.1608
DEBUG - 2022-11-10 09:08:03 --> Total execution time: 0.2675
DEBUG - 2022-11-10 09:09:06 --> Total execution time: 0.1631
DEBUG - 2022-11-10 09:09:15 --> Total execution time: 0.1892
DEBUG - 2022-11-10 09:09:19 --> Total execution time: 0.1677
DEBUG - 2022-11-10 09:09:35 --> Total execution time: 0.1854
DEBUG - 2022-11-10 09:09:37 --> Total execution time: 0.1646
DEBUG - 2022-11-10 09:09:52 --> Total execution time: 0.2358
DEBUG - 2022-11-10 09:10:35 --> Total execution time: 0.1620
DEBUG - 2022-11-10 09:12:34 --> Total execution time: 0.1055
DEBUG - 2022-11-10 09:13:10 --> Total execution time: 0.4325
DEBUG - 2022-11-10 09:13:16 --> Total execution time: 0.1027
DEBUG - 2022-11-10 09:13:17 --> Total execution time: 0.1116
DEBUG - 2022-11-10 09:13:20 --> Total execution time: 0.1610
DEBUG - 2022-11-10 09:13:25 --> Total execution time: 0.4558
DEBUG - 2022-11-10 09:13:30 --> Total execution time: 0.1668
DEBUG - 2022-11-10 09:13:37 --> Total execution time: 0.2420
DEBUG - 2022-11-10 09:13:38 --> Total execution time: 0.2185
DEBUG - 2022-11-10 09:14:51 --> Total execution time: 0.4054
DEBUG - 2022-11-10 09:15:41 --> Total execution time: 0.1649
DEBUG - 2022-11-10 09:15:58 --> Total execution time: 0.1697
DEBUG - 2022-11-10 09:16:01 --> Total execution time: 0.2065
DEBUG - 2022-11-10 09:16:06 --> Total execution time: 0.1739
DEBUG - 2022-11-10 09:16:10 --> Total execution time: 0.1721
DEBUG - 2022-11-10 09:16:15 --> Total execution time: 0.1706
DEBUG - 2022-11-10 09:16:17 --> Total execution time: 0.1742
DEBUG - 2022-11-10 09:16:24 --> Total execution time: 0.1689
DEBUG - 2022-11-10 09:16:30 --> Total execution time: 0.1612
DEBUG - 2022-11-10 09:17:01 --> Total execution time: 0.5247
DEBUG - 2022-11-10 09:17:06 --> Total execution time: 0.1608
DEBUG - 2022-11-10 09:17:18 --> Total execution time: 0.1767
DEBUG - 2022-11-10 09:17:21 --> Total execution time: 0.1598
DEBUG - 2022-11-10 09:17:23 --> Total execution time: 0.1646
DEBUG - 2022-11-10 09:17:34 --> Total execution time: 0.1029
DEBUG - 2022-11-10 09:17:36 --> Total execution time: 0.1662
DEBUG - 2022-11-10 09:17:43 --> Total execution time: 0.2263
DEBUG - 2022-11-10 09:19:03 --> Total execution time: 0.1057
DEBUG - 2022-11-10 09:19:47 --> Total execution time: 0.1820
DEBUG - 2022-11-10 09:21:31 --> Total execution time: 0.1563
DEBUG - 2022-11-10 09:21:56 --> Total execution time: 2.3582
DEBUG - 2022-11-10 09:22:04 --> Total execution time: 0.1637
DEBUG - 2022-11-10 09:22:13 --> Total execution time: 0.1764
DEBUG - 2022-11-10 09:22:15 --> Total execution time: 0.0975
DEBUG - 2022-11-10 09:22:28 --> Total execution time: 0.1785
DEBUG - 2022-11-10 09:22:31 --> Total execution time: 0.3221
DEBUG - 2022-11-10 09:22:57 --> Total execution time: 0.2140
DEBUG - 2022-11-10 09:23:30 --> Total execution time: 0.4335
DEBUG - 2022-11-10 09:23:31 --> Total execution time: 0.1783
DEBUG - 2022-11-10 09:23:37 --> Total execution time: 0.1717
DEBUG - 2022-11-10 09:23:51 --> Total execution time: 0.1753
DEBUG - 2022-11-10 09:23:57 --> Total execution time: 0.1658
DEBUG - 2022-11-10 09:24:02 --> Total execution time: 0.4983
DEBUG - 2022-11-10 09:24:13 --> Total execution time: 0.2199
DEBUG - 2022-11-10 09:24:17 --> Total execution time: 0.4397
DEBUG - 2022-11-10 09:24:20 --> Total execution time: 0.4455
DEBUG - 2022-11-10 09:24:22 --> Total execution time: 0.4310
DEBUG - 2022-11-10 09:24:24 --> Total execution time: 0.1089
DEBUG - 2022-11-10 09:24:24 --> Total execution time: 0.1536
DEBUG - 2022-11-10 09:24:27 --> Total execution time: 0.2138
DEBUG - 2022-11-10 09:24:33 --> Total execution time: 0.1715
DEBUG - 2022-11-10 09:24:43 --> Total execution time: 0.1805
DEBUG - 2022-11-10 09:24:47 --> Total execution time: 0.2145
DEBUG - 2022-11-10 09:26:35 --> Total execution time: 0.1110
DEBUG - 2022-11-10 09:27:48 --> Total execution time: 0.1610
DEBUG - 2022-11-10 09:28:52 --> Total execution time: 0.1641
DEBUG - 2022-11-10 09:28:57 --> Total execution time: 0.1687
DEBUG - 2022-11-10 09:29:03 --> Total execution time: 0.1626
DEBUG - 2022-11-10 09:29:08 --> Total execution time: 0.1725
DEBUG - 2022-11-10 09:29:18 --> Total execution time: 0.2187
DEBUG - 2022-11-10 09:29:25 --> Total execution time: 0.4390
DEBUG - 2022-11-10 09:29:31 --> Total execution time: 0.1691
DEBUG - 2022-11-10 09:29:39 --> Total execution time: 0.1673
DEBUG - 2022-11-10 09:29:43 --> Total execution time: 0.1066
DEBUG - 2022-11-10 09:29:44 --> Total execution time: 0.1607
DEBUG - 2022-11-10 09:29:50 --> Total execution time: 0.1756
DEBUG - 2022-11-10 09:30:02 --> Total execution time: 0.1454
DEBUG - 2022-11-10 09:30:10 --> Total execution time: 0.4487
DEBUG - 2022-11-10 09:30:11 --> Total execution time: 0.1670
DEBUG - 2022-11-10 09:30:16 --> Total execution time: 0.1769
DEBUG - 2022-11-10 09:30:24 --> Total execution time: 0.1678
DEBUG - 2022-11-10 09:30:28 --> Total execution time: 0.2058
DEBUG - 2022-11-10 09:30:32 --> Total execution time: 0.1708
DEBUG - 2022-11-10 09:30:44 --> Total execution time: 0.1621
DEBUG - 2022-11-10 09:30:51 --> Total execution time: 0.1750
DEBUG - 2022-11-10 09:31:23 --> Total execution time: 0.1680
DEBUG - 2022-11-10 09:31:35 --> Total execution time: 0.3176
DEBUG - 2022-11-10 09:31:39 --> Total execution time: 0.4548
DEBUG - 2022-11-10 09:32:16 --> Total execution time: 0.4847
DEBUG - 2022-11-10 09:34:02 --> Total execution time: 0.2021
DEBUG - 2022-11-10 09:34:03 --> Total execution time: 0.1114
DEBUG - 2022-11-10 09:34:08 --> Total execution time: 0.1697
DEBUG - 2022-11-10 09:34:37 --> Total execution time: 0.1028
DEBUG - 2022-11-10 09:34:44 --> Total execution time: 0.1752
DEBUG - 2022-11-10 09:34:56 --> Total execution time: 0.1734
DEBUG - 2022-11-10 09:35:04 --> Total execution time: 0.1983
DEBUG - 2022-11-10 09:35:07 --> Total execution time: 0.2058
DEBUG - 2022-11-10 09:35:12 --> Total execution time: 0.1682
DEBUG - 2022-11-10 09:35:22 --> Total execution time: 0.1731
DEBUG - 2022-11-10 09:35:23 --> Total execution time: 0.1752
DEBUG - 2022-11-10 09:35:24 --> Total execution time: 0.1890
DEBUG - 2022-11-10 09:35:30 --> Total execution time: 0.1680
DEBUG - 2022-11-10 09:36:04 --> Total execution time: 0.1941
DEBUG - 2022-11-10 09:36:45 --> Total execution time: 0.1936
DEBUG - 2022-11-10 09:37:12 --> Total execution time: 0.1925
DEBUG - 2022-11-10 09:37:21 --> Total execution time: 0.2121
DEBUG - 2022-11-10 09:37:26 --> Total execution time: 0.1875
DEBUG - 2022-11-10 09:38:20 --> Total execution time: 0.2560
DEBUG - 2022-11-10 09:40:57 --> Total execution time: 0.1797
DEBUG - 2022-11-10 09:45:59 --> Total execution time: 0.5739
DEBUG - 2022-11-10 09:45:59 --> Total execution time: 0.1895
DEBUG - 2022-11-10 09:46:04 --> Total execution time: 0.1978
DEBUG - 2022-11-10 09:46:08 --> Total execution time: 0.1757
DEBUG - 2022-11-10 09:46:13 --> Total execution time: 0.2423
DEBUG - 2022-11-10 09:46:40 --> Total execution time: 0.1752
DEBUG - 2022-11-10 09:46:58 --> Total execution time: 0.4456
DEBUG - 2022-11-10 09:47:07 --> Total execution time: 0.2121
DEBUG - 2022-11-10 09:47:10 --> Total execution time: 0.1074
DEBUG - 2022-11-10 09:47:15 --> Total execution time: 0.2158
DEBUG - 2022-11-10 09:47:48 --> Total execution time: 0.2348
DEBUG - 2022-11-10 09:47:51 --> Total execution time: 0.1053
DEBUG - 2022-11-10 09:48:07 --> Total execution time: 0.2004
DEBUG - 2022-11-10 09:48:26 --> Total execution time: 0.1900
DEBUG - 2022-11-10 09:48:26 --> Total execution time: 0.1054
DEBUG - 2022-11-10 09:48:44 --> Total execution time: 0.1922
DEBUG - 2022-11-10 09:48:44 --> Total execution time: 0.1917
DEBUG - 2022-11-10 09:48:51 --> Total execution time: 0.2075
DEBUG - 2022-11-10 09:48:56 --> Total execution time: 0.2016
DEBUG - 2022-11-10 09:49:00 --> Total execution time: 0.1743
DEBUG - 2022-11-10 09:49:35 --> Total execution time: 0.1804
DEBUG - 2022-11-10 09:49:53 --> Total execution time: 0.2068
DEBUG - 2022-11-10 09:51:47 --> Total execution time: 0.1068
DEBUG - 2022-11-10 09:52:16 --> Total execution time: 0.1100
DEBUG - 2022-11-10 09:52:18 --> Total execution time: 0.1938
DEBUG - 2022-11-10 09:53:54 --> Total execution time: 0.9341
DEBUG - 2022-11-10 09:54:23 --> Total execution time: 0.1742
DEBUG - 2022-11-10 09:54:33 --> Total execution time: 0.1913
DEBUG - 2022-11-10 09:54:39 --> Total execution time: 0.1725
DEBUG - 2022-11-10 09:55:04 --> Total execution time: 0.2078
DEBUG - 2022-11-10 09:55:14 --> Total execution time: 0.2502
DEBUG - 2022-11-10 09:55:47 --> Total execution time: 0.4432
DEBUG - 2022-11-10 09:55:54 --> Total execution time: 0.1221
DEBUG - 2022-11-10 09:56:08 --> Total execution time: 0.1691
DEBUG - 2022-11-10 09:56:16 --> Total execution time: 0.1664
DEBUG - 2022-11-10 09:56:19 --> Total execution time: 0.1802
DEBUG - 2022-11-10 09:57:53 --> Total execution time: 0.5623
DEBUG - 2022-11-10 09:57:54 --> Total execution time: 0.1223
DEBUG - 2022-11-10 09:58:29 --> Total execution time: 0.2287
DEBUG - 2022-11-10 10:00:23 --> Total execution time: 2.2596
DEBUG - 2022-11-10 10:02:07 --> Total execution time: 2.3742
DEBUG - 2022-11-10 10:02:21 --> Total execution time: 0.7750
DEBUG - 2022-11-10 10:02:38 --> Total execution time: 1.1541
DEBUG - 2022-11-10 10:04:49 --> Total execution time: 0.7645
DEBUG - 2022-11-10 10:07:43 --> Total execution time: 0.7517
DEBUG - 2022-11-10 10:08:16 --> Total execution time: 0.2262
DEBUG - 2022-11-10 10:08:26 --> Total execution time: 0.2169
DEBUG - 2022-11-10 10:08:29 --> Total execution time: 0.2097
DEBUG - 2022-11-10 10:08:49 --> Total execution time: 0.1651
DEBUG - 2022-11-10 10:08:54 --> Total execution time: 0.1652
DEBUG - 2022-11-10 10:12:25 --> Total execution time: 0.1871
DEBUG - 2022-11-10 10:13:13 --> Total execution time: 0.1742
DEBUG - 2022-11-10 10:13:25 --> Total execution time: 0.2198
DEBUG - 2022-11-10 10:13:50 --> Total execution time: 0.1162
DEBUG - 2022-11-10 10:13:50 --> Total execution time: 0.1786
DEBUG - 2022-11-10 10:15:15 --> Total execution time: 1.6826
DEBUG - 2022-11-10 10:15:20 --> Total execution time: 0.1200
DEBUG - 2022-11-10 10:15:21 --> Total execution time: 0.1637
DEBUG - 2022-11-10 10:15:33 --> Total execution time: 0.6044
DEBUG - 2022-11-10 10:15:40 --> Total execution time: 0.4387
DEBUG - 2022-11-10 10:15:41 --> Total execution time: 0.1737
DEBUG - 2022-11-10 10:15:47 --> Total execution time: 0.1732
DEBUG - 2022-11-10 10:18:02 --> Total execution time: 1.2045
DEBUG - 2022-11-10 10:19:07 --> Total execution time: 0.6815
DEBUG - 2022-11-10 10:19:50 --> Total execution time: 0.2087
DEBUG - 2022-11-10 10:20:00 --> Total execution time: 0.1720
DEBUG - 2022-11-10 10:20:02 --> Total execution time: 0.2345
DEBUG - 2022-11-10 10:20:09 --> Total execution time: 0.1778
DEBUG - 2022-11-10 10:20:15 --> Total execution time: 0.1862
DEBUG - 2022-11-10 10:21:41 --> Total execution time: 0.1779
DEBUG - 2022-11-10 10:21:45 --> Total execution time: 0.1807
DEBUG - 2022-11-10 10:21:46 --> Total execution time: 0.1170
DEBUG - 2022-11-10 10:22:29 --> Total execution time: 0.4650
DEBUG - 2022-11-10 10:22:30 --> Total execution time: 0.1825
DEBUG - 2022-11-10 10:23:04 --> Total execution time: 0.1692
DEBUG - 2022-11-10 10:23:15 --> Total execution time: 0.1912
DEBUG - 2022-11-10 10:23:39 --> Total execution time: 0.2811
DEBUG - 2022-11-10 10:24:02 --> Total execution time: 0.1724
DEBUG - 2022-11-10 10:24:40 --> Total execution time: 0.1876
DEBUG - 2022-11-10 10:24:56 --> Total execution time: 0.1995
DEBUG - 2022-11-10 10:24:56 --> Total execution time: 2.0343
DEBUG - 2022-11-10 10:25:02 --> Total execution time: 0.1720
DEBUG - 2022-11-10 10:25:07 --> Total execution time: 0.1720
DEBUG - 2022-11-10 10:25:13 --> Total execution time: 0.1699
DEBUG - 2022-11-10 10:25:18 --> Total execution time: 0.1986
DEBUG - 2022-11-10 10:25:26 --> Total execution time: 0.1698
DEBUG - 2022-11-10 10:25:31 --> Total execution time: 0.2026
DEBUG - 2022-11-10 10:25:44 --> Total execution time: 0.2000
DEBUG - 2022-11-10 10:26:04 --> Total execution time: 0.1753
DEBUG - 2022-11-10 10:27:02 --> Total execution time: 0.2321
DEBUG - 2022-11-10 10:27:10 --> Total execution time: 0.1749
DEBUG - 2022-11-10 10:27:18 --> Total execution time: 0.1796
DEBUG - 2022-11-10 10:27:26 --> Total execution time: 0.1608
DEBUG - 2022-11-10 10:30:03 --> Total execution time: 0.3191
DEBUG - 2022-11-10 10:32:51 --> Total execution time: 0.1614
DEBUG - 2022-11-10 10:40:50 --> Total execution time: 0.6333
DEBUG - 2022-11-10 10:40:51 --> Total execution time: 0.1745
DEBUG - 2022-11-10 10:41:01 --> Total execution time: 0.2122
DEBUG - 2022-11-10 10:41:06 --> Total execution time: 0.1693
DEBUG - 2022-11-10 10:41:11 --> Total execution time: 0.1709
DEBUG - 2022-11-10 10:41:16 --> Total execution time: 0.1847
DEBUG - 2022-11-10 10:41:20 --> Total execution time: 0.1672
DEBUG - 2022-11-10 10:41:49 --> Total execution time: 0.1799
DEBUG - 2022-11-10 10:45:06 --> Total execution time: 0.1707
DEBUG - 2022-11-10 10:45:10 --> Total execution time: 0.1099
DEBUG - 2022-11-10 10:45:13 --> Total execution time: 0.4635
DEBUG - 2022-11-10 10:45:26 --> Total execution time: 0.1330
DEBUG - 2022-11-10 10:45:34 --> Total execution time: 0.1052
DEBUG - 2022-11-10 10:45:35 --> Total execution time: 0.1096
DEBUG - 2022-11-10 10:45:45 --> Total execution time: 0.1071
DEBUG - 2022-11-10 10:46:19 --> Total execution time: 0.1665
DEBUG - 2022-11-10 10:47:26 --> Total execution time: 0.1735
DEBUG - 2022-11-10 10:48:01 --> Total execution time: 0.1837
DEBUG - 2022-11-10 10:48:10 --> Total execution time: 0.1195
DEBUG - 2022-11-10 10:48:10 --> Total execution time: 0.4713
DEBUG - 2022-11-10 10:48:11 --> Total execution time: 0.1060
DEBUG - 2022-11-10 10:48:17 --> Total execution time: 0.1305
DEBUG - 2022-11-10 10:48:19 --> Total execution time: 0.1781
DEBUG - 2022-11-10 10:49:29 --> Total execution time: 0.6840
DEBUG - 2022-11-10 10:49:37 --> Total execution time: 0.2107
DEBUG - 2022-11-10 10:50:00 --> Total execution time: 0.1931
DEBUG - 2022-11-10 10:50:33 --> Total execution time: 0.2060
DEBUG - 2022-11-10 10:50:56 --> Total execution time: 0.1650
DEBUG - 2022-11-10 10:51:12 --> Total execution time: 0.1692
DEBUG - 2022-11-10 10:51:18 --> Total execution time: 0.2598
DEBUG - 2022-11-10 10:51:19 --> Total execution time: 0.1641
DEBUG - 2022-11-10 10:51:20 --> Total execution time: 0.1635
DEBUG - 2022-11-10 10:51:23 --> Total execution time: 0.1679
DEBUG - 2022-11-10 10:51:31 --> Total execution time: 0.1723
DEBUG - 2022-11-10 10:51:32 --> Total execution time: 0.1988
DEBUG - 2022-11-10 10:51:42 --> Total execution time: 0.4464
DEBUG - 2022-11-10 10:51:46 --> Total execution time: 0.1704
DEBUG - 2022-11-10 10:52:17 --> Total execution time: 0.1653
DEBUG - 2022-11-10 10:52:23 --> Total execution time: 0.1675
DEBUG - 2022-11-10 10:52:30 --> Total execution time: 0.1653
DEBUG - 2022-11-10 10:52:34 --> Total execution time: 0.1648
DEBUG - 2022-11-10 10:53:29 --> Total execution time: 0.1676
DEBUG - 2022-11-10 10:53:35 --> Total execution time: 0.1783
DEBUG - 2022-11-10 10:53:46 --> Total execution time: 0.1603
DEBUG - 2022-11-10 10:53:47 --> Total execution time: 0.1702
DEBUG - 2022-11-10 10:54:10 --> Total execution time: 0.1640
DEBUG - 2022-11-10 10:54:10 --> Total execution time: 0.2033
DEBUG - 2022-11-10 10:54:20 --> Total execution time: 0.1636
DEBUG - 2022-11-10 10:54:26 --> Total execution time: 0.1942
DEBUG - 2022-11-10 10:54:31 --> Total execution time: 0.1607
DEBUG - 2022-11-10 10:54:31 --> Total execution time: 0.1167
DEBUG - 2022-11-10 10:54:34 --> Total execution time: 0.1764
DEBUG - 2022-11-10 10:54:35 --> Total execution time: 0.1747
DEBUG - 2022-11-10 10:54:57 --> Total execution time: 0.1779
DEBUG - 2022-11-10 10:54:59 --> Total execution time: 0.1668
DEBUG - 2022-11-10 10:55:46 --> Total execution time: 0.2404
DEBUG - 2022-11-10 10:55:52 --> Total execution time: 0.2372
DEBUG - 2022-11-10 10:55:54 --> Total execution time: 0.3008
DEBUG - 2022-11-10 10:55:54 --> Total execution time: 0.2225
DEBUG - 2022-11-10 10:55:54 --> Total execution time: 0.2914
DEBUG - 2022-11-10 10:55:57 --> Total execution time: 0.1576
DEBUG - 2022-11-10 10:56:02 --> Total execution time: 0.1332
DEBUG - 2022-11-10 10:56:09 --> Total execution time: 0.2118
DEBUG - 2022-11-10 10:56:19 --> Total execution time: 0.1210
DEBUG - 2022-11-10 10:56:19 --> Total execution time: 0.1217
DEBUG - 2022-11-10 10:56:20 --> Total execution time: 0.2832
DEBUG - 2022-11-10 10:56:20 --> Total execution time: 0.1649
DEBUG - 2022-11-10 10:57:23 --> Total execution time: 0.7259
DEBUG - 2022-11-10 10:57:38 --> Total execution time: 1.5986
DEBUG - 2022-11-10 10:57:56 --> Total execution time: 0.2142
DEBUG - 2022-11-10 10:58:06 --> Total execution time: 0.1966
DEBUG - 2022-11-10 10:59:20 --> Total execution time: 0.4625
DEBUG - 2022-11-10 10:59:21 --> Total execution time: 0.1680
DEBUG - 2022-11-10 11:00:06 --> Total execution time: 0.1777
DEBUG - 2022-11-10 11:00:14 --> Total execution time: 0.1908
DEBUG - 2022-11-10 11:00:21 --> Total execution time: 0.1772
DEBUG - 2022-11-10 11:00:24 --> Total execution time: 0.1679
DEBUG - 2022-11-10 11:00:34 --> Total execution time: 0.1645
DEBUG - 2022-11-10 11:02:45 --> Total execution time: 2.4940
DEBUG - 2022-11-10 11:02:50 --> Total execution time: 0.2037
DEBUG - 2022-11-10 11:02:55 --> Total execution time: 0.1911
DEBUG - 2022-11-10 11:03:05 --> Total execution time: 0.1711
DEBUG - 2022-11-10 11:03:09 --> Total execution time: 0.1894
DEBUG - 2022-11-10 11:03:20 --> Total execution time: 0.1767
DEBUG - 2022-11-10 11:03:24 --> Total execution time: 0.1738
DEBUG - 2022-11-10 11:03:32 --> Total execution time: 0.1756
DEBUG - 2022-11-10 11:03:39 --> Total execution time: 0.2043
DEBUG - 2022-11-10 11:03:40 --> Total execution time: 0.1722
DEBUG - 2022-11-10 11:03:41 --> Total execution time: 0.1862
DEBUG - 2022-11-10 11:03:44 --> Total execution time: 0.1698
DEBUG - 2022-11-10 11:03:51 --> Total execution time: 0.1596
DEBUG - 2022-11-10 11:03:57 --> Total execution time: 0.1882
DEBUG - 2022-11-10 11:04:08 --> Total execution time: 0.1626
DEBUG - 2022-11-10 11:04:10 --> Total execution time: 0.1686
DEBUG - 2022-11-10 11:04:12 --> Total execution time: 0.1657
DEBUG - 2022-11-10 11:04:20 --> Total execution time: 0.1760
DEBUG - 2022-11-10 11:04:21 --> Total execution time: 0.1678
DEBUG - 2022-11-10 11:04:29 --> Total execution time: 0.1756
DEBUG - 2022-11-10 11:04:34 --> Total execution time: 0.1660
DEBUG - 2022-11-10 11:04:58 --> Total execution time: 0.1124
DEBUG - 2022-11-10 11:05:03 --> Total execution time: 0.1643
DEBUG - 2022-11-10 11:05:24 --> Total execution time: 0.1641
DEBUG - 2022-11-10 11:05:26 --> Total execution time: 0.1587
DEBUG - 2022-11-10 11:05:38 --> Total execution time: 0.1729
DEBUG - 2022-11-10 11:05:48 --> Total execution time: 0.4629
DEBUG - 2022-11-10 11:05:52 --> Total execution time: 0.1624
DEBUG - 2022-11-10 11:05:53 --> Total execution time: 0.1653
DEBUG - 2022-11-10 11:05:56 --> Total execution time: 0.1787
DEBUG - 2022-11-10 11:06:13 --> Total execution time: 0.1629
DEBUG - 2022-11-10 11:06:18 --> Total execution time: 0.1670
DEBUG - 2022-11-10 11:06:33 --> Total execution time: 0.2329
DEBUG - 2022-11-10 11:06:34 --> Total execution time: 0.1795
DEBUG - 2022-11-10 11:06:55 --> Total execution time: 0.1665
DEBUG - 2022-11-10 11:06:59 --> Total execution time: 0.1617
DEBUG - 2022-11-10 11:07:33 --> Total execution time: 0.1534
DEBUG - 2022-11-10 11:08:07 --> Total execution time: 0.1200
DEBUG - 2022-11-10 11:08:18 --> Total execution time: 0.2065
DEBUG - 2022-11-10 11:08:33 --> Total execution time: 0.1942
DEBUG - 2022-11-10 11:08:33 --> Total execution time: 0.1812
DEBUG - 2022-11-10 11:08:41 --> Total execution time: 0.1910
DEBUG - 2022-11-10 11:09:12 --> Total execution time: 0.1659
DEBUG - 2022-11-10 11:09:41 --> Total execution time: 0.1631
DEBUG - 2022-11-10 11:11:34 --> Total execution time: 0.1659
DEBUG - 2022-11-10 11:12:08 --> Total execution time: 0.1741
DEBUG - 2022-11-10 11:13:22 --> Total execution time: 0.6050
DEBUG - 2022-11-10 11:13:24 --> Total execution time: 0.1888
DEBUG - 2022-11-10 11:13:25 --> Total execution time: 0.1829
DEBUG - 2022-11-10 11:13:33 --> Total execution time: 0.2036
DEBUG - 2022-11-10 11:13:58 --> Total execution time: 0.1686
DEBUG - 2022-11-10 11:14:04 --> Total execution time: 0.1798
DEBUG - 2022-11-10 11:14:11 --> Total execution time: 0.1817
DEBUG - 2022-11-10 11:14:31 --> Total execution time: 0.1717
DEBUG - 2022-11-10 11:15:32 --> Total execution time: 0.1950
DEBUG - 2022-11-10 11:15:41 --> Total execution time: 0.1912
DEBUG - 2022-11-10 11:15:45 --> Total execution time: 0.2248
DEBUG - 2022-11-10 11:15:57 --> Total execution time: 0.1779
DEBUG - 2022-11-10 11:16:05 --> Total execution time: 0.1534
DEBUG - 2022-11-10 11:16:25 --> Total execution time: 0.1636
DEBUG - 2022-11-10 11:16:32 --> Total execution time: 0.1603
DEBUG - 2022-11-10 11:16:44 --> Total execution time: 0.1634
DEBUG - 2022-11-10 11:18:35 --> Total execution time: 0.1151
DEBUG - 2022-11-10 11:18:38 --> Total execution time: 0.1759
DEBUG - 2022-11-10 11:19:54 --> Total execution time: 0.5984
DEBUG - 2022-11-10 11:20:08 --> Total execution time: 0.2457
DEBUG - 2022-11-10 11:20:33 --> Total execution time: 2.2663
DEBUG - 2022-11-10 11:20:36 --> Total execution time: 0.2800
DEBUG - 2022-11-10 11:20:40 --> Total execution time: 0.3239
DEBUG - 2022-11-10 11:20:48 --> Total execution time: 0.1897
DEBUG - 2022-11-10 11:20:52 --> Total execution time: 0.8298
DEBUG - 2022-11-10 11:20:57 --> Total execution time: 0.1802
DEBUG - 2022-11-10 11:20:58 --> Total execution time: 0.2223
DEBUG - 2022-11-10 11:21:11 --> Total execution time: 0.1648
DEBUG - 2022-11-10 11:21:19 --> Total execution time: 0.1788
DEBUG - 2022-11-10 11:21:24 --> Total execution time: 0.2614
DEBUG - 2022-11-10 11:21:30 --> Total execution time: 0.1806
DEBUG - 2022-11-10 11:23:56 --> Total execution time: 0.1732
DEBUG - 2022-11-10 11:23:58 --> Total execution time: 0.1637
DEBUG - 2022-11-10 11:24:08 --> Total execution time: 0.2101
DEBUG - 2022-11-10 11:24:18 --> Total execution time: 0.3945
DEBUG - 2022-11-10 11:24:35 --> Total execution time: 0.1760
DEBUG - 2022-11-10 11:24:39 --> Total execution time: 0.2864
DEBUG - 2022-11-10 11:24:46 --> Total execution time: 0.1881
DEBUG - 2022-11-10 11:25:09 --> Total execution time: 0.4458
DEBUG - 2022-11-10 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:30:03 --> Total execution time: 0.8056
DEBUG - 2022-11-10 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:35:28 --> Total execution time: 0.7091
DEBUG - 2022-11-10 11:35:28 --> Total execution time: 0.7389
DEBUG - 2022-11-10 11:35:28 --> Total execution time: 0.7390
DEBUG - 2022-11-10 11:35:28 --> Total execution time: 0.5087
DEBUG - 2022-11-10 00:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:36:04 --> Total execution time: 0.1681
DEBUG - 2022-11-10 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:05 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:05 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:05 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:36:23 --> Total execution time: 0.1702
DEBUG - 2022-11-10 00:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:36:25 --> Total execution time: 0.1691
DEBUG - 2022-11-10 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:26 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:26 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 00:06:26 --> 404 Page Not Found: User/login
DEBUG - 2022-11-10 00:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:09:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:39:42 --> Total execution time: 0.8664
DEBUG - 2022-11-10 00:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:39:47 --> Total execution time: 0.1623
DEBUG - 2022-11-10 00:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:09 --> Total execution time: 0.1038
DEBUG - 2022-11-10 00:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:16 --> Total execution time: 0.2158
DEBUG - 2022-11-10 00:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:19 --> Total execution time: 0.4401
DEBUG - 2022-11-10 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:23 --> Total execution time: 0.2407
DEBUG - 2022-11-10 00:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:10:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:32 --> Total execution time: 0.1660
DEBUG - 2022-11-10 00:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:41:06 --> Total execution time: 0.1751
DEBUG - 2022-11-10 00:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:41:22 --> Total execution time: 0.1754
DEBUG - 2022-11-10 00:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:41:29 --> Total execution time: 0.1053
DEBUG - 2022-11-10 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:41:47 --> Total execution time: 0.1641
DEBUG - 2022-11-10 00:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:12:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:42:15 --> Total execution time: 0.1680
DEBUG - 2022-11-10 00:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:42:17 --> Total execution time: 0.1961
DEBUG - 2022-11-10 00:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:42:37 --> Total execution time: 0.2587
DEBUG - 2022-11-10 00:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:13:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:23 --> Total execution time: 0.2031
DEBUG - 2022-11-10 00:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:13:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:24 --> Total execution time: 0.1180
DEBUG - 2022-11-10 00:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:13:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:34 --> Total execution time: 0.1056
DEBUG - 2022-11-10 00:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:13:58 --> Total execution time: 0.1714
DEBUG - 2022-11-10 00:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:14:00 --> Total execution time: 0.2804
DEBUG - 2022-11-10 00:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:14:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:14:01 --> Total execution time: 0.1878
DEBUG - 2022-11-10 00:14:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:14:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:14:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:44:10 --> Total execution time: 0.1688
DEBUG - 2022-11-10 00:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:16:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:46:52 --> Total execution time: 0.2098
DEBUG - 2022-11-10 00:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:46:59 --> Total execution time: 0.1645
DEBUG - 2022-11-10 00:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:47:57 --> Total execution time: 0.7712
DEBUG - 2022-11-10 00:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:49:12 --> Total execution time: 0.5557
DEBUG - 2022-11-10 00:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:49:23 --> Total execution time: 0.2712
DEBUG - 2022-11-10 00:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:19:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:49:42 --> Total execution time: 0.2347
DEBUG - 2022-11-10 00:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:50:03 --> Total execution time: 0.2105
DEBUG - 2022-11-10 00:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:50:12 --> Total execution time: 0.3134
DEBUG - 2022-11-10 00:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:51:16 --> Total execution time: 0.1714
DEBUG - 2022-11-10 00:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:51:18 --> Total execution time: 0.1716
DEBUG - 2022-11-10 00:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:51:21 --> Total execution time: 0.1671
DEBUG - 2022-11-10 00:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:51:22 --> Total execution time: 0.1588
DEBUG - 2022-11-10 00:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:51:30 --> Total execution time: 0.1594
DEBUG - 2022-11-10 00:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:55:25 --> Total execution time: 0.5515
DEBUG - 2022-11-10 00:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:27:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:57:54 --> Total execution time: 0.8209
DEBUG - 2022-11-10 00:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:58:00 --> Total execution time: 0.1118
DEBUG - 2022-11-10 00:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:58:37 --> Total execution time: 0.2225
DEBUG - 2022-11-10 00:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:58:49 --> Total execution time: 0.2028
DEBUG - 2022-11-10 00:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:58:56 --> Total execution time: 0.1831
DEBUG - 2022-11-10 00:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:59:14 --> Total execution time: 0.1164
DEBUG - 2022-11-10 00:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:59:30 --> Total execution time: 0.1694
DEBUG - 2022-11-10 00:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:29:35 --> Total execution time: 0.1698
DEBUG - 2022-11-10 00:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:29:40 --> Total execution time: 0.2312
DEBUG - 2022-11-10 00:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:29:40 --> Total execution time: 0.2057
DEBUG - 2022-11-10 00:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:59:42 --> Total execution time: 0.1695
DEBUG - 2022-11-10 00:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:59:54 --> Total execution time: 0.1729
DEBUG - 2022-11-10 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:29:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:59:56 --> Total execution time: 0.1139
DEBUG - 2022-11-10 00:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:07 --> Total execution time: 0.1914
DEBUG - 2022-11-10 00:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:42 --> Total execution time: 0.1697
DEBUG - 2022-11-10 00:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:50 --> Total execution time: 0.1635
DEBUG - 2022-11-10 00:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:58 --> Total execution time: 0.1962
DEBUG - 2022-11-10 00:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:01:06 --> Total execution time: 0.2703
DEBUG - 2022-11-10 00:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:01:24 --> Total execution time: 0.2780
DEBUG - 2022-11-10 00:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:01:29 --> Total execution time: 0.1621
DEBUG - 2022-11-10 00:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:01:37 --> Total execution time: 0.1768
DEBUG - 2022-11-10 00:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:31:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:01:58 --> Total execution time: 0.4220
DEBUG - 2022-11-10 00:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:02 --> Total execution time: 0.5086
DEBUG - 2022-11-10 00:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:06 --> Total execution time: 0.2339
DEBUG - 2022-11-10 00:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:09 --> Total execution time: 0.1963
DEBUG - 2022-11-10 00:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:10 --> Total execution time: 0.5465
DEBUG - 2022-11-10 00:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:16 --> Total execution time: 0.1713
DEBUG - 2022-11-10 00:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:22 --> Total execution time: 0.4302
DEBUG - 2022-11-10 00:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:02:25 --> Total execution time: 0.1739
DEBUG - 2022-11-10 00:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:03:28 --> Total execution time: 2.4681
DEBUG - 2022-11-10 00:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:03:34 --> Total execution time: 1.0060
DEBUG - 2022-11-10 00:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:33:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:03:38 --> Total execution time: 0.1709
DEBUG - 2022-11-10 00:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:04:10 --> Total execution time: 0.1796
DEBUG - 2022-11-10 00:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:34:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:04:29 --> Total execution time: 0.1717
DEBUG - 2022-11-10 00:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:34:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:04:53 --> Total execution time: 0.1702
DEBUG - 2022-11-10 00:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:35:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:05:21 --> Total execution time: 0.1717
DEBUG - 2022-11-10 00:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:35:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:05:36 --> Total execution time: 0.1033
DEBUG - 2022-11-10 00:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:05:41 --> Total execution time: 0.1187
DEBUG - 2022-11-10 00:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:35:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:05:43 --> Total execution time: 0.1060
DEBUG - 2022-11-10 00:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:00 --> Total execution time: 0.2113
DEBUG - 2022-11-10 00:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:04 --> Total execution time: 0.1979
DEBUG - 2022-11-10 00:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:08 --> Total execution time: 0.1872
DEBUG - 2022-11-10 00:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:12 --> Total execution time: 0.2222
DEBUG - 2022-11-10 00:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:20 --> Total execution time: 0.1734
DEBUG - 2022-11-10 00:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:27 --> Total execution time: 0.1940
DEBUG - 2022-11-10 00:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:31 --> Total execution time: 0.1830
DEBUG - 2022-11-10 00:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:44 --> Total execution time: 0.1612
DEBUG - 2022-11-10 00:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:06:46 --> Total execution time: 0.1652
DEBUG - 2022-11-10 00:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:00 --> Total execution time: 0.5626
DEBUG - 2022-11-10 00:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:15 --> Total execution time: 0.1737
DEBUG - 2022-11-10 00:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:48 --> Total execution time: 0.1730
DEBUG - 2022-11-10 00:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:59 --> Total execution time: 0.1634
DEBUG - 2022-11-10 00:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:11:47 --> Total execution time: 3.3997
DEBUG - 2022-11-10 00:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:13:39 --> Total execution time: 2.2136
DEBUG - 2022-11-10 00:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:43:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:13:45 --> Total execution time: 0.1768
DEBUG - 2022-11-10 00:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:14:04 --> Total execution time: 0.1787
DEBUG - 2022-11-10 00:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:47:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:17:09 --> Total execution time: 0.5497
DEBUG - 2022-11-10 00:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:19:10 --> Total execution time: 0.9802
DEBUG - 2022-11-10 00:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:19:32 --> Total execution time: 0.1677
DEBUG - 2022-11-10 00:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:22:21 --> Total execution time: 0.2420
DEBUG - 2022-11-10 00:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:22:53 --> Total execution time: 0.5889
DEBUG - 2022-11-10 00:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:53:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:23:29 --> Total execution time: 0.9096
DEBUG - 2022-11-10 00:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:23:41 --> Total execution time: 0.1720
DEBUG - 2022-11-10 00:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:57:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:27:11 --> Total execution time: 0.6608
DEBUG - 2022-11-10 00:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:58:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:28:23 --> Total execution time: 0.1781
DEBUG - 2022-11-10 00:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 00:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:28:48 --> Total execution time: 0.1715
DEBUG - 2022-11-10 00:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:29:30 --> Total execution time: 0.1659
DEBUG - 2022-11-10 00:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:59:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 00:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:29:40 --> Total execution time: 0.1682
DEBUG - 2022-11-10 00:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 00:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 00:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:29:59 --> Total execution time: 0.1787
DEBUG - 2022-11-10 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:02 --> Total execution time: 0.1601
DEBUG - 2022-11-10 01:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:20 --> Total execution time: 0.6002
DEBUG - 2022-11-10 01:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:42 --> Total execution time: 0.4656
DEBUG - 2022-11-10 01:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:43 --> Total execution time: 0.2143
DEBUG - 2022-11-10 01:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:55 --> Total execution time: 0.2153
DEBUG - 2022-11-10 01:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:31:39 --> Total execution time: 0.1736
DEBUG - 2022-11-10 01:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:36:38 --> Total execution time: 0.6143
DEBUG - 2022-11-10 01:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:07:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:37:49 --> Total execution time: 0.9099
DEBUG - 2022-11-10 01:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:42:08 --> Total execution time: 0.6091
DEBUG - 2022-11-10 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 01:12:46 --> 404 Page Not Found: Allsitemapxml/index
DEBUG - 2022-11-10 01:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:43:31 --> Total execution time: 0.4506
DEBUG - 2022-11-10 01:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:14:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 01:14:59 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-10 01:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 01:15:15 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-10 01:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:17:05 --> Total execution time: 0.1946
DEBUG - 2022-11-10 01:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:47:10 --> Total execution time: 0.2066
DEBUG - 2022-11-10 01:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:47:11 --> Total execution time: 0.1595
DEBUG - 2022-11-10 01:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:47:38 --> Total execution time: 0.6533
DEBUG - 2022-11-10 01:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:17:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:47:54 --> Total execution time: 0.1192
DEBUG - 2022-11-10 01:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:18:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:48:07 --> Total execution time: 0.6161
DEBUG - 2022-11-10 01:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:18:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:18:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:48:45 --> Total execution time: 2.5958
DEBUG - 2022-11-10 01:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:49:16 --> Total execution time: 0.1983
DEBUG - 2022-11-10 01:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:19:21 --> Total execution time: 0.1720
DEBUG - 2022-11-10 01:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:19:21 --> Total execution time: 0.1681
DEBUG - 2022-11-10 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:19:24 --> Total execution time: 0.6055
DEBUG - 2022-11-10 01:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:19:24 --> Total execution time: 0.4199
DEBUG - 2022-11-10 01:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:52:38 --> Total execution time: 0.6165
DEBUG - 2022-11-10 01:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:52:53 --> Total execution time: 0.2125
DEBUG - 2022-11-10 01:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:55:56 --> Total execution time: 0.6648
DEBUG - 2022-11-10 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:55:57 --> Total execution time: 0.2045
DEBUG - 2022-11-10 01:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:56:22 --> Total execution time: 0.5508
DEBUG - 2022-11-10 01:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:56:24 --> Total execution time: 0.2298
DEBUG - 2022-11-10 01:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:56:28 --> Total execution time: 0.2112
DEBUG - 2022-11-10 01:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:56:35 --> Total execution time: 0.3720
DEBUG - 2022-11-10 01:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:56:54 --> Total execution time: 0.4589
DEBUG - 2022-11-10 01:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:57:07 --> Total execution time: 0.1642
DEBUG - 2022-11-10 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:59:19 --> Total execution time: 0.1631
DEBUG - 2022-11-10 01:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:59:25 --> Total execution time: 0.4583
DEBUG - 2022-11-10 01:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:30:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:30:38 --> Total execution time: 0.7422
DEBUG - 2022-11-10 01:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:30:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:30:49 --> Total execution time: 0.2466
DEBUG - 2022-11-10 01:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:01:38 --> Total execution time: 0.1125
DEBUG - 2022-11-10 01:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:31:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:01:53 --> Total execution time: 0.1882
DEBUG - 2022-11-10 01:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:02:05 --> Total execution time: 0.2182
DEBUG - 2022-11-10 01:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:02:40 --> Total execution time: 1.8439
DEBUG - 2022-11-10 01:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:03:28 --> Total execution time: 6.7476
DEBUG - 2022-11-10 01:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:03:43 --> Total execution time: 0.4800
DEBUG - 2022-11-10 01:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:50 --> Total execution time: 0.2614
DEBUG - 2022-11-10 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:51 --> Total execution time: 0.2447
DEBUG - 2022-11-10 01:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:52 --> Total execution time: 0.1707
DEBUG - 2022-11-10 01:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:56 --> Total execution time: 0.2145
DEBUG - 2022-11-10 01:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:32 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 01:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:34 --> Total execution time: 0.2475
DEBUG - 2022-11-10 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 01:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:45 --> Total execution time: 0.2601
DEBUG - 2022-11-10 01:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:59 --> Total execution time: 0.1803
DEBUG - 2022-11-10 01:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:36:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:06:15 --> Total execution time: 0.1381
DEBUG - 2022-11-10 01:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:37:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:07:14 --> Total execution time: 0.1126
DEBUG - 2022-11-10 01:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:08:29 --> Total execution time: 1.1862
DEBUG - 2022-11-10 01:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:08:31 --> Total execution time: 0.1718
DEBUG - 2022-11-10 01:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:08:32 --> Total execution time: 0.2361
DEBUG - 2022-11-10 01:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:09:58 --> Total execution time: 0.7052
DEBUG - 2022-11-10 01:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 01:40:51 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 01:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:40:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 01:40:58 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 01:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:41:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:11:08 --> Total execution time: 0.6969
DEBUG - 2022-11-10 01:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:43:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:13:14 --> Total execution time: 0.8651
DEBUG - 2022-11-10 01:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:13:21 --> Total execution time: 0.1652
DEBUG - 2022-11-10 01:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:13:47 --> Total execution time: 0.2577
DEBUG - 2022-11-10 01:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:13:58 --> Total execution time: 0.2560
DEBUG - 2022-11-10 01:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:16 --> Total execution time: 0.1907
DEBUG - 2022-11-10 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:26 --> Total execution time: 0.1892
DEBUG - 2022-11-10 01:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:38 --> Total execution time: 0.1654
DEBUG - 2022-11-10 01:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:42 --> Total execution time: 0.1845
DEBUG - 2022-11-10 01:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:53 --> Total execution time: 0.1177
DEBUG - 2022-11-10 01:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:44:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:14:55 --> Total execution time: 0.1052
DEBUG - 2022-11-10 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:15:01 --> Total execution time: 0.2267
DEBUG - 2022-11-10 01:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:15:08 --> Total execution time: 0.1813
DEBUG - 2022-11-10 01:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:15:13 --> Total execution time: 0.1851
DEBUG - 2022-11-10 01:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:15:59 --> Total execution time: 0.1854
DEBUG - 2022-11-10 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:16:04 --> Total execution time: 0.1726
DEBUG - 2022-11-10 01:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:16:13 --> Total execution time: 0.2179
DEBUG - 2022-11-10 01:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:16:42 --> Total execution time: 0.4534
DEBUG - 2022-11-10 01:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:47:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:17:04 --> Total execution time: 0.1762
DEBUG - 2022-11-10 01:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:18:10 --> Total execution time: 0.2129
DEBUG - 2022-11-10 01:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:18:23 --> Total execution time: 0.1846
DEBUG - 2022-11-10 01:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:18:30 --> Total execution time: 0.1823
DEBUG - 2022-11-10 01:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:18:38 --> Total execution time: 0.1640
DEBUG - 2022-11-10 01:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:19:04 --> Total execution time: 0.1685
DEBUG - 2022-11-10 01:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:19:26 --> Total execution time: 0.2026
DEBUG - 2022-11-10 01:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:21:26 --> Total execution time: 0.1643
DEBUG - 2022-11-10 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:21:32 --> Total execution time: 0.1759
DEBUG - 2022-11-10 01:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:51:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:21:34 --> Total execution time: 0.1359
DEBUG - 2022-11-10 01:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:21:42 --> Total execution time: 0.1090
DEBUG - 2022-11-10 01:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:21:52 --> Total execution time: 1.2014
DEBUG - 2022-11-10 01:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:22:02 --> Total execution time: 0.2096
DEBUG - 2022-11-10 01:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:22:18 --> Total execution time: 0.2295
DEBUG - 2022-11-10 01:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:22:30 --> Total execution time: 0.1734
DEBUG - 2022-11-10 01:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:52:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:22:31 --> Total execution time: 0.1665
DEBUG - 2022-11-10 01:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:04 --> Total execution time: 0.1051
DEBUG - 2022-11-10 01:53:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:04 --> Total execution time: 0.1012
DEBUG - 2022-11-10 01:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:08 --> Total execution time: 0.1801
DEBUG - 2022-11-10 01:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:16 --> Total execution time: 0.1676
DEBUG - 2022-11-10 01:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:19 --> Total execution time: 0.1863
DEBUG - 2022-11-10 01:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:26 --> Total execution time: 0.2222
DEBUG - 2022-11-10 01:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:52 --> Total execution time: 0.1750
DEBUG - 2022-11-10 01:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:55 --> Total execution time: 0.1780
DEBUG - 2022-11-10 01:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:56:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:26:42 --> Total execution time: 0.5529
DEBUG - 2022-11-10 01:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:56:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:26:53 --> Total execution time: 0.1111
DEBUG - 2022-11-10 01:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:06 --> Total execution time: 0.1138
DEBUG - 2022-11-10 01:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:07 --> Total execution time: 0.1011
DEBUG - 2022-11-10 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:18 --> Total execution time: 0.1781
DEBUG - 2022-11-10 01:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:25 --> Total execution time: 0.1662
DEBUG - 2022-11-10 01:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:33 --> Total execution time: 0.1618
DEBUG - 2022-11-10 01:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:58:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 01:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:28:21 --> Total execution time: 0.1049
DEBUG - 2022-11-10 01:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:28:26 --> Total execution time: 0.1144
DEBUG - 2022-11-10 01:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:06 --> Total execution time: 0.2227
DEBUG - 2022-11-10 01:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:11 --> Total execution time: 0.4559
DEBUG - 2022-11-10 01:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:18 --> Total execution time: 0.1682
DEBUG - 2022-11-10 01:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:23 --> Total execution time: 0.1889
DEBUG - 2022-11-10 01:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:31 --> Total execution time: 0.1110
DEBUG - 2022-11-10 01:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:31 --> Total execution time: 0.1691
DEBUG - 2022-11-10 01:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:31 --> Total execution time: 0.1970
DEBUG - 2022-11-10 01:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:36 --> Total execution time: 0.1755
DEBUG - 2022-11-10 01:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 01:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:39 --> Total execution time: 0.1794
DEBUG - 2022-11-10 01:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:45 --> Total execution time: 0.1629
DEBUG - 2022-11-10 01:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:49 --> Total execution time: 0.2064
DEBUG - 2022-11-10 01:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:50 --> Total execution time: 0.1978
DEBUG - 2022-11-10 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:58 --> Total execution time: 0.1811
DEBUG - 2022-11-10 01:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 01:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 01:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:29:58 --> Total execution time: 0.1705
DEBUG - 2022-11-10 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:02 --> Total execution time: 0.1539
DEBUG - 2022-11-10 02:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:07 --> Total execution time: 0.1712
DEBUG - 2022-11-10 02:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:08 --> Total execution time: 0.1846
DEBUG - 2022-11-10 02:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:13 --> Total execution time: 0.2330
DEBUG - 2022-11-10 02:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:18 --> Total execution time: 0.2176
DEBUG - 2022-11-10 02:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:21 --> Total execution time: 0.1846
DEBUG - 2022-11-10 02:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:26 --> Total execution time: 0.1917
DEBUG - 2022-11-10 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:43 --> Total execution time: 0.1648
DEBUG - 2022-11-10 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:30:45 --> Total execution time: 0.1686
DEBUG - 2022-11-10 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:00 --> Total execution time: 0.1766
DEBUG - 2022-11-10 02:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:02 --> Total execution time: 0.2046
DEBUG - 2022-11-10 02:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:03 --> Total execution time: 0.1890
DEBUG - 2022-11-10 02:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:12 --> Total execution time: 0.1681
DEBUG - 2022-11-10 02:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:13 --> Total execution time: 0.1836
DEBUG - 2022-11-10 02:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:25 --> Total execution time: 0.1685
DEBUG - 2022-11-10 02:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:34 --> Total execution time: 0.1699
DEBUG - 2022-11-10 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:38 --> Total execution time: 0.1709
DEBUG - 2022-11-10 02:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:42 --> Total execution time: 0.1668
DEBUG - 2022-11-10 02:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:31:47 --> Total execution time: 0.2041
DEBUG - 2022-11-10 02:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:32:21 --> Total execution time: 0.2024
DEBUG - 2022-11-10 02:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:02:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:32:30 --> Total execution time: 0.2566
DEBUG - 2022-11-10 02:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:33:31 --> Total execution time: 0.1097
DEBUG - 2022-11-10 02:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:03:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:33:57 --> Total execution time: 0.1650
DEBUG - 2022-11-10 02:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:33:59 --> Total execution time: 0.1613
DEBUG - 2022-11-10 02:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:31 --> Total execution time: 0.1222
DEBUG - 2022-11-10 02:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:50 --> Total execution time: 0.1977
DEBUG - 2022-11-10 02:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:04:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:04:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:51 --> Total execution time: 0.1699
DEBUG - 2022-11-10 02:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:04:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:52 --> Total execution time: 0.1666
DEBUG - 2022-11-10 02:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:53 --> Total execution time: 0.1641
DEBUG - 2022-11-10 02:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:35:32 --> Total execution time: 0.3347
DEBUG - 2022-11-10 02:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:06:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:36:29 --> Total execution time: 0.1981
DEBUG - 2022-11-10 02:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:06:41 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-10 02:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:06:42 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-11-10 02:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:37:28 --> Total execution time: 0.4710
DEBUG - 2022-11-10 02:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:37:38 --> Total execution time: 0.1611
DEBUG - 2022-11-10 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:13 --> Total execution time: 1.0455
DEBUG - 2022-11-10 02:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:16 --> Total execution time: 0.1096
DEBUG - 2022-11-10 02:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:18 --> Total execution time: 0.1033
DEBUG - 2022-11-10 02:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:18 --> Total execution time: 0.1181
DEBUG - 2022-11-10 02:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:29 --> Total execution time: 0.1975
DEBUG - 2022-11-10 02:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:44 --> Total execution time: 0.2001
DEBUG - 2022-11-10 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:46 --> Total execution time: 0.1084
DEBUG - 2022-11-10 02:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:40:59 --> Total execution time: 0.1899
DEBUG - 2022-11-10 02:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:41:47 --> Total execution time: 1.0901
DEBUG - 2022-11-10 02:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:42:05 --> Total execution time: 0.2661
DEBUG - 2022-11-10 02:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:42:07 --> Total execution time: 0.1215
DEBUG - 2022-11-10 02:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:02 --> Total execution time: 0.3520
DEBUG - 2022-11-10 02:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:20 --> Total execution time: 0.4504
DEBUG - 2022-11-10 02:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:24 --> Total execution time: 0.1772
DEBUG - 2022-11-10 02:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:28 --> Total execution time: 0.2099
DEBUG - 2022-11-10 02:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:31 --> Total execution time: 0.1027
DEBUG - 2022-11-10 02:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:31 --> Total execution time: 0.1708
DEBUG - 2022-11-10 02:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:39 --> Total execution time: 0.1842
DEBUG - 2022-11-10 02:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:41 --> Total execution time: 0.1370
DEBUG - 2022-11-10 02:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:47 --> Total execution time: 0.1693
DEBUG - 2022-11-10 02:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:43:57 --> Total execution time: 0.1993
DEBUG - 2022-11-10 02:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:44:04 --> Total execution time: 0.1890
DEBUG - 2022-11-10 02:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:44:06 --> Total execution time: 0.1047
DEBUG - 2022-11-10 02:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:44:09 --> Total execution time: 0.1933
DEBUG - 2022-11-10 02:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:44:12 --> Total execution time: 0.1012
DEBUG - 2022-11-10 02:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:16:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:46:41 --> Total execution time: 1.1127
DEBUG - 2022-11-10 02:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:46:48 --> Total execution time: 0.4408
DEBUG - 2022-11-10 02:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:47:05 --> Total execution time: 0.2188
DEBUG - 2022-11-10 02:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:48:20 --> Total execution time: 0.2050
DEBUG - 2022-11-10 02:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:48:44 --> Total execution time: 0.2627
DEBUG - 2022-11-10 02:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:49:19 --> Total execution time: 0.2033
DEBUG - 2022-11-10 02:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:19:25 --> Total execution time: 0.1815
DEBUG - 2022-11-10 02:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:19:43 --> Total execution time: 0.1689
DEBUG - 2022-11-10 02:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:50:12 --> Total execution time: 0.4650
DEBUG - 2022-11-10 02:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:20:23 --> Total execution time: 0.1877
DEBUG - 2022-11-10 02:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:50:44 --> Total execution time: 0.1968
DEBUG - 2022-11-10 02:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:50:58 --> Total execution time: 0.1626
DEBUG - 2022-11-10 02:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:51:05 --> Total execution time: 0.2760
DEBUG - 2022-11-10 02:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:52:54 --> Total execution time: 0.1753
DEBUG - 2022-11-10 02:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:52:58 --> Total execution time: 0.4586
DEBUG - 2022-11-10 02:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:53:03 --> Total execution time: 0.1758
DEBUG - 2022-11-10 02:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:53:56 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 02:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:23:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:53:57 --> Total execution time: 0.1877
DEBUG - 2022-11-10 02:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:54:34 --> Total execution time: 0.2139
DEBUG - 2022-11-10 02:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:54:43 --> Total execution time: 0.1650
DEBUG - 2022-11-10 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:54:46 --> Total execution time: 0.1659
DEBUG - 2022-11-10 02:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:54:54 --> Total execution time: 0.2433
DEBUG - 2022-11-10 02:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:54:59 --> Total execution time: 0.1953
DEBUG - 2022-11-10 02:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:05 --> Total execution time: 0.1618
DEBUG - 2022-11-10 02:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:10 --> Total execution time: 0.1609
DEBUG - 2022-11-10 02:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:20 --> Total execution time: 0.1615
DEBUG - 2022-11-10 02:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:26 --> Total execution time: 0.1852
DEBUG - 2022-11-10 02:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:34 --> Total execution time: 0.2641
DEBUG - 2022-11-10 02:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:42 --> Total execution time: 0.1763
DEBUG - 2022-11-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:53 --> Total execution time: 0.1652
DEBUG - 2022-11-10 02:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:53 --> Total execution time: 0.1681
DEBUG - 2022-11-10 02:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:55:57 --> Total execution time: 0.1610
DEBUG - 2022-11-10 02:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:00 --> Total execution time: 0.1770
DEBUG - 2022-11-10 02:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:56:03 --> Total execution time: 0.1594
DEBUG - 2022-11-10 02:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:06 --> Total execution time: 0.1675
DEBUG - 2022-11-10 02:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:07 --> Total execution time: 0.1988
DEBUG - 2022-11-10 02:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:56:10 --> Total execution time: 0.1752
DEBUG - 2022-11-10 02:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:13 --> Total execution time: 0.1724
DEBUG - 2022-11-10 02:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:16 --> Total execution time: 0.1679
DEBUG - 2022-11-10 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:19 --> Total execution time: 0.1759
DEBUG - 2022-11-10 02:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:19 --> Total execution time: 0.1674
DEBUG - 2022-11-10 02:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:26 --> Total execution time: 0.2265
DEBUG - 2022-11-10 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:29 --> Total execution time: 0.1631
DEBUG - 2022-11-10 02:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:35 --> Total execution time: 0.1743
DEBUG - 2022-11-10 02:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:39 --> Total execution time: 0.1773
DEBUG - 2022-11-10 02:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:26:41 --> Total execution time: 0.1770
DEBUG - 2022-11-10 02:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:56:43 --> Total execution time: 0.1722
DEBUG - 2022-11-10 02:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:56:53 --> Total execution time: 0.1788
DEBUG - 2022-11-10 02:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:56:54 --> Total execution time: 0.1682
DEBUG - 2022-11-10 02:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:57:07 --> Total execution time: 0.1700
DEBUG - 2022-11-10 02:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:57:17 --> Total execution time: 0.2140
DEBUG - 2022-11-10 02:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:28:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 02:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:58:24 --> Total execution time: 0.1108
DEBUG - 2022-11-10 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:58:31 --> Total execution time: 0.1646
DEBUG - 2022-11-10 02:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:58:51 --> Total execution time: 0.1706
DEBUG - 2022-11-10 02:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:58:58 --> Total execution time: 2.3297
DEBUG - 2022-11-10 02:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:29:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:10 --> Total execution time: 0.1687
DEBUG - 2022-11-10 02:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:14 --> Total execution time: 0.2146
DEBUG - 2022-11-10 02:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:43 --> Total execution time: 0.1798
DEBUG - 2022-11-10 02:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:52 --> Total execution time: 0.1866
DEBUG - 2022-11-10 02:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:58 --> Total execution time: 0.2194
DEBUG - 2022-11-10 02:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:59:59 --> Total execution time: 0.2146
DEBUG - 2022-11-10 02:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:00:22 --> Total execution time: 0.2020
DEBUG - 2022-11-10 02:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:00:30 --> Total execution time: 0.1944
DEBUG - 2022-11-10 02:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:30:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:00:57 --> Total execution time: 0.1075
DEBUG - 2022-11-10 02:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:01:11 --> Total execution time: 0.1723
DEBUG - 2022-11-10 02:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:31:22 --> Total execution time: 0.2059
DEBUG - 2022-11-10 02:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:01:37 --> Total execution time: 0.1796
DEBUG - 2022-11-10 02:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:01:49 --> Total execution time: 0.2079
DEBUG - 2022-11-10 02:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:02:40 --> Total execution time: 0.1763
DEBUG - 2022-11-10 02:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:02:47 --> Total execution time: 0.1727
DEBUG - 2022-11-10 02:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:02:55 --> Total execution time: 0.1966
DEBUG - 2022-11-10 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:03:17 --> Total execution time: 0.1628
DEBUG - 2022-11-10 02:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:35:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:05:46 --> Total execution time: 0.1971
DEBUG - 2022-11-10 02:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:37:42 --> Total execution time: 0.1701
DEBUG - 2022-11-10 02:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:38:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:38:03 --> Total execution time: 0.1738
DEBUG - 2022-11-10 02:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:38:07 --> Total execution time: 0.1656
DEBUG - 2022-11-10 02:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:08:31 --> Total execution time: 0.1925
DEBUG - 2022-11-10 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:08:55 --> Total execution time: 0.1143
DEBUG - 2022-11-10 02:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:09:44 --> Total execution time: 0.1773
DEBUG - 2022-11-10 02:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:40:12 --> Total execution time: 0.1737
DEBUG - 2022-11-10 02:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:40:13 --> Total execution time: 0.2112
DEBUG - 2022-11-10 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:42:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:12:57 --> Total execution time: 2.6266
DEBUG - 2022-11-10 02:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:12:57 --> Total execution time: 2.4206
DEBUG - 2022-11-10 02:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:43:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:13:20 --> Total execution time: 0.5548
DEBUG - 2022-11-10 02:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:43:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:13:23 --> Total execution time: 0.1053
DEBUG - 2022-11-10 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:13:32 --> Total execution time: 2.2398
DEBUG - 2022-11-10 02:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:43:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:13:49 --> Total execution time: 0.1721
DEBUG - 2022-11-10 02:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:14:16 --> Total execution time: 0.1844
DEBUG - 2022-11-10 02:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:44:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:14:41 --> Total execution time: 0.1793
DEBUG - 2022-11-10 02:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:45:00 --> Total execution time: 0.1916
DEBUG - 2022-11-10 02:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:45:04 --> Total execution time: 0.2751
DEBUG - 2022-11-10 02:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:45:04 --> Total execution time: 0.4625
DEBUG - 2022-11-10 02:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:16:28 --> Total execution time: 3.9541
DEBUG - 2022-11-10 02:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:46:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 02:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:16:59 --> Total execution time: 0.4397
DEBUG - 2022-11-10 02:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:17:26 --> Total execution time: 0.1958
DEBUG - 2022-11-10 02:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:17:29 --> Total execution time: 0.3626
DEBUG - 2022-11-10 02:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:17:56 --> Total execution time: 0.4862
DEBUG - 2022-11-10 02:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:18:03 --> Total execution time: 3.1698
DEBUG - 2022-11-10 02:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:18:07 --> Total execution time: 0.1674
DEBUG - 2022-11-10 02:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:18:47 --> Total execution time: 0.1635
DEBUG - 2022-11-10 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:18:53 --> Total execution time: 0.1030
DEBUG - 2022-11-10 02:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:12 --> Total execution time: 0.1812
DEBUG - 2022-11-10 02:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:26 --> Total execution time: 0.1798
DEBUG - 2022-11-10 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:26 --> Total execution time: 0.1534
DEBUG - 2022-11-10 02:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:40 --> Total execution time: 0.4426
DEBUG - 2022-11-10 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:48 --> Total execution time: 0.4897
DEBUG - 2022-11-10 02:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:50 --> Total execution time: 0.1668
DEBUG - 2022-11-10 02:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:01 --> Total execution time: 0.2021
DEBUG - 2022-11-10 02:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:06 --> Total execution time: 0.1809
DEBUG - 2022-11-10 02:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:08 --> Total execution time: 0.1808
DEBUG - 2022-11-10 02:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:17 --> Total execution time: 0.1639
DEBUG - 2022-11-10 02:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:23 --> Total execution time: 0.2312
DEBUG - 2022-11-10 02:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:30 --> Total execution time: 0.1741
DEBUG - 2022-11-10 02:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:35 --> Total execution time: 0.1791
DEBUG - 2022-11-10 02:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:58 --> Total execution time: 0.2091
DEBUG - 2022-11-10 02:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:01 --> Total execution time: 0.2668
DEBUG - 2022-11-10 02:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:41 --> Total execution time: 0.1103
DEBUG - 2022-11-10 02:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:42 --> Total execution time: 0.1304
DEBUG - 2022-11-10 02:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:51:42 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-11-10 02:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 02:51:46 --> 404 Page Not Found: Summer-course-starts-from-june/esalestrix.in
DEBUG - 2022-11-10 02:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:47 --> Total execution time: 0.4359
DEBUG - 2022-11-10 02:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:48 --> Total execution time: 0.2197
DEBUG - 2022-11-10 02:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:22:02 --> Total execution time: 0.2240
DEBUG - 2022-11-10 02:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:22:07 --> Total execution time: 0.1989
DEBUG - 2022-11-10 02:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 02:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:23:18 --> Total execution time: 0.1088
DEBUG - 2022-11-10 02:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:53:25 --> Total execution time: 0.1649
DEBUG - 2022-11-10 02:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:23:37 --> Total execution time: 0.1792
DEBUG - 2022-11-10 02:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 02:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:23:58 --> Total execution time: 0.1705
DEBUG - 2022-11-10 02:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:24:12 --> Total execution time: 0.1817
DEBUG - 2022-11-10 02:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:24:13 --> Total execution time: 0.1889
DEBUG - 2022-11-10 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:24:25 --> Total execution time: 0.1773
DEBUG - 2022-11-10 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:24:25 --> Total execution time: 0.1682
DEBUG - 2022-11-10 02:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:24:34 --> Total execution time: 0.1726
DEBUG - 2022-11-10 02:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:25:20 --> Total execution time: 0.4606
DEBUG - 2022-11-10 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:26:49 --> Total execution time: 0.1797
DEBUG - 2022-11-10 02:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:27:21 --> Total execution time: 0.1714
DEBUG - 2022-11-10 02:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:57:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:27:25 --> Total execution time: 0.1820
DEBUG - 2022-11-10 02:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:27:55 --> Total execution time: 0.1785
DEBUG - 2022-11-10 02:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:28:08 --> Total execution time: 0.1803
DEBUG - 2022-11-10 02:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 02:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 02:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:29:17 --> Total execution time: 0.4579
DEBUG - 2022-11-10 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:30:03 --> Total execution time: 0.1238
DEBUG - 2022-11-10 03:01:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:01:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:31:42 --> Total execution time: 0.5678
DEBUG - 2022-11-10 03:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:01 --> Total execution time: 0.2769
DEBUG - 2022-11-10 03:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:03 --> Total execution time: 0.1741
DEBUG - 2022-11-10 03:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:06 --> Total execution time: 0.2146
DEBUG - 2022-11-10 03:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:02:06 --> Total execution time: 0.4202
DEBUG - 2022-11-10 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:02:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:32:22 --> Total execution time: 0.1647
DEBUG - 2022-11-10 03:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:35:03 --> Total execution time: 0.2326
DEBUG - 2022-11-10 03:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:35:09 --> Total execution time: 0.2508
DEBUG - 2022-11-10 03:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:09 --> Total execution time: 0.1116
DEBUG - 2022-11-10 03:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:32 --> Total execution time: 0.1216
DEBUG - 2022-11-10 03:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:35 --> Total execution time: 0.3232
DEBUG - 2022-11-10 03:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:38 --> Total execution time: 0.1443
DEBUG - 2022-11-10 03:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:44 --> Total execution time: 0.1868
DEBUG - 2022-11-10 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:45 --> Total execution time: 0.1765
DEBUG - 2022-11-10 03:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:49 --> Total execution time: 0.1740
DEBUG - 2022-11-10 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:37:26 --> Total execution time: 0.1673
DEBUG - 2022-11-10 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:37:28 --> Total execution time: 0.4600
DEBUG - 2022-11-10 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:37:41 --> Total execution time: 0.1736
DEBUG - 2022-11-10 03:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:37:44 --> Total execution time: 0.2475
DEBUG - 2022-11-10 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:37:52 --> Total execution time: 0.2161
DEBUG - 2022-11-10 03:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:08:18 --> Total execution time: 0.1749
DEBUG - 2022-11-10 03:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:22 --> Total execution time: 0.2341
DEBUG - 2022-11-10 03:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:24 --> Total execution time: 0.1836
DEBUG - 2022-11-10 03:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:26 --> Total execution time: 0.1923
DEBUG - 2022-11-10 03:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:27 --> Total execution time: 0.2053
DEBUG - 2022-11-10 03:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:27 --> Total execution time: 0.3289
DEBUG - 2022-11-10 03:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:29 --> Total execution time: 0.1739
DEBUG - 2022-11-10 03:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:37 --> Total execution time: 0.1997
DEBUG - 2022-11-10 03:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:41 --> Total execution time: 0.2033
DEBUG - 2022-11-10 03:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:51 --> Total execution time: 0.1120
DEBUG - 2022-11-10 03:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:38:53 --> Total execution time: 0.2507
DEBUG - 2022-11-10 03:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:39:05 --> Total execution time: 0.1721
DEBUG - 2022-11-10 03:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:39:09 --> Total execution time: 0.2138
DEBUG - 2022-11-10 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:39:11 --> Total execution time: 0.5779
DEBUG - 2022-11-10 03:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:39:27 --> Total execution time: 0.2383
DEBUG - 2022-11-10 03:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:09:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:39:40 --> Total execution time: 0.1718
DEBUG - 2022-11-10 03:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:11:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:41:16 --> Total execution time: 0.1434
DEBUG - 2022-11-10 03:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:43:31 --> Total execution time: 0.4985
DEBUG - 2022-11-10 03:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:43:39 --> Total execution time: 0.1805
DEBUG - 2022-11-10 03:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:43:52 --> Total execution time: 0.1769
DEBUG - 2022-11-10 03:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:44:04 --> Total execution time: 0.1851
DEBUG - 2022-11-10 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:10 --> Total execution time: 0.4271
DEBUG - 2022-11-10 03:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:10 --> Total execution time: 0.6075
DEBUG - 2022-11-10 03:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:12 --> Total execution time: 0.1622
DEBUG - 2022-11-10 03:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:17 --> Total execution time: 0.1686
DEBUG - 2022-11-10 03:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:24 --> Total execution time: 0.1809
DEBUG - 2022-11-10 03:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:31 --> Total execution time: 0.1738
DEBUG - 2022-11-10 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:46:41 --> Total execution time: 0.1905
DEBUG - 2022-11-10 03:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:46:43 --> Total execution time: 0.1659
DEBUG - 2022-11-10 03:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:47:11 --> Total execution time: 0.8761
DEBUG - 2022-11-10 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:47:20 --> Total execution time: 0.2193
DEBUG - 2022-11-10 03:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:47:21 --> Total execution time: 0.2218
DEBUG - 2022-11-10 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:06 --> Total execution time: 0.2386
DEBUG - 2022-11-10 03:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:08 --> Total execution time: 0.1631
DEBUG - 2022-11-10 03:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:11 --> Total execution time: 0.1810
DEBUG - 2022-11-10 03:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:30 --> Total execution time: 0.1885
DEBUG - 2022-11-10 03:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:36 --> Total execution time: 0.1853
DEBUG - 2022-11-10 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:37 --> Total execution time: 0.1807
DEBUG - 2022-11-10 03:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:40 --> Total execution time: 0.1869
DEBUG - 2022-11-10 03:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:41 --> Total execution time: 0.1615
DEBUG - 2022-11-10 03:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:46 --> Total execution time: 0.1646
DEBUG - 2022-11-10 03:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:49:45 --> Total execution time: 0.1975
DEBUG - 2022-11-10 03:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:50:24 --> Total execution time: 0.2125
DEBUG - 2022-11-10 03:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:50:36 --> Total execution time: 0.1687
DEBUG - 2022-11-10 03:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:51:17 --> Total execution time: 0.4366
DEBUG - 2022-11-10 03:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:53:32 --> Total execution time: 0.1838
DEBUG - 2022-11-10 03:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:23:46 --> Total execution time: 0.1684
DEBUG - 2022-11-10 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:23:50 --> Total execution time: 0.2206
DEBUG - 2022-11-10 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:23:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:23:50 --> Total execution time: 0.1728
DEBUG - 2022-11-10 03:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:55:24 --> Total execution time: 0.1079
DEBUG - 2022-11-10 03:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:55:51 --> Total execution time: 0.4773
DEBUG - 2022-11-10 03:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:55:51 --> Total execution time: 0.1895
DEBUG - 2022-11-10 03:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:55:52 --> Total execution time: 0.1713
DEBUG - 2022-11-10 03:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:55:53 --> Total execution time: 0.2389
DEBUG - 2022-11-10 03:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:56:05 --> Total execution time: 0.1699
DEBUG - 2022-11-10 03:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:56:08 --> Total execution time: 0.1685
DEBUG - 2022-11-10 03:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:56:15 --> Total execution time: 0.1682
DEBUG - 2022-11-10 03:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:56:19 --> Total execution time: 0.1701
DEBUG - 2022-11-10 03:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:56:29 --> Total execution time: 0.2183
DEBUG - 2022-11-10 03:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:02 --> Total execution time: 0.4839
DEBUG - 2022-11-10 03:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:16 --> Total execution time: 0.1890
DEBUG - 2022-11-10 03:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:17 --> Total execution time: 0.3627
DEBUG - 2022-11-10 03:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:27 --> Total execution time: 0.1715
DEBUG - 2022-11-10 03:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:37 --> Total execution time: 0.1767
DEBUG - 2022-11-10 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:57:44 --> Total execution time: 0.2566
DEBUG - 2022-11-10 03:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:59:55 --> Total execution time: 0.2470
DEBUG - 2022-11-10 03:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:31:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:01:11 --> Total execution time: 0.1933
DEBUG - 2022-11-10 03:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:03:10 --> Total execution time: 0.2941
DEBUG - 2022-11-10 03:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:03:49 --> Total execution time: 0.1115
DEBUG - 2022-11-10 03:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 03:33:50 --> 404 Page Not Found: Apple-touch-icon-120x120-precomposedpng/index
DEBUG - 2022-11-10 03:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 03:33:51 --> 404 Page Not Found: Apple-touch-icon-120x120png/index
DEBUG - 2022-11-10 03:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:03:51 --> Total execution time: 0.5165
DEBUG - 2022-11-10 03:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:33:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:03:51 --> Total execution time: 0.1068
DEBUG - 2022-11-10 03:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 03:33:52 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
DEBUG - 2022-11-10 03:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 03:33:52 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-11-10 03:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:03:55 --> Total execution time: 0.2055
DEBUG - 2022-11-10 03:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:04:04 --> Total execution time: 0.1622
DEBUG - 2022-11-10 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:04:17 --> Total execution time: 0.4653
DEBUG - 2022-11-10 03:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:04:20 --> Total execution time: 0.1756
DEBUG - 2022-11-10 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:04:25 --> Total execution time: 0.1691
DEBUG - 2022-11-10 03:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:04:35 --> Total execution time: 0.1773
DEBUG - 2022-11-10 03:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:05:00 --> Total execution time: 0.1721
DEBUG - 2022-11-10 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:05:04 --> Total execution time: 0.1782
DEBUG - 2022-11-10 03:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:06:35 --> Total execution time: 0.1065
DEBUG - 2022-11-10 03:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:07:13 --> Total execution time: 0.1015
DEBUG - 2022-11-10 03:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:07:16 --> Total execution time: 0.1876
DEBUG - 2022-11-10 03:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:07:30 --> Total execution time: 0.1618
DEBUG - 2022-11-10 03:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:08:21 --> Total execution time: 0.1772
DEBUG - 2022-11-10 03:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:41:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:11:52 --> Total execution time: 0.6100
DEBUG - 2022-11-10 03:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:42:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:12:07 --> Total execution time: 0.1773
DEBUG - 2022-11-10 03:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:43:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:43:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:13:15 --> Total execution time: 0.1131
DEBUG - 2022-11-10 03:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:13:22 --> Total execution time: 0.1061
DEBUG - 2022-11-10 03:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:13:52 --> Total execution time: 0.2124
DEBUG - 2022-11-10 03:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:14:44 --> Total execution time: 0.2799
DEBUG - 2022-11-10 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:47:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:17:03 --> Total execution time: 0.1657
DEBUG - 2022-11-10 03:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:48:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:18:48 --> Total execution time: 0.2765
DEBUG - 2022-11-10 03:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:18:56 --> Total execution time: 0.1004
DEBUG - 2022-11-10 03:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:19:21 --> Total execution time: 0.2066
DEBUG - 2022-11-10 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:19:54 --> Total execution time: 0.1652
DEBUG - 2022-11-10 03:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:04 --> Total execution time: 0.1771
DEBUG - 2022-11-10 03:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:16 --> Total execution time: 0.1615
DEBUG - 2022-11-10 03:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:17 --> Total execution time: 0.1743
DEBUG - 2022-11-10 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:17 --> Total execution time: 0.1681
DEBUG - 2022-11-10 03:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:21 --> Total execution time: 0.1671
DEBUG - 2022-11-10 03:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:25 --> Total execution time: 0.1572
DEBUG - 2022-11-10 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 03:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:47 --> Total execution time: 0.1838
DEBUG - 2022-11-10 03:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 03:51:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 03:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:54:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:24:18 --> Total execution time: 2.6311
DEBUG - 2022-11-10 03:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:56:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:26:28 --> Total execution time: 0.4453
DEBUG - 2022-11-10 03:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:56:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:56:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:26:42 --> Total execution time: 0.1679
DEBUG - 2022-11-10 03:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:57:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:27:16 --> Total execution time: 0.1682
DEBUG - 2022-11-10 03:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 03:58:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 03:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:28:45 --> Total execution time: 0.9265
DEBUG - 2022-11-10 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:02:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:32:03 --> Total execution time: 1.0054
DEBUG - 2022-11-10 04:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:03:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:33:17 --> Total execution time: 1.0099
DEBUG - 2022-11-10 04:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:03:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:33:40 --> Total execution time: 0.1118
DEBUG - 2022-11-10 04:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:03:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:33:54 --> Total execution time: 0.1260
DEBUG - 2022-11-10 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:05:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:35:16 --> Total execution time: 0.2781
DEBUG - 2022-11-10 04:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:06:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:36:29 --> Total execution time: 0.2396
DEBUG - 2022-11-10 04:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:07:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:37:16 --> Total execution time: 0.1980
DEBUG - 2022-11-10 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:07:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:07:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:37:44 --> Total execution time: 0.2844
DEBUG - 2022-11-10 04:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:37:44 --> Total execution time: 0.1964
DEBUG - 2022-11-10 04:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:07:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:37:49 --> Total execution time: 0.1853
DEBUG - 2022-11-10 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:08:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:38:39 --> Total execution time: 1.0513
DEBUG - 2022-11-10 04:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:08:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:38:49 --> Total execution time: 0.4542
DEBUG - 2022-11-10 04:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:14:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:44:04 --> Total execution time: 0.8935
DEBUG - 2022-11-10 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:14:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:44:25 --> Total execution time: 0.1283
DEBUG - 2022-11-10 04:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:26:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:56:08 --> Total execution time: 0.5605
DEBUG - 2022-11-10 04:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:30:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:00:06 --> Total execution time: 0.6592
DEBUG - 2022-11-10 04:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:30:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:00:20 --> Total execution time: 0.1091
DEBUG - 2022-11-10 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:30:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:00:59 --> Total execution time: 0.1749
DEBUG - 2022-11-10 04:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:36:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:06:21 --> Total execution time: 0.5291
DEBUG - 2022-11-10 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:38:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:08:51 --> Total execution time: 0.5716
DEBUG - 2022-11-10 04:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:41:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:11:36 --> Total execution time: 0.6644
DEBUG - 2022-11-10 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:43:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:13:49 --> Total execution time: 0.5988
DEBUG - 2022-11-10 04:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:44:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:14:43 --> Total execution time: 0.1378
DEBUG - 2022-11-10 04:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:44:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:14:48 --> Total execution time: 0.1124
DEBUG - 2022-11-10 04:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:44:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:14:56 --> Total execution time: 0.1696
DEBUG - 2022-11-10 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:45:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:15:27 --> Total execution time: 0.1913
DEBUG - 2022-11-10 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:45:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:15:47 --> Total execution time: 0.2380
DEBUG - 2022-11-10 04:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:45:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:15:58 --> Total execution time: 0.1920
DEBUG - 2022-11-10 04:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:49:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:19:11 --> Total execution time: 0.1867
DEBUG - 2022-11-10 04:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 04:54:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 04:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 04:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:24:49 --> Total execution time: 4.3308
DEBUG - 2022-11-10 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:04:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:34:12 --> Total execution time: 0.7470
DEBUG - 2022-11-10 05:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:05:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:35:16 --> Total execution time: 0.1328
DEBUG - 2022-11-10 05:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:05:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:35:18 --> Total execution time: 0.1244
DEBUG - 2022-11-10 05:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:05:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:35:19 --> Total execution time: 0.1632
DEBUG - 2022-11-10 05:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:10:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:40:13 --> Total execution time: 0.1584
DEBUG - 2022-11-10 05:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:13:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:43:49 --> Total execution time: 1.0585
DEBUG - 2022-11-10 05:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:13:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:43:57 --> Total execution time: 0.1259
DEBUG - 2022-11-10 05:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:14:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:44:19 --> Total execution time: 0.1752
DEBUG - 2022-11-10 05:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:14:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:14:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:44:46 --> Total execution time: 0.1867
DEBUG - 2022-11-10 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:15:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:45:48 --> Total execution time: 0.1132
DEBUG - 2022-11-10 05:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:16:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:46:04 --> Total execution time: 0.1482
DEBUG - 2022-11-10 05:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:16:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:46:18 --> Total execution time: 0.1085
DEBUG - 2022-11-10 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:16:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:46:19 --> Total execution time: 0.1791
DEBUG - 2022-11-10 05:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:18:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:18:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:48:03 --> Total execution time: 0.1383
DEBUG - 2022-11-10 05:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:18:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:48:33 --> Total execution time: 0.1232
DEBUG - 2022-11-10 05:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:18:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:48:41 --> Total execution time: 0.1922
DEBUG - 2022-11-10 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:18:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:48:53 --> Total execution time: 0.1109
DEBUG - 2022-11-10 05:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:19:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:49:21 --> Total execution time: 0.1679
DEBUG - 2022-11-10 05:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:19:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:49:47 --> Total execution time: 0.1678
DEBUG - 2022-11-10 05:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:19:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:49:56 --> Total execution time: 0.1371
DEBUG - 2022-11-10 05:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:20:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:50:53 --> Total execution time: 0.1679
DEBUG - 2022-11-10 05:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:20:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:50:59 --> Total execution time: 0.1659
DEBUG - 2022-11-10 05:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:21:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:51:02 --> Total execution time: 0.1978
DEBUG - 2022-11-10 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:21:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:51:14 --> Total execution time: 0.1087
DEBUG - 2022-11-10 05:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:22:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:22:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:52:16 --> Total execution time: 0.1690
DEBUG - 2022-11-10 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:22:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:52:41 --> Total execution time: 0.1745
DEBUG - 2022-11-10 05:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:22:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:52:59 --> Total execution time: 0.4496
DEBUG - 2022-11-10 05:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:23:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:53:05 --> Total execution time: 0.1775
DEBUG - 2022-11-10 05:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:23:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:53:32 --> Total execution time: 0.1754
DEBUG - 2022-11-10 05:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:23:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:53:36 --> Total execution time: 0.2760
DEBUG - 2022-11-10 05:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:23:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:53:58 --> Total execution time: 0.4518
DEBUG - 2022-11-10 05:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:25:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:55:19 --> Total execution time: 0.1781
DEBUG - 2022-11-10 05:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:25:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:55:29 --> Total execution time: 0.1972
DEBUG - 2022-11-10 05:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:28:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:58:30 --> Total execution time: 0.2197
DEBUG - 2022-11-10 05:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:28:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:58:32 --> Total execution time: 0.4643
DEBUG - 2022-11-10 05:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:29:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:59:55 --> Total execution time: 0.5920
DEBUG - 2022-11-10 05:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:30:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:00:55 --> Total execution time: 0.1155
DEBUG - 2022-11-10 05:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:32:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:32:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:02:05 --> Total execution time: 0.1096
DEBUG - 2022-11-10 05:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:32:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:02:22 --> Total execution time: 0.1666
DEBUG - 2022-11-10 05:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:32:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:02:50 --> Total execution time: 0.4848
DEBUG - 2022-11-10 05:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:34:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:04:09 --> Total execution time: 0.1078
DEBUG - 2022-11-10 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:34:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:04:41 --> Total execution time: 0.1766
DEBUG - 2022-11-10 05:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:35:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:05:27 --> Total execution time: 0.1779
DEBUG - 2022-11-10 05:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:37:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:07:14 --> Total execution time: 2.0966
DEBUG - 2022-11-10 05:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:37:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:07:51 --> Total execution time: 0.4010
DEBUG - 2022-11-10 05:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:38:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:08:38 --> Total execution time: 0.7960
DEBUG - 2022-11-10 05:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:38:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:08:50 --> Total execution time: 0.2325
DEBUG - 2022-11-10 05:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:39:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:09:51 --> Total execution time: 0.5514
DEBUG - 2022-11-10 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:41:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:11:42 --> Total execution time: 0.6377
DEBUG - 2022-11-10 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:42:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:12:11 --> Total execution time: 2.9534
DEBUG - 2022-11-10 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:43:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:13:09 --> Total execution time: 2.0957
DEBUG - 2022-11-10 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:43:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:13:40 --> Total execution time: 4.5794
DEBUG - 2022-11-10 05:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:43:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 05:43:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1040): Too many connections /home3/esalesei/esalestrix.in/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-11-10 05:43:54 --> Unable to connect to the database
ERROR - 2022-11-10 05:43:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home3/esalesei/esalestrix.in/system/core/Exceptions.php:271) /home3/esalesei/esalestrix.in/system/core/Common.php 570
DEBUG - 2022-11-10 05:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:44:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:14:21 --> Total execution time: 0.4664
DEBUG - 2022-11-10 05:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:45:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:15:03 --> Total execution time: 0.1204
DEBUG - 2022-11-10 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:45:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:15:54 --> Total execution time: 0.1212
DEBUG - 2022-11-10 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:46:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:16:19 --> Total execution time: 0.4611
DEBUG - 2022-11-10 05:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:46:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:16:26 --> Total execution time: 0.1991
DEBUG - 2022-11-10 05:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:46:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:16:27 --> Total execution time: 0.1322
DEBUG - 2022-11-10 05:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:48:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:18:29 --> Total execution time: 1.1509
DEBUG - 2022-11-10 05:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:48:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:18:30 --> Total execution time: 0.1718
DEBUG - 2022-11-10 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:50:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:20:48 --> Total execution time: 0.5095
DEBUG - 2022-11-10 05:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:50:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:20:48 --> Total execution time: 0.1145
DEBUG - 2022-11-10 05:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:51:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:21:24 --> Total execution time: 0.1742
DEBUG - 2022-11-10 05:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:52:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:22:26 --> Total execution time: 0.5029
DEBUG - 2022-11-10 05:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:52:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:22:30 --> Total execution time: 0.1750
DEBUG - 2022-11-10 05:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:52:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:22:32 --> Total execution time: 0.1731
DEBUG - 2022-11-10 05:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:53:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:23:34 --> Total execution time: 0.1709
DEBUG - 2022-11-10 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:54:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:24:52 --> Total execution time: 0.1061
DEBUG - 2022-11-10 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 05:58:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 05:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 05:58:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:28:23 --> Total execution time: 0.9027
DEBUG - 2022-11-10 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:00:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:30:48 --> Total execution time: 1.1334
DEBUG - 2022-11-10 06:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:03:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:33:33 --> Total execution time: 0.5763
DEBUG - 2022-11-10 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:04:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:34:54 --> Total execution time: 0.7915
DEBUG - 2022-11-10 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:05:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:35:21 --> Total execution time: 0.1204
DEBUG - 2022-11-10 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:06:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:36:12 --> Total execution time: 0.2362
DEBUG - 2022-11-10 06:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:06:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:36:26 --> Total execution time: 0.1820
DEBUG - 2022-11-10 06:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:07:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:37:28 --> Total execution time: 0.4485
DEBUG - 2022-11-10 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:07:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:37:30 --> Total execution time: 0.1757
DEBUG - 2022-11-10 06:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:10:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:43 --> Total execution time: 0.5076
DEBUG - 2022-11-10 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:10:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:47 --> Total execution time: 0.4625
DEBUG - 2022-11-10 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:11:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:41:12 --> Total execution time: 0.4467
DEBUG - 2022-11-10 06:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:11:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:41:25 --> Total execution time: 0.1867
DEBUG - 2022-11-10 06:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:12:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:42:13 --> Total execution time: 0.1698
DEBUG - 2022-11-10 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:12:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:42:26 --> Total execution time: 0.1236
DEBUG - 2022-11-10 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:12:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:42:27 --> Total execution time: 0.1115
DEBUG - 2022-11-10 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:12:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:42:40 --> Total execution time: 0.1683
DEBUG - 2022-11-10 06:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:13:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:13:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:43:02 --> Total execution time: 0.1800
DEBUG - 2022-11-10 06:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:13:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:43:56 --> Total execution time: 0.2489
DEBUG - 2022-11-10 06:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:14:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:44:45 --> Total execution time: 0.1734
DEBUG - 2022-11-10 06:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:14:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:44:59 --> Total execution time: 0.5228
DEBUG - 2022-11-10 06:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:15:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:45:10 --> Total execution time: 0.2832
DEBUG - 2022-11-10 06:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:15:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:15:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:45:56 --> Total execution time: 0.1714
DEBUG - 2022-11-10 06:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:16:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:46:27 --> Total execution time: 0.4545
DEBUG - 2022-11-10 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:16:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:46:56 --> Total execution time: 0.4672
DEBUG - 2022-11-10 06:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:17:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:47:11 --> Total execution time: 0.1901
DEBUG - 2022-11-10 06:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:17:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:47:17 --> Total execution time: 0.1772
DEBUG - 2022-11-10 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:17:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:47:36 --> Total execution time: 0.1410
DEBUG - 2022-11-10 06:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:18:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:18:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:48:33 --> Total execution time: 0.1151
DEBUG - 2022-11-10 06:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:20:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:50:06 --> Total execution time: 0.4380
DEBUG - 2022-11-10 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:20:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:50:41 --> Total execution time: 0.1683
DEBUG - 2022-11-10 06:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:23:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:53:32 --> Total execution time: 0.4719
DEBUG - 2022-11-10 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:24:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:54:03 --> Total execution time: 0.5113
DEBUG - 2022-11-10 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:26:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:56:08 --> Total execution time: 0.6573
DEBUG - 2022-11-10 06:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:31:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:01:28 --> Total execution time: 0.5932
DEBUG - 2022-11-10 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:41:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:11:51 --> Total execution time: 0.6034
DEBUG - 2022-11-10 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:42:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:12:43 --> Total execution time: 0.1221
DEBUG - 2022-11-10 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:42:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:12:51 --> Total execution time: 0.6717
DEBUG - 2022-11-10 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:43:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:13:53 --> Total execution time: 3.1428
DEBUG - 2022-11-10 06:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:46:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:16:05 --> Total execution time: 2.6044
DEBUG - 2022-11-10 06:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:46:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:16:26 --> Total execution time: 0.5494
DEBUG - 2022-11-10 06:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:46:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:46:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:16:33 --> Total execution time: 0.1805
DEBUG - 2022-11-10 06:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:46:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:16:38 --> Total execution time: 0.1117
DEBUG - 2022-11-10 06:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:48:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:18:09 --> Total execution time: 0.7339
DEBUG - 2022-11-10 06:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:48:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:18:16 --> Total execution time: 0.4793
DEBUG - 2022-11-10 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:50:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:50:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:20:46 --> Total execution time: 0.7520
DEBUG - 2022-11-10 06:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:20:46 --> Total execution time: 0.6108
DEBUG - 2022-11-10 06:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:55:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:25:18 --> Total execution time: 0.8488
DEBUG - 2022-11-10 06:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:55:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:55:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:25:28 --> Total execution time: 0.1058
DEBUG - 2022-11-10 06:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:55:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:25:37 --> Total execution time: 0.1954
DEBUG - 2022-11-10 06:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:55:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:25:54 --> Total execution time: 0.1749
DEBUG - 2022-11-10 06:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:55:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:25:59 --> Total execution time: 0.4426
DEBUG - 2022-11-10 06:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:56:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:26:00 --> Total execution time: 0.4363
DEBUG - 2022-11-10 06:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:56:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:26:10 --> Total execution time: 0.1160
DEBUG - 2022-11-10 06:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:56:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:56:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:26:19 --> Total execution time: 0.1681
DEBUG - 2022-11-10 06:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:56:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:26:57 --> Total execution time: 0.1748
DEBUG - 2022-11-10 06:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:56:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:26:59 --> Total execution time: 0.1871
DEBUG - 2022-11-10 06:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:57:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:27:38 --> Total execution time: 0.1153
DEBUG - 2022-11-10 06:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:58:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:28:28 --> Total execution time: 0.1730
DEBUG - 2022-11-10 06:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:59:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:29:06 --> Total execution time: 0.2206
DEBUG - 2022-11-10 06:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 06:59:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 06:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 06:59:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:29:16 --> Total execution time: 0.1713
DEBUG - 2022-11-10 07:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:04:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:04:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 07:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:34:20 --> Total execution time: 3.0261
DEBUG - 2022-11-10 18:34:20 --> Total execution time: 2.0747
DEBUG - 2022-11-10 07:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:04:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:34:32 --> Total execution time: 0.1163
DEBUG - 2022-11-10 07:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:04:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:34:55 --> Total execution time: 0.1457
DEBUG - 2022-11-10 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:05:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:35:20 --> Total execution time: 0.1087
DEBUG - 2022-11-10 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:05:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:35:25 --> Total execution time: 0.4663
DEBUG - 2022-11-10 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:05:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:35:26 --> Total execution time: 0.1821
DEBUG - 2022-11-10 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:07:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:37:01 --> Total execution time: 0.6856
DEBUG - 2022-11-10 07:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:10:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:40:28 --> Total execution time: 0.9706
DEBUG - 2022-11-10 07:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:10:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:40:46 --> Total execution time: 0.4607
DEBUG - 2022-11-10 07:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:10:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:40:49 --> Total execution time: 0.1687
DEBUG - 2022-11-10 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:12:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:42:17 --> Total execution time: 0.1684
DEBUG - 2022-11-10 07:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:14:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:44:27 --> Total execution time: 0.5639
DEBUG - 2022-11-10 07:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:14:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:44:32 --> Total execution time: 0.4869
DEBUG - 2022-11-10 07:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:14:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:44:43 --> Total execution time: 0.4461
DEBUG - 2022-11-10 07:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:14:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:44:45 --> Total execution time: 0.1719
DEBUG - 2022-11-10 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:15:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:45:13 --> Total execution time: 0.1826
DEBUG - 2022-11-10 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:15:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:45:13 --> Total execution time: 0.1202
DEBUG - 2022-11-10 07:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:15:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:45:26 --> Total execution time: 0.1658
DEBUG - 2022-11-10 07:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:16:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:46:05 --> Total execution time: 0.1709
DEBUG - 2022-11-10 07:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:16:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:46:28 --> Total execution time: 0.1097
DEBUG - 2022-11-10 07:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:16:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:46:33 --> Total execution time: 0.4481
DEBUG - 2022-11-10 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:17:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:06 --> Total execution time: 0.2296
DEBUG - 2022-11-10 07:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:17:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:08 --> Total execution time: 0.1840
DEBUG - 2022-11-10 07:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:17:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:09 --> Total execution time: 0.1727
DEBUG - 2022-11-10 07:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:17:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:11 --> Total execution time: 0.1717
DEBUG - 2022-11-10 07:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:18:01 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:01 --> Total execution time: 0.1340
DEBUG - 2022-11-10 07:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:18:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:18:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:27 --> Total execution time: 0.1689
DEBUG - 2022-11-10 07:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:18:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:53 --> Total execution time: 0.1723
DEBUG - 2022-11-10 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:19:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:49:48 --> Total execution time: 0.1145
DEBUG - 2022-11-10 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:19:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:49:57 --> Total execution time: 0.1223
DEBUG - 2022-11-10 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:19:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:49:57 --> Total execution time: 0.1598
DEBUG - 2022-11-10 07:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:19:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:49:59 --> Total execution time: 0.1064
DEBUG - 2022-11-10 07:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:20:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:50:24 --> Total execution time: 0.1354
DEBUG - 2022-11-10 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:20:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:50:49 --> Total execution time: 0.1141
DEBUG - 2022-11-10 07:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:21:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:51:40 --> Total execution time: 0.4667
DEBUG - 2022-11-10 07:24:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:24:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:54:01 --> Total execution time: 0.1182
DEBUG - 2022-11-10 07:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:24:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:24:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:54:28 --> Total execution time: 0.1130
DEBUG - 2022-11-10 07:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:26:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:56:18 --> Total execution time: 3.2969
DEBUG - 2022-11-10 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:26:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:56:40 --> Total execution time: 1.0309
DEBUG - 2022-11-10 07:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:26:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:56:41 --> Total execution time: 0.1974
DEBUG - 2022-11-10 07:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:27:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:57:02 --> Total execution time: 0.1194
DEBUG - 2022-11-10 07:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:27:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:57:46 --> Total execution time: 0.1713
DEBUG - 2022-11-10 07:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:27:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:57:51 --> Total execution time: 0.1788
DEBUG - 2022-11-10 07:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:28:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:58:19 --> Total execution time: 0.1173
DEBUG - 2022-11-10 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:28:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:58:59 --> Total execution time: 0.1675
DEBUG - 2022-11-10 07:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:29:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:59:02 --> Total execution time: 0.1685
DEBUG - 2022-11-10 07:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:29:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:59:29 --> Total execution time: 0.1126
DEBUG - 2022-11-10 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:29:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:59:41 --> Total execution time: 0.1781
DEBUG - 2022-11-10 07:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:29:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:59:56 --> Total execution time: 0.1100
DEBUG - 2022-11-10 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:30:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:00:06 --> Total execution time: 0.4579
DEBUG - 2022-11-10 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:30:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:00:22 --> Total execution time: 0.1199
DEBUG - 2022-11-10 07:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:30:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:00:27 --> Total execution time: 0.1674
DEBUG - 2022-11-10 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:31:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:01:44 --> Total execution time: 0.9082
DEBUG - 2022-11-10 07:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:31:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:01:57 --> Total execution time: 0.1965
DEBUG - 2022-11-10 07:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:32:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:02:44 --> Total execution time: 0.4758
DEBUG - 2022-11-10 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:33:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:03:05 --> Total execution time: 0.1270
DEBUG - 2022-11-10 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:33:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:03:52 --> Total execution time: 0.2110
DEBUG - 2022-11-10 07:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:34:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:05 --> Total execution time: 0.1250
DEBUG - 2022-11-10 07:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:34:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:25 --> Total execution time: 0.1665
DEBUG - 2022-11-10 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:26 --> Total execution time: 0.1148
DEBUG - 2022-11-10 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:27 --> Total execution time: 0.1076
DEBUG - 2022-11-10 07:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:31 --> Total execution time: 0.4944
DEBUG - 2022-11-10 07:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:43 --> Total execution time: 0.1179
DEBUG - 2022-11-10 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:48 --> Total execution time: 0.1709
DEBUG - 2022-11-10 07:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:35:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:55 --> Total execution time: 0.1852
DEBUG - 2022-11-10 07:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:36:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:06:17 --> Total execution time: 0.1694
DEBUG - 2022-11-10 07:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:36:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:06:20 --> Total execution time: 0.4623
DEBUG - 2022-11-10 07:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:36:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:06:28 --> Total execution time: 0.1752
DEBUG - 2022-11-10 07:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:36:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:06:35 --> Total execution time: 0.1353
DEBUG - 2022-11-10 07:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:36:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:06:52 --> Total execution time: 0.1786
DEBUG - 2022-11-10 07:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:37:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:07:12 --> Total execution time: 0.1990
DEBUG - 2022-11-10 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:37:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:07:19 --> Total execution time: 0.4476
DEBUG - 2022-11-10 07:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:38:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:38:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:08:29 --> Total execution time: 0.1258
DEBUG - 2022-11-10 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:38:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:08:30 --> Total execution time: 0.1153
DEBUG - 2022-11-10 07:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:38:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:08:44 --> Total execution time: 0.1709
DEBUG - 2022-11-10 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:39:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:09:04 --> Total execution time: 0.1075
DEBUG - 2022-11-10 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:39:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:09:10 --> Total execution time: 0.1792
DEBUG - 2022-11-10 07:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:39:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:09:19 --> Total execution time: 0.2032
DEBUG - 2022-11-10 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:39:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:09:29 --> Total execution time: 0.4798
DEBUG - 2022-11-10 07:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:39:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:09:38 --> Total execution time: 0.1725
DEBUG - 2022-11-10 07:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:40:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:10:12 --> Total execution time: 0.1784
DEBUG - 2022-11-10 07:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:40:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:10:39 --> Total execution time: 0.1779
DEBUG - 2022-11-10 07:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:41:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:11:08 --> Total execution time: 0.1799
DEBUG - 2022-11-10 07:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:41:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:11:10 --> Total execution time: 0.1736
DEBUG - 2022-11-10 07:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:41:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:11:47 --> Total execution time: 0.1839
DEBUG - 2022-11-10 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:42:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:42:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:12:32 --> Total execution time: 0.1688
DEBUG - 2022-11-10 07:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:12:32 --> Total execution time: 0.4536
DEBUG - 2022-11-10 07:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:42:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:12:41 --> Total execution time: 0.1500
DEBUG - 2022-11-10 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:43:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:13:06 --> Total execution time: 0.1651
DEBUG - 2022-11-10 07:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:43:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:13:07 --> Total execution time: 0.1672
DEBUG - 2022-11-10 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:44:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:14:14 --> Total execution time: 0.1139
DEBUG - 2022-11-10 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:44:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:14:15 --> Total execution time: 0.4687
DEBUG - 2022-11-10 07:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:00 --> Total execution time: 0.2144
DEBUG - 2022-11-10 07:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:20 --> Total execution time: 0.1802
DEBUG - 2022-11-10 07:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:36 --> Total execution time: 0.4426
DEBUG - 2022-11-10 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:37 --> Total execution time: 0.1065
DEBUG - 2022-11-10 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:38 --> Total execution time: 0.1727
DEBUG - 2022-11-10 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:38 --> Total execution time: 0.1143
DEBUG - 2022-11-10 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:39 --> Total execution time: 0.1738
DEBUG - 2022-11-10 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:39 --> Total execution time: 0.1693
DEBUG - 2022-11-10 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:39 --> Total execution time: 0.1728
DEBUG - 2022-11-10 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:40 --> Total execution time: 0.1760
DEBUG - 2022-11-10 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:40 --> Total execution time: 0.1670
DEBUG - 2022-11-10 07:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:41 --> Total execution time: 0.1163
DEBUG - 2022-11-10 07:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:45:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:41 --> Total execution time: 0.1133
DEBUG - 2022-11-10 07:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:46:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:46:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:47 --> Total execution time: 0.4470
DEBUG - 2022-11-10 07:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:47:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:17:59 --> Total execution time: 0.1797
DEBUG - 2022-11-10 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:48:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:22 --> Total execution time: 0.1086
DEBUG - 2022-11-10 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:48:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:56 --> Total execution time: 0.4395
DEBUG - 2022-11-10 07:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:49:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:19:03 --> Total execution time: 0.1586
DEBUG - 2022-11-10 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:49:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:19:31 --> Total execution time: 0.1059
DEBUG - 2022-11-10 07:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:49:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:19:31 --> Total execution time: 0.1667
DEBUG - 2022-11-10 07:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:49:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:19:45 --> Total execution time: 0.2120
DEBUG - 2022-11-10 07:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:50:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:20:20 --> Total execution time: 0.1680
DEBUG - 2022-11-10 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:50:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:20:39 --> Total execution time: 0.4482
DEBUG - 2022-11-10 07:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:50:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:20:45 --> Total execution time: 0.1705
DEBUG - 2022-11-10 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:50:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:20:52 --> Total execution time: 0.1568
DEBUG - 2022-11-10 07:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:51:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:21:06 --> Total execution time: 0.1064
DEBUG - 2022-11-10 07:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:51:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:21:07 --> Total execution time: 0.1064
DEBUG - 2022-11-10 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:51:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:21:48 --> Total execution time: 0.1661
DEBUG - 2022-11-10 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:52:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:22:02 --> Total execution time: 0.1900
DEBUG - 2022-11-10 07:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:53:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:23:36 --> Total execution time: 0.8840
DEBUG - 2022-11-10 07:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:53:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:53:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:23:39 --> Total execution time: 0.1697
DEBUG - 2022-11-10 07:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:54:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:08 --> Total execution time: 0.2664
DEBUG - 2022-11-10 07:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:54:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:13 --> Total execution time: 0.1736
DEBUG - 2022-11-10 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:55:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:55:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:04 --> Total execution time: 2.0387
DEBUG - 2022-11-10 07:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:55:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:55:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:47 --> Total execution time: 2.2157
DEBUG - 2022-11-10 07:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:55:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:48 --> Total execution time: 0.1156
DEBUG - 2022-11-10 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:56:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:56:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:35 --> Total execution time: 0.5143
DEBUG - 2022-11-10 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:56:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:55 --> Total execution time: 0.2468
DEBUG - 2022-11-10 07:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:57:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:27:43 --> Total execution time: 1.3117
DEBUG - 2022-11-10 07:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:57:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:27:55 --> Total execution time: 0.4464
DEBUG - 2022-11-10 07:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:58:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:04 --> Total execution time: 0.1117
DEBUG - 2022-11-10 07:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 07:58:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 07:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 07:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:08 --> Total execution time: 0.1831
DEBUG - 2022-11-10 08:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:04:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:04:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:34:24 --> Total execution time: 0.8391
DEBUG - 2022-11-10 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:04:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:34:26 --> Total execution time: 0.1077
DEBUG - 2022-11-10 08:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:04:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:34:34 --> Total execution time: 0.4460
DEBUG - 2022-11-10 08:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:07:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:37:31 --> Total execution time: 0.4415
DEBUG - 2022-11-10 08:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:08 --> Total execution time: 0.1096
DEBUG - 2022-11-10 08:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:29 --> Total execution time: 0.1760
DEBUG - 2022-11-10 08:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:36 --> Total execution time: 0.4456
DEBUG - 2022-11-10 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:37 --> Total execution time: 0.1742
DEBUG - 2022-11-10 08:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:49 --> Total execution time: 0.1161
DEBUG - 2022-11-10 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:08:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:38:53 --> Total execution time: 0.4443
DEBUG - 2022-11-10 08:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:09:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:39:11 --> Total execution time: 0.1677
DEBUG - 2022-11-10 08:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:09:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:39:43 --> Total execution time: 0.1172
DEBUG - 2022-11-10 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:09:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:39:56 --> Total execution time: 0.1713
DEBUG - 2022-11-10 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:09:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:39:57 --> Total execution time: 0.1671
DEBUG - 2022-11-10 08:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:10:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:40:33 --> Total execution time: 0.6718
DEBUG - 2022-11-10 08:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:10:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:40:44 --> Total execution time: 0.4634
DEBUG - 2022-11-10 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:12:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:36 --> Total execution time: 0.3118
DEBUG - 2022-11-10 08:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:12:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:47 --> Total execution time: 0.1730
DEBUG - 2022-11-10 08:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:13:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:03 --> Total execution time: 0.1517
DEBUG - 2022-11-10 08:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:13:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:54 --> Total execution time: 0.1253
DEBUG - 2022-11-10 08:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:13:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:59 --> Total execution time: 0.1223
DEBUG - 2022-11-10 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:14:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:03 --> Total execution time: 0.1866
DEBUG - 2022-11-10 08:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:14:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:14:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:22 --> Total execution time: 0.1703
DEBUG - 2022-11-10 08:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:14:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:43 --> Total execution time: 0.1716
DEBUG - 2022-11-10 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:14:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:59 --> Total execution time: 0.1953
DEBUG - 2022-11-10 08:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:15:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:45:34 --> Total execution time: 0.4541
DEBUG - 2022-11-10 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:15:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:45:34 --> Total execution time: 0.1821
DEBUG - 2022-11-10 08:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:15:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:45:53 --> Total execution time: 0.4579
DEBUG - 2022-11-10 08:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:16:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:46:27 --> Total execution time: 0.4406
DEBUG - 2022-11-10 08:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:17:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:17:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:47:30 --> Total execution time: 0.1663
DEBUG - 2022-11-10 08:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:17:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:47:38 --> Total execution time: 0.1748
DEBUG - 2022-11-10 08:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:19:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:49:19 --> Total execution time: 0.1820
DEBUG - 2022-11-10 08:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:19:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:49:33 --> Total execution time: 0.1749
DEBUG - 2022-11-10 08:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:19:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:49:48 --> Total execution time: 0.1859
DEBUG - 2022-11-10 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:23:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:53:53 --> Total execution time: 0.9613
DEBUG - 2022-11-10 08:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:25:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:25:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:55:29 --> Total execution time: 2.5013
DEBUG - 2022-11-10 08:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:55:29 --> Total execution time: 0.6397
DEBUG - 2022-11-10 08:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:25:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:55:29 --> Total execution time: 0.1667
DEBUG - 2022-11-10 08:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:28:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:58:25 --> Total execution time: 0.5513
DEBUG - 2022-11-10 08:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:28:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:58:46 --> Total execution time: 0.6540
DEBUG - 2022-11-10 08:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:29:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:59:15 --> Total execution time: 0.1661
DEBUG - 2022-11-10 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:29:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:59:49 --> Total execution time: 0.1717
DEBUG - 2022-11-10 08:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:30:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:00:29 --> Total execution time: 0.1665
DEBUG - 2022-11-10 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:31:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:01:28 --> Total execution time: 0.4614
DEBUG - 2022-11-10 08:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:31:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:01:39 --> Total execution time: 0.1716
DEBUG - 2022-11-10 08:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:32:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:02:13 --> Total execution time: 0.4531
DEBUG - 2022-11-10 08:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:32:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:02:25 --> Total execution time: 0.1733
DEBUG - 2022-11-10 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:32:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:02:26 --> Total execution time: 0.1971
DEBUG - 2022-11-10 08:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:33:01 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:03:01 --> Total execution time: 0.2048
DEBUG - 2022-11-10 08:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:33:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:03:27 --> Total execution time: 0.4795
DEBUG - 2022-11-10 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:34:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:04:39 --> Total execution time: 0.1799
DEBUG - 2022-11-10 08:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:35:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:05:14 --> Total execution time: 0.1747
DEBUG - 2022-11-10 08:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:36:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:06:51 --> Total execution time: 0.1179
DEBUG - 2022-11-10 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:36:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:06:52 --> Total execution time: 0.1007
DEBUG - 2022-11-10 08:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:36:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:06:58 --> Total execution time: 0.1831
DEBUG - 2022-11-10 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:37:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:07:31 --> Total execution time: 0.1114
DEBUG - 2022-11-10 08:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:37:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:07:59 --> Total execution time: 0.1114
DEBUG - 2022-11-10 08:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:38:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:08:41 --> Total execution time: 0.1745
DEBUG - 2022-11-10 08:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:40:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:10:24 --> Total execution time: 0.1131
DEBUG - 2022-11-10 08:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:41:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:41:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:11:41 --> Total execution time: 0.5444
DEBUG - 2022-11-10 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:41:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:11:46 --> Total execution time: 0.1668
DEBUG - 2022-11-10 08:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:42:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:12:11 --> Total execution time: 0.1167
DEBUG - 2022-11-10 08:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:42:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:12:18 --> Total execution time: 0.1705
DEBUG - 2022-11-10 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:44:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:14:19 --> Total execution time: 0.4517
DEBUG - 2022-11-10 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:49:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:19:44 --> Total execution time: 0.5116
DEBUG - 2022-11-10 08:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:50:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:20:03 --> Total execution time: 0.1694
DEBUG - 2022-11-10 08:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:50:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:20:03 --> Total execution time: 0.1690
DEBUG - 2022-11-10 08:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:50:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:20:25 --> Total execution time: 0.1884
DEBUG - 2022-11-10 08:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:50:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:20:56 --> Total execution time: 0.4438
DEBUG - 2022-11-10 08:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:52:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:22:31 --> Total execution time: 0.1712
DEBUG - 2022-11-10 08:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:00 --> Total execution time: 0.1716
DEBUG - 2022-11-10 08:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:03 --> Total execution time: 0.1713
DEBUG - 2022-11-10 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:07 --> Total execution time: 0.1098
DEBUG - 2022-11-10 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:12 --> Total execution time: 0.1774
DEBUG - 2022-11-10 08:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:14 --> Total execution time: 0.1728
DEBUG - 2022-11-10 08:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:15 --> Total execution time: 0.1752
DEBUG - 2022-11-10 08:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:16 --> Total execution time: 0.1667
DEBUG - 2022-11-10 08:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:16 --> Total execution time: 0.1118
DEBUG - 2022-11-10 08:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:20 --> Total execution time: 0.1098
DEBUG - 2022-11-10 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:21 --> Total execution time: 0.1753
DEBUG - 2022-11-10 08:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:21 --> Total execution time: 0.1716
DEBUG - 2022-11-10 08:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:53:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:23:37 --> Total execution time: 0.1882
DEBUG - 2022-11-10 08:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:54:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:24:20 --> Total execution time: 0.1712
DEBUG - 2022-11-10 08:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:54:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:24:34 --> Total execution time: 0.1781
DEBUG - 2022-11-10 08:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:54:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:24:55 --> Total execution time: 0.4383
DEBUG - 2022-11-10 08:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:54:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:24:57 --> Total execution time: 0.1315
DEBUG - 2022-11-10 08:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:55:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:25:24 --> Total execution time: 0.1129
DEBUG - 2022-11-10 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:55:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:25:48 --> Total execution time: 0.1693
DEBUG - 2022-11-10 08:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:55:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:25:52 --> Total execution time: 0.1696
DEBUG - 2022-11-10 08:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:57:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:27:22 --> Total execution time: 0.2034
DEBUG - 2022-11-10 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:57:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:27:55 --> Total execution time: 0.1817
DEBUG - 2022-11-10 08:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:57:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:27:56 --> Total execution time: 0.1700
DEBUG - 2022-11-10 08:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:58:07 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:28:07 --> Total execution time: 0.1318
DEBUG - 2022-11-10 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:58:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:28:08 --> Total execution time: 0.1083
DEBUG - 2022-11-10 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:59:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:29:34 --> Total execution time: 0.1074
DEBUG - 2022-11-10 08:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:59:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:29:40 --> Total execution time: 0.1303
DEBUG - 2022-11-10 08:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 08:59:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 08:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 08:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:29:41 --> Total execution time: 0.1009
DEBUG - 2022-11-10 09:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:00:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:30:09 --> Total execution time: 0.1735
DEBUG - 2022-11-10 09:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:00:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:30:12 --> Total execution time: 0.1093
DEBUG - 2022-11-10 09:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:00:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:30:49 --> Total execution time: 0.1797
DEBUG - 2022-11-10 09:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:01:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:31:12 --> Total execution time: 0.1118
DEBUG - 2022-11-10 09:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:01:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:31:21 --> Total execution time: 0.1727
DEBUG - 2022-11-10 09:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:13 --> Total execution time: 0.1852
DEBUG - 2022-11-10 09:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:15 --> Total execution time: 0.1684
DEBUG - 2022-11-10 09:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:28 --> Total execution time: 0.1096
DEBUG - 2022-11-10 09:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:29 --> Total execution time: 0.1137
DEBUG - 2022-11-10 09:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:31 --> Total execution time: 0.1081
DEBUG - 2022-11-10 09:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:03:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:33:49 --> Total execution time: 0.4541
DEBUG - 2022-11-10 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:04:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:34:15 --> Total execution time: 0.1696
DEBUG - 2022-11-10 09:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:04:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:34:16 --> Total execution time: 0.1683
DEBUG - 2022-11-10 09:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:04:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:34:33 --> Total execution time: 0.1698
DEBUG - 2022-11-10 09:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:04:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:34:53 --> Total execution time: 0.4425
DEBUG - 2022-11-10 09:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:04:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:34:53 --> Total execution time: 0.1674
DEBUG - 2022-11-10 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:05:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:35:29 --> Total execution time: 0.1192
DEBUG - 2022-11-10 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:05:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:35:36 --> Total execution time: 0.1105
DEBUG - 2022-11-10 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:05:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:35:58 --> Total execution time: 0.1805
DEBUG - 2022-11-10 09:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:06:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:36:17 --> Total execution time: 0.1090
DEBUG - 2022-11-10 09:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:06:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:36:35 --> Total execution time: 0.1826
DEBUG - 2022-11-10 09:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:07:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:37:22 --> Total execution time: 0.4353
DEBUG - 2022-11-10 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:07:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:37:25 --> Total execution time: 0.1636
DEBUG - 2022-11-10 09:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:07:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:37:36 --> Total execution time: 0.1672
DEBUG - 2022-11-10 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:07:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:37:39 --> Total execution time: 0.5141
DEBUG - 2022-11-10 09:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:07:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:07:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:37:59 --> Total execution time: 0.1718
DEBUG - 2022-11-10 09:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:08:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:38:13 --> Total execution time: 0.1804
DEBUG - 2022-11-10 09:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:05 --> Total execution time: 0.4588
DEBUG - 2022-11-10 09:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:08 --> Total execution time: 0.1702
DEBUG - 2022-11-10 09:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:09 --> Total execution time: 0.4717
DEBUG - 2022-11-10 09:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:15 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:15 --> Total execution time: 0.2158
DEBUG - 2022-11-10 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:16 --> Total execution time: 0.1785
DEBUG - 2022-11-10 09:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:09:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:39:25 --> Total execution time: 0.1687
DEBUG - 2022-11-10 09:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:10:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:40:11 --> Total execution time: 0.1121
DEBUG - 2022-11-10 09:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:14 --> Total execution time: 0.1683
DEBUG - 2022-11-10 09:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:26 --> Total execution time: 0.1757
DEBUG - 2022-11-10 09:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:26 --> Total execution time: 0.4885
DEBUG - 2022-11-10 09:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:27 --> Total execution time: 0.1774
DEBUG - 2022-11-10 09:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:37 --> Total execution time: 0.1717
DEBUG - 2022-11-10 09:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:45 --> Total execution time: 0.2059
DEBUG - 2022-11-10 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:46 --> Total execution time: 0.1299
DEBUG - 2022-11-10 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:46 --> Total execution time: 0.1876
DEBUG - 2022-11-10 09:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 09:11:51 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-10 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:54 --> Total execution time: 0.1769
DEBUG - 2022-11-10 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:54 --> Total execution time: 0.1767
DEBUG - 2022-11-10 09:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:54 --> Total execution time: 0.4394
DEBUG - 2022-11-10 09:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:55 --> Total execution time: 0.4454
DEBUG - 2022-11-10 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:56 --> Total execution time: 0.1657
DEBUG - 2022-11-10 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:11:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:41:58 --> Total execution time: 0.1038
DEBUG - 2022-11-10 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:13 --> Total execution time: 0.1671
DEBUG - 2022-11-10 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:14 --> Total execution time: 0.1658
DEBUG - 2022-11-10 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:16 --> Total execution time: 0.1662
DEBUG - 2022-11-10 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:18 --> Total execution time: 0.1914
DEBUG - 2022-11-10 09:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:31 --> Total execution time: 0.1788
DEBUG - 2022-11-10 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:33 --> Total execution time: 0.1640
DEBUG - 2022-11-10 09:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:35 --> Total execution time: 0.1666
DEBUG - 2022-11-10 09:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:37 --> Total execution time: 0.1635
DEBUG - 2022-11-10 09:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:37 --> Total execution time: 0.1646
DEBUG - 2022-11-10 09:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:40 --> Total execution time: 0.1724
DEBUG - 2022-11-10 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:44 --> Total execution time: 0.4413
DEBUG - 2022-11-10 09:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:50 --> Total execution time: 0.4394
DEBUG - 2022-11-10 09:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:54 --> Total execution time: 0.1630
DEBUG - 2022-11-10 09:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:42:59 --> Total execution time: 0.1659
DEBUG - 2022-11-10 09:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:03 --> Total execution time: 0.1089
DEBUG - 2022-11-10 09:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:20 --> Total execution time: 0.1665
DEBUG - 2022-11-10 09:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:20 --> Total execution time: 0.1746
DEBUG - 2022-11-10 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:23 --> Total execution time: 0.4445
DEBUG - 2022-11-10 09:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:30 --> Total execution time: 0.1644
DEBUG - 2022-11-10 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:33 --> Total execution time: 0.1687
DEBUG - 2022-11-10 09:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:33 --> Total execution time: 0.1733
DEBUG - 2022-11-10 09:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:33 --> Total execution time: 0.1673
DEBUG - 2022-11-10 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:37 --> Total execution time: 0.1700
DEBUG - 2022-11-10 09:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:38 --> Total execution time: 0.4437
DEBUG - 2022-11-10 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:39 --> Total execution time: 0.1625
DEBUG - 2022-11-10 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:13:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:43:46 --> Total execution time: 0.1712
DEBUG - 2022-11-10 09:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:01 --> Total execution time: 2.9308
DEBUG - 2022-11-10 09:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:04 --> Total execution time: 0.1698
DEBUG - 2022-11-10 09:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:13 --> Total execution time: 0.2216
DEBUG - 2022-11-10 09:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:27 --> Total execution time: 0.1270
DEBUG - 2022-11-10 20:44:27 --> Total execution time: 0.2527
DEBUG - 2022-11-10 09:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:34 --> Total execution time: 0.1782
DEBUG - 2022-11-10 09:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:36 --> Total execution time: 0.5621
DEBUG - 2022-11-10 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:37 --> Total execution time: 0.1713
DEBUG - 2022-11-10 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:39 --> Total execution time: 0.1706
DEBUG - 2022-11-10 09:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:44:57 --> Total execution time: 2.1033
DEBUG - 2022-11-10 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 20:45:08 --> Total execution time: 2.0270
DEBUG - 2022-11-10 09:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:10 --> Total execution time: 2.6532
DEBUG - 2022-11-10 09:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:12 --> Total execution time: 0.1070
DEBUG - 2022-11-10 20:45:12 --> Total execution time: 4.3767
DEBUG - 2022-11-10 09:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:15 --> Total execution time: 0.1674
DEBUG - 2022-11-10 09:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:20 --> Total execution time: 1.7878
DEBUG - 2022-11-10 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:20 --> Total execution time: 0.1779
DEBUG - 2022-11-10 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:22 --> Total execution time: 0.1670
DEBUG - 2022-11-10 09:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:29 --> Total execution time: 0.1701
DEBUG - 2022-11-10 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:48 --> Total execution time: 0.1766
DEBUG - 2022-11-10 09:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:45:50 --> Total execution time: 0.3668
DEBUG - 2022-11-10 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:06 --> Total execution time: 1.9436
DEBUG - 2022-11-10 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:07 --> Total execution time: 0.1801
DEBUG - 2022-11-10 09:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:17 --> Total execution time: 0.2236
DEBUG - 2022-11-10 09:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:21 --> Total execution time: 0.1768
DEBUG - 2022-11-10 09:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:23 --> Total execution time: 0.1820
DEBUG - 2022-11-10 20:46:24 --> Total execution time: 1.8987
DEBUG - 2022-11-10 09:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:27 --> Total execution time: 0.1063
DEBUG - 2022-11-10 09:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:31 --> Total execution time: 0.1816
DEBUG - 2022-11-10 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:37 --> Total execution time: 0.1752
DEBUG - 2022-11-10 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:39 --> Total execution time: 0.1945
DEBUG - 2022-11-10 09:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:44 --> Total execution time: 0.1798
DEBUG - 2022-11-10 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:46 --> Total execution time: 0.2132
DEBUG - 2022-11-10 09:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:16:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:46:51 --> Total execution time: 0.1797
DEBUG - 2022-11-10 09:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:01 --> Total execution time: 0.2685
DEBUG - 2022-11-10 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:24 --> Total execution time: 0.1682
DEBUG - 2022-11-10 09:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:37 --> Total execution time: 0.1680
DEBUG - 2022-11-10 09:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:42 --> Total execution time: 0.4461
DEBUG - 2022-11-10 09:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:47 --> Total execution time: 0.1651
DEBUG - 2022-11-10 09:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:51 --> Total execution time: 0.4623
DEBUG - 2022-11-10 09:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:47:58 --> Total execution time: 0.1766
DEBUG - 2022-11-10 09:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:09 --> Total execution time: 0.1792
DEBUG - 2022-11-10 09:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:22 --> Total execution time: 0.1725
DEBUG - 2022-11-10 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:26 --> Total execution time: 0.1686
DEBUG - 2022-11-10 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:32 --> Total execution time: 0.1093
DEBUG - 2022-11-10 09:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:39 --> Total execution time: 0.2413
DEBUG - 2022-11-10 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:48 --> Total execution time: 0.1709
DEBUG - 2022-11-10 09:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:48:59 --> Total execution time: 0.1785
DEBUG - 2022-11-10 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:19:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:49:31 --> Total execution time: 0.4391
DEBUG - 2022-11-10 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:49:44 --> Total execution time: 0.1919
DEBUG - 2022-11-10 09:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:49:45 --> Total execution time: 0.1725
DEBUG - 2022-11-10 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:49:58 --> Total execution time: 0.1723
DEBUG - 2022-11-10 09:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:15 --> Total execution time: 0.1730
DEBUG - 2022-11-10 09:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:21 --> Total execution time: 0.1095
DEBUG - 2022-11-10 09:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:31 --> Total execution time: 0.1764
DEBUG - 2022-11-10 09:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:32 --> Total execution time: 0.1711
DEBUG - 2022-11-10 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:39 --> Total execution time: 0.2250
DEBUG - 2022-11-10 09:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:44 --> Total execution time: 0.1731
DEBUG - 2022-11-10 09:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:54 --> Total execution time: 0.4973
DEBUG - 2022-11-10 09:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:50:57 --> Total execution time: 0.1763
DEBUG - 2022-11-10 09:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:10 --> Total execution time: 0.1750
DEBUG - 2022-11-10 09:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:12 --> Total execution time: 0.1313
DEBUG - 2022-11-10 09:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:16 --> Total execution time: 0.2123
DEBUG - 2022-11-10 09:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:16 --> Total execution time: 0.1636
DEBUG - 2022-11-10 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:17 --> Total execution time: 0.1073
DEBUG - 2022-11-10 09:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:17 --> Total execution time: 0.1843
DEBUG - 2022-11-10 09:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:21 --> Total execution time: 0.2357
DEBUG - 2022-11-10 09:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:26 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:26 --> Total execution time: 0.1153
DEBUG - 2022-11-10 09:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:33 --> Total execution time: 0.1081
DEBUG - 2022-11-10 09:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:45 --> Total execution time: 0.1783
DEBUG - 2022-11-10 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:47 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:47 --> Total execution time: 0.4690
DEBUG - 2022-11-10 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:48 --> Total execution time: 0.1815
DEBUG - 2022-11-10 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:53 --> Total execution time: 0.2150
DEBUG - 2022-11-10 09:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:57 --> Total execution time: 0.1693
DEBUG - 2022-11-10 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:21:58 --> Total execution time: 0.1790
DEBUG - 2022-11-10 09:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:21:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:51:59 --> Total execution time: 0.1104
DEBUG - 2022-11-10 09:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:01 --> Total execution time: 0.1810
DEBUG - 2022-11-10 09:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:01 --> Total execution time: 0.1712
DEBUG - 2022-11-10 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:02 --> Total execution time: 0.2351
DEBUG - 2022-11-10 09:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:05 --> Total execution time: 0.1658
DEBUG - 2022-11-10 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:08 --> Total execution time: 0.1670
DEBUG - 2022-11-10 09:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:10 --> Total execution time: 0.1705
DEBUG - 2022-11-10 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:10 --> Total execution time: 0.1674
DEBUG - 2022-11-10 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:15 --> Total execution time: 0.1774
DEBUG - 2022-11-10 09:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:17 --> Total execution time: 0.1724
DEBUG - 2022-11-10 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:18 --> Total execution time: 0.1916
DEBUG - 2022-11-10 09:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:19 --> Total execution time: 0.1720
DEBUG - 2022-11-10 09:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:25 --> Total execution time: 0.4461
DEBUG - 2022-11-10 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:28 --> Total execution time: 0.1833
DEBUG - 2022-11-10 09:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:29 --> Total execution time: 0.1690
DEBUG - 2022-11-10 09:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:31 --> Total execution time: 0.1735
DEBUG - 2022-11-10 09:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:32 --> Total execution time: 0.1925
DEBUG - 2022-11-10 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:34 --> Total execution time: 0.1720
DEBUG - 2022-11-10 09:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:40 --> Total execution time: 0.1957
DEBUG - 2022-11-10 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:46 --> Total execution time: 0.1999
DEBUG - 2022-11-10 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:52:49 --> Total execution time: 1.6264
DEBUG - 2022-11-10 09:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:02 --> Total execution time: 0.1918
DEBUG - 2022-11-10 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:03 --> Total execution time: 0.1939
DEBUG - 2022-11-10 09:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:09 --> Total execution time: 0.1713
DEBUG - 2022-11-10 09:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:13 --> Total execution time: 0.2444
DEBUG - 2022-11-10 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:16 --> Total execution time: 0.4593
DEBUG - 2022-11-10 09:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:22 --> Total execution time: 0.2167
DEBUG - 2022-11-10 09:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:23 --> Total execution time: 0.1719
DEBUG - 2022-11-10 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:27 --> Total execution time: 0.1103
DEBUG - 2022-11-10 09:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:27 --> Total execution time: 0.2021
DEBUG - 2022-11-10 09:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:32 --> Total execution time: 0.2060
DEBUG - 2022-11-10 09:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:33 --> Total execution time: 0.1879
DEBUG - 2022-11-10 09:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 20:53:38 --> Total execution time: 1.9936
DEBUG - 2022-11-10 09:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:39 --> Total execution time: 0.1749
DEBUG - 2022-11-10 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:44 --> Total execution time: 0.1792
DEBUG - 2022-11-10 09:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:44 --> Total execution time: 0.1974
DEBUG - 2022-11-10 09:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:48 --> Total execution time: 0.1730
DEBUG - 2022-11-10 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:54 --> Total execution time: 0.2470
DEBUG - 2022-11-10 09:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:58 --> Total execution time: 0.2029
DEBUG - 2022-11-10 09:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:23:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:53:59 --> Total execution time: 0.1155
DEBUG - 2022-11-10 09:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:03 --> Total execution time: 0.2038
DEBUG - 2022-11-10 09:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:13 --> Total execution time: 0.2024
DEBUG - 2022-11-10 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:21 --> Total execution time: 0.1671
DEBUG - 2022-11-10 09:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:33 --> Total execution time: 0.2060
DEBUG - 2022-11-10 09:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:39 --> Total execution time: 0.2338
DEBUG - 2022-11-10 09:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:44 --> Total execution time: 0.2988
DEBUG - 2022-11-10 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:54:54 --> Total execution time: 0.1731
DEBUG - 2022-11-10 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:03 --> Total execution time: 0.2944
DEBUG - 2022-11-10 09:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:13 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 09:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:17 --> Total execution time: 0.2059
DEBUG - 2022-11-10 09:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:19 --> Total execution time: 0.1966
DEBUG - 2022-11-10 09:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:40 --> Total execution time: 0.5081
DEBUG - 2022-11-10 09:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:45 --> Total execution time: 0.2106
DEBUG - 2022-11-10 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:46 --> Total execution time: 0.2083
DEBUG - 2022-11-10 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:47 --> Total execution time: 0.2019
DEBUG - 2022-11-10 09:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:51 --> Total execution time: 0.1982
DEBUG - 2022-11-10 09:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:52 --> Total execution time: 0.2005
DEBUG - 2022-11-10 09:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:55 --> Total execution time: 0.2103
DEBUG - 2022-11-10 09:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:25:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:55:57 --> Total execution time: 0.1864
DEBUG - 2022-11-10 09:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:07 --> Total execution time: 0.2101
DEBUG - 2022-11-10 09:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 20:56:10 --> Total execution time: 1.6975
DEBUG - 2022-11-10 09:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:10 --> Total execution time: 0.1818
DEBUG - 2022-11-10 09:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:11 --> Total execution time: 0.3491
DEBUG - 2022-11-10 09:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:14 --> Total execution time: 0.2095
DEBUG - 2022-11-10 20:56:14 --> Total execution time: 1.7753
DEBUG - 2022-11-10 09:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:17 --> Total execution time: 0.2032
DEBUG - 2022-11-10 09:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 20:56:17 --> Total execution time: 0.1949
DEBUG - 2022-11-10 09:26:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:17 --> Total execution time: 0.2229
DEBUG - 2022-11-10 09:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 09:26:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 09:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:24 --> Total execution time: 0.2162
DEBUG - 2022-11-10 09:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:27 --> Total execution time: 0.1998
DEBUG - 2022-11-10 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:30 --> Total execution time: 0.1744
DEBUG - 2022-11-10 09:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:42 --> Total execution time: 0.1738
DEBUG - 2022-11-10 09:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:53 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:53 --> Total execution time: 0.1667
DEBUG - 2022-11-10 09:26:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:55 --> Total execution time: 0.1861
DEBUG - 2022-11-10 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:57 --> Total execution time: 0.3161
DEBUG - 2022-11-10 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:56:58 --> Total execution time: 0.1752
DEBUG - 2022-11-10 09:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:05 --> Total execution time: 0.1693
DEBUG - 2022-11-10 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:11 --> Total execution time: 0.1753
DEBUG - 2022-11-10 09:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:15 --> Total execution time: 0.1703
DEBUG - 2022-11-10 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:16 --> Total execution time: 0.1849
DEBUG - 2022-11-10 09:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:19 --> Total execution time: 1.8003
DEBUG - 2022-11-10 09:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:19 --> Total execution time: 0.2047
DEBUG - 2022-11-10 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:25 --> Total execution time: 0.1702
DEBUG - 2022-11-10 09:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:35 --> Total execution time: 0.1750
DEBUG - 2022-11-10 09:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:27:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:57:36 --> Total execution time: 0.4585
DEBUG - 2022-11-10 09:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:01 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:58:02 --> Total execution time: 0.1577
DEBUG - 2022-11-10 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:58:07 --> Total execution time: 0.1730
DEBUG - 2022-11-10 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-11-10 20:58:09 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 424
DEBUG - 2022-11-10 20:58:09 --> Total execution time: 0.1846
DEBUG - 2022-11-10 09:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:58:35 --> Total execution time: 0.1711
DEBUG - 2022-11-10 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:58:46 --> Total execution time: 0.1956
DEBUG - 2022-11-10 09:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:58:48 --> Total execution time: 0.1835
DEBUG - 2022-11-10 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:59:35 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-11-10 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:29:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:59:36 --> Total execution time: 0.1809
DEBUG - 2022-11-10 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 20:59:57 --> Total execution time: 0.1773
DEBUG - 2022-11-10 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:00:04 --> Total execution time: 0.1832
DEBUG - 2022-11-10 09:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:30:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:00:23 --> Total execution time: 0.1454
DEBUG - 2022-11-10 09:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:31:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:01:51 --> Total execution time: 0.1245
DEBUG - 2022-11-10 09:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:11 --> Total execution time: 0.1705
DEBUG - 2022-11-10 09:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:20 --> Total execution time: 0.4440
DEBUG - 2022-11-10 09:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:28 --> Total execution time: 0.1089
DEBUG - 2022-11-10 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:44 --> Total execution time: 0.1334
DEBUG - 2022-11-10 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 21:02:46 --> Total execution time: 2.2225
DEBUG - 2022-11-10 09:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 21:02:48 --> Total execution time: 3.5924
DEBUG - 2022-11-10 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:50 --> Total execution time: 2.9848
DEBUG - 2022-11-10 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:51 --> Total execution time: 0.1809
DEBUG - 2022-11-10 21:02:52 --> Total execution time: 3.6116
DEBUG - 2022-11-10 09:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:54 --> Total execution time: 5.3079
DEBUG - 2022-11-10 09:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:55 --> Total execution time: 6.8333
DEBUG - 2022-11-10 09:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:56 --> Total execution time: 0.2175
DEBUG - 2022-11-10 21:02:57 --> Total execution time: 7.9777
DEBUG - 2022-11-10 09:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:02:59 --> Total execution time: 8.4296
DEBUG - 2022-11-10 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:01 --> Total execution time: 0.2180
DEBUG - 2022-11-10 09:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:16 --> Total execution time: 0.1043
DEBUG - 2022-11-10 09:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:25 --> Total execution time: 0.1764
DEBUG - 2022-11-10 09:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:28 --> Total execution time: 0.1724
DEBUG - 2022-11-10 09:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:30 --> Total execution time: 0.1812
DEBUG - 2022-11-10 09:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:33 --> Total execution time: 0.1838
DEBUG - 2022-11-10 09:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:37 --> Total execution time: 0.1800
DEBUG - 2022-11-10 09:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:41 --> Total execution time: 0.2363
DEBUG - 2022-11-10 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:44 --> Total execution time: 0.1861
DEBUG - 2022-11-10 09:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:03:58 --> Total execution time: 0.1684
DEBUG - 2022-11-10 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:18 --> Total execution time: 0.1712
DEBUG - 2022-11-10 09:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:25 --> Total execution time: 0.1905
DEBUG - 2022-11-10 09:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:34 --> Total execution time: 0.2047
DEBUG - 2022-11-10 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:35 --> Total execution time: 0.1727
DEBUG - 2022-11-10 09:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:47 --> Total execution time: 0.1811
DEBUG - 2022-11-10 09:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:57 --> Total execution time: 0.1791
DEBUG - 2022-11-10 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:04:58 --> Total execution time: 0.1809
DEBUG - 2022-11-10 09:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:03 --> Total execution time: 0.2144
DEBUG - 2022-11-10 09:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:05 --> Total execution time: 0.1918
DEBUG - 2022-11-10 09:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:10 --> Total execution time: 0.1711
DEBUG - 2022-11-10 09:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:15 --> Total execution time: 0.1725
DEBUG - 2022-11-10 09:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:16 --> Total execution time: 0.1708
DEBUG - 2022-11-10 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:24 --> Total execution time: 0.1737
DEBUG - 2022-11-10 09:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:28 --> Total execution time: 0.1815
DEBUG - 2022-11-10 09:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:31 --> Total execution time: 0.2140
DEBUG - 2022-11-10 09:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:33 --> Total execution time: 0.1654
DEBUG - 2022-11-10 09:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:36 --> Total execution time: 0.2030
DEBUG - 2022-11-10 09:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:38 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:38 --> Total execution time: 0.1109
DEBUG - 2022-11-10 09:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:38 --> Total execution time: 0.4352
DEBUG - 2022-11-10 09:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:42 --> Total execution time: 2.0111
DEBUG - 2022-11-10 09:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:45 --> Total execution time: 0.2008
DEBUG - 2022-11-10 09:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:50 --> Total execution time: 0.2814
DEBUG - 2022-11-10 09:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:05:55 --> Total execution time: 0.1678
DEBUG - 2022-11-10 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:00 --> Total execution time: 0.1721
DEBUG - 2022-11-10 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:02 --> Total execution time: 0.1758
DEBUG - 2022-11-10 09:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:06 --> Total execution time: 1.8013
DEBUG - 2022-11-10 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:10 --> Total execution time: 0.1920
DEBUG - 2022-11-10 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:11 --> Total execution time: 0.1739
DEBUG - 2022-11-10 09:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:16 --> Total execution time: 0.1651
DEBUG - 2022-11-10 09:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:18 --> Total execution time: 0.2055
DEBUG - 2022-11-10 09:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:20 --> Total execution time: 0.1789
DEBUG - 2022-11-10 09:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:22 --> Total execution time: 0.1791
DEBUG - 2022-11-10 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:24 --> Total execution time: 0.1753
DEBUG - 2022-11-10 09:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:25 --> Total execution time: 0.1779
DEBUG - 2022-11-10 09:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:30 --> Total execution time: 0.1138
DEBUG - 2022-11-10 21:06:31 --> Total execution time: 1.6688
DEBUG - 2022-11-10 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:31 --> Total execution time: 0.1992
DEBUG - 2022-11-10 09:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:31 --> Total execution time: 0.1794
DEBUG - 2022-11-10 09:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:34 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:34 --> Total execution time: 0.1068
DEBUG - 2022-11-10 09:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:35 --> Total execution time: 0.1075
DEBUG - 2022-11-10 09:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:38 --> Total execution time: 0.2025
DEBUG - 2022-11-10 09:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:41 --> Total execution time: 0.1692
DEBUG - 2022-11-10 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:49 --> Total execution time: 0.1711
DEBUG - 2022-11-10 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:52 --> Total execution time: 0.1667
DEBUG - 2022-11-10 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:53 --> Total execution time: 0.1820
DEBUG - 2022-11-10 09:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:58 --> Total execution time: 0.2516
DEBUG - 2022-11-10 09:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:06:58 --> Total execution time: 0.2002
DEBUG - 2022-11-10 21:06:59 --> Total execution time: 2.1066
DEBUG - 2022-11-10 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:01 --> Total execution time: 0.1999
DEBUG - 2022-11-10 09:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:02 --> Total execution time: 0.3088
DEBUG - 2022-11-10 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:04 --> Total execution time: 0.1760
DEBUG - 2022-11-10 09:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:10 --> Total execution time: 1.7478
DEBUG - 2022-11-10 09:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:11 --> Total execution time: 0.2146
DEBUG - 2022-11-10 09:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:12 --> Total execution time: 0.1701
DEBUG - 2022-11-10 09:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:27 --> Total execution time: 0.1801
DEBUG - 2022-11-10 09:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:30 --> Total execution time: 0.2041
DEBUG - 2022-11-10 09:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:30 --> Total execution time: 0.1801
DEBUG - 2022-11-10 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:38 --> Total execution time: 0.1759
DEBUG - 2022-11-10 09:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:42 --> Total execution time: 0.1818
DEBUG - 2022-11-10 09:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:48 --> Total execution time: 0.2047
DEBUG - 2022-11-10 09:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:07:53 --> Total execution time: 0.2242
DEBUG - 2022-11-10 09:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:26 --> Total execution time: 1.6758
DEBUG - 2022-11-10 09:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:34 --> Total execution time: 0.1745
DEBUG - 2022-11-10 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:38:39 --> Total execution time: 0.1792
DEBUG - 2022-11-10 09:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:38:40 --> Total execution time: 0.1680
DEBUG - 2022-11-10 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:48 --> Total execution time: 0.1669
DEBUG - 2022-11-10 09:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:49 --> Total execution time: 0.1769
DEBUG - 2022-11-10 09:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:56 --> Total execution time: 0.2318
DEBUG - 2022-11-10 09:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:08:58 --> Total execution time: 0.2333
DEBUG - 2022-11-10 09:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:24 --> Total execution time: 0.4599
DEBUG - 2022-11-10 09:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:33 --> Total execution time: 0.4394
DEBUG - 2022-11-10 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:47 --> Total execution time: 0.2208
DEBUG - 2022-11-10 09:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:52 --> Total execution time: 0.2138
DEBUG - 2022-11-10 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:56 --> Total execution time: 0.2249
DEBUG - 2022-11-10 09:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:09:59 --> Total execution time: 0.1748
DEBUG - 2022-11-10 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:06 --> Total execution time: 0.1874
DEBUG - 2022-11-10 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:13 --> Total execution time: 0.2059
DEBUG - 2022-11-10 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:27 --> Total execution time: 0.2145
DEBUG - 2022-11-10 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:29 --> Total execution time: 0.2195
DEBUG - 2022-11-10 09:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:31 --> Total execution time: 0.2057
DEBUG - 2022-11-10 09:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:34 --> Total execution time: 0.1732
DEBUG - 2022-11-10 09:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:34 --> Total execution time: 0.2187
DEBUG - 2022-11-10 09:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:36 --> Total execution time: 0.1694
DEBUG - 2022-11-10 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:10:42 --> Total execution time: 0.1656
DEBUG - 2022-11-10 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:11:31 --> Total execution time: 0.1741
DEBUG - 2022-11-10 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:12:59 --> Total execution time: 0.5653
DEBUG - 2022-11-10 09:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:01 --> Total execution time: 0.2241
DEBUG - 2022-11-10 09:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:04 --> Total execution time: 0.2281
DEBUG - 2022-11-10 09:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:07 --> Total execution time: 0.2215
DEBUG - 2022-11-10 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:40 --> Total execution time: 0.2126
DEBUG - 2022-11-10 09:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:46 --> Total execution time: 0.2032
DEBUG - 2022-11-10 09:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:48 --> Total execution time: 0.2593
DEBUG - 2022-11-10 09:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:51 --> Total execution time: 0.1848
DEBUG - 2022-11-10 09:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:13:56 --> Total execution time: 0.4409
DEBUG - 2022-11-10 09:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:14:00 --> Total execution time: 0.2238
DEBUG - 2022-11-10 09:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:07 --> Total execution time: 0.1786
DEBUG - 2022-11-10 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:09 --> Total execution time: 0.1833
DEBUG - 2022-11-10 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:09 --> Total execution time: 0.1722
DEBUG - 2022-11-10 09:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:14:11 --> Total execution time: 0.1989
DEBUG - 2022-11-10 09:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:14:15 --> Total execution time: 0.2108
DEBUG - 2022-11-10 09:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:14:30 --> Total execution time: 0.2149
DEBUG - 2022-11-10 09:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:45 --> Total execution time: 0.1783
DEBUG - 2022-11-10 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:48 --> Total execution time: 0.2026
DEBUG - 2022-11-10 09:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:44:48 --> Total execution time: 0.1649
DEBUG - 2022-11-10 09:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:45:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:15:04 --> Total execution time: 0.1141
DEBUG - 2022-11-10 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:15:08 --> Total execution time: 0.2122
DEBUG - 2022-11-10 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:15:45 --> Total execution time: 0.4893
DEBUG - 2022-11-10 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:46:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:16:56 --> Total execution time: 0.4635
DEBUG - 2022-11-10 09:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:17:05 --> Total execution time: 0.2209
DEBUG - 2022-11-10 09:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:17:17 --> Total execution time: 0.1047
DEBUG - 2022-11-10 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:13 --> Total execution time: 0.1932
DEBUG - 2022-11-10 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:13 --> Total execution time: 0.1087
DEBUG - 2022-11-10 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:13 --> Total execution time: 0.1124
DEBUG - 2022-11-10 09:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:30 --> Total execution time: 0.1041
DEBUG - 2022-11-10 09:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:38 --> Total execution time: 0.1667
DEBUG - 2022-11-10 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:39 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:39 --> Total execution time: 0.1678
DEBUG - 2022-11-10 09:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:40 --> Total execution time: 0.3919
DEBUG - 2022-11-10 09:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:42 --> Total execution time: 0.1641
DEBUG - 2022-11-10 09:48:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:42 --> Total execution time: 0.3906
DEBUG - 2022-11-10 09:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:18:50 --> Total execution time: 0.1695
DEBUG - 2022-11-10 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:49:02 --> Total execution time: 0.4834
DEBUG - 2022-11-10 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:49:04 --> Total execution time: 0.1585
DEBUG - 2022-11-10 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:19:04 --> Total execution time: 0.1711
DEBUG - 2022-11-10 09:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:49:04 --> Total execution time: 0.1665
DEBUG - 2022-11-10 09:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:19:16 --> Total execution time: 0.1043
DEBUG - 2022-11-10 09:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:49:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:49:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:19:54 --> Total execution time: 0.4794
DEBUG - 2022-11-10 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:50:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:20:09 --> Total execution time: 2.1264
DEBUG - 2022-11-10 09:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:50:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:20:17 --> Total execution time: 0.1732
DEBUG - 2022-11-10 09:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:50:18 --> Total execution time: 0.1691
DEBUG - 2022-11-10 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:50:21 --> Total execution time: 0.1804
DEBUG - 2022-11-10 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:50:21 --> Total execution time: 0.1797
DEBUG - 2022-11-10 09:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:21:18 --> Total execution time: 0.4556
DEBUG - 2022-11-10 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:51:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:21:25 --> Total execution time: 0.1652
DEBUG - 2022-11-10 09:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:22:00 --> Total execution time: 0.0978
DEBUG - 2022-11-10 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:05 --> Total execution time: 0.1591
DEBUG - 2022-11-10 09:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:52:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:22:57 --> Total execution time: 0.1044
DEBUG - 2022-11-10 09:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:53:02 --> Total execution time: 0.2802
DEBUG - 2022-11-10 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:53:50 --> Total execution time: 0.1667
DEBUG - 2022-11-10 09:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:53:50 --> Total execution time: 0.3995
DEBUG - 2022-11-10 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:23:57 --> Total execution time: 0.1679
DEBUG - 2022-11-10 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:54:05 --> Total execution time: 0.1647
DEBUG - 2022-11-10 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:54:18 --> Total execution time: 0.1811
DEBUG - 2022-11-10 09:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:54:18 --> Total execution time: 0.3615
DEBUG - 2022-11-10 09:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:54:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:24:43 --> Total execution time: 0.1121
DEBUG - 2022-11-10 09:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:25:05 --> Total execution time: 0.1730
DEBUG - 2022-11-10 09:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:25:14 --> Total execution time: 0.2542
DEBUG - 2022-11-10 09:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:25:18 --> Total execution time: 0.1244
DEBUG - 2022-11-10 09:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:25:48 --> Total execution time: 0.1816
DEBUG - 2022-11-10 09:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:55:48 --> Total execution time: 0.1761
DEBUG - 2022-11-10 09:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:55:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:55:59 --> Total execution time: 0.1679
DEBUG - 2022-11-10 09:56:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:56:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:56:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:56:01 --> Total execution time: 0.1767
DEBUG - 2022-11-10 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:56:02 --> Total execution time: 0.2427
DEBUG - 2022-11-10 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:56:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:26:40 --> Total execution time: 0.1629
DEBUG - 2022-11-10 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:27:12 --> Total execution time: 0.2012
DEBUG - 2022-11-10 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:57:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:27:14 --> Total execution time: 0.1704
DEBUG - 2022-11-10 09:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:58:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:28:02 --> Total execution time: 0.1075
DEBUG - 2022-11-10 09:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:58:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:28:04 --> Total execution time: 0.4846
DEBUG - 2022-11-10 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:28:27 --> Total execution time: 0.1681
DEBUG - 2022-11-10 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 09:58:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:59:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:29:12 --> Total execution time: 0.1654
DEBUG - 2022-11-10 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:59:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 09:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:29:22 --> Total execution time: 0.4403
DEBUG - 2022-11-10 09:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:29:26 --> Total execution time: 0.1870
DEBUG - 2022-11-10 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 09:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:29:55 --> Total execution time: 0.1610
DEBUG - 2022-11-10 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:03 --> Total execution time: 0.1473
DEBUG - 2022-11-10 10:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:03 --> Total execution time: 0.1732
DEBUG - 2022-11-10 10:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:06 --> Total execution time: 0.1080
DEBUG - 2022-11-10 10:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:12 --> Total execution time: 0.1787
DEBUG - 2022-11-10 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:16 --> Total execution time: 0.1780
DEBUG - 2022-11-10 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:46 --> Total execution time: 0.1729
DEBUG - 2022-11-10 10:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:30:57 --> Total execution time: 0.1105
DEBUG - 2022-11-10 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:02 --> Total execution time: 0.1913
DEBUG - 2022-11-10 10:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:06 --> Total execution time: 0.1072
DEBUG - 2022-11-10 10:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:14 --> Total execution time: 0.1767
DEBUG - 2022-11-10 10:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:19 --> Total execution time: 0.1765
DEBUG - 2022-11-10 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:22 --> Total execution time: 0.2148
DEBUG - 2022-11-10 10:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:30 --> Total execution time: 0.1791
DEBUG - 2022-11-10 10:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:35 --> Total execution time: 0.1685
DEBUG - 2022-11-10 10:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:44 --> Total execution time: 0.1832
DEBUG - 2022-11-10 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:47 --> Total execution time: 0.2059
DEBUG - 2022-11-10 21:31:49 --> Total execution time: 1.6617
DEBUG - 2022-11-10 10:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:31:53 --> Total execution time: 0.1631
DEBUG - 2022-11-10 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:16 --> Total execution time: 0.1837
DEBUG - 2022-11-10 10:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:17 --> Total execution time: 0.1867
DEBUG - 2022-11-10 10:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:02:20 --> Total execution time: 0.5770
DEBUG - 2022-11-10 10:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:22 --> Total execution time: 0.2045
DEBUG - 2022-11-10 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:02:23 --> Total execution time: 0.1805
DEBUG - 2022-11-10 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:02:24 --> Total execution time: 0.1741
DEBUG - 2022-11-10 10:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:30 --> Total execution time: 0.1791
DEBUG - 2022-11-10 10:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:39 --> Total execution time: 0.2312
DEBUG - 2022-11-10 10:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:40 --> Total execution time: 0.1676
DEBUG - 2022-11-10 10:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:32:47 --> Total execution time: 0.1599
DEBUG - 2022-11-10 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:15 --> Total execution time: 0.1637
DEBUG - 2022-11-10 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:03:26 --> Total execution time: 0.1655
DEBUG - 2022-11-10 10:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:28 --> Total execution time: 0.1853
DEBUG - 2022-11-10 10:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:03:29 --> Total execution time: 0.1666
DEBUG - 2022-11-10 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:03:29 --> Total execution time: 0.1788
DEBUG - 2022-11-10 10:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:32 --> Total execution time: 0.2058
DEBUG - 2022-11-10 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:35 --> Total execution time: 0.1101
DEBUG - 2022-11-10 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:38 --> Total execution time: 0.1063
DEBUG - 2022-11-10 10:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:49 --> Total execution time: 0.2685
DEBUG - 2022-11-10 10:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:52 --> Total execution time: 0.2104
DEBUG - 2022-11-10 10:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:03:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:33:58 --> Total execution time: 0.1706
DEBUG - 2022-11-10 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:09 --> Total execution time: 0.1210
DEBUG - 2022-11-10 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:13 --> Total execution time: 0.1683
DEBUG - 2022-11-10 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:14 --> Total execution time: 0.1692
DEBUG - 2022-11-10 10:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:22 --> Total execution time: 0.1658
DEBUG - 2022-11-10 10:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:23 --> Total execution time: 0.1656
DEBUG - 2022-11-10 10:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:34:57 --> Total execution time: 0.1724
DEBUG - 2022-11-10 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:06 --> Total execution time: 0.5529
DEBUG - 2022-11-10 10:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:07 --> Total execution time: 0.1975
DEBUG - 2022-11-10 10:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:09 --> Total execution time: 0.1807
DEBUG - 2022-11-10 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:12 --> Total execution time: 0.1651
DEBUG - 2022-11-10 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:13 --> Total execution time: 0.4419
DEBUG - 2022-11-10 10:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:19 --> Total execution time: 0.2339
DEBUG - 2022-11-10 10:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:20 --> Total execution time: 0.2068
DEBUG - 2022-11-10 10:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:26 --> Total execution time: 0.2065
DEBUG - 2022-11-10 10:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:33 --> Total execution time: 0.1626
DEBUG - 2022-11-10 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:34 --> Total execution time: 0.1802
DEBUG - 2022-11-10 10:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:44 --> Total execution time: 0.1682
DEBUG - 2022-11-10 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:46 --> Total execution time: 0.1776
DEBUG - 2022-11-10 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:48 --> Total execution time: 0.1689
DEBUG - 2022-11-10 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:50 --> Total execution time: 0.2063
DEBUG - 2022-11-10 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:56 --> Total execution time: 0.2009
DEBUG - 2022-11-10 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:35:57 --> Total execution time: 0.1714
DEBUG - 2022-11-10 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:36:06 --> Total execution time: 0.2206
DEBUG - 2022-11-10 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:36:18 --> Total execution time: 0.1786
DEBUG - 2022-11-10 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:36:29 --> Total execution time: 0.2066
DEBUG - 2022-11-10 10:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:36:38 --> Total execution time: 0.4455
DEBUG - 2022-11-10 10:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:36:43 --> Total execution time: 0.2113
DEBUG - 2022-11-10 10:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:06:49 --> Total execution time: 0.1696
DEBUG - 2022-11-10 10:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:37:04 --> Total execution time: 0.1688
DEBUG - 2022-11-10 10:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:37:04 --> Total execution time: 0.1773
DEBUG - 2022-11-10 10:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:37:14 --> Total execution time: 0.1886
DEBUG - 2022-11-10 10:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:37:50 --> Total execution time: 0.1971
DEBUG - 2022-11-10 10:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:38:06 --> Total execution time: 0.1693
DEBUG - 2022-11-10 10:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:38:29 --> Total execution time: 0.2011
DEBUG - 2022-11-10 10:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:38:43 --> Total execution time: 0.1809
DEBUG - 2022-11-10 10:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:38:57 --> Total execution time: 0.1843
DEBUG - 2022-11-10 10:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:09 --> Total execution time: 0.1899
DEBUG - 2022-11-10 10:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:18 --> Total execution time: 0.1716
DEBUG - 2022-11-10 10:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:19 --> Total execution time: 0.1667
DEBUG - 2022-11-10 10:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:21 --> Total execution time: 0.1855
DEBUG - 2022-11-10 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:09:23 --> Total execution time: 0.1674
DEBUG - 2022-11-10 10:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:09:26 --> Total execution time: 0.1836
DEBUG - 2022-11-10 10:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:09:26 --> Total execution time: 0.1798
DEBUG - 2022-11-10 10:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:09:35 --> Total execution time: 0.1195
DEBUG - 2022-11-10 10:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:37 --> Total execution time: 0.2252
DEBUG - 2022-11-10 10:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:39:42 --> Total execution time: 0.1675
DEBUG - 2022-11-10 10:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:02 --> Total execution time: 0.3627
DEBUG - 2022-11-10 10:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:10 --> Total execution time: 0.1822
DEBUG - 2022-11-10 10:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:12 --> Total execution time: 0.2106
DEBUG - 2022-11-10 10:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:23 --> Total execution time: 0.4494
DEBUG - 2022-11-10 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:29 --> Total execution time: 0.1712
DEBUG - 2022-11-10 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:37 --> Total execution time: 0.2009
DEBUG - 2022-11-10 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:37 --> Total execution time: 0.1860
DEBUG - 2022-11-10 10:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:10:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 10:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:48 --> Total execution time: 0.1741
DEBUG - 2022-11-10 10:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:54 --> Total execution time: 0.1835
DEBUG - 2022-11-10 10:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:40:55 --> Total execution time: 0.1113
DEBUG - 2022-11-10 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:00 --> Total execution time: 0.1701
DEBUG - 2022-11-10 10:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:02 --> Total execution time: 0.1056
DEBUG - 2022-11-10 10:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:21 --> Total execution time: 0.1756
DEBUG - 2022-11-10 10:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:23 --> Total execution time: 0.1833
DEBUG - 2022-11-10 10:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:27 --> Total execution time: 0.1758
DEBUG - 2022-11-10 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:28 --> Total execution time: 0.1519
DEBUG - 2022-11-10 10:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:11:29 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:29 --> Total execution time: 0.1756
DEBUG - 2022-11-10 10:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:41:29 --> Total execution time: 0.1239
DEBUG - 2022-11-10 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:42:11 --> Total execution time: 0.1576
DEBUG - 2022-11-10 10:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:13:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:43:13 --> Total execution time: 0.1821
DEBUG - 2022-11-10 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:43:58 --> Total execution time: 0.1167
DEBUG - 2022-11-10 10:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:45:10 --> Total execution time: 0.1828
DEBUG - 2022-11-10 10:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:45:18 --> Total execution time: 0.2056
DEBUG - 2022-11-10 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:45:31 --> Total execution time: 0.4296
DEBUG - 2022-11-10 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:45:38 --> Total execution time: 0.1576
DEBUG - 2022-11-10 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:46:18 --> Total execution time: 0.1652
DEBUG - 2022-11-10 10:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:46:31 --> Total execution time: 0.1796
DEBUG - 2022-11-10 10:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:46:34 --> Total execution time: 0.1705
DEBUG - 2022-11-10 10:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:42 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:46:43 --> Total execution time: 0.4608
DEBUG - 2022-11-10 10:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:16:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:46:50 --> Total execution time: 0.1906
DEBUG - 2022-11-10 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:47:05 --> Total execution time: 0.1631
DEBUG - 2022-11-10 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:17:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:47:37 --> Total execution time: 0.1684
DEBUG - 2022-11-10 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:17:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:17:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 10:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:05 --> Total execution time: 0.2084
DEBUG - 2022-11-10 10:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:11 --> Total execution time: 0.1660
DEBUG - 2022-11-10 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:16 --> Total execution time: 0.1668
DEBUG - 2022-11-10 10:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:19 --> Total execution time: 0.1618
DEBUG - 2022-11-10 10:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:24 --> Total execution time: 0.1574
DEBUG - 2022-11-10 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:36 --> Total execution time: 0.1700
DEBUG - 2022-11-10 10:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:48:44 --> Total execution time: 0.1787
DEBUG - 2022-11-10 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:19:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:49:05 --> Total execution time: 0.1726
DEBUG - 2022-11-10 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:19:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:49:07 --> Total execution time: 0.1643
DEBUG - 2022-11-10 10:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:20:33 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:50:33 --> Total execution time: 0.4533
DEBUG - 2022-11-10 10:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:20:48 --> Total execution time: 0.1773
DEBUG - 2022-11-10 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:20:50 --> Total execution time: 0.1857
DEBUG - 2022-11-10 10:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:20:51 --> Total execution time: 0.1693
DEBUG - 2022-11-10 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:21:17 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:51:17 --> Total execution time: 0.4383
DEBUG - 2022-11-10 10:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:51:22 --> Total execution time: 0.1668
DEBUG - 2022-11-10 10:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:06 --> Total execution time: 0.4552
DEBUG - 2022-11-10 10:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:15 --> Total execution time: 0.1724
DEBUG - 2022-11-10 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:22 --> Total execution time: 0.1709
DEBUG - 2022-11-10 10:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:23 --> Total execution time: 0.1657
DEBUG - 2022-11-10 10:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:23 --> Total execution time: 0.2396
DEBUG - 2022-11-10 10:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:27 --> Total execution time: 0.1727
DEBUG - 2022-11-10 10:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:37 --> Total execution time: 0.4649
DEBUG - 2022-11-10 10:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:46 --> Total execution time: 2.1553
DEBUG - 2022-11-10 10:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:52:59 --> Total execution time: 0.2068
DEBUG - 2022-11-10 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:53:25 --> Total execution time: 0.1667
DEBUG - 2022-11-10 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:07 --> Total execution time: 0.1847
DEBUG - 2022-11-10 10:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:10 --> Total execution time: 0.3543
DEBUG - 2022-11-10 10:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:42 --> Total execution time: 0.1742
DEBUG - 2022-11-10 10:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:44 --> Total execution time: 0.7566
DEBUG - 2022-11-10 10:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:44 --> Total execution time: 0.2141
DEBUG - 2022-11-10 10:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:54:48 --> Total execution time: 0.1973
DEBUG - 2022-11-10 10:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:01 --> Total execution time: 0.2656
DEBUG - 2022-11-10 10:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:10 --> Total execution time: 0.1707
DEBUG - 2022-11-10 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:24 --> Total execution time: 0.1981
DEBUG - 2022-11-10 10:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:28 --> Total execution time: 0.1957
DEBUG - 2022-11-10 10:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:29 --> Total execution time: 0.1690
DEBUG - 2022-11-10 10:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:38 --> Total execution time: 0.1781
DEBUG - 2022-11-10 10:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:41 --> Total execution time: 0.4494
DEBUG - 2022-11-10 10:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:42 --> Total execution time: 0.1811
DEBUG - 2022-11-10 10:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:55:51 --> Total execution time: 0.1735
DEBUG - 2022-11-10 10:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:56:07 --> Total execution time: 0.1633
DEBUG - 2022-11-10 10:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:56:33 --> Total execution time: 0.4555
DEBUG - 2022-11-10 10:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:56:39 --> Total execution time: 0.1705
DEBUG - 2022-11-10 10:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:57:03 --> Total execution time: 0.2062
DEBUG - 2022-11-10 10:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:57:05 --> Total execution time: 0.4376
DEBUG - 2022-11-10 10:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:57:21 --> Total execution time: 0.1622
DEBUG - 2022-11-10 10:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:57:27 --> Total execution time: 0.1652
DEBUG - 2022-11-10 10:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:28:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:58:13 --> Total execution time: 0.1698
DEBUG - 2022-11-10 10:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:58:23 --> Total execution time: 0.3104
DEBUG - 2022-11-10 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:28:50 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:28:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 21:58:51 --> Total execution time: 0.1132
DEBUG - 2022-11-10 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:05 --> Total execution time: 0.4508
DEBUG - 2022-11-10 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:06 --> Total execution time: 0.1653
DEBUG - 2022-11-10 10:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:10 --> Total execution time: 0.1921
DEBUG - 2022-11-10 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:17 --> Total execution time: 0.1670
DEBUG - 2022-11-10 10:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:18 --> Total execution time: 0.2550
DEBUG - 2022-11-10 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:18 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:18 --> Total execution time: 0.1247
DEBUG - 2022-11-10 10:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:19 --> Total execution time: 0.1699
DEBUG - 2022-11-10 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:26 --> Total execution time: 0.1715
DEBUG - 2022-11-10 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:40 --> Total execution time: 0.1803
DEBUG - 2022-11-10 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:46 --> Total execution time: 0.1022
DEBUG - 2022-11-10 10:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:51 --> Total execution time: 0.2306
DEBUG - 2022-11-10 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:00:55 --> Total execution time: 0.1797
DEBUG - 2022-11-10 10:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:01:16 --> Total execution time: 0.1986
DEBUG - 2022-11-10 10:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:01:28 --> Total execution time: 0.2094
DEBUG - 2022-11-10 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:31:30 --> Total execution time: 0.1770
DEBUG - 2022-11-10 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:31:33 --> Total execution time: 0.1712
DEBUG - 2022-11-10 10:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:31:34 --> Total execution time: 0.1619
DEBUG - 2022-11-10 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:01:38 --> Total execution time: 0.1611
DEBUG - 2022-11-10 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:01:45 --> Total execution time: 0.2133
DEBUG - 2022-11-10 10:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:02:17 --> Total execution time: 0.2053
DEBUG - 2022-11-10 10:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:02:18 --> Total execution time: 0.2507
DEBUG - 2022-11-10 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:02:24 --> Total execution time: 0.2006
DEBUG - 2022-11-10 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:02:26 --> Total execution time: 0.1750
DEBUG - 2022-11-10 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:03:25 --> Total execution time: 0.1117
DEBUG - 2022-11-10 10:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:33:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:03:39 --> Total execution time: 0.1850
DEBUG - 2022-11-10 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:03:47 --> Total execution time: 0.2347
DEBUG - 2022-11-10 10:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:03:48 --> Total execution time: 0.2132
DEBUG - 2022-11-10 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:33:53 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 10:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:33:54 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 10:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:33:56 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 10:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:04 --> Total execution time: 0.1197
DEBUG - 2022-11-10 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:09 --> Total execution time: 0.1702
DEBUG - 2022-11-10 10:34:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:10 --> Total execution time: 0.1651
DEBUG - 2022-11-10 10:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:11 --> Total execution time: 0.1701
DEBUG - 2022-11-10 10:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:17 --> Total execution time: 0.1706
DEBUG - 2022-11-10 10:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:23 --> Total execution time: 0.1739
DEBUG - 2022-11-10 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:26 --> Total execution time: 0.2097
DEBUG - 2022-11-10 10:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:33 --> Total execution time: 0.2023
DEBUG - 2022-11-10 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:39 --> Total execution time: 0.1734
DEBUG - 2022-11-10 10:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:44 --> Total execution time: 0.1744
DEBUG - 2022-11-10 10:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:50 --> Total execution time: 0.4542
DEBUG - 2022-11-10 10:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:51 --> Total execution time: 0.1656
DEBUG - 2022-11-10 10:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:52 --> Total execution time: 0.1070
DEBUG - 2022-11-10 10:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:04:57 --> Total execution time: 0.1734
DEBUG - 2022-11-10 10:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:05:07 --> Total execution time: 1.8565
DEBUG - 2022-11-10 10:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:05:09 --> Total execution time: 1.3405
DEBUG - 2022-11-10 10:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:35:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 10:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:05:15 --> Total execution time: 0.1737
DEBUG - 2022-11-10 10:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 10:35:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 10:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:05:24 --> Total execution time: 0.1720
DEBUG - 2022-11-10 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:05:57 --> Total execution time: 0.1897
DEBUG - 2022-11-10 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:06:22 --> Total execution time: 0.1378
DEBUG - 2022-11-10 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:06:43 --> Total execution time: 0.1186
DEBUG - 2022-11-10 10:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:06:43 --> Total execution time: 0.1143
DEBUG - 2022-11-10 22:06:43 --> Total execution time: 0.1505
DEBUG - 2022-11-10 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:06:44 --> Total execution time: 0.1121
DEBUG - 2022-11-10 10:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:06:44 --> Total execution time: 0.1639
DEBUG - 2022-11-10 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:08 --> Total execution time: 0.4522
DEBUG - 2022-11-10 10:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:23 --> Total execution time: 0.1894
DEBUG - 2022-11-10 10:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:53 --> Total execution time: 0.1855
DEBUG - 2022-11-10 10:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:55 --> Total execution time: 0.1797
DEBUG - 2022-11-10 10:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:56 --> Total execution time: 0.2327
DEBUG - 2022-11-10 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:37:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:07:59 --> Total execution time: 0.1752
DEBUG - 2022-11-10 10:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:38:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:08:21 --> Total execution time: 0.1856
DEBUG - 2022-11-10 10:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:38:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:08:58 --> Total execution time: 0.1682
DEBUG - 2022-11-10 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:38:59 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:38:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:08:59 --> Total execution time: 0.1713
DEBUG - 2022-11-10 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:39:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:09:01 --> Total execution time: 0.1027
DEBUG - 2022-11-10 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:39:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:09:06 --> Total execution time: 0.1701
DEBUG - 2022-11-10 10:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:09:42 --> Total execution time: 0.1016
DEBUG - 2022-11-10 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:40:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:10:44 --> Total execution time: 0.1070
DEBUG - 2022-11-10 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:40:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:10:50 --> Total execution time: 0.1775
DEBUG - 2022-11-10 10:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:11:05 --> Total execution time: 0.1797
DEBUG - 2022-11-10 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:41:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:11:44 --> Total execution time: 0.1173
DEBUG - 2022-11-10 10:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:42:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:12:21 --> Total execution time: 0.1065
DEBUG - 2022-11-10 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:43:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:13:41 --> Total execution time: 0.1091
DEBUG - 2022-11-10 10:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:13:43 --> Total execution time: 0.1748
DEBUG - 2022-11-10 10:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:14:05 --> Total execution time: 0.1729
DEBUG - 2022-11-10 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:14:08 --> Total execution time: 0.1762
DEBUG - 2022-11-10 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:14:15 --> Total execution time: 0.2359
DEBUG - 2022-11-10 10:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:14:45 --> Total execution time: 0.1351
DEBUG - 2022-11-10 10:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:44:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:14:46 --> Total execution time: 0.1009
DEBUG - 2022-11-10 10:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:45:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:15:21 --> Total execution time: 0.1076
DEBUG - 2022-11-10 10:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:47:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:17:31 --> Total execution time: 0.4450
DEBUG - 2022-11-10 10:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:17:39 --> Total execution time: 0.2000
DEBUG - 2022-11-10 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:17:43 --> Total execution time: 0.1689
DEBUG - 2022-11-10 10:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:18:22 --> Total execution time: 0.1785
DEBUG - 2022-11-10 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:21:15 --> Total execution time: 0.8159
DEBUG - 2022-11-10 10:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:21:32 --> Total execution time: 0.1693
DEBUG - 2022-11-10 10:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:52:10 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:22:10 --> Total execution time: 0.1119
DEBUG - 2022-11-10 10:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:52:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:22:45 --> Total execution time: 0.1714
DEBUG - 2022-11-10 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:53:52 --> Total execution time: 0.1876
DEBUG - 2022-11-10 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:54:10 --> Total execution time: 0.2137
DEBUG - 2022-11-10 10:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:55:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:25:53 --> Total execution time: 4.8619
DEBUG - 2022-11-10 10:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:06 --> Total execution time: 0.1702
DEBUG - 2022-11-10 10:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:13 --> Total execution time: 0.2552
DEBUG - 2022-11-10 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:15 --> Total execution time: 0.1800
DEBUG - 2022-11-10 10:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:29 --> Total execution time: 0.2343
DEBUG - 2022-11-10 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:32 --> Total execution time: 0.2465
DEBUG - 2022-11-10 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:26:55 --> Total execution time: 0.6117
DEBUG - 2022-11-10 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:57:45 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:27:47 --> Total execution time: 1.9897
DEBUG - 2022-11-10 10:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:27:59 --> Total execution time: 0.8638
DEBUG - 2022-11-10 10:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:28:20 --> Total execution time: 0.1962
DEBUG - 2022-11-10 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:28:26 --> Total execution time: 0.2506
DEBUG - 2022-11-10 10:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:28:36 --> Total execution time: 0.1808
DEBUG - 2022-11-10 10:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:28:37 --> Total execution time: 0.1766
DEBUG - 2022-11-10 10:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 10:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:28:44 --> Total execution time: 0.1106
DEBUG - 2022-11-10 10:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:58:55 --> Total execution time: 0.1714
DEBUG - 2022-11-10 10:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:58:58 --> Total execution time: 0.2200
DEBUG - 2022-11-10 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 10:58:58 --> Total execution time: 0.1849
DEBUG - 2022-11-10 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:30:02 --> Total execution time: 0.2558
DEBUG - 2022-11-10 11:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:30:03 --> Total execution time: 0.2352
DEBUG - 2022-11-10 11:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:30:27 --> Total execution time: 2.2644
DEBUG - 2022-11-10 11:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:02 --> Total execution time: 0.1307
DEBUG - 2022-11-10 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:05 --> Total execution time: 0.1688
DEBUG - 2022-11-10 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:06 --> Total execution time: 0.3257
DEBUG - 2022-11-10 11:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:14 --> Total execution time: 0.5132
DEBUG - 2022-11-10 11:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:15 --> Total execution time: 0.1757
DEBUG - 2022-11-10 11:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:18 --> Total execution time: 0.1716
DEBUG - 2022-11-10 11:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:20 --> Total execution time: 0.1658
DEBUG - 2022-11-10 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:21 --> Total execution time: 0.2021
DEBUG - 2022-11-10 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:55 --> Total execution time: 0.1265
DEBUG - 2022-11-10 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:55 --> Total execution time: 0.1698
DEBUG - 2022-11-10 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:01:55 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:31:56 --> Total execution time: 0.1723
DEBUG - 2022-11-10 11:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:02:15 --> Total execution time: 0.1738
DEBUG - 2022-11-10 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:32:48 --> Total execution time: 0.1604
DEBUG - 2022-11-10 11:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:32:52 --> Total execution time: 0.1627
DEBUG - 2022-11-10 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:06 --> Total execution time: 0.1784
DEBUG - 2022-11-10 11:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:08 --> Total execution time: 0.1897
DEBUG - 2022-11-10 11:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:11 --> Total execution time: 2.0946
DEBUG - 2022-11-10 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:17 --> Total execution time: 0.6006
DEBUG - 2022-11-10 11:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:21 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:21 --> Total execution time: 0.1110
DEBUG - 2022-11-10 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:25 --> Total execution time: 0.1665
DEBUG - 2022-11-10 11:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:26 --> Total execution time: 0.1949
DEBUG - 2022-11-10 11:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:27 --> Total execution time: 0.1750
DEBUG - 2022-11-10 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:31 --> Total execution time: 0.1842
DEBUG - 2022-11-10 11:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:35 --> Total execution time: 0.1724
DEBUG - 2022-11-10 11:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:35 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:35 --> Total execution time: 0.1658
DEBUG - 2022-11-10 11:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:38 --> Total execution time: 0.1617
DEBUG - 2022-11-10 11:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:41 --> Total execution time: 0.1681
DEBUG - 2022-11-10 11:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:03:42 --> Total execution time: 0.3836
DEBUG - 2022-11-10 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:03:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:33:58 --> Total execution time: 0.1229
DEBUG - 2022-11-10 11:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:09 --> Total execution time: 0.1787
DEBUG - 2022-11-10 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:10 --> Total execution time: 0.1704
DEBUG - 2022-11-10 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:11 --> Total execution time: 0.1791
DEBUG - 2022-11-10 11:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:11 --> Total execution time: 0.3861
DEBUG - 2022-11-10 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:12 --> Total execution time: 0.1664
DEBUG - 2022-11-10 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:13 --> Total execution time: 0.1637
DEBUG - 2022-11-10 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:21 --> Total execution time: 0.1723
DEBUG - 2022-11-10 11:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:22 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:22 --> Total execution time: 0.1684
DEBUG - 2022-11-10 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:27 --> Total execution time: 0.1677
DEBUG - 2022-11-10 11:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:32 --> Total execution time: 0.1675
DEBUG - 2022-11-10 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:32 --> Total execution time: 0.1739
DEBUG - 2022-11-10 11:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:34 --> Total execution time: 0.1810
DEBUG - 2022-11-10 11:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:39 --> Total execution time: 0.2854
DEBUG - 2022-11-10 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:39 --> Total execution time: 0.2023
DEBUG - 2022-11-10 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:48 --> Total execution time: 0.1666
DEBUG - 2022-11-10 11:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:34:55 --> Total execution time: 0.1728
DEBUG - 2022-11-10 11:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:01 --> Total execution time: 0.1778
DEBUG - 2022-11-10 11:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:05 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:05 --> Total execution time: 0.1196
DEBUG - 2022-11-10 11:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:06 --> Total execution time: 0.1703
DEBUG - 2022-11-10 11:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:09 --> Total execution time: 0.1768
DEBUG - 2022-11-10 11:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:12 --> Total execution time: 0.1957
DEBUG - 2022-11-10 11:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:13 --> Total execution time: 0.2489
DEBUG - 2022-11-10 11:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:20 --> Total execution time: 0.1763
DEBUG - 2022-11-10 11:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:20 --> Total execution time: 0.1642
DEBUG - 2022-11-10 11:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:27 --> Total execution time: 0.2056
DEBUG - 2022-11-10 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:28 --> Total execution time: 0.1798
DEBUG - 2022-11-10 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:35 --> Total execution time: 0.1776
DEBUG - 2022-11-10 11:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:37 --> Total execution time: 0.2017
DEBUG - 2022-11-10 11:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:37 --> Total execution time: 0.1715
DEBUG - 2022-11-10 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:37 --> Total execution time: 0.1689
DEBUG - 2022-11-10 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:48 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 22:35:48 --> Total execution time: 0.1836
DEBUG - 2022-11-10 11:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:48 --> Total execution time: 0.1202
DEBUG - 2022-11-10 11:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:57 --> Total execution time: 0.1035
DEBUG - 2022-11-10 11:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:35:57 --> Total execution time: 0.1788
DEBUG - 2022-11-10 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:08 --> Total execution time: 0.1675
DEBUG - 2022-11-10 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:17 --> Total execution time: 0.1810
DEBUG - 2022-11-10 11:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:22 --> Total execution time: 0.1764
DEBUG - 2022-11-10 11:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:24 --> Total execution time: 1.9294
DEBUG - 2022-11-10 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 11:06:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:34 --> Total execution time: 0.1745
DEBUG - 2022-11-10 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:42 --> Total execution time: 0.1778
DEBUG - 2022-11-10 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:36:44 --> Total execution time: 0.1736
DEBUG - 2022-11-10 11:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:01 --> Total execution time: 0.1979
DEBUG - 2022-11-10 11:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:03 --> Total execution time: 0.3253
DEBUG - 2022-11-10 11:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:05 --> Total execution time: 0.1707
DEBUG - 2022-11-10 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:10 --> Total execution time: 0.1761
DEBUG - 2022-11-10 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:18 --> Total execution time: 0.2050
DEBUG - 2022-11-10 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:22 --> Total execution time: 0.2174
DEBUG - 2022-11-10 11:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:37:51 --> Total execution time: 0.1741
DEBUG - 2022-11-10 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:38:18 --> Total execution time: 0.1813
DEBUG - 2022-11-10 11:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:38:25 --> Total execution time: 0.4985
DEBUG - 2022-11-10 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:38:29 --> Total execution time: 0.1775
DEBUG - 2022-11-10 11:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:39:57 --> Total execution time: 0.5413
DEBUG - 2022-11-10 11:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:03 --> Total execution time: 0.1822
DEBUG - 2022-11-10 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:09 --> Total execution time: 0.1984
DEBUG - 2022-11-10 11:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:10 --> Total execution time: 0.4633
DEBUG - 2022-11-10 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:11 --> Total execution time: 0.1766
DEBUG - 2022-11-10 11:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:12 --> Total execution time: 0.2519
DEBUG - 2022-11-10 11:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:13 --> Total execution time: 0.1987
DEBUG - 2022-11-10 11:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:22 --> Total execution time: 0.1936
DEBUG - 2022-11-10 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:35 --> Total execution time: 0.1830
DEBUG - 2022-11-10 11:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:36 --> Total execution time: 0.1769
DEBUG - 2022-11-10 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:39 --> Total execution time: 0.2105
DEBUG - 2022-11-10 11:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:45 --> Total execution time: 0.1739
DEBUG - 2022-11-10 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:51 --> Total execution time: 0.1680
DEBUG - 2022-11-10 11:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:53 --> Total execution time: 0.1784
DEBUG - 2022-11-10 11:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:10:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:40:56 --> Total execution time: 0.1791
DEBUG - 2022-11-10 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:03 --> Total execution time: 0.2282
DEBUG - 2022-11-10 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:04 --> Total execution time: 0.2049
DEBUG - 2022-11-10 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:12 --> Total execution time: 0.1723
DEBUG - 2022-11-10 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:13 --> Total execution time: 0.1681
DEBUG - 2022-11-10 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:13 --> Total execution time: 0.2869
DEBUG - 2022-11-10 11:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:11:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:41:14 --> Total execution time: 0.1675
DEBUG - 2022-11-10 11:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:04 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:05 --> Total execution time: 0.8669
DEBUG - 2022-11-10 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:16 --> Total execution time: 0.1789
DEBUG - 2022-11-10 11:16:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:16 --> Total execution time: 0.4452
DEBUG - 2022-11-10 11:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:19 --> Total execution time: 0.1660
DEBUG - 2022-11-10 11:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:31 --> Total execution time: 0.2426
DEBUG - 2022-11-10 11:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:32 --> Total execution time: 0.1766
DEBUG - 2022-11-10 11:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:46:37 --> Total execution time: 0.2503
DEBUG - 2022-11-10 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:19:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:49:51 --> Total execution time: 0.1366
DEBUG - 2022-11-10 11:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:20:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:50:44 --> Total execution time: 0.4486
DEBUG - 2022-11-10 11:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:21:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:51:02 --> Total execution time: 0.1976
DEBUG - 2022-11-10 11:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:21:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:51:03 --> Total execution time: 0.1766
DEBUG - 2022-11-10 11:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:21:13 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:51:13 --> Total execution time: 0.1705
DEBUG - 2022-11-10 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:51:49 --> Total execution time: 3.0742
DEBUG - 2022-11-10 11:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:52:35 --> Total execution time: 1.0484
DEBUG - 2022-11-10 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:22:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:22:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:52:53 --> Total execution time: 0.4823
DEBUG - 2022-11-10 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:22:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:00 --> Total execution time: 0.1948
DEBUG - 2022-11-10 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:09 --> Total execution time: 0.1737
DEBUG - 2022-11-10 11:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:09 --> Total execution time: 0.2098
DEBUG - 2022-11-10 11:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:15 --> Total execution time: 0.1733
DEBUG - 2022-11-10 11:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:23 --> Total execution time: 0.1731
DEBUG - 2022-11-10 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:39 --> Total execution time: 0.2683
DEBUG - 2022-11-10 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:53:41 --> Total execution time: 0.1715
DEBUG - 2022-11-10 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:24:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:54:34 --> Total execution time: 2.8791
DEBUG - 2022-11-10 11:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:54:37 --> Total execution time: 0.2180
DEBUG - 2022-11-10 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:54:48 --> Total execution time: 0.2004
DEBUG - 2022-11-10 11:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:25:56 --> Total execution time: 0.1713
DEBUG - 2022-11-10 11:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:26:04 --> Total execution time: 0.2333
DEBUG - 2022-11-10 11:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:26:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:56:42 --> Total execution time: 0.2630
DEBUG - 2022-11-10 11:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:56:59 --> Total execution time: 0.2103
DEBUG - 2022-11-10 11:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:57:02 --> Total execution time: 0.1726
DEBUG - 2022-11-10 11:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:57:39 --> Total execution time: 0.4512
DEBUG - 2022-11-10 11:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:57:50 --> Total execution time: 0.1872
DEBUG - 2022-11-10 11:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:57:57 --> Total execution time: 0.1819
DEBUG - 2022-11-10 11:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:28:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:58:02 --> Total execution time: 0.1738
DEBUG - 2022-11-10 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:58:10 --> Total execution time: 0.2836
DEBUG - 2022-11-10 11:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:05 --> Total execution time: 0.1857
DEBUG - 2022-11-10 11:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:18 --> Total execution time: 0.1733
DEBUG - 2022-11-10 11:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:26 --> Total execution time: 0.1856
DEBUG - 2022-11-10 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:29 --> Total execution time: 0.1658
DEBUG - 2022-11-10 11:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:40 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:40 --> Total execution time: 0.1147
DEBUG - 2022-11-10 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:42 --> Total execution time: 0.2206
DEBUG - 2022-11-10 11:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 22:59:56 --> Total execution time: 0.2341
DEBUG - 2022-11-10 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:00:08 --> Total execution time: 0.2158
DEBUG - 2022-11-10 11:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:00:10 --> Total execution time: 0.1808
DEBUG - 2022-11-10 11:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:00:21 --> Total execution time: 0.1743
DEBUG - 2022-11-10 11:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:00:27 --> Total execution time: 0.1841
DEBUG - 2022-11-10 11:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:30:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:00:36 --> Total execution time: 0.1718
DEBUG - 2022-11-10 11:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:01:20 --> Total execution time: 0.1726
DEBUG - 2022-11-10 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:01:26 --> Total execution time: 0.1665
DEBUG - 2022-11-10 11:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:32:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:02:27 --> Total execution time: 0.1145
DEBUG - 2022-11-10 11:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:33:41 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:03:41 --> Total execution time: 0.1069
DEBUG - 2022-11-10 11:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:34:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:04:29 --> Total execution time: 0.2531
DEBUG - 2022-11-10 11:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:04:34 --> Total execution time: 0.1782
DEBUG - 2022-11-10 11:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:04:50 --> Total execution time: 0.2111
DEBUG - 2022-11-10 11:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:35:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:05:38 --> Total execution time: 0.1745
DEBUG - 2022-11-10 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:26 --> Total execution time: 0.1245
DEBUG - 2022-11-10 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:27 --> Total execution time: 0.1500
DEBUG - 2022-11-10 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:28 --> Total execution time: 0.1498
DEBUG - 2022-11-10 11:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:31 --> Total execution time: 0.1209
DEBUG - 2022-11-10 11:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:31 --> Total execution time: 0.1734
DEBUG - 2022-11-10 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:06:47 --> Total execution time: 0.1070
DEBUG - 2022-11-10 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:08:31 --> Total execution time: 0.4700
DEBUG - 2022-11-10 11:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:08:37 --> Total execution time: 0.1582
DEBUG - 2022-11-10 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:38:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:08:58 --> Total execution time: 0.1111
DEBUG - 2022-11-10 11:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:39:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:09:31 --> Total execution time: 0.1943
DEBUG - 2022-11-10 11:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:09:36 --> Total execution time: 0.1583
DEBUG - 2022-11-10 11:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:09:49 --> Total execution time: 0.2527
DEBUG - 2022-11-10 11:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:10:02 --> Total execution time: 0.2079
DEBUG - 2022-11-10 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:10:36 --> Total execution time: 0.1669
DEBUG - 2022-11-10 11:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:42:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:12:22 --> Total execution time: 0.1779
DEBUG - 2022-11-10 11:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:12:49 --> Total execution time: 0.1637
DEBUG - 2022-11-10 11:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:13:07 --> Total execution time: 0.1726
DEBUG - 2022-11-10 11:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:13:10 --> Total execution time: 0.1762
DEBUG - 2022-11-10 11:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:13:59 --> Total execution time: 0.1713
DEBUG - 2022-11-10 11:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:14:44 --> Total execution time: 0.1679
DEBUG - 2022-11-10 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:15:33 --> Total execution time: 0.1838
DEBUG - 2022-11-10 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:45:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:15:51 --> Total execution time: 0.1133
DEBUG - 2022-11-10 11:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:45:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:46:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:16:06 --> Total execution time: 0.2204
DEBUG - 2022-11-10 11:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:16:15 --> Total execution time: 0.1855
DEBUG - 2022-11-10 11:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:16:20 --> Total execution time: 0.1779
DEBUG - 2022-11-10 11:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:16:35 --> Total execution time: 0.1672
DEBUG - 2022-11-10 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:50:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:20:04 --> Total execution time: 0.4421
DEBUG - 2022-11-10 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:12 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:22:12 --> Total execution time: 0.1163
DEBUG - 2022-11-10 11:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:14 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:22:14 --> Total execution time: 0.1100
DEBUG - 2022-11-10 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:22:18 --> Total execution time: 0.1681
DEBUG - 2022-11-10 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:22:25 --> Total execution time: 0.1151
DEBUG - 2022-11-10 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:22:56 --> Total execution time: 0.1754
DEBUG - 2022-11-10 11:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:05 --> Total execution time: 0.2248
DEBUG - 2022-11-10 11:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:14 --> Total execution time: 0.1686
DEBUG - 2022-11-10 11:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:25 --> Total execution time: 0.3326
DEBUG - 2022-11-10 11:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:26 --> Total execution time: 0.1605
DEBUG - 2022-11-10 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:44 --> Total execution time: 0.1892
DEBUG - 2022-11-10 11:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:23:59 --> Total execution time: 0.1702
DEBUG - 2022-11-10 11:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:02 --> Total execution time: 0.2632
DEBUG - 2022-11-10 11:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:03 --> Total execution time: 0.1777
DEBUG - 2022-11-10 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:20 --> Total execution time: 0.1715
DEBUG - 2022-11-10 11:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:22 --> Total execution time: 0.1849
DEBUG - 2022-11-10 11:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:27 --> Total execution time: 0.1721
DEBUG - 2022-11-10 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:46 --> Total execution time: 0.1685
DEBUG - 2022-11-10 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:46 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:47 --> Total execution time: 0.1747
DEBUG - 2022-11-10 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:50 --> Total execution time: 0.2004
DEBUG - 2022-11-10 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:55 --> Total execution time: 0.1838
DEBUG - 2022-11-10 11:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:24:55 --> Total execution time: 0.1783
DEBUG - 2022-11-10 11:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:00 --> Total execution time: 0.1650
DEBUG - 2022-11-10 11:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:11 --> Total execution time: 0.1864
DEBUG - 2022-11-10 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:12 --> Total execution time: 0.1080
DEBUG - 2022-11-10 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:20 --> No URI present. Default controller set.
DEBUG - 2022-11-10 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:20 --> Total execution time: 0.1821
DEBUG - 2022-11-10 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:27 --> Total execution time: 0.1644
DEBUG - 2022-11-10 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:41 --> Total execution time: 0.1996
DEBUG - 2022-11-10 11:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:46 --> Total execution time: 0.1800
DEBUG - 2022-11-10 11:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:51 --> Total execution time: 0.1618
DEBUG - 2022-11-10 11:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:25:55 --> Total execution time: 0.1893
DEBUG - 2022-11-10 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:05 --> Total execution time: 0.1962
DEBUG - 2022-11-10 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:07 --> Total execution time: 0.1799
DEBUG - 2022-11-10 11:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:11 --> Total execution time: 0.2602
DEBUG - 2022-11-10 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:20 --> Total execution time: 0.1978
DEBUG - 2022-11-10 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:24 --> Total execution time: 0.1822
DEBUG - 2022-11-10 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:27 --> Total execution time: 0.1751
DEBUG - 2022-11-10 11:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:29 --> Total execution time: 0.1822
DEBUG - 2022-11-10 11:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:37 --> Total execution time: 0.1750
DEBUG - 2022-11-10 11:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:45 --> Total execution time: 0.1736
DEBUG - 2022-11-10 11:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:54 --> Total execution time: 0.1849
DEBUG - 2022-11-10 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:26:56 --> Total execution time: 0.1650
DEBUG - 2022-11-10 11:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:28:32 --> Total execution time: 0.1046
DEBUG - 2022-11-10 11:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:59:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:29:32 --> Total execution time: 0.1714
DEBUG - 2022-11-10 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 11:59:44 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 11:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 11:59:45 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 11:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 11:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:29:47 --> Total execution time: 0.1767
DEBUG - 2022-11-10 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 11:59:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 11:59:49 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:30:03 --> Total execution time: 0.1461
DEBUG - 2022-11-10 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:30:15 --> Total execution time: 0.1745
DEBUG - 2022-11-10 12:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:30:57 --> Total execution time: 0.2095
DEBUG - 2022-11-10 12:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:01:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:31:30 --> Total execution time: 0.1307
DEBUG - 2022-11-10 12:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:01:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:31:30 --> Total execution time: 0.1679
DEBUG - 2022-11-10 12:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:01:32 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:31:32 --> Total execution time: 0.1756
DEBUG - 2022-11-10 12:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:02:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:32:52 --> Total execution time: 0.4424
DEBUG - 2022-11-10 12:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:04:19 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:34:19 --> Total execution time: 0.1069
DEBUG - 2022-11-10 12:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:04:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:34:30 --> Total execution time: 0.1822
DEBUG - 2022-11-10 12:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:38:44 --> Total execution time: 0.4633
DEBUG - 2022-11-10 12:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:38:49 --> Total execution time: 0.1850
DEBUG - 2022-11-10 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:39:22 --> Total execution time: 0.1938
DEBUG - 2022-11-10 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:39:58 --> Total execution time: 0.1628
DEBUG - 2022-11-10 12:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:01 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:02 --> Total execution time: 0.1479
DEBUG - 2022-11-10 12:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:07 --> Total execution time: 0.1029
DEBUG - 2022-11-10 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:08 --> Total execution time: 0.1068
DEBUG - 2022-11-10 12:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:08 --> Total execution time: 0.1033
DEBUG - 2022-11-10 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:30 --> Total execution time: 0.2054
DEBUG - 2022-11-10 12:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:32 --> Total execution time: 0.1179
DEBUG - 2022-11-10 12:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:41 --> Total execution time: 0.5323
DEBUG - 2022-11-10 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:43 --> Total execution time: 0.1805
DEBUG - 2022-11-10 12:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:46 --> Total execution time: 0.1884
DEBUG - 2022-11-10 12:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:48 --> Total execution time: 0.2277
DEBUG - 2022-11-10 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:49 --> Total execution time: 0.1095
DEBUG - 2022-11-10 12:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:55 --> Total execution time: 0.1647
DEBUG - 2022-11-10 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:40:57 --> Total execution time: 0.4669
DEBUG - 2022-11-10 12:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:06 --> Total execution time: 0.1639
DEBUG - 2022-11-10 12:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:08 --> Total execution time: 0.1707
DEBUG - 2022-11-10 12:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:10 --> Total execution time: 0.1909
DEBUG - 2022-11-10 12:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:13 --> Total execution time: 0.1093
DEBUG - 2022-11-10 12:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:14 --> Total execution time: 0.1657
DEBUG - 2022-11-10 12:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:14 --> Total execution time: 0.1832
DEBUG - 2022-11-10 12:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:22 --> Total execution time: 0.1799
DEBUG - 2022-11-10 12:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:24 --> Total execution time: 0.1940
DEBUG - 2022-11-10 12:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:41:26 --> Total execution time: 0.1214
DEBUG - 2022-11-10 12:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:11:48 --> Total execution time: 0.1727
DEBUG - 2022-11-10 12:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:12:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:12:06 --> Total execution time: 0.2342
DEBUG - 2022-11-10 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:13:52 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:43:52 --> Total execution time: 0.1171
DEBUG - 2022-11-10 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:44:07 --> Total execution time: 0.2096
DEBUG - 2022-11-10 12:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:44:18 --> Total execution time: 0.1847
DEBUG - 2022-11-10 12:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:18:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:18:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:48:58 --> Total execution time: 0.4671
DEBUG - 2022-11-10 12:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:49:00 --> Total execution time: 0.4442
DEBUG - 2022-11-10 12:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:49:00 --> Total execution time: 0.1648
DEBUG - 2022-11-10 12:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:49:11 --> Total execution time: 0.1745
DEBUG - 2022-11-10 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:49:43 --> Total execution time: 0.2035
DEBUG - 2022-11-10 12:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:19:49 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:49:49 --> Total execution time: 0.1711
DEBUG - 2022-11-10 12:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:50:11 --> Total execution time: 0.1693
DEBUG - 2022-11-10 12:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:50:13 --> Total execution time: 0.1894
DEBUG - 2022-11-10 12:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:20:50 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-10 12:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:20:56 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-10 12:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:21:04 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 12:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:21:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:21:11 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 12:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:51:35 --> Total execution time: 0.1081
DEBUG - 2022-11-10 12:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:27:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 23:57:47 --> Total execution time: 0.8847
DEBUG - 2022-11-10 12:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:41:28 --> No URI present. Default controller set.
DEBUG - 2022-11-10 12:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 12:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 12:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:51:40 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 12:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:51:41 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 12:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 12:51:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 12:51:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 13:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:02:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 13:03:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 13:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:05:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 13:07:02 --> 404 Page Not Found: 3d8noncoinage13p/nhdae4757878.html
DEBUG - 2022-11-10 13:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:10:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:23:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:32 --> Total execution time: 0.1679
DEBUG - 2022-11-10 13:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:27:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:27:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:28:58 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:34:51 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 13:41:16 --> No URI present. Default controller set.
DEBUG - 2022-11-10 13:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 13:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:09:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:03 --> Total execution time: 0.1650
DEBUG - 2022-11-10 14:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:07 --> Total execution time: 0.1716
DEBUG - 2022-11-10 14:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:07 --> Total execution time: 0.1596
DEBUG - 2022-11-10 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:11 --> No URI present. Default controller set.
DEBUG - 2022-11-10 14:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:18 --> Total execution time: 0.1645
DEBUG - 2022-11-10 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:20 --> Total execution time: 0.1643
DEBUG - 2022-11-10 14:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:20:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:20:20 --> Total execution time: 0.1804
DEBUG - 2022-11-10 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:21:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:30 --> Total execution time: 0.1597
DEBUG - 2022-11-10 14:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:32 --> Total execution time: 0.1657
DEBUG - 2022-11-10 14:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:21:32 --> Total execution time: 0.3796
DEBUG - 2022-11-10 14:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:36:54 --> 404 Page Not Found: Tips-to-developing-a-quality-discussion/index
DEBUG - 2022-11-10 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:37:30 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-11-10 14:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:37:36 --> 404 Page Not Found: 1indexphp/index
DEBUG - 2022-11-10 14:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:38:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:38:44 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 14:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:39:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:39:04 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 14:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:42:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 14:42:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 14:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:48:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:54 --> Total execution time: 0.9270
DEBUG - 2022-11-10 14:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:56 --> Total execution time: 0.2126
DEBUG - 2022-11-10 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 14:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 14:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 14:48:57 --> Total execution time: 0.1711
DEBUG - 2022-11-10 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:17:30 --> No URI present. Default controller set.
DEBUG - 2022-11-10 15:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:17:31 --> No URI present. Default controller set.
DEBUG - 2022-11-10 15:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:17:52 --> 404 Page Not Found: Sitemap_1xml/index
DEBUG - 2022-11-10 15:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:17:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:17:55 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-11-10 15:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:19:08 --> No URI present. Default controller set.
DEBUG - 2022-11-10 15:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:13 --> Total execution time: 0.4388
DEBUG - 2022-11-10 15:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:15 --> Total execution time: 0.2299
DEBUG - 2022-11-10 15:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:20:15 --> Total execution time: 0.1646
DEBUG - 2022-11-10 15:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:37:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:37:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-11-10 15:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:45:57 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-10 15:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:45:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:45:59 --> 404 Page Not Found: Wp-content/plugins
DEBUG - 2022-11-10 15:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:46:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:46:01 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:46:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:46:04 --> 404 Page Not Found: Wp-content/themes
DEBUG - 2022-11-10 15:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:54:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 15:54:50 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-11-10 15:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:57:02 --> No URI present. Default controller set.
DEBUG - 2022-11-10 15:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 15:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:19:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:22:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 16:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 16:22:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:03:33 --> Total execution time: 0.8614
DEBUG - 2022-11-10 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:03:39 --> Total execution time: 0.2227
DEBUG - 2022-11-10 17:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:03:39 --> Total execution time: 0.4363
DEBUG - 2022-11-10 17:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:38:54 --> No URI present. Default controller set.
DEBUG - 2022-11-10 17:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:01 --> No URI present. Default controller set.
DEBUG - 2022-11-10 17:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:40:43 --> No URI present. Default controller set.
DEBUG - 2022-11-10 17:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 17:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 17:49:03 --> No URI present. Default controller set.
DEBUG - 2022-11-10 17:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 17:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:19:44 --> No URI present. Default controller set.
DEBUG - 2022-11-10 18:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:23:14 --> 404 Page Not Found: Contact/index
DEBUG - 2022-11-10 18:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:28:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:28:10 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 18:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:28:13 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:28:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:28:14 --> 404 Page Not Found: Administrator/index.php
DEBUG - 2022-11-10 18:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:46:23 --> No URI present. Default controller set.
DEBUG - 2022-11-10 18:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:48:10 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 18:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:48:13 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 18:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 18:48:14 --> 404 Page Not Found: Admin/index.php
DEBUG - 2022-11-10 18:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 18:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 18:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 18:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:09 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:16:37 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:23:00 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:23:36 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:06 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:26:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:30:24 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:43:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:44:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 19:48:51 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-11-10 19:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:49:56 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:49:57 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:25 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:53:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:56:27 --> No URI present. Default controller set.
DEBUG - 2022-11-10 19:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 19:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-10 19:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:58:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 19:58:50 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-10 19:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 19:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-10 19:58:54 --> 404 Page Not Found: Sxallsitemapxml/index
DEBUG - 2022-11-10 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-10 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-10 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
