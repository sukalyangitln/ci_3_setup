<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-24 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 08:11:31 --> Total execution time: 0.9741
DEBUG - 2022-11-24 08:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 08:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 08:12:53 --> Total execution time: 0.0541
DEBUG - 2022-11-24 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 08:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:12:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 12:42:57 --> Total execution time: 0.1150
DEBUG - 2022-11-24 08:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 12:43:06 --> Total execution time: 0.1301
DEBUG - 2022-11-24 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 12:43:56 --> Total execution time: 0.1051
DEBUG - 2022-11-24 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 12:44:03 --> Total execution time: 0.0945
DEBUG - 2022-11-24 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-24 08:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-24 08:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-24 12:44:08 --> Total execution time: 0.0759
