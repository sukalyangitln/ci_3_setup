<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-23 03:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 03:48:12 --> Total execution time: 0.7838
DEBUG - 2022-11-23 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 03:48:15 --> Total execution time: 0.0405
DEBUG - 2022-11-23 03:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 03:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 03:49:43 --> Total execution time: 0.0503
DEBUG - 2022-11-23 03:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 03:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:19:57 --> Total execution time: 0.1145
DEBUG - 2022-11-23 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:20:19 --> Total execution time: 0.1696
DEBUG - 2022-11-23 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:20:19 --> Total execution time: 0.1385
DEBUG - 2022-11-23 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 03:50:19 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 03:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:20:30 --> Total execution time: 0.0944
DEBUG - 2022-11-23 03:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:20:49 --> Total execution time: 0.0767
DEBUG - 2022-11-23 03:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:21:02 --> Total execution time: 0.1186
DEBUG - 2022-11-23 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:21:07 --> Total execution time: 0.8572
DEBUG - 2022-11-23 04:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:39 --> Total execution time: 0.1030
DEBUG - 2022-11-23 04:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:40 --> Total execution time: 0.0808
DEBUG - 2022-11-23 04:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:40 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:44 --> Total execution time: 0.0979
DEBUG - 2022-11-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:45 --> Total execution time: 0.0919
DEBUG - 2022-11-23 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:45 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:45 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:45 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:46 --> Total execution time: 0.1029
DEBUG - 2022-11-23 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:46 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-23 04:02:46 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:47 --> Total execution time: 0.1048
DEBUG - 2022-11-23 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:48 --> 404 Page Not Found: Assets/user_thumbnail
ERROR - 2022-11-23 04:02:48 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:49 --> Total execution time: 0.1004
DEBUG - 2022-11-23 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:49 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:50 --> Total execution time: 0.0830
DEBUG - 2022-11-23 04:02:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:02:50 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:02:54 --> No URI present. Default controller set.
DEBUG - 2022-11-23 04:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:32:54 --> Total execution time: 0.0520
DEBUG - 2022-11-23 04:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:03:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:33:10 --> Total execution time: 0.0645
DEBUG - 2022-11-23 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:33:28 --> Total execution time: 0.1221
DEBUG - 2022-11-23 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:03:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:03:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:03:28 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:33:46 --> Total execution time: 0.0572
DEBUG - 2022-11-23 04:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:03:46 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:33:55 --> Total execution time: 0.0718
DEBUG - 2022-11-23 04:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:03:55 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:03:55 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:34:01 --> Upload class already loaded. Second attempt ignored.
ERROR - 2022-11-23 08:34:01 --> Severity: Warning --> unlink(assets/user_thumbnail/p0l8836esw1653398777.jpg): No such file or directory C:\xampp\htdocs\gopal\leadrsark\application\controllers\User\Profile_Controller.php 311
DEBUG - 2022-11-23 04:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:34:01 --> Total execution time: 0.0506
DEBUG - 2022-11-23 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:36:05 --> Total execution time: 0.0529
DEBUG - 2022-11-23 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:06:26 --> No URI present. Default controller set.
DEBUG - 2022-11-23 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:36:26 --> Total execution time: 0.0477
DEBUG - 2022-11-23 04:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:36:29 --> Total execution time: 0.0470
DEBUG - 2022-11-23 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:36:45 --> Total execution time: 11.5213
DEBUG - 2022-11-23 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:37:28 --> Total execution time: 8.9261
DEBUG - 2022-11-23 04:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:39:43 --> Total execution time: 0.0739
DEBUG - 2022-11-23 04:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:39:57 --> Total execution time: 0.0700
DEBUG - 2022-11-23 04:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:41:42 --> Total execution time: 0.1281
DEBUG - 2022-11-23 04:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:44:17 --> Total execution time: 0.0810
DEBUG - 2022-11-23 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:44:20 --> Total execution time: 0.0595
DEBUG - 2022-11-23 04:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:44:28 --> Total execution time: 0.0593
DEBUG - 2022-11-23 04:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:15:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:45:38 --> Total execution time: 0.0598
DEBUG - 2022-11-23 04:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:45:49 --> Total execution time: 0.0434
DEBUG - 2022-11-23 04:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:45:51 --> Total execution time: 0.0533
DEBUG - 2022-11-23 04:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 08:45:58 --> Total execution time: 0.0504
DEBUG - 2022-11-23 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:02:25 --> Total execution time: 0.0524
DEBUG - 2022-11-23 04:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:02:44 --> Total execution time: 0.0477
DEBUG - 2022-11-23 04:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:04:26 --> Total execution time: 0.0563
DEBUG - 2022-11-23 04:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:35:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:05:49 --> Total execution time: 0.0451
DEBUG - 2022-11-23 04:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:06:24 --> Total execution time: 0.0585
DEBUG - 2022-11-23 04:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:36:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:06:50 --> Total execution time: 0.0487
DEBUG - 2022-11-23 04:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:37:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:07:11 --> Total execution time: 0.0681
DEBUG - 2022-11-23 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:07:32 --> Total execution time: 0.0458
DEBUG - 2022-11-23 04:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:07:40 --> Total execution time: 0.0472
DEBUG - 2022-11-23 04:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:09:40 --> Total execution time: 0.0685
DEBUG - 2022-11-23 04:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:42:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:12:05 --> Total execution time: 0.0475
DEBUG - 2022-11-23 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:12:44 --> Total execution time: 0.0532
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 04:43:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:14:18 --> Total execution time: 0.0640
DEBUG - 2022-11-23 04:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:15:05 --> Total execution time: 0.0448
DEBUG - 2022-11-23 04:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:15:18 --> Total execution time: 0.0434
DEBUG - 2022-11-23 04:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:16:03 --> Total execution time: 0.0607
DEBUG - 2022-11-23 04:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:16:32 --> Total execution time: 0.0447
DEBUG - 2022-11-23 04:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:22:41 --> Total execution time: 0.0653
DEBUG - 2022-11-23 04:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:53:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:23:01 --> Total execution time: 0.0457
DEBUG - 2022-11-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 04:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:23:12 --> Total execution time: 0.0470
DEBUG - 2022-11-23 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 04:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 04:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 04:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 09:23:21 --> Total execution time: 0.0467
DEBUG - 2022-11-23 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 11:29:44 --> Total execution time: 0.7134
DEBUG - 2022-11-23 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 11:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 15:59:50 --> Total execution time: 0.1185
DEBUG - 2022-11-23 11:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:00:01 --> Total execution time: 0.1016
DEBUG - 2022-11-23 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:00:03 --> Total execution time: 0.0942
DEBUG - 2022-11-23 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:00:10 --> Total execution time: 0.0976
DEBUG - 2022-11-23 11:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:04:23 --> Total execution time: 0.0473
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:34:26 --> UTF-8 Support Enabled
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:34:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:05:41 --> Total execution time: 0.0579
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:35:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 11:35:42 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:35:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:05:45 --> Total execution time: 0.0480
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:35:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:35:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:06:47 --> Total execution time: 0.0592
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 11:36:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 11:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:07:06 --> Total execution time: 0.0506
DEBUG - 2022-11-23 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:07:13 --> Total execution time: 0.0436
DEBUG - 2022-11-23 11:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:07:15 --> Total execution time: 0.0638
DEBUG - 2022-11-23 11:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:37:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:07:17 --> Total execution time: 0.0585
DEBUG - 2022-11-23 11:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:15:08 --> Total execution time: 0.0509
DEBUG - 2022-11-23 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:20:45 --> Total execution time: 0.0605
DEBUG - 2022-11-23 11:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:23:21 --> Total execution time: 0.0588
DEBUG - 2022-11-23 11:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:23:36 --> Total execution time: 0.0525
DEBUG - 2022-11-23 11:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:24:08 --> Total execution time: 0.0661
DEBUG - 2022-11-23 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:25:08 --> Total execution time: 0.0590
DEBUG - 2022-11-23 11:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:55:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:25:24 --> Total execution time: 0.0498
DEBUG - 2022-11-23 11:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:25:27 --> Total execution time: 0.0470
DEBUG - 2022-11-23 11:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:26:46 --> Total execution time: 0.0451
DEBUG - 2022-11-23 11:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 11:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 11:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:27:40 --> Total execution time: 0.0456
DEBUG - 2022-11-23 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:30:31 --> Total execution time: 0.0564
DEBUG - 2022-11-23 12:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:00:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:30:55 --> Total execution time: 0.0486
DEBUG - 2022-11-23 12:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:31:34 --> Total execution time: 0.0501
DEBUG - 2022-11-23 12:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:34:11 --> Total execution time: 0.0854
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:04:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:04:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:35:08 --> Total execution time: 0.2214
DEBUG - 2022-11-23 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:05:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:35:09 --> Total execution time: 0.1283
DEBUG - 2022-11-23 12:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:05:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:05:09 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:05:14 --> No URI present. Default controller set.
DEBUG - 2022-11-23 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:35:15 --> Total execution time: 0.1203
DEBUG - 2022-11-23 12:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:35:21 --> Total execution time: 0.0769
DEBUG - 2022-11-23 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:06:23 --> Total execution time: 0.0962
DEBUG - 2022-11-23 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:06:23 --> Total execution time: 0.0485
DEBUG - 2022-11-23 12:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:06:23 --> Total execution time: 0.0679
DEBUG - 2022-11-23 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:36:59 --> Total execution time: 0.0613
DEBUG - 2022-11-23 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:02 --> Total execution time: 0.0841
DEBUG - 2022-11-23 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:07:02 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-11-23 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:13 --> Total execution time: 0.1326
DEBUG - 2022-11-23 12:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:20 --> Total execution time: 0.1020
DEBUG - 2022-11-23 12:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:41 --> Total execution time: 11.6715
DEBUG - 2022-11-23 12:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:44 --> Total execution time: 0.0791
DEBUG - 2022-11-23 12:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:47 --> Total execution time: 0.0883
DEBUG - 2022-11-23 12:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:49 --> Total execution time: 0.0930
DEBUG - 2022-11-23 12:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:52 --> Total execution time: 0.0897
DEBUG - 2022-11-23 12:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:37:58 --> Total execution time: 0.0845
DEBUG - 2022-11-23 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:00 --> Total execution time: 0.0939
DEBUG - 2022-11-23 12:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:02 --> Total execution time: 0.1130
DEBUG - 2022-11-23 12:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:04 --> Total execution time: 0.0984
DEBUG - 2022-11-23 12:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:15 --> Total execution time: 0.1419
DEBUG - 2022-11-23 12:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:19 --> Total execution time: 0.1122
DEBUG - 2022-11-23 12:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:23 --> Total execution time: 0.0712
DEBUG - 2022-11-23 12:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:27 --> Total execution time: 0.0902
DEBUG - 2022-11-23 12:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:34 --> Total execution time: 0.0765
DEBUG - 2022-11-23 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:38:40 --> Total execution time: 0.0389
DEBUG - 2022-11-23 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:08:47 --> Total execution time: 0.0460
DEBUG - 2022-11-23 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:08:47 --> Total execution time: 0.0745
DEBUG - 2022-11-23 12:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:08:47 --> Total execution time: 0.0851
DEBUG - 2022-11-23 12:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:17 --> Total execution time: 0.0492
DEBUG - 2022-11-23 12:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:18 --> Total execution time: 0.0666
DEBUG - 2022-11-23 12:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:18 --> Total execution time: 0.0845
DEBUG - 2022-11-23 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:20 --> Total execution time: 0.0696
DEBUG - 2022-11-23 12:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:21 --> Total execution time: 0.0736
DEBUG - 2022-11-23 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:34 --> Total execution time: 0.0615
DEBUG - 2022-11-23 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:34 --> Total execution time: 0.0537
DEBUG - 2022-11-23 12:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:34 --> Total execution time: 0.0642
DEBUG - 2022-11-23 12:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:41 --> Total execution time: 0.0602
DEBUG - 2022-11-23 12:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:42 --> Total execution time: 0.0489
DEBUG - 2022-11-23 12:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:43 --> Total execution time: 0.0823
DEBUG - 2022-11-23 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:52 --> Total execution time: 0.0507
DEBUG - 2022-11-23 12:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:10:52 --> Total execution time: 0.0491
DEBUG - 2022-11-23 12:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:03 --> Total execution time: 0.0512
DEBUG - 2022-11-23 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:09 --> Total execution time: 0.0771
DEBUG - 2022-11-23 12:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:09 --> Total execution time: 0.0542
DEBUG - 2022-11-23 12:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:12 --> Total execution time: 0.0454
DEBUG - 2022-11-23 12:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:12 --> Total execution time: 0.0551
DEBUG - 2022-11-23 12:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:11:12 --> Total execution time: 0.0624
DEBUG - 2022-11-23 12:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:44:33 --> Total execution time: 0.0628
DEBUG - 2022-11-23 12:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:44:33 --> Total execution time: 0.0614
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:43 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:44:47 --> Total execution time: 0.0527
DEBUG - 2022-11-23 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:47 --> UTF-8 Support Enabled
ERROR - 2022-11-23 12:14:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
ERROR - 2022-11-23 12:14:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 12:14:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-23 12:14:48 --> 404 Page Not Found: Assets/backend
ERROR - 2022-11-23 12:14:48 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-11-23 12:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:44:48 --> Total execution time: 0.0521
DEBUG - 2022-11-23 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:15:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:45:12 --> Total execution time: 0.0643
DEBUG - 2022-11-23 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:15:15 --> Total execution time: 0.0606
DEBUG - 2022-11-23 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:15:15 --> Total execution time: 0.0452
DEBUG - 2022-11-23 12:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:15:15 --> Total execution time: 0.0640
DEBUG - 2022-11-23 12:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 12:15:19 --> Total execution time: 0.0552
DEBUG - 2022-11-23 12:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:16:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-11-23 12:16:10 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 508
DEBUG - 2022-11-23 12:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:16:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:46:12 --> Total execution time: 1.7902
DEBUG - 2022-11-23 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:47:12 --> Total execution time: 1.3260
DEBUG - 2022-11-23 12:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-11-23 16:47:39 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 508
DEBUG - 2022-11-23 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:47:39 --> Total execution time: 0.0649
DEBUG - 2022-11-23 12:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-11-23 16:47:39 --> Severity: Notice --> Trying to get property 'ul_login_status' of non-object C:\xampp\htdocs\gopal\leadrsark\application\helpers\project_helper.php 424
DEBUG - 2022-11-23 16:47:39 --> Total execution time: 0.0757
DEBUG - 2022-11-23 12:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:47:41 --> Total execution time: 0.0470
DEBUG - 2022-11-23 12:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:47:46 --> Total execution time: 0.0700
DEBUG - 2022-11-23 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:47:59 --> Total execution time: 0.0656
DEBUG - 2022-11-23 12:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:07 --> Total execution time: 0.0603
DEBUG - 2022-11-23 12:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:08 --> Total execution time: 0.0912
DEBUG - 2022-11-23 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:10 --> Total execution time: 0.0425
DEBUG - 2022-11-23 12:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:15 --> Total execution time: 0.0442
DEBUG - 2022-11-23 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:18 --> Total execution time: 0.0465
DEBUG - 2022-11-23 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:20 --> Total execution time: 0.0440
DEBUG - 2022-11-23 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:48:23 --> Total execution time: 0.0807
DEBUG - 2022-11-23 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:19:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:49:39 --> Total execution time: 0.0448
DEBUG - 2022-11-23 12:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:49:58 --> Total execution time: 0.0531
DEBUG - 2022-11-23 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:50:04 --> Total execution time: 0.0450
DEBUG - 2022-11-23 12:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:50:04 --> Total execution time: 0.0432
DEBUG - 2022-11-23 12:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:50:07 --> Total execution time: 0.1668
DEBUG - 2022-11-23 12:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:50:21 --> Total execution time: 0.1122
DEBUG - 2022-11-23 12:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:21:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:51:40 --> Total execution time: 0.0652
DEBUG - 2022-11-23 12:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:54:50 --> Total execution time: 0.0570
DEBUG - 2022-11-23 12:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:54:51 --> Total execution time: 0.0653
DEBUG - 2022-11-23 12:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-23 12:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-23 12:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-11-23 16:54:52 --> Total execution time: 0.0450
