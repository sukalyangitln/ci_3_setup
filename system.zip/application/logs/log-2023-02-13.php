<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2023-02-13 15:23:07 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 15:23:07 --> No URI present. Default controller set.
DEBUG - 2023-02-13 15:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 15:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 15:23:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 19:53:08 --> Total execution time: 0.9269
DEBUG - 2023-02-13 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 15:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 15:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 15:23:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-02-13 15:23:22 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Test.php 13
DEBUG - 2023-02-13 15:23:28 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 15:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 15:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 15:23:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-02-13 15:23:28 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Test.php 13
DEBUG - 2023-02-13 15:23:31 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 15:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 15:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 15:23:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2023-02-13 15:23:31 --> Severity: error --> Exception: Class 'Google_Client' not found C:\xampp\htdocs\gopal\crowd_funding\application\controllers\Test.php 13
DEBUG - 2023-02-13 15:24:38 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 15:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 15:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 15:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 15:24:38 --> Total execution time: 0.0761
DEBUG - 2023-02-13 16:24:24 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:54:25 --> Total execution time: 0.0904
DEBUG - 2023-02-13 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:56:52 --> Total execution time: 0.1084
DEBUG - 2023-02-13 16:28:52 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:58:52 --> Total execution time: 0.0634
DEBUG - 2023-02-13 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:29:11 --> UTF-8 Support Enabled
ERROR - 2023-02-13 16:29:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:11 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:12 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:12 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:14 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:59:15 --> Total execution time: 0.0418
DEBUG - 2023-02-13 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:15 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:50 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:29:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:59:50 --> Total execution time: 0.0465
DEBUG - 2023-02-13 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:51 --> 404 Page Not Found: Assets/website
ERROR - 2023-02-13 16:29:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:51 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:51 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 20:59:57 --> Total execution time: 0.0458
DEBUG - 2023-02-13 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:29:57 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 21:00:27 --> Total execution time: 0.0679
DEBUG - 2023-02-13 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:27 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:32 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2023-02-13 16:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2023-02-13 16:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2023-02-13 21:00:32 --> Total execution time: 0.0631
DEBUG - 2023-02-13 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:33 --> 404 Page Not Found: Assets/website
DEBUG - 2023-02-13 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2023-02-13 16:30:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2023-02-13 16:30:33 --> 404 Page Not Found: Assets/website
