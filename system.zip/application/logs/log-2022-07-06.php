<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-06 00:00:28 --> Total execution time: 0.0675
DEBUG - 2022-07-06 00:00:37 --> Total execution time: 0.0746
DEBUG - 2022-07-06 00:03:17 --> Total execution time: 0.1096
DEBUG - 2022-07-06 00:10:50 --> Total execution time: 0.2097
DEBUG - 2022-07-06 00:22:13 --> Total execution time: 0.0536
DEBUG - 2022-07-06 00:28:47 --> Total execution time: 0.0505
DEBUG - 2022-07-06 00:28:52 --> Total execution time: 0.0986
DEBUG - 2022-07-06 00:28:53 --> Total execution time: 0.1002
DEBUG - 2022-07-06 00:28:57 --> Total execution time: 0.0693
DEBUG - 2022-07-06 00:29:03 --> Total execution time: 0.2015
DEBUG - 2022-07-06 00:29:19 --> Total execution time: 0.1463
DEBUG - 2022-07-06 00:30:00 --> Total execution time: 0.0682
DEBUG - 2022-07-06 00:30:02 --> Total execution time: 0.1770
DEBUG - 2022-07-06 00:30:03 --> Total execution time: 0.0925
DEBUG - 2022-07-06 00:30:06 --> Total execution time: 0.0760
DEBUG - 2022-07-06 00:30:38 --> Total execution time: 0.0893
DEBUG - 2022-07-06 00:30:44 --> Total execution time: 0.0858
DEBUG - 2022-07-06 00:30:56 --> Total execution time: 0.0811
DEBUG - 2022-07-06 00:31:03 --> Total execution time: 0.0811
DEBUG - 2022-07-06 00:36:48 --> Total execution time: 0.2231
DEBUG - 2022-07-06 00:36:56 --> Total execution time: 0.0551
DEBUG - 2022-07-06 00:37:29 --> Total execution time: 0.0682
DEBUG - 2022-07-06 00:37:33 --> Total execution time: 0.0545
DEBUG - 2022-07-06 00:38:18 --> Total execution time: 0.1704
DEBUG - 2022-07-06 00:39:20 --> Total execution time: 0.1236
DEBUG - 2022-07-06 00:40:32 --> Total execution time: 0.0478
DEBUG - 2022-07-06 00:40:33 --> Total execution time: 0.0438
DEBUG - 2022-07-06 00:46:31 --> Total execution time: 0.0545
DEBUG - 2022-07-06 00:52:43 --> Total execution time: 0.2132
DEBUG - 2022-07-06 01:28:32 --> Total execution time: 0.1808
DEBUG - 2022-07-06 01:28:36 --> Total execution time: 0.0380
DEBUG - 2022-07-06 01:29:12 --> Total execution time: 0.0694
DEBUG - 2022-07-06 01:29:22 --> Total execution time: 0.0541
DEBUG - 2022-07-06 01:30:02 --> Total execution time: 0.0426
DEBUG - 2022-07-06 02:30:03 --> Total execution time: 0.2207
DEBUG - 2022-07-06 02:51:18 --> Total execution time: 0.1676
DEBUG - 2022-07-06 02:51:19 --> Total execution time: 0.0570
DEBUG - 2022-07-06 03:30:04 --> Total execution time: 0.2880
DEBUG - 2022-07-06 03:34:12 --> Total execution time: 0.1680
DEBUG - 2022-07-06 03:34:20 --> Total execution time: 0.0352
DEBUG - 2022-07-06 04:30:03 --> Total execution time: 0.2422
DEBUG - 2022-07-06 04:58:55 --> Total execution time: 0.2085
DEBUG - 2022-07-06 05:00:45 --> Total execution time: 0.0394
DEBUG - 2022-07-06 05:03:59 --> Total execution time: 0.0995
DEBUG - 2022-07-06 05:04:00 --> Total execution time: 0.0429
DEBUG - 2022-07-06 05:05:15 --> Total execution time: 0.0715
DEBUG - 2022-07-06 05:06:07 --> Total execution time: 0.0595
DEBUG - 2022-07-06 05:06:23 --> Total execution time: 0.0447
DEBUG - 2022-07-06 05:06:33 --> Total execution time: 0.0478
DEBUG - 2022-07-06 05:06:44 --> Total execution time: 0.0787
DEBUG - 2022-07-06 05:06:51 --> Total execution time: 0.0789
DEBUG - 2022-07-06 05:06:58 --> Total execution time: 0.0566
DEBUG - 2022-07-06 05:07:35 --> Total execution time: 0.0359
DEBUG - 2022-07-06 05:07:59 --> Total execution time: 0.0538
DEBUG - 2022-07-06 05:08:33 --> Total execution time: 0.0344
DEBUG - 2022-07-06 05:14:19 --> Total execution time: 0.0863
DEBUG - 2022-07-06 05:15:37 --> Total execution time: 0.0420
DEBUG - 2022-07-06 05:16:42 --> Total execution time: 0.0421
DEBUG - 2022-07-06 05:18:58 --> Total execution time: 0.0981
DEBUG - 2022-07-06 05:19:14 --> Total execution time: 0.0751
DEBUG - 2022-07-06 05:21:09 --> Total execution time: 0.0531
DEBUG - 2022-07-06 05:21:16 --> Total execution time: 0.0559
DEBUG - 2022-07-06 05:21:23 --> Total execution time: 0.0627
DEBUG - 2022-07-06 05:22:14 --> Total execution time: 0.0352
DEBUG - 2022-07-06 05:30:03 --> Total execution time: 0.1551
DEBUG - 2022-07-06 05:30:03 --> Total execution time: 0.0693
DEBUG - 2022-07-06 05:30:08 --> Total execution time: 0.0677
DEBUG - 2022-07-06 05:34:16 --> Total execution time: 0.0989
DEBUG - 2022-07-06 05:58:21 --> Total execution time: 0.1269
DEBUG - 2022-07-06 05:58:28 --> Total execution time: 0.0513
DEBUG - 2022-07-06 05:58:37 --> Total execution time: 0.0873
DEBUG - 2022-07-06 05:58:45 --> Total execution time: 0.0685
DEBUG - 2022-07-06 05:58:50 --> Total execution time: 0.0628
DEBUG - 2022-07-06 05:59:01 --> Total execution time: 0.0603
DEBUG - 2022-07-06 05:59:04 --> Total execution time: 0.0693
DEBUG - 2022-07-06 06:00:59 --> Total execution time: 0.0358
DEBUG - 2022-07-06 06:02:48 --> Total execution time: 0.0344
DEBUG - 2022-07-06 06:03:12 --> Total execution time: 0.0669
DEBUG - 2022-07-06 06:03:34 --> Total execution time: 0.0659
DEBUG - 2022-07-06 06:03:50 --> Total execution time: 0.0704
DEBUG - 2022-07-06 06:04:13 --> Total execution time: 0.1163
DEBUG - 2022-07-06 06:08:58 --> Total execution time: 0.1104
DEBUG - 2022-07-06 06:08:58 --> Total execution time: 0.1018
DEBUG - 2022-07-06 06:09:07 --> Total execution time: 0.0400
DEBUG - 2022-07-06 06:09:12 --> Total execution time: 0.0362
DEBUG - 2022-07-06 06:09:26 --> Total execution time: 0.0591
DEBUG - 2022-07-06 06:09:31 --> Total execution time: 0.0412
DEBUG - 2022-07-06 06:09:39 --> Total execution time: 0.0556
DEBUG - 2022-07-06 06:09:43 --> Total execution time: 0.0548
DEBUG - 2022-07-06 06:21:01 --> Total execution time: 0.1884
DEBUG - 2022-07-06 06:21:01 --> Total execution time: 0.0551
DEBUG - 2022-07-06 06:23:26 --> Total execution time: 0.2033
DEBUG - 2022-07-06 06:23:30 --> Total execution time: 0.0654
DEBUG - 2022-07-06 06:24:10 --> Total execution time: 0.0610
DEBUG - 2022-07-06 06:24:20 --> Total execution time: 0.0622
DEBUG - 2022-07-06 06:30:03 --> Total execution time: 0.1236
DEBUG - 2022-07-06 06:33:06 --> Total execution time: 0.1824
DEBUG - 2022-07-06 06:48:01 --> Total execution time: 0.1318
DEBUG - 2022-07-06 06:49:00 --> Total execution time: 0.0561
DEBUG - 2022-07-06 06:55:13 --> Total execution time: 0.0514
DEBUG - 2022-07-06 07:03:49 --> Total execution time: 0.0528
DEBUG - 2022-07-06 07:06:14 --> Total execution time: 0.2023
DEBUG - 2022-07-06 07:06:41 --> Total execution time: 0.0551
DEBUG - 2022-07-06 07:06:41 --> Total execution time: 0.0500
DEBUG - 2022-07-06 07:06:45 --> Total execution time: 0.0438
DEBUG - 2022-07-06 07:06:54 --> Total execution time: 0.0814
DEBUG - 2022-07-06 07:07:01 --> Total execution time: 0.1353
DEBUG - 2022-07-06 07:07:08 --> Total execution time: 0.0662
DEBUG - 2022-07-06 07:07:18 --> Total execution time: 0.0523
DEBUG - 2022-07-06 07:09:37 --> Total execution time: 0.1366
DEBUG - 2022-07-06 07:16:47 --> Total execution time: 0.1640
DEBUG - 2022-07-06 07:16:48 --> Total execution time: 0.0485
DEBUG - 2022-07-06 07:18:09 --> Total execution time: 0.0439
DEBUG - 2022-07-06 07:18:13 --> Total execution time: 0.0542
DEBUG - 2022-07-06 07:18:19 --> Total execution time: 0.0816
DEBUG - 2022-07-06 07:18:27 --> Total execution time: 0.1363
DEBUG - 2022-07-06 07:19:30 --> Total execution time: 0.0585
DEBUG - 2022-07-06 07:19:46 --> Total execution time: 0.0534
DEBUG - 2022-07-06 07:20:03 --> Total execution time: 0.0532
DEBUG - 2022-07-06 07:20:14 --> Total execution time: 0.0567
DEBUG - 2022-07-06 07:20:23 --> Total execution time: 0.0504
DEBUG - 2022-07-06 07:20:27 --> Total execution time: 0.0471
DEBUG - 2022-07-06 07:20:31 --> Total execution time: 0.0540
DEBUG - 2022-07-06 07:20:39 --> Total execution time: 0.0868
DEBUG - 2022-07-06 07:21:03 --> Total execution time: 0.0539
DEBUG - 2022-07-06 07:21:08 --> Total execution time: 0.0821
DEBUG - 2022-07-06 07:21:14 --> Total execution time: 0.0676
DEBUG - 2022-07-06 07:21:19 --> Total execution time: 0.0521
DEBUG - 2022-07-06 07:21:24 --> Total execution time: 0.0685
DEBUG - 2022-07-06 07:30:03 --> Total execution time: 0.1695
DEBUG - 2022-07-06 07:31:40 --> Total execution time: 0.0405
DEBUG - 2022-07-06 07:32:24 --> Total execution time: 0.0384
DEBUG - 2022-07-06 07:32:33 --> Total execution time: 0.0389
DEBUG - 2022-07-06 07:32:34 --> Total execution time: 0.0345
DEBUG - 2022-07-06 07:33:11 --> Total execution time: 0.0636
DEBUG - 2022-07-06 07:33:37 --> Total execution time: 0.0737
DEBUG - 2022-07-06 07:34:05 --> Total execution time: 0.0754
DEBUG - 2022-07-06 07:34:40 --> Total execution time: 0.0864
DEBUG - 2022-07-06 07:34:45 --> Total execution time: 0.0737
DEBUG - 2022-07-06 07:35:01 --> Total execution time: 0.0744
DEBUG - 2022-07-06 07:35:12 --> Total execution time: 0.0529
DEBUG - 2022-07-06 07:35:34 --> Total execution time: 0.0665
DEBUG - 2022-07-06 07:36:10 --> Total execution time: 0.0355
DEBUG - 2022-07-06 07:36:37 --> Total execution time: 0.0502
DEBUG - 2022-07-06 07:48:57 --> Total execution time: 0.1312
DEBUG - 2022-07-06 07:49:13 --> Total execution time: 0.0675
DEBUG - 2022-07-06 07:52:11 --> Total execution time: 0.1163
DEBUG - 2022-07-06 07:52:16 --> Total execution time: 0.0601
DEBUG - 2022-07-06 07:52:32 --> Total execution time: 0.0499
DEBUG - 2022-07-06 07:52:38 --> Total execution time: 0.0954
DEBUG - 2022-07-06 07:53:58 --> Total execution time: 0.0352
DEBUG - 2022-07-06 07:54:09 --> Total execution time: 0.0489
DEBUG - 2022-07-06 07:54:21 --> Total execution time: 0.0497
DEBUG - 2022-07-06 07:54:44 --> Total execution time: 0.0508
DEBUG - 2022-07-06 07:54:48 --> Total execution time: 0.0539
DEBUG - 2022-07-06 07:54:53 --> Total execution time: 0.0762
DEBUG - 2022-07-06 07:55:15 --> Total execution time: 0.0554
DEBUG - 2022-07-06 07:55:22 --> Total execution time: 0.0551
DEBUG - 2022-07-06 07:55:49 --> Total execution time: 0.0629
DEBUG - 2022-07-06 07:55:52 --> Total execution time: 0.0510
DEBUG - 2022-07-06 07:55:55 --> Total execution time: 0.0542
DEBUG - 2022-07-06 07:56:01 --> Total execution time: 0.0531
DEBUG - 2022-07-06 07:56:02 --> Total execution time: 0.0528
DEBUG - 2022-07-06 07:56:03 --> Total execution time: 0.0876
DEBUG - 2022-07-06 07:56:03 --> Total execution time: 0.0887
DEBUG - 2022-07-06 07:56:06 --> Total execution time: 0.0829
DEBUG - 2022-07-06 07:57:00 --> Total execution time: 0.0594
DEBUG - 2022-07-06 07:57:19 --> Total execution time: 0.0543
DEBUG - 2022-07-06 07:57:28 --> Total execution time: 0.1070
DEBUG - 2022-07-06 07:57:42 --> Total execution time: 0.0615
DEBUG - 2022-07-06 07:58:30 --> Total execution time: 0.0486
DEBUG - 2022-07-06 08:04:22 --> Total execution time: 0.1742
DEBUG - 2022-07-06 08:06:21 --> Total execution time: 0.1694
DEBUG - 2022-07-06 08:07:30 --> Total execution time: 0.0455
DEBUG - 2022-07-06 08:07:42 --> Total execution time: 0.0381
DEBUG - 2022-07-06 08:07:43 --> Total execution time: 0.0569
DEBUG - 2022-07-06 08:07:46 --> Total execution time: 0.0324
DEBUG - 2022-07-06 08:07:56 --> Total execution time: 0.0551
DEBUG - 2022-07-06 08:08:10 --> Total execution time: 0.1012
DEBUG - 2022-07-06 08:08:12 --> Total execution time: 0.0508
DEBUG - 2022-07-06 08:08:19 --> Total execution time: 0.0959
DEBUG - 2022-07-06 08:08:24 --> Total execution time: 0.0563
DEBUG - 2022-07-06 08:08:31 --> Total execution time: 0.0578
DEBUG - 2022-07-06 08:08:40 --> Total execution time: 0.0538
DEBUG - 2022-07-06 08:08:47 --> Total execution time: 0.0625
DEBUG - 2022-07-06 08:08:51 --> Total execution time: 0.0913
DEBUG - 2022-07-06 08:08:53 --> Total execution time: 0.0549
DEBUG - 2022-07-06 08:08:58 --> Total execution time: 0.0649
DEBUG - 2022-07-06 08:09:08 --> Total execution time: 0.0807
DEBUG - 2022-07-06 08:09:22 --> Total execution time: 0.0649
DEBUG - 2022-07-06 08:09:26 --> Total execution time: 0.0596
DEBUG - 2022-07-06 08:09:28 --> Total execution time: 0.0690
DEBUG - 2022-07-06 08:09:33 --> Total execution time: 0.0713
DEBUG - 2022-07-06 08:09:38 --> Total execution time: 0.0563
DEBUG - 2022-07-06 08:09:43 --> Total execution time: 0.0699
DEBUG - 2022-07-06 08:09:44 --> Total execution time: 0.0611
DEBUG - 2022-07-06 08:09:46 --> Total execution time: 0.0738
DEBUG - 2022-07-06 08:09:49 --> Total execution time: 0.0619
DEBUG - 2022-07-06 08:09:53 --> Total execution time: 0.0706
DEBUG - 2022-07-06 08:09:55 --> Total execution time: 0.0623
DEBUG - 2022-07-06 08:09:58 --> Total execution time: 0.0698
DEBUG - 2022-07-06 08:10:00 --> Total execution time: 0.0566
DEBUG - 2022-07-06 08:10:13 --> Total execution time: 0.0758
DEBUG - 2022-07-06 08:10:44 --> Total execution time: 0.0551
DEBUG - 2022-07-06 08:10:49 --> Total execution time: 0.0511
DEBUG - 2022-07-06 08:10:56 --> Total execution time: 0.0763
DEBUG - 2022-07-06 08:12:04 --> Total execution time: 0.0584
DEBUG - 2022-07-06 08:12:13 --> Total execution time: 0.0620
DEBUG - 2022-07-06 08:12:32 --> Total execution time: 0.1427
DEBUG - 2022-07-06 08:12:34 --> Total execution time: 0.0893
DEBUG - 2022-07-06 08:12:44 --> Total execution time: 0.1070
DEBUG - 2022-07-06 08:12:48 --> Total execution time: 0.1405
DEBUG - 2022-07-06 08:12:51 --> Total execution time: 0.0580
DEBUG - 2022-07-06 08:12:51 --> Total execution time: 0.0568
DEBUG - 2022-07-06 08:12:53 --> Total execution time: 0.0592
DEBUG - 2022-07-06 08:12:56 --> Total execution time: 0.0537
DEBUG - 2022-07-06 08:12:57 --> Total execution time: 0.0732
DEBUG - 2022-07-06 08:13:04 --> Total execution time: 0.0576
DEBUG - 2022-07-06 08:13:07 --> Total execution time: 0.0644
DEBUG - 2022-07-06 08:13:14 --> Total execution time: 0.1308
DEBUG - 2022-07-06 08:13:30 --> Total execution time: 0.0562
DEBUG - 2022-07-06 08:13:35 --> Total execution time: 0.0549
DEBUG - 2022-07-06 08:13:38 --> Total execution time: 0.0738
DEBUG - 2022-07-06 08:14:27 --> Total execution time: 0.0512
DEBUG - 2022-07-06 08:14:41 --> Total execution time: 0.0551
DEBUG - 2022-07-06 08:14:46 --> Total execution time: 0.0596
DEBUG - 2022-07-06 08:14:50 --> Total execution time: 0.0517
DEBUG - 2022-07-06 08:14:54 --> Total execution time: 0.0597
DEBUG - 2022-07-06 08:15:03 --> Total execution time: 0.0608
DEBUG - 2022-07-06 08:15:21 --> Total execution time: 0.0863
DEBUG - 2022-07-06 08:15:31 --> Total execution time: 0.1017
DEBUG - 2022-07-06 08:15:52 --> Total execution time: 0.0786
DEBUG - 2022-07-06 08:16:05 --> Total execution time: 0.0534
DEBUG - 2022-07-06 08:16:12 --> Total execution time: 0.0508
DEBUG - 2022-07-06 08:16:43 --> Total execution time: 0.0619
DEBUG - 2022-07-06 08:16:54 --> Total execution time: 0.0497
DEBUG - 2022-07-06 08:17:22 --> Total execution time: 0.0528
DEBUG - 2022-07-06 08:17:26 --> Total execution time: 0.0564
DEBUG - 2022-07-06 08:17:28 --> Total execution time: 0.0523
DEBUG - 2022-07-06 08:17:40 --> Total execution time: 0.0534
DEBUG - 2022-07-06 08:17:43 --> Total execution time: 0.0423
DEBUG - 2022-07-06 08:17:45 --> Total execution time: 0.0282
DEBUG - 2022-07-06 08:17:49 --> Total execution time: 0.0318
DEBUG - 2022-07-06 08:17:53 --> Total execution time: 0.0553
DEBUG - 2022-07-06 08:18:02 --> Total execution time: 0.0589
DEBUG - 2022-07-06 08:18:09 --> Total execution time: 0.0496
DEBUG - 2022-07-06 08:18:10 --> Total execution time: 0.0550
DEBUG - 2022-07-06 08:18:18 --> Total execution time: 0.1318
DEBUG - 2022-07-06 08:18:22 --> Total execution time: 0.0803
DEBUG - 2022-07-06 08:20:24 --> Total execution time: 0.0402
DEBUG - 2022-07-06 08:20:45 --> Total execution time: 0.0562
DEBUG - 2022-07-06 08:20:51 --> Total execution time: 0.0715
DEBUG - 2022-07-06 08:20:56 --> Total execution time: 0.0705
DEBUG - 2022-07-06 08:20:59 --> Total execution time: 0.0574
DEBUG - 2022-07-06 08:21:12 --> Total execution time: 0.0845
DEBUG - 2022-07-06 08:21:42 --> Total execution time: 0.0571
DEBUG - 2022-07-06 08:23:18 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:23:37 --> Total execution time: 0.0488
DEBUG - 2022-07-06 08:23:53 --> Total execution time: 0.0524
DEBUG - 2022-07-06 08:24:03 --> Total execution time: 0.1721
DEBUG - 2022-07-06 08:24:07 --> Total execution time: 0.1352
DEBUG - 2022-07-06 08:24:23 --> Total execution time: 0.0831
DEBUG - 2022-07-06 08:24:36 --> Total execution time: 0.0488
DEBUG - 2022-07-06 08:24:36 --> Total execution time: 0.0751
DEBUG - 2022-07-06 08:25:01 --> Total execution time: 0.0627
DEBUG - 2022-07-06 08:25:10 --> Total execution time: 0.0729
DEBUG - 2022-07-06 08:25:22 --> Total execution time: 0.1315
DEBUG - 2022-07-06 08:25:27 --> Total execution time: 0.0738
DEBUG - 2022-07-06 08:25:29 --> Total execution time: 0.0638
DEBUG - 2022-07-06 08:25:32 --> Total execution time: 0.0770
DEBUG - 2022-07-06 08:25:33 --> Total execution time: 0.0381
DEBUG - 2022-07-06 08:25:34 --> Total execution time: 0.0373
DEBUG - 2022-07-06 08:25:38 --> Total execution time: 0.0777
DEBUG - 2022-07-06 08:25:42 --> Total execution time: 0.1210
DEBUG - 2022-07-06 08:25:44 --> Total execution time: 0.0510
DEBUG - 2022-07-06 08:26:01 --> Total execution time: 0.0852
DEBUG - 2022-07-06 08:26:40 --> Total execution time: 0.0742
DEBUG - 2022-07-06 08:26:51 --> Total execution time: 0.0354
DEBUG - 2022-07-06 08:30:03 --> Total execution time: 0.0777
DEBUG - 2022-07-06 08:30:19 --> Total execution time: 0.0516
DEBUG - 2022-07-06 08:30:27 --> Total execution time: 0.0574
DEBUG - 2022-07-06 08:30:34 --> Total execution time: 0.0663
DEBUG - 2022-07-06 08:30:42 --> Total execution time: 0.0694
DEBUG - 2022-07-06 08:30:46 --> Total execution time: 0.0542
DEBUG - 2022-07-06 08:30:52 --> Total execution time: 0.0516
DEBUG - 2022-07-06 08:32:14 --> Total execution time: 0.1159
DEBUG - 2022-07-06 08:32:20 --> Total execution time: 0.0542
DEBUG - 2022-07-06 08:32:22 --> Total execution time: 0.0597
DEBUG - 2022-07-06 08:32:23 --> Total execution time: 0.0552
DEBUG - 2022-07-06 08:32:26 --> Total execution time: 0.0560
DEBUG - 2022-07-06 08:32:33 --> Total execution time: 0.0866
DEBUG - 2022-07-06 08:34:56 --> Total execution time: 0.1035
DEBUG - 2022-07-06 08:35:32 --> Total execution time: 0.0456
DEBUG - 2022-07-06 08:35:40 --> Total execution time: 0.0415
DEBUG - 2022-07-06 08:36:18 --> Total execution time: 0.0607
DEBUG - 2022-07-06 08:36:27 --> Total execution time: 0.0498
DEBUG - 2022-07-06 08:36:40 --> Total execution time: 0.0531
DEBUG - 2022-07-06 08:36:41 --> Total execution time: 0.0577
DEBUG - 2022-07-06 08:36:59 --> Total execution time: 0.0752
DEBUG - 2022-07-06 08:36:59 --> Total execution time: 0.0799
DEBUG - 2022-07-06 08:37:10 --> Total execution time: 0.0678
DEBUG - 2022-07-06 08:37:17 --> Total execution time: 0.0615
DEBUG - 2022-07-06 08:40:26 --> Total execution time: 0.1229
DEBUG - 2022-07-06 08:40:27 --> Total execution time: 0.0357
DEBUG - 2022-07-06 08:40:32 --> Total execution time: 0.0347
DEBUG - 2022-07-06 08:40:50 --> Total execution time: 0.0475
DEBUG - 2022-07-06 08:41:03 --> Total execution time: 0.0484
DEBUG - 2022-07-06 08:41:46 --> Total execution time: 0.0724
DEBUG - 2022-07-06 08:41:56 --> Total execution time: 0.0760
DEBUG - 2022-07-06 08:42:03 --> Total execution time: 0.1097
DEBUG - 2022-07-06 08:47:07 --> Total execution time: 0.1120
DEBUG - 2022-07-06 08:47:15 --> Total execution time: 0.0479
DEBUG - 2022-07-06 08:47:19 --> Total execution time: 0.0586
DEBUG - 2022-07-06 08:47:30 --> Total execution time: 0.0359
DEBUG - 2022-07-06 08:47:33 --> Total execution time: 0.0498
DEBUG - 2022-07-06 08:47:39 --> Total execution time: 0.0559
DEBUG - 2022-07-06 08:47:44 --> Total execution time: 0.0875
DEBUG - 2022-07-06 08:47:53 --> Total execution time: 0.0651
DEBUG - 2022-07-06 08:48:05 --> Total execution time: 0.0573
DEBUG - 2022-07-06 08:48:25 --> Total execution time: 0.0363
DEBUG - 2022-07-06 08:49:10 --> Total execution time: 0.0573
DEBUG - 2022-07-06 08:49:21 --> Total execution time: 0.0585
DEBUG - 2022-07-06 08:52:24 --> Total execution time: 0.1041
DEBUG - 2022-07-06 08:52:45 --> Total execution time: 0.1279
DEBUG - 2022-07-06 08:52:52 --> Total execution time: 0.0563
DEBUG - 2022-07-06 08:53:20 --> Total execution time: 0.1327
DEBUG - 2022-07-06 08:53:27 --> Total execution time: 0.0614
DEBUG - 2022-07-06 08:53:31 --> Total execution time: 0.0714
DEBUG - 2022-07-06 08:53:51 --> Total execution time: 0.0863
DEBUG - 2022-07-06 08:54:27 --> Total execution time: 0.0904
DEBUG - 2022-07-06 08:55:45 --> Total execution time: 0.0637
DEBUG - 2022-07-06 08:56:13 --> Total execution time: 0.0613
DEBUG - 2022-07-06 08:56:16 --> Total execution time: 0.1357
DEBUG - 2022-07-06 08:56:54 --> Total execution time: 0.0665
DEBUG - 2022-07-06 08:57:06 --> Total execution time: 0.0619
DEBUG - 2022-07-06 08:57:11 --> Total execution time: 0.0664
DEBUG - 2022-07-06 09:01:15 --> Total execution time: 0.1091
DEBUG - 2022-07-06 09:01:41 --> Total execution time: 0.0598
DEBUG - 2022-07-06 09:02:15 --> Total execution time: 0.0427
DEBUG - 2022-07-06 09:02:19 --> Total execution time: 0.0473
DEBUG - 2022-07-06 09:02:26 --> Total execution time: 0.0775
DEBUG - 2022-07-06 09:03:39 --> Total execution time: 0.0370
DEBUG - 2022-07-06 09:06:19 --> Total execution time: 0.0511
DEBUG - 2022-07-06 09:06:31 --> Total execution time: 0.0828
DEBUG - 2022-07-06 09:07:22 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:07:36 --> Total execution time: 0.0499
DEBUG - 2022-07-06 09:17:25 --> Total execution time: 0.0933
DEBUG - 2022-07-06 09:18:07 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:18:36 --> Total execution time: 0.0389
DEBUG - 2022-07-06 09:18:47 --> Total execution time: 0.0322
DEBUG - 2022-07-06 09:19:11 --> Total execution time: 0.0629
DEBUG - 2022-07-06 09:19:44 --> Total execution time: 0.3421
DEBUG - 2022-07-06 09:19:45 --> Total execution time: 0.1118
DEBUG - 2022-07-06 09:20:10 --> Total execution time: 0.1182
DEBUG - 2022-07-06 09:20:21 --> Total execution time: 0.0808
DEBUG - 2022-07-06 09:20:38 --> Total execution time: 0.0706
DEBUG - 2022-07-06 09:20:54 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:21:19 --> Total execution time: 0.0562
DEBUG - 2022-07-06 09:21:24 --> Total execution time: 0.0486
DEBUG - 2022-07-06 09:21:42 --> Total execution time: 0.0538
DEBUG - 2022-07-06 09:22:06 --> Total execution time: 0.0419
DEBUG - 2022-07-06 09:22:18 --> Total execution time: 0.0509
DEBUG - 2022-07-06 09:23:15 --> Total execution time: 0.0484
DEBUG - 2022-07-06 09:23:29 --> Total execution time: 0.0778
DEBUG - 2022-07-06 09:23:37 --> Total execution time: 0.0606
DEBUG - 2022-07-06 09:23:39 --> Total execution time: 0.0304
DEBUG - 2022-07-06 09:24:04 --> Total execution time: 0.0600
DEBUG - 2022-07-06 09:24:14 --> Total execution time: 0.1215
DEBUG - 2022-07-06 09:24:36 --> Total execution time: 0.0491
DEBUG - 2022-07-06 09:24:41 --> Total execution time: 0.0653
DEBUG - 2022-07-06 09:24:46 --> Total execution time: 0.1177
DEBUG - 2022-07-06 09:24:58 --> Total execution time: 0.0543
DEBUG - 2022-07-06 09:25:04 --> Total execution time: 0.0849
DEBUG - 2022-07-06 09:25:13 --> Total execution time: 0.0397
DEBUG - 2022-07-06 09:25:14 --> Total execution time: 0.0615
DEBUG - 2022-07-06 09:25:17 --> Total execution time: 0.0427
DEBUG - 2022-07-06 09:25:53 --> Total execution time: 0.0545
DEBUG - 2022-07-06 09:26:07 --> Total execution time: 0.1186
DEBUG - 2022-07-06 09:26:54 --> Total execution time: 0.0829
DEBUG - 2022-07-06 09:27:21 --> Total execution time: 0.1627
DEBUG - 2022-07-06 09:28:28 --> Total execution time: 0.0783
DEBUG - 2022-07-06 09:28:33 --> Total execution time: 0.0545
DEBUG - 2022-07-06 09:28:36 --> Total execution time: 0.0590
DEBUG - 2022-07-06 09:28:39 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:28:49 --> Total execution time: 0.0532
DEBUG - 2022-07-06 09:28:50 --> Total execution time: 0.0448
DEBUG - 2022-07-06 09:28:51 --> Total execution time: 0.0580
DEBUG - 2022-07-06 09:29:55 --> Total execution time: 0.1294
DEBUG - 2022-07-06 09:30:01 --> Total execution time: 0.0422
DEBUG - 2022-07-06 09:30:42 --> Total execution time: 0.0510
DEBUG - 2022-07-06 09:32:36 --> Total execution time: 0.0997
DEBUG - 2022-07-06 09:35:34 --> Total execution time: 0.0629
DEBUG - 2022-07-06 09:36:57 --> Total execution time: 0.0631
DEBUG - 2022-07-06 09:37:03 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:37:09 --> Total execution time: 0.0999
DEBUG - 2022-07-06 09:37:27 --> Total execution time: 0.0549
DEBUG - 2022-07-06 09:37:36 --> Total execution time: 0.0479
DEBUG - 2022-07-06 09:37:40 --> Total execution time: 0.0771
DEBUG - 2022-07-06 09:37:50 --> Total execution time: 0.0550
DEBUG - 2022-07-06 09:37:57 --> Total execution time: 0.0504
DEBUG - 2022-07-06 09:38:05 --> Total execution time: 0.0624
DEBUG - 2022-07-06 09:38:14 --> Total execution time: 0.1251
DEBUG - 2022-07-06 09:38:17 --> Total execution time: 0.0489
DEBUG - 2022-07-06 09:38:21 --> Total execution time: 0.0620
DEBUG - 2022-07-06 09:38:29 --> Total execution time: 0.0492
DEBUG - 2022-07-06 09:39:36 --> Total execution time: 0.1786
DEBUG - 2022-07-06 09:40:07 --> Total execution time: 0.0795
DEBUG - 2022-07-06 09:40:07 --> Total execution time: 0.0721
DEBUG - 2022-07-06 09:41:22 --> Total execution time: 0.0576
DEBUG - 2022-07-06 09:41:26 --> Total execution time: 0.0557
DEBUG - 2022-07-06 09:41:29 --> Total execution time: 0.0802
DEBUG - 2022-07-06 09:41:30 --> Total execution time: 0.0562
DEBUG - 2022-07-06 09:45:22 --> Total execution time: 0.2809
DEBUG - 2022-07-06 09:45:39 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:46:39 --> Total execution time: 0.0516
DEBUG - 2022-07-06 09:47:12 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:47:22 --> Total execution time: 0.0492
DEBUG - 2022-07-06 09:47:29 --> Total execution time: 0.0677
DEBUG - 2022-07-06 09:47:47 --> Total execution time: 0.0327
DEBUG - 2022-07-06 09:50:31 --> Total execution time: 0.0407
DEBUG - 2022-07-06 09:50:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:50:40 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:51:16 --> Total execution time: 0.0591
DEBUG - 2022-07-06 09:51:22 --> Total execution time: 0.0561
DEBUG - 2022-07-06 09:51:23 --> Total execution time: 0.0539
DEBUG - 2022-07-06 09:51:31 --> Total execution time: 0.0619
DEBUG - 2022-07-06 09:51:38 --> Total execution time: 0.0564
DEBUG - 2022-07-06 09:51:43 --> Total execution time: 0.1256
DEBUG - 2022-07-06 09:51:51 --> Total execution time: 0.0884
DEBUG - 2022-07-06 09:52:21 --> Total execution time: 0.0927
DEBUG - 2022-07-06 09:52:47 --> Total execution time: 0.0779
DEBUG - 2022-07-06 09:52:56 --> Total execution time: 0.0581
DEBUG - 2022-07-06 09:53:05 --> Total execution time: 0.0690
DEBUG - 2022-07-06 09:53:18 --> Total execution time: 0.0760
DEBUG - 2022-07-06 09:53:23 --> Total execution time: 0.0825
DEBUG - 2022-07-06 09:55:01 --> Total execution time: 0.1596
DEBUG - 2022-07-06 09:55:08 --> Total execution time: 0.0731
DEBUG - 2022-07-06 09:55:15 --> Total execution time: 0.0530
DEBUG - 2022-07-06 09:55:36 --> Total execution time: 0.1204
DEBUG - 2022-07-06 09:56:46 --> Total execution time: 0.0354
DEBUG - 2022-07-06 09:56:47 --> Total execution time: 0.0298
DEBUG - 2022-07-06 09:57:05 --> Total execution time: 0.0567
DEBUG - 2022-07-06 09:57:34 --> Total execution time: 0.0576
DEBUG - 2022-07-06 09:58:14 --> Total execution time: 0.0338
DEBUG - 2022-07-06 09:58:14 --> Total execution time: 0.0658
DEBUG - 2022-07-06 09:58:16 --> Total execution time: 0.0355
DEBUG - 2022-07-06 09:58:22 --> Total execution time: 0.0351
DEBUG - 2022-07-06 09:58:40 --> Total execution time: 0.0705
DEBUG - 2022-07-06 09:58:43 --> Total execution time: 0.0611
DEBUG - 2022-07-06 09:58:47 --> Total execution time: 0.0672
DEBUG - 2022-07-06 09:59:06 --> Total execution time: 0.0775
DEBUG - 2022-07-06 09:59:15 --> Total execution time: 0.0608
DEBUG - 2022-07-06 09:59:21 --> Total execution time: 0.0699
DEBUG - 2022-07-06 09:59:23 --> Total execution time: 0.0574
DEBUG - 2022-07-06 09:59:27 --> Total execution time: 0.0586
DEBUG - 2022-07-06 09:59:48 --> Total execution time: 0.0720
DEBUG - 2022-07-06 09:59:53 --> Total execution time: 0.0619
DEBUG - 2022-07-06 09:59:59 --> Total execution time: 0.0565
DEBUG - 2022-07-06 10:00:41 --> Total execution time: 0.0704
DEBUG - 2022-07-06 10:00:56 --> Total execution time: 0.0668
DEBUG - 2022-07-06 10:03:04 --> Total execution time: 0.1244
DEBUG - 2022-07-06 10:03:21 --> Total execution time: 0.0700
DEBUG - 2022-07-06 10:03:26 --> Total execution time: 0.0568
DEBUG - 2022-07-06 10:03:35 --> Total execution time: 0.0532
DEBUG - 2022-07-06 10:03:49 --> Total execution time: 0.0811
DEBUG - 2022-07-06 10:04:00 --> Total execution time: 0.0710
DEBUG - 2022-07-06 10:04:07 --> Total execution time: 0.0603
DEBUG - 2022-07-06 10:05:16 --> Total execution time: 0.0540
DEBUG - 2022-07-06 10:05:20 --> Total execution time: 0.0328
DEBUG - 2022-07-06 10:05:21 --> Total execution time: 0.0670
DEBUG - 2022-07-06 10:05:37 --> Total execution time: 0.0920
DEBUG - 2022-07-06 10:05:39 --> Total execution time: 0.0330
DEBUG - 2022-07-06 10:06:19 --> Total execution time: 0.0533
DEBUG - 2022-07-06 10:06:43 --> Total execution time: 0.0572
DEBUG - 2022-07-06 10:06:48 --> Total execution time: 0.0530
DEBUG - 2022-07-06 10:06:59 --> Total execution time: 0.0715
DEBUG - 2022-07-06 10:07:23 --> Total execution time: 0.0971
DEBUG - 2022-07-06 10:07:41 --> Total execution time: 0.1097
DEBUG - 2022-07-06 10:08:09 --> Total execution time: 0.2388
DEBUG - 2022-07-06 10:08:10 --> Total execution time: 0.1123
DEBUG - 2022-07-06 10:08:17 --> Total execution time: 0.0625
DEBUG - 2022-07-06 10:08:38 --> Total execution time: 0.0652
DEBUG - 2022-07-06 10:08:45 --> Total execution time: 0.0583
DEBUG - 2022-07-06 10:09:00 --> Total execution time: 0.0566
DEBUG - 2022-07-06 10:09:04 --> Total execution time: 0.0588
DEBUG - 2022-07-06 10:09:12 --> Total execution time: 0.0635
DEBUG - 2022-07-06 10:09:14 --> Total execution time: 0.0613
DEBUG - 2022-07-06 10:09:18 --> Total execution time: 0.0586
DEBUG - 2022-07-06 10:14:54 --> Total execution time: 0.0402
DEBUG - 2022-07-06 10:16:56 --> Total execution time: 0.0363
DEBUG - 2022-07-06 10:17:36 --> Total execution time: 0.0383
DEBUG - 2022-07-06 10:17:52 --> Total execution time: 0.0765
DEBUG - 2022-07-06 10:18:05 --> Total execution time: 0.0353
DEBUG - 2022-07-06 10:18:09 --> Total execution time: 0.0361
DEBUG - 2022-07-06 10:18:09 --> Total execution time: 0.0487
DEBUG - 2022-07-06 10:18:10 --> Total execution time: 0.0329
DEBUG - 2022-07-06 10:18:36 --> Total execution time: 0.0633
DEBUG - 2022-07-06 10:20:23 --> Total execution time: 0.0513
DEBUG - 2022-07-06 10:20:52 --> Total execution time: 0.0543
DEBUG - 2022-07-06 10:20:56 --> Total execution time: 0.0316
DEBUG - 2022-07-06 10:25:53 --> Total execution time: 0.4574
DEBUG - 2022-07-06 10:26:06 --> Total execution time: 0.0682
DEBUG - 2022-07-06 10:26:12 --> Total execution time: 0.0765
DEBUG - 2022-07-06 10:26:21 --> Total execution time: 0.0662
DEBUG - 2022-07-06 10:26:25 --> Total execution time: 0.0735
DEBUG - 2022-07-06 10:26:37 --> Total execution time: 0.0595
DEBUG - 2022-07-06 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:30:02 --> Total execution time: 0.2045
DEBUG - 2022-07-06 00:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:30:24 --> Total execution time: 0.2001
DEBUG - 2022-07-06 00:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:30:27 --> Total execution time: 0.0359
DEBUG - 2022-07-06 00:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:02:36 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 00:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:02:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 00:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:02:41 --> 404 Page Not Found: Course/gold-level-program
DEBUG - 2022-07-06 00:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:32:44 --> Total execution time: 0.1107
DEBUG - 2022-07-06 00:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:32:45 --> Total execution time: 0.1334
DEBUG - 2022-07-06 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:32:49 --> Total execution time: 0.0327
DEBUG - 2022-07-06 00:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:32:49 --> Total execution time: 0.0506
DEBUG - 2022-07-06 00:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:02 --> Total execution time: 0.0935
DEBUG - 2022-07-06 00:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:09 --> Total execution time: 0.0501
DEBUG - 2022-07-06 00:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:24 --> Total execution time: 0.0636
DEBUG - 2022-07-06 00:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:28 --> Total execution time: 0.0890
DEBUG - 2022-07-06 00:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:33 --> Total execution time: 0.0558
DEBUG - 2022-07-06 00:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:35 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:35 --> Total execution time: 0.0423
DEBUG - 2022-07-06 00:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:39 --> Total execution time: 0.0494
DEBUG - 2022-07-06 00:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:43 --> Total execution time: 0.0878
DEBUG - 2022-07-06 00:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:46 --> Total execution time: 0.0322
DEBUG - 2022-07-06 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:53 --> Total execution time: 0.0630
DEBUG - 2022-07-06 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:54 --> Total execution time: 0.0913
DEBUG - 2022-07-06 00:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:33:56 --> Total execution time: 0.0770
DEBUG - 2022-07-06 00:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:05 --> Total execution time: 0.0878
DEBUG - 2022-07-06 00:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:11 --> Total execution time: 0.0774
DEBUG - 2022-07-06 00:04:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:16 --> Total execution time: 0.0601
DEBUG - 2022-07-06 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:04:35 --> Total execution time: 0.0363
DEBUG - 2022-07-06 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:04:37 --> Total execution time: 0.0588
DEBUG - 2022-07-06 00:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:04:37 --> Total execution time: 0.1004
DEBUG - 2022-07-06 00:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:04:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:48 --> Total execution time: 0.1281
DEBUG - 2022-07-06 00:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:37:36 --> Total execution time: 0.0922
DEBUG - 2022-07-06 00:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:06 --> Total execution time: 0.0448
DEBUG - 2022-07-06 00:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:10 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:10 --> Total execution time: 0.0689
DEBUG - 2022-07-06 00:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:31 --> Total execution time: 0.0595
DEBUG - 2022-07-06 00:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:32 --> Total execution time: 0.0348
DEBUG - 2022-07-06 00:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:37 --> Total execution time: 0.0564
DEBUG - 2022-07-06 00:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:41 --> Total execution time: 0.0481
DEBUG - 2022-07-06 00:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:44 --> Total execution time: 0.0914
DEBUG - 2022-07-06 00:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:52 --> Total execution time: 0.0507
DEBUG - 2022-07-06 00:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:09:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:39:14 --> Total execution time: 0.0510
DEBUG - 2022-07-06 00:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:39:38 --> Total execution time: 0.0605
DEBUG - 2022-07-06 00:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:40:03 --> Total execution time: 0.0640
DEBUG - 2022-07-06 00:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:40:10 --> Total execution time: 0.0674
DEBUG - 2022-07-06 00:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:10:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:40:47 --> Total execution time: 0.1380
DEBUG - 2022-07-06 00:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:09 --> Total execution time: 0.1013
DEBUG - 2022-07-06 00:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:19 --> Total execution time: 0.0489
DEBUG - 2022-07-06 00:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:35 --> Total execution time: 0.0558
DEBUG - 2022-07-06 00:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:49 --> Total execution time: 0.0568
DEBUG - 2022-07-06 00:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:54 --> Total execution time: 0.0776
DEBUG - 2022-07-06 00:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:44:59 --> Total execution time: 0.0705
DEBUG - 2022-07-06 00:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:45:05 --> Total execution time: 0.0683
DEBUG - 2022-07-06 00:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:45:08 --> Total execution time: 0.0748
DEBUG - 2022-07-06 00:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:45:11 --> Total execution time: 0.0503
DEBUG - 2022-07-06 00:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:15:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:45:49 --> Total execution time: 0.0487
DEBUG - 2022-07-06 00:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:19:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:19:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:49:21 --> Total execution time: 0.1006
DEBUG - 2022-07-06 00:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:49:24 --> Total execution time: 0.1452
DEBUG - 2022-07-06 00:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:19:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:49:26 --> Total execution time: 0.0689
DEBUG - 2022-07-06 00:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:49:29 --> Total execution time: 0.0582
DEBUG - 2022-07-06 00:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:20:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:50:11 --> Total execution time: 0.0508
DEBUG - 2022-07-06 00:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:03 --> Total execution time: 0.0516
DEBUG - 2022-07-06 00:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:12 --> Total execution time: 0.0519
DEBUG - 2022-07-06 00:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:14 --> Total execution time: 0.0489
DEBUG - 2022-07-06 00:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:21 --> Total execution time: 0.0643
DEBUG - 2022-07-06 00:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:23 --> Total execution time: 0.0566
DEBUG - 2022-07-06 00:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:26 --> Total execution time: 0.0656
DEBUG - 2022-07-06 00:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:51:33 --> Total execution time: 0.0560
DEBUG - 2022-07-06 00:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:52:58 --> Total execution time: 0.0410
DEBUG - 2022-07-06 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:53:53 --> Total execution time: 0.0488
DEBUG - 2022-07-06 00:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:24:26 --> 404 Page Not Found: Sports/feed
DEBUG - 2022-07-06 00:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:55:02 --> Total execution time: 0.1493
DEBUG - 2022-07-06 00:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:55:12 --> Total execution time: 0.0521
DEBUG - 2022-07-06 00:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:25:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:55:13 --> Total execution time: 0.0736
DEBUG - 2022-07-06 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:26:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:56:05 --> Total execution time: 0.0566
DEBUG - 2022-07-06 00:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:26:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:26:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:56:05 --> Total execution time: 0.0474
DEBUG - 2022-07-06 00:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:27:43 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:57:43 --> Total execution time: 0.0339
DEBUG - 2022-07-06 00:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:27:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:57:52 --> Total execution time: 0.0544
DEBUG - 2022-07-06 00:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:27:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:57:57 --> Total execution time: 0.0596
DEBUG - 2022-07-06 00:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:05 --> Total execution time: 0.0340
DEBUG - 2022-07-06 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:15 --> Total execution time: 0.0495
DEBUG - 2022-07-06 00:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:18 --> Total execution time: 0.0468
DEBUG - 2022-07-06 00:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:33 --> Total execution time: 0.0601
DEBUG - 2022-07-06 00:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:35 --> Total execution time: 0.0551
DEBUG - 2022-07-06 00:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:39 --> Total execution time: 0.0598
DEBUG - 2022-07-06 00:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:41 --> Total execution time: 0.0524
DEBUG - 2022-07-06 00:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:28:43 --> Total execution time: 0.1332
DEBUG - 2022-07-06 00:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:43 --> Total execution time: 0.0669
DEBUG - 2022-07-06 00:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:44 --> Total execution time: 0.0570
DEBUG - 2022-07-06 00:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:45 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 00:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:45 --> Total execution time: 0.0486
DEBUG - 2022-07-06 00:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:58:48 --> Total execution time: 0.0839
DEBUG - 2022-07-06 00:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:15 --> Total execution time: 0.1396
DEBUG - 2022-07-06 00:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:16 --> Total execution time: 0.0490
DEBUG - 2022-07-06 00:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:18 --> Total execution time: 0.0463
DEBUG - 2022-07-06 00:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:29:19 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-06 00:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:25 --> Total execution time: 0.0520
DEBUG - 2022-07-06 00:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:37 --> Total execution time: 0.0365
DEBUG - 2022-07-06 00:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:37 --> Total execution time: 0.0476
DEBUG - 2022-07-06 10:59:37 --> Total execution time: 0.0590
DEBUG - 2022-07-06 00:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:37 --> Total execution time: 0.0467
DEBUG - 2022-07-06 00:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:38 --> Total execution time: 0.0586
DEBUG - 2022-07-06 00:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:38 --> Total execution time: 0.0416
DEBUG - 2022-07-06 00:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:38 --> Total execution time: 0.0439
DEBUG - 2022-07-06 10:59:38 --> Total execution time: 0.0600
DEBUG - 2022-07-06 00:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:38 --> Total execution time: 0.0440
DEBUG - 2022-07-06 00:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:52 --> Total execution time: 0.0511
DEBUG - 2022-07-06 00:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:29:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:59:58 --> Total execution time: 0.0893
DEBUG - 2022-07-06 00:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:01 --> Total execution time: 0.0507
DEBUG - 2022-07-06 00:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:03 --> Total execution time: 0.0681
DEBUG - 2022-07-06 00:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:04 --> Total execution time: 0.0781
DEBUG - 2022-07-06 00:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:05 --> Total execution time: 0.1364
DEBUG - 2022-07-06 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:16 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:16 --> Total execution time: 0.1383
DEBUG - 2022-07-06 00:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:17 --> Total execution time: 0.0440
DEBUG - 2022-07-06 00:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:18 --> Total execution time: 0.0543
DEBUG - 2022-07-06 00:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:20 --> Total execution time: 0.0413
DEBUG - 2022-07-06 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:22 --> Total execution time: 0.0486
DEBUG - 2022-07-06 00:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:29 --> Total execution time: 0.0562
DEBUG - 2022-07-06 00:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:47 --> Total execution time: 0.0613
DEBUG - 2022-07-06 00:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:53 --> Total execution time: 0.0575
DEBUG - 2022-07-06 00:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:00:57 --> Total execution time: 0.0500
DEBUG - 2022-07-06 00:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:01:02 --> Total execution time: 0.0546
DEBUG - 2022-07-06 00:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:01:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 00:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:31:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:01:03 --> Total execution time: 0.0531
DEBUG - 2022-07-06 00:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:01:31 --> Total execution time: 0.1332
DEBUG - 2022-07-06 00:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:31:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:01:45 --> Total execution time: 0.0646
DEBUG - 2022-07-06 00:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:32:55 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:02:55 --> Total execution time: 0.0470
DEBUG - 2022-07-06 00:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:32:55 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:02:55 --> Total execution time: 0.0434
DEBUG - 2022-07-06 00:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:32:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 00:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:03:27 --> Total execution time: 0.1090
DEBUG - 2022-07-06 00:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:03:28 --> Total execution time: 0.1942
DEBUG - 2022-07-06 00:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:03:28 --> Total execution time: 0.1691
DEBUG - 2022-07-06 00:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:04:14 --> Total execution time: 0.0736
DEBUG - 2022-07-06 00:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:04:19 --> Total execution time: 0.0670
DEBUG - 2022-07-06 00:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:04:21 --> Total execution time: 0.0539
DEBUG - 2022-07-06 00:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:04:54 --> Total execution time: 0.0690
DEBUG - 2022-07-06 00:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:03 --> Total execution time: 0.0550
DEBUG - 2022-07-06 00:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:09 --> Total execution time: 0.0543
DEBUG - 2022-07-06 00:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:10 --> Total execution time: 0.0735
DEBUG - 2022-07-06 00:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:12 --> Total execution time: 0.0584
DEBUG - 2022-07-06 00:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 00:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:20 --> Total execution time: 0.0834
DEBUG - 2022-07-06 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:24 --> Total execution time: 0.0544
DEBUG - 2022-07-06 00:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:24 --> Total execution time: 0.0529
DEBUG - 2022-07-06 00:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:11:24 --> Total execution time: 0.1227
DEBUG - 2022-07-06 00:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:44:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:14:46 --> Total execution time: 0.1109
DEBUG - 2022-07-06 00:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:15:52 --> Total execution time: 0.0714
DEBUG - 2022-07-06 00:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:31 --> Total execution time: 0.0434
DEBUG - 2022-07-06 00:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:32 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:32 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:33 --> 404 Page Not Found: Panelstxt/index
DEBUG - 2022-07-06 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:33 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:34 --> 404 Page Not Found: Wp-includes/upload_index.php
DEBUG - 2022-07-06 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:35 --> 404 Page Not Found: Upload_indexphp/index
DEBUG - 2022-07-06 00:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:35 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:36 --> 404 Page Not Found: Th3_alphaphp/index
DEBUG - 2022-07-06 00:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:36 --> 404 Page Not Found: Wp-includes/th3_alpha.php
DEBUG - 2022-07-06 00:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:37 --> 404 Page Not Found: Vphp/index
DEBUG - 2022-07-06 00:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:37 --> 404 Page Not Found: Class-wp-registroyphp/index
DEBUG - 2022-07-06 00:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:38 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:46:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:46:38 --> 404 Page Not Found: Wp-content/class-wp-type-registroy.php
DEBUG - 2022-07-06 00:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:24:24 --> Total execution time: 0.1419
DEBUG - 2022-07-06 00:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:54:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:24:36 --> Total execution time: 0.1302
DEBUG - 2022-07-06 00:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:54:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 00:54:44 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 00:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:55:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 00:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 00:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:25:13 --> Total execution time: 0.0378
DEBUG - 2022-07-06 00:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 00:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:30:00 --> Total execution time: 0.2168
DEBUG - 2022-07-06 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:30:02 --> Total execution time: 0.1189
DEBUG - 2022-07-06 01:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:30:15 --> Total execution time: 0.0890
DEBUG - 2022-07-06 01:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:30:18 --> Total execution time: 0.0538
DEBUG - 2022-07-06 01:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:32:13 --> Total execution time: 0.1064
DEBUG - 2022-07-06 01:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:32:45 --> Total execution time: 0.2007
DEBUG - 2022-07-06 01:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:15 --> Total execution time: 0.1740
DEBUG - 2022-07-06 01:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:15 --> Total execution time: 0.1327
DEBUG - 2022-07-06 01:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:16 --> Total execution time: 0.1597
DEBUG - 2022-07-06 01:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:16 --> Total execution time: 0.1777
DEBUG - 2022-07-06 01:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:17 --> Total execution time: 0.1411
DEBUG - 2022-07-06 01:03:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:33:17 --> Total execution time: 0.3158
DEBUG - 2022-07-06 01:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:07:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:37:04 --> Total execution time: 0.1363
DEBUG - 2022-07-06 01:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:07:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 01:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:09:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:39:55 --> Total execution time: 0.2064
DEBUG - 2022-07-06 01:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:11 --> Total execution time: 0.0521
DEBUG - 2022-07-06 01:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:16 --> Total execution time: 0.0519
DEBUG - 2022-07-06 01:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:17 --> Total execution time: 0.0629
DEBUG - 2022-07-06 01:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:18 --> Total execution time: 0.0670
DEBUG - 2022-07-06 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:20 --> Total execution time: 0.0504
DEBUG - 2022-07-06 01:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:21 --> Total execution time: 0.1238
DEBUG - 2022-07-06 01:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:52 --> Total execution time: 0.0554
DEBUG - 2022-07-06 01:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:10:54 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:10:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:40:54 --> Total execution time: 0.0504
DEBUG - 2022-07-06 01:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:00 --> Total execution time: 0.0489
DEBUG - 2022-07-06 01:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:06 --> Total execution time: 0.0614
DEBUG - 2022-07-06 01:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:18 --> Total execution time: 0.0505
DEBUG - 2022-07-06 01:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:21 --> Total execution time: 0.0367
DEBUG - 2022-07-06 01:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:11:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:34 --> Total execution time: 0.0573
DEBUG - 2022-07-06 01:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:37 --> Total execution time: 0.0652
DEBUG - 2022-07-06 01:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:13:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:13:11 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 01:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:13:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:43:57 --> Total execution time: 0.1340
DEBUG - 2022-07-06 01:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:44:08 --> Total execution time: 0.0429
DEBUG - 2022-07-06 01:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:44:09 --> Total execution time: 0.0408
DEBUG - 2022-07-06 01:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:44:12 --> Total execution time: 0.0370
DEBUG - 2022-07-06 01:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:44:18 --> Total execution time: 0.0808
DEBUG - 2022-07-06 01:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:44:52 --> Total execution time: 0.0838
DEBUG - 2022-07-06 01:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:15:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:15:43 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:17:48 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 01:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:51:44 --> Total execution time: 0.0507
DEBUG - 2022-07-06 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:51:51 --> Total execution time: 0.0538
DEBUG - 2022-07-06 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:51:53 --> Total execution time: 0.0516
DEBUG - 2022-07-06 01:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:30 --> Total execution time: 0.0557
DEBUG - 2022-07-06 01:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:37 --> Total execution time: 0.1267
DEBUG - 2022-07-06 01:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:39 --> Total execution time: 0.0895
DEBUG - 2022-07-06 01:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:22:49 --> Total execution time: 0.0552
DEBUG - 2022-07-06 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:22:50 --> Total execution time: 0.0591
DEBUG - 2022-07-06 01:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:22:50 --> Total execution time: 0.0828
DEBUG - 2022-07-06 01:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:50 --> Total execution time: 0.0743
DEBUG - 2022-07-06 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:11 --> Total execution time: 0.0483
DEBUG - 2022-07-06 01:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:45 --> Total execution time: 0.0420
DEBUG - 2022-07-06 01:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:52 --> Total execution time: 0.0504
DEBUG - 2022-07-06 01:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:54 --> Total execution time: 0.0474
DEBUG - 2022-07-06 01:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:56 --> Total execution time: 0.0565
DEBUG - 2022-07-06 01:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:23:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:58 --> Total execution time: 0.0576
DEBUG - 2022-07-06 01:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:02 --> Total execution time: 0.0492
DEBUG - 2022-07-06 01:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:17 --> Total execution time: 0.0487
DEBUG - 2022-07-06 01:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:20 --> Total execution time: 0.0495
DEBUG - 2022-07-06 01:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:24:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:55 --> Total execution time: 0.0758
DEBUG - 2022-07-06 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:25:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:14 --> Total execution time: 0.1954
DEBUG - 2022-07-06 01:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:17 --> Total execution time: 0.0698
DEBUG - 2022-07-06 01:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:48 --> Total execution time: 0.0675
DEBUG - 2022-07-06 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:52 --> Total execution time: 0.0451
DEBUG - 2022-07-06 01:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:25:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:58 --> Total execution time: 0.0536
DEBUG - 2022-07-06 01:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:30:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:00:32 --> Total execution time: 0.1450
DEBUG - 2022-07-06 01:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:31:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:08 --> Total execution time: 0.0411
DEBUG - 2022-07-06 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:02:29 --> Total execution time: 0.0715
DEBUG - 2022-07-06 01:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:32:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:02:50 --> Total execution time: 0.1571
DEBUG - 2022-07-06 01:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:03:14 --> Total execution time: 0.0510
DEBUG - 2022-07-06 01:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:03:30 --> Total execution time: 0.0529
DEBUG - 2022-07-06 01:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:11:14 --> Total execution time: 0.2573
DEBUG - 2022-07-06 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 01:41:21 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 01:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:11:28 --> Total execution time: 0.1109
DEBUG - 2022-07-06 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:11:39 --> Total execution time: 0.0497
DEBUG - 2022-07-06 01:41:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:11:39 --> Total execution time: 0.0608
DEBUG - 2022-07-06 01:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:11:57 --> Total execution time: 0.0895
DEBUG - 2022-07-06 01:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:23 --> Total execution time: 0.2446
DEBUG - 2022-07-06 01:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:23 --> Total execution time: 0.4347
DEBUG - 2022-07-06 01:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:26 --> Total execution time: 0.0712
DEBUG - 2022-07-06 01:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:35 --> Total execution time: 0.0686
DEBUG - 2022-07-06 01:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:44 --> Total execution time: 0.0726
DEBUG - 2022-07-06 01:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:47 --> Total execution time: 0.0343
DEBUG - 2022-07-06 01:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:12:58 --> Total execution time: 0.0487
DEBUG - 2022-07-06 01:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:13:11 --> Total execution time: 0.0552
DEBUG - 2022-07-06 01:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:13:22 --> Total execution time: 0.0769
DEBUG - 2022-07-06 01:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:13:26 --> Total execution time: 0.0633
DEBUG - 2022-07-06 01:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:13:33 --> Total execution time: 0.0779
DEBUG - 2022-07-06 01:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:13:35 --> Total execution time: 0.0858
DEBUG - 2022-07-06 01:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:44:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:14:57 --> Total execution time: 0.0638
DEBUG - 2022-07-06 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:45:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:15:01 --> Total execution time: 0.1227
DEBUG - 2022-07-06 01:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:45:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:15:47 --> Total execution time: 0.0467
DEBUG - 2022-07-06 01:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:49:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:19:51 --> Total execution time: 0.1369
DEBUG - 2022-07-06 01:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:19:59 --> Total execution time: 0.0360
DEBUG - 2022-07-06 01:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:03 --> Total execution time: 0.0698
DEBUG - 2022-07-06 01:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:09 --> Total execution time: 0.0698
DEBUG - 2022-07-06 01:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:12 --> Total execution time: 0.0907
DEBUG - 2022-07-06 01:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:19 --> Total execution time: 0.0655
DEBUG - 2022-07-06 01:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:24 --> Total execution time: 0.0528
DEBUG - 2022-07-06 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:32 --> Total execution time: 0.0534
DEBUG - 2022-07-06 01:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:38 --> Total execution time: 0.1209
DEBUG - 2022-07-06 01:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:20:59 --> Total execution time: 0.1219
DEBUG - 2022-07-06 01:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:21:07 --> Total execution time: 0.0560
DEBUG - 2022-07-06 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:21:14 --> Total execution time: 0.0883
DEBUG - 2022-07-06 01:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:26 --> Total execution time: 0.0503
DEBUG - 2022-07-06 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:31 --> Total execution time: 0.0565
DEBUG - 2022-07-06 01:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:36 --> Total execution time: 0.0516
DEBUG - 2022-07-06 01:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:39 --> Total execution time: 0.0477
DEBUG - 2022-07-06 01:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:51:42 --> Total execution time: 0.0609
DEBUG - 2022-07-06 01:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:55 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:21:55 --> Total execution time: 0.0466
DEBUG - 2022-07-06 01:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:51:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:21:59 --> Total execution time: 0.0496
DEBUG - 2022-07-06 01:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:52:00 --> Total execution time: 0.0503
DEBUG - 2022-07-06 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:52:02 --> Total execution time: 0.0489
DEBUG - 2022-07-06 01:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:04 --> Total execution time: 0.0696
DEBUG - 2022-07-06 01:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:06 --> Total execution time: 0.0501
DEBUG - 2022-07-06 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:12 --> Total execution time: 0.1003
DEBUG - 2022-07-06 01:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:14 --> Total execution time: 0.0756
DEBUG - 2022-07-06 01:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 01:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:16 --> Total execution time: 0.0656
DEBUG - 2022-07-06 01:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:52:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:22:17 --> Total execution time: 0.0552
DEBUG - 2022-07-06 01:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:57:15 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:27:16 --> Total execution time: 0.1543
DEBUG - 2022-07-06 01:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 01:57:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 01:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 01:57:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:27:39 --> Total execution time: 0.0558
DEBUG - 2022-07-06 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:30:04 --> Total execution time: 0.4688
DEBUG - 2022-07-06 02:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:31:36 --> Total execution time: 0.2011
DEBUG - 2022-07-06 02:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:32:52 --> Total execution time: 0.0678
DEBUG - 2022-07-06 02:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:32:54 --> Total execution time: 0.0498
DEBUG - 2022-07-06 02:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:01 --> Total execution time: 0.0684
DEBUG - 2022-07-06 02:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:02 --> Total execution time: 0.0496
DEBUG - 2022-07-06 02:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:05 --> Total execution time: 0.0568
DEBUG - 2022-07-06 02:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:12 --> Total execution time: 0.0741
DEBUG - 2022-07-06 02:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:14 --> Total execution time: 0.0778
DEBUG - 2022-07-06 02:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:14 --> Total execution time: 0.0612
DEBUG - 2022-07-06 02:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:19 --> Total execution time: 0.0592
DEBUG - 2022-07-06 02:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:23 --> Total execution time: 0.0717
DEBUG - 2022-07-06 02:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:29 --> Total execution time: 0.0912
DEBUG - 2022-07-06 02:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:31 --> Total execution time: 0.0689
DEBUG - 2022-07-06 02:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:32 --> Total execution time: 0.0854
DEBUG - 2022-07-06 02:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:33 --> Total execution time: 0.0788
DEBUG - 2022-07-06 02:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:42 --> Total execution time: 0.0551
DEBUG - 2022-07-06 02:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:33:55 --> Total execution time: 0.0546
DEBUG - 2022-07-06 02:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:34:02 --> Total execution time: 0.1166
DEBUG - 2022-07-06 02:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:34:11 --> Total execution time: 0.0658
DEBUG - 2022-07-06 02:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:35:19 --> Total execution time: 0.0640
DEBUG - 2022-07-06 02:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:35:19 --> Total execution time: 0.0638
DEBUG - 2022-07-06 02:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:35:20 --> Total execution time: 0.1628
DEBUG - 2022-07-06 02:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:35:41 --> Total execution time: 0.0385
DEBUG - 2022-07-06 02:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:35:51 --> Total execution time: 0.0524
DEBUG - 2022-07-06 02:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:06:02 --> Total execution time: 0.0537
DEBUG - 2022-07-06 02:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:07 --> Total execution time: 0.0738
DEBUG - 2022-07-06 02:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:12 --> Total execution time: 0.0870
DEBUG - 2022-07-06 02:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:13 --> Total execution time: 0.0746
DEBUG - 2022-07-06 02:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:14 --> Total execution time: 0.0904
DEBUG - 2022-07-06 02:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:19 --> Total execution time: 0.0734
DEBUG - 2022-07-06 02:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:26 --> Total execution time: 0.1798
DEBUG - 2022-07-06 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:36:34 --> Total execution time: 0.0933
DEBUG - 2022-07-06 02:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:07:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:37:03 --> Total execution time: 0.0945
DEBUG - 2022-07-06 02:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:37:11 --> Total execution time: 0.1902
DEBUG - 2022-07-06 02:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:21 --> Total execution time: 0.1204
DEBUG - 2022-07-06 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:22 --> Total execution time: 0.0938
DEBUG - 2022-07-06 02:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:32 --> Total execution time: 0.0690
DEBUG - 2022-07-06 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:41 --> Total execution time: 0.0586
DEBUG - 2022-07-06 02:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:44 --> Total execution time: 0.0510
DEBUG - 2022-07-06 02:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:48 --> Total execution time: 0.0452
DEBUG - 2022-07-06 02:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:38:50 --> Total execution time: 0.0645
DEBUG - 2022-07-06 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:39:00 --> Total execution time: 0.0556
DEBUG - 2022-07-06 02:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:09:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:39:09 --> Total execution time: 0.0534
DEBUG - 2022-07-06 02:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:09:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:39:13 --> Total execution time: 0.0494
DEBUG - 2022-07-06 02:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:40:32 --> Total execution time: 0.1212
DEBUG - 2022-07-06 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:40:35 --> Total execution time: 0.0427
DEBUG - 2022-07-06 02:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:41:27 --> Total execution time: 0.0341
DEBUG - 2022-07-06 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:43:34 --> Total execution time: 0.2571
DEBUG - 2022-07-06 02:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:43:38 --> Total execution time: 0.0565
DEBUG - 2022-07-06 02:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:43:43 --> Total execution time: 0.0660
DEBUG - 2022-07-06 02:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:15:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:45:09 --> Total execution time: 0.0629
DEBUG - 2022-07-06 02:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:45:19 --> Total execution time: 0.0589
DEBUG - 2022-07-06 02:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:45:31 --> Total execution time: 0.0551
DEBUG - 2022-07-06 02:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:15:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:45:40 --> Total execution time: 0.0548
DEBUG - 2022-07-06 02:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:46:08 --> Total execution time: 0.1194
DEBUG - 2022-07-06 02:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:21:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:21:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:51:27 --> Total execution time: 0.1342
DEBUG - 2022-07-06 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:51:33 --> Total execution time: 0.1340
DEBUG - 2022-07-06 02:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:57:51 --> Total execution time: 0.1244
DEBUG - 2022-07-06 02:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:58:10 --> Total execution time: 0.1034
DEBUG - 2022-07-06 02:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:58:20 --> Total execution time: 0.0877
DEBUG - 2022-07-06 02:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:20 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:58:20 --> Total execution time: 0.0391
DEBUG - 2022-07-06 02:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:28:48 --> Total execution time: 0.0715
DEBUG - 2022-07-06 02:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:59:02 --> Total execution time: 0.0970
DEBUG - 2022-07-06 02:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:29:11 --> Total execution time: 0.0431
DEBUG - 2022-07-06 02:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:59:13 --> Total execution time: 0.0703
DEBUG - 2022-07-06 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:59:24 --> Total execution time: 0.0644
DEBUG - 2022-07-06 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:59:40 --> Total execution time: 0.0909
DEBUG - 2022-07-06 02:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:00:03 --> Total execution time: 0.0715
DEBUG - 2022-07-06 02:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:00:10 --> Total execution time: 0.0568
DEBUG - 2022-07-06 02:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:00:28 --> Total execution time: 0.0592
DEBUG - 2022-07-06 02:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:01:08 --> Total execution time: 0.0546
DEBUG - 2022-07-06 02:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:32:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:02:18 --> Total execution time: 0.0535
DEBUG - 2022-07-06 02:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:02:40 --> Total execution time: 0.0466
DEBUG - 2022-07-06 02:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:32:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:32:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:02:42 --> Total execution time: 0.0416
DEBUG - 2022-07-06 02:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:04:14 --> Total execution time: 0.1218
DEBUG - 2022-07-06 02:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:04:24 --> Total execution time: 0.0669
DEBUG - 2022-07-06 02:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:40:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:10:00 --> Total execution time: 0.2440
DEBUG - 2022-07-06 02:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:10:04 --> Total execution time: 0.0759
DEBUG - 2022-07-06 02:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:18 --> Total execution time: 0.1184
DEBUG - 2022-07-06 02:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:18 --> Total execution time: 0.0503
DEBUG - 2022-07-06 02:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:21 --> Total execution time: 0.0324
DEBUG - 2022-07-06 02:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:28 --> Total execution time: 0.0312
DEBUG - 2022-07-06 02:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:28 --> Total execution time: 0.0390
DEBUG - 2022-07-06 02:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:36 --> Total execution time: 0.0467
DEBUG - 2022-07-06 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:37 --> Total execution time: 0.0578
DEBUG - 2022-07-06 02:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:45 --> Total execution time: 0.0522
DEBUG - 2022-07-06 02:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:50 --> Total execution time: 0.0808
DEBUG - 2022-07-06 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:56 --> Total execution time: 0.0450
DEBUG - 2022-07-06 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:01 --> Total execution time: 0.0601
DEBUG - 2022-07-06 02:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:08 --> Total execution time: 0.0695
DEBUG - 2022-07-06 02:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:10 --> Total execution time: 0.0486
DEBUG - 2022-07-06 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:20 --> Total execution time: 0.0482
DEBUG - 2022-07-06 02:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:56 --> Total execution time: 0.0371
DEBUG - 2022-07-06 02:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:43:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:43:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:13:56 --> Total execution time: 0.0284
DEBUG - 2022-07-06 02:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:03 --> Total execution time: 0.0468
DEBUG - 2022-07-06 02:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:28 --> Total execution time: 0.0570
DEBUG - 2022-07-06 02:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:33 --> Total execution time: 0.0623
DEBUG - 2022-07-06 02:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:37 --> Total execution time: 0.0789
DEBUG - 2022-07-06 02:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:42 --> Total execution time: 0.1033
DEBUG - 2022-07-06 02:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:49 --> Total execution time: 0.0538
DEBUG - 2022-07-06 02:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:52 --> Total execution time: 0.0678
DEBUG - 2022-07-06 02:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:14:56 --> Total execution time: 0.0580
DEBUG - 2022-07-06 02:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:15:22 --> Total execution time: 0.0491
DEBUG - 2022-07-06 02:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:48:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:18:31 --> Total execution time: 0.1059
DEBUG - 2022-07-06 02:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:50:43 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:20:43 --> Total execution time: 0.1070
DEBUG - 2022-07-06 02:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:14 --> Total execution time: 0.2823
DEBUG - 2022-07-06 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:20 --> Total execution time: 0.0960
DEBUG - 2022-07-06 02:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:23 --> Total execution time: 0.1243
DEBUG - 2022-07-06 02:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:31 --> Total execution time: 0.0601
DEBUG - 2022-07-06 02:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:31 --> Total execution time: 0.0404
DEBUG - 2022-07-06 02:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:33 --> Total execution time: 0.0579
DEBUG - 2022-07-06 02:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:38 --> Total execution time: 0.0698
DEBUG - 2022-07-06 02:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:41 --> Total execution time: 0.0629
DEBUG - 2022-07-06 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:45 --> Total execution time: 0.0680
DEBUG - 2022-07-06 02:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:47 --> Total execution time: 0.0746
DEBUG - 2022-07-06 02:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:50 --> Total execution time: 0.0649
DEBUG - 2022-07-06 02:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:51 --> Total execution time: 0.0734
DEBUG - 2022-07-06 02:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:53 --> Total execution time: 0.0595
DEBUG - 2022-07-06 02:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:54 --> Total execution time: 0.0538
DEBUG - 2022-07-06 02:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:55 --> Total execution time: 0.0613
DEBUG - 2022-07-06 02:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:21:55 --> Total execution time: 0.0615
DEBUG - 2022-07-06 02:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:52:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:22:00 --> Total execution time: 0.0751
DEBUG - 2022-07-06 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:22:05 --> Total execution time: 0.0802
DEBUG - 2022-07-06 02:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:22:05 --> Total execution time: 0.1269
DEBUG - 2022-07-06 02:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:22:08 --> Total execution time: 0.0583
DEBUG - 2022-07-06 02:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:22:44 --> Total execution time: 0.0521
DEBUG - 2022-07-06 02:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:53:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 02:53:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 02:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:24:08 --> Total execution time: 0.0520
DEBUG - 2022-07-06 02:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:24:18 --> Total execution time: 0.0715
DEBUG - 2022-07-06 02:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:24:27 --> Total execution time: 0.0549
DEBUG - 2022-07-06 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:55:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:25:53 --> Total execution time: 0.0433
DEBUG - 2022-07-06 02:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:55:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 02:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:25:54 --> Total execution time: 0.0370
DEBUG - 2022-07-06 02:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:25:56 --> Total execution time: 0.0612
DEBUG - 2022-07-06 02:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:25:57 --> Total execution time: 0.0828
DEBUG - 2022-07-06 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:00 --> Total execution time: 0.0317
DEBUG - 2022-07-06 02:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:14 --> Total execution time: 0.0541
DEBUG - 2022-07-06 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 02:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:20 --> Total execution time: 0.0589
DEBUG - 2022-07-06 02:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:21 --> Total execution time: 0.0634
DEBUG - 2022-07-06 02:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:24 --> Total execution time: 0.0613
DEBUG - 2022-07-06 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 02:56:25 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 02:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:26 --> Total execution time: 0.0614
DEBUG - 2022-07-06 02:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:28 --> Total execution time: 0.0630
DEBUG - 2022-07-06 02:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:34 --> Total execution time: 0.1284
DEBUG - 2022-07-06 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 02:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:26:49 --> Total execution time: 0.1042
DEBUG - 2022-07-06 02:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 02:58:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 02:58:36 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:30:02 --> Total execution time: 0.1302
DEBUG - 2022-07-06 03:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:30:50 --> Total execution time: 0.1094
DEBUG - 2022-07-06 03:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:00 --> Total execution time: 0.1575
DEBUG - 2022-07-06 03:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:04 --> Total execution time: 0.0707
DEBUG - 2022-07-06 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:09 --> Total execution time: 0.0846
DEBUG - 2022-07-06 03:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:13 --> Total execution time: 0.0795
DEBUG - 2022-07-06 03:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:16 --> Total execution time: 0.1710
DEBUG - 2022-07-06 03:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:19 --> Total execution time: 0.1086
DEBUG - 2022-07-06 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:21 --> Total execution time: 0.0678
DEBUG - 2022-07-06 03:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:23 --> Total execution time: 0.0707
DEBUG - 2022-07-06 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:35 --> Total execution time: 0.0629
DEBUG - 2022-07-06 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:42 --> Total execution time: 0.0748
DEBUG - 2022-07-06 03:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:44 --> Total execution time: 0.0728
DEBUG - 2022-07-06 03:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:32:49 --> Total execution time: 0.0717
DEBUG - 2022-07-06 03:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:08 --> Total execution time: 0.0638
DEBUG - 2022-07-06 03:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:26 --> Total execution time: 0.0593
DEBUG - 2022-07-06 03:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:57 --> Total execution time: 0.0967
DEBUG - 2022-07-06 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:34:00 --> Total execution time: 0.2633
DEBUG - 2022-07-06 03:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:34:02 --> Total execution time: 0.1085
DEBUG - 2022-07-06 03:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:04:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:34:07 --> Total execution time: 0.1175
DEBUG - 2022-07-06 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:10 --> Total execution time: 0.0581
DEBUG - 2022-07-06 03:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:18 --> Total execution time: 0.0557
DEBUG - 2022-07-06 03:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:50 --> Total execution time: 0.0603
DEBUG - 2022-07-06 03:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:58 --> Total execution time: 0.0904
DEBUG - 2022-07-06 03:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:37:30 --> Total execution time: 0.0516
DEBUG - 2022-07-06 03:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:37:53 --> Total execution time: 0.0548
DEBUG - 2022-07-06 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:00 --> Total execution time: 0.0575
DEBUG - 2022-07-06 03:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:26 --> Total execution time: 0.0505
DEBUG - 2022-07-06 03:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:31 --> Total execution time: 0.0568
DEBUG - 2022-07-06 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:32 --> Total execution time: 0.0577
DEBUG - 2022-07-06 03:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:39 --> Total execution time: 0.0554
DEBUG - 2022-07-06 03:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:44 --> Total execution time: 0.0582
DEBUG - 2022-07-06 03:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:38:47 --> Total execution time: 0.0732
DEBUG - 2022-07-06 03:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:39:00 --> Total execution time: 0.0538
DEBUG - 2022-07-06 03:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:39:01 --> Total execution time: 0.0547
DEBUG - 2022-07-06 03:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:39:08 --> Total execution time: 0.0516
DEBUG - 2022-07-06 03:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:09:46 --> Total execution time: 0.0829
DEBUG - 2022-07-06 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:07 --> Total execution time: 0.0510
DEBUG - 2022-07-06 03:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:20 --> Total execution time: 0.0474
DEBUG - 2022-07-06 03:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:10:35 --> Total execution time: 0.0474
DEBUG - 2022-07-06 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:13 --> Total execution time: 0.0469
DEBUG - 2022-07-06 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:14 --> Total execution time: 0.0568
DEBUG - 2022-07-06 03:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:16 --> Total execution time: 0.0609
DEBUG - 2022-07-06 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:19 --> Total execution time: 0.0596
DEBUG - 2022-07-06 03:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:20 --> Total execution time: 0.0476
DEBUG - 2022-07-06 03:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:23 --> Total execution time: 0.0503
DEBUG - 2022-07-06 03:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:24 --> Total execution time: 0.0550
DEBUG - 2022-07-06 03:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:25 --> Total execution time: 0.0520
DEBUG - 2022-07-06 03:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:26 --> Total execution time: 0.0439
DEBUG - 2022-07-06 03:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:26 --> Total execution time: 0.0569
DEBUG - 2022-07-06 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:41:30 --> Total execution time: 0.0601
DEBUG - 2022-07-06 03:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:41:34 --> Total execution time: 0.0596
DEBUG - 2022-07-06 03:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:13:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:44 --> Total execution time: 0.1995
DEBUG - 2022-07-06 03:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:18:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:48:44 --> Total execution time: 0.1133
DEBUG - 2022-07-06 03:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:48:47 --> Total execution time: 0.0391
DEBUG - 2022-07-06 03:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:48:55 --> Total execution time: 0.0802
DEBUG - 2022-07-06 03:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:49:01 --> Total execution time: 0.0688
DEBUG - 2022-07-06 03:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:49:03 --> Total execution time: 0.0799
DEBUG - 2022-07-06 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:49:10 --> Total execution time: 0.0486
DEBUG - 2022-07-06 03:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:49:28 --> Total execution time: 0.1683
DEBUG - 2022-07-06 03:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:50:04 --> Total execution time: 0.0327
DEBUG - 2022-07-06 03:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:05 --> Total execution time: 0.0654
DEBUG - 2022-07-06 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:19 --> Total execution time: 0.0486
DEBUG - 2022-07-06 03:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:24 --> Total execution time: 0.0352
DEBUG - 2022-07-06 03:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:25 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:25 --> Total execution time: 0.0506
DEBUG - 2022-07-06 03:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:30 --> Total execution time: 0.0575
DEBUG - 2022-07-06 03:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:34 --> Total execution time: 0.0361
DEBUG - 2022-07-06 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:54 --> Total execution time: 0.0751
DEBUG - 2022-07-06 03:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:50:59 --> Total execution time: 0.0770
DEBUG - 2022-07-06 03:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:51:09 --> Total execution time: 0.0608
DEBUG - 2022-07-06 03:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:51:13 --> Total execution time: 0.0766
DEBUG - 2022-07-06 03:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:21:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:51:21 --> Total execution time: 0.0683
DEBUG - 2022-07-06 03:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 03:22:35 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 03:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:26:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:56:37 --> Total execution time: 0.1505
DEBUG - 2022-07-06 03:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:58:18 --> Total execution time: 0.0431
DEBUG - 2022-07-06 03:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:58:20 --> Total execution time: 0.0536
DEBUG - 2022-07-06 03:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:29:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:59:13 --> Total execution time: 0.0374
DEBUG - 2022-07-06 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:59:22 --> Total execution time: 0.1545
DEBUG - 2022-07-06 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:30:23 --> Total execution time: 0.0429
DEBUG - 2022-07-06 03:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:30:25 --> Total execution time: 0.0579
DEBUG - 2022-07-06 03:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:30:25 --> Total execution time: 0.1176
DEBUG - 2022-07-06 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:30:47 --> Total execution time: 0.0511
DEBUG - 2022-07-06 03:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:30:55 --> Total execution time: 0.0621
DEBUG - 2022-07-06 03:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:30:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:30:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:00:57 --> Total execution time: 0.0498
DEBUG - 2022-07-06 03:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:13 --> Total execution time: 0.2147
DEBUG - 2022-07-06 03:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:22 --> Total execution time: 0.0684
DEBUG - 2022-07-06 03:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:24 --> Total execution time: 0.0640
DEBUG - 2022-07-06 03:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:43 --> Total execution time: 0.0578
DEBUG - 2022-07-06 03:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:45 --> Total execution time: 0.0646
DEBUG - 2022-07-06 03:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:47 --> Total execution time: 0.0943
DEBUG - 2022-07-06 03:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:04:52 --> Total execution time: 0.0590
DEBUG - 2022-07-06 03:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:05:03 --> Total execution time: 0.0717
DEBUG - 2022-07-06 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:05:21 --> Total execution time: 0.0827
DEBUG - 2022-07-06 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:35:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:05:21 --> Total execution time: 0.1475
DEBUG - 2022-07-06 03:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:36:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:06:21 --> Total execution time: 0.0355
DEBUG - 2022-07-06 03:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:36:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:06:42 --> Total execution time: 0.0413
DEBUG - 2022-07-06 03:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:36:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:06:51 --> Total execution time: 0.0410
DEBUG - 2022-07-06 03:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:44:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:14:14 --> Total execution time: 0.1092
DEBUG - 2022-07-06 03:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:14:21 --> Total execution time: 0.0395
DEBUG - 2022-07-06 03:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:14:35 --> Total execution time: 0.0568
DEBUG - 2022-07-06 03:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:04 --> Total execution time: 0.0529
DEBUG - 2022-07-06 03:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:18 --> Total execution time: 0.0635
DEBUG - 2022-07-06 03:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:35 --> Total execution time: 0.0478
DEBUG - 2022-07-06 03:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:46 --> Total execution time: 0.0515
DEBUG - 2022-07-06 03:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:53 --> Total execution time: 0.0665
DEBUG - 2022-07-06 03:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 03:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:45:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:15:54 --> Total execution time: 0.0483
DEBUG - 2022-07-06 03:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:16:49 --> Total execution time: 0.0589
DEBUG - 2022-07-06 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:17:28 --> Total execution time: 0.0508
DEBUG - 2022-07-06 03:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:17:36 --> Total execution time: 0.0649
DEBUG - 2022-07-06 03:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:17:40 --> Total execution time: 0.1139
DEBUG - 2022-07-06 03:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:17:54 --> Total execution time: 0.0867
DEBUG - 2022-07-06 03:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:17:58 --> Total execution time: 0.0746
DEBUG - 2022-07-06 03:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:18:08 --> Total execution time: 0.1248
DEBUG - 2022-07-06 03:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:19:00 --> Total execution time: 0.0862
DEBUG - 2022-07-06 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:50:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 03:50:28 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:52:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:22:34 --> Total execution time: 0.0830
DEBUG - 2022-07-06 03:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:22:42 --> Total execution time: 0.0490
DEBUG - 2022-07-06 03:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:10 --> Total execution time: 0.0551
DEBUG - 2022-07-06 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:17 --> Total execution time: 0.0535
DEBUG - 2022-07-06 03:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:21 --> Total execution time: 0.0857
DEBUG - 2022-07-06 03:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:30 --> Total execution time: 0.0791
DEBUG - 2022-07-06 03:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:45 --> Total execution time: 0.0523
DEBUG - 2022-07-06 03:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:23:55 --> Total execution time: 0.0515
DEBUG - 2022-07-06 03:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:24:18 --> Total execution time: 0.0496
DEBUG - 2022-07-06 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:24:22 --> Total execution time: 0.0508
DEBUG - 2022-07-06 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 03:54:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 03:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:24:22 --> Total execution time: 0.0575
DEBUG - 2022-07-06 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:30:03 --> Total execution time: 0.1988
DEBUG - 2022-07-06 04:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:01:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:31:19 --> Total execution time: 0.0453
DEBUG - 2022-07-06 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:31:24 --> Total execution time: 0.0504
DEBUG - 2022-07-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:31:31 --> Total execution time: 0.0507
DEBUG - 2022-07-06 04:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:06 --> Total execution time: 0.0528
DEBUG - 2022-07-06 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:13 --> Total execution time: 0.0482
DEBUG - 2022-07-06 04:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:23 --> Total execution time: 0.0424
DEBUG - 2022-07-06 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:26 --> Total execution time: 0.0583
DEBUG - 2022-07-06 04:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:37 --> Total execution time: 0.0671
DEBUG - 2022-07-06 04:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:38 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:38 --> Total execution time: 0.0456
DEBUG - 2022-07-06 04:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:05:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:35:01 --> Total execution time: 0.0826
DEBUG - 2022-07-06 04:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:36:12 --> Total execution time: 0.0649
DEBUG - 2022-07-06 04:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:36:16 --> Total execution time: 0.0540
DEBUG - 2022-07-06 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:36:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:36:17 --> Total execution time: 0.0562
DEBUG - 2022-07-06 04:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:10:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:40:57 --> Total execution time: 0.1380
DEBUG - 2022-07-06 04:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:41:12 --> Total execution time: 0.0542
DEBUG - 2022-07-06 04:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:42:04 --> Total execution time: 0.0571
DEBUG - 2022-07-06 04:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:12:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:42:41 --> Total execution time: 0.0523
DEBUG - 2022-07-06 04:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:42:52 --> Total execution time: 0.0659
DEBUG - 2022-07-06 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:43:00 --> Total execution time: 0.0526
DEBUG - 2022-07-06 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:43:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:43:01 --> Total execution time: 0.0687
DEBUG - 2022-07-06 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:45:19 --> Total execution time: 0.0708
DEBUG - 2022-07-06 04:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:46:42 --> Total execution time: 0.0497
DEBUG - 2022-07-06 04:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:47:21 --> Total execution time: 0.0599
DEBUG - 2022-07-06 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:18:02 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:48:02 --> Total execution time: 0.1025
DEBUG - 2022-07-06 04:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:48:10 --> Total execution time: 0.0496
DEBUG - 2022-07-06 04:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:48:29 --> Total execution time: 0.0320
DEBUG - 2022-07-06 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:48:52 --> Total execution time: 0.0571
DEBUG - 2022-07-06 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:49:00 --> Total execution time: 0.0527
DEBUG - 2022-07-06 04:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:49:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:19:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:49:01 --> Total execution time: 0.0880
DEBUG - 2022-07-06 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:51:05 --> Total execution time: 0.1239
DEBUG - 2022-07-06 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:51:06 --> Total execution time: 0.0781
DEBUG - 2022-07-06 04:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:51:13 --> Total execution time: 0.0525
DEBUG - 2022-07-06 04:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:51:25 --> Total execution time: 0.0682
DEBUG - 2022-07-06 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:51:54 --> Total execution time: 0.0506
DEBUG - 2022-07-06 04:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:52:18 --> Total execution time: 0.0378
DEBUG - 2022-07-06 04:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:52:22 --> Total execution time: 0.0373
DEBUG - 2022-07-06 04:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:52:40 --> Total execution time: 0.0751
DEBUG - 2022-07-06 04:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:52:41 --> Total execution time: 0.0469
DEBUG - 2022-07-06 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:52:45 --> Total execution time: 0.0535
DEBUG - 2022-07-06 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:09 --> Total execution time: 0.0399
DEBUG - 2022-07-06 04:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:11 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:11 --> Total execution time: 0.0523
DEBUG - 2022-07-06 04:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:32 --> Total execution time: 0.0554
DEBUG - 2022-07-06 04:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:41 --> Total execution time: 0.0329
DEBUG - 2022-07-06 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:46 --> Total execution time: 0.0909
DEBUG - 2022-07-06 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:53:55 --> Total execution time: 0.0690
DEBUG - 2022-07-06 04:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:54:19 --> Total execution time: 0.1021
DEBUG - 2022-07-06 04:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:54:24 --> Total execution time: 0.0755
DEBUG - 2022-07-06 04:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:54:29 --> Total execution time: 0.0770
DEBUG - 2022-07-06 04:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:54:35 --> Total execution time: 0.0820
DEBUG - 2022-07-06 04:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:24:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:54:48 --> Total execution time: 0.0573
DEBUG - 2022-07-06 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:55:18 --> Total execution time: 0.0487
DEBUG - 2022-07-06 14:55:18 --> Total execution time: 0.0678
DEBUG - 2022-07-06 04:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:55:34 --> Total execution time: 0.0733
DEBUG - 2022-07-06 04:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:00 --> Total execution time: 0.0346
DEBUG - 2022-07-06 04:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:04 --> Total execution time: 0.0692
DEBUG - 2022-07-06 04:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:13 --> Total execution time: 0.0611
DEBUG - 2022-07-06 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:24 --> Total execution time: 0.1423
DEBUG - 2022-07-06 04:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:36 --> Total execution time: 0.0498
DEBUG - 2022-07-06 04:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:50 --> Total execution time: 0.0527
DEBUG - 2022-07-06 04:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:56:58 --> Total execution time: 0.0805
DEBUG - 2022-07-06 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:15 --> Total execution time: 0.0918
DEBUG - 2022-07-06 04:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:35 --> Total execution time: 0.0724
DEBUG - 2022-07-06 04:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:37 --> Total execution time: 0.0574
DEBUG - 2022-07-06 04:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:38 --> Total execution time: 0.0942
DEBUG - 2022-07-06 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:43 --> Total execution time: 0.0555
DEBUG - 2022-07-06 04:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:43 --> Total execution time: 0.0659
DEBUG - 2022-07-06 04:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:43 --> Total execution time: 0.0479
DEBUG - 2022-07-06 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:45 --> Total execution time: 0.0642
DEBUG - 2022-07-06 04:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:46 --> Total execution time: 0.0521
DEBUG - 2022-07-06 04:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:48 --> Total execution time: 0.0872
DEBUG - 2022-07-06 04:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:51 --> Total execution time: 0.0498
DEBUG - 2022-07-06 04:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:52 --> Total execution time: 0.0549
DEBUG - 2022-07-06 04:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:55 --> Total execution time: 0.0578
DEBUG - 2022-07-06 04:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:56 --> Total execution time: 0.0542
DEBUG - 2022-07-06 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:58 --> Total execution time: 0.0533
DEBUG - 2022-07-06 04:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:58 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:59 --> Total execution time: 0.0529
DEBUG - 2022-07-06 04:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:27:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:57:59 --> Total execution time: 0.0547
DEBUG - 2022-07-06 04:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:58:05 --> Total execution time: 0.0567
DEBUG - 2022-07-06 04:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:58:15 --> Total execution time: 0.1438
DEBUG - 2022-07-06 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:58:44 --> Total execution time: 0.1369
DEBUG - 2022-07-06 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:58:46 --> Total execution time: 0.0704
DEBUG - 2022-07-06 04:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:58:50 --> Total execution time: 0.1050
DEBUG - 2022-07-06 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:08 --> Total execution time: 0.1295
DEBUG - 2022-07-06 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:17 --> Total execution time: 0.0755
DEBUG - 2022-07-06 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:19 --> Total execution time: 0.0508
DEBUG - 2022-07-06 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:20 --> Total execution time: 0.0648
DEBUG - 2022-07-06 04:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:22 --> Total execution time: 0.0521
DEBUG - 2022-07-06 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:23 --> Total execution time: 0.0615
DEBUG - 2022-07-06 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:24 --> Total execution time: 0.0633
DEBUG - 2022-07-06 04:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:29:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:59:24 --> Total execution time: 0.0463
DEBUG - 2022-07-06 04:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:14 --> Total execution time: 0.0694
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Configjs/index
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Phpinfo/index
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Phpinfophp/index
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Infophp/index
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: _profiler/phpinfo
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Debug/default
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: Aws/credentials
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: _profiler/index
ERROR - 2022-07-06 04:30:16 --> 404 Page Not Found: App_devphp/_profiler
DEBUG - 2022-07-06 04:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:16 --> Total execution time: 0.0569
DEBUG - 2022-07-06 04:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:24 --> Total execution time: 0.0488
DEBUG - 2022-07-06 04:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:28 --> Total execution time: 0.0503
DEBUG - 2022-07-06 04:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:41 --> Total execution time: 0.0619
DEBUG - 2022-07-06 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:44 --> Total execution time: 0.0716
DEBUG - 2022-07-06 04:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:56 --> Total execution time: 0.0481
DEBUG - 2022-07-06 04:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:31:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:01:38 --> Total execution time: 0.0393
DEBUG - 2022-07-06 04:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:17 --> Total execution time: 0.1253
DEBUG - 2022-07-06 04:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:24 --> Total execution time: 0.0591
DEBUG - 2022-07-06 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:25 --> Total execution time: 0.0477
DEBUG - 2022-07-06 04:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:26 --> Total execution time: 0.0504
DEBUG - 2022-07-06 04:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:26 --> Total execution time: 0.0921
DEBUG - 2022-07-06 04:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:27 --> Total execution time: 0.0609
DEBUG - 2022-07-06 04:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:27 --> Total execution time: 0.0490
DEBUG - 2022-07-06 04:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:28 --> Total execution time: 0.0481
DEBUG - 2022-07-06 04:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:29 --> Total execution time: 0.0542
DEBUG - 2022-07-06 04:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:29 --> Total execution time: 0.0703
DEBUG - 2022-07-06 04:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:29 --> Total execution time: 0.0618
DEBUG - 2022-07-06 04:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:30 --> Total execution time: 0.0677
DEBUG - 2022-07-06 04:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:30 --> Total execution time: 0.0562
DEBUG - 2022-07-06 04:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:31 --> Total execution time: 0.0503
DEBUG - 2022-07-06 04:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:31 --> Total execution time: 0.0586
DEBUG - 2022-07-06 04:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:32 --> Total execution time: 0.0487
DEBUG - 2022-07-06 04:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:33 --> Total execution time: 0.0541
DEBUG - 2022-07-06 04:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:33 --> Total execution time: 0.0492
DEBUG - 2022-07-06 04:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:41 --> Total execution time: 0.0493
DEBUG - 2022-07-06 04:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:42 --> Total execution time: 0.0831
DEBUG - 2022-07-06 04:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:42 --> Total execution time: 0.0477
DEBUG - 2022-07-06 04:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:48 --> Total execution time: 0.1313
DEBUG - 2022-07-06 04:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:52 --> Total execution time: 0.0639
DEBUG - 2022-07-06 04:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:53 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:04:54 --> Total execution time: 0.0637
DEBUG - 2022-07-06 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:35:56 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 04:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:37:46 --> Total execution time: 0.0652
DEBUG - 2022-07-06 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:07:48 --> Total execution time: 0.0557
DEBUG - 2022-07-06 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:37:49 --> Total execution time: 0.1485
DEBUG - 2022-07-06 04:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:37:49 --> Total execution time: 0.2199
DEBUG - 2022-07-06 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:07:49 --> Total execution time: 0.1093
DEBUG - 2022-07-06 04:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:07:57 --> Total execution time: 0.0527
DEBUG - 2022-07-06 04:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:00 --> Total execution time: 0.2034
DEBUG - 2022-07-06 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:38:06 --> Total execution time: 0.0897
DEBUG - 2022-07-06 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:38:07 --> Total execution time: 0.1076
DEBUG - 2022-07-06 04:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:38:08 --> Total execution time: 0.2209
DEBUG - 2022-07-06 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:25 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:25 --> Total execution time: 0.0776
DEBUG - 2022-07-06 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:38:36 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 04:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:44 --> Total execution time: 0.0865
DEBUG - 2022-07-06 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:49 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:49 --> Total execution time: 0.0825
DEBUG - 2022-07-06 04:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:54 --> Total execution time: 0.0587
DEBUG - 2022-07-06 04:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:38:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:38:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:08:57 --> Total execution time: 0.1655
DEBUG - 2022-07-06 04:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:06 --> Total execution time: 0.1179
DEBUG - 2022-07-06 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:10 --> Total execution time: 0.0831
DEBUG - 2022-07-06 04:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:17 --> Total execution time: 0.1412
DEBUG - 2022-07-06 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:17 --> Total execution time: 0.1385
DEBUG - 2022-07-06 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:17 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 04:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:18 --> Total execution time: 0.0842
DEBUG - 2022-07-06 04:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:29 --> Total execution time: 0.1357
DEBUG - 2022-07-06 04:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:37 --> Total execution time: 0.1032
DEBUG - 2022-07-06 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:39 --> Total execution time: 0.0756
DEBUG - 2022-07-06 04:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:39 --> Total execution time: 0.1224
DEBUG - 2022-07-06 04:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:42 --> Total execution time: 0.1731
DEBUG - 2022-07-06 04:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:46 --> Total execution time: 0.0798
DEBUG - 2022-07-06 04:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:09:49 --> Total execution time: 0.0835
DEBUG - 2022-07-06 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:10:00 --> Total execution time: 0.1533
DEBUG - 2022-07-06 04:40:00 --> Total execution time: 0.1399
DEBUG - 2022-07-06 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:01 --> Total execution time: 0.2321
DEBUG - 2022-07-06 04:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:02 --> Total execution time: 0.5584
DEBUG - 2022-07-06 04:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:03 --> Total execution time: 0.0590
DEBUG - 2022-07-06 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:04 --> Total execution time: 0.0765
DEBUG - 2022-07-06 04:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:40:04 --> Total execution time: 0.1446
DEBUG - 2022-07-06 04:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:10:09 --> Total execution time: 0.0683
DEBUG - 2022-07-06 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:10:19 --> Total execution time: 0.2031
DEBUG - 2022-07-06 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:10:23 --> Total execution time: 0.0719
DEBUG - 2022-07-06 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:40:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:10:23 --> Total execution time: 0.0632
DEBUG - 2022-07-06 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:40:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 04:40:49 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 04:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:11:01 --> Total execution time: 0.0506
DEBUG - 2022-07-06 04:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:11:07 --> Total execution time: 0.0538
DEBUG - 2022-07-06 04:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:14:59 --> Total execution time: 0.1156
DEBUG - 2022-07-06 04:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:15:03 --> Total execution time: 0.0715
DEBUG - 2022-07-06 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:45:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:15:35 --> Total execution time: 0.0568
DEBUG - 2022-07-06 04:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:45:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:15:47 --> Total execution time: 0.0664
DEBUG - 2022-07-06 04:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:46:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:16:03 --> Total execution time: 0.0798
DEBUG - 2022-07-06 04:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:16:07 --> Total execution time: 0.0941
DEBUG - 2022-07-06 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:46:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:16:31 --> Total execution time: 0.0645
DEBUG - 2022-07-06 04:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:17:52 --> Total execution time: 0.0905
DEBUG - 2022-07-06 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:19:12 --> Total execution time: 0.1067
DEBUG - 2022-07-06 04:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:50:10 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:20:10 --> Total execution time: 0.0515
DEBUG - 2022-07-06 04:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:20:19 --> Total execution time: 0.1698
DEBUG - 2022-07-06 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:50:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:20:49 --> Total execution time: 0.0437
DEBUG - 2022-07-06 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:55:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:25:30 --> Total execution time: 0.1933
DEBUG - 2022-07-06 04:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:28:51 --> Total execution time: 0.0497
DEBUG - 2022-07-06 04:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 04:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 04:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 04:59:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:29:02 --> Total execution time: 0.0551
DEBUG - 2022-07-06 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:30:02 --> Total execution time: 0.0655
DEBUG - 2022-07-06 05:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:30:15 --> Total execution time: 0.0911
DEBUG - 2022-07-06 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:30:48 --> Total execution time: 0.0565
DEBUG - 2022-07-06 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:30:49 --> Total execution time: 0.0674
DEBUG - 2022-07-06 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:32:05 --> Total execution time: 0.1593
DEBUG - 2022-07-06 05:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:34:50 --> Total execution time: 0.0393
DEBUG - 2022-07-06 05:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:05:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:05:28 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 05:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:05:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:35:37 --> Total execution time: 0.0830
DEBUG - 2022-07-06 05:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:10:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:40:48 --> Total execution time: 0.1396
DEBUG - 2022-07-06 05:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:40:52 --> Total execution time: 0.0352
DEBUG - 2022-07-06 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:02 --> Total execution time: 0.0757
DEBUG - 2022-07-06 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:06 --> Total execution time: 0.0807
DEBUG - 2022-07-06 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:21 --> Total execution time: 0.0618
DEBUG - 2022-07-06 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:21 --> Total execution time: 0.0448
DEBUG - 2022-07-06 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:31 --> Total execution time: 0.0679
DEBUG - 2022-07-06 05:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:32 --> Total execution time: 0.0537
DEBUG - 2022-07-06 05:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:39 --> Total execution time: 0.0500
DEBUG - 2022-07-06 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:43 --> Total execution time: 0.0613
DEBUG - 2022-07-06 05:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:46 --> Total execution time: 0.0676
DEBUG - 2022-07-06 05:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:49 --> Total execution time: 0.0677
DEBUG - 2022-07-06 05:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:41:54 --> Total execution time: 0.0698
DEBUG - 2022-07-06 05:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:42:16 --> Total execution time: 0.0378
DEBUG - 2022-07-06 05:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:43:13 --> Total execution time: 0.0485
DEBUG - 2022-07-06 05:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:13:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:13:57 --> Total execution time: 0.0773
DEBUG - 2022-07-06 05:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:43:59 --> Total execution time: 0.0349
DEBUG - 2022-07-06 05:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:14:00 --> Total execution time: 0.0647
DEBUG - 2022-07-06 05:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:14:00 --> Total execution time: 0.1299
DEBUG - 2022-07-06 05:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:04 --> Total execution time: 0.0653
DEBUG - 2022-07-06 05:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:12 --> Total execution time: 0.0520
DEBUG - 2022-07-06 05:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:25 --> Total execution time: 0.1097
DEBUG - 2022-07-06 05:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:26 --> Total execution time: 0.0499
DEBUG - 2022-07-06 05:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:28 --> Total execution time: 0.0492
DEBUG - 2022-07-06 05:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:29 --> Total execution time: 0.0538
DEBUG - 2022-07-06 05:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:14:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:32 --> Total execution time: 0.0474
DEBUG - 2022-07-06 05:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:36 --> Total execution time: 0.0651
DEBUG - 2022-07-06 05:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:45:04 --> Total execution time: 0.0501
DEBUG - 2022-07-06 05:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:47:07 --> Total execution time: 0.1012
DEBUG - 2022-07-06 05:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:18:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:23 --> Total execution time: 0.0405
DEBUG - 2022-07-06 05:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:19:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:49:31 --> Total execution time: 0.0399
DEBUG - 2022-07-06 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:49:35 --> Total execution time: 0.0567
DEBUG - 2022-07-06 05:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:20:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:20:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:05 --> Total execution time: 0.0622
DEBUG - 2022-07-06 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:40 --> Total execution time: 0.0957
DEBUG - 2022-07-06 05:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:20:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:48 --> Total execution time: 0.0521
DEBUG - 2022-07-06 05:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:03 --> Total execution time: 0.0583
DEBUG - 2022-07-06 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:14 --> Total execution time: 0.0770
DEBUG - 2022-07-06 05:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:23 --> Total execution time: 0.0602
DEBUG - 2022-07-06 05:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:35 --> Total execution time: 0.1114
DEBUG - 2022-07-06 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:39 --> Total execution time: 0.0566
DEBUG - 2022-07-06 05:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:42 --> Total execution time: 0.0588
DEBUG - 2022-07-06 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:47 --> Total execution time: 0.0324
DEBUG - 2022-07-06 05:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:48 --> Total execution time: 0.0345
DEBUG - 2022-07-06 05:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:51:48 --> Total execution time: 0.0374
DEBUG - 2022-07-06 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:52:08 --> Total execution time: 0.0533
DEBUG - 2022-07-06 05:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:52:08 --> Total execution time: 0.1009
DEBUG - 2022-07-06 05:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:10 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:52:10 --> Total execution time: 0.0528
DEBUG - 2022-07-06 05:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:52:24 --> Total execution time: 0.0657
DEBUG - 2022-07-06 05:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:22:38 --> Total execution time: 0.0516
DEBUG - 2022-07-06 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:22:40 --> Total execution time: 0.0570
DEBUG - 2022-07-06 05:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:22:40 --> Total execution time: 0.1054
DEBUG - 2022-07-06 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:22:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:52:45 --> Total execution time: 0.0630
DEBUG - 2022-07-06 05:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:53:06 --> Total execution time: 0.0611
DEBUG - 2022-07-06 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:53:15 --> Total execution time: 0.0792
DEBUG - 2022-07-06 05:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:53:18 --> Total execution time: 0.0624
DEBUG - 2022-07-06 05:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:23:27 --> Total execution time: 0.0512
DEBUG - 2022-07-06 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:23:29 --> Total execution time: 0.0545
DEBUG - 2022-07-06 05:23:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:23:29 --> Total execution time: 0.0951
DEBUG - 2022-07-06 05:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:53:52 --> Total execution time: 0.0502
DEBUG - 2022-07-06 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:25:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:25:24 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:25:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:55:27 --> Total execution time: 2.0812
DEBUG - 2022-07-06 05:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:56:20 --> Total execution time: 0.0639
DEBUG - 2022-07-06 05:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:56:21 --> Total execution time: 0.0652
DEBUG - 2022-07-06 05:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:56:31 --> Total execution time: 0.1356
DEBUG - 2022-07-06 05:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:56:39 --> Total execution time: 0.0499
DEBUG - 2022-07-06 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:56:44 --> Total execution time: 0.0540
DEBUG - 2022-07-06 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:27:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:57:27 --> Total execution time: 0.0547
DEBUG - 2022-07-06 05:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:27:42 --> Total execution time: 0.0772
DEBUG - 2022-07-06 05:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:27:45 --> Total execution time: 0.0912
DEBUG - 2022-07-06 05:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:27:45 --> Total execution time: 0.1721
DEBUG - 2022-07-06 05:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:58:09 --> Total execution time: 0.0384
DEBUG - 2022-07-06 05:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:58:12 --> Total execution time: 0.0387
DEBUG - 2022-07-06 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:58:20 --> Total execution time: 0.0560
DEBUG - 2022-07-06 05:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:58:23 --> Total execution time: 0.0573
DEBUG - 2022-07-06 05:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:58:29 --> Total execution time: 0.0591
DEBUG - 2022-07-06 05:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:29:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:29:23 --> Total execution time: 0.0505
DEBUG - 2022-07-06 05:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:29:26 --> Total execution time: 0.0722
DEBUG - 2022-07-06 05:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:29:26 --> Total execution time: 0.0909
DEBUG - 2022-07-06 05:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:29:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:59:41 --> Total execution time: 0.0601
DEBUG - 2022-07-06 05:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:00:27 --> Total execution time: 0.0427
DEBUG - 2022-07-06 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:30:30 --> Total execution time: 0.0514
DEBUG - 2022-07-06 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:30:33 --> Total execution time: 0.0691
DEBUG - 2022-07-06 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:30:33 --> Total execution time: 0.0710
DEBUG - 2022-07-06 05:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:30:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:00:56 --> Total execution time: 0.0485
DEBUG - 2022-07-06 05:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:31:08 --> Total execution time: 0.1234
DEBUG - 2022-07-06 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:31:09 --> Total execution time: 0.0585
DEBUG - 2022-07-06 05:31:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:31:09 --> Total execution time: 0.0925
DEBUG - 2022-07-06 05:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:18 --> Total execution time: 0.0546
DEBUG - 2022-07-06 05:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:21 --> Total execution time: 0.0585
DEBUG - 2022-07-06 05:31:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:24 --> Total execution time: 0.0732
DEBUG - 2022-07-06 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:27 --> Total execution time: 0.0696
DEBUG - 2022-07-06 05:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:40 --> Total execution time: 0.0734
DEBUG - 2022-07-06 05:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:31:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:46 --> Total execution time: 0.0532
DEBUG - 2022-07-06 05:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:02:16 --> Total execution time: 0.0707
DEBUG - 2022-07-06 05:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:33:49 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:03:49 --> Total execution time: 0.0389
DEBUG - 2022-07-06 05:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:33:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:33:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 05:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:14 --> Total execution time: 0.0516
DEBUG - 2022-07-06 05:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:26 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:26 --> Total execution time: 0.0576
DEBUG - 2022-07-06 05:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:43 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:43 --> Total execution time: 0.0591
DEBUG - 2022-07-06 05:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:45 --> Total execution time: 0.0634
DEBUG - 2022-07-06 05:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:50 --> Total execution time: 0.0704
DEBUG - 2022-07-06 05:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:04:54 --> Total execution time: 0.0975
DEBUG - 2022-07-06 05:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:05:06 --> Total execution time: 0.0546
DEBUG - 2022-07-06 05:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:05:09 --> Total execution time: 0.0576
DEBUG - 2022-07-06 05:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:05:14 --> Total execution time: 0.0607
DEBUG - 2022-07-06 05:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:35:22 --> Total execution time: 0.0546
DEBUG - 2022-07-06 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:35:23 --> Total execution time: 0.0717
DEBUG - 2022-07-06 05:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:35:23 --> Total execution time: 0.1652
DEBUG - 2022-07-06 05:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:36:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:06:00 --> Total execution time: 0.0399
DEBUG - 2022-07-06 05:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:36:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:36:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 05:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:07 --> Total execution time: 0.1063
DEBUG - 2022-07-06 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:39 --> Total execution time: 0.0565
DEBUG - 2022-07-06 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:51 --> Total execution time: 0.1414
DEBUG - 2022-07-06 05:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:52 --> Total execution time: 0.0617
DEBUG - 2022-07-06 05:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:53 --> Total execution time: 0.0324
DEBUG - 2022-07-06 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:08:55 --> Total execution time: 0.0513
DEBUG - 2022-07-06 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:09:00 --> Total execution time: 0.0492
DEBUG - 2022-07-06 05:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:39:33 --> Total execution time: 0.1687
DEBUG - 2022-07-06 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:39:34 --> Total execution time: 0.0529
DEBUG - 2022-07-06 05:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:39:35 --> Total execution time: 0.0840
DEBUG - 2022-07-06 05:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:39:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:39:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:09:56 --> Total execution time: 0.0570
DEBUG - 2022-07-06 05:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:40:03 --> Total execution time: 0.0501
DEBUG - 2022-07-06 05:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:40:04 --> Total execution time: 0.0589
DEBUG - 2022-07-06 05:40:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:40:04 --> Total execution time: 0.1116
DEBUG - 2022-07-06 05:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:10:36 --> Total execution time: 0.1523
DEBUG - 2022-07-06 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:10:43 --> Total execution time: 0.0659
DEBUG - 2022-07-06 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:10:48 --> Total execution time: 0.0583
DEBUG - 2022-07-06 05:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:05 --> Total execution time: 0.0622
DEBUG - 2022-07-06 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:11 --> Total execution time: 0.0576
DEBUG - 2022-07-06 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:16 --> Total execution time: 0.0549
DEBUG - 2022-07-06 05:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:20 --> Total execution time: 0.0653
DEBUG - 2022-07-06 05:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:23 --> Total execution time: 0.0766
DEBUG - 2022-07-06 05:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:27 --> Total execution time: 0.0565
DEBUG - 2022-07-06 05:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:41:29 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:30 --> Total execution time: 0.0470
DEBUG - 2022-07-06 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:30 --> Total execution time: 0.0379
DEBUG - 2022-07-06 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:41:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:34 --> Total execution time: 0.0479
DEBUG - 2022-07-06 05:41:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:38 --> Total execution time: 0.1337
DEBUG - 2022-07-06 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:41:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:43 --> Total execution time: 0.0624
DEBUG - 2022-07-06 16:11:44 --> Total execution time: 1.6065
DEBUG - 2022-07-06 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:41:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:11:47 --> Total execution time: 0.0752
DEBUG - 2022-07-06 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:03 --> Total execution time: 0.0703
DEBUG - 2022-07-06 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:03 --> Total execution time: 0.0474
DEBUG - 2022-07-06 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:08 --> Total execution time: 0.0466
DEBUG - 2022-07-06 05:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:11 --> Total execution time: 0.0511
DEBUG - 2022-07-06 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:42:14 --> Total execution time: 0.0529
DEBUG - 2022-07-06 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:22 --> Total execution time: 0.1183
DEBUG - 2022-07-06 05:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:23 --> Total execution time: 0.0498
DEBUG - 2022-07-06 05:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:24 --> Total execution time: 0.0479
DEBUG - 2022-07-06 05:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:34 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:34 --> Total execution time: 0.1020
DEBUG - 2022-07-06 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:34 --> Total execution time: 0.0629
DEBUG - 2022-07-06 05:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 16:12:36 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 16:12:36 --> Total execution time: 0.1996
DEBUG - 2022-07-06 05:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:38 --> Total execution time: 0.0698
DEBUG - 2022-07-06 05:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:41 --> Total execution time: 0.0543
DEBUG - 2022-07-06 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:45 --> Total execution time: 0.0531
DEBUG - 2022-07-06 05:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:47 --> Total execution time: 0.0516
DEBUG - 2022-07-06 05:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:50 --> Total execution time: 1.9490
DEBUG - 2022-07-06 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:52 --> Total execution time: 0.0519
DEBUG - 2022-07-06 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:12:56 --> Total execution time: 0.0799
DEBUG - 2022-07-06 05:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:42:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:42:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 05:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:17 --> Total execution time: 0.0564
DEBUG - 2022-07-06 05:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:24 --> Total execution time: 0.0514
DEBUG - 2022-07-06 05:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 16:13:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 16:13:27 --> Total execution time: 0.1745
DEBUG - 2022-07-06 05:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:45 --> Total execution time: 0.0518
DEBUG - 2022-07-06 05:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:13:58 --> Total execution time: 0.1481
DEBUG - 2022-07-06 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:14:22 --> Total execution time: 0.1117
DEBUG - 2022-07-06 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:14:35 --> Total execution time: 0.2086
DEBUG - 2022-07-06 05:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:16:16 --> Total execution time: 0.0993
DEBUG - 2022-07-06 05:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:17:40 --> Total execution time: 0.1184
DEBUG - 2022-07-06 05:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:17:43 --> Total execution time: 0.1010
DEBUG - 2022-07-06 05:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:18:05 --> Total execution time: 0.0616
DEBUG - 2022-07-06 05:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:18:14 --> Total execution time: 0.0332
DEBUG - 2022-07-06 05:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:18:24 --> Total execution time: 0.0778
DEBUG - 2022-07-06 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:18:37 --> Total execution time: 0.0528
DEBUG - 2022-07-06 05:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:48:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:18:44 --> Total execution time: 0.0505
DEBUG - 2022-07-06 05:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:02 --> Total execution time: 0.1265
DEBUG - 2022-07-06 05:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:13 --> Total execution time: 0.0578
DEBUG - 2022-07-06 05:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:16 --> Total execution time: 0.0633
DEBUG - 2022-07-06 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:18 --> Total execution time: 0.0475
DEBUG - 2022-07-06 05:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:31 --> Total execution time: 0.0591
DEBUG - 2022-07-06 05:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:40 --> Total execution time: 0.0512
DEBUG - 2022-07-06 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:46 --> Total execution time: 0.1467
DEBUG - 2022-07-06 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:47 --> Total execution time: 0.0545
DEBUG - 2022-07-06 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:51 --> Total execution time: 0.0509
DEBUG - 2022-07-06 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:20:53 --> Total execution time: 0.0884
DEBUG - 2022-07-06 05:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:21:03 --> Total execution time: 0.0515
DEBUG - 2022-07-06 05:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:21:08 --> Total execution time: 0.0632
DEBUG - 2022-07-06 05:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:21:17 --> Total execution time: 0.0734
DEBUG - 2022-07-06 05:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:21:20 --> Total execution time: 0.0505
DEBUG - 2022-07-06 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:51:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:21:29 --> Total execution time: 0.0485
DEBUG - 2022-07-06 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:21 --> Total execution time: 0.0547
DEBUG - 2022-07-06 16:22:21 --> Total execution time: 0.0464
DEBUG - 2022-07-06 05:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:22 --> Total execution time: 0.0444
DEBUG - 2022-07-06 05:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:28 --> Total execution time: 0.0322
DEBUG - 2022-07-06 05:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:32 --> Total execution time: 0.0694
DEBUG - 2022-07-06 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:36 --> Total execution time: 0.0713
DEBUG - 2022-07-06 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:38 --> Total execution time: 0.0519
DEBUG - 2022-07-06 05:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:39 --> Total execution time: 0.0517
DEBUG - 2022-07-06 05:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:44 --> Total execution time: 0.0714
DEBUG - 2022-07-06 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:46 --> Total execution time: 0.0724
DEBUG - 2022-07-06 05:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:50 --> Total execution time: 0.0721
DEBUG - 2022-07-06 05:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:52 --> Total execution time: 0.0841
DEBUG - 2022-07-06 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:22:59 --> Total execution time: 0.0767
DEBUG - 2022-07-06 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:23:00 --> Total execution time: 0.0563
DEBUG - 2022-07-06 05:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:55:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:25:57 --> Total execution time: 0.1154
DEBUG - 2022-07-06 05:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:26:02 --> Total execution time: 0.0483
DEBUG - 2022-07-06 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 05:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:26:24 --> Total execution time: 0.0630
DEBUG - 2022-07-06 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:26:30 --> Total execution time: 0.0594
DEBUG - 2022-07-06 05:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:26:33 --> Total execution time: 0.0702
DEBUG - 2022-07-06 05:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:26:43 --> Total execution time: 0.0799
DEBUG - 2022-07-06 05:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:08 --> Total execution time: 0.1771
DEBUG - 2022-07-06 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:16 --> Total execution time: 0.0778
DEBUG - 2022-07-06 05:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:24 --> Total execution time: 0.0605
DEBUG - 2022-07-06 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:28 --> Total execution time: 0.0948
DEBUG - 2022-07-06 05:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:32 --> Total execution time: 0.1366
DEBUG - 2022-07-06 05:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:48 --> Total execution time: 0.0570
DEBUG - 2022-07-06 05:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:27:54 --> Total execution time: 0.0600
DEBUG - 2022-07-06 05:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:05 --> Total execution time: 0.0799
DEBUG - 2022-07-06 05:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:09 --> Total execution time: 0.0544
DEBUG - 2022-07-06 05:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:19 --> Total execution time: 0.0627
DEBUG - 2022-07-06 05:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:24 --> Total execution time: 0.0919
DEBUG - 2022-07-06 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:28 --> Total execution time: 0.0762
DEBUG - 2022-07-06 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:32 --> Total execution time: 0.0684
DEBUG - 2022-07-06 05:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:37 --> Total execution time: 0.0727
DEBUG - 2022-07-06 05:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:28:45 --> Total execution time: 0.0730
DEBUG - 2022-07-06 05:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:59:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:59:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:29:01 --> Total execution time: 0.0616
DEBUG - 2022-07-06 05:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:59:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 05:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:29:17 --> Total execution time: 0.0654
DEBUG - 2022-07-06 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 05:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:29:25 --> Total execution time: 1.5917
DEBUG - 2022-07-06 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 05:59:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 05:59:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:30:02 --> Total execution time: 0.1402
DEBUG - 2022-07-06 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:00:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:30:22 --> Total execution time: 0.0568
DEBUG - 2022-07-06 06:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:30:29 --> Total execution time: 2.0331
DEBUG - 2022-07-06 06:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:03:02 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:33:03 --> Total execution time: 0.2313
DEBUG - 2022-07-06 06:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:03:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:33:37 --> Total execution time: 0.0607
DEBUG - 2022-07-06 06:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:04:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:34:40 --> Total execution time: 0.1566
DEBUG - 2022-07-06 06:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:04:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:34:43 --> Total execution time: 0.0580
DEBUG - 2022-07-06 06:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:04:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:34:48 --> Total execution time: 0.0724
DEBUG - 2022-07-06 06:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:04:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:34:49 --> Total execution time: 0.0708
DEBUG - 2022-07-06 06:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:23 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:23 --> Total execution time: 0.0360
DEBUG - 2022-07-06 06:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:26 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:26 --> Total execution time: 0.0422
DEBUG - 2022-07-06 06:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:34 --> Total execution time: 0.0531
DEBUG - 2022-07-06 06:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:37 --> Total execution time: 0.0504
DEBUG - 2022-07-06 06:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:39 --> Total execution time: 0.0742
DEBUG - 2022-07-06 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:05:43 --> Total execution time: 0.0546
DEBUG - 2022-07-06 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:44 --> Total execution time: 0.0694
DEBUG - 2022-07-06 06:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:05:45 --> Total execution time: 0.0709
DEBUG - 2022-07-06 06:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:05:45 --> Total execution time: 0.1231
DEBUG - 2022-07-06 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:47 --> Total execution time: 0.0527
DEBUG - 2022-07-06 06:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:35:53 --> Total execution time: 0.0556
DEBUG - 2022-07-06 06:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:07:01 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:37:06 --> Total execution time: 4.5588
DEBUG - 2022-07-06 06:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:07:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:07:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:39:52 --> Total execution time: 0.1683
DEBUG - 2022-07-06 06:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:11:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:41:18 --> Total execution time: 0.0495
DEBUG - 2022-07-06 06:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:12:47 --> Total execution time: 0.0359
DEBUG - 2022-07-06 06:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:12:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:42:58 --> Total execution time: 0.1334
DEBUG - 2022-07-06 06:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:12:59 --> Total execution time: 0.0580
DEBUG - 2022-07-06 06:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:12:59 --> Total execution time: 0.0539
DEBUG - 2022-07-06 06:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:18:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:18:25 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 06:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:49:20 --> Total execution time: 0.2180
DEBUG - 2022-07-06 06:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:21:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:21:01 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 06:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:21:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:51:19 --> Total execution time: 0.0689
DEBUG - 2022-07-06 06:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:21:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:51:24 --> Total execution time: 0.0527
DEBUG - 2022-07-06 06:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:22:16 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 06:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:22:27 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 06:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:22:45 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:23:06 --> Total execution time: 0.0549
DEBUG - 2022-07-06 06:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:23:07 --> Total execution time: 0.0677
DEBUG - 2022-07-06 06:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:23:07 --> Total execution time: 0.1161
DEBUG - 2022-07-06 06:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:23:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 06:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:23:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:53:54 --> Total execution time: 1.9672
DEBUG - 2022-07-06 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:23:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:55:23 --> Total execution time: 0.0882
DEBUG - 2022-07-06 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:25:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:55:48 --> Total execution time: 0.0356
DEBUG - 2022-07-06 06:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:55:54 --> Total execution time: 0.0754
DEBUG - 2022-07-06 06:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:02 --> Total execution time: 0.0536
DEBUG - 2022-07-06 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:26:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:10 --> Total execution time: 0.0880
DEBUG - 2022-07-06 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:26:10 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:14 --> Total execution time: 0.0801
DEBUG - 2022-07-06 06:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:26:15 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:30 --> Total execution time: 0.0640
DEBUG - 2022-07-06 06:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:26:30 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:48 --> Total execution time: 0.0582
DEBUG - 2022-07-06 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:57 --> Total execution time: 0.1506
DEBUG - 2022-07-06 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:27:42 --> Total execution time: 0.0640
DEBUG - 2022-07-06 06:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:57:51 --> Total execution time: 0.0575
DEBUG - 2022-07-06 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:57:54 --> Total execution time: 0.0544
DEBUG - 2022-07-06 06:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:27:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:27:55 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:00 --> Total execution time: 0.0581
DEBUG - 2022-07-06 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:03 --> Total execution time: 0.0921
DEBUG - 2022-07-06 06:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:28:04 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:12 --> Total execution time: 0.0830
DEBUG - 2022-07-06 06:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:28:12 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:18 --> Total execution time: 0.1238
DEBUG - 2022-07-06 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:26 --> Total execution time: 0.1232
DEBUG - 2022-07-06 06:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:28:27 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:47 --> Total execution time: 0.0900
DEBUG - 2022-07-06 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:58:52 --> Total execution time: 0.1032
DEBUG - 2022-07-06 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:28:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:58:52 --> Total execution time: 0.0906
DEBUG - 2022-07-06 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:59:02 --> Total execution time: 0.0657
DEBUG - 2022-07-06 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:59:02 --> Total execution time: 0.0602
DEBUG - 2022-07-06 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:59:26 --> Total execution time: 0.0579
DEBUG - 2022-07-06 06:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:59:44 --> Total execution time: 0.0573
DEBUG - 2022-07-06 06:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:29:44 --> 404 Page Not Found: Assets/user_thumbnail
DEBUG - 2022-07-06 06:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:59:47 --> Total execution time: 0.1210
DEBUG - 2022-07-06 06:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:00:14 --> Total execution time: 0.1526
DEBUG - 2022-07-06 06:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:30:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:00:29 --> Total execution time: 0.1672
DEBUG - 2022-07-06 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:27 --> Total execution time: 0.1138
DEBUG - 2022-07-06 06:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:32 --> Total execution time: 0.0415
DEBUG - 2022-07-06 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:47 --> Total execution time: 0.0528
DEBUG - 2022-07-06 06:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:54 --> Total execution time: 0.1468
DEBUG - 2022-07-06 06:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:55 --> Total execution time: 0.0513
DEBUG - 2022-07-06 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:03:01 --> Total execution time: 0.0666
DEBUG - 2022-07-06 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:03:03 --> Total execution time: 0.0543
DEBUG - 2022-07-06 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:33:04 --> Total execution time: 0.0378
DEBUG - 2022-07-06 06:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:33:05 --> Total execution time: 0.0496
DEBUG - 2022-07-06 06:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:33:05 --> Total execution time: 0.1362
DEBUG - 2022-07-06 06:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:03:23 --> Total execution time: 0.0561
DEBUG - 2022-07-06 06:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:03 --> Total execution time: 0.0400
DEBUG - 2022-07-06 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:07 --> Total execution time: 0.0379
DEBUG - 2022-07-06 06:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:28 --> Total execution time: 0.0714
DEBUG - 2022-07-06 06:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:36 --> Total execution time: 0.0692
DEBUG - 2022-07-06 06:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:43 --> Total execution time: 0.0808
DEBUG - 2022-07-06 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:45 --> Total execution time: 0.0407
DEBUG - 2022-07-06 06:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:45 --> Total execution time: 0.0554
DEBUG - 2022-07-06 06:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:47 --> Total execution time: 0.0671
DEBUG - 2022-07-06 06:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:34:49 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:49 --> Total execution time: 0.0566
DEBUG - 2022-07-06 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:35:15 --> Total execution time: 0.0505
DEBUG - 2022-07-06 06:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:35:16 --> Total execution time: 0.0725
DEBUG - 2022-07-06 06:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:35:16 --> Total execution time: 0.1127
DEBUG - 2022-07-06 06:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:06:07 --> Total execution time: 0.0692
DEBUG - 2022-07-06 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:37:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:07:23 --> Total execution time: 1.6178
DEBUG - 2022-07-06 06:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:37:26 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:07:28 --> Total execution time: 0.0783
DEBUG - 2022-07-06 06:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:08:12 --> Total execution time: 0.0624
DEBUG - 2022-07-06 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:38:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:38:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:08:12 --> Total execution time: 0.0514
DEBUG - 2022-07-06 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:08:46 --> Total execution time: 0.0713
DEBUG - 2022-07-06 06:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:39:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:09:19 --> Total execution time: 0.0611
DEBUG - 2022-07-06 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:39:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:09:24 --> Total execution time: 0.0479
DEBUG - 2022-07-06 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:39:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:09:45 --> Total execution time: 0.0406
DEBUG - 2022-07-06 06:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:40:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:10:13 --> Total execution time: 0.0597
DEBUG - 2022-07-06 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:40:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:10:40 --> Total execution time: 0.0365
DEBUG - 2022-07-06 06:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:40:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:10:42 --> Total execution time: 0.0352
DEBUG - 2022-07-06 06:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:01 --> Total execution time: 0.0503
DEBUG - 2022-07-06 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:02 --> Total execution time: 0.1166
DEBUG - 2022-07-06 06:41:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:02 --> Total execution time: 0.1414
DEBUG - 2022-07-06 06:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:51 --> Total execution time: 0.0449
DEBUG - 2022-07-06 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:41:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:41:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:41:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:12:01 --> Total execution time: 1.8217
DEBUG - 2022-07-06 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:42:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:42:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:42:09 --> Total execution time: 0.0561
DEBUG - 2022-07-06 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:42:09 --> Total execution time: 0.0577
DEBUG - 2022-07-06 06:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:14:20 --> Total execution time: 0.1116
DEBUG - 2022-07-06 06:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:47:23 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 06:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:47:30 --> Total execution time: 0.0756
DEBUG - 2022-07-06 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:47:31 --> Total execution time: 0.0676
DEBUG - 2022-07-06 06:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:47:31 --> Total execution time: 0.0878
DEBUG - 2022-07-06 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:48:03 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 06:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:18:05 --> Total execution time: 1.6016
DEBUG - 2022-07-06 06:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 06:48:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 06:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:18:46 --> Total execution time: 0.0564
DEBUG - 2022-07-06 06:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:18:52 --> Total execution time: 0.0677
DEBUG - 2022-07-06 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:18:57 --> Total execution time: 0.0401
DEBUG - 2022-07-06 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:48:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:18:57 --> Total execution time: 0.0426
DEBUG - 2022-07-06 17:18:57 --> Total execution time: 0.0643
DEBUG - 2022-07-06 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:00 --> Total execution time: 0.0440
DEBUG - 2022-07-06 06:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:08 --> Total execution time: 0.0688
DEBUG - 2022-07-06 06:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:08 --> Total execution time: 0.0821
DEBUG - 2022-07-06 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:12 --> Total execution time: 0.0632
DEBUG - 2022-07-06 06:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:15 --> Total execution time: 0.0577
DEBUG - 2022-07-06 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:17 --> Total execution time: 0.0509
DEBUG - 2022-07-06 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:26 --> Total execution time: 0.0571
DEBUG - 2022-07-06 06:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:30 --> Total execution time: 0.0546
DEBUG - 2022-07-06 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:38 --> Total execution time: 0.0751
DEBUG - 2022-07-06 06:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:19:53 --> Total execution time: 1.4845
DEBUG - 2022-07-06 06:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:21:00 --> Total execution time: 0.0539
DEBUG - 2022-07-06 06:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:21:02 --> Total execution time: 0.0912
DEBUG - 2022-07-06 06:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:51:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:21:05 --> Total execution time: 0.0832
DEBUG - 2022-07-06 06:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:21:16 --> Total execution time: 0.0607
DEBUG - 2022-07-06 06:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:52:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:22:35 --> Total execution time: 0.0569
DEBUG - 2022-07-06 06:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:22:39 --> Total execution time: 0.0670
DEBUG - 2022-07-06 06:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:23:23 --> Total execution time: 0.0601
DEBUG - 2022-07-06 06:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:23:27 --> Total execution time: 0.0721
DEBUG - 2022-07-06 06:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:53:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:23:54 --> Total execution time: 0.0893
DEBUG - 2022-07-06 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:24:28 --> Total execution time: 0.1333
DEBUG - 2022-07-06 06:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:24:28 --> Total execution time: 0.0813
DEBUG - 2022-07-06 06:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:24:30 --> Total execution time: 0.0622
DEBUG - 2022-07-06 06:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:54:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:24:30 --> Total execution time: 0.1272
DEBUG - 2022-07-06 06:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:26:00 --> Total execution time: 0.0374
DEBUG - 2022-07-06 06:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:58:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:28:54 --> Total execution time: 0.1270
DEBUG - 2022-07-06 06:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:28:57 --> Total execution time: 0.0585
DEBUG - 2022-07-06 06:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:07 --> Total execution time: 0.0371
DEBUG - 2022-07-06 06:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:14 --> Total execution time: 0.0747
DEBUG - 2022-07-06 06:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:25 --> Total execution time: 0.2854
DEBUG - 2022-07-06 06:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:48 --> Total execution time: 0.0889
DEBUG - 2022-07-06 06:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 06:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:52 --> Total execution time: 0.0558
DEBUG - 2022-07-06 06:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 06:59:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 06:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 06:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:29:59 --> Total execution time: 0.0660
DEBUG - 2022-07-06 07:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:30:01 --> Total execution time: 0.1155
DEBUG - 2022-07-06 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:30:03 --> Total execution time: 0.0508
DEBUG - 2022-07-06 07:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:00:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:30:53 --> Total execution time: 0.1286
DEBUG - 2022-07-06 07:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:31:23 --> Total execution time: 0.0640
DEBUG - 2022-07-06 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:31:29 --> Total execution time: 0.0875
DEBUG - 2022-07-06 07:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:31:32 --> Total execution time: 0.0628
DEBUG - 2022-07-06 07:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:31:44 --> Total execution time: 0.0545
DEBUG - 2022-07-06 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:33:05 --> Total execution time: 0.3012
DEBUG - 2022-07-06 07:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:33:49 --> Total execution time: 0.1737
DEBUG - 2022-07-06 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:03:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:33:58 --> Total execution time: 0.0857
DEBUG - 2022-07-06 07:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:10 --> Total execution time: 0.0551
DEBUG - 2022-07-06 07:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:15 --> Total execution time: 0.1340
DEBUG - 2022-07-06 07:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:17 --> Total execution time: 0.0699
DEBUG - 2022-07-06 07:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:44 --> Total execution time: 0.0710
DEBUG - 2022-07-06 07:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:45 --> Total execution time: 0.0956
DEBUG - 2022-07-06 07:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:34:54 --> Total execution time: 0.0947
DEBUG - 2022-07-06 07:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:08:02 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:38:02 --> Total execution time: 0.2134
DEBUG - 2022-07-06 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:09:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:39:08 --> Total execution time: 0.0729
DEBUG - 2022-07-06 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:43:06 --> Total execution time: 0.0611
DEBUG - 2022-07-06 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:43:08 --> Total execution time: 0.0630
DEBUG - 2022-07-06 07:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:43:08 --> Total execution time: 0.0612
DEBUG - 2022-07-06 07:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:14:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:44:57 --> Total execution time: 0.0835
DEBUG - 2022-07-06 07:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:50:13 --> Total execution time: 0.1526
DEBUG - 2022-07-06 07:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:50:13 --> Total execution time: 0.0388
DEBUG - 2022-07-06 07:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:50:33 --> Total execution time: 0.0663
DEBUG - 2022-07-06 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:50:45 --> Total execution time: 0.0589
DEBUG - 2022-07-06 07:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:20:50 --> Total execution time: 0.0398
DEBUG - 2022-07-06 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:20:52 --> Total execution time: 0.0849
DEBUG - 2022-07-06 07:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:20:52 --> Total execution time: 0.1597
DEBUG - 2022-07-06 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:20:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:50:59 --> Total execution time: 0.0514
DEBUG - 2022-07-06 07:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:07 --> Total execution time: 0.0506
DEBUG - 2022-07-06 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:14 --> Total execution time: 0.0684
DEBUG - 2022-07-06 07:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:21:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:18 --> Total execution time: 0.0584
DEBUG - 2022-07-06 07:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:19 --> Total execution time: 0.0817
DEBUG - 2022-07-06 07:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:20 --> Total execution time: 0.0728
DEBUG - 2022-07-06 07:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:22 --> Total execution time: 0.0522
DEBUG - 2022-07-06 07:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:23 --> Total execution time: 0.0940
DEBUG - 2022-07-06 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:34 --> Total execution time: 0.0670
DEBUG - 2022-07-06 07:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:36 --> Total execution time: 0.0745
DEBUG - 2022-07-06 07:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:48 --> Total execution time: 0.0578
DEBUG - 2022-07-06 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:51:55 --> Total execution time: 0.0793
DEBUG - 2022-07-06 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:22:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:52:06 --> Total execution time: 0.0382
DEBUG - 2022-07-06 07:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:22:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:22:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:52:27 --> Total execution time: 0.1762
DEBUG - 2022-07-06 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:23:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:53:03 --> Total execution time: 0.0362
DEBUG - 2022-07-06 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:23:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:53:03 --> Total execution time: 0.0345
DEBUG - 2022-07-06 07:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 07:23:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 07:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:54:32 --> Total execution time: 0.0919
DEBUG - 2022-07-06 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:54:41 --> Total execution time: 0.0590
DEBUG - 2022-07-06 07:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:31:23 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:31:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:01:23 --> Total execution time: 0.1272
DEBUG - 2022-07-06 07:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:01:30 --> Total execution time: 0.0572
DEBUG - 2022-07-06 07:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:32:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:02:44 --> Total execution time: 0.0413
DEBUG - 2022-07-06 07:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:17 --> Total execution time: 0.0532
DEBUG - 2022-07-06 07:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:17 --> Total execution time: 0.0349
DEBUG - 2022-07-06 07:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:21 --> Total execution time: 0.0547
DEBUG - 2022-07-06 07:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:33 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:33 --> Total execution time: 0.0356
DEBUG - 2022-07-06 07:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:41 --> Total execution time: 0.0400
DEBUG - 2022-07-06 07:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:41 --> Total execution time: 0.0514
DEBUG - 2022-07-06 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:50 --> Total execution time: 0.0575
DEBUG - 2022-07-06 07:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:33:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:03:52 --> Total execution time: 0.0488
DEBUG - 2022-07-06 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:00 --> Total execution time: 0.0507
DEBUG - 2022-07-06 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:18 --> Total execution time: 0.0600
DEBUG - 2022-07-06 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:43 --> Total execution time: 0.0572
DEBUG - 2022-07-06 07:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:48 --> Total execution time: 0.0498
DEBUG - 2022-07-06 07:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:48 --> Total execution time: 0.0575
DEBUG - 2022-07-06 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:34:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:04:53 --> Total execution time: 0.0838
DEBUG - 2022-07-06 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:05:02 --> Total execution time: 0.0645
DEBUG - 2022-07-06 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:35:33 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:05:33 --> Total execution time: 0.0565
DEBUG - 2022-07-06 07:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:35:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:05:47 --> Total execution time: 0.0543
DEBUG - 2022-07-06 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:05:58 --> Total execution time: 0.0499
DEBUG - 2022-07-06 07:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:06:02 --> Total execution time: 0.0539
DEBUG - 2022-07-06 07:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:06:11 --> Total execution time: 0.0583
DEBUG - 2022-07-06 07:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:06:11 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 07:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:06:12 --> Total execution time: 0.0528
DEBUG - 2022-07-06 07:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:06:22 --> Total execution time: 0.0548
DEBUG - 2022-07-06 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:07:07 --> Total execution time: 0.0485
DEBUG - 2022-07-06 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:37:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:07:59 --> Total execution time: 0.1183
DEBUG - 2022-07-06 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:07 --> Total execution time: 0.0620
DEBUG - 2022-07-06 07:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:15 --> Total execution time: 0.0482
DEBUG - 2022-07-06 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:22 --> Total execution time: 0.0554
DEBUG - 2022-07-06 07:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:34 --> Total execution time: 0.0531
DEBUG - 2022-07-06 07:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:49 --> Total execution time: 0.0492
DEBUG - 2022-07-06 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:38:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:08:56 --> Total execution time: 0.0511
DEBUG - 2022-07-06 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:40:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:10:42 --> Total execution time: 0.0359
DEBUG - 2022-07-06 07:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:11:08 --> Total execution time: 0.0498
DEBUG - 2022-07-06 07:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:11:31 --> Total execution time: 0.0574
DEBUG - 2022-07-06 07:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:11:32 --> Total execution time: 0.0362
DEBUG - 2022-07-06 07:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:11:40 --> Total execution time: 0.0532
DEBUG - 2022-07-06 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:11:57 --> Total execution time: 0.0566
DEBUG - 2022-07-06 07:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:22 --> Total execution time: 0.0635
DEBUG - 2022-07-06 07:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:31 --> Total execution time: 0.1221
DEBUG - 2022-07-06 07:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:34 --> Total execution time: 0.0289
DEBUG - 2022-07-06 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:36 --> Total execution time: 0.0623
DEBUG - 2022-07-06 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:37 --> Total execution time: 0.0473
DEBUG - 2022-07-06 07:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:42 --> Total execution time: 0.0586
DEBUG - 2022-07-06 07:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:46 --> Total execution time: 0.0562
DEBUG - 2022-07-06 07:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:12:54 --> Total execution time: 0.0489
DEBUG - 2022-07-06 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:13:43 --> Total execution time: 0.0489
DEBUG - 2022-07-06 07:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:43:54 --> Total execution time: 0.0777
DEBUG - 2022-07-06 07:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:01 --> Total execution time: 0.1632
DEBUG - 2022-07-06 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:18 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:18 --> Total execution time: 0.0419
DEBUG - 2022-07-06 07:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:26 --> Total execution time: 0.1097
DEBUG - 2022-07-06 07:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:30 --> Total execution time: 0.0541
DEBUG - 2022-07-06 07:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:35 --> Total execution time: 0.1229
DEBUG - 2022-07-06 07:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:36 --> Total execution time: 0.0328
DEBUG - 2022-07-06 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:14:42 --> Total execution time: 0.0516
DEBUG - 2022-07-06 07:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:48 --> Total execution time: 0.0697
DEBUG - 2022-07-06 07:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:49 --> Total execution time: 0.0574
DEBUG - 2022-07-06 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:54 --> Total execution time: 0.0467
DEBUG - 2022-07-06 07:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:44:59 --> Total execution time: 0.0618
DEBUG - 2022-07-06 07:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:04 --> Total execution time: 0.0472
DEBUG - 2022-07-06 07:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:05 --> Total execution time: 0.0588
DEBUG - 2022-07-06 07:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:07 --> Total execution time: 0.0790
DEBUG - 2022-07-06 07:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:08 --> Total execution time: 0.0937
DEBUG - 2022-07-06 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:13 --> Total execution time: 0.0648
DEBUG - 2022-07-06 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:17 --> Total execution time: 0.0786
DEBUG - 2022-07-06 18:15:17 --> Total execution time: 0.0844
DEBUG - 2022-07-06 07:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:21 --> Total execution time: 0.0839
DEBUG - 2022-07-06 07:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:29 --> Total execution time: 0.1039
DEBUG - 2022-07-06 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:36 --> Total execution time: 0.0760
DEBUG - 2022-07-06 07:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:37 --> Total execution time: 0.0543
DEBUG - 2022-07-06 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:38 --> Total execution time: 0.0542
DEBUG - 2022-07-06 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:45:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:15:55 --> Total execution time: 0.0736
DEBUG - 2022-07-06 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:47:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:17:25 --> Total execution time: 0.0611
DEBUG - 2022-07-06 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:17:51 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 07:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:17:52 --> Total execution time: 0.0766
DEBUG - 2022-07-06 07:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:18:13 --> Total execution time: 0.0630
DEBUG - 2022-07-06 07:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:19:26 --> Total execution time: 0.0560
DEBUG - 2022-07-06 07:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:19:33 --> Total execution time: 0.0618
DEBUG - 2022-07-06 07:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:19:45 --> Total execution time: 0.0576
DEBUG - 2022-07-06 07:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:11 --> Total execution time: 0.1289
DEBUG - 2022-07-06 07:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:13 --> Total execution time: 0.0544
DEBUG - 2022-07-06 07:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:22 --> Total execution time: 0.1471
DEBUG - 2022-07-06 07:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:29 --> Total execution time: 0.0590
DEBUG - 2022-07-06 07:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:32 --> Total execution time: 0.0560
DEBUG - 2022-07-06 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:39 --> Total execution time: 0.0356
DEBUG - 2022-07-06 07:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:41 --> Total execution time: 0.0737
DEBUG - 2022-07-06 07:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:44 --> Total execution time: 0.0477
DEBUG - 2022-07-06 07:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:20:48 --> Total execution time: 0.0506
DEBUG - 2022-07-06 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:00 --> Total execution time: 0.0478
DEBUG - 2022-07-06 07:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:27 --> Total execution time: 0.1389
DEBUG - 2022-07-06 07:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:30 --> Total execution time: 0.0498
DEBUG - 2022-07-06 07:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:37 --> Total execution time: 0.0592
DEBUG - 2022-07-06 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:38 --> Total execution time: 0.0585
DEBUG - 2022-07-06 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:40 --> Total execution time: 0.0503
DEBUG - 2022-07-06 07:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:50 --> Total execution time: 0.0537
DEBUG - 2022-07-06 07:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:51:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:21:58 --> Total execution time: 0.0888
DEBUG - 2022-07-06 07:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:22:28 --> Total execution time: 0.0486
DEBUG - 2022-07-06 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:22:34 --> Total execution time: 0.0882
DEBUG - 2022-07-06 07:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:22:44 --> Total execution time: 0.0509
DEBUG - 2022-07-06 07:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:22:55 --> Total execution time: 0.0753
DEBUG - 2022-07-06 07:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:23:51 --> Total execution time: 0.0639
DEBUG - 2022-07-06 07:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:12 --> Total execution time: 0.0482
DEBUG - 2022-07-06 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:22 --> Total execution time: 0.0857
DEBUG - 2022-07-06 07:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:23 --> Total execution time: 0.0533
DEBUG - 2022-07-06 07:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:25 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:25 --> Total execution time: 0.1213
DEBUG - 2022-07-06 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:29 --> Total execution time: 0.0531
DEBUG - 2022-07-06 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:30 --> Total execution time: 0.1666
DEBUG - 2022-07-06 07:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:31 --> Total execution time: 0.0759
DEBUG - 2022-07-06 07:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:45 --> Total execution time: 0.0717
DEBUG - 2022-07-06 07:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:49 --> Total execution time: 0.0567
DEBUG - 2022-07-06 07:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:53 --> Total execution time: 0.0683
DEBUG - 2022-07-06 07:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:24:57 --> Total execution time: 0.0676
DEBUG - 2022-07-06 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:25:33 --> Total execution time: 0.0536
DEBUG - 2022-07-06 07:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:25:46 --> Total execution time: 0.0372
DEBUG - 2022-07-06 07:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:25:49 --> Total execution time: 0.0692
DEBUG - 2022-07-06 07:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:25:53 --> Total execution time: 0.0483
DEBUG - 2022-07-06 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:25:58 --> Total execution time: 0.0656
DEBUG - 2022-07-06 07:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:04 --> Total execution time: 0.0598
DEBUG - 2022-07-06 07:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:27 --> Total execution time: 0.0553
DEBUG - 2022-07-06 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:35 --> No URI present. Default controller set.
DEBUG - 2022-07-06 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:36 --> Total execution time: 0.1266
DEBUG - 2022-07-06 07:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:40 --> Total execution time: 0.0487
DEBUG - 2022-07-06 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:46 --> Total execution time: 0.0483
DEBUG - 2022-07-06 07:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:52 --> Total execution time: 0.0518
DEBUG - 2022-07-06 07:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:56 --> Total execution time: 0.0683
DEBUG - 2022-07-06 07:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:56:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:26:58 --> Total execution time: 0.0507
DEBUG - 2022-07-06 07:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:27:00 --> Total execution time: 0.0747
DEBUG - 2022-07-06 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 07:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:27:06 --> Total execution time: 0.0547
DEBUG - 2022-07-06 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:57:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:27:53 --> Total execution time: 0.0544
DEBUG - 2022-07-06 07:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:27:56 --> Total execution time: 0.0516
DEBUG - 2022-07-06 07:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:28:42 --> Total execution time: 0.0609
DEBUG - 2022-07-06 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:38 --> Total execution time: 0.0704
DEBUG - 2022-07-06 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 07:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:39 --> Total execution time: 0.1211
DEBUG - 2022-07-06 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:02 --> Total execution time: 0.0597
DEBUG - 2022-07-06 08:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:05 --> Total execution time: 0.2855
DEBUG - 2022-07-06 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:09 --> Total execution time: 0.0692
DEBUG - 2022-07-06 08:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:13 --> Total execution time: 0.1028
DEBUG - 2022-07-06 08:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:16 --> Total execution time: 0.0660
DEBUG - 2022-07-06 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:27 --> Total execution time: 0.0835
DEBUG - 2022-07-06 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:36 --> Total execution time: 0.0533
DEBUG - 2022-07-06 08:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:00:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:00:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:46 --> Total execution time: 0.0388
DEBUG - 2022-07-06 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:01:46 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 08:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:04:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:04:28 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 08:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:34:46 --> Total execution time: 0.0587
DEBUG - 2022-07-06 08:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:34:56 --> Total execution time: 0.0678
DEBUG - 2022-07-06 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:02 --> Total execution time: 0.0841
DEBUG - 2022-07-06 08:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:04 --> Total execution time: 0.0715
DEBUG - 2022-07-06 08:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:12 --> Total execution time: 0.0759
DEBUG - 2022-07-06 08:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:22 --> Total execution time: 0.0713
DEBUG - 2022-07-06 08:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:24 --> Total execution time: 0.0561
DEBUG - 2022-07-06 08:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:31 --> Total execution time: 0.1305
DEBUG - 2022-07-06 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:41 --> Total execution time: 0.0574
DEBUG - 2022-07-06 08:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:05:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:46 --> Total execution time: 0.1220
DEBUG - 2022-07-06 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:21 --> Total execution time: 0.0487
DEBUG - 2022-07-06 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:34 --> Total execution time: 0.1359
DEBUG - 2022-07-06 08:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:37 --> Total execution time: 0.0499
DEBUG - 2022-07-06 08:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:06:41 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 08:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:43 --> Total execution time: 0.0535
DEBUG - 2022-07-06 08:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:50 --> Total execution time: 0.0955
DEBUG - 2022-07-06 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:06:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:36:52 --> Total execution time: 0.1321
DEBUG - 2022-07-06 08:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:01 --> Total execution time: 0.0364
DEBUG - 2022-07-06 08:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:14 --> Total execution time: 0.0325
DEBUG - 2022-07-06 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:18 --> Total execution time: 0.0478
DEBUG - 2022-07-06 08:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:27 --> Total execution time: 0.0647
DEBUG - 2022-07-06 08:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:38 --> Total execution time: 0.0799
DEBUG - 2022-07-06 08:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:38 --> Total execution time: 0.0580
DEBUG - 2022-07-06 08:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:42 --> Total execution time: 0.0830
DEBUG - 2022-07-06 08:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:48 --> Total execution time: 0.0528
DEBUG - 2022-07-06 08:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:51 --> Total execution time: 0.0596
DEBUG - 2022-07-06 08:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:37:53 --> Total execution time: 0.0684
DEBUG - 2022-07-06 08:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:01 --> Total execution time: 0.0517
DEBUG - 2022-07-06 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:05 --> Total execution time: 0.0530
DEBUG - 2022-07-06 08:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:10 --> Total execution time: 0.1360
DEBUG - 2022-07-06 08:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:28 --> Total execution time: 0.0667
DEBUG - 2022-07-06 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:37 --> Total execution time: 0.0599
DEBUG - 2022-07-06 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:40 --> Total execution time: 0.0548
DEBUG - 2022-07-06 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:45 --> Total execution time: 0.0715
DEBUG - 2022-07-06 08:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:48 --> Total execution time: 0.0589
DEBUG - 2022-07-06 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:52 --> Total execution time: 0.0489
DEBUG - 2022-07-06 08:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:38:57 --> Total execution time: 0.0497
DEBUG - 2022-07-06 08:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:39:45 --> Total execution time: 0.0523
DEBUG - 2022-07-06 08:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:40:08 --> Total execution time: 0.0485
DEBUG - 2022-07-06 08:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:40:20 --> Total execution time: 0.0555
DEBUG - 2022-07-06 08:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:40:38 --> Total execution time: 0.0569
DEBUG - 2022-07-06 08:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:40:41 --> Total execution time: 0.0706
DEBUG - 2022-07-06 08:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:40:42 --> Total execution time: 0.0584
DEBUG - 2022-07-06 08:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:42:14 --> Total execution time: 0.0497
DEBUG - 2022-07-06 08:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:42:22 --> Total execution time: 0.1410
DEBUG - 2022-07-06 08:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:42:31 --> Total execution time: 0.1395
DEBUG - 2022-07-06 08:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:42:36 --> Total execution time: 0.0555
DEBUG - 2022-07-06 08:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:12:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:42:49 --> Total execution time: 0.0541
DEBUG - 2022-07-06 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:13:17 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-06 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:43:38 --> Total execution time: 0.0525
DEBUG - 2022-07-06 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:43:43 --> Total execution time: 0.0529
DEBUG - 2022-07-06 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:43:51 --> Total execution time: 0.1212
DEBUG - 2022-07-06 18:43:51 --> Total execution time: 0.1319
DEBUG - 2022-07-06 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:43:56 --> Total execution time: 0.0601
DEBUG - 2022-07-06 08:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:43:58 --> Total execution time: 0.0666
DEBUG - 2022-07-06 08:14:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:00 --> Total execution time: 0.0342
DEBUG - 2022-07-06 08:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:02 --> Total execution time: 0.0581
DEBUG - 2022-07-06 08:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:07 --> Total execution time: 0.0546
DEBUG - 2022-07-06 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:11 --> Total execution time: 0.0568
DEBUG - 2022-07-06 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:13 --> Total execution time: 0.0698
DEBUG - 2022-07-06 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:14 --> Total execution time: 0.0610
DEBUG - 2022-07-06 08:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:30 --> Total execution time: 0.0632
DEBUG - 2022-07-06 08:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:35 --> Total execution time: 0.0590
DEBUG - 2022-07-06 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:44:37 --> Total execution time: 0.0645
DEBUG - 2022-07-06 08:14:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:37 --> Total execution time: 0.0862
DEBUG - 2022-07-06 08:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:42 --> Total execution time: 0.0633
DEBUG - 2022-07-06 08:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:42 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:42 --> Total execution time: 0.0530
DEBUG - 2022-07-06 08:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:14:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:44:47 --> Total execution time: 0.1225
DEBUG - 2022-07-06 08:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:06 --> Total execution time: 0.0563
DEBUG - 2022-07-06 08:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:08 --> Total execution time: 0.0557
DEBUG - 2022-07-06 08:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:10 --> Total execution time: 0.0646
DEBUG - 2022-07-06 08:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:11 --> Total execution time: 0.0583
DEBUG - 2022-07-06 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:13 --> Total execution time: 0.0598
DEBUG - 2022-07-06 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:14 --> Total execution time: 0.0814
DEBUG - 2022-07-06 08:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:29 --> Total execution time: 0.0638
DEBUG - 2022-07-06 08:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:32 --> Total execution time: 0.0478
DEBUG - 2022-07-06 08:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:37 --> Total execution time: 0.0605
DEBUG - 2022-07-06 08:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:44 --> Total execution time: 0.0508
DEBUG - 2022-07-06 08:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:53 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:58 --> Total execution time: 0.0522
DEBUG - 2022-07-06 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:45:59 --> Total execution time: 0.0459
DEBUG - 2022-07-06 08:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:14 --> Total execution time: 0.0513
DEBUG - 2022-07-06 08:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:17 --> Total execution time: 0.0482
DEBUG - 2022-07-06 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:31 --> Total execution time: 0.0718
DEBUG - 2022-07-06 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:50 --> Total execution time: 0.0696
DEBUG - 2022-07-06 08:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:50 --> Total execution time: 0.1177
DEBUG - 2022-07-06 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:16:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:46:54 --> Total execution time: 0.0511
DEBUG - 2022-07-06 08:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:21 --> Total execution time: 0.0500
DEBUG - 2022-07-06 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:25 --> Total execution time: 0.0527
DEBUG - 2022-07-06 08:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:25 --> Total execution time: 0.0317
DEBUG - 2022-07-06 08:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:28 --> Total execution time: 0.0537
DEBUG - 2022-07-06 08:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:29 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:29 --> Total execution time: 0.0484
DEBUG - 2022-07-06 08:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:41 --> Total execution time: 0.0568
DEBUG - 2022-07-06 08:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:47 --> Total execution time: 0.0599
DEBUG - 2022-07-06 08:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:55 --> Total execution time: 0.0517
DEBUG - 2022-07-06 08:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:47:59 --> Total execution time: 0.0584
DEBUG - 2022-07-06 08:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:07 --> Total execution time: 0.0560
DEBUG - 2022-07-06 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:22 --> Total execution time: 0.0699
DEBUG - 2022-07-06 08:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:35 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:35 --> Total execution time: 0.1305
DEBUG - 2022-07-06 08:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:39 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:41 --> Total execution time: 0.0486
DEBUG - 2022-07-06 08:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:44 --> Total execution time: 0.0532
DEBUG - 2022-07-06 08:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:47 --> Total execution time: 0.1386
DEBUG - 2022-07-06 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:48:52 --> Total execution time: 0.0509
DEBUG - 2022-07-06 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:49:40 --> Total execution time: 0.0548
DEBUG - 2022-07-06 08:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:01 --> Total execution time: 0.1522
DEBUG - 2022-07-06 08:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:20:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:14 --> Total execution time: 0.1299
DEBUG - 2022-07-06 08:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:44 --> Total execution time: 0.0559
DEBUG - 2022-07-06 08:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:52 --> Total execution time: 0.1470
DEBUG - 2022-07-06 08:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:58 --> Total execution time: 0.0516
DEBUG - 2022-07-06 08:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:51:23 --> Total execution time: 0.0516
DEBUG - 2022-07-06 08:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:51:24 --> Total execution time: 0.0487
DEBUG - 2022-07-06 08:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:52:06 --> Total execution time: 0.0576
DEBUG - 2022-07-06 08:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:22:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:52:10 --> Total execution time: 0.0614
DEBUG - 2022-07-06 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:52:36 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:52:48 --> Total execution time: 0.0483
DEBUG - 2022-07-06 08:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:53:21 --> Total execution time: 0.0514
DEBUG - 2022-07-06 08:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:53:48 --> Total execution time: 0.1363
DEBUG - 2022-07-06 08:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:53:55 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:54:07 --> Total execution time: 0.0904
DEBUG - 2022-07-06 08:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:54:08 --> Total execution time: 0.0620
DEBUG - 2022-07-06 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:55:41 --> Total execution time: 0.0390
DEBUG - 2022-07-06 08:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:55:54 --> Total execution time: 0.0558
DEBUG - 2022-07-06 08:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:56:19 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:26:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:56:23 --> Total execution time: 0.1244
DEBUG - 2022-07-06 08:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:56:47 --> Total execution time: 0.2172
DEBUG - 2022-07-06 08:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:56:52 --> Total execution time: 0.0519
DEBUG - 2022-07-06 08:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:26:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:56:59 --> Total execution time: 0.0478
DEBUG - 2022-07-06 08:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:02 --> Total execution time: 0.0943
DEBUG - 2022-07-06 08:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:06 --> Total execution time: 0.0878
DEBUG - 2022-07-06 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:08 --> Total execution time: 0.0632
DEBUG - 2022-07-06 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:16 --> Total execution time: 0.0326
DEBUG - 2022-07-06 08:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:18 --> Total execution time: 0.0539
DEBUG - 2022-07-06 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:30 --> Total execution time: 0.0582
DEBUG - 2022-07-06 08:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:32 --> Total execution time: 0.0549
DEBUG - 2022-07-06 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:37 --> Total execution time: 0.0586
DEBUG - 2022-07-06 08:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:39 --> Total execution time: 0.0626
DEBUG - 2022-07-06 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:44 --> Total execution time: 0.0609
DEBUG - 2022-07-06 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:51 --> Total execution time: 0.0485
DEBUG - 2022-07-06 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:54 --> Total execution time: 0.1071
DEBUG - 2022-07-06 08:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:57:54 --> Total execution time: 0.0537
DEBUG - 2022-07-06 08:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:28:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:58:00 --> Total execution time: 0.0518
DEBUG - 2022-07-06 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:58:32 --> Total execution time: 0.0650
DEBUG - 2022-07-06 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:58:43 --> Total execution time: 0.0488
DEBUG - 2022-07-06 08:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:58:48 --> Total execution time: 0.0484
DEBUG - 2022-07-06 08:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:08 --> Total execution time: 0.0552
DEBUG - 2022-07-06 08:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:09 --> Total execution time: 0.0627
DEBUG - 2022-07-06 08:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:18 --> Total execution time: 0.0544
DEBUG - 2022-07-06 08:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:27 --> Total execution time: 0.1241
DEBUG - 2022-07-06 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:41 --> Total execution time: 0.0515
DEBUG - 2022-07-06 08:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:41 --> Total execution time: 0.1519
DEBUG - 2022-07-06 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:48 --> Total execution time: 0.0573
DEBUG - 2022-07-06 08:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:48 --> Total execution time: 0.0980
DEBUG - 2022-07-06 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:49 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:49 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:54 --> Total execution time: 0.0698
DEBUG - 2022-07-06 08:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:55 --> Total execution time: 0.0709
DEBUG - 2022-07-06 08:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:57 --> Total execution time: 0.0506
DEBUG - 2022-07-06 08:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:00 --> Total execution time: 0.1003
DEBUG - 2022-07-06 08:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:00 --> Total execution time: 0.0539
DEBUG - 2022-07-06 08:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:02 --> Total execution time: 0.0925
DEBUG - 2022-07-06 08:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:54 --> Total execution time: 0.0822
DEBUG - 2022-07-06 08:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:59 --> Total execution time: 0.0775
DEBUG - 2022-07-06 08:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:31:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:31:04 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 08:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:01:05 --> Total execution time: 0.0715
DEBUG - 2022-07-06 08:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:07 --> Total execution time: 0.0399
DEBUG - 2022-07-06 08:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:10 --> Total execution time: 0.1076
DEBUG - 2022-07-06 08:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:14 --> Total execution time: 0.0784
DEBUG - 2022-07-06 08:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:25 --> Total execution time: 0.0583
DEBUG - 2022-07-06 08:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:28 --> Total execution time: 0.0446
DEBUG - 2022-07-06 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:32 --> Total execution time: 0.0736
DEBUG - 2022-07-06 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:35 --> Total execution time: 0.0603
DEBUG - 2022-07-06 08:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:02:55 --> Total execution time: 0.1402
DEBUG - 2022-07-06 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:04 --> Total execution time: 0.0947
DEBUG - 2022-07-06 08:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:13 --> Total execution time: 0.0511
DEBUG - 2022-07-06 08:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:17 --> Total execution time: 0.0540
DEBUG - 2022-07-06 08:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:25 --> Total execution time: 0.0540
DEBUG - 2022-07-06 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:26 --> Total execution time: 0.0521
DEBUG - 2022-07-06 08:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:30 --> Total execution time: 0.1117
DEBUG - 2022-07-06 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:34 --> Total execution time: 0.0525
DEBUG - 2022-07-06 08:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:35 --> Total execution time: 0.0499
DEBUG - 2022-07-06 08:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:37 --> Total execution time: 0.1182
DEBUG - 2022-07-06 08:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:38 --> Total execution time: 0.0507
DEBUG - 2022-07-06 08:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:41 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:46 --> Total execution time: 0.0369
DEBUG - 2022-07-06 08:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:46 --> Total execution time: 0.0512
DEBUG - 2022-07-06 08:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:48 --> Total execution time: 0.1090
DEBUG - 2022-07-06 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:54 --> Total execution time: 0.0528
DEBUG - 2022-07-06 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:03:57 --> Total execution time: 0.0477
DEBUG - 2022-07-06 08:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:02 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:02 --> Total execution time: 0.0606
DEBUG - 2022-07-06 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:19 --> Total execution time: 0.0644
DEBUG - 2022-07-06 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:21 --> Total execution time: 0.0588
DEBUG - 2022-07-06 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:26 --> Total execution time: 0.0486
DEBUG - 2022-07-06 08:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:32 --> Total execution time: 0.0529
DEBUG - 2022-07-06 08:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:32 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:33 --> Total execution time: 0.0525
DEBUG - 2022-07-06 08:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:36 --> Total execution time: 0.0554
DEBUG - 2022-07-06 08:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:39 --> Total execution time: 0.0537
DEBUG - 2022-07-06 08:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:34:49 --> Total execution time: 0.0509
DEBUG - 2022-07-06 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:34:50 --> Total execution time: 0.0499
DEBUG - 2022-07-06 08:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:34:51 --> Total execution time: 0.1228
DEBUG - 2022-07-06 08:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:04:57 --> Total execution time: 0.0683
DEBUG - 2022-07-06 08:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:00 --> Total execution time: 0.0504
DEBUG - 2022-07-06 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:01 --> Total execution time: 0.0608
DEBUG - 2022-07-06 08:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:01 --> Total execution time: 0.0967
DEBUG - 2022-07-06 08:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:16 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:16 --> Total execution time: 0.0501
DEBUG - 2022-07-06 08:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:20 --> Total execution time: 0.0554
DEBUG - 2022-07-06 08:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:21 --> Total execution time: 0.0531
DEBUG - 2022-07-06 08:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:29 --> Total execution time: 0.0487
DEBUG - 2022-07-06 08:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:33 --> Total execution time: 0.0527
DEBUG - 2022-07-06 08:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:05:36 --> Total execution time: 0.0489
DEBUG - 2022-07-06 08:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:36:33 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:06:36 --> Total execution time: 1.9354
DEBUG - 2022-07-06 08:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:36:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:36:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:07:04 --> Total execution time: 0.0365
DEBUG - 2022-07-06 08:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:07:09 --> Total execution time: 0.0489
DEBUG - 2022-07-06 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:07:21 --> Total execution time: 0.0488
DEBUG - 2022-07-06 08:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:07:35 --> Total execution time: 0.1504
DEBUG - 2022-07-06 08:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:07:50 --> Total execution time: 0.0493
DEBUG - 2022-07-06 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:21 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:22 --> Total execution time: 0.0550
DEBUG - 2022-07-06 08:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 19:08:23 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 19:08:23 --> Total execution time: 0.1834
DEBUG - 2022-07-06 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:31 --> Total execution time: 0.0531
DEBUG - 2022-07-06 08:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:43 --> Total execution time: 0.0668
DEBUG - 2022-07-06 08:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:08:47 --> Total execution time: 0.0828
DEBUG - 2022-07-06 08:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:09:29 --> Total execution time: 0.1480
DEBUG - 2022-07-06 08:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:09:30 --> Total execution time: 0.2488
DEBUG - 2022-07-06 08:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:09:51 --> Total execution time: 0.1020
DEBUG - 2022-07-06 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:27 --> Total execution time: 0.0383
DEBUG - 2022-07-06 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:27 --> Total execution time: 0.0531
DEBUG - 2022-07-06 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:31 --> Total execution time: 0.1227
DEBUG - 2022-07-06 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:31 --> Total execution time: 0.0493
DEBUG - 2022-07-06 08:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:31 --> Total execution time: 0.0609
DEBUG - 2022-07-06 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:32 --> Total execution time: 0.0491
DEBUG - 2022-07-06 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:32 --> Total execution time: 0.0517
DEBUG - 2022-07-06 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:32 --> Total execution time: 0.0586
DEBUG - 2022-07-06 08:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:35 --> Total execution time: 0.0539
DEBUG - 2022-07-06 08:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:40 --> Total execution time: 0.0701
DEBUG - 2022-07-06 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:10:49 --> Total execution time: 0.0587
DEBUG - 2022-07-06 08:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:49 --> Total execution time: 0.0915
DEBUG - 2022-07-06 08:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:10:55 --> Total execution time: 0.1059
DEBUG - 2022-07-06 08:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:06 --> Total execution time: 0.0593
DEBUG - 2022-07-06 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:15 --> Total execution time: 0.0747
DEBUG - 2022-07-06 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:19 --> Total execution time: 0.0492
DEBUG - 2022-07-06 08:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:44 --> Total execution time: 0.0544
DEBUG - 2022-07-06 08:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:47 --> Total execution time: 0.1398
DEBUG - 2022-07-06 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:11:52 --> Total execution time: 0.0556
DEBUG - 2022-07-06 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:03 --> Total execution time: 0.0622
DEBUG - 2022-07-06 08:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:07 --> Total execution time: 0.0922
DEBUG - 2022-07-06 08:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:12 --> Total execution time: 0.0521
DEBUG - 2022-07-06 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:16 --> Total execution time: 0.0541
DEBUG - 2022-07-06 08:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:18 --> Total execution time: 0.1029
DEBUG - 2022-07-06 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:25 --> Total execution time: 0.0522
DEBUG - 2022-07-06 08:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:34 --> Total execution time: 0.0996
DEBUG - 2022-07-06 08:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:42 --> Total execution time: 0.0630
DEBUG - 2022-07-06 08:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:45 --> Total execution time: 0.0742
DEBUG - 2022-07-06 08:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:47 --> Total execution time: 0.1030
DEBUG - 2022-07-06 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:51 --> Total execution time: 0.0533
DEBUG - 2022-07-06 08:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:12:56 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:00 --> Total execution time: 0.1020
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0389
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0426
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0436
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0520
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0498
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0521
DEBUG - 2022-07-06 08:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:05 --> Total execution time: 0.0382
DEBUG - 2022-07-06 08:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:07 --> Total execution time: 0.1106
DEBUG - 2022-07-06 08:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:09 --> Total execution time: 0.0749
DEBUG - 2022-07-06 08:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:14 --> Total execution time: 0.0639
DEBUG - 2022-07-06 08:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:29 --> Total execution time: 0.0385
DEBUG - 2022-07-06 08:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:43:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:43:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:13:30 --> Total execution time: 0.0430
DEBUG - 2022-07-06 08:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:05 --> Total execution time: 0.0612
DEBUG - 2022-07-06 08:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:24 --> Total execution time: 0.0543
DEBUG - 2022-07-06 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:41 --> Total execution time: 0.1297
DEBUG - 2022-07-06 08:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:44 --> Total execution time: 0.0645
DEBUG - 2022-07-06 08:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:46 --> Total execution time: 0.0913
DEBUG - 2022-07-06 08:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:49 --> Total execution time: 0.0551
DEBUG - 2022-07-06 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:52 --> Total execution time: 0.0727
DEBUG - 2022-07-06 08:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:55 --> Total execution time: 0.0803
DEBUG - 2022-07-06 08:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:56 --> Total execution time: 0.0344
DEBUG - 2022-07-06 08:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:56 --> Total execution time: 0.0347
DEBUG - 2022-07-06 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:14:59 --> Total execution time: 0.0881
DEBUG - 2022-07-06 08:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:15:32 --> Total execution time: 0.0338
DEBUG - 2022-07-06 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:15:34 --> Total execution time: 0.0676
DEBUG - 2022-07-06 08:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:45:34 --> Total execution time: 0.0505
DEBUG - 2022-07-06 08:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:45:38 --> Total execution time: 0.0502
DEBUG - 2022-07-06 08:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:45:42 --> Total execution time: 0.0771
DEBUG - 2022-07-06 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:15:48 --> Total execution time: 0.0575
DEBUG - 2022-07-06 08:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:15:57 --> Total execution time: 0.0719
DEBUG - 2022-07-06 08:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:23 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:23 --> Total execution time: 0.0357
DEBUG - 2022-07-06 08:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:30 --> Total execution time: 0.0331
DEBUG - 2022-07-06 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:33 --> Total execution time: 0.1016
DEBUG - 2022-07-06 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:37 --> Total execution time: 0.0549
DEBUG - 2022-07-06 08:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:41 --> Total execution time: 0.0490
DEBUG - 2022-07-06 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:42 --> Total execution time: 0.0494
DEBUG - 2022-07-06 08:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:49 --> Total execution time: 0.0478
DEBUG - 2022-07-06 08:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:50 --> Total execution time: 0.0596
DEBUG - 2022-07-06 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:51 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:51 --> Total execution time: 0.0446
DEBUG - 2022-07-06 08:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:54 --> Total execution time: 0.0471
DEBUG - 2022-07-06 08:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:47:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:17:58 --> Total execution time: 0.0934
DEBUG - 2022-07-06 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:18:12 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:18:12 --> Total execution time: 0.0931
DEBUG - 2022-07-06 08:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:18:26 --> Total execution time: 0.0572
DEBUG - 2022-07-06 08:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:19:36 --> Total execution time: 0.0589
DEBUG - 2022-07-06 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:49:42 --> Total execution time: 0.0509
DEBUG - 2022-07-06 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:49:43 --> Total execution time: 0.0691
DEBUG - 2022-07-06 08:49:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:49:43 --> Total execution time: 0.1538
DEBUG - 2022-07-06 08:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:19:52 --> Total execution time: 0.1336
DEBUG - 2022-07-06 08:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:20:00 --> Total execution time: 0.0503
DEBUG - 2022-07-06 08:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:20:02 --> Total execution time: 0.0622
DEBUG - 2022-07-06 08:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:20:36 --> Total execution time: 0.0563
DEBUG - 2022-07-06 08:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:20:46 --> Total execution time: 0.0790
DEBUG - 2022-07-06 08:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:20:52 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:51:18 --> Total execution time: 0.0547
DEBUG - 2022-07-06 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:51:19 --> Total execution time: 0.0532
DEBUG - 2022-07-06 08:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:51:19 --> Total execution time: 0.1246
DEBUG - 2022-07-06 08:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:51:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:21:28 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:52:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:22:55 --> Total execution time: 0.0492
DEBUG - 2022-07-06 08:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:22:59 --> Total execution time: 0.0543
DEBUG - 2022-07-06 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:11 --> Total execution time: 0.0524
DEBUG - 2022-07-06 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:12 --> Total execution time: 0.0765
DEBUG - 2022-07-06 08:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:12 --> Total execution time: 0.0477
DEBUG - 2022-07-06 08:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:17 --> Total execution time: 0.0522
DEBUG - 2022-07-06 08:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:33 --> Total execution time: 0.0492
DEBUG - 2022-07-06 08:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:41 --> Total execution time: 0.0550
DEBUG - 2022-07-06 08:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:53:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:42 --> Total execution time: 0.0517
DEBUG - 2022-07-06 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:53:48 --> Total execution time: 0.0498
DEBUG - 2022-07-06 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:53:49 --> Total execution time: 0.0523
DEBUG - 2022-07-06 08:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:53:49 --> Total execution time: 0.0845
DEBUG - 2022-07-06 08:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:52 --> Total execution time: 0.0720
DEBUG - 2022-07-06 08:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:53:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:23:57 --> Total execution time: 0.1861
DEBUG - 2022-07-06 08:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:01 --> Total execution time: 0.0778
DEBUG - 2022-07-06 08:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:11 --> Total execution time: 0.0546
DEBUG - 2022-07-06 08:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:15 --> Total execution time: 0.0732
DEBUG - 2022-07-06 08:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:18 --> Total execution time: 0.1988
DEBUG - 2022-07-06 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:54:29 --> Total execution time: 0.0502
DEBUG - 2022-07-06 08:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:54:30 --> Total execution time: 0.0672
DEBUG - 2022-07-06 08:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:54:30 --> Total execution time: 0.0934
DEBUG - 2022-07-06 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:47 --> Total execution time: 0.0372
DEBUG - 2022-07-06 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:47 --> Total execution time: 0.0356
DEBUG - 2022-07-06 08:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:24:51 --> Total execution time: 0.0401
DEBUG - 2022-07-06 08:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:01 --> Total execution time: 0.0485
DEBUG - 2022-07-06 08:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:11 --> Total execution time: 0.0481
DEBUG - 2022-07-06 08:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:55:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:14 --> Total execution time: 1.9644
DEBUG - 2022-07-06 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 08:55:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 08:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:17 --> Total execution time: 0.0714
DEBUG - 2022-07-06 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:18 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 08:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:18 --> Total execution time: 0.0787
DEBUG - 2022-07-06 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:26 --> Total execution time: 0.0865
DEBUG - 2022-07-06 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:40 --> Total execution time: 0.0890
DEBUG - 2022-07-06 08:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:42 --> Total execution time: 0.0520
DEBUG - 2022-07-06 08:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:44 --> Total execution time: 0.1294
DEBUG - 2022-07-06 08:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:49 --> Total execution time: 0.0626
DEBUG - 2022-07-06 08:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:55:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:25:49 --> Total execution time: 0.0583
DEBUG - 2022-07-06 08:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:26:07 --> Total execution time: 0.0518
DEBUG - 2022-07-06 08:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:26:20 --> Total execution time: 0.0536
DEBUG - 2022-07-06 08:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:56:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:26:26 --> Total execution time: 0.0455
DEBUG - 2022-07-06 08:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:26:40 --> Total execution time: 0.0570
DEBUG - 2022-07-06 08:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:27:08 --> Total execution time: 0.0527
DEBUG - 2022-07-06 08:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:27:12 --> Total execution time: 0.0590
DEBUG - 2022-07-06 08:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:27:20 --> Total execution time: 0.0526
DEBUG - 2022-07-06 08:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:57:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:27:41 --> Total execution time: 0.0528
DEBUG - 2022-07-06 08:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:28:29 --> Total execution time: 0.2248
DEBUG - 2022-07-06 08:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:28:29 --> Total execution time: 0.1320
DEBUG - 2022-07-06 08:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:28:32 --> Total execution time: 0.0529
DEBUG - 2022-07-06 08:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:28:39 --> Total execution time: 0.0534
DEBUG - 2022-07-06 08:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:28:46 --> Total execution time: 0.0777
DEBUG - 2022-07-06 08:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 08:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:29:06 --> Total execution time: 0.0581
DEBUG - 2022-07-06 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:59:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:29:34 --> Total execution time: 0.0533
DEBUG - 2022-07-06 08:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 08:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 08:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:29:59 --> Total execution time: 0.0569
DEBUG - 2022-07-06 09:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:30:02 --> Total execution time: 0.0788
DEBUG - 2022-07-06 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:30:08 --> Total execution time: 0.1526
DEBUG - 2022-07-06 09:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:30:31 --> Total execution time: 0.1765
DEBUG - 2022-07-06 09:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:30:36 --> Total execution time: 0.0619
DEBUG - 2022-07-06 09:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:30:43 --> Total execution time: 0.0534
DEBUG - 2022-07-06 09:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:31:01 --> Total execution time: 0.0735
DEBUG - 2022-07-06 09:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:31:06 --> Total execution time: 0.0739
DEBUG - 2022-07-06 09:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:01:48 --> Total execution time: 0.0595
DEBUG - 2022-07-06 09:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:01:55 --> Total execution time: 0.0700
DEBUG - 2022-07-06 09:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:02:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:32:16 --> Total execution time: 0.0688
DEBUG - 2022-07-06 09:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:32:28 --> Total execution time: 0.0703
DEBUG - 2022-07-06 09:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:32:53 --> Total execution time: 0.0852
DEBUG - 2022-07-06 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:11 --> Total execution time: 0.0538
DEBUG - 2022-07-06 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:19 --> Total execution time: 0.0589
DEBUG - 2022-07-06 09:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:43 --> Total execution time: 0.0592
DEBUG - 2022-07-06 09:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:48 --> Total execution time: 0.0556
DEBUG - 2022-07-06 09:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:49 --> Total execution time: 0.0509
DEBUG - 2022-07-06 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:33:57 --> Total execution time: 0.0544
DEBUG - 2022-07-06 09:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:04:14 --> Total execution time: 0.0539
DEBUG - 2022-07-06 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:04:15 --> Total execution time: 0.0565
DEBUG - 2022-07-06 09:04:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:04:15 --> Total execution time: 0.1061
DEBUG - 2022-07-06 09:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:34:23 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:34:35 --> Total execution time: 0.0488
DEBUG - 2022-07-06 09:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:34:46 --> Total execution time: 0.0585
DEBUG - 2022-07-06 09:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:34:47 --> Total execution time: 0.0769
DEBUG - 2022-07-06 09:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:35:08 --> Total execution time: 0.0490
DEBUG - 2022-07-06 09:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:20 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:35:20 --> Total execution time: 0.0547
DEBUG - 2022-07-06 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:35:28 --> Total execution time: 0.0597
DEBUG - 2022-07-06 09:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:35:29 --> Total execution time: 0.0675
DEBUG - 2022-07-06 09:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:05:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:05:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:35:37 --> Total execution time: 0.0516
DEBUG - 2022-07-06 09:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:08:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:38:07 --> Total execution time: 0.2201
DEBUG - 2022-07-06 09:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:09:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:39:42 --> Total execution time: 0.0508
DEBUG - 2022-07-06 09:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:39:50 --> Total execution time: 0.0499
DEBUG - 2022-07-06 09:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:09:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:39:58 --> Total execution time: 0.0522
DEBUG - 2022-07-06 09:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:09 --> Total execution time: 0.1644
DEBUG - 2022-07-06 09:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:15 --> Total execution time: 0.0709
DEBUG - 2022-07-06 09:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:21 --> Total execution time: 0.0880
DEBUG - 2022-07-06 09:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:26 --> Total execution time: 0.0696
DEBUG - 2022-07-06 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:27 --> Total execution time: 0.0557
DEBUG - 2022-07-06 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:28 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:28 --> Total execution time: 0.0511
DEBUG - 2022-07-06 09:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:35 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:35 --> Total execution time: 0.0538
DEBUG - 2022-07-06 09:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:40:59 --> Total execution time: 0.1378
DEBUG - 2022-07-06 09:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:41:04 --> Total execution time: 0.0768
DEBUG - 2022-07-06 09:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:11:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:41:35 --> Total execution time: 0.1301
DEBUG - 2022-07-06 09:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:08 --> Total execution time: 0.0500
DEBUG - 2022-07-06 09:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:08 --> Total execution time: 0.0554
DEBUG - 2022-07-06 09:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:16 --> Total execution time: 0.0542
DEBUG - 2022-07-06 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:17 --> Total execution time: 0.0408
DEBUG - 2022-07-06 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:17 --> Total execution time: 0.0340
DEBUG - 2022-07-06 09:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:21 --> Total execution time: 0.0395
DEBUG - 2022-07-06 09:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:21 --> Total execution time: 0.0550
DEBUG - 2022-07-06 09:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:28 --> Total execution time: 0.0522
DEBUG - 2022-07-06 09:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:36 --> Total execution time: 0.0599
DEBUG - 2022-07-06 09:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:43 --> Total execution time: 0.1904
DEBUG - 2022-07-06 09:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:44 --> Total execution time: 0.0619
DEBUG - 2022-07-06 09:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:14:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:44:56 --> Total execution time: 0.0661
DEBUG - 2022-07-06 09:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:03 --> Total execution time: 0.0718
DEBUG - 2022-07-06 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:08 --> Total execution time: 0.0776
DEBUG - 2022-07-06 09:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:24 --> Total execution time: 0.0609
DEBUG - 2022-07-06 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:36 --> Total execution time: 0.1578
DEBUG - 2022-07-06 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:37 --> Total execution time: 0.0776
DEBUG - 2022-07-06 09:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:44 --> Total execution time: 0.0765
DEBUG - 2022-07-06 09:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:06 --> Total execution time: 0.0836
DEBUG - 2022-07-06 09:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:10 --> Total execution time: 0.0948
DEBUG - 2022-07-06 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:18 --> Total execution time: 0.0508
DEBUG - 2022-07-06 09:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:23 --> Total execution time: 0.0863
DEBUG - 2022-07-06 09:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:44 --> Total execution time: 0.0705
DEBUG - 2022-07-06 09:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:45 --> Total execution time: 0.0828
DEBUG - 2022-07-06 09:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:49 --> Total execution time: 0.0552
DEBUG - 2022-07-06 09:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:52 --> Total execution time: 0.0746
DEBUG - 2022-07-06 09:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:17:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:47:56 --> Total execution time: 0.0943
DEBUG - 2022-07-06 09:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:48:09 --> Total execution time: 0.0522
DEBUG - 2022-07-06 09:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:19:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:49:03 --> Total execution time: 0.0498
DEBUG - 2022-07-06 09:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:19:22 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-06 09:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:19:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:19:56 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-06 09:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:21:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:51:19 --> Total execution time: 0.0410
DEBUG - 2022-07-06 09:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:51:22 --> Total execution time: 0.0477
DEBUG - 2022-07-06 09:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:51:52 --> Total execution time: 0.0508
DEBUG - 2022-07-06 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:52:50 --> Total execution time: 0.0604
DEBUG - 2022-07-06 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:55:02 --> Total execution time: 0.0686
DEBUG - 2022-07-06 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:55:12 --> Total execution time: 0.0599
DEBUG - 2022-07-06 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:55:15 --> Total execution time: 0.0805
DEBUG - 2022-07-06 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:56:39 --> Total execution time: 0.0586
DEBUG - 2022-07-06 09:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:56:40 --> Total execution time: 0.1270
DEBUG - 2022-07-06 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:56:58 --> Total execution time: 0.0522
DEBUG - 2022-07-06 09:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:57:55 --> Total execution time: 0.0545
DEBUG - 2022-07-06 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:27:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:57:58 --> Total execution time: 0.0531
DEBUG - 2022-07-06 09:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:58:15 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:28:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:58:32 --> Total execution time: 0.1224
DEBUG - 2022-07-06 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:00:16 --> Total execution time: 0.0486
DEBUG - 2022-07-06 09:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:00:26 --> Total execution time: 0.0487
DEBUG - 2022-07-06 09:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:00:31 --> Total execution time: 0.0501
DEBUG - 2022-07-06 09:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:00:48 --> Total execution time: 0.0656
DEBUG - 2022-07-06 09:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:00:54 --> Total execution time: 0.0629
DEBUG - 2022-07-06 09:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:31:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:01:08 --> Total execution time: 0.0495
DEBUG - 2022-07-06 09:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:31:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:01:25 --> Total execution time: 0.0477
DEBUG - 2022-07-06 09:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:01:27 --> Total execution time: 0.0500
DEBUG - 2022-07-06 09:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:31:55 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:01:56 --> Total execution time: 0.1680
DEBUG - 2022-07-06 09:32:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:07 --> Total execution time: 0.0602
DEBUG - 2022-07-06 09:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:11 --> Total execution time: 0.1982
DEBUG - 2022-07-06 09:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:12 --> Total execution time: 0.1000
DEBUG - 2022-07-06 09:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:14 --> Total execution time: 0.0499
DEBUG - 2022-07-06 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:21 --> Total execution time: 0.0554
DEBUG - 2022-07-06 09:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:22 --> Total execution time: 0.0825
DEBUG - 2022-07-06 09:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:23 --> Total execution time: 0.0722
DEBUG - 2022-07-06 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:27 --> Total execution time: 0.0366
DEBUG - 2022-07-06 09:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:27 --> Total execution time: 0.0528
DEBUG - 2022-07-06 09:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:28 --> Total execution time: 0.1592
DEBUG - 2022-07-06 09:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:29 --> Total execution time: 0.0561
DEBUG - 2022-07-06 09:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:31 --> Total execution time: 0.0617
DEBUG - 2022-07-06 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:47 --> Total execution time: 0.0354
DEBUG - 2022-07-06 09:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:02:48 --> Total execution time: 0.1231
DEBUG - 2022-07-06 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:32:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:32:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 09:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:03:02 --> Total execution time: 0.0630
DEBUG - 2022-07-06 09:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:33:18 --> Total execution time: 0.0506
DEBUG - 2022-07-06 09:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:33:20 --> Total execution time: 0.0560
DEBUG - 2022-07-06 09:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:33:20 --> Total execution time: 0.1162
DEBUG - 2022-07-06 09:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:03:27 --> Total execution time: 0.1288
DEBUG - 2022-07-06 09:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:03:40 --> Total execution time: 0.0473
DEBUG - 2022-07-06 09:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:03:49 --> Total execution time: 0.0528
DEBUG - 2022-07-06 09:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:06 --> Total execution time: 0.0495
DEBUG - 2022-07-06 09:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:13 --> Total execution time: 0.0549
DEBUG - 2022-07-06 09:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:17 --> Total execution time: 0.0791
DEBUG - 2022-07-06 09:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:29 --> Total execution time: 0.0840
DEBUG - 2022-07-06 09:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:30 --> Total execution time: 0.0561
DEBUG - 2022-07-06 09:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:32 --> Total execution time: 0.0770
DEBUG - 2022-07-06 09:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:44 --> Total execution time: 0.0698
DEBUG - 2022-07-06 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:04:57 --> Total execution time: 0.0761
DEBUG - 2022-07-06 09:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:04 --> Total execution time: 0.0490
DEBUG - 2022-07-06 09:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:13 --> Total execution time: 0.0788
DEBUG - 2022-07-06 09:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:14 --> Total execution time: 0.0609
DEBUG - 2022-07-06 09:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:17 --> Total execution time: 0.0513
DEBUG - 2022-07-06 09:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:28 --> Total execution time: 0.0601
DEBUG - 2022-07-06 09:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:29 --> Total execution time: 0.0509
DEBUG - 2022-07-06 09:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:35 --> Total execution time: 0.0559
DEBUG - 2022-07-06 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:37 --> Total execution time: 0.0570
DEBUG - 2022-07-06 09:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:35:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:05:42 --> Total execution time: 0.0544
DEBUG - 2022-07-06 09:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:06:11 --> Total execution time: 0.0518
DEBUG - 2022-07-06 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:36:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:06:24 --> Total execution time: 0.0382
DEBUG - 2022-07-06 09:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:06:35 --> Total execution time: 0.0490
DEBUG - 2022-07-06 09:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:03 --> Total execution time: 0.0510
DEBUG - 2022-07-06 09:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:04 --> Total execution time: 0.0325
DEBUG - 2022-07-06 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:20 --> Total execution time: 0.0480
DEBUG - 2022-07-06 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:22 --> Total execution time: 0.0553
DEBUG - 2022-07-06 09:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:38 --> Total execution time: 0.1310
DEBUG - 2022-07-06 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:41 --> Total execution time: 0.0543
DEBUG - 2022-07-06 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:43 --> Total execution time: 0.0532
DEBUG - 2022-07-06 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:43 --> Total execution time: 0.0477
DEBUG - 2022-07-06 09:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:44 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:45 --> Total execution time: 0.0540
DEBUG - 2022-07-06 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:07:46 --> Total execution time: 0.0550
DEBUG - 2022-07-06 09:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:08 --> Total execution time: 0.0534
DEBUG - 2022-07-06 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:11 --> Total execution time: 0.0649
DEBUG - 2022-07-06 09:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:16 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:16 --> Total execution time: 0.0820
DEBUG - 2022-07-06 09:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:21 --> Total execution time: 0.0439
DEBUG - 2022-07-06 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:31 --> Total execution time: 0.0861
DEBUG - 2022-07-06 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:37 --> Total execution time: 0.1426
DEBUG - 2022-07-06 09:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:52 --> Total execution time: 0.0478
DEBUG - 2022-07-06 09:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:38:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:08:55 --> Total execution time: 0.0486
DEBUG - 2022-07-06 09:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:24 --> Total execution time: 0.0509
DEBUG - 2022-07-06 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:30 --> Total execution time: 0.0926
DEBUG - 2022-07-06 09:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:33 --> Total execution time: 0.0323
DEBUG - 2022-07-06 09:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:38 --> Total execution time: 0.0757
DEBUG - 2022-07-06 09:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:41 --> Total execution time: 0.0424
DEBUG - 2022-07-06 09:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:44 --> Total execution time: 0.0586
DEBUG - 2022-07-06 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:47 --> Total execution time: 0.0508
DEBUG - 2022-07-06 09:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:49 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:49 --> Total execution time: 0.0528
DEBUG - 2022-07-06 09:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:39:55 --> Total execution time: 0.0523
DEBUG - 2022-07-06 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:39:57 --> Total execution time: 0.0537
DEBUG - 2022-07-06 09:39:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:39:57 --> Total execution time: 0.1190
DEBUG - 2022-07-06 09:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:09:59 --> Total execution time: 0.0529
DEBUG - 2022-07-06 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:00 --> Total execution time: 0.0513
DEBUG - 2022-07-06 09:40:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:11 --> Total execution time: 0.0536
DEBUG - 2022-07-06 09:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:39 --> Total execution time: 0.0513
DEBUG - 2022-07-06 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:40:41 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:44 --> Total execution time: 1.9753
DEBUG - 2022-07-06 09:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:40:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:40:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:40:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:10:59 --> Total execution time: 0.0679
DEBUG - 2022-07-06 09:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:01 --> Total execution time: 0.0756
DEBUG - 2022-07-06 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:05 --> Total execution time: 0.0573
DEBUG - 2022-07-06 09:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:07 --> Total execution time: 0.0325
DEBUG - 2022-07-06 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:09 --> Total execution time: 0.0351
DEBUG - 2022-07-06 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:10 --> Total execution time: 0.1328
DEBUG - 2022-07-06 09:41:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:10 --> Total execution time: 0.0608
DEBUG - 2022-07-06 09:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:13 --> Total execution time: 0.0512
DEBUG - 2022-07-06 09:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:17 --> Total execution time: 0.0524
DEBUG - 2022-07-06 09:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:18 --> Total execution time: 0.0819
DEBUG - 2022-07-06 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:20 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:21 --> Total execution time: 0.0633
DEBUG - 2022-07-06 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:21 --> Total execution time: 0.0730
DEBUG - 2022-07-06 09:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-07-06 20:11:22 --> Severity: Warning --> Attempt to read property "ul_login_status" on bool /home3/esalesei/esalestrix.in/application/helpers/project_helper.php 414
DEBUG - 2022-07-06 20:11:22 --> Total execution time: 0.0743
DEBUG - 2022-07-06 09:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:26 --> Total execution time: 0.0958
DEBUG - 2022-07-06 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:11:31 --> Total execution time: 0.1329
DEBUG - 2022-07-06 09:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:31 --> Total execution time: 0.0549
DEBUG - 2022-07-06 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:31 --> Total execution time: 0.0791
DEBUG - 2022-07-06 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:35 --> Total execution time: 0.0326
DEBUG - 2022-07-06 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:36 --> Total execution time: 0.0583
DEBUG - 2022-07-06 09:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:37 --> Total execution time: 0.1103
DEBUG - 2022-07-06 09:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:38 --> Total execution time: 0.0529
DEBUG - 2022-07-06 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:43 --> Total execution time: 0.0546
DEBUG - 2022-07-06 09:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:46 --> Total execution time: 0.0625
DEBUG - 2022-07-06 09:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:49 --> Total execution time: 0.0788
DEBUG - 2022-07-06 09:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:50 --> Total execution time: 0.0614
DEBUG - 2022-07-06 09:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:11:52 --> Total execution time: 0.0711
DEBUG - 2022-07-06 09:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:00 --> Total execution time: 0.0539
DEBUG - 2022-07-06 09:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:01 --> Total execution time: 0.0773
DEBUG - 2022-07-06 09:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:06 --> Total execution time: 0.0490
DEBUG - 2022-07-06 09:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:08 --> Total execution time: 0.0349
DEBUG - 2022-07-06 09:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:09 --> Total execution time: 0.0325
DEBUG - 2022-07-06 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:10 --> Total execution time: 0.0394
DEBUG - 2022-07-06 09:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:10 --> Total execution time: 0.0554
DEBUG - 2022-07-06 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:15 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:15 --> Total execution time: 0.0413
DEBUG - 2022-07-06 09:42:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:15 --> Total execution time: 0.0574
DEBUG - 2022-07-06 09:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:33 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:33 --> Total execution time: 0.0535
DEBUG - 2022-07-06 09:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:54 --> Total execution time: 0.1208
DEBUG - 2022-07-06 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:58 --> Total execution time: 0.0523
DEBUG - 2022-07-06 09:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:12:59 --> Total execution time: 0.0570
DEBUG - 2022-07-06 09:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:01 --> Total execution time: 0.0770
DEBUG - 2022-07-06 09:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:02 --> Total execution time: 0.0505
DEBUG - 2022-07-06 09:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:07 --> Total execution time: 0.0499
DEBUG - 2022-07-06 09:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:07 --> Total execution time: 0.0647
DEBUG - 2022-07-06 09:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:10 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:10 --> Total execution time: 0.0507
DEBUG - 2022-07-06 09:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:13 --> Total execution time: 0.0781
DEBUG - 2022-07-06 09:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:25 --> Total execution time: 0.0405
DEBUG - 2022-07-06 09:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:26 --> Total execution time: 0.0501
DEBUG - 2022-07-06 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:35 --> Total execution time: 0.0515
DEBUG - 2022-07-06 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:41 --> Total execution time: 0.0914
DEBUG - 2022-07-06 09:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:47 --> Total execution time: 0.0511
DEBUG - 2022-07-06 09:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:51 --> Total execution time: 0.0624
DEBUG - 2022-07-06 09:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:43:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:13:52 --> Total execution time: 0.0555
DEBUG - 2022-07-06 09:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:01 --> Total execution time: 0.0573
DEBUG - 2022-07-06 09:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:01 --> Total execution time: 0.0625
DEBUG - 2022-07-06 09:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:44:03 --> Total execution time: 0.0640
DEBUG - 2022-07-06 09:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:04 --> Total execution time: 0.0615
DEBUG - 2022-07-06 09:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:06 --> Total execution time: 0.0541
DEBUG - 2022-07-06 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:09 --> Total execution time: 0.1256
DEBUG - 2022-07-06 09:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:12 --> Total execution time: 0.0754
DEBUG - 2022-07-06 09:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:18 --> Total execution time: 0.0490
DEBUG - 2022-07-06 09:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:39 --> Total execution time: 0.0496
DEBUG - 2022-07-06 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:41 --> Total execution time: 0.0505
DEBUG - 2022-07-06 09:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:14:59 --> Total execution time: 0.1381
DEBUG - 2022-07-06 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:15:03 --> Total execution time: 0.0531
DEBUG - 2022-07-06 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:15:09 --> Total execution time: 0.0865
DEBUG - 2022-07-06 09:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:15:17 --> Total execution time: 0.0809
DEBUG - 2022-07-06 09:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:15:27 --> Total execution time: 0.0782
DEBUG - 2022-07-06 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:46:18 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 09:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:16:20 --> Total execution time: 0.0531
DEBUG - 2022-07-06 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:16:26 --> Total execution time: 0.0790
DEBUG - 2022-07-06 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:16:26 --> Total execution time: 0.0679
DEBUG - 2022-07-06 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:16:34 --> Total execution time: 0.1290
DEBUG - 2022-07-06 09:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:46:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:16:38 --> Total execution time: 0.0511
DEBUG - 2022-07-06 09:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:05 --> Total execution time: 0.0557
DEBUG - 2022-07-06 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:07 --> Total execution time: 0.0536
DEBUG - 2022-07-06 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:19 --> Total execution time: 0.0535
DEBUG - 2022-07-06 09:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:22 --> Total execution time: 0.0483
DEBUG - 2022-07-06 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:26 --> Total execution time: 0.0510
DEBUG - 2022-07-06 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:27 --> Total execution time: 0.0588
DEBUG - 2022-07-06 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:40 --> Total execution time: 0.0424
DEBUG - 2022-07-06 09:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:42 --> Total execution time: 0.0750
DEBUG - 2022-07-06 09:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:44 --> Total execution time: 0.1324
DEBUG - 2022-07-06 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:47 --> Total execution time: 0.0493
DEBUG - 2022-07-06 09:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:50 --> Total execution time: 0.0477
DEBUG - 2022-07-06 09:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:50 --> Total execution time: 0.0489
DEBUG - 2022-07-06 09:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:50 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:51 --> Total execution time: 0.0499
DEBUG - 2022-07-06 09:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:17:51 --> Total execution time: 0.0467
DEBUG - 2022-07-06 09:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:01 --> Total execution time: 0.0485
DEBUG - 2022-07-06 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:03 --> Total execution time: 0.0388
DEBUG - 2022-07-06 09:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:06 --> Total execution time: 0.0414
DEBUG - 2022-07-06 09:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:08 --> Total execution time: 0.0611
DEBUG - 2022-07-06 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:11 --> Total execution time: 0.0496
DEBUG - 2022-07-06 09:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:15 --> Total execution time: 0.0520
DEBUG - 2022-07-06 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:35 --> Total execution time: 0.0742
DEBUG - 2022-07-06 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:35 --> Total execution time: 0.0724
DEBUG - 2022-07-06 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:39 --> Total execution time: 0.0555
DEBUG - 2022-07-06 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:43 --> Total execution time: 0.0717
DEBUG - 2022-07-06 09:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:48:59 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 09:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:12 --> Total execution time: 0.0365
DEBUG - 2022-07-06 09:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:12 --> Total execution time: 0.0374
DEBUG - 2022-07-06 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:14 --> Total execution time: 0.0362
DEBUG - 2022-07-06 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:15 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:15 --> Total execution time: 0.0500
DEBUG - 2022-07-06 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:15 --> Total execution time: 0.0423
DEBUG - 2022-07-06 09:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:16 --> Total execution time: 0.0367
DEBUG - 2022-07-06 09:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:31 --> Total execution time: 0.0592
DEBUG - 2022-07-06 09:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:41 --> Total execution time: 0.0631
DEBUG - 2022-07-06 09:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:19:44 --> Total execution time: 0.0795
DEBUG - 2022-07-06 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:20:21 --> Total execution time: 0.0514
DEBUG - 2022-07-06 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:20:37 --> Total execution time: 0.0385
DEBUG - 2022-07-06 09:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:20:54 --> Total execution time: 0.0560
DEBUG - 2022-07-06 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:21:06 --> Total execution time: 0.1574
DEBUG - 2022-07-06 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 09:51:06 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 09:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:21:13 --> Total execution time: 0.0510
DEBUG - 2022-07-06 09:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:21:15 --> Total execution time: 0.0529
DEBUG - 2022-07-06 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:51:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:51:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:21:28 --> Total execution time: 0.0399
DEBUG - 2022-07-06 20:21:28 --> Total execution time: 0.0740
DEBUG - 2022-07-06 09:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:52:03 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:22:03 --> Total execution time: 0.0384
DEBUG - 2022-07-06 09:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:22:27 --> Total execution time: 0.0539
DEBUG - 2022-07-06 09:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:22:40 --> Total execution time: 0.0603
DEBUG - 2022-07-06 09:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:54:25 --> Total execution time: 0.0564
DEBUG - 2022-07-06 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:24:28 --> Total execution time: 0.0493
DEBUG - 2022-07-06 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:24:30 --> Total execution time: 0.0371
DEBUG - 2022-07-06 09:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:54:37 --> Total execution time: 0.1543
DEBUG - 2022-07-06 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:24:42 --> Total execution time: 0.0549
DEBUG - 2022-07-06 09:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:25:00 --> Total execution time: 0.1450
DEBUG - 2022-07-06 09:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:25:53 --> Total execution time: 0.0481
DEBUG - 2022-07-06 09:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:26:10 --> Total execution time: 0.0483
DEBUG - 2022-07-06 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:26:45 --> Total execution time: 0.0343
DEBUG - 2022-07-06 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:26:48 --> Total execution time: 0.0593
DEBUG - 2022-07-06 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:26:48 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:26:49 --> Total execution time: 0.0544
DEBUG - 2022-07-06 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:00 --> Total execution time: 0.0558
DEBUG - 2022-07-06 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:08 --> Total execution time: 0.0702
DEBUG - 2022-07-06 09:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:13 --> Total execution time: 0.0497
DEBUG - 2022-07-06 09:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:18 --> Total execution time: 0.0506
DEBUG - 2022-07-06 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:27 --> Total execution time: 0.0994
DEBUG - 2022-07-06 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:35 --> Total execution time: 0.0514
DEBUG - 2022-07-06 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:51 --> Total execution time: 0.0570
DEBUG - 2022-07-06 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:27:57 --> Total execution time: 0.0723
DEBUG - 2022-07-06 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:08 --> Total execution time: 0.0893
DEBUG - 2022-07-06 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:29 --> Total execution time: 0.0501
DEBUG - 2022-07-06 09:58:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:29 --> Total execution time: 0.0859
DEBUG - 2022-07-06 09:58:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:35 --> Total execution time: 0.0714
DEBUG - 2022-07-06 09:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:37 --> Total execution time: 0.1189
DEBUG - 2022-07-06 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:28:52 --> Total execution time: 0.1523
DEBUG - 2022-07-06 09:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:11 --> Total execution time: 0.0731
DEBUG - 2022-07-06 09:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:37 --> Total execution time: 0.0906
DEBUG - 2022-07-06 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 09:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:40 --> Total execution time: 0.0865
DEBUG - 2022-07-06 09:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:49 --> Total execution time: 0.0568
DEBUG - 2022-07-06 09:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:50 --> Total execution time: 0.0574
DEBUG - 2022-07-06 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:29:52 --> Total execution time: 0.0587
DEBUG - 2022-07-06 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 09:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:30:00 --> Total execution time: 0.0871
DEBUG - 2022-07-06 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:30:02 --> Total execution time: 0.0511
DEBUG - 2022-07-06 10:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:31:13 --> Total execution time: 0.0647
DEBUG - 2022-07-06 10:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:31:28 --> Total execution time: 0.0982
DEBUG - 2022-07-06 10:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:31:52 --> Total execution time: 0.0508
DEBUG - 2022-07-06 10:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:32:33 --> Total execution time: 0.0477
DEBUG - 2022-07-06 10:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:32:58 --> Total execution time: 0.0578
DEBUG - 2022-07-06 10:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:32:59 --> Total execution time: 0.1246
DEBUG - 2022-07-06 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:33:20 --> Total execution time: 0.1245
DEBUG - 2022-07-06 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:33:21 --> Total execution time: 0.0482
DEBUG - 2022-07-06 10:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:33:36 --> Total execution time: 0.0475
DEBUG - 2022-07-06 10:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:33:54 --> Total execution time: 0.0536
DEBUG - 2022-07-06 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:03:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:33:59 --> Total execution time: 0.0551
DEBUG - 2022-07-06 10:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:00 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 10:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:00 --> Total execution time: 0.0434
DEBUG - 2022-07-06 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:12 --> Total execution time: 0.0519
DEBUG - 2022-07-06 10:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:38 --> Total execution time: 0.0608
DEBUG - 2022-07-06 10:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:48 --> Total execution time: 0.0553
DEBUG - 2022-07-06 10:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:50 --> Total execution time: 0.0478
DEBUG - 2022-07-06 10:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:04:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:04:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:34:57 --> Total execution time: 0.0508
DEBUG - 2022-07-06 10:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:04 --> Total execution time: 0.0487
DEBUG - 2022-07-06 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:11 --> Total execution time: 0.0527
DEBUG - 2022-07-06 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:12 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:12 --> Total execution time: 0.0436
DEBUG - 2022-07-06 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:16 --> Total execution time: 0.0456
DEBUG - 2022-07-06 10:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:29 --> Total execution time: 0.0529
DEBUG - 2022-07-06 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:33 --> Total execution time: 0.0552
DEBUG - 2022-07-06 10:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:40 --> Total execution time: 0.0613
DEBUG - 2022-07-06 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:05:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:35:58 --> Total execution time: 0.0775
DEBUG - 2022-07-06 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:36:06 --> Total execution time: 0.0342
DEBUG - 2022-07-06 10:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:36:06 --> Total execution time: 0.0528
DEBUG - 2022-07-06 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:36:08 --> Total execution time: 0.0452
DEBUG - 2022-07-06 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:06:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:36:44 --> Total execution time: 0.1246
DEBUG - 2022-07-06 10:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:36:44 --> Total execution time: 0.1434
DEBUG - 2022-07-06 10:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:08 --> Total execution time: 0.1256
DEBUG - 2022-07-06 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:11 --> Total execution time: 0.0580
DEBUG - 2022-07-06 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:16 --> Total execution time: 0.0675
DEBUG - 2022-07-06 10:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:33 --> Total execution time: 0.0469
DEBUG - 2022-07-06 10:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:43 --> Total execution time: 0.2289
DEBUG - 2022-07-06 10:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:49 --> Total execution time: 0.2739
DEBUG - 2022-07-06 10:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:37:56 --> Total execution time: 0.0527
DEBUG - 2022-07-06 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:38:21 --> Total execution time: 0.0989
DEBUG - 2022-07-06 10:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:38:21 --> Total execution time: 0.0504
DEBUG - 2022-07-06 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:08:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:38:22 --> Total execution time: 0.1435
DEBUG - 2022-07-06 10:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:38:52 --> Total execution time: 0.1545
DEBUG - 2022-07-06 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:38:53 --> Total execution time: 0.0754
DEBUG - 2022-07-06 10:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:39:08 --> Total execution time: 0.0802
DEBUG - 2022-07-06 10:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:39:49 --> Total execution time: 0.0532
DEBUG - 2022-07-06 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:40:03 --> Total execution time: 0.0576
DEBUG - 2022-07-06 10:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:40:37 --> Total execution time: 0.0494
DEBUG - 2022-07-06 10:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:40:41 --> Total execution time: 0.0781
DEBUG - 2022-07-06 10:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:40:42 --> Total execution time: 0.0768
DEBUG - 2022-07-06 10:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:10:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:40:52 --> Total execution time: 0.0728
DEBUG - 2022-07-06 10:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:07 --> Total execution time: 0.0509
DEBUG - 2022-07-06 10:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:13 --> Total execution time: 0.0501
DEBUG - 2022-07-06 10:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:25 --> Total execution time: 0.0521
DEBUG - 2022-07-06 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:38 --> Total execution time: 0.0885
DEBUG - 2022-07-06 10:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:39 --> Total execution time: 0.0466
DEBUG - 2022-07-06 10:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:46 --> Total execution time: 0.0498
DEBUG - 2022-07-06 10:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:51 --> Total execution time: 0.0547
DEBUG - 2022-07-06 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:41:52 --> Total execution time: 0.0508
DEBUG - 2022-07-06 10:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:11:57 --> Total execution time: 0.0477
DEBUG - 2022-07-06 10:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:10 --> Total execution time: 0.1193
DEBUG - 2022-07-06 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:14 --> Total execution time: 0.0546
DEBUG - 2022-07-06 10:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:14 --> Total execution time: 0.0852
DEBUG - 2022-07-06 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:25 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 10:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:25 --> Total execution time: 0.0509
DEBUG - 2022-07-06 10:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:42:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 10:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:27 --> Total execution time: 0.0725
DEBUG - 2022-07-06 20:42:27 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 20:42:27 --> Total execution time: 0.2241
DEBUG - 2022-07-06 10:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:39 --> Total execution time: 0.0513
DEBUG - 2022-07-06 10:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:44 --> Total execution time: 0.0829
DEBUG - 2022-07-06 10:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:52 --> Total execution time: 0.4429
DEBUG - 2022-07-06 10:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:42:59 --> Total execution time: 0.0519
DEBUG - 2022-07-06 10:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:04 --> Total execution time: 0.0849
DEBUG - 2022-07-06 10:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:13 --> Total execution time: 0.3590
DEBUG - 2022-07-06 10:13:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:21 --> Total execution time: 0.0382
DEBUG - 2022-07-06 10:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:25 --> Total execution time: 0.0526
DEBUG - 2022-07-06 10:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:28 --> Total execution time: 0.0577
DEBUG - 2022-07-06 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:29 --> Total execution time: 0.0512
DEBUG - 2022-07-06 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:32 --> Total execution time: 0.0537
DEBUG - 2022-07-06 10:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:35 --> Total execution time: 0.0681
DEBUG - 2022-07-06 10:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:13:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:43:47 --> Total execution time: 0.0496
DEBUG - 2022-07-06 10:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:14:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:44:06 --> Total execution time: 0.1198
DEBUG - 2022-07-06 10:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 10:15:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 10:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:46:13 --> Total execution time: 0.1293
DEBUG - 2022-07-06 10:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:46:30 --> Total execution time: 0.0602
DEBUG - 2022-07-06 10:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:46:46 --> Total execution time: 0.0499
DEBUG - 2022-07-06 10:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:16:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:46:58 --> Total execution time: 0.0538
DEBUG - 2022-07-06 10:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:47:05 --> Total execution time: 0.0555
DEBUG - 2022-07-06 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:47:21 --> Total execution time: 0.1085
DEBUG - 2022-07-06 10:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:47:49 --> Total execution time: 0.0590
DEBUG - 2022-07-06 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:47:55 --> Total execution time: 0.0580
DEBUG - 2022-07-06 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:06 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:06 --> Total execution time: 0.1345
DEBUG - 2022-07-06 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:08 --> Total execution time: 0.0429
DEBUG - 2022-07-06 10:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:26 --> Total execution time: 0.0620
DEBUG - 2022-07-06 10:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:29 --> Total execution time: 0.0616
DEBUG - 2022-07-06 10:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:37 --> Total execution time: 0.1312
DEBUG - 2022-07-06 10:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:40 --> Total execution time: 0.0365
DEBUG - 2022-07-06 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:50 --> Total execution time: 0.0604
DEBUG - 2022-07-06 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:50 --> Total execution time: 0.0510
DEBUG - 2022-07-06 10:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:31:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:01:04 --> Total execution time: 0.0811
DEBUG - 2022-07-06 10:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:32:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:02:57 --> Total execution time: 0.1609
DEBUG - 2022-07-06 10:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:04 --> Total execution time: 0.0850
DEBUG - 2022-07-06 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:11 --> Total execution time: 0.0577
DEBUG - 2022-07-06 10:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:21 --> Total execution time: 0.0801
DEBUG - 2022-07-06 10:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:40 --> Total execution time: 0.0678
DEBUG - 2022-07-06 10:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:41 --> Total execution time: 0.1501
DEBUG - 2022-07-06 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:57 --> Total execution time: 0.0800
DEBUG - 2022-07-06 10:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:03:59 --> Total execution time: 0.0574
DEBUG - 2022-07-06 10:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:01 --> Total execution time: 0.0509
DEBUG - 2022-07-06 10:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:02 --> Total execution time: 0.0547
DEBUG - 2022-07-06 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:03 --> Total execution time: 0.0556
DEBUG - 2022-07-06 10:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:06 --> Total execution time: 0.0549
DEBUG - 2022-07-06 10:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:10 --> Total execution time: 0.1313
DEBUG - 2022-07-06 10:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:13 --> Total execution time: 0.0587
DEBUG - 2022-07-06 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:20 --> Total execution time: 0.0589
DEBUG - 2022-07-06 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:39 --> Total execution time: 0.0559
DEBUG - 2022-07-06 10:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:40 --> Total execution time: 0.0517
DEBUG - 2022-07-06 10:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:42 --> Total execution time: 0.0524
DEBUG - 2022-07-06 10:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:44 --> Total execution time: 0.0528
DEBUG - 2022-07-06 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:04:59 --> Total execution time: 0.0581
DEBUG - 2022-07-06 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:05:02 --> Total execution time: 0.0533
DEBUG - 2022-07-06 10:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:05:41 --> Total execution time: 0.0771
DEBUG - 2022-07-06 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:23 --> Total execution time: 0.1233
DEBUG - 2022-07-06 10:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:26 --> Total execution time: 0.1259
DEBUG - 2022-07-06 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:40 --> Total execution time: 0.0493
DEBUG - 2022-07-06 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:55 --> Total execution time: 0.0519
DEBUG - 2022-07-06 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:10 --> Total execution time: 0.0615
DEBUG - 2022-07-06 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:21 --> Total execution time: 0.0486
DEBUG - 2022-07-06 10:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:32 --> Total execution time: 0.0493
DEBUG - 2022-07-06 10:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:39 --> Total execution time: 0.0545
DEBUG - 2022-07-06 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:47 --> Total execution time: 0.0532
DEBUG - 2022-07-06 10:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:47 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 10:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:37:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:48 --> Total execution time: 0.0573
DEBUG - 2022-07-06 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:08:08 --> Total execution time: 0.0493
DEBUG - 2022-07-06 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:08:27 --> Total execution time: 0.0490
DEBUG - 2022-07-06 10:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:38:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:08:43 --> Total execution time: 0.0498
DEBUG - 2022-07-06 10:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:39:26 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:09:26 --> Total execution time: 0.0390
DEBUG - 2022-07-06 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:39:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:09:59 --> Total execution time: 0.0541
DEBUG - 2022-07-06 10:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:40:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:40:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:10:20 --> Total execution time: 0.0571
DEBUG - 2022-07-06 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:10:24 --> Total execution time: 0.0695
DEBUG - 2022-07-06 10:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:10:30 --> Total execution time: 0.0576
DEBUG - 2022-07-06 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:10:35 --> Total execution time: 0.0902
DEBUG - 2022-07-06 10:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 10:45:03 --> 404 Page Not Found: Wp-signinphp/index
DEBUG - 2022-07-06 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:15:05 --> Total execution time: 0.1738
DEBUG - 2022-07-06 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:15:17 --> Total execution time: 0.0431
DEBUG - 2022-07-06 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:15:18 --> Total execution time: 0.0881
DEBUG - 2022-07-06 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:15:49 --> Total execution time: 0.0801
DEBUG - 2022-07-06 10:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:15:49 --> Total execution time: 0.0739
DEBUG - 2022-07-06 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:46:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:16:04 --> Total execution time: 0.0560
DEBUG - 2022-07-06 10:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:46:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 10:46:20 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 10:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 10:46:23 --> 404 Page Not Found: Checkout-2/index
DEBUG - 2022-07-06 10:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:20:32 --> Total execution time: 0.2418
DEBUG - 2022-07-06 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:53:02 --> Total execution time: 0.1231
DEBUG - 2022-07-06 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:53:12 --> Total execution time: 0.1209
DEBUG - 2022-07-06 10:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:23:20 --> Total execution time: 0.0761
DEBUG - 2022-07-06 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:23:23 --> Total execution time: 0.0492
DEBUG - 2022-07-06 10:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:53:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:23:27 --> Total execution time: 0.0580
DEBUG - 2022-07-06 10:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:23:34 --> Total execution time: 0.1194
DEBUG - 2022-07-06 10:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:23:36 --> Total execution time: 0.1084
DEBUG - 2022-07-06 10:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:04 --> Total execution time: 0.0532
DEBUG - 2022-07-06 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:09 --> Total execution time: 0.0608
DEBUG - 2022-07-06 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:10 --> Total execution time: 0.0774
DEBUG - 2022-07-06 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:14 --> Total execution time: 0.0956
DEBUG - 2022-07-06 10:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:27 --> Total execution time: 0.0556
DEBUG - 2022-07-06 10:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:40 --> Total execution time: 0.1876
DEBUG - 2022-07-06 10:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:46 --> Total execution time: 0.1430
DEBUG - 2022-07-06 10:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:26:10 --> Total execution time: 0.0694
DEBUG - 2022-07-06 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:27:47 --> Total execution time: 0.0581
DEBUG - 2022-07-06 10:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:58:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 10:58:38 --> 404 Page Not Found: Shop/feed
DEBUG - 2022-07-06 10:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:28:40 --> Total execution time: 0.0979
DEBUG - 2022-07-06 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:28:58 --> Total execution time: 0.0682
DEBUG - 2022-07-06 10:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:12 --> Total execution time: 0.0543
DEBUG - 2022-07-06 10:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:15 --> Total execution time: 0.0719
DEBUG - 2022-07-06 10:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:17 --> Total execution time: 0.0521
DEBUG - 2022-07-06 10:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:20 --> Total execution time: 0.0709
DEBUG - 2022-07-06 10:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:27 --> Total execution time: 0.0896
DEBUG - 2022-07-06 10:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:27 --> Total execution time: 0.0888
DEBUG - 2022-07-06 10:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 10:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 10:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:29:34 --> Total execution time: 0.0587
DEBUG - 2022-07-06 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:30:02 --> Total execution time: 0.0572
DEBUG - 2022-07-06 11:00:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:00:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:30:27 --> Total execution time: 0.0514
DEBUG - 2022-07-06 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:10 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:11 --> Total execution time: 0.1050
DEBUG - 2022-07-06 11:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:15 --> Total execution time: 0.0370
DEBUG - 2022-07-06 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:27 --> Total execution time: 0.0594
DEBUG - 2022-07-06 11:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:32 --> Total execution time: 0.0846
DEBUG - 2022-07-06 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:35 --> Total execution time: 0.0609
DEBUG - 2022-07-06 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:40 --> Total execution time: 0.0718
DEBUG - 2022-07-06 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:43 --> Total execution time: 0.0541
DEBUG - 2022-07-06 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:45 --> Total execution time: 0.0636
DEBUG - 2022-07-06 11:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:35:53 --> Total execution time: 0.0652
DEBUG - 2022-07-06 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:00 --> Total execution time: 0.0651
DEBUG - 2022-07-06 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:09 --> Total execution time: 0.0512
DEBUG - 2022-07-06 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:12 --> Total execution time: 0.0535
DEBUG - 2022-07-06 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:17 --> Total execution time: 0.0570
DEBUG - 2022-07-06 11:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:20 --> Total execution time: 0.0639
DEBUG - 2022-07-06 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:25 --> Total execution time: 0.0654
DEBUG - 2022-07-06 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:32 --> Total execution time: 0.0563
DEBUG - 2022-07-06 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:06:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:06:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:06:33 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:36:33 --> Total execution time: 0.0306
DEBUG - 2022-07-06 11:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:07:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:37:08 --> Total execution time: 0.1441
DEBUG - 2022-07-06 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:07:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:37:10 --> Total execution time: 0.0530
DEBUG - 2022-07-06 11:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:37:48 --> Total execution time: 0.1728
DEBUG - 2022-07-06 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:38:03 --> Total execution time: 0.0554
DEBUG - 2022-07-06 11:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:08:17 --> 404 Page Not Found: Category/health
DEBUG - 2022-07-06 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:38:54 --> Total execution time: 0.0637
DEBUG - 2022-07-06 11:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:08:55 --> Total execution time: 0.0706
DEBUG - 2022-07-06 11:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:38:57 --> Total execution time: 0.0722
DEBUG - 2022-07-06 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:38:59 --> Total execution time: 0.0485
DEBUG - 2022-07-06 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:09:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:39:18 --> Total execution time: 0.0660
DEBUG - 2022-07-06 11:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:10:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:40:34 --> Total execution time: 0.1368
DEBUG - 2022-07-06 11:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:10:36 --> 404 Page Not Found: Category/culture
DEBUG - 2022-07-06 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:41:12 --> Total execution time: 0.0446
DEBUG - 2022-07-06 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:41:13 --> Total execution time: 0.0556
DEBUG - 2022-07-06 11:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:41:19 --> Total execution time: 0.0553
DEBUG - 2022-07-06 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:41:27 --> Total execution time: 0.0597
DEBUG - 2022-07-06 11:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:11:57 --> Total execution time: 0.0600
DEBUG - 2022-07-06 11:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:12:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:12:05 --> Total execution time: 0.1534
DEBUG - 2022-07-06 11:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:42:16 --> Total execution time: 0.0631
DEBUG - 2022-07-06 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:12:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:42:54 --> Total execution time: 0.0804
DEBUG - 2022-07-06 11:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:43:05 --> Total execution time: 0.1336
DEBUG - 2022-07-06 11:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:13:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:43:12 --> Total execution time: 0.0459
DEBUG - 2022-07-06 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:43:23 --> Total execution time: 0.0502
DEBUG - 2022-07-06 11:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:13:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:43:28 --> Total execution time: 0.0523
DEBUG - 2022-07-06 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:31 --> Total execution time: 0.1005
DEBUG - 2022-07-06 11:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:34 --> Total execution time: 0.0553
DEBUG - 2022-07-06 11:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:38 --> Total execution time: 0.0528
DEBUG - 2022-07-06 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:40 --> Total execution time: 0.0937
DEBUG - 2022-07-06 11:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:45 --> Total execution time: 0.0572
DEBUG - 2022-07-06 11:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:52 --> Total execution time: 0.0544
DEBUG - 2022-07-06 11:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:14:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:58 --> Total execution time: 0.0639
DEBUG - 2022-07-06 11:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:10 --> Total execution time: 0.0591
DEBUG - 2022-07-06 11:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:28 --> Total execution time: 0.0569
DEBUG - 2022-07-06 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:33 --> Total execution time: 0.0881
DEBUG - 2022-07-06 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:35 --> Total execution time: 0.1238
DEBUG - 2022-07-06 11:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:44 --> Total execution time: 0.0536
DEBUG - 2022-07-06 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:44 --> Total execution time: 0.0791
DEBUG - 2022-07-06 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:45:52 --> Total execution time: 0.0545
DEBUG - 2022-07-06 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:15:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:15:53 --> Total execution time: 0.0533
DEBUG - 2022-07-06 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:46:00 --> Total execution time: 0.0820
DEBUG - 2022-07-06 11:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:46:03 --> Total execution time: 0.0593
DEBUG - 2022-07-06 11:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:46:05 --> Total execution time: 0.0574
DEBUG - 2022-07-06 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:05 --> Total execution time: 0.0530
DEBUG - 2022-07-06 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:46:05 --> Total execution time: 0.0625
DEBUG - 2022-07-06 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:33 --> Total execution time: 0.0502
DEBUG - 2022-07-06 11:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:38 --> Total execution time: 0.0479
DEBUG - 2022-07-06 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:16:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:16:56 --> Total execution time: 0.0494
DEBUG - 2022-07-06 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:05 --> Total execution time: 0.0498
DEBUG - 2022-07-06 11:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:07 --> Total execution time: 0.0517
DEBUG - 2022-07-06 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:09 --> Total execution time: 0.0492
DEBUG - 2022-07-06 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:10 --> Total execution time: 0.0832
DEBUG - 2022-07-06 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:10 --> Total execution time: 0.0841
DEBUG - 2022-07-06 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:38 --> Total execution time: 0.0859
DEBUG - 2022-07-06 11:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:42 --> Total execution time: 0.0802
DEBUG - 2022-07-06 11:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:44 --> Total execution time: 0.0811
DEBUG - 2022-07-06 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:46 --> Total execution time: 0.0898
DEBUG - 2022-07-06 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:46 --> Total execution time: 0.0525
DEBUG - 2022-07-06 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:46 --> Total execution time: 0.0515
DEBUG - 2022-07-06 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:55 --> Total execution time: 0.0475
DEBUG - 2022-07-06 11:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:17:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:59 --> Total execution time: 0.0495
DEBUG - 2022-07-06 11:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:18:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:48:21 --> Total execution time: 0.0515
DEBUG - 2022-07-06 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:49:15 --> Total execution time: 0.0871
DEBUG - 2022-07-06 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:19:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:49:25 --> Total execution time: 0.1090
DEBUG - 2022-07-06 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:49:32 --> Total execution time: 0.1276
DEBUG - 2022-07-06 11:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:07 --> Total execution time: 0.0512
DEBUG - 2022-07-06 11:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:10 --> Total execution time: 0.0431
DEBUG - 2022-07-06 11:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:26 --> Total execution time: 0.0517
DEBUG - 2022-07-06 11:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:31 --> Total execution time: 0.0468
DEBUG - 2022-07-06 11:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:36 --> Total execution time: 0.1253
DEBUG - 2022-07-06 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:45 --> Total execution time: 0.0536
DEBUG - 2022-07-06 11:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:20:52 --> Total execution time: 0.0503
DEBUG - 2022-07-06 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:54 --> Total execution time: 0.0650
DEBUG - 2022-07-06 11:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:20:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:50:58 --> Total execution time: 0.0675
DEBUG - 2022-07-06 11:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:09 --> Total execution time: 0.0602
DEBUG - 2022-07-06 11:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:16 --> Total execution time: 0.0523
DEBUG - 2022-07-06 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:22 --> Total execution time: 0.0528
DEBUG - 2022-07-06 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:23 --> Total execution time: 0.0681
DEBUG - 2022-07-06 11:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:30 --> Total execution time: 0.1902
DEBUG - 2022-07-06 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:51:58 --> Total execution time: 0.0568
DEBUG - 2022-07-06 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:11 --> Total execution time: 0.0825
DEBUG - 2022-07-06 11:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:15 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:15 --> Total execution time: 0.1410
DEBUG - 2022-07-06 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:18 --> Total execution time: 0.0574
DEBUG - 2022-07-06 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:21 --> Total execution time: 0.0543
DEBUG - 2022-07-06 11:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:24 --> Total execution time: 0.0619
DEBUG - 2022-07-06 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:26 --> Total execution time: 0.0563
DEBUG - 2022-07-06 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:29 --> Total execution time: 0.0632
DEBUG - 2022-07-06 11:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:45 --> Total execution time: 0.0577
DEBUG - 2022-07-06 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:22:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:52:48 --> Total execution time: 0.0776
DEBUG - 2022-07-06 11:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:13 --> Total execution time: 0.0607
DEBUG - 2022-07-06 11:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:16 --> Total execution time: 0.0667
DEBUG - 2022-07-06 11:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:21 --> Total execution time: 0.0694
DEBUG - 2022-07-06 11:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:25 --> Total execution time: 0.0538
DEBUG - 2022-07-06 11:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:27 --> Total execution time: 0.0690
DEBUG - 2022-07-06 11:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:30 --> Total execution time: 0.0619
DEBUG - 2022-07-06 11:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:33 --> Total execution time: 0.0624
DEBUG - 2022-07-06 11:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:53:36 --> Total execution time: 0.0625
DEBUG - 2022-07-06 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:24:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:54:02 --> Total execution time: 0.0725
DEBUG - 2022-07-06 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:54:37 --> Total execution time: 0.0573
DEBUG - 2022-07-06 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:54:41 --> Total execution time: 0.0693
DEBUG - 2022-07-06 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:54:44 --> Total execution time: 0.0594
DEBUG - 2022-07-06 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:54:46 --> Total execution time: 0.0536
DEBUG - 2022-07-06 11:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:55:00 --> Total execution time: 0.1084
DEBUG - 2022-07-06 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:25:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:55:03 --> Total execution time: 0.0562
DEBUG - 2022-07-06 11:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:25:11 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:25:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:55:11 --> Total execution time: 0.0608
DEBUG - 2022-07-06 11:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:56:12 --> Total execution time: 0.1339
DEBUG - 2022-07-06 11:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:56:18 --> Total execution time: 0.0555
DEBUG - 2022-07-06 11:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:56:24 --> Total execution time: 0.0545
DEBUG - 2022-07-06 11:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:56:55 --> Total execution time: 0.0588
DEBUG - 2022-07-06 11:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:56:59 --> Total execution time: 0.0549
DEBUG - 2022-07-06 11:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:06 --> Total execution time: 0.0721
DEBUG - 2022-07-06 11:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:07 --> Total execution time: 0.0724
DEBUG - 2022-07-06 11:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:15 --> Total execution time: 0.0681
DEBUG - 2022-07-06 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:18 --> Total execution time: 0.0556
DEBUG - 2022-07-06 11:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:27:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:27:56 --> 404 Page Not Found: Category/reviews
DEBUG - 2022-07-06 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:31:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:31:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:01:27 --> Total execution time: 0.0563
DEBUG - 2022-07-06 11:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:31:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:31:50 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 11:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:32:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:14 --> Total execution time: 0.0369
DEBUG - 2022-07-06 11:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:37 --> Total execution time: 0.0641
DEBUG - 2022-07-06 11:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:47 --> Total execution time: 0.0892
DEBUG - 2022-07-06 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:32:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:32:58 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 11:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:02 --> Total execution time: 0.0620
DEBUG - 2022-07-06 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:07 --> Total execution time: 0.0641
DEBUG - 2022-07-06 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:13 --> Total execution time: 0.0616
DEBUG - 2022-07-06 11:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:19 --> Total execution time: 0.0654
DEBUG - 2022-07-06 11:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:55 --> Total execution time: 0.0770
DEBUG - 2022-07-06 11:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:12 --> Total execution time: 0.0557
DEBUG - 2022-07-06 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:19 --> Total execution time: 0.1036
DEBUG - 2022-07-06 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:19 --> Total execution time: 0.0821
DEBUG - 2022-07-06 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:42 --> Total execution time: 0.0545
DEBUG - 2022-07-06 11:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:45 --> Total execution time: 0.1076
DEBUG - 2022-07-06 11:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:54 --> Total execution time: 0.0618
DEBUG - 2022-07-06 11:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:58 --> Total execution time: 0.1290
DEBUG - 2022-07-06 11:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:06 --> Total execution time: 0.2029
DEBUG - 2022-07-06 11:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:06 --> Total execution time: 0.1513
DEBUG - 2022-07-06 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:11 --> Total execution time: 0.1052
DEBUG - 2022-07-06 11:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:16 --> Total execution time: 0.0849
DEBUG - 2022-07-06 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:17 --> Total execution time: 0.0843
DEBUG - 2022-07-06 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:20 --> Total execution time: 0.0919
DEBUG - 2022-07-06 11:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:21 --> Total execution time: 0.0760
DEBUG - 2022-07-06 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:35:56 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 11:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:05:56 --> Total execution time: 0.1865
DEBUG - 2022-07-06 11:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:36:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:06:17 --> Total execution time: 0.1488
DEBUG - 2022-07-06 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:06:36 --> Total execution time: 0.2879
DEBUG - 2022-07-06 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:36:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:36:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:06:51 --> Total execution time: 0.0488
DEBUG - 2022-07-06 11:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:07:05 --> Total execution time: 0.0819
DEBUG - 2022-07-06 11:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:37:15 --> Total execution time: 0.0590
DEBUG - 2022-07-06 11:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:07:19 --> Total execution time: 0.0628
DEBUG - 2022-07-06 11:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:07:22 --> Total execution time: 0.0733
DEBUG - 2022-07-06 11:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:07:28 --> Total execution time: 0.0784
DEBUG - 2022-07-06 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:37:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:07:30 --> Total execution time: 0.0333
DEBUG - 2022-07-06 11:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:37:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 11:37:43 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 11:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:09:02 --> Total execution time: 0.1418
DEBUG - 2022-07-06 11:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:39:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:09:06 --> Total execution time: 0.0769
DEBUG - 2022-07-06 11:39:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:39:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:09:17 --> Total execution time: 0.0636
DEBUG - 2022-07-06 11:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:39:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:09:23 --> Total execution time: 0.0937
DEBUG - 2022-07-06 11:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:39:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:09:59 --> Total execution time: 0.0587
DEBUG - 2022-07-06 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:40:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:10:03 --> Total execution time: 0.0469
DEBUG - 2022-07-06 11:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:11:55 --> Total execution time: 0.0536
DEBUG - 2022-07-06 11:41:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:41:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:11:56 --> Total execution time: 0.0553
DEBUG - 2022-07-06 11:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:12:02 --> Total execution time: 0.1195
DEBUG - 2022-07-06 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:43:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:09 --> Total execution time: 0.1525
DEBUG - 2022-07-06 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:43:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:22 --> Total execution time: 0.0576
DEBUG - 2022-07-06 11:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:26 --> Total execution time: 0.0650
DEBUG - 2022-07-06 11:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:39 --> Total execution time: 0.1370
DEBUG - 2022-07-06 11:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:44:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:14:13 --> Total execution time: 0.0563
DEBUG - 2022-07-06 11:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:44:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:14:17 --> Total execution time: 0.0540
DEBUG - 2022-07-06 11:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:14:36 --> Total execution time: 0.0573
DEBUG - 2022-07-06 11:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:44:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:14:48 --> Total execution time: 0.0612
DEBUG - 2022-07-06 11:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:45:20 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:45:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:15:20 --> Total execution time: 0.0418
DEBUG - 2022-07-06 11:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:45:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:15:21 --> Total execution time: 0.0568
DEBUG - 2022-07-06 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:15:51 --> Total execution time: 0.0508
DEBUG - 2022-07-06 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:10 --> Total execution time: 0.1346
DEBUG - 2022-07-06 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:12 --> Total execution time: 0.0620
DEBUG - 2022-07-06 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:14 --> Total execution time: 0.0509
DEBUG - 2022-07-06 11:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:20 --> Total execution time: 0.0640
DEBUG - 2022-07-06 11:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:25 --> Total execution time: 0.0550
DEBUG - 2022-07-06 11:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:29 --> Total execution time: 0.0623
DEBUG - 2022-07-06 11:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:35 --> Total execution time: 0.0534
DEBUG - 2022-07-06 11:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:36 --> Total execution time: 0.0522
DEBUG - 2022-07-06 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:43 --> Total execution time: 0.0503
DEBUG - 2022-07-06 11:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:52 --> Total execution time: 0.0618
DEBUG - 2022-07-06 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:46:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:16:58 --> Total execution time: 0.0578
DEBUG - 2022-07-06 11:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:01 --> Total execution time: 0.0524
DEBUG - 2022-07-06 11:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:06 --> Total execution time: 0.0560
DEBUG - 2022-07-06 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:12 --> Total execution time: 0.1735
DEBUG - 2022-07-06 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:12 --> Total execution time: 0.0591
DEBUG - 2022-07-06 11:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:17 --> Total execution time: 0.0763
DEBUG - 2022-07-06 11:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:17:29 --> Total execution time: 0.0506
DEBUG - 2022-07-06 11:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:07 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:07 --> Total execution time: 0.0388
DEBUG - 2022-07-06 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:17 --> Total execution time: 0.0684
DEBUG - 2022-07-06 11:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:27 --> Total execution time: 0.0531
DEBUG - 2022-07-06 11:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:32 --> Total execution time: 0.0612
DEBUG - 2022-07-06 11:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:37 --> Total execution time: 0.0483
DEBUG - 2022-07-06 11:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:43 --> Total execution time: 0.0743
DEBUG - 2022-07-06 11:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:46 --> Total execution time: 0.0936
DEBUG - 2022-07-06 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:52 --> Total execution time: 0.0590
DEBUG - 2022-07-06 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:59 --> Total execution time: 0.0572
DEBUG - 2022-07-06 11:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:11 --> Total execution time: 0.0625
DEBUG - 2022-07-06 11:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:19 --> Total execution time: 0.1153
DEBUG - 2022-07-06 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:23 --> Total execution time: 0.0665
DEBUG - 2022-07-06 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:25 --> Total execution time: 0.0706
DEBUG - 2022-07-06 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:28 --> Total execution time: 0.0662
DEBUG - 2022-07-06 11:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:42 --> Total execution time: 0.0520
DEBUG - 2022-07-06 11:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:50 --> Total execution time: 0.0332
DEBUG - 2022-07-06 11:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:49:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:49:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:59 --> Total execution time: 0.0536
DEBUG - 2022-07-06 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:02 --> Total execution time: 0.0480
DEBUG - 2022-07-06 11:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:05 --> Total execution time: 0.0485
DEBUG - 2022-07-06 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:11 --> Total execution time: 0.0533
DEBUG - 2022-07-06 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:17 --> Total execution time: 0.0410
DEBUG - 2022-07-06 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:18 --> Total execution time: 0.0757
DEBUG - 2022-07-06 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:41 --> Total execution time: 0.1014
DEBUG - 2022-07-06 11:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:44 --> Total execution time: 0.0524
DEBUG - 2022-07-06 11:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:47 --> Total execution time: 0.0783
DEBUG - 2022-07-06 11:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:54 --> Total execution time: 0.1453
DEBUG - 2022-07-06 11:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:01 --> Total execution time: 0.0746
DEBUG - 2022-07-06 11:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:03 --> Total execution time: 0.0682
DEBUG - 2022-07-06 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:09 --> Total execution time: 0.0379
DEBUG - 2022-07-06 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:10 --> Total execution time: 0.1757
DEBUG - 2022-07-06 11:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:13 --> Total execution time: 0.0564
DEBUG - 2022-07-06 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:14 --> Total execution time: 0.0508
DEBUG - 2022-07-06 11:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:18 --> Total execution time: 0.0491
DEBUG - 2022-07-06 11:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:23 --> Total execution time: 0.0577
DEBUG - 2022-07-06 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:51:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:21:25 --> Total execution time: 0.1395
DEBUG - 2022-07-06 11:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:22:03 --> Total execution time: 0.0540
DEBUG - 2022-07-06 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:22:10 --> Total execution time: 0.0669
DEBUG - 2022-07-06 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:11 --> Total execution time: 0.0707
DEBUG - 2022-07-06 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:12 --> Total execution time: 0.0635
DEBUG - 2022-07-06 11:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:12 --> Total execution time: 0.0891
DEBUG - 2022-07-06 11:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:22:18 --> Total execution time: 0.0565
DEBUG - 2022-07-06 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:22:20 --> Total execution time: 0.0592
DEBUG - 2022-07-06 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:52:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:52:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:22:40 --> Total execution time: 0.0724
DEBUG - 2022-07-06 11:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:14 --> Total execution time: 0.0694
DEBUG - 2022-07-06 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:16 --> Total execution time: 0.0514
DEBUG - 2022-07-06 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:19 --> Total execution time: 0.0514
DEBUG - 2022-07-06 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:24 --> Total execution time: 0.0608
DEBUG - 2022-07-06 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:33 --> Total execution time: 0.0570
DEBUG - 2022-07-06 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:43 --> Total execution time: 0.0701
DEBUG - 2022-07-06 11:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:50 --> Total execution time: 0.0656
DEBUG - 2022-07-06 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:53:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:23:52 --> Total execution time: 0.0503
DEBUG - 2022-07-06 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:54:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:24:19 --> Total execution time: 0.0530
DEBUG - 2022-07-06 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:24:22 --> Total execution time: 0.0646
DEBUG - 2022-07-06 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:54:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:24:29 --> Total execution time: 0.0521
DEBUG - 2022-07-06 11:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:07 --> Total execution time: 0.0549
DEBUG - 2022-07-06 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:20 --> Total execution time: 0.0554
DEBUG - 2022-07-06 11:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:32 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:32 --> Total execution time: 0.0353
DEBUG - 2022-07-06 11:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:39 --> Total execution time: 0.0594
DEBUG - 2022-07-06 11:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:41 --> Total execution time: 0.0516
DEBUG - 2022-07-06 11:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:46 --> Total execution time: 0.1220
DEBUG - 2022-07-06 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:56:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:26:20 --> Total execution time: 0.0480
DEBUG - 2022-07-06 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:56:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:26:21 --> Total execution time: 0.0451
DEBUG - 2022-07-06 11:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:26:50 --> Total execution time: 0.0813
DEBUG - 2022-07-06 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:12 --> Total execution time: 0.1301
DEBUG - 2022-07-06 11:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:25 --> Total execution time: 0.0558
DEBUG - 2022-07-06 11:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:25 --> Total execution time: 0.0619
DEBUG - 2022-07-06 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:36 --> Total execution time: 0.0462
DEBUG - 2022-07-06 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 11:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:40 --> Total execution time: 0.1335
DEBUG - 2022-07-06 11:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:43 --> Total execution time: 0.0508
DEBUG - 2022-07-06 11:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:46 --> Total execution time: 0.0483
DEBUG - 2022-07-06 11:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:51 --> Total execution time: 0.0617
DEBUG - 2022-07-06 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:57 --> Total execution time: 0.0573
DEBUG - 2022-07-06 11:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:10 --> Total execution time: 0.0520
DEBUG - 2022-07-06 11:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 11:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:12 --> Total execution time: 0.0514
DEBUG - 2022-07-06 11:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:19 --> Total execution time: 0.0833
DEBUG - 2022-07-06 11:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:21 --> Total execution time: 0.0551
DEBUG - 2022-07-06 11:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:41 --> Total execution time: 0.0517
DEBUG - 2022-07-06 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 11:59:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:29:47 --> Total execution time: 0.0563
DEBUG - 2022-07-06 12:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:03 --> Total execution time: 0.0593
DEBUG - 2022-07-06 12:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:12 --> Total execution time: 0.0568
DEBUG - 2022-07-06 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:14 --> Total execution time: 0.0889
DEBUG - 2022-07-06 12:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:19 --> Total execution time: 0.1128
DEBUG - 2022-07-06 12:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:30 --> Total execution time: 0.0563
DEBUG - 2022-07-06 12:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:43 --> Total execution time: 0.1154
DEBUG - 2022-07-06 12:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:45 --> Total execution time: 0.0699
DEBUG - 2022-07-06 12:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:49 --> Total execution time: 0.0809
DEBUG - 2022-07-06 12:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:30:58 --> Total execution time: 0.0599
DEBUG - 2022-07-06 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:00 --> Total execution time: 0.0475
DEBUG - 2022-07-06 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:01 --> Total execution time: 0.0503
DEBUG - 2022-07-06 12:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:01 --> Total execution time: 0.3549
DEBUG - 2022-07-06 12:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:08 --> Total execution time: 0.0727
DEBUG - 2022-07-06 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:10 --> Total execution time: 0.0489
DEBUG - 2022-07-06 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:10 --> Total execution time: 0.0489
DEBUG - 2022-07-06 12:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:12 --> Total execution time: 0.0590
DEBUG - 2022-07-06 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:19 --> Total execution time: 0.0556
DEBUG - 2022-07-06 12:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:24 --> Total execution time: 0.0534
DEBUG - 2022-07-06 12:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:31 --> Total execution time: 0.0751
DEBUG - 2022-07-06 12:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:36 --> Total execution time: 0.0369
DEBUG - 2022-07-06 12:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:44 --> Total execution time: 0.0477
DEBUG - 2022-07-06 12:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:46 --> Total execution time: 0.0536
DEBUG - 2022-07-06 12:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:47 --> Total execution time: 0.0487
DEBUG - 2022-07-06 12:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:48 --> Total execution time: 0.0465
DEBUG - 2022-07-06 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:51 --> Total execution time: 0.0484
DEBUG - 2022-07-06 12:01:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:01:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:53 --> Total execution time: 0.0475
DEBUG - 2022-07-06 12:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:57 --> Total execution time: 0.0695
DEBUG - 2022-07-06 12:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:31:59 --> Total execution time: 0.0486
DEBUG - 2022-07-06 12:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:32:23 --> Total execution time: 0.1151
DEBUG - 2022-07-06 12:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:02:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:32:38 --> Total execution time: 0.0566
DEBUG - 2022-07-06 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:34:01 --> Total execution time: 0.0515
DEBUG - 2022-07-06 12:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:04:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:34:22 --> Total execution time: 0.0618
DEBUG - 2022-07-06 12:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:34:31 --> Total execution time: 0.0565
DEBUG - 2022-07-06 12:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:04:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:34:37 --> Total execution time: 0.0490
DEBUG - 2022-07-06 12:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:34:53 --> Total execution time: 0.0553
DEBUG - 2022-07-06 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:35:05 --> Total execution time: 0.0959
DEBUG - 2022-07-06 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:35:27 --> Total execution time: 0.0610
DEBUG - 2022-07-06 12:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:35:52 --> Total execution time: 0.0694
DEBUG - 2022-07-06 12:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:35:56 --> Total execution time: 0.0513
DEBUG - 2022-07-06 12:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:36:06 --> Total execution time: 0.0597
DEBUG - 2022-07-06 12:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:36:10 --> Total execution time: 0.1481
DEBUG - 2022-07-06 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:36:20 --> Total execution time: 0.0758
DEBUG - 2022-07-06 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:40:25 --> Total execution time: 0.1342
DEBUG - 2022-07-06 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:00 --> Total execution time: 0.1404
DEBUG - 2022-07-06 12:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:04 --> Total execution time: 0.0568
DEBUG - 2022-07-06 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:13 --> Total execution time: 0.0556
DEBUG - 2022-07-06 12:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:16 --> Total execution time: 0.0524
DEBUG - 2022-07-06 12:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:19 --> Total execution time: 0.0803
DEBUG - 2022-07-06 12:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:19 --> Total execution time: 0.0687
DEBUG - 2022-07-06 12:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:12:28 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-06 12:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:12:29 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 12:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:32 --> Total execution time: 0.0880
DEBUG - 2022-07-06 12:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:12:38 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-06 12:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:12:41 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-06 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:42 --> Total execution time: 0.0402
DEBUG - 2022-07-06 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:43 --> Total execution time: 0.1444
DEBUG - 2022-07-06 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:12:52 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-06 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:13:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:43:14 --> Total execution time: 0.0791
DEBUG - 2022-07-06 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:13:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:13:37 --> 404 Page Not Found: My-account-2/index
DEBUG - 2022-07-06 12:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:46:38 --> Total execution time: 0.1445
DEBUG - 2022-07-06 12:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:16:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:46:41 --> Total execution time: 0.0756
DEBUG - 2022-07-06 12:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:22:24 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:22:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:24 --> Total execution time: 0.1118
DEBUG - 2022-07-06 12:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:22:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:22:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:58 --> Total execution time: 0.0374
DEBUG - 2022-07-06 12:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:56:00 --> Total execution time: 0.0395
DEBUG - 2022-07-06 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:26:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:56:04 --> Total execution time: 0.0569
DEBUG - 2022-07-06 12:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:28:50 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:58:50 --> Total execution time: 0.0676
DEBUG - 2022-07-06 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:31:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:31:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:01:29 --> Total execution time: 0.2107
DEBUG - 2022-07-06 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:31:54 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:01:54 --> Total execution time: 0.0583
DEBUG - 2022-07-06 12:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:02:49 --> Total execution time: 0.0726
DEBUG - 2022-07-06 12:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:32:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:02:53 --> Total execution time: 0.0508
DEBUG - 2022-07-06 12:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:33:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:03:08 --> Total execution time: 0.0667
DEBUG - 2022-07-06 12:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:33:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:03:12 --> Total execution time: 0.0684
DEBUG - 2022-07-06 12:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:16 --> Total execution time: 0.2139
DEBUG - 2022-07-06 12:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:32 --> Total execution time: 0.0729
DEBUG - 2022-07-06 12:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:40 --> Total execution time: 0.0531
DEBUG - 2022-07-06 12:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:49 --> Total execution time: 0.0587
DEBUG - 2022-07-06 12:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:07:08 --> Total execution time: 0.0614
DEBUG - 2022-07-06 12:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:07:23 --> Total execution time: 0.1084
DEBUG - 2022-07-06 12:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:37:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:07:49 --> Total execution time: 0.0496
DEBUG - 2022-07-06 12:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:28 --> Total execution time: 0.0625
DEBUG - 2022-07-06 12:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 12:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:29 --> Total execution time: 0.0333
DEBUG - 2022-07-06 12:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:34 --> Total execution time: 0.0489
DEBUG - 2022-07-06 12:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:50 --> Total execution time: 0.0598
DEBUG - 2022-07-06 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:39:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:54 --> Total execution time: 0.0521
DEBUG - 2022-07-06 12:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:40:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:10:02 --> Total execution time: 0.0846
DEBUG - 2022-07-06 12:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:40:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:10:06 --> Total execution time: 0.0929
DEBUG - 2022-07-06 12:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:10:12 --> Total execution time: 0.0670
DEBUG - 2022-07-06 12:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:40:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:10:27 --> Total execution time: 0.0822
DEBUG - 2022-07-06 12:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:26 --> Total execution time: 0.2366
DEBUG - 2022-07-06 12:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:53 --> Total execution time: 0.0783
DEBUG - 2022-07-06 12:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:57 --> Total execution time: 0.0707
DEBUG - 2022-07-06 12:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:12:27 --> Total execution time: 0.0505
DEBUG - 2022-07-06 12:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:46:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:46:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:16:16 --> Total execution time: 0.0792
DEBUG - 2022-07-06 12:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:46:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:16:48 --> Total execution time: 0.1673
DEBUG - 2022-07-06 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:46:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:16:54 --> Total execution time: 0.0738
DEBUG - 2022-07-06 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:47:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:17:03 --> Total execution time: 0.2792
DEBUG - 2022-07-06 12:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:48:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:18:05 --> Total execution time: 0.0548
DEBUG - 2022-07-06 12:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:22:15 --> Total execution time: 0.0561
DEBUG - 2022-07-06 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:22:22 --> Total execution time: 0.0567
DEBUG - 2022-07-06 12:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:22:32 --> Total execution time: 0.0575
DEBUG - 2022-07-06 12:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:34 --> Total execution time: 0.0568
DEBUG - 2022-07-06 12:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:37 --> Total execution time: 0.0545
DEBUG - 2022-07-06 12:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:59 --> Total execution time: 0.1418
DEBUG - 2022-07-06 12:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:56:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 12:56:07 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-06 12:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 12:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 12:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:29:13 --> Total execution time: 0.1926
DEBUG - 2022-07-06 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:30:02 --> Total execution time: 0.0472
DEBUG - 2022-07-06 13:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:00:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:30:51 --> Total execution time: 0.0584
DEBUG - 2022-07-06 13:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:00 --> Total execution time: 0.0364
DEBUG - 2022-07-06 13:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:11 --> Total execution time: 0.0675
DEBUG - 2022-07-06 13:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:23 --> Total execution time: 0.0754
DEBUG - 2022-07-06 13:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:24 --> Total execution time: 0.0549
DEBUG - 2022-07-06 13:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:34 --> Total execution time: 0.0631
DEBUG - 2022-07-06 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:10:37 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:37 --> Total execution time: 0.1518
DEBUG - 2022-07-06 13:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:05 --> Total execution time: 0.0440
DEBUG - 2022-07-06 13:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:11 --> Total execution time: 0.0839
DEBUG - 2022-07-06 13:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:17 --> Total execution time: 0.0395
DEBUG - 2022-07-06 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:18 --> Total execution time: 0.0689
DEBUG - 2022-07-06 13:11:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:18 --> Total execution time: 0.1371
DEBUG - 2022-07-06 13:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:21 --> Total execution time: 0.0829
DEBUG - 2022-07-06 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:26 --> Total execution time: 0.0734
DEBUG - 2022-07-06 13:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:28 --> Total execution time: 0.0521
DEBUG - 2022-07-06 13:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:43 --> Total execution time: 0.0618
DEBUG - 2022-07-06 13:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:44 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:44 --> Total execution time: 0.0692
DEBUG - 2022-07-06 13:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:11:59 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 13:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:42:01 --> Total execution time: 0.0500
DEBUG - 2022-07-06 23:42:02 --> Total execution time: 2.0028
DEBUG - 2022-07-06 13:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:12:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 13:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:42:23 --> Total execution time: 0.0530
DEBUG - 2022-07-06 13:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:37 --> Total execution time: 0.0497
DEBUG - 2022-07-06 13:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:42 --> Total execution time: 0.0512
DEBUG - 2022-07-06 13:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:47 --> Total execution time: 0.0497
DEBUG - 2022-07-06 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:12:55 --> Total execution time: 0.0516
DEBUG - 2022-07-06 13:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:13:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:13:04 --> 404 Page Not Found: Category/uncategorized
DEBUG - 2022-07-06 13:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:16:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:16:04 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 13:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:18:43 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:20:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:50:29 --> Total execution time: 0.0924
DEBUG - 2022-07-06 13:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:20:53 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 13:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:52:52 --> Total execution time: 0.1246
DEBUG - 2022-07-06 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:26:35 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:26:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:56:35 --> Total execution time: 0.1047
DEBUG - 2022-07-06 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:30:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:30:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:33:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:35:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:35:15 --> 404 Page Not Found: Affiliate-account-page/index
DEBUG - 2022-07-06 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:35:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:36:34 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:36:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:36:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:08 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:43:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:45:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 13:45:35 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 13:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 13:45:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 13:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 13:45:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:01:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:01:03 --> 404 Page Not Found: Category/world
DEBUG - 2022-07-06 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:06:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:06:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:06:53 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:07:48 --> 404 Page Not Found: 400shtml/index
DEBUG - 2022-07-06 14:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:52 --> Total execution time: 0.0624
DEBUG - 2022-07-06 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:54 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:07:55 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:08:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:08:07 --> 404 Page Not Found: Util/login.aspx
DEBUG - 2022-07-06 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:08:07 --> 404 Page Not Found: Magento_version/index
DEBUG - 2022-07-06 14:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:08:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:08:07 --> 404 Page Not Found: Installphp/index
DEBUG - 2022-07-06 14:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:10:30 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 14:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:14:48 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 14:18:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:18:09 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:21:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:21:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:22:25 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:22:49 --> 404 Page Not Found: Category/news
DEBUG - 2022-07-06 14:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:24:21 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:26:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:26:12 --> 404 Page Not Found: News/feed
DEBUG - 2022-07-06 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:29:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:33:04 --> 404 Page Not Found: Appphp/feed
DEBUG - 2022-07-06 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:38:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:39:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:40:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:41:41 --> 404 Page Not Found: Blog/feed
DEBUG - 2022-07-06 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:46:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 14:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 14:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 14:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:49:11 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-07-06 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 14:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 14:54:08 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-07-06 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:00:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:00:24 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:03:05 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 15:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:04:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 15:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:05:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:05:18 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 15:10:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:21:46 --> 404 Page Not Found: Category/opinion
DEBUG - 2022-07-06 15:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:28:36 --> 404 Page Not Found: Category/lifestyle
DEBUG - 2022-07-06 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:30:05 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:31:56 --> 404 Page Not Found: Webgility/upgrade.php
DEBUG - 2022-07-06 15:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:38:07 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 15:38:13 --> 404 Page Not Found: Category/technology
DEBUG - 2022-07-06 15:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:38:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:38:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:38:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:39:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:39:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:42:33 --> Total execution time: 0.1486
DEBUG - 2022-07-06 15:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:42:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:42:40 --> Total execution time: 0.1148
DEBUG - 2022-07-06 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:44:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:46:20 --> Total execution time: 0.0509
DEBUG - 2022-07-06 15:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:46:42 --> Total execution time: 0.0688
DEBUG - 2022-07-06 15:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:49:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:49:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 15:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:50:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 15:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 15:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 15:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:29:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 16:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 16:31:43 --> 404 Page Not Found: Category/features
DEBUG - 2022-07-06 16:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:46:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 16:46:01 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 16:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:46:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 16:48:41 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 16:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 16:51:10 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 16:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:56:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 16:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 16:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 16:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 16:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 16:56:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:00:13 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:00:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:00:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:02:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:02:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:02:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:04:23 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:04:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:04:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:07:11 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:07:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:09:28 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:09:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:09:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:09:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:11:52 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:11:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:11:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:14:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:14:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:14:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:16:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:16:22 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 17:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:17:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:17:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 17:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:35:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 17:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 17:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 17:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 17:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 17:56:26 --> 404 Page Not Found: Membership-account/your-profile
DEBUG - 2022-07-06 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:30 --> No URI present. Default controller set.
DEBUG - 2022-07-06 18:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 18:31:03 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 18:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:33:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 18:33:45 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:34:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:35:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 18:35:58 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 18:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:50:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 18:50:59 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-06 18:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:56:51 --> No URI present. Default controller set.
DEBUG - 2022-07-06 18:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:56:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 18:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 18:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 18:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:00:36 --> No URI present. Default controller set.
DEBUG - 2022-07-06 19:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:00:52 --> 404 Page Not Found: Kcfinder/upload.php
DEBUG - 2022-07-06 19:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:11 --> 404 Page Not Found: Asset/kcfinder
DEBUG - 2022-07-06 19:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:21 --> 404 Page Not Found: Assets/kcfinder
DEBUG - 2022-07-06 19:01:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:33 --> 404 Page Not Found: Js/kcfinder
DEBUG - 2022-07-06 19:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:39 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 19:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:45 --> 404 Page Not Found: Assets/js
DEBUG - 2022-07-06 19:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:01:58 --> 404 Page Not Found: Assets/plugins
DEBUG - 2022-07-06 19:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:03:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:03:50 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-06 19:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:18:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:45:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:45:39 --> 404 Page Not Found: Wp-content/cache.php
DEBUG - 2022-07-06 19:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:49:20 --> No URI present. Default controller set.
DEBUG - 2022-07-06 19:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 19:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 19:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 19:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 19:50:52 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-07-06 20:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 20:18:04 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 20:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 20:20:52 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 20:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 20:21:59 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-07-06 20:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:23:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 20:23:14 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 20:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:32:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 20:48:56 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 20:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:57:19 --> No URI present. Default controller set.
DEBUG - 2022-07-06 20:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:57:56 --> Total execution time: 0.1294
DEBUG - 2022-07-06 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:57:57 --> Total execution time: 0.0606
DEBUG - 2022-07-06 20:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 20:57:58 --> Total execution time: 0.1204
DEBUG - 2022-07-06 20:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 20:58:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 20:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 20:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:00:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:06:14 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:06:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 21:06:15 --> 404 Page Not Found: Apple-touch-iconpng/index
DEBUG - 2022-07-06 21:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:20 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:10:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:11:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:19:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:20:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:24:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:39 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:25:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:26:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:27:31 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:30:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:30:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:31:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:44:12 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:44:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:40 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:47:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:47:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 21:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 21:57:48 --> No URI present. Default controller set.
DEBUG - 2022-07-06 21:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 21:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:35 --> Total execution time: 0.0908
DEBUG - 2022-07-06 22:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:37 --> Total execution time: 0.0513
DEBUG - 2022-07-06 22:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:37 --> Total execution time: 0.1450
DEBUG - 2022-07-06 22:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:03:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:04:26 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:06:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:06:00 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 22:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:08:41 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 22:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:10:58 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 22:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:12:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:12:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:05 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:16 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:13:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:15:59 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:15:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:19:45 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 22:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:46 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:19:48 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:20:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:20:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:20:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:35:53 --> 404 Page Not Found: Feed/index
DEBUG - 2022-07-06 22:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:36:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:36:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:37:58 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:38:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:38:22 --> Total execution time: 0.0557
DEBUG - 2022-07-06 22:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:38:27 --> Total execution time: 0.0551
DEBUG - 2022-07-06 22:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:38:27 --> Total execution time: 0.1174
DEBUG - 2022-07-06 22:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:41:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:41:35 --> Total execution time: 0.0503
DEBUG - 2022-07-06 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:04 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 22:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:42:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:42:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 22:42:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-07-06 22:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:42:47 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:42:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:42:59 --> Total execution time: 0.0534
DEBUG - 2022-07-06 22:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:44:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:44:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:45:41 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:51:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:51:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:52:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:52:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:53:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:54:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:54:56 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:57:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 22:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:57:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 22:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 22:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 22:59:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:06:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:06:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:07:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:09:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:11:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:11:25 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:11:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:11:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:23:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:23:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:23:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:25:42 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:25:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:00 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:20 --> Total execution time: 0.0725
DEBUG - 2022-07-06 23:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:22 --> Total execution time: 0.0555
DEBUG - 2022-07-06 23:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:22 --> Total execution time: 0.1384
DEBUG - 2022-07-06 23:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:38 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:27 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:29 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:40 --> Total execution time: 0.0834
DEBUG - 2022-07-06 23:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:28:58 --> Total execution time: 0.0720
DEBUG - 2022-07-06 23:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:28:58 --> Total execution time: 0.0697
DEBUG - 2022-07-06 23:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:29:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:30:54 --> Email class already loaded. Second attempt ignored.
DEBUG - 2022-07-06 23:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:30:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:02 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:33:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:34:23 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:35:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:37:45 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:37:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:04 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:17 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:40:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:42:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:43:01 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:43:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:43:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:44:57 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:44:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:48:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 23:48:21 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 23:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 23:48:22 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-07-06 23:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:48:22 --> No URI present. Default controller set.
DEBUG - 2022-07-06 23:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:48:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:51:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 23:51:04 --> 404 Page Not Found: Author/admin
DEBUG - 2022-07-06 23:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 23:53:46 --> 404 Page Not Found: Feed/atom
DEBUG - 2022-07-06 23:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:56:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-06 23:56:03 --> 404 Page Not Found: Category/business
DEBUG - 2022-07-06 23:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-07-06 23:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-06 23:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-06 23:59:58 --> Encryption: Auto-configured driver 'openssl'.
