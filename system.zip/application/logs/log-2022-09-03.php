<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-09-03 00:00:52 --> Total execution time: 0.1522
DEBUG - 2022-09-03 00:02:19 --> Total execution time: 0.0641
DEBUG - 2022-09-03 00:05:22 --> Total execution time: 0.1552
DEBUG - 2022-09-03 00:12:16 --> Total execution time: 0.1470
DEBUG - 2022-09-03 00:20:09 --> Total execution time: 0.3208
DEBUG - 2022-09-03 00:20:28 --> Total execution time: 0.1073
DEBUG - 2022-09-03 00:30:03 --> Total execution time: 0.2395
DEBUG - 2022-09-03 00:53:56 --> Total execution time: 0.1801
DEBUG - 2022-09-03 01:04:28 --> Total execution time: 0.1342
DEBUG - 2022-09-03 01:13:53 --> Total execution time: 0.1344
DEBUG - 2022-09-03 01:14:08 --> Total execution time: 0.0968
DEBUG - 2022-09-03 01:15:44 --> Total execution time: 0.0858
DEBUG - 2022-09-03 01:17:21 --> Total execution time: 0.0614
DEBUG - 2022-09-03 01:18:29 --> Total execution time: 0.1170
DEBUG - 2022-09-03 01:30:03 --> Total execution time: 0.2036
DEBUG - 2022-09-03 01:33:15 --> Total execution time: 0.0915
DEBUG - 2022-09-03 01:33:24 --> Total execution time: 0.1360
DEBUG - 2022-09-03 01:45:23 --> Total execution time: 0.1697
DEBUG - 2022-09-03 01:54:58 --> Total execution time: 0.1306
DEBUG - 2022-09-03 01:56:21 --> Total execution time: 0.0572
DEBUG - 2022-09-03 02:20:53 --> Total execution time: 0.1093
DEBUG - 2022-09-03 02:30:03 --> Total execution time: 0.1382
DEBUG - 2022-09-03 02:35:13 --> Total execution time: 0.3305
DEBUG - 2022-09-03 02:44:31 --> Total execution time: 0.3065
DEBUG - 2022-09-03 02:50:46 --> Total execution time: 0.3422
DEBUG - 2022-09-03 02:50:48 --> Total execution time: 0.1118
DEBUG - 2022-09-03 03:30:03 --> Total execution time: 0.3555
DEBUG - 2022-09-03 03:40:48 --> Total execution time: 0.1287
DEBUG - 2022-09-03 04:03:23 --> Total execution time: 0.2745
DEBUG - 2022-09-03 04:05:25 --> Total execution time: 0.0703
DEBUG - 2022-09-03 04:25:52 --> Total execution time: 0.1378
DEBUG - 2022-09-03 04:30:02 --> Total execution time: 0.1595
DEBUG - 2022-09-03 04:30:53 --> Total execution time: 0.0716
DEBUG - 2022-09-03 04:31:01 --> Total execution time: 0.0888
DEBUG - 2022-09-03 04:31:19 --> Total execution time: 0.1130
DEBUG - 2022-09-03 04:31:28 --> Total execution time: 0.1125
DEBUG - 2022-09-03 04:31:36 --> Total execution time: 0.0965
DEBUG - 2022-09-03 04:31:41 --> Total execution time: 0.1298
DEBUG - 2022-09-03 04:31:51 --> Total execution time: 0.1062
DEBUG - 2022-09-03 04:31:55 --> Total execution time: 0.1081
DEBUG - 2022-09-03 04:44:08 --> Total execution time: 0.0939
DEBUG - 2022-09-03 04:45:46 --> Total execution time: 0.2574
DEBUG - 2022-09-03 04:45:54 --> Total execution time: 0.1230
DEBUG - 2022-09-03 04:49:46 --> Total execution time: 0.1763
DEBUG - 2022-09-03 04:49:48 --> Total execution time: 0.1268
DEBUG - 2022-09-03 04:49:55 --> Total execution time: 0.0938
DEBUG - 2022-09-03 04:50:03 --> Total execution time: 0.0983
DEBUG - 2022-09-03 04:51:09 --> Total execution time: 0.0933
DEBUG - 2022-09-03 04:55:48 --> Total execution time: 0.1487
DEBUG - 2022-09-03 04:55:52 --> Total execution time: 0.1095
DEBUG - 2022-09-03 05:02:32 --> Total execution time: 0.1165
DEBUG - 2022-09-03 05:02:34 --> Total execution time: 0.0908
DEBUG - 2022-09-03 05:02:42 --> Total execution time: 0.0960
DEBUG - 2022-09-03 05:02:44 --> Total execution time: 0.0934
DEBUG - 2022-09-03 05:09:21 --> Total execution time: 0.1568
DEBUG - 2022-09-03 05:09:33 --> Total execution time: 0.1014
DEBUG - 2022-09-03 05:09:34 --> Total execution time: 0.0890
DEBUG - 2022-09-03 05:09:47 --> Total execution time: 0.0955
DEBUG - 2022-09-03 05:09:48 --> Total execution time: 0.0938
DEBUG - 2022-09-03 05:19:18 --> Total execution time: 0.3662
DEBUG - 2022-09-03 05:19:19 --> Total execution time: 0.1178
DEBUG - 2022-09-03 05:19:28 --> Total execution time: 0.0979
DEBUG - 2022-09-03 05:19:32 --> Total execution time: 0.1043
DEBUG - 2022-09-03 05:19:33 --> Total execution time: 0.0616
DEBUG - 2022-09-03 05:19:42 --> Total execution time: 0.0913
DEBUG - 2022-09-03 05:19:42 --> Total execution time: 0.0876
DEBUG - 2022-09-03 05:19:46 --> Total execution time: 0.1000
DEBUG - 2022-09-03 05:19:48 --> Total execution time: 0.1231
DEBUG - 2022-09-03 05:19:49 --> Total execution time: 0.1031
DEBUG - 2022-09-03 05:20:00 --> Total execution time: 0.0912
DEBUG - 2022-09-03 05:20:13 --> Total execution time: 0.1200
DEBUG - 2022-09-03 05:20:47 --> Total execution time: 0.1243
DEBUG - 2022-09-03 05:20:57 --> Total execution time: 0.0998
DEBUG - 2022-09-03 05:21:03 --> Total execution time: 0.0973
DEBUG - 2022-09-03 05:27:06 --> Total execution time: 0.1310
DEBUG - 2022-09-03 05:30:03 --> Total execution time: 0.1145
DEBUG - 2022-09-03 05:43:45 --> Total execution time: 0.1506
DEBUG - 2022-09-03 05:44:23 --> Total execution time: 0.0598
DEBUG - 2022-09-03 05:44:25 --> Total execution time: 0.0615
DEBUG - 2022-09-03 05:45:10 --> Total execution time: 0.1105
DEBUG - 2022-09-03 05:49:18 --> Total execution time: 0.1098
DEBUG - 2022-09-03 05:53:23 --> Total execution time: 0.1088
DEBUG - 2022-09-03 05:53:48 --> Total execution time: 0.1003
DEBUG - 2022-09-03 05:53:59 --> Total execution time: 0.1106
DEBUG - 2022-09-03 05:54:16 --> Total execution time: 0.1169
DEBUG - 2022-09-03 05:54:31 --> Total execution time: 0.0986
DEBUG - 2022-09-03 05:54:42 --> Total execution time: 0.0922
DEBUG - 2022-09-03 05:54:48 --> Total execution time: 0.0947
DEBUG - 2022-09-03 05:54:56 --> Total execution time: 0.0916
DEBUG - 2022-09-03 05:55:23 --> Total execution time: 0.0605
DEBUG - 2022-09-03 05:55:41 --> Total execution time: 0.0585
DEBUG - 2022-09-03 05:55:45 --> Total execution time: 0.0586
DEBUG - 2022-09-03 05:55:46 --> Total execution time: 0.0519
DEBUG - 2022-09-03 05:55:55 --> Total execution time: 0.0590
DEBUG - 2022-09-03 05:56:44 --> Total execution time: 0.0954
DEBUG - 2022-09-03 05:56:50 --> Total execution time: 0.0912
DEBUG - 2022-09-03 05:57:02 --> Total execution time: 0.0932
DEBUG - 2022-09-03 05:57:08 --> Total execution time: 0.1411
DEBUG - 2022-09-03 05:57:16 --> Total execution time: 0.0935
DEBUG - 2022-09-03 05:57:24 --> Total execution time: 0.0995
DEBUG - 2022-09-03 05:57:47 --> Total execution time: 0.0974
DEBUG - 2022-09-03 05:59:29 --> Total execution time: 0.0625
DEBUG - 2022-09-03 06:00:04 --> Total execution time: 0.0684
DEBUG - 2022-09-03 06:00:15 --> Total execution time: 0.0965
DEBUG - 2022-09-03 06:00:34 --> Total execution time: 0.1051
DEBUG - 2022-09-03 06:02:19 --> Total execution time: 0.0953
DEBUG - 2022-09-03 06:02:46 --> Total execution time: 0.0652
DEBUG - 2022-09-03 06:02:48 --> Total execution time: 0.0997
DEBUG - 2022-09-03 06:04:37 --> Total execution time: 0.0611
DEBUG - 2022-09-03 06:04:40 --> Total execution time: 0.2899
DEBUG - 2022-09-03 06:05:04 --> Total execution time: 0.0947
DEBUG - 2022-09-03 06:11:20 --> Total execution time: 0.1038
DEBUG - 2022-09-03 06:18:38 --> Total execution time: 0.1063
DEBUG - 2022-09-03 06:21:09 --> Total execution time: 0.3246
DEBUG - 2022-09-03 06:21:19 --> Total execution time: 0.1113
DEBUG - 2022-09-03 06:21:29 --> Total execution time: 0.1042
DEBUG - 2022-09-03 06:21:38 --> Total execution time: 0.0984
DEBUG - 2022-09-03 06:21:45 --> Total execution time: 0.1021
DEBUG - 2022-09-03 06:21:53 --> Total execution time: 0.1026
DEBUG - 2022-09-03 06:21:56 --> Total execution time: 0.1009
DEBUG - 2022-09-03 06:21:59 --> Total execution time: 0.0971
DEBUG - 2022-09-03 06:22:05 --> Total execution time: 0.1235
DEBUG - 2022-09-03 06:22:29 --> Total execution time: 0.1236
DEBUG - 2022-09-03 06:22:31 --> Total execution time: 0.0975
DEBUG - 2022-09-03 06:22:51 --> Total execution time: 0.1201
DEBUG - 2022-09-03 06:22:52 --> Total execution time: 0.1148
DEBUG - 2022-09-03 06:22:56 --> Total execution time: 0.1035
DEBUG - 2022-09-03 06:22:59 --> Total execution time: 0.0966
DEBUG - 2022-09-03 06:23:00 --> Total execution time: 0.1031
DEBUG - 2022-09-03 06:23:16 --> Total execution time: 0.1016
DEBUG - 2022-09-03 06:23:19 --> Total execution time: 0.0976
DEBUG - 2022-09-03 06:23:27 --> Total execution time: 0.1197
DEBUG - 2022-09-03 06:23:33 --> Total execution time: 0.0997
DEBUG - 2022-09-03 06:23:34 --> Total execution time: 0.0976
DEBUG - 2022-09-03 06:23:35 --> Total execution time: 0.0958
DEBUG - 2022-09-03 06:23:40 --> Total execution time: 0.1713
DEBUG - 2022-09-03 06:23:43 --> Total execution time: 0.1100
DEBUG - 2022-09-03 06:23:46 --> Total execution time: 0.0998
DEBUG - 2022-09-03 06:23:50 --> Total execution time: 0.0942
DEBUG - 2022-09-03 06:23:56 --> Total execution time: 0.1397
DEBUG - 2022-09-03 06:24:15 --> Total execution time: 0.1328
DEBUG - 2022-09-03 06:24:21 --> Total execution time: 0.0940
DEBUG - 2022-09-03 06:24:22 --> Total execution time: 0.0979
DEBUG - 2022-09-03 06:24:26 --> Total execution time: 0.0995
DEBUG - 2022-09-03 06:24:31 --> Total execution time: 0.0942
DEBUG - 2022-09-03 06:24:40 --> Total execution time: 0.0982
DEBUG - 2022-09-03 06:24:47 --> Total execution time: 0.0963
DEBUG - 2022-09-03 06:24:51 --> Total execution time: 0.0608
DEBUG - 2022-09-03 06:25:26 --> Total execution time: 0.0616
DEBUG - 2022-09-03 06:28:35 --> Total execution time: 0.1229
DEBUG - 2022-09-03 06:28:35 --> Total execution time: 0.0878
DEBUG - 2022-09-03 06:28:48 --> Total execution time: 0.0622
DEBUG - 2022-09-03 06:28:49 --> Total execution time: 0.0567
DEBUG - 2022-09-03 06:29:36 --> Total execution time: 0.2531
DEBUG - 2022-09-03 06:29:53 --> Total execution time: 0.1170
DEBUG - 2022-09-03 06:30:02 --> Total execution time: 0.0957
DEBUG - 2022-09-03 06:30:02 --> Total execution time: 0.1463
DEBUG - 2022-09-03 06:30:12 --> Total execution time: 0.1589
DEBUG - 2022-09-03 06:30:14 --> Total execution time: 0.1042
DEBUG - 2022-09-03 06:30:15 --> Total execution time: 0.1375
DEBUG - 2022-09-03 06:30:30 --> Total execution time: 0.2442
DEBUG - 2022-09-03 06:34:24 --> Total execution time: 0.3215
DEBUG - 2022-09-03 06:34:25 --> Total execution time: 0.0965
DEBUG - 2022-09-03 06:34:33 --> Total execution time: 0.0980
DEBUG - 2022-09-03 06:34:40 --> Total execution time: 0.2720
DEBUG - 2022-09-03 06:34:44 --> Total execution time: 0.1007
DEBUG - 2022-09-03 06:34:55 --> Total execution time: 0.1048
DEBUG - 2022-09-03 06:35:06 --> Total execution time: 0.1552
DEBUG - 2022-09-03 06:35:23 --> Total execution time: 0.0621
DEBUG - 2022-09-03 06:35:28 --> Total execution time: 0.0934
DEBUG - 2022-09-03 06:36:07 --> Total execution time: 0.0974
DEBUG - 2022-09-03 06:36:26 --> Total execution time: 0.1025
DEBUG - 2022-09-03 06:36:45 --> Total execution time: 0.1062
DEBUG - 2022-09-03 06:36:46 --> Total execution time: 0.1009
DEBUG - 2022-09-03 06:36:50 --> Total execution time: 0.1456
DEBUG - 2022-09-03 06:36:55 --> Total execution time: 0.1041
DEBUG - 2022-09-03 06:37:20 --> Total execution time: 0.1031
DEBUG - 2022-09-03 06:37:32 --> Total execution time: 0.1079
DEBUG - 2022-09-03 06:37:37 --> Total execution time: 0.1187
DEBUG - 2022-09-03 06:38:23 --> Total execution time: 0.1551
DEBUG - 2022-09-03 06:39:19 --> Total execution time: 0.0998
DEBUG - 2022-09-03 06:39:23 --> Total execution time: 0.1036
DEBUG - 2022-09-03 06:39:27 --> Total execution time: 0.2431
DEBUG - 2022-09-03 06:44:51 --> Total execution time: 0.1554
DEBUG - 2022-09-03 06:44:52 --> Total execution time: 0.0631
DEBUG - 2022-09-03 06:44:54 --> Total execution time: 0.0899
DEBUG - 2022-09-03 06:44:59 --> Total execution time: 0.0772
DEBUG - 2022-09-03 06:45:08 --> Total execution time: 0.0972
DEBUG - 2022-09-03 06:45:19 --> Total execution time: 0.1595
DEBUG - 2022-09-03 06:45:26 --> Total execution time: 0.0925
DEBUG - 2022-09-03 06:45:39 --> Total execution time: 0.1095
DEBUG - 2022-09-03 06:45:49 --> Total execution time: 0.1010
DEBUG - 2022-09-03 06:45:58 --> Total execution time: 0.1540
DEBUG - 2022-09-03 06:45:58 --> Total execution time: 0.1191
DEBUG - 2022-09-03 06:46:11 --> Total execution time: 0.1127
DEBUG - 2022-09-03 06:46:18 --> Total execution time: 0.1075
DEBUG - 2022-09-03 06:46:31 --> Total execution time: 0.0991
DEBUG - 2022-09-03 06:46:31 --> Total execution time: 0.0753
DEBUG - 2022-09-03 06:46:36 --> Total execution time: 0.1032
DEBUG - 2022-09-03 06:46:38 --> Total execution time: 0.0635
DEBUG - 2022-09-03 06:46:42 --> Total execution time: 0.1009
DEBUG - 2022-09-03 06:46:54 --> Total execution time: 0.1364
DEBUG - 2022-09-03 06:47:53 --> Total execution time: 0.0635
DEBUG - 2022-09-03 06:48:59 --> Total execution time: 2.4015
DEBUG - 2022-09-03 06:50:03 --> Total execution time: 0.2711
DEBUG - 2022-09-03 06:50:26 --> Total execution time: 0.1354
DEBUG - 2022-09-03 06:50:44 --> Total execution time: 0.0972
DEBUG - 2022-09-03 06:51:09 --> Total execution time: 0.1075
DEBUG - 2022-09-03 06:51:25 --> Total execution time: 0.1281
DEBUG - 2022-09-03 06:51:38 --> Total execution time: 0.1263
DEBUG - 2022-09-03 06:52:01 --> Total execution time: 0.1255
DEBUG - 2022-09-03 06:52:23 --> Total execution time: 0.1138
DEBUG - 2022-09-03 06:52:33 --> Total execution time: 0.0974
DEBUG - 2022-09-03 06:56:10 --> Total execution time: 0.2551
DEBUG - 2022-09-03 06:59:49 --> Total execution time: 0.2014
DEBUG - 2022-09-03 07:00:48 --> Total execution time: 0.2930
DEBUG - 2022-09-03 07:04:34 --> Total execution time: 0.1410
DEBUG - 2022-09-03 07:21:14 --> Total execution time: 0.1414
DEBUG - 2022-09-03 07:22:59 --> Total execution time: 0.0708
DEBUG - 2022-09-03 07:23:28 --> Total execution time: 0.0919
DEBUG - 2022-09-03 07:24:02 --> Total execution time: 0.1223
DEBUG - 2022-09-03 07:24:11 --> Total execution time: 0.1050
DEBUG - 2022-09-03 07:24:20 --> Total execution time: 0.0981
DEBUG - 2022-09-03 07:24:24 --> Total execution time: 0.1020
DEBUG - 2022-09-03 07:24:44 --> Total execution time: 0.1076
DEBUG - 2022-09-03 07:24:55 --> Total execution time: 0.0927
DEBUG - 2022-09-03 07:25:02 --> Total execution time: 0.0975
DEBUG - 2022-09-03 07:25:16 --> Total execution time: 0.1011
DEBUG - 2022-09-03 07:25:22 --> Total execution time: 0.0989
DEBUG - 2022-09-03 07:25:30 --> Total execution time: 0.0981
DEBUG - 2022-09-03 07:25:34 --> Total execution time: 0.0969
DEBUG - 2022-09-03 07:25:41 --> Total execution time: 0.0990
DEBUG - 2022-09-03 07:26:58 --> Total execution time: 0.2630
DEBUG - 2022-09-03 07:27:04 --> Total execution time: 0.1057
DEBUG - 2022-09-03 07:29:41 --> Total execution time: 0.1342
DEBUG - 2022-09-03 07:30:02 --> Total execution time: 0.1568
DEBUG - 2022-09-03 07:38:17 --> Total execution time: 0.1370
DEBUG - 2022-09-03 07:45:08 --> Total execution time: 0.1355
DEBUG - 2022-09-03 07:46:11 --> Total execution time: 0.2764
DEBUG - 2022-09-03 07:46:20 --> Total execution time: 0.0978
DEBUG - 2022-09-03 07:46:52 --> Total execution time: 0.0997
DEBUG - 2022-09-03 07:47:05 --> Total execution time: 0.0991
DEBUG - 2022-09-03 07:52:39 --> Total execution time: 0.1273
DEBUG - 2022-09-03 07:56:55 --> Total execution time: 0.1168
DEBUG - 2022-09-03 07:59:56 --> Total execution time: 0.1137
DEBUG - 2022-09-03 08:00:34 --> Total execution time: 0.0966
DEBUG - 2022-09-03 08:02:46 --> Total execution time: 0.1227
DEBUG - 2022-09-03 08:02:47 --> Total execution time: 0.0660
DEBUG - 2022-09-03 08:02:47 --> Total execution time: 0.0947
DEBUG - 2022-09-03 08:07:11 --> Total execution time: 0.1248
DEBUG - 2022-09-03 08:07:39 --> Total execution time: 0.0931
DEBUG - 2022-09-03 08:08:07 --> Total execution time: 0.0711
DEBUG - 2022-09-03 08:09:35 --> Total execution time: 0.0625
DEBUG - 2022-09-03 08:12:01 --> Total execution time: 0.0944
DEBUG - 2022-09-03 08:12:36 --> Total execution time: 0.0667
DEBUG - 2022-09-03 08:12:52 --> Total execution time: 0.0592
DEBUG - 2022-09-03 08:13:55 --> Total execution time: 0.1347
DEBUG - 2022-09-03 08:15:06 --> Total execution time: 0.1367
DEBUG - 2022-09-03 08:15:33 --> Total execution time: 0.1373
DEBUG - 2022-09-03 08:15:57 --> Total execution time: 0.1149
DEBUG - 2022-09-03 08:16:04 --> Total execution time: 0.0665
DEBUG - 2022-09-03 08:17:04 --> Total execution time: 0.0994
DEBUG - 2022-09-03 08:17:15 --> Total execution time: 0.1075
DEBUG - 2022-09-03 08:17:25 --> Total execution time: 0.1544
DEBUG - 2022-09-03 08:18:17 --> Total execution time: 0.2542
DEBUG - 2022-09-03 08:18:54 --> Total execution time: 0.1383
DEBUG - 2022-09-03 08:19:15 --> Total execution time: 0.1003
DEBUG - 2022-09-03 08:26:43 --> Total execution time: 0.1719
DEBUG - 2022-09-03 08:26:47 --> Total execution time: 0.0997
DEBUG - 2022-09-03 08:27:03 --> Total execution time: 0.1103
DEBUG - 2022-09-03 08:27:32 --> Total execution time: 0.0909
DEBUG - 2022-09-03 08:27:47 --> Total execution time: 0.1078
DEBUG - 2022-09-03 08:28:22 --> Total execution time: 0.1154
DEBUG - 2022-09-03 08:28:44 --> Total execution time: 0.2708
DEBUG - 2022-09-03 08:29:02 --> Total execution time: 0.1406
DEBUG - 2022-09-03 08:29:09 --> Total execution time: 0.1015
DEBUG - 2022-09-03 08:29:10 --> Total execution time: 0.1004
DEBUG - 2022-09-03 08:29:17 --> Total execution time: 0.1021
DEBUG - 2022-09-03 08:29:17 --> Total execution time: 0.1038
DEBUG - 2022-09-03 08:29:24 --> Total execution time: 0.0922
DEBUG - 2022-09-03 08:29:25 --> Total execution time: 0.0921
DEBUG - 2022-09-03 08:29:50 --> Total execution time: 0.0933
DEBUG - 2022-09-03 08:29:56 --> Total execution time: 0.0956
DEBUG - 2022-09-03 08:29:58 --> Total execution time: 0.0957
DEBUG - 2022-09-03 08:29:59 --> Total execution time: 0.1351
DEBUG - 2022-09-03 08:30:03 --> Total execution time: 0.0645
DEBUG - 2022-09-03 08:30:21 --> Total execution time: 0.1613
DEBUG - 2022-09-03 08:30:59 --> Total execution time: 0.1074
DEBUG - 2022-09-03 08:31:11 --> Total execution time: 0.1300
DEBUG - 2022-09-03 08:31:24 --> Total execution time: 0.2950
DEBUG - 2022-09-03 08:31:27 --> Total execution time: 0.1000
DEBUG - 2022-09-03 08:33:52 --> Total execution time: 0.1055
DEBUG - 2022-09-03 08:37:15 --> Total execution time: 0.1820
DEBUG - 2022-09-03 08:37:38 --> Total execution time: 0.0675
DEBUG - 2022-09-03 08:37:57 --> Total execution time: 0.0782
DEBUG - 2022-09-03 08:38:01 --> Total execution time: 0.0764
DEBUG - 2022-09-03 08:38:46 --> Total execution time: 0.1130
DEBUG - 2022-09-03 08:39:06 --> Total execution time: 0.1025
DEBUG - 2022-09-03 08:39:07 --> Total execution time: 0.0994
DEBUG - 2022-09-03 08:39:33 --> Total execution time: 0.1425
DEBUG - 2022-09-03 08:39:34 --> Total execution time: 0.1621
DEBUG - 2022-09-03 08:39:40 --> Total execution time: 0.2504
DEBUG - 2022-09-03 08:39:52 --> Total execution time: 0.1096
DEBUG - 2022-09-03 08:39:53 --> Total execution time: 0.0986
DEBUG - 2022-09-03 08:40:02 --> Total execution time: 0.1802
DEBUG - 2022-09-03 08:40:02 --> Total execution time: 0.1230
DEBUG - 2022-09-03 08:40:10 --> Total execution time: 0.1407
DEBUG - 2022-09-03 08:40:42 --> Total execution time: 0.1346
DEBUG - 2022-09-03 08:42:10 --> Total execution time: 0.0582
DEBUG - 2022-09-03 08:44:13 --> Total execution time: 0.0985
DEBUG - 2022-09-03 08:44:28 --> Total execution time: 0.1045
DEBUG - 2022-09-03 08:47:04 --> Total execution time: 0.2736
DEBUG - 2022-09-03 08:47:06 --> Total execution time: 0.1021
DEBUG - 2022-09-03 08:47:25 --> Total execution time: 0.1122
DEBUG - 2022-09-03 08:47:38 --> Total execution time: 0.1042
DEBUG - 2022-09-03 08:47:39 --> Total execution time: 0.1035
DEBUG - 2022-09-03 08:47:49 --> Total execution time: 0.0985
DEBUG - 2022-09-03 08:48:00 --> Total execution time: 0.1060
DEBUG - 2022-09-03 08:48:11 --> Total execution time: 0.1291
DEBUG - 2022-09-03 08:48:12 --> Total execution time: 0.1268
DEBUG - 2022-09-03 08:48:21 --> Total execution time: 0.1644
DEBUG - 2022-09-03 08:48:22 --> Total execution time: 0.1326
DEBUG - 2022-09-03 08:48:33 --> Total execution time: 0.0963
DEBUG - 2022-09-03 08:48:34 --> Total execution time: 0.1026
DEBUG - 2022-09-03 08:48:34 --> Total execution time: 0.0960
DEBUG - 2022-09-03 08:48:44 --> Total execution time: 0.0915
DEBUG - 2022-09-03 08:48:53 --> Total execution time: 0.1142
DEBUG - 2022-09-03 08:48:54 --> Total execution time: 0.1168
DEBUG - 2022-09-03 08:48:59 --> Total execution time: 0.0975
DEBUG - 2022-09-03 08:49:04 --> Total execution time: 0.0935
DEBUG - 2022-09-03 08:49:09 --> Total execution time: 0.0992
DEBUG - 2022-09-03 08:49:22 --> Total execution time: 0.2826
DEBUG - 2022-09-03 08:49:35 --> Total execution time: 0.0626
DEBUG - 2022-09-03 08:49:43 --> Total execution time: 0.0996
DEBUG - 2022-09-03 08:49:51 --> Total execution time: 0.1246
DEBUG - 2022-09-03 08:50:11 --> Total execution time: 0.0977
DEBUG - 2022-09-03 08:59:36 --> Total execution time: 0.1348
DEBUG - 2022-09-03 09:03:55 --> Total execution time: 0.3293
DEBUG - 2022-09-03 09:04:07 --> Total execution time: 0.1227
DEBUG - 2022-09-03 09:04:14 --> Total execution time: 0.1038
DEBUG - 2022-09-03 09:04:39 --> Total execution time: 0.0665
DEBUG - 2022-09-03 09:08:00 --> Total execution time: 0.1226
DEBUG - 2022-09-03 09:08:18 --> Total execution time: 0.0757
DEBUG - 2022-09-03 09:08:25 --> Total execution time: 0.0645
DEBUG - 2022-09-03 09:08:30 --> Total execution time: 0.0950
DEBUG - 2022-09-03 09:08:44 --> Total execution time: 0.1069
DEBUG - 2022-09-03 09:08:52 --> Total execution time: 0.1454
DEBUG - 2022-09-03 09:11:05 --> Total execution time: 0.1401
DEBUG - 2022-09-03 09:11:06 --> Total execution time: 0.0615
DEBUG - 2022-09-03 09:12:04 --> Total execution time: 0.0699
DEBUG - 2022-09-03 09:12:10 --> Total execution time: 0.0772
DEBUG - 2022-09-03 09:12:21 --> Total execution time: 0.1381
DEBUG - 2022-09-03 09:12:37 --> Total execution time: 0.0904
DEBUG - 2022-09-03 09:12:57 --> Total execution time: 0.1276
DEBUG - 2022-09-03 09:13:37 --> Total execution time: 0.1264
DEBUG - 2022-09-03 09:13:53 --> Total execution time: 0.1586
DEBUG - 2022-09-03 09:13:59 --> Total execution time: 0.0893
DEBUG - 2022-09-03 09:14:08 --> Total execution time: 0.1062
DEBUG - 2022-09-03 09:14:16 --> Total execution time: 0.1416
DEBUG - 2022-09-03 09:14:54 --> Total execution time: 0.1128
DEBUG - 2022-09-03 09:15:15 --> Total execution time: 0.1080
DEBUG - 2022-09-03 09:15:33 --> Total execution time: 0.0888
DEBUG - 2022-09-03 09:22:21 --> Total execution time: 0.1455
DEBUG - 2022-09-03 09:23:16 --> Total execution time: 0.1155
DEBUG - 2022-09-03 09:24:32 --> Total execution time: 2.5110
DEBUG - 2022-09-03 09:25:15 --> Total execution time: 0.1058
DEBUG - 2022-09-03 09:25:23 --> Total execution time: 1.7854
DEBUG - 2022-09-03 09:25:28 --> Total execution time: 0.0689
DEBUG - 2022-09-03 09:25:36 --> Total execution time: 0.0636
DEBUG - 2022-09-03 09:25:49 --> Total execution time: 0.0619
DEBUG - 2022-09-03 09:25:55 --> Total execution time: 0.0943
DEBUG - 2022-09-03 09:26:02 --> Total execution time: 0.1346
DEBUG - 2022-09-03 09:26:09 --> Total execution time: 0.1515
DEBUG - 2022-09-03 09:26:17 --> Total execution time: 0.0946
DEBUG - 2022-09-03 09:26:23 --> Total execution time: 0.0976
DEBUG - 2022-09-03 09:26:23 --> Total execution time: 0.1017
DEBUG - 2022-09-03 09:26:31 --> Total execution time: 0.1370
DEBUG - 2022-09-03 09:27:34 --> Total execution time: 0.2408
DEBUG - 2022-09-03 09:27:58 --> Total execution time: 1.9548
DEBUG - 2022-09-03 09:28:12 --> Total execution time: 0.1017
DEBUG - 2022-09-03 09:28:18 --> Total execution time: 0.1783
DEBUG - 2022-09-03 09:28:24 --> Total execution time: 0.1301
DEBUG - 2022-09-03 09:28:25 --> Total execution time: 0.2371
DEBUG - 2022-09-03 09:28:41 --> Total execution time: 0.0990
DEBUG - 2022-09-03 09:29:21 --> Total execution time: 0.0967
DEBUG - 2022-09-03 09:29:27 --> Total execution time: 0.0939
DEBUG - 2022-09-03 09:30:02 --> Total execution time: 0.1243
DEBUG - 2022-09-03 09:33:00 --> Total execution time: 0.1022
DEBUG - 2022-09-03 09:33:19 --> Total execution time: 0.0724
DEBUG - 2022-09-03 09:42:21 --> Total execution time: 0.3298
DEBUG - 2022-09-03 09:42:32 --> Total execution time: 0.0686
DEBUG - 2022-09-03 09:42:41 --> Total execution time: 0.0942
DEBUG - 2022-09-03 09:42:53 --> Total execution time: 0.1265
DEBUG - 2022-09-03 09:43:01 --> Total execution time: 0.2011
DEBUG - 2022-09-03 09:44:51 --> Total execution time: 0.0578
DEBUG - 2022-09-03 09:44:51 --> Total execution time: 0.0538
DEBUG - 2022-09-03 09:44:59 --> Total execution time: 0.0959
DEBUG - 2022-09-03 09:45:08 --> Total execution time: 0.1409
DEBUG - 2022-09-03 09:45:08 --> Total execution time: 0.1256
DEBUG - 2022-09-03 09:45:16 --> Total execution time: 0.1271
DEBUG - 2022-09-03 09:45:17 --> Total execution time: 0.1004
DEBUG - 2022-09-03 09:45:20 --> Total execution time: 0.1266
DEBUG - 2022-09-03 09:52:23 --> Total execution time: 0.1594
DEBUG - 2022-09-03 09:53:24 --> Total execution time: 0.1095
DEBUG - 2022-09-03 09:53:35 --> Total execution time: 0.1182
DEBUG - 2022-09-03 09:53:44 --> Total execution time: 0.2336
DEBUG - 2022-09-03 09:53:53 --> Total execution time: 0.0994
DEBUG - 2022-09-03 09:53:59 --> Total execution time: 0.1703
DEBUG - 2022-09-03 09:54:26 --> Total execution time: 0.0974
DEBUG - 2022-09-03 09:54:34 --> Total execution time: 0.0908
DEBUG - 2022-09-03 09:54:37 --> Total execution time: 0.1427
DEBUG - 2022-09-03 09:56:02 --> Total execution time: 0.0599
DEBUG - 2022-09-03 09:56:35 --> Total execution time: 2.4736
DEBUG - 2022-09-03 09:57:22 --> Total execution time: 0.0740
DEBUG - 2022-09-03 09:58:53 --> Total execution time: 0.1112
DEBUG - 2022-09-03 09:58:56 --> Total execution time: 0.2770
DEBUG - 2022-09-03 10:04:14 --> Total execution time: 0.2301
DEBUG - 2022-09-03 10:05:01 --> Total execution time: 0.3629
DEBUG - 2022-09-03 10:05:09 --> Total execution time: 0.0993
DEBUG - 2022-09-03 10:10:08 --> Total execution time: 0.1590
DEBUG - 2022-09-03 10:13:19 --> Total execution time: 0.3351
DEBUG - 2022-09-03 10:14:12 --> Total execution time: 0.0930
DEBUG - 2022-09-03 10:14:22 --> Total execution time: 0.1077
DEBUG - 2022-09-03 10:14:31 --> Total execution time: 0.1759
DEBUG - 2022-09-03 10:14:39 --> Total execution time: 0.0872
DEBUG - 2022-09-03 10:14:49 --> Total execution time: 0.1111
DEBUG - 2022-09-03 10:16:01 --> Total execution time: 2.2401
DEBUG - 2022-09-03 10:16:20 --> Total execution time: 0.2632
DEBUG - 2022-09-03 10:16:25 --> Total execution time: 0.0979
DEBUG - 2022-09-03 10:16:37 --> Total execution time: 0.0928
DEBUG - 2022-09-03 10:16:39 --> Total execution time: 0.2719
DEBUG - 2022-09-03 10:16:43 --> Total execution time: 0.1198
DEBUG - 2022-09-03 10:16:48 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:16:54 --> Total execution time: 0.0899
DEBUG - 2022-09-03 10:17:10 --> Total execution time: 0.1062
DEBUG - 2022-09-03 10:17:17 --> Total execution time: 0.1219
DEBUG - 2022-09-03 10:21:18 --> Total execution time: 0.0738
DEBUG - 2022-09-03 10:23:58 --> Total execution time: 0.2558
DEBUG - 2022-09-03 10:25:20 --> Total execution time: 0.2796
DEBUG - 2022-09-03 10:25:31 --> Total execution time: 0.1399
DEBUG - 2022-09-03 10:25:41 --> Total execution time: 0.0997
DEBUG - 2022-09-03 10:25:41 --> Total execution time: 0.1148
DEBUG - 2022-09-03 10:25:42 --> Total execution time: 0.1044
DEBUG - 2022-09-03 10:25:43 --> Total execution time: 0.0985
DEBUG - 2022-09-03 10:26:43 --> Total execution time: 0.1059
DEBUG - 2022-09-03 10:27:50 --> Total execution time: 0.1149
DEBUG - 2022-09-03 10:28:46 --> Total execution time: 0.0841
DEBUG - 2022-09-03 10:29:02 --> Total execution time: 0.0606
DEBUG - 2022-09-03 10:29:33 --> Total execution time: 0.1017
DEBUG - 2022-09-03 00:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:30:02 --> Total execution time: 0.1202
DEBUG - 2022-09-03 00:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:30:20 --> Total execution time: 0.1224
DEBUG - 2022-09-03 00:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:01:20 --> Total execution time: 0.1130
DEBUG - 2022-09-03 00:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:01:24 --> Total execution time: 0.1791
DEBUG - 2022-09-03 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:02:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:02:24 --> Total execution time: 0.1125
DEBUG - 2022-09-03 00:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:02:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:02:31 --> Total execution time: 0.1254
DEBUG - 2022-09-03 00:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:02 --> Total execution time: 0.1840
DEBUG - 2022-09-03 00:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:17 --> Total execution time: 0.0737
DEBUG - 2022-09-03 00:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 10:34:30 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-09-03 00:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:30 --> Total execution time: 0.1256
DEBUG - 2022-09-03 00:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:04:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:56 --> Total execution time: 0.0833
DEBUG - 2022-09-03 00:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:03 --> Total execution time: 0.1244
DEBUG - 2022-09-03 00:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:08 --> Total execution time: 0.0622
DEBUG - 2022-09-03 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:22 --> Total execution time: 0.0654
DEBUG - 2022-09-03 00:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:27 --> Total execution time: 0.0765
DEBUG - 2022-09-03 00:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:27 --> Total execution time: 0.0652
DEBUG - 2022-09-03 00:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:43 --> Total execution time: 0.1199
DEBUG - 2022-09-03 00:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:50 --> Total execution time: 0.1117
DEBUG - 2022-09-03 00:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:54 --> Total execution time: 0.0820
DEBUG - 2022-09-03 00:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:05 --> Total execution time: 0.1198
DEBUG - 2022-09-03 00:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:10 --> Total execution time: 0.1794
DEBUG - 2022-09-03 00:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:13 --> Total execution time: 0.0655
DEBUG - 2022-09-03 00:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:17 --> Total execution time: 0.0652
DEBUG - 2022-09-03 00:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:18 --> Total execution time: 0.0670
DEBUG - 2022-09-03 00:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:22 --> Total execution time: 0.0744
DEBUG - 2022-09-03 00:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:30 --> Total execution time: 0.0649
DEBUG - 2022-09-03 00:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 00:06:36 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-03 00:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:59 --> Total execution time: 0.1433
DEBUG - 2022-09-03 00:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:19 --> Total execution time: 0.1087
DEBUG - 2022-09-03 00:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:28 --> Total execution time: 0.1009
DEBUG - 2022-09-03 00:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:31 --> Total execution time: 0.1228
DEBUG - 2022-09-03 00:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:07:44 --> Total execution time: 0.1050
DEBUG - 2022-09-03 00:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:45 --> Total execution time: 0.1271
DEBUG - 2022-09-03 00:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:07:47 --> Total execution time: 0.0920
DEBUG - 2022-09-03 00:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:07:47 --> Total execution time: 0.0944
DEBUG - 2022-09-03 00:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:55 --> Total execution time: 0.0980
DEBUG - 2022-09-03 00:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:24 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 00:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:24 --> Total execution time: 0.1456
DEBUG - 2022-09-03 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:08:46 --> Total execution time: 0.0980
DEBUG - 2022-09-03 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:08:49 --> Total execution time: 0.1004
DEBUG - 2022-09-03 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:08:50 --> Total execution time: 0.0968
DEBUG - 2022-09-03 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:52 --> Total execution time: 0.1009
DEBUG - 2022-09-03 00:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:57 --> Total execution time: 0.1018
DEBUG - 2022-09-03 00:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:58 --> Total execution time: 0.1099
DEBUG - 2022-09-03 00:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:02 --> Total execution time: 0.0924
DEBUG - 2022-09-03 00:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:26 --> Total execution time: 0.1030
DEBUG - 2022-09-03 00:09:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:26 --> Total execution time: 0.2832
DEBUG - 2022-09-03 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:09:34 --> Total execution time: 0.0902
DEBUG - 2022-09-03 00:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:36 --> Total execution time: 0.0951
DEBUG - 2022-09-03 00:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:38 --> Total execution time: 0.1009
DEBUG - 2022-09-03 00:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:45 --> Total execution time: 0.0914
DEBUG - 2022-09-03 00:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:46 --> Total execution time: 0.0974
DEBUG - 2022-09-03 00:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:54 --> Total execution time: 0.0993
DEBUG - 2022-09-03 00:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:09:56 --> Total execution time: 0.1019
DEBUG - 2022-09-03 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:57 --> Total execution time: 0.0899
DEBUG - 2022-09-03 00:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:09:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:00 --> Total execution time: 2.2176
DEBUG - 2022-09-03 00:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:02 --> Total execution time: 0.0994
DEBUG - 2022-09-03 00:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 00:10:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 00:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:24 --> Total execution time: 0.1037
DEBUG - 2022-09-03 00:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:27 --> Total execution time: 0.1292
DEBUG - 2022-09-03 00:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:28 --> Total execution time: 0.1004
DEBUG - 2022-09-03 00:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:30 --> Total execution time: 0.1502
DEBUG - 2022-09-03 00:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:31 --> Total execution time: 0.0994
DEBUG - 2022-09-03 00:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:34 --> Total execution time: 0.1324
DEBUG - 2022-09-03 00:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:39 --> Total execution time: 0.1156
DEBUG - 2022-09-03 00:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:40:45 --> Total execution time: 0.0651
DEBUG - 2022-09-03 00:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:16 --> Total execution time: 0.1015
DEBUG - 2022-09-03 00:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:27 --> Total execution time: 0.1353
DEBUG - 2022-09-03 00:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:45 --> Total execution time: 0.1138
DEBUG - 2022-09-03 00:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:47 --> Total execution time: 0.1136
DEBUG - 2022-09-03 00:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:50 --> Total execution time: 0.0967
DEBUG - 2022-09-03 00:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:41:56 --> Total execution time: 1.8517
DEBUG - 2022-09-03 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:46:19 --> Total execution time: 0.3459
DEBUG - 2022-09-03 00:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:17:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:47:24 --> Total execution time: 0.1007
DEBUG - 2022-09-03 00:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:47:38 --> Total execution time: 2.1588
DEBUG - 2022-09-03 00:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:18:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:48:38 --> Total execution time: 2.0216
DEBUG - 2022-09-03 00:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:53:28 --> Total execution time: 0.1172
DEBUG - 2022-09-03 00:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:54:05 --> Total execution time: 0.0664
DEBUG - 2022-09-03 00:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:55:04 --> Total execution time: 0.1185
DEBUG - 2022-09-03 00:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:56:29 --> Total execution time: 0.1189
DEBUG - 2022-09-03 00:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:57:01 --> Total execution time: 0.1267
DEBUG - 2022-09-03 00:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:58:23 --> Total execution time: 2.6433
DEBUG - 2022-09-03 00:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:29:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:29:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:59:07 --> Total execution time: 0.0873
DEBUG - 2022-09-03 00:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:00:01 --> Total execution time: 1.9797
DEBUG - 2022-09-03 00:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:30:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:00:33 --> Total execution time: 0.2634
DEBUG - 2022-09-03 00:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:33:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:03:08 --> Total execution time: 2.0984
DEBUG - 2022-09-03 00:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:37 --> Total execution time: 0.0956
DEBUG - 2022-09-03 00:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:34:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:47 --> Total execution time: 0.2816
DEBUG - 2022-09-03 00:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:56 --> Total execution time: 2.2048
DEBUG - 2022-09-03 00:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:42:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:12:18 --> Total execution time: 0.5514
DEBUG - 2022-09-03 00:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:45:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:45:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:15:57 --> Total execution time: 0.3575
DEBUG - 2022-09-03 00:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:17:47 --> Total execution time: 0.1315
DEBUG - 2022-09-03 00:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:17:57 --> Total execution time: 0.3555
DEBUG - 2022-09-03 00:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:18:09 --> Total execution time: 0.1029
DEBUG - 2022-09-03 00:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:18:16 --> Total execution time: 0.1035
DEBUG - 2022-09-03 00:48:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:18:20 --> Total execution time: 0.1451
DEBUG - 2022-09-03 00:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:48:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:18:44 --> Total execution time: 0.1410
DEBUG - 2022-09-03 00:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:00 --> Total execution time: 0.1523
DEBUG - 2022-09-03 00:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:11 --> Total execution time: 0.0990
DEBUG - 2022-09-03 00:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:16 --> Total execution time: 0.1773
DEBUG - 2022-09-03 00:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:29 --> Total execution time: 0.1055
DEBUG - 2022-09-03 00:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:45 --> Total execution time: 0.0700
DEBUG - 2022-09-03 00:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:49 --> Total execution time: 0.1157
DEBUG - 2022-09-03 00:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:49:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:19:58 --> Total execution time: 0.1146
DEBUG - 2022-09-03 00:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:51:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:21:37 --> Total execution time: 0.0653
DEBUG - 2022-09-03 00:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:54:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:54:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:45 --> Total execution time: 0.1708
DEBUG - 2022-09-03 00:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:54:46 --> No URI present. Default controller set.
DEBUG - 2022-09-03 00:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:54:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:46 --> Total execution time: 0.0672
DEBUG - 2022-09-03 00:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:55:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:25:14 --> Total execution time: 0.0610
DEBUG - 2022-09-03 00:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:25:17 --> Total execution time: 0.0902
DEBUG - 2022-09-03 00:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:55:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 00:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:25:53 --> Total execution time: 0.1071
DEBUG - 2022-09-03 00:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 00:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 00:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:26:12 --> Total execution time: 0.1324
DEBUG - 2022-09-03 01:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:02 --> Total execution time: 0.1727
DEBUG - 2022-09-03 01:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:15 --> Total execution time: 0.0703
DEBUG - 2022-09-03 01:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:17 --> Total execution time: 0.1040
DEBUG - 2022-09-03 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:23 --> Total execution time: 0.0842
DEBUG - 2022-09-03 01:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:24 --> Total execution time: 0.0685
DEBUG - 2022-09-03 01:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:31 --> Total execution time: 0.2583
DEBUG - 2022-09-03 01:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:40 --> Total execution time: 0.2848
DEBUG - 2022-09-03 01:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:43 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:43 --> Total execution time: 0.1052
DEBUG - 2022-09-03 01:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:45 --> Total execution time: 0.0981
DEBUG - 2022-09-03 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:58 --> Total execution time: 0.0956
DEBUG - 2022-09-03 01:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:00:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:58 --> Total execution time: 0.0956
DEBUG - 2022-09-03 01:01:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:05 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:05 --> Total execution time: 0.1029
DEBUG - 2022-09-03 01:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:11 --> Total execution time: 0.1089
DEBUG - 2022-09-03 01:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:17 --> Total execution time: 0.1320
DEBUG - 2022-09-03 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:18 --> Total execution time: 0.0980
DEBUG - 2022-09-03 01:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:19 --> Total execution time: 0.0970
DEBUG - 2022-09-03 01:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:20 --> Total execution time: 0.0982
DEBUG - 2022-09-03 01:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:31 --> Total execution time: 0.0997
DEBUG - 2022-09-03 01:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:31 --> Total execution time: 0.1188
DEBUG - 2022-09-03 01:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:44 --> Total execution time: 0.1239
DEBUG - 2022-09-03 01:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:01:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:31:45 --> Total execution time: 0.1086
DEBUG - 2022-09-03 01:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:32:13 --> Total execution time: 0.0981
DEBUG - 2022-09-03 01:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:32:14 --> Total execution time: 0.1002
DEBUG - 2022-09-03 01:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:03:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:33:15 --> Total execution time: 0.0753
DEBUG - 2022-09-03 01:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:33:38 --> Total execution time: 0.1146
DEBUG - 2022-09-03 01:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:33:52 --> Total execution time: 0.1053
DEBUG - 2022-09-03 01:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:01 --> Total execution time: 0.1379
DEBUG - 2022-09-03 01:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:09 --> Total execution time: 0.1445
DEBUG - 2022-09-03 01:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:26 --> Total execution time: 0.1025
DEBUG - 2022-09-03 01:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:31 --> Total execution time: 0.1217
DEBUG - 2022-09-03 01:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:35 --> Total execution time: 0.1084
DEBUG - 2022-09-03 01:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:34:47 --> Total execution time: 0.1276
DEBUG - 2022-09-03 01:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:35:05 --> Total execution time: 0.0971
DEBUG - 2022-09-03 01:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:09:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:09:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:39:35 --> Total execution time: 0.1312
DEBUG - 2022-09-03 01:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:09:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:39:37 --> Total execution time: 0.1032
DEBUG - 2022-09-03 01:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:11:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:41:57 --> Total execution time: 0.3795
DEBUG - 2022-09-03 01:12:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:12:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:13 --> Total execution time: 0.1330
DEBUG - 2022-09-03 01:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:34 --> Total execution time: 0.1209
DEBUG - 2022-09-03 01:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:43 --> Total execution time: 0.1072
DEBUG - 2022-09-03 01:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:48 --> Total execution time: 0.1178
DEBUG - 2022-09-03 01:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:50 --> Total execution time: 0.1147
DEBUG - 2022-09-03 01:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:14:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:44:07 --> Total execution time: 0.0724
DEBUG - 2022-09-03 01:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:46:04 --> Total execution time: 0.2992
DEBUG - 2022-09-03 01:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:17:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:07 --> Total execution time: 0.0644
DEBUG - 2022-09-03 01:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:33 --> Total execution time: 0.0986
DEBUG - 2022-09-03 01:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:43 --> Total execution time: 0.1084
DEBUG - 2022-09-03 01:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:48 --> Total execution time: 0.1243
DEBUG - 2022-09-03 01:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:18:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:48:00 --> Total execution time: 0.1194
DEBUG - 2022-09-03 01:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:07 --> Total execution time: 0.1534
DEBUG - 2022-09-03 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:18 --> Total execution time: 0.1071
DEBUG - 2022-09-03 01:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:30 --> Total execution time: 0.1128
DEBUG - 2022-09-03 01:23:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:35 --> Total execution time: 0.1331
DEBUG - 2022-09-03 01:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:42 --> Total execution time: 0.1449
DEBUG - 2022-09-03 01:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:01 --> Total execution time: 0.1407
DEBUG - 2022-09-03 01:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:05 --> Total execution time: 0.1094
DEBUG - 2022-09-03 01:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:13 --> Total execution time: 0.1120
DEBUG - 2022-09-03 01:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:17 --> Total execution time: 0.0961
DEBUG - 2022-09-03 01:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:21 --> Total execution time: 0.1103
DEBUG - 2022-09-03 01:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:54:47 --> Total execution time: 0.0977
DEBUG - 2022-09-03 01:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:25:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:04 --> Total execution time: 0.1080
DEBUG - 2022-09-03 01:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:57:44 --> Total execution time: 0.1827
DEBUG - 2022-09-03 01:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:57:51 --> Total execution time: 0.1126
DEBUG - 2022-09-03 01:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:12 --> Total execution time: 0.0830
DEBUG - 2022-09-03 01:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:12 --> Total execution time: 0.0731
DEBUG - 2022-09-03 01:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:12 --> Total execution time: 0.0638
DEBUG - 2022-09-03 01:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:12 --> Total execution time: 0.0653
DEBUG - 2022-09-03 01:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:17 --> Total execution time: 0.0838
DEBUG - 2022-09-03 01:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:38 --> Total execution time: 0.0992
DEBUG - 2022-09-03 01:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:28:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:58:45 --> Total execution time: 0.0632
DEBUG - 2022-09-03 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:01 --> Total execution time: 0.1440
DEBUG - 2022-09-03 01:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:04 --> Total execution time: 0.2879
DEBUG - 2022-09-03 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:04 --> Total execution time: 0.1369
DEBUG - 2022-09-03 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:11 --> Total execution time: 0.1109
DEBUG - 2022-09-03 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:11 --> Total execution time: 0.0966
DEBUG - 2022-09-03 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:11 --> Total execution time: 0.0943
DEBUG - 2022-09-03 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:11 --> Total execution time: 0.1041
DEBUG - 2022-09-03 01:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:12 --> Total execution time: 0.2294
DEBUG - 2022-09-03 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:21 --> Total execution time: 0.0906
DEBUG - 2022-09-03 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:34 --> Total execution time: 0.1018
DEBUG - 2022-09-03 01:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:35 --> Total execution time: 0.0970
DEBUG - 2022-09-03 01:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:48 --> Total execution time: 0.0726
DEBUG - 2022-09-03 01:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:29:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:59:52 --> Total execution time: 0.1300
DEBUG - 2022-09-03 01:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:01:28 --> Total execution time: 0.1114
DEBUG - 2022-09-03 01:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:31:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:01:31 --> Total execution time: 0.0710
DEBUG - 2022-09-03 01:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:01:40 --> Total execution time: 0.0975
DEBUG - 2022-09-03 01:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:11 --> Total execution time: 0.0952
DEBUG - 2022-09-03 01:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:12 --> Total execution time: 0.1101
DEBUG - 2022-09-03 01:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:21 --> Total execution time: 0.1555
DEBUG - 2022-09-03 01:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:39 --> Total execution time: 0.1112
DEBUG - 2022-09-03 01:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:44 --> Total execution time: 0.0991
DEBUG - 2022-09-03 01:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:48 --> Total execution time: 0.1011
DEBUG - 2022-09-03 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:32:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:02:56 --> Total execution time: 0.1035
DEBUG - 2022-09-03 01:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:36:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:06:37 --> Total execution time: 0.1415
DEBUG - 2022-09-03 01:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:37:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:07:56 --> Total execution time: 0.0667
DEBUG - 2022-09-03 01:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 01:37:56 --> 404 Page Not Found: Wp-includes/css
DEBUG - 2022-09-03 01:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:37:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 01:37:56 --> 404 Page Not Found: Media/system
DEBUG - 2022-09-03 01:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:12:11 --> Total execution time: 0.2737
DEBUG - 2022-09-03 01:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:45:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:45:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:15:44 --> Total execution time: 0.3358
DEBUG - 2022-09-03 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:45:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:15:45 --> Total execution time: 0.1026
DEBUG - 2022-09-03 01:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:00 --> Total execution time: 0.2546
DEBUG - 2022-09-03 01:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:07 --> Total execution time: 0.1146
DEBUG - 2022-09-03 01:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:13 --> Total execution time: 0.0676
DEBUG - 2022-09-03 01:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:17 --> Total execution time: 0.1007
DEBUG - 2022-09-03 01:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 01:46:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 01:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:23 --> Total execution time: 0.1037
DEBUG - 2022-09-03 01:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:32 --> Total execution time: 0.1029
DEBUG - 2022-09-03 01:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:41 --> Total execution time: 0.1134
DEBUG - 2022-09-03 01:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:46:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:16:51 --> Total execution time: 0.1139
DEBUG - 2022-09-03 01:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:11 --> Total execution time: 0.0768
DEBUG - 2022-09-03 01:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:17 --> Total execution time: 0.0679
DEBUG - 2022-09-03 01:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:18 --> Total execution time: 0.1155
DEBUG - 2022-09-03 01:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:21 --> Total execution time: 0.1218
DEBUG - 2022-09-03 01:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:24 --> Total execution time: 0.1665
DEBUG - 2022-09-03 01:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:29 --> Total execution time: 0.1565
DEBUG - 2022-09-03 01:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:31 --> Total execution time: 0.0924
DEBUG - 2022-09-03 01:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:37 --> Total execution time: 0.0941
DEBUG - 2022-09-03 01:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:39 --> Total execution time: 0.1148
DEBUG - 2022-09-03 01:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:17:44 --> Total execution time: 0.1034
DEBUG - 2022-09-03 01:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:08 --> Total execution time: 0.1585
DEBUG - 2022-09-03 01:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:08 --> Total execution time: 0.2713
DEBUG - 2022-09-03 01:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:10 --> Total execution time: 0.1815
DEBUG - 2022-09-03 01:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:15 --> Total execution time: 0.1944
DEBUG - 2022-09-03 01:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:19 --> Total execution time: 0.1094
DEBUG - 2022-09-03 01:48:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:30 --> Total execution time: 0.0950
DEBUG - 2022-09-03 01:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:18:37 --> Total execution time: 0.0962
DEBUG - 2022-09-03 01:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:49:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:19:23 --> Total execution time: 0.1247
DEBUG - 2022-09-03 01:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:19:25 --> Total execution time: 0.1203
DEBUG - 2022-09-03 01:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:19:33 --> Total execution time: 0.1192
DEBUG - 2022-09-03 01:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:50:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:20:57 --> Total execution time: 0.0615
DEBUG - 2022-09-03 01:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:23:37 --> Total execution time: 0.1114
DEBUG - 2022-09-03 01:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:53:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:23:44 --> Total execution time: 0.1213
DEBUG - 2022-09-03 01:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:23:56 --> Total execution time: 0.0973
DEBUG - 2022-09-03 01:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:24:07 --> Total execution time: 0.1057
DEBUG - 2022-09-03 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:24:11 --> Total execution time: 0.0695
DEBUG - 2022-09-03 01:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:24:33 --> Total execution time: 0.0612
DEBUG - 2022-09-03 01:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:24:36 --> Total execution time: 0.0588
DEBUG - 2022-09-03 01:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:54:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:24:37 --> Total execution time: 0.0591
DEBUG - 2022-09-03 01:57:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:21 --> Total execution time: 0.0749
DEBUG - 2022-09-03 01:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:22 --> Total execution time: 0.0643
DEBUG - 2022-09-03 01:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:27 --> Total execution time: 0.0978
DEBUG - 2022-09-03 01:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:29 --> Total execution time: 0.0592
DEBUG - 2022-09-03 01:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 01:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:34 --> Total execution time: 0.1026
DEBUG - 2022-09-03 01:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:57:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:42 --> Total execution time: 0.1755
DEBUG - 2022-09-03 01:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:58:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:28:24 --> Total execution time: 0.1073
DEBUG - 2022-09-03 01:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 01:59:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 01:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 01:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:29:07 --> Total execution time: 0.0776
DEBUG - 2022-09-03 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:30:02 --> Total execution time: 0.1134
DEBUG - 2022-09-03 02:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:30:52 --> Total execution time: 0.0939
DEBUG - 2022-09-03 02:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:03:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 02:03:40 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-03 02:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:35:59 --> Total execution time: 0.2135
DEBUG - 2022-09-03 02:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 02:05:59 --> 404 Page Not Found: Credentialsphp/index
DEBUG - 2022-09-03 02:06:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:06:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:36:28 --> Total execution time: 0.1310
DEBUG - 2022-09-03 02:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:36:44 --> Total execution time: 0.1004
DEBUG - 2022-09-03 02:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:36:55 --> Total execution time: 0.0897
DEBUG - 2022-09-03 02:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:37:09 --> Total execution time: 0.0999
DEBUG - 2022-09-03 02:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:37:53 --> Total execution time: 0.1092
DEBUG - 2022-09-03 02:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:06 --> Total execution time: 0.1019
DEBUG - 2022-09-03 02:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:07 --> Total execution time: 0.0897
DEBUG - 2022-09-03 02:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:13 --> Total execution time: 0.1028
DEBUG - 2022-09-03 02:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:28 --> Total execution time: 0.0995
DEBUG - 2022-09-03 02:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:37 --> Total execution time: 0.0682
DEBUG - 2022-09-03 02:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:38 --> Total execution time: 0.0701
DEBUG - 2022-09-03 02:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:47 --> Total execution time: 0.1563
DEBUG - 2022-09-03 02:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:38:54 --> Total execution time: 0.1433
DEBUG - 2022-09-03 02:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:12:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:42:11 --> Total execution time: 0.3667
DEBUG - 2022-09-03 02:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:12:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:42:26 --> Total execution time: 0.1110
DEBUG - 2022-09-03 02:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:12:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:12:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:42:37 --> Total execution time: 0.1066
DEBUG - 2022-09-03 02:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:44:07 --> Total execution time: 0.0999
DEBUG - 2022-09-03 02:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:14:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:44:15 --> Total execution time: 0.1256
DEBUG - 2022-09-03 02:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:44:20 --> Total execution time: 0.4699
DEBUG - 2022-09-03 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:15:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:45:17 --> Total execution time: 0.0797
DEBUG - 2022-09-03 02:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:45:37 --> Total execution time: 0.0593
DEBUG - 2022-09-03 02:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:15:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:45:47 --> Total execution time: 0.0969
DEBUG - 2022-09-03 02:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:46:12 --> Total execution time: 0.1189
DEBUG - 2022-09-03 02:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:16:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:46:12 --> Total execution time: 0.1197
DEBUG - 2022-09-03 02:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:46:33 --> Total execution time: 0.1392
DEBUG - 2022-09-03 02:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:18:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:48:57 --> Total execution time: 0.0833
DEBUG - 2022-09-03 02:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:49:02 --> Total execution time: 0.1181
DEBUG - 2022-09-03 02:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:51:37 --> Total execution time: 0.0605
DEBUG - 2022-09-03 02:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:22:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:52:32 --> Total execution time: 0.0881
DEBUG - 2022-09-03 02:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:53:14 --> Total execution time: 0.2715
DEBUG - 2022-09-03 02:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:53:21 --> Total execution time: 0.0929
DEBUG - 2022-09-03 02:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:53:32 --> Total execution time: 0.0953
DEBUG - 2022-09-03 02:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:53:38 --> Total execution time: 0.1031
DEBUG - 2022-09-03 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:23:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:53:52 --> Total execution time: 0.1359
DEBUG - 2022-09-03 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:54:13 --> Total execution time: 0.0962
DEBUG - 2022-09-03 02:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:55:48 --> Total execution time: 0.1000
DEBUG - 2022-09-03 02:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:26:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:56:29 --> Total execution time: 0.1164
DEBUG - 2022-09-03 02:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:56:38 --> Total execution time: 0.0741
DEBUG - 2022-09-03 02:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:29:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:29:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:59:24 --> Total execution time: 0.4438
DEBUG - 2022-09-03 02:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:29:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:29:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:59:25 --> Total execution time: 0.2589
DEBUG - 2022-09-03 02:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:29:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:59:39 --> Total execution time: 0.1028
DEBUG - 2022-09-03 02:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:29:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:59:40 --> Total execution time: 0.1026
DEBUG - 2022-09-03 02:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:03:02 --> Total execution time: 0.1042
DEBUG - 2022-09-03 02:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:33:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:03:10 --> Total execution time: 0.1108
DEBUG - 2022-09-03 02:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:03:16 --> Total execution time: 0.1167
DEBUG - 2022-09-03 02:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:03:54 --> Total execution time: 0.1088
DEBUG - 2022-09-03 02:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:37:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:07:45 --> Total execution time: 0.1364
DEBUG - 2022-09-03 02:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:07:46 --> Total execution time: 0.1316
DEBUG - 2022-09-03 02:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:38:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:08:38 --> Total execution time: 0.0738
DEBUG - 2022-09-03 02:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:38:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:08:39 --> Total execution time: 0.0920
DEBUG - 2022-09-03 02:40:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:40:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:10:30 --> Total execution time: 0.0928
DEBUG - 2022-09-03 02:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:19 --> Total execution time: 0.0977
DEBUG - 2022-09-03 02:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:44 --> Total execution time: 0.0655
DEBUG - 2022-09-03 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:46 --> Total execution time: 0.1242
DEBUG - 2022-09-03 02:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:53 --> Total execution time: 0.1184
DEBUG - 2022-09-03 02:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:54 --> Total execution time: 0.1074
DEBUG - 2022-09-03 02:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:42:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:12:56 --> Total execution time: 0.1157
DEBUG - 2022-09-03 02:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:01 --> Total execution time: 0.0972
DEBUG - 2022-09-03 02:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:02 --> Total execution time: 0.2762
DEBUG - 2022-09-03 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:05 --> Total execution time: 0.1262
DEBUG - 2022-09-03 02:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:06 --> Total execution time: 0.1788
DEBUG - 2022-09-03 02:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:06 --> Total execution time: 0.1431
DEBUG - 2022-09-03 02:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:12 --> Total execution time: 0.1043
DEBUG - 2022-09-03 02:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:23 --> Total execution time: 0.1011
DEBUG - 2022-09-03 02:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:43:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:13:59 --> Total execution time: 0.1274
DEBUG - 2022-09-03 02:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:14 --> Total execution time: 0.1217
DEBUG - 2022-09-03 02:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:30 --> Total execution time: 0.1202
DEBUG - 2022-09-03 02:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:31 --> Total execution time: 0.2774
DEBUG - 2022-09-03 02:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:43 --> Total execution time: 0.1255
DEBUG - 2022-09-03 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:47 --> Total execution time: 0.1058
DEBUG - 2022-09-03 02:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:47 --> Total execution time: 0.1093
DEBUG - 2022-09-03 02:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:50 --> Total execution time: 0.1369
DEBUG - 2022-09-03 02:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:55 --> Total execution time: 0.0977
DEBUG - 2022-09-03 02:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:55 --> Total execution time: 0.1915
DEBUG - 2022-09-03 02:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:44:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:14:59 --> Total execution time: 0.1280
DEBUG - 2022-09-03 02:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:02 --> Total execution time: 0.2137
DEBUG - 2022-09-03 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:06 --> Total execution time: 0.1296
DEBUG - 2022-09-03 02:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:09 --> Total execution time: 0.1062
DEBUG - 2022-09-03 02:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:17 --> Total execution time: 0.1078
DEBUG - 2022-09-03 02:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:41 --> Total execution time: 0.0987
DEBUG - 2022-09-03 02:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:45:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:15:47 --> Total execution time: 0.1006
DEBUG - 2022-09-03 02:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:49:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:19:41 --> Total execution time: 0.1407
DEBUG - 2022-09-03 02:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:50:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:50:39 --> Total execution time: 0.0960
DEBUG - 2022-09-03 02:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:50:41 --> Total execution time: 0.1053
DEBUG - 2022-09-03 02:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:50:42 --> Total execution time: 0.1004
DEBUG - 2022-09-03 02:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:51:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:21:32 --> Total execution time: 0.0671
DEBUG - 2022-09-03 02:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:22:12 --> Total execution time: 0.1076
DEBUG - 2022-09-03 02:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:22:15 --> Total execution time: 0.1208
DEBUG - 2022-09-03 02:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:54:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:24 --> Total execution time: 0.1783
DEBUG - 2022-09-03 02:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:25 --> Total execution time: 0.1313
DEBUG - 2022-09-03 02:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:36 --> Total execution time: 0.1203
DEBUG - 2022-09-03 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:54:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:37 --> Total execution time: 0.1239
DEBUG - 2022-09-03 02:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:25:29 --> Total execution time: 2.5680
DEBUG - 2022-09-03 02:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:55:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 02:55:34 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 02:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:55:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:25:50 --> Total execution time: 0.0620
DEBUG - 2022-09-03 02:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:57:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:27:08 --> Total execution time: 0.0928
DEBUG - 2022-09-03 02:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:28:19 --> Total execution time: 0.2935
DEBUG - 2022-09-03 02:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:59:52 --> No URI present. Default controller set.
DEBUG - 2022-09-03 02:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:59:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:29:52 --> Total execution time: 0.0659
DEBUG - 2022-09-03 02:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:59:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 02:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:29:54 --> Total execution time: 0.1024
DEBUG - 2022-09-03 02:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 02:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 02:59:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:29:55 --> Total execution time: 0.0993
DEBUG - 2022-09-03 03:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:30:02 --> Total execution time: 0.1359
DEBUG - 2022-09-03 03:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:09 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:30:09 --> Total execution time: 0.1305
DEBUG - 2022-09-03 03:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:00:15 --> Total execution time: 0.1100
DEBUG - 2022-09-03 03:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:00:17 --> Total execution time: 0.1028
DEBUG - 2022-09-03 03:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:00:17 --> Total execution time: 0.1117
DEBUG - 2022-09-03 03:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:30:37 --> Total execution time: 0.0611
DEBUG - 2022-09-03 03:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:02:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:32:25 --> Total execution time: 0.0775
DEBUG - 2022-09-03 03:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:32:33 --> Total execution time: 0.0595
DEBUG - 2022-09-03 03:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:02:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:02:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:32:45 --> Total execution time: 0.1177
DEBUG - 2022-09-03 03:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:02:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:32:52 --> Total execution time: 0.1220
DEBUG - 2022-09-03 03:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:03:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:33:02 --> Total execution time: 0.1083
DEBUG - 2022-09-03 03:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:03:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:33:39 --> Total execution time: 0.0982
DEBUG - 2022-09-03 03:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:33:57 --> Total execution time: 0.0987
DEBUG - 2022-09-03 03:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:34:09 --> Total execution time: 0.1068
DEBUG - 2022-09-03 03:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:04:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:34:27 --> Total execution time: 0.0978
DEBUG - 2022-09-03 03:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:19 --> Total execution time: 0.2734
DEBUG - 2022-09-03 03:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:25 --> Total execution time: 0.1213
DEBUG - 2022-09-03 03:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:28 --> Total execution time: 0.0796
DEBUG - 2022-09-03 03:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:35 --> Total execution time: 0.0970
DEBUG - 2022-09-03 03:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:45 --> Total execution time: 0.0959
DEBUG - 2022-09-03 03:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:47 --> Total execution time: 0.0999
DEBUG - 2022-09-03 03:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:51 --> Total execution time: 1.9716
DEBUG - 2022-09-03 03:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:54 --> Total execution time: 0.0922
DEBUG - 2022-09-03 03:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:05:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 03:05:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 03:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:04 --> Total execution time: 0.0960
DEBUG - 2022-09-03 03:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:05 --> Total execution time: 0.0954
DEBUG - 2022-09-03 03:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:27 --> Total execution time: 0.0974
DEBUG - 2022-09-03 03:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:36 --> Total execution time: 0.1085
DEBUG - 2022-09-03 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:47 --> Total execution time: 0.1386
DEBUG - 2022-09-03 03:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:49 --> Total execution time: 0.1036
DEBUG - 2022-09-03 03:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:49 --> Total execution time: 0.0940
DEBUG - 2022-09-03 03:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:51 --> Total execution time: 0.2897
DEBUG - 2022-09-03 03:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:56 --> Total execution time: 0.0670
DEBUG - 2022-09-03 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:56 --> Total execution time: 0.1109
DEBUG - 2022-09-03 03:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:06 --> Total execution time: 0.1030
DEBUG - 2022-09-03 03:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:14 --> Total execution time: 0.1007
DEBUG - 2022-09-03 03:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:19 --> Total execution time: 0.1505
DEBUG - 2022-09-03 03:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:23 --> Total execution time: 0.1112
DEBUG - 2022-09-03 03:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:31 --> Total execution time: 0.1411
DEBUG - 2022-09-03 03:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:32 --> Total execution time: 0.1014
DEBUG - 2022-09-03 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:41 --> Total execution time: 0.1284
DEBUG - 2022-09-03 03:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:57 --> Total execution time: 0.1019
DEBUG - 2022-09-03 03:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:10:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:40:18 --> Total execution time: 0.1787
DEBUG - 2022-09-03 03:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:41:27 --> Total execution time: 0.0702
DEBUG - 2022-09-03 03:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:11:27 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:11:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:41:27 --> Total execution time: 0.0617
DEBUG - 2022-09-03 03:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:11:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:11:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:41:54 --> Total execution time: 0.1061
DEBUG - 2022-09-03 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:12:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:42:04 --> Total execution time: 0.2709
DEBUG - 2022-09-03 03:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:42:24 --> Total execution time: 0.0964
DEBUG - 2022-09-03 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:42:43 --> Total execution time: 0.1016
DEBUG - 2022-09-03 03:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:12:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:42:51 --> Total execution time: 0.1172
DEBUG - 2022-09-03 03:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:13:03 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:43:03 --> Total execution time: 0.0987
DEBUG - 2022-09-03 03:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:43:09 --> Total execution time: 0.1188
DEBUG - 2022-09-03 03:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:44:34 --> Total execution time: 0.1210
DEBUG - 2022-09-03 03:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:15 --> Total execution time: 0.1104
DEBUG - 2022-09-03 03:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:22 --> Total execution time: 0.0977
DEBUG - 2022-09-03 03:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:15:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:54 --> Total execution time: 0.0797
DEBUG - 2022-09-03 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:16:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:25 --> Total execution time: 0.0993
DEBUG - 2022-09-03 03:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:32 --> Total execution time: 0.1300
DEBUG - 2022-09-03 03:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:42 --> Total execution time: 0.1100
DEBUG - 2022-09-03 03:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:16:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:55 --> Total execution time: 0.1002
DEBUG - 2022-09-03 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:17:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:17:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:47:03 --> Total execution time: 0.0891
DEBUG - 2022-09-03 03:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:18:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:48:39 --> Total execution time: 0.0718
DEBUG - 2022-09-03 03:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:19:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:19:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:49:17 --> Total execution time: 0.0628
DEBUG - 2022-09-03 03:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:19:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:19:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:49:51 --> Total execution time: 0.0642
DEBUG - 2022-09-03 03:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:21:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:21:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:51:24 --> Total execution time: 0.1082
DEBUG - 2022-09-03 03:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:51:42 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 03:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:51:43 --> Total execution time: 0.1048
DEBUG - 2022-09-03 03:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:22:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:52:19 --> Total execution time: 0.1125
DEBUG - 2022-09-03 03:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:22:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:52:20 --> Total execution time: 0.0956
DEBUG - 2022-09-03 03:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:22:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:52:25 --> Total execution time: 0.0660
DEBUG - 2022-09-03 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:22:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:52:28 --> Total execution time: 0.1216
DEBUG - 2022-09-03 03:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:53:07 --> Total execution time: 0.0959
DEBUG - 2022-09-03 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:23:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:23:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:53:48 --> Total execution time: 0.0631
DEBUG - 2022-09-03 03:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:23:53 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:53:53 --> Total execution time: 0.1070
DEBUG - 2022-09-03 03:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:53:59 --> Total execution time: 0.2460
DEBUG - 2022-09-03 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:54:05 --> Total execution time: 0.1072
DEBUG - 2022-09-03 03:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:54:10 --> Total execution time: 0.1477
DEBUG - 2022-09-03 03:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:25:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:55:08 --> Total execution time: 0.2866
DEBUG - 2022-09-03 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:26:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:56:12 --> Total execution time: 0.1094
DEBUG - 2022-09-03 03:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:30:03 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:00:03 --> Total execution time: 0.1637
DEBUG - 2022-09-03 03:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:01:38 --> Total execution time: 0.2856
DEBUG - 2022-09-03 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:02:01 --> Total execution time: 0.1236
DEBUG - 2022-09-03 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:02:47 --> Total execution time: 0.1088
DEBUG - 2022-09-03 03:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:33:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:07 --> Total execution time: 0.2834
DEBUG - 2022-09-03 03:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:33:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:33:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:23 --> Total execution time: 0.0979
DEBUG - 2022-09-03 03:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:33:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:35 --> Total execution time: 0.0955
DEBUG - 2022-09-03 03:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:33:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:33:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:42 --> Total execution time: 0.0691
DEBUG - 2022-09-03 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:46 --> Total execution time: 0.0921
DEBUG - 2022-09-03 03:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:03 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:03 --> Total execution time: 0.1734
DEBUG - 2022-09-03 03:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:08 --> Total execution time: 0.1030
DEBUG - 2022-09-03 03:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:11 --> Total execution time: 0.1130
DEBUG - 2022-09-03 03:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:12 --> Total execution time: 0.0636
DEBUG - 2022-09-03 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:19 --> Total execution time: 0.0700
DEBUG - 2022-09-03 03:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:21 --> Total execution time: 0.0598
DEBUG - 2022-09-03 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:23 --> Total execution time: 0.1414
DEBUG - 2022-09-03 03:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:23 --> Total execution time: 0.0641
DEBUG - 2022-09-03 03:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:28 --> Total execution time: 0.0996
DEBUG - 2022-09-03 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:33 --> Total execution time: 0.0969
DEBUG - 2022-09-03 03:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:38 --> Total execution time: 0.1132
DEBUG - 2022-09-03 03:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:40 --> Total execution time: 0.0600
DEBUG - 2022-09-03 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:41 --> Total execution time: 0.1039
DEBUG - 2022-09-03 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:45 --> Total execution time: 0.0946
DEBUG - 2022-09-03 03:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:46 --> Total execution time: 0.1296
DEBUG - 2022-09-03 03:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:49 --> Total execution time: 0.1150
DEBUG - 2022-09-03 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:54 --> Total execution time: 0.1130
DEBUG - 2022-09-03 03:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:01 --> Total execution time: 0.1159
DEBUG - 2022-09-03 03:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:35:06 --> Total execution time: 0.0903
DEBUG - 2022-09-03 03:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:07 --> Total execution time: 0.0956
DEBUG - 2022-09-03 03:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:08 --> Total execution time: 0.0959
DEBUG - 2022-09-03 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:35:10 --> Total execution time: 0.0954
DEBUG - 2022-09-03 03:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:35:10 --> Total execution time: 0.0964
DEBUG - 2022-09-03 03:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:15 --> Total execution time: 0.0894
DEBUG - 2022-09-03 03:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:23 --> Total execution time: 0.1726
DEBUG - 2022-09-03 03:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:55 --> Total execution time: 0.1069
DEBUG - 2022-09-03 03:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:59 --> Total execution time: 0.0916
DEBUG - 2022-09-03 03:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:36:02 --> Total execution time: 0.0876
DEBUG - 2022-09-03 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:36:05 --> Total execution time: 0.0927
DEBUG - 2022-09-03 03:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:36:06 --> Total execution time: 0.0987
DEBUG - 2022-09-03 03:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:06:21 --> Total execution time: 0.0948
DEBUG - 2022-09-03 03:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:06:48 --> Total execution time: 0.1073
DEBUG - 2022-09-03 03:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:06:58 --> Total execution time: 0.0929
DEBUG - 2022-09-03 03:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:03 --> Total execution time: 0.0966
DEBUG - 2022-09-03 03:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:07 --> Total execution time: 0.1010
DEBUG - 2022-09-03 03:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:16 --> Total execution time: 0.0971
DEBUG - 2022-09-03 03:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:18 --> Total execution time: 0.1140
DEBUG - 2022-09-03 03:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:23 --> Total execution time: 0.1018
DEBUG - 2022-09-03 03:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:33 --> Total execution time: 0.0943
DEBUG - 2022-09-03 03:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:40 --> Total execution time: 0.1012
DEBUG - 2022-09-03 03:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:37:41 --> Total execution time: 0.0920
DEBUG - 2022-09-03 03:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:37:46 --> Total execution time: 0.1017
DEBUG - 2022-09-03 03:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:37:46 --> Total execution time: 0.0969
DEBUG - 2022-09-03 03:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:51 --> Total execution time: 0.1039
DEBUG - 2022-09-03 03:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:38:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:38:38 --> Total execution time: 0.0959
DEBUG - 2022-09-03 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:38:40 --> Total execution time: 0.1002
DEBUG - 2022-09-03 03:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:38:41 --> Total execution time: 0.0932
DEBUG - 2022-09-03 03:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:39:27 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:39:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:09:28 --> Total execution time: 0.2764
DEBUG - 2022-09-03 03:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:41:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:41:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:11:19 --> Total execution time: 0.0872
DEBUG - 2022-09-03 14:11:19 --> Total execution time: 0.0959
DEBUG - 2022-09-03 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:12:17 --> Total execution time: 0.0977
DEBUG - 2022-09-03 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:45:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:15:33 --> Total execution time: 0.0636
DEBUG - 2022-09-03 03:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:47:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:17:14 --> Total execution time: 0.0690
DEBUG - 2022-09-03 03:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:47:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:17:50 --> Total execution time: 0.0652
DEBUG - 2022-09-03 03:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:49:27 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:19:27 --> Total execution time: 0.0650
DEBUG - 2022-09-03 03:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:19:32 --> Total execution time: 0.0944
DEBUG - 2022-09-03 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:19:46 --> Total execution time: 0.1114
DEBUG - 2022-09-03 03:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:20:01 --> Total execution time: 0.3965
DEBUG - 2022-09-03 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:50:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:50:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:20:28 --> Total execution time: 0.0753
DEBUG - 2022-09-03 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:50:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:20:29 --> Total execution time: 0.0792
DEBUG - 2022-09-03 03:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:52:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:22:13 --> Total execution time: 0.0873
DEBUG - 2022-09-03 03:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:52:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:22:18 --> Total execution time: 0.0670
DEBUG - 2022-09-03 03:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:24:10 --> Total execution time: 0.1024
DEBUG - 2022-09-03 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:02 --> Total execution time: 0.1463
DEBUG - 2022-09-03 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:09 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:10 --> Total execution time: 0.2783
DEBUG - 2022-09-03 03:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:55:17 --> Total execution time: 0.1053
DEBUG - 2022-09-03 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:18 --> Total execution time: 0.1149
DEBUG - 2022-09-03 03:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:55:19 --> Total execution time: 0.0974
DEBUG - 2022-09-03 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:55:20 --> Total execution time: 0.0920
DEBUG - 2022-09-03 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:42 --> Total execution time: 0.1135
DEBUG - 2022-09-03 03:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:54 --> Total execution time: 0.1091
DEBUG - 2022-09-03 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:25:59 --> Total execution time: 2.4222
DEBUG - 2022-09-03 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 03:56:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 03:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:56:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:26:30 --> Total execution time: 0.1796
DEBUG - 2022-09-03 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:56:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:26:59 --> Total execution time: 0.1522
DEBUG - 2022-09-03 03:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:27:17 --> Total execution time: 0.0827
DEBUG - 2022-09-03 03:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:27:39 --> Total execution time: 0.1116
DEBUG - 2022-09-03 03:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:27:50 --> Total execution time: 0.1047
DEBUG - 2022-09-03 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:27:58 --> Total execution time: 0.0964
DEBUG - 2022-09-03 03:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:20 --> Total execution time: 0.0707
DEBUG - 2022-09-03 03:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:22 --> Total execution time: 0.0563
DEBUG - 2022-09-03 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:32 --> Total execution time: 0.0711
DEBUG - 2022-09-03 03:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:43 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:43 --> Total execution time: 0.2535
DEBUG - 2022-09-03 03:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:45 --> Total execution time: 0.0996
DEBUG - 2022-09-03 03:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:12 --> Total execution time: 0.1016
DEBUG - 2022-09-03 03:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:13 --> Total execution time: 0.5443
DEBUG - 2022-09-03 03:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 03:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:17 --> Total execution time: 0.1017
DEBUG - 2022-09-03 03:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:17 --> Total execution time: 0.1014
DEBUG - 2022-09-03 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:20 --> Total execution time: 0.1066
DEBUG - 2022-09-03 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:20 --> Total execution time: 0.1061
DEBUG - 2022-09-03 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:20 --> Total execution time: 0.1340
DEBUG - 2022-09-03 03:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:25 --> Total execution time: 0.1439
DEBUG - 2022-09-03 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:26 --> Total execution time: 0.0993
DEBUG - 2022-09-03 03:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 03:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 03:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:30 --> Total execution time: 0.1293
DEBUG - 2022-09-03 04:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:30:02 --> Total execution time: 0.2477
DEBUG - 2022-09-03 04:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:30:54 --> Total execution time: 0.1272
DEBUG - 2022-09-03 04:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:02 --> Total execution time: 0.2700
DEBUG - 2022-09-03 04:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:03 --> Total execution time: 0.1123
DEBUG - 2022-09-03 04:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:03 --> Total execution time: 0.1133
DEBUG - 2022-09-03 04:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:11 --> Total execution time: 0.1233
DEBUG - 2022-09-03 04:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:29 --> Total execution time: 0.1353
DEBUG - 2022-09-03 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:32 --> Total execution time: 0.1062
DEBUG - 2022-09-03 04:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:39 --> Total execution time: 0.1045
DEBUG - 2022-09-03 04:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:44 --> Total execution time: 0.1183
DEBUG - 2022-09-03 04:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:47 --> Total execution time: 0.1071
DEBUG - 2022-09-03 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:55 --> Total execution time: 0.1904
DEBUG - 2022-09-03 04:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:31:57 --> Total execution time: 0.1097
DEBUG - 2022-09-03 04:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:05 --> Total execution time: 0.1606
DEBUG - 2022-09-03 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:06 --> Total execution time: 0.0946
DEBUG - 2022-09-03 04:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:13 --> Total execution time: 0.1355
DEBUG - 2022-09-03 04:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:14 --> Total execution time: 0.1410
DEBUG - 2022-09-03 04:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:18 --> Total execution time: 0.0975
DEBUG - 2022-09-03 04:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:23 --> Total execution time: 0.1058
DEBUG - 2022-09-03 04:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:34 --> Total execution time: 0.0915
DEBUG - 2022-09-03 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:37 --> Total execution time: 0.0904
DEBUG - 2022-09-03 04:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:40 --> Total execution time: 0.0973
DEBUG - 2022-09-03 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:46 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:46 --> Total execution time: 0.1059
DEBUG - 2022-09-03 04:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:47 --> Total execution time: 0.1189
DEBUG - 2022-09-03 04:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:53 --> Total execution time: 0.1454
DEBUG - 2022-09-03 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:57 --> Total execution time: 2.0214
DEBUG - 2022-09-03 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:32:59 --> Total execution time: 0.1493
DEBUG - 2022-09-03 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:01 --> Total execution time: 0.0719
DEBUG - 2022-09-03 04:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:03 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:03 --> Total execution time: 0.1132
DEBUG - 2022-09-03 04:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:08 --> Total execution time: 0.1900
DEBUG - 2022-09-03 04:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:03:13 --> Total execution time: 0.0972
DEBUG - 2022-09-03 04:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:03:15 --> Total execution time: 0.1107
DEBUG - 2022-09-03 04:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:03:15 --> Total execution time: 0.0991
DEBUG - 2022-09-03 04:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:20 --> Total execution time: 0.4232
DEBUG - 2022-09-03 04:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:30 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 04:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:33 --> Total execution time: 0.1305
DEBUG - 2022-09-03 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:41 --> Total execution time: 0.1038
DEBUG - 2022-09-03 04:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:03:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:50 --> Total execution time: 0.0753
DEBUG - 2022-09-03 04:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:09 --> Total execution time: 0.1113
DEBUG - 2022-09-03 04:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:04:17 --> Total execution time: 0.1065
DEBUG - 2022-09-03 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:19 --> Total execution time: 0.2881
DEBUG - 2022-09-03 04:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:04:20 --> Total execution time: 0.1014
DEBUG - 2022-09-03 04:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:04:20 --> Total execution time: 0.1096
DEBUG - 2022-09-03 04:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:33 --> Total execution time: 0.1390
DEBUG - 2022-09-03 04:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:34 --> Total execution time: 0.1002
DEBUG - 2022-09-03 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:39 --> Total execution time: 0.1158
DEBUG - 2022-09-03 04:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:42 --> Total execution time: 0.1108
DEBUG - 2022-09-03 04:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:46 --> Total execution time: 0.1254
DEBUG - 2022-09-03 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:04:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:34:53 --> Total execution time: 1.9352
DEBUG - 2022-09-03 04:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:04:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 04:04:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:17 --> Total execution time: 0.0982
DEBUG - 2022-09-03 04:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:23 --> Total execution time: 0.1484
DEBUG - 2022-09-03 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:28 --> Total execution time: 0.0956
DEBUG - 2022-09-03 04:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:29 --> Total execution time: 1.7969
DEBUG - 2022-09-03 14:35:31 --> Total execution time: 1.9982
DEBUG - 2022-09-03 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:34 --> Total execution time: 0.2850
DEBUG - 2022-09-03 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:35 --> Total execution time: 0.1231
DEBUG - 2022-09-03 04:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:36 --> Total execution time: 0.0947
DEBUG - 2022-09-03 04:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:39 --> Total execution time: 1.7286
DEBUG - 2022-09-03 04:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:40 --> Total execution time: 0.1531
DEBUG - 2022-09-03 04:05:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:40 --> Total execution time: 0.1181
DEBUG - 2022-09-03 04:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:43 --> Total execution time: 0.0604
DEBUG - 2022-09-03 04:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:45 --> Total execution time: 0.1667
DEBUG - 2022-09-03 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:46 --> Total execution time: 0.0977
DEBUG - 2022-09-03 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:48 --> Total execution time: 0.1440
DEBUG - 2022-09-03 04:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:51 --> Total execution time: 0.1297
DEBUG - 2022-09-03 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:53 --> Total execution time: 0.1386
DEBUG - 2022-09-03 04:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:54 --> Total execution time: 0.1024
DEBUG - 2022-09-03 04:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:58 --> Total execution time: 0.1218
DEBUG - 2022-09-03 04:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:35:59 --> Total execution time: 0.1374
DEBUG - 2022-09-03 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:05 --> Total execution time: 0.1101
DEBUG - 2022-09-03 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:07 --> Total execution time: 0.0987
DEBUG - 2022-09-03 04:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:19 --> Total execution time: 0.1227
DEBUG - 2022-09-03 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:21 --> Total execution time: 0.1367
DEBUG - 2022-09-03 04:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:25 --> Total execution time: 0.1296
DEBUG - 2022-09-03 04:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:26 --> Total execution time: 0.1797
DEBUG - 2022-09-03 04:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:29 --> Total execution time: 0.1168
DEBUG - 2022-09-03 04:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:31 --> Total execution time: 0.1191
DEBUG - 2022-09-03 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:35 --> Total execution time: 0.1255
DEBUG - 2022-09-03 04:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:53 --> Total execution time: 0.0967
DEBUG - 2022-09-03 04:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:55 --> Total execution time: 0.2832
DEBUG - 2022-09-03 04:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:36:58 --> Total execution time: 0.1018
DEBUG - 2022-09-03 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:07 --> Total execution time: 0.1053
DEBUG - 2022-09-03 04:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:09 --> Total execution time: 0.2689
DEBUG - 2022-09-03 04:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:20 --> Total execution time: 1.8290
DEBUG - 2022-09-03 04:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:27 --> Total execution time: 1.8994
DEBUG - 2022-09-03 04:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:32 --> Total execution time: 0.1073
DEBUG - 2022-09-03 04:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:36 --> Total execution time: 0.2188
DEBUG - 2022-09-03 04:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:39 --> Total execution time: 0.1487
DEBUG - 2022-09-03 04:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:44 --> Total execution time: 0.1010
DEBUG - 2022-09-03 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:45 --> Total execution time: 0.1277
DEBUG - 2022-09-03 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:48 --> Total execution time: 0.1214
DEBUG - 2022-09-03 04:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:52 --> Total execution time: 0.1334
DEBUG - 2022-09-03 04:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:07:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:55 --> Total execution time: 0.1372
DEBUG - 2022-09-03 04:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:08:02 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:08:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:38:02 --> Total execution time: 0.0785
DEBUG - 2022-09-03 04:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:39:03 --> Total execution time: 0.1033
DEBUG - 2022-09-03 04:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:10:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:10:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:40:45 --> Total execution time: 0.2511
DEBUG - 2022-09-03 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:12:16 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:42:16 --> Total execution time: 0.0801
DEBUG - 2022-09-03 04:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:12:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:42:17 --> Total execution time: 0.0696
DEBUG - 2022-09-03 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:12:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:42:51 --> Total execution time: 0.2643
DEBUG - 2022-09-03 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:43:00 --> Total execution time: 0.1167
DEBUG - 2022-09-03 04:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:13:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:43:06 --> Total execution time: 0.1207
DEBUG - 2022-09-03 04:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:43:38 --> Total execution time: 0.1309
DEBUG - 2022-09-03 04:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:14:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:44:18 --> Total execution time: 0.0689
DEBUG - 2022-09-03 04:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:49:23 --> Total execution time: 0.3788
DEBUG - 2022-09-03 04:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:19:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:49:41 --> Total execution time: 0.0674
DEBUG - 2022-09-03 04:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:20:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:50:01 --> Total execution time: 0.1073
DEBUG - 2022-09-03 04:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:50:12 --> Total execution time: 0.1630
DEBUG - 2022-09-03 04:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:20:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:50:41 --> Total execution time: 0.1293
DEBUG - 2022-09-03 04:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:51:12 --> Total execution time: 0.1095
DEBUG - 2022-09-03 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:22:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:22:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:52:55 --> Total execution time: 0.0640
DEBUG - 2022-09-03 04:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:22:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:22:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:52:56 --> Total execution time: 0.0616
DEBUG - 2022-09-03 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:36 --> Total execution time: 0.0807
DEBUG - 2022-09-03 04:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:37 --> Total execution time: 0.0751
DEBUG - 2022-09-03 04:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:37 --> Total execution time: 0.0730
DEBUG - 2022-09-03 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:39 --> Total execution time: 0.1302
DEBUG - 2022-09-03 04:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:40 --> Total execution time: 0.1443
DEBUG - 2022-09-03 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 04:23:45 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-09-03 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:23:47 --> Total execution time: 0.1035
DEBUG - 2022-09-03 04:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:53:55 --> Total execution time: 0.0644
DEBUG - 2022-09-03 04:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:54:06 --> Total execution time: 0.1005
DEBUG - 2022-09-03 04:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:54:10 --> Total execution time: 0.1068
DEBUG - 2022-09-03 04:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:54:14 --> Total execution time: 0.1006
DEBUG - 2022-09-03 04:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:54:23 --> Total execution time: 0.1113
DEBUG - 2022-09-03 04:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:24:47 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:54:47 --> Total execution time: 0.2511
DEBUG - 2022-09-03 04:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:25:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:25:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:55:23 --> Total execution time: 0.0608
DEBUG - 2022-09-03 04:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:25:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:55:55 --> Total execution time: 0.1013
DEBUG - 2022-09-03 04:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:26:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:56:05 --> Total execution time: 2.3916
DEBUG - 2022-09-03 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:56:28 --> Total execution time: 2.0278
DEBUG - 2022-09-03 04:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 04:26:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:57:17 --> Total execution time: 0.0661
DEBUG - 2022-09-03 04:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:01:14 --> Total execution time: 0.1057
DEBUG - 2022-09-03 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:01:51 --> Total execution time: 2.1912
DEBUG - 2022-09-03 04:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:01:57 --> Total execution time: 1.7269
DEBUG - 2022-09-03 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:32:52 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:02:52 --> Total execution time: 0.1069
DEBUG - 2022-09-03 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:03:04 --> Total execution time: 1.8440
DEBUG - 2022-09-03 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:03:07 --> Total execution time: 1.8197
DEBUG - 2022-09-03 04:33:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:03:09 --> Total execution time: 2.5182
DEBUG - 2022-09-03 04:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:03:55 --> Total execution time: 0.2761
DEBUG - 2022-09-03 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:33:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:03:57 --> Total execution time: 0.1522
DEBUG - 2022-09-03 04:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:35:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:05:21 --> Total execution time: 0.0993
DEBUG - 2022-09-03 04:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:08:33 --> Total execution time: 0.3374
DEBUG - 2022-09-03 04:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:38:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:08:35 --> Total execution time: 0.1058
DEBUG - 2022-09-03 04:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:41:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:11:07 --> Total execution time: 0.1585
DEBUG - 2022-09-03 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:00 --> Total execution time: 0.5608
DEBUG - 2022-09-03 04:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:01 --> Total execution time: 0.2849
DEBUG - 2022-09-03 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:17 --> Total execution time: 0.1212
DEBUG - 2022-09-03 04:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:17 --> Total execution time: 0.0926
DEBUG - 2022-09-03 04:42:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:28 --> Total execution time: 0.1221
DEBUG - 2022-09-03 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:12:50 --> Total execution time: 0.2144
DEBUG - 2022-09-03 04:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:43:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:13:23 --> Total execution time: 0.0782
DEBUG - 2022-09-03 04:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:43:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:13:42 --> Total execution time: 0.0640
DEBUG - 2022-09-03 04:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:43:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:43:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:13:58 --> Total execution time: 0.0648
DEBUG - 2022-09-03 04:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:45:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:45:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:15:15 --> Total execution time: 0.0745
DEBUG - 2022-09-03 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:45:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:15:41 --> Total execution time: 0.1495
DEBUG - 2022-09-03 04:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:45:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:45:59 --> Total execution time: 0.0989
DEBUG - 2022-09-03 04:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:46:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:46:00 --> Total execution time: 0.1023
DEBUG - 2022-09-03 04:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:46:01 --> Total execution time: 0.0978
DEBUG - 2022-09-03 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:18:24 --> Total execution time: 0.1032
DEBUG - 2022-09-03 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:48:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:18:29 --> Total execution time: 0.0971
DEBUG - 2022-09-03 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:48:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:18:43 --> Total execution time: 2.5162
DEBUG - 2022-09-03 04:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:48:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 04:48:48 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:19:02 --> Total execution time: 0.0941
DEBUG - 2022-09-03 04:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:19:18 --> Total execution time: 0.0891
DEBUG - 2022-09-03 04:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:19:26 --> Total execution time: 0.1026
DEBUG - 2022-09-03 04:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:19:37 --> Total execution time: 0.1120
DEBUG - 2022-09-03 04:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:49:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:19:53 --> Total execution time: 0.0970
DEBUG - 2022-09-03 04:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:03 --> Total execution time: 0.0986
DEBUG - 2022-09-03 04:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:15 --> Total execution time: 0.1128
DEBUG - 2022-09-03 04:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:20 --> Total execution time: 0.1011
DEBUG - 2022-09-03 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:48 --> Total execution time: 0.0987
DEBUG - 2022-09-03 04:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:51 --> Total execution time: 0.2584
DEBUG - 2022-09-03 04:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:20:59 --> Total execution time: 0.1261
DEBUG - 2022-09-03 04:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:21:02 --> Total execution time: 0.1068
DEBUG - 2022-09-03 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:51:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:21:04 --> Total execution time: 0.1367
DEBUG - 2022-09-03 04:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:21:11 --> Total execution time: 0.1086
DEBUG - 2022-09-03 04:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:22:03 --> Total execution time: 0.0990
DEBUG - 2022-09-03 04:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:52:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:22:11 --> Total execution time: 0.1267
DEBUG - 2022-09-03 04:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:22:13 --> Total execution time: 0.1112
DEBUG - 2022-09-03 04:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:22:16 --> Total execution time: 1.5977
DEBUG - 2022-09-03 04:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:52:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:22:34 --> Total execution time: 0.0822
DEBUG - 2022-09-03 04:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:53:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:23:55 --> Total execution time: 0.1022
DEBUG - 2022-09-03 04:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:07 --> Total execution time: 1.8021
DEBUG - 2022-09-03 04:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:19 --> Total execution time: 0.0598
DEBUG - 2022-09-03 04:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:25 --> Total execution time: 0.0905
DEBUG - 2022-09-03 04:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:30 --> Total execution time: 1.9630
DEBUG - 2022-09-03 04:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:37 --> Total execution time: 0.0892
DEBUG - 2022-09-03 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:54:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:44 --> Total execution time: 0.1225
DEBUG - 2022-09-03 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:25:00 --> Total execution time: 0.1323
DEBUG - 2022-09-03 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:25:01 --> Total execution time: 0.1525
DEBUG - 2022-09-03 04:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:55:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:25:39 --> Total execution time: 0.1219
DEBUG - 2022-09-03 04:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:55:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:25:53 --> Total execution time: 0.2944
DEBUG - 2022-09-03 04:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:55:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:25:55 --> Total execution time: 0.1023
DEBUG - 2022-09-03 04:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:56:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:26:07 --> Total execution time: 0.1018
DEBUG - 2022-09-03 04:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:56:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:26:25 --> Total execution time: 0.1023
DEBUG - 2022-09-03 04:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:26:44 --> Total execution time: 0.0960
DEBUG - 2022-09-03 04:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:57:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:27:13 --> Total execution time: 0.0921
DEBUG - 2022-09-03 04:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:27:22 --> Total execution time: 0.0904
DEBUG - 2022-09-03 04:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:27:37 --> Total execution time: 0.1007
DEBUG - 2022-09-03 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:27:56 --> Total execution time: 0.1175
DEBUG - 2022-09-03 04:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:58:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:28:21 --> Total execution time: 0.0964
DEBUG - 2022-09-03 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:28:36 --> Total execution time: 0.2849
DEBUG - 2022-09-03 04:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:28:59 --> Total execution time: 0.1086
DEBUG - 2022-09-03 04:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 04:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:19 --> Total execution time: 0.1199
DEBUG - 2022-09-03 04:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:23 --> Total execution time: 0.2769
DEBUG - 2022-09-03 04:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:30 --> Total execution time: 0.1012
DEBUG - 2022-09-03 04:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:34 --> Total execution time: 0.0937
DEBUG - 2022-09-03 04:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:35 --> Total execution time: 0.1144
DEBUG - 2022-09-03 04:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:50 --> Total execution time: 0.0977
DEBUG - 2022-09-03 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:50 --> Total execution time: 0.0980
DEBUG - 2022-09-03 04:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:50 --> Total execution time: 0.1052
DEBUG - 2022-09-03 04:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 04:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 04:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:57 --> Total execution time: 0.1912
DEBUG - 2022-09-03 05:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:02 --> Total execution time: 0.0907
DEBUG - 2022-09-03 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:04 --> Total execution time: 0.1715
DEBUG - 2022-09-03 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:00:05 --> Total execution time: 0.1131
DEBUG - 2022-09-03 05:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:18 --> Total execution time: 0.1292
DEBUG - 2022-09-03 05:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:20 --> Total execution time: 0.1183
DEBUG - 2022-09-03 05:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:28 --> Total execution time: 0.1142
DEBUG - 2022-09-03 05:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:36 --> Total execution time: 0.1072
DEBUG - 2022-09-03 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:00:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:30:38 --> Total execution time: 0.1106
DEBUG - 2022-09-03 05:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:13 --> Total execution time: 0.1147
DEBUG - 2022-09-03 05:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:14 --> Total execution time: 0.1289
DEBUG - 2022-09-03 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:16 --> Total execution time: 0.0974
DEBUG - 2022-09-03 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:24 --> Total execution time: 0.1203
DEBUG - 2022-09-03 05:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:42 --> Total execution time: 0.0865
DEBUG - 2022-09-03 05:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:31:59 --> Total execution time: 0.1141
DEBUG - 2022-09-03 05:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:32:07 --> Total execution time: 0.1084
DEBUG - 2022-09-03 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:02:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:32:14 --> Total execution time: 0.0946
DEBUG - 2022-09-03 05:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:32:15 --> Total execution time: 0.1072
DEBUG - 2022-09-03 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 05:02:26 --> 404 Page Not Found: Category/business
DEBUG - 2022-09-03 05:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:32:58 --> Total execution time: 0.1345
DEBUG - 2022-09-03 05:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:21 --> Total execution time: 0.1117
DEBUG - 2022-09-03 05:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:31 --> Total execution time: 0.1314
DEBUG - 2022-09-03 05:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:42 --> Total execution time: 0.1075
DEBUG - 2022-09-03 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:48 --> Total execution time: 0.2480
DEBUG - 2022-09-03 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:49 --> Total execution time: 0.1148
DEBUG - 2022-09-03 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:33:51 --> Total execution time: 0.0973
DEBUG - 2022-09-03 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:34:09 --> Total execution time: 0.1291
DEBUG - 2022-09-03 05:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:04:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:34:11 --> Total execution time: 0.2976
DEBUG - 2022-09-03 05:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:04:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:34:13 --> Total execution time: 0.0974
DEBUG - 2022-09-03 05:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:27 --> Total execution time: 0.0762
DEBUG - 2022-09-03 05:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:33 --> Total execution time: 0.2593
DEBUG - 2022-09-03 05:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:34 --> Total execution time: 0.1186
DEBUG - 2022-09-03 05:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:43 --> Total execution time: 0.1055
DEBUG - 2022-09-03 05:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:47 --> Total execution time: 0.1109
DEBUG - 2022-09-03 05:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:58 --> Total execution time: 0.0937
DEBUG - 2022-09-03 05:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:33 --> Total execution time: 0.0789
DEBUG - 2022-09-03 05:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:44 --> Total execution time: 2.4086
DEBUG - 2022-09-03 05:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:44 --> Total execution time: 0.1001
DEBUG - 2022-09-03 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:53 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:53 --> Total execution time: 0.1138
DEBUG - 2022-09-03 05:06:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:53 --> Total execution time: 0.1296
DEBUG - 2022-09-03 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:06:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:06:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:36:58 --> Total execution time: 0.0955
DEBUG - 2022-09-03 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:37:23 --> Total execution time: 0.1051
DEBUG - 2022-09-03 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:07:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:37:27 --> Total execution time: 0.0978
DEBUG - 2022-09-03 05:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:37:31 --> Total execution time: 0.1062
DEBUG - 2022-09-03 05:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:11:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:41:04 --> Total execution time: 0.1372
DEBUG - 2022-09-03 05:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:11:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:41:06 --> Total execution time: 0.1337
DEBUG - 2022-09-03 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:42:19 --> Total execution time: 0.1099
DEBUG - 2022-09-03 05:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:42:52 --> Total execution time: 0.3109
DEBUG - 2022-09-03 05:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:43:48 --> Total execution time: 0.1035
DEBUG - 2022-09-03 05:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:15:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:45:28 --> Total execution time: 0.0708
DEBUG - 2022-09-03 05:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:15:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:15:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:45:41 --> Total execution time: 0.1038
DEBUG - 2022-09-03 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:15:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:45:48 --> Total execution time: 0.0694
DEBUG - 2022-09-03 05:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:03 --> Total execution time: 0.1131
DEBUG - 2022-09-03 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:19 --> Total execution time: 0.0954
DEBUG - 2022-09-03 05:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:25 --> Total execution time: 0.2798
DEBUG - 2022-09-03 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:29 --> Total execution time: 0.0648
DEBUG - 2022-09-03 05:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:30 --> Total execution time: 0.2571
DEBUG - 2022-09-03 05:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:46 --> Total execution time: 0.1014
DEBUG - 2022-09-03 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:50 --> Total execution time: 0.0910
DEBUG - 2022-09-03 05:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:46:59 --> Total execution time: 0.1142
DEBUG - 2022-09-03 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:01 --> Total execution time: 0.1097
DEBUG - 2022-09-03 05:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:06 --> Total execution time: 0.1605
DEBUG - 2022-09-03 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:08 --> Total execution time: 0.0928
DEBUG - 2022-09-03 05:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:10 --> Total execution time: 0.2878
DEBUG - 2022-09-03 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:13 --> Total execution time: 0.1133
DEBUG - 2022-09-03 05:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:14 --> Total execution time: 0.1291
DEBUG - 2022-09-03 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:19 --> Total execution time: 0.1078
DEBUG - 2022-09-03 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:20 --> Total execution time: 0.1157
DEBUG - 2022-09-03 05:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:22 --> Total execution time: 0.1070
DEBUG - 2022-09-03 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:32 --> Total execution time: 0.0936
DEBUG - 2022-09-03 05:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:35 --> Total execution time: 0.0897
DEBUG - 2022-09-03 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:43 --> Total execution time: 0.0917
DEBUG - 2022-09-03 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:49 --> Total execution time: 0.0949
DEBUG - 2022-09-03 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:53 --> Total execution time: 0.0942
DEBUG - 2022-09-03 05:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:47:57 --> Total execution time: 0.1003
DEBUG - 2022-09-03 15:47:57 --> Total execution time: 0.1207
DEBUG - 2022-09-03 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:18:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:18:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:48:06 --> Total execution time: 0.0616
DEBUG - 2022-09-03 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:18:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:18:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:48:07 --> Total execution time: 0.0563
DEBUG - 2022-09-03 05:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:48:49 --> Total execution time: 0.1004
DEBUG - 2022-09-03 05:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:21:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:21:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:51:34 --> Total execution time: 0.1805
DEBUG - 2022-09-03 05:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:22:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:52:14 --> Total execution time: 0.0749
DEBUG - 2022-09-03 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:52:25 --> Total execution time: 0.0687
DEBUG - 2022-09-03 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:23:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:53:14 --> Total execution time: 0.1167
DEBUG - 2022-09-03 05:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:53:28 --> Total execution time: 0.2279
DEBUG - 2022-09-03 05:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:23:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:53:42 --> Total execution time: 0.1017
DEBUG - 2022-09-03 05:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:54:15 --> Total execution time: 0.0997
DEBUG - 2022-09-03 05:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 05:24:17 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 05:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:54:20 --> Total execution time: 0.1099
DEBUG - 2022-09-03 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:24:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:54:33 --> Total execution time: 0.1274
DEBUG - 2022-09-03 05:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:54:42 --> Total execution time: 0.0624
DEBUG - 2022-09-03 05:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:54:54 --> Total execution time: 0.0707
DEBUG - 2022-09-03 05:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:25:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:55:09 --> Total execution time: 0.2074
DEBUG - 2022-09-03 05:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:55:17 --> Total execution time: 0.1447
DEBUG - 2022-09-03 05:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:55:26 --> Total execution time: 0.1133
DEBUG - 2022-09-03 05:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:26:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:56:15 --> Total execution time: 0.0800
DEBUG - 2022-09-03 05:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:26:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:56:20 --> Total execution time: 0.0627
DEBUG - 2022-09-03 05:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:56:41 --> Total execution time: 0.0910
DEBUG - 2022-09-03 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:57:02 --> Total execution time: 0.0934
DEBUG - 2022-09-03 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:57:06 --> Total execution time: 0.1303
DEBUG - 2022-09-03 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:57:21 --> Total execution time: 0.1126
DEBUG - 2022-09-03 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:57:27 --> Total execution time: 0.1355
DEBUG - 2022-09-03 05:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:27:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:57:41 --> Total execution time: 0.1040
DEBUG - 2022-09-03 05:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:01 --> Total execution time: 0.1679
DEBUG - 2022-09-03 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:11 --> Total execution time: 0.1102
DEBUG - 2022-09-03 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:12 --> Total execution time: 0.1051
DEBUG - 2022-09-03 05:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:21 --> Total execution time: 0.1399
DEBUG - 2022-09-03 05:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:22 --> Total execution time: 0.1088
DEBUG - 2022-09-03 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:25 --> Total execution time: 0.1019
DEBUG - 2022-09-03 05:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:27 --> Total execution time: 0.0972
DEBUG - 2022-09-03 05:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:28:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:58:28 --> Total execution time: 0.0953
DEBUG - 2022-09-03 05:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:29:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:29:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:59:14 --> Total execution time: 0.2698
DEBUG - 2022-09-03 05:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:00:07 --> Total execution time: 0.1025
DEBUG - 2022-09-03 05:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:31:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:01:31 --> Total execution time: 0.0683
DEBUG - 2022-09-03 05:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:02:02 --> Total execution time: 0.1293
DEBUG - 2022-09-03 05:32:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:32:04 --> Total execution time: 0.0981
DEBUG - 2022-09-03 05:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:02:11 --> Total execution time: 0.1416
DEBUG - 2022-09-03 05:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:02:31 --> Total execution time: 0.1148
DEBUG - 2022-09-03 05:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:04:41 --> Total execution time: 0.1029
DEBUG - 2022-09-03 05:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:05:19 --> Total execution time: 0.1016
DEBUG - 2022-09-03 05:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:05:23 --> Total execution time: 0.1417
DEBUG - 2022-09-03 05:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:05:30 --> Total execution time: 0.2083
DEBUG - 2022-09-03 05:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:05:43 --> Total execution time: 0.1104
DEBUG - 2022-09-03 05:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:06:12 --> Total execution time: 0.1053
DEBUG - 2022-09-03 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:36:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:06:20 --> Total execution time: 0.1018
DEBUG - 2022-09-03 05:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:06:27 --> Total execution time: 0.1336
DEBUG - 2022-09-03 05:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:06:33 --> Total execution time: 0.1001
DEBUG - 2022-09-03 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:06:41 --> Total execution time: 2.2517
DEBUG - 2022-09-03 05:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:36:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 05:36:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:07:13 --> Total execution time: 0.0964
DEBUG - 2022-09-03 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:07:29 --> Total execution time: 0.1018
DEBUG - 2022-09-03 05:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:07:35 --> Total execution time: 0.1069
DEBUG - 2022-09-03 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:07:45 --> Total execution time: 0.1272
DEBUG - 2022-09-03 05:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:37:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:07:52 --> Total execution time: 0.1116
DEBUG - 2022-09-03 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:38:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:38:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:08:11 --> Total execution time: 0.0803
DEBUG - 2022-09-03 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:02 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:02 --> Total execution time: 0.0973
DEBUG - 2022-09-03 05:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:14 --> Total execution time: 0.0617
DEBUG - 2022-09-03 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:21 --> Total execution time: 0.1198
DEBUG - 2022-09-03 05:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:39 --> Total execution time: 0.1239
DEBUG - 2022-09-03 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:40 --> Total execution time: 0.1068
DEBUG - 2022-09-03 05:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:39:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:09:42 --> Total execution time: 0.1011
DEBUG - 2022-09-03 05:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:09 --> Total execution time: 0.2630
DEBUG - 2022-09-03 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:35 --> Total execution time: 0.1067
DEBUG - 2022-09-03 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:43 --> Total execution time: 0.1055
DEBUG - 2022-09-03 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:44 --> Total execution time: 0.1200
DEBUG - 2022-09-03 05:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:44 --> Total execution time: 0.1072
DEBUG - 2022-09-03 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:49 --> Total execution time: 0.1304
DEBUG - 2022-09-03 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:52 --> Total execution time: 0.1042
DEBUG - 2022-09-03 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:10:58 --> Total execution time: 0.1428
DEBUG - 2022-09-03 05:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:41:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:11:04 --> Total execution time: 0.1753
DEBUG - 2022-09-03 05:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:11:11 --> Total execution time: 0.1126
DEBUG - 2022-09-03 05:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:11:16 --> Total execution time: 0.1113
DEBUG - 2022-09-03 05:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:11:20 --> Total execution time: 0.1231
DEBUG - 2022-09-03 05:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:11:54 --> Total execution time: 0.1070
DEBUG - 2022-09-03 05:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:45:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:45:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:15:51 --> Total execution time: 0.1538
DEBUG - 2022-09-03 05:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:48:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:48:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:18:56 --> Total execution time: 0.1808
DEBUG - 2022-09-03 05:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:52:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:22:07 --> Total execution time: 0.1112
DEBUG - 2022-09-03 05:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:52:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:52:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:22:46 --> Total execution time: 0.1210
DEBUG - 2022-09-03 05:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:52:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:22:47 --> Total execution time: 0.1103
DEBUG - 2022-09-03 05:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:23:06 --> Total execution time: 0.1337
DEBUG - 2022-09-03 05:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:23:16 --> Total execution time: 0.1642
DEBUG - 2022-09-03 05:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:23:23 --> Total execution time: 0.1088
DEBUG - 2022-09-03 05:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:23:41 --> Total execution time: 0.1196
DEBUG - 2022-09-03 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:23:58 --> Total execution time: 0.1029
DEBUG - 2022-09-03 05:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:24:04 --> Total execution time: 0.0973
DEBUG - 2022-09-03 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:24:05 --> Total execution time: 0.0921
DEBUG - 2022-09-03 05:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:55:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:25:17 --> Total execution time: 0.0880
DEBUG - 2022-09-03 05:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 05:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:27:24 --> Total execution time: 0.1197
DEBUG - 2022-09-03 05:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 05:59:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 05:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 05:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:29:40 --> Total execution time: 0.1308
DEBUG - 2022-09-03 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:30:02 --> Total execution time: 0.1290
DEBUG - 2022-09-03 06:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:30:05 --> Total execution time: 0.1453
DEBUG - 2022-09-03 06:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:01:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:31:01 --> Total execution time: 0.1378
DEBUG - 2022-09-03 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:31:23 --> Total execution time: 0.1025
DEBUG - 2022-09-03 06:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:31:41 --> Total execution time: 0.0630
DEBUG - 2022-09-03 06:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:01:49 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:01:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:31:49 --> Total execution time: 0.0929
DEBUG - 2022-09-03 06:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:02:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:32:39 --> Total execution time: 0.1001
DEBUG - 2022-09-03 06:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:02:46 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:02:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:32:46 --> Total execution time: 0.0643
DEBUG - 2022-09-03 06:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:02:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:32:49 --> Total execution time: 0.0585
DEBUG - 2022-09-03 06:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:02:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:02:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:32:58 --> Total execution time: 0.0963
DEBUG - 2022-09-03 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:08 --> Total execution time: 0.1065
DEBUG - 2022-09-03 06:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:13 --> Total execution time: 0.1175
DEBUG - 2022-09-03 06:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:20 --> Total execution time: 0.1216
DEBUG - 2022-09-03 06:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:22 --> Total execution time: 0.1105
DEBUG - 2022-09-03 06:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:28 --> Total execution time: 0.0989
DEBUG - 2022-09-03 06:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 06:03:29 --> 404 Page Not Found: Sample-page/esalestrix.in
DEBUG - 2022-09-03 06:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:38 --> Total execution time: 0.2503
DEBUG - 2022-09-03 06:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:33:41 --> Total execution time: 0.1303
DEBUG - 2022-09-03 06:04:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:04:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:34:30 --> Total execution time: 0.2530
DEBUG - 2022-09-03 06:04:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:04:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:34:38 --> Total execution time: 0.1036
DEBUG - 2022-09-03 06:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:04:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:34:41 --> Total execution time: 0.1103
DEBUG - 2022-09-03 06:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:34:58 --> Total execution time: 0.0945
DEBUG - 2022-09-03 06:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:05 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:35:05 --> Total execution time: 0.0603
DEBUG - 2022-09-03 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:35:11 --> Total execution time: 0.0555
DEBUG - 2022-09-03 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:35:25 --> Total execution time: 0.0615
DEBUG - 2022-09-03 06:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:35:34 --> Total execution time: 0.1055
DEBUG - 2022-09-03 06:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:35:41 --> Total execution time: 0.1424
DEBUG - 2022-09-03 06:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:02 --> Total execution time: 0.1171
DEBUG - 2022-09-03 06:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:02 --> Total execution time: 0.1167
DEBUG - 2022-09-03 06:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:10 --> Total execution time: 0.1511
DEBUG - 2022-09-03 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:14 --> Total execution time: 0.0908
DEBUG - 2022-09-03 06:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:22 --> Total execution time: 0.1538
DEBUG - 2022-09-03 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:36:56 --> Total execution time: 0.3186
DEBUG - 2022-09-03 06:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:08:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:38:03 --> Total execution time: 0.1296
DEBUG - 2022-09-03 06:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:38:07 --> Total execution time: 0.1462
DEBUG - 2022-09-03 06:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:08:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:08:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:38:19 --> Total execution time: 0.1057
DEBUG - 2022-09-03 06:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:08:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:38:20 --> Total execution time: 0.1406
DEBUG - 2022-09-03 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:38:33 --> Total execution time: 0.1088
DEBUG - 2022-09-03 06:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:39:16 --> Total execution time: 0.1150
DEBUG - 2022-09-03 06:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:12:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:42:50 --> Total execution time: 0.3251
DEBUG - 2022-09-03 06:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:13:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 06:13:23 --> 404 Page Not Found: Teacher/index
DEBUG - 2022-09-03 06:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:15:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:45:17 --> Total execution time: 0.2722
DEBUG - 2022-09-03 06:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:45:18 --> Total execution time: 0.1157
DEBUG - 2022-09-03 06:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:45:22 --> Total execution time: 0.1092
DEBUG - 2022-09-03 06:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:16:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:46:17 --> Total execution time: 0.0719
DEBUG - 2022-09-03 06:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:17:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:47:50 --> Total execution time: 0.1148
DEBUG - 2022-09-03 06:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:50:29 --> Total execution time: 0.0673
DEBUG - 2022-09-03 06:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:51:44 --> Total execution time: 0.2542
DEBUG - 2022-09-03 06:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:51:52 --> Total execution time: 0.0992
DEBUG - 2022-09-03 06:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:51:55 --> Total execution time: 0.1081
DEBUG - 2022-09-03 06:22:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:52:08 --> Total execution time: 0.0823
DEBUG - 2022-09-03 06:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:52:31 --> Total execution time: 0.2662
DEBUG - 2022-09-03 06:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:52:39 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 06:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:52:40 --> Total execution time: 0.1213
DEBUG - 2022-09-03 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:52:42 --> Total execution time: 0.0992
DEBUG - 2022-09-03 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:23:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:53:21 --> Total execution time: 0.1055
DEBUG - 2022-09-03 06:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:53:27 --> Total execution time: 0.0928
DEBUG - 2022-09-03 06:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:53:45 --> Total execution time: 0.1320
DEBUG - 2022-09-03 06:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:23:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:53:46 --> Total execution time: 0.1218
DEBUG - 2022-09-03 06:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:06 --> Total execution time: 0.0984
DEBUG - 2022-09-03 06:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:07 --> Total execution time: 0.1299
DEBUG - 2022-09-03 06:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:19 --> Total execution time: 0.1021
DEBUG - 2022-09-03 06:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:20 --> Total execution time: 0.1488
DEBUG - 2022-09-03 06:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:36 --> Total execution time: 0.0904
DEBUG - 2022-09-03 06:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:39 --> Total execution time: 0.1117
DEBUG - 2022-09-03 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:24:40 --> Total execution time: 0.0955
DEBUG - 2022-09-03 06:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:54:42 --> Total execution time: 0.1204
DEBUG - 2022-09-03 06:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:24:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:54:59 --> Total execution time: 0.1027
DEBUG - 2022-09-03 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:18 --> Total execution time: 0.0784
DEBUG - 2022-09-03 06:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:20 --> Total execution time: 0.0907
DEBUG - 2022-09-03 06:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:22 --> Total execution time: 0.1019
DEBUG - 2022-09-03 06:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:30 --> Total execution time: 0.1240
DEBUG - 2022-09-03 06:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:38 --> Total execution time: 0.2763
DEBUG - 2022-09-03 16:55:38 --> Total execution time: 0.2033
DEBUG - 2022-09-03 06:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:55:53 --> Total execution time: 0.1415
DEBUG - 2022-09-03 06:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:07 --> Total execution time: 0.1331
DEBUG - 2022-09-03 06:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:21 --> Total execution time: 0.0975
DEBUG - 2022-09-03 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:34 --> Total execution time: 0.1013
DEBUG - 2022-09-03 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:37 --> Total execution time: 0.0956
DEBUG - 2022-09-03 06:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:52 --> Total execution time: 0.1042
DEBUG - 2022-09-03 06:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:26:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:56:55 --> Total execution time: 0.2815
DEBUG - 2022-09-03 06:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:27:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:57:03 --> Total execution time: 0.1295
DEBUG - 2022-09-03 06:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:27:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:57:14 --> Total execution time: 0.1196
DEBUG - 2022-09-03 06:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:57:18 --> Total execution time: 0.1466
DEBUG - 2022-09-03 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:27:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:57:42 --> Total execution time: 0.1126
DEBUG - 2022-09-03 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:08 --> Total execution time: 0.1149
DEBUG - 2022-09-03 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:10 --> Total execution time: 0.1177
DEBUG - 2022-09-03 06:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:11 --> Total execution time: 0.0649
DEBUG - 2022-09-03 06:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:28 --> Total execution time: 0.1175
DEBUG - 2022-09-03 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:37 --> Total execution time: 0.1012
DEBUG - 2022-09-03 06:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:45 --> Total execution time: 0.1351
DEBUG - 2022-09-03 06:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:58:46 --> Total execution time: 0.1434
DEBUG - 2022-09-03 06:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:59:08 --> Total execution time: 0.1065
DEBUG - 2022-09-03 06:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:59:13 --> Total execution time: 0.0898
DEBUG - 2022-09-03 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:59:18 --> Total execution time: 0.1167
DEBUG - 2022-09-03 06:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:59:46 --> Total execution time: 0.1579
DEBUG - 2022-09-03 06:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:29:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:59:47 --> Total execution time: 0.0936
DEBUG - 2022-09-03 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:30:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:00:08 --> Total execution time: 0.1260
DEBUG - 2022-09-03 06:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:30:10 --> Total execution time: 0.1028
DEBUG - 2022-09-03 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:30:17 --> Total execution time: 0.1238
DEBUG - 2022-09-03 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:00:25 --> Total execution time: 0.1001
DEBUG - 2022-09-03 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:01:31 --> Total execution time: 0.2778
DEBUG - 2022-09-03 06:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:01:51 --> Total execution time: 0.1049
DEBUG - 2022-09-03 06:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:32:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:32:36 --> Total execution time: 0.0989
DEBUG - 2022-09-03 06:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:32:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:32:41 --> Total execution time: 0.1109
DEBUG - 2022-09-03 06:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:32:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:02:48 --> Total execution time: 0.1261
DEBUG - 2022-09-03 06:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:02:55 --> Total execution time: 0.1101
DEBUG - 2022-09-03 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:09 --> Total execution time: 0.1129
DEBUG - 2022-09-03 06:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:19 --> Total execution time: 0.0542
DEBUG - 2022-09-03 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:44 --> Total execution time: 0.1015
DEBUG - 2022-09-03 06:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:44 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 06:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:44 --> Total execution time: 0.1029
DEBUG - 2022-09-03 06:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:56 --> Total execution time: 0.1439
DEBUG - 2022-09-03 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:58 --> Total execution time: 0.0590
DEBUG - 2022-09-03 06:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:33:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:33:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:03:59 --> Total execution time: 0.0589
DEBUG - 2022-09-03 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:05 --> Total execution time: 0.1181
DEBUG - 2022-09-03 06:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:07 --> Total execution time: 0.1049
DEBUG - 2022-09-03 06:34:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:23 --> Total execution time: 0.1003
DEBUG - 2022-09-03 06:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:34:26 --> Total execution time: 0.1004
DEBUG - 2022-09-03 06:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:28 --> Total execution time: 0.0625
DEBUG - 2022-09-03 06:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:34:31 --> Total execution time: 0.1094
DEBUG - 2022-09-03 06:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:33 --> Total execution time: 0.1190
DEBUG - 2022-09-03 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:38 --> Total execution time: 0.1104
DEBUG - 2022-09-03 06:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:42 --> Total execution time: 0.0930
DEBUG - 2022-09-03 06:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:52 --> Total execution time: 0.0927
DEBUG - 2022-09-03 06:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:04:57 --> Total execution time: 0.1105
DEBUG - 2022-09-03 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:01 --> Total execution time: 0.1175
DEBUG - 2022-09-03 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:03 --> Total execution time: 0.0944
DEBUG - 2022-09-03 06:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:07 --> Total execution time: 0.1226
DEBUG - 2022-09-03 06:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:09 --> Total execution time: 0.0905
DEBUG - 2022-09-03 06:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:16 --> Total execution time: 0.0950
DEBUG - 2022-09-03 06:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:18 --> Total execution time: 0.0972
DEBUG - 2022-09-03 06:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:19 --> Total execution time: 0.1022
DEBUG - 2022-09-03 06:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:35:23 --> Total execution time: 0.0967
DEBUG - 2022-09-03 06:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:25 --> Total execution time: 0.0977
DEBUG - 2022-09-03 06:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:29 --> Total execution time: 0.1060
DEBUG - 2022-09-03 06:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:38 --> Total execution time: 0.1032
DEBUG - 2022-09-03 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:35:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:05:43 --> Total execution time: 0.1082
DEBUG - 2022-09-03 06:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:36:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:06:22 --> Total execution time: 0.1636
DEBUG - 2022-09-03 06:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:06:31 --> Total execution time: 0.1000
DEBUG - 2022-09-03 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:37:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:07:51 --> Total execution time: 0.1400
DEBUG - 2022-09-03 06:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:38:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:08:30 --> Total execution time: 0.0647
DEBUG - 2022-09-03 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:38:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:38:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:08:34 --> Total execution time: 0.2672
DEBUG - 2022-09-03 06:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:38:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:08:48 --> Total execution time: 0.0982
DEBUG - 2022-09-03 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:39:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:09:11 --> Total execution time: 0.1047
DEBUG - 2022-09-03 06:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:39:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:09:29 --> Total execution time: 0.2641
DEBUG - 2022-09-03 06:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:09:47 --> Total execution time: 0.1242
DEBUG - 2022-09-03 06:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:39:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:09:55 --> Total execution time: 0.1229
DEBUG - 2022-09-03 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:10:24 --> Total execution time: 0.1032
DEBUG - 2022-09-03 06:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:10:32 --> Total execution time: 0.1020
DEBUG - 2022-09-03 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:10:40 --> Total execution time: 0.1172
DEBUG - 2022-09-03 06:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:10:51 --> Total execution time: 0.1025
DEBUG - 2022-09-03 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:40:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:40:57 --> Total execution time: 0.0978
DEBUG - 2022-09-03 06:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:41:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:11:08 --> Total execution time: 0.0984
DEBUG - 2022-09-03 06:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:11:49 --> Total execution time: 0.1074
DEBUG - 2022-09-03 06:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:42:19 --> Total execution time: 0.0966
DEBUG - 2022-09-03 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:25 --> Total execution time: 0.1043
DEBUG - 2022-09-03 06:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:31 --> Total execution time: 0.1082
DEBUG - 2022-09-03 06:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:38 --> Total execution time: 0.0998
DEBUG - 2022-09-03 06:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:43 --> Total execution time: 0.1309
DEBUG - 2022-09-03 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:48 --> Total execution time: 0.0995
DEBUG - 2022-09-03 06:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:49 --> Total execution time: 0.1250
DEBUG - 2022-09-03 06:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:12:54 --> Total execution time: 0.1287
DEBUG - 2022-09-03 06:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:13:02 --> Total execution time: 0.1297
DEBUG - 2022-09-03 06:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:43:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:13:05 --> Total execution time: 0.1155
DEBUG - 2022-09-03 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:13:11 --> Total execution time: 0.2125
DEBUG - 2022-09-03 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:13:32 --> Total execution time: 0.1044
DEBUG - 2022-09-03 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:43:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:13:50 --> Total execution time: 0.1134
DEBUG - 2022-09-03 06:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:14:04 --> Total execution time: 0.1080
DEBUG - 2022-09-03 06:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:14:09 --> Total execution time: 0.1171
DEBUG - 2022-09-03 06:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:44:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:14:11 --> Total execution time: 0.0975
DEBUG - 2022-09-03 06:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:44:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:14:28 --> Total execution time: 0.1374
DEBUG - 2022-09-03 06:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:46:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:16:10 --> Total execution time: 0.2659
DEBUG - 2022-09-03 06:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:46:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:16:22 --> Total execution time: 0.1303
DEBUG - 2022-09-03 06:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:16:40 --> Total execution time: 0.1117
DEBUG - 2022-09-03 06:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:46:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:16:51 --> Total execution time: 0.1028
DEBUG - 2022-09-03 06:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:48:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:18:39 --> Total execution time: 0.3105
DEBUG - 2022-09-03 06:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:48:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:18:48 --> Total execution time: 0.1427
DEBUG - 2022-09-03 06:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:48:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:18:53 --> Total execution time: 0.1211
DEBUG - 2022-09-03 06:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:49:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:19:00 --> Total execution time: 0.1106
DEBUG - 2022-09-03 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:49:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:19:25 --> Total execution time: 0.2504
DEBUG - 2022-09-03 06:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:20:56 --> Total execution time: 0.1196
DEBUG - 2022-09-03 06:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:51:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:51:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:21:20 --> Total execution time: 0.1115
DEBUG - 2022-09-03 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:08 --> Total execution time: 0.2909
DEBUG - 2022-09-03 06:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:14 --> Total execution time: 0.1008
DEBUG - 2022-09-03 06:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:18 --> Total execution time: 0.1063
DEBUG - 2022-09-03 06:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:26 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:26 --> Total execution time: 0.2606
DEBUG - 2022-09-03 06:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 06:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:28 --> Total execution time: 0.1146
DEBUG - 2022-09-03 06:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:22:49 --> Total execution time: 0.1007
DEBUG - 2022-09-03 06:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:24:08 --> Total execution time: 0.1049
DEBUG - 2022-09-03 06:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:54:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:24:26 --> Total execution time: 0.1138
DEBUG - 2022-09-03 06:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:24:37 --> Total execution time: 0.1005
DEBUG - 2022-09-03 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:55:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:25:01 --> Total execution time: 0.1112
DEBUG - 2022-09-03 06:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:55:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 06:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:55:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:25:33 --> Total execution time: 0.2528
DEBUG - 2022-09-03 06:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:56:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:26:25 --> Total execution time: 0.3283
DEBUG - 2022-09-03 06:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:26:44 --> Total execution time: 0.1255
DEBUG - 2022-09-03 06:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:28:49 --> Total execution time: 0.2216
DEBUG - 2022-09-03 06:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:28:58 --> Total execution time: 0.0978
DEBUG - 2022-09-03 06:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:29:10 --> Total execution time: 0.1091
DEBUG - 2022-09-03 06:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:59:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:29:14 --> Total execution time: 0.1013
DEBUG - 2022-09-03 06:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 06:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 06:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:29:20 --> Total execution time: 0.1405
DEBUG - 2022-09-03 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:30:02 --> Total execution time: 0.1365
DEBUG - 2022-09-03 07:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:30:37 --> Total execution time: 0.0715
DEBUG - 2022-09-03 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:00:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:30:51 --> Total execution time: 0.1061
DEBUG - 2022-09-03 07:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:31:04 --> Total execution time: 0.1078
DEBUG - 2022-09-03 07:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:31:08 --> Total execution time: 0.1291
DEBUG - 2022-09-03 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:01:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:31:18 --> Total execution time: 0.1811
DEBUG - 2022-09-03 07:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:02:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:32:43 --> Total execution time: 0.3367
DEBUG - 2022-09-03 07:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:06:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:36:55 --> Total execution time: 0.3736
DEBUG - 2022-09-03 07:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:06:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:36:56 --> Total execution time: 0.4434
DEBUG - 2022-09-03 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:37:12 --> Total execution time: 0.2475
DEBUG - 2022-09-03 07:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:37:35 --> Total execution time: 0.4609
DEBUG - 2022-09-03 07:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:37:45 --> Total execution time: 0.2798
DEBUG - 2022-09-03 07:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:07:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:37:58 --> Total execution time: 0.1072
DEBUG - 2022-09-03 07:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:38:05 --> Total execution time: 0.1490
DEBUG - 2022-09-03 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:38:17 --> Total execution time: 0.1041
DEBUG - 2022-09-03 07:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:38:23 --> Total execution time: 0.1933
DEBUG - 2022-09-03 07:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:38:33 --> Total execution time: 0.1703
DEBUG - 2022-09-03 07:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:08:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:08:46 --> Total execution time: 0.2270
DEBUG - 2022-09-03 07:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:09:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:09:03 --> Total execution time: 0.1575
DEBUG - 2022-09-03 07:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:09:08 --> Total execution time: 0.1361
DEBUG - 2022-09-03 07:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:39:11 --> Total execution time: 0.2916
DEBUG - 2022-09-03 07:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:44:04 --> Total execution time: 0.1731
DEBUG - 2022-09-03 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:16:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:16:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:46:21 --> Total execution time: 0.1915
DEBUG - 2022-09-03 07:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:46:32 --> Total execution time: 0.3583
DEBUG - 2022-09-03 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:46:40 --> Total execution time: 0.2290
DEBUG - 2022-09-03 07:16:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:16:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:46:42 --> Total execution time: 0.2081
DEBUG - 2022-09-03 07:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:17:47 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:17:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:47:47 --> Total execution time: 0.1228
DEBUG - 2022-09-03 07:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:48:50 --> Total execution time: 0.1163
DEBUG - 2022-09-03 07:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:04 --> Total execution time: 0.0886
DEBUG - 2022-09-03 07:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:06 --> Total execution time: 0.0695
DEBUG - 2022-09-03 07:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:12 --> Total execution time: 0.0563
DEBUG - 2022-09-03 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:19 --> Total execution time: 0.1408
DEBUG - 2022-09-03 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:19:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:19:27 --> Total execution time: 0.1160
DEBUG - 2022-09-03 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:28 --> Total execution time: 0.1413
DEBUG - 2022-09-03 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:19:29 --> Total execution time: 0.1169
DEBUG - 2022-09-03 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:19:30 --> Total execution time: 0.1021
DEBUG - 2022-09-03 07:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:35 --> Total execution time: 0.1712
DEBUG - 2022-09-03 07:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:38 --> Total execution time: 0.0528
DEBUG - 2022-09-03 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:44 --> Total execution time: 0.0928
DEBUG - 2022-09-03 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:46 --> Total execution time: 0.0940
DEBUG - 2022-09-03 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:56 --> Total execution time: 0.1052
DEBUG - 2022-09-03 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:58 --> Total execution time: 0.1152
DEBUG - 2022-09-03 07:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:19:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:49:58 --> Total execution time: 0.0982
DEBUG - 2022-09-03 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:50:06 --> Total execution time: 0.1312
DEBUG - 2022-09-03 07:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:50:15 --> Total execution time: 0.0996
DEBUG - 2022-09-03 07:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:50:28 --> Total execution time: 0.1041
DEBUG - 2022-09-03 07:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:50:39 --> Total execution time: 0.1052
DEBUG - 2022-09-03 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:45 --> Total execution time: 0.0980
DEBUG - 2022-09-03 07:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:53 --> Total execution time: 0.0927
DEBUG - 2022-09-03 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:57 --> Total execution time: 0.0950
DEBUG - 2022-09-03 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:20:59 --> Total execution time: 0.1031
DEBUG - 2022-09-03 07:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:04 --> Total execution time: 0.1164
DEBUG - 2022-09-03 07:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:05 --> Total execution time: 0.1027
DEBUG - 2022-09-03 07:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:07 --> Total execution time: 0.0641
DEBUG - 2022-09-03 07:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:11 --> Total execution time: 0.1048
DEBUG - 2022-09-03 07:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:16 --> Total execution time: 0.1076
DEBUG - 2022-09-03 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:38 --> Total execution time: 0.0997
DEBUG - 2022-09-03 07:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:21:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:51:50 --> Total execution time: 2.4184
DEBUG - 2022-09-03 07:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:21:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 07:21:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 07:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:52:26 --> Total execution time: 0.1414
DEBUG - 2022-09-03 07:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:52:33 --> Total execution time: 0.1769
DEBUG - 2022-09-03 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:52:37 --> Total execution time: 0.2472
DEBUG - 2022-09-03 07:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:52:46 --> Total execution time: 0.0984
DEBUG - 2022-09-03 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:03 --> Total execution time: 0.3579
DEBUG - 2022-09-03 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:13 --> Total execution time: 0.2225
DEBUG - 2022-09-03 07:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:22 --> Total execution time: 0.2632
DEBUG - 2022-09-03 07:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:36 --> Total execution time: 0.1618
DEBUG - 2022-09-03 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:41 --> Total execution time: 0.2239
DEBUG - 2022-09-03 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:44 --> Total execution time: 0.1481
DEBUG - 2022-09-03 07:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:54 --> Total execution time: 0.1859
DEBUG - 2022-09-03 07:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:56 --> Total execution time: 0.2435
DEBUG - 2022-09-03 07:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:24:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:54:57 --> Total execution time: 0.2459
DEBUG - 2022-09-03 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:55:00 --> Total execution time: 0.3937
DEBUG - 2022-09-03 07:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:55:05 --> Total execution time: 0.1343
DEBUG - 2022-09-03 07:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:25:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:55:21 --> Total execution time: 0.2303
DEBUG - 2022-09-03 07:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:55:34 --> Total execution time: 0.1362
DEBUG - 2022-09-03 07:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:55:41 --> Total execution time: 0.1432
DEBUG - 2022-09-03 07:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:26:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:56:34 --> Total execution time: 0.3698
DEBUG - 2022-09-03 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:26:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:56:39 --> Total execution time: 0.7789
DEBUG - 2022-09-03 07:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:26:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:26:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:56:39 --> Total execution time: 0.1355
DEBUG - 2022-09-03 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:26:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:56:53 --> Total execution time: 0.3152
DEBUG - 2022-09-03 07:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:57:00 --> Total execution time: 0.0942
DEBUG - 2022-09-03 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:57:35 --> Total execution time: 0.0996
DEBUG - 2022-09-03 07:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:57:45 --> Total execution time: 0.1132
DEBUG - 2022-09-03 07:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:57:50 --> Total execution time: 0.1282
DEBUG - 2022-09-03 07:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:27:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:57:54 --> Total execution time: 0.0908
DEBUG - 2022-09-03 07:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:59:01 --> Total execution time: 0.0836
DEBUG - 2022-09-03 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:30:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:00:32 --> Total execution time: 0.0644
DEBUG - 2022-09-03 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:30:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:30:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:00:42 --> Total execution time: 0.1035
DEBUG - 2022-09-03 07:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:32:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:58 --> Total execution time: 0.1352
DEBUG - 2022-09-03 07:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:33:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:03:01 --> Total execution time: 0.1373
DEBUG - 2022-09-03 07:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:03:05 --> Total execution time: 0.1300
DEBUG - 2022-09-03 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:33:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:03:12 --> Total execution time: 0.0939
DEBUG - 2022-09-03 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:03:57 --> Total execution time: 0.0872
DEBUG - 2022-09-03 07:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:04:28 --> Total execution time: 0.1226
DEBUG - 2022-09-03 07:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:04:42 --> Total execution time: 0.1117
DEBUG - 2022-09-03 07:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:04:58 --> Total execution time: 0.1036
DEBUG - 2022-09-03 07:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:04:59 --> Total execution time: 0.1029
DEBUG - 2022-09-03 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:06 --> Total execution time: 0.1381
DEBUG - 2022-09-03 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:23 --> Total execution time: 0.0970
DEBUG - 2022-09-03 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:25 --> Total execution time: 0.2569
DEBUG - 2022-09-03 07:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:44 --> Total execution time: 0.1047
DEBUG - 2022-09-03 07:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:54 --> Total execution time: 0.1231
DEBUG - 2022-09-03 07:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:35:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:05:58 --> Total execution time: 0.0963
DEBUG - 2022-09-03 07:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:06:06 --> Total execution time: 0.1246
DEBUG - 2022-09-03 07:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:36:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:06:27 --> Total execution time: 0.1037
DEBUG - 2022-09-03 07:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:36:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:06:32 --> Total execution time: 0.1003
DEBUG - 2022-09-03 07:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:36:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:06:41 --> Total execution time: 0.1040
DEBUG - 2022-09-03 07:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:37:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:07:01 --> Total execution time: 0.0932
DEBUG - 2022-09-03 07:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:07:56 --> Total execution time: 0.1057
DEBUG - 2022-09-03 07:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:27 --> Total execution time: 0.0924
DEBUG - 2022-09-03 07:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:30 --> Total execution time: 0.0628
DEBUG - 2022-09-03 07:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:33 --> Total execution time: 0.2596
DEBUG - 2022-09-03 07:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:36 --> Total execution time: 0.0968
DEBUG - 2022-09-03 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:48 --> Total execution time: 0.1078
DEBUG - 2022-09-03 07:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:38:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:08:52 --> Total execution time: 0.0758
DEBUG - 2022-09-03 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:39:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:39:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:39:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:09:35 --> Total execution time: 0.0967
DEBUG - 2022-09-03 07:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:39:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:09:48 --> Total execution time: 0.1076
DEBUG - 2022-09-03 07:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:39:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:09:49 --> Total execution time: 0.1222
DEBUG - 2022-09-03 07:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:40:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:10:47 --> Total execution time: 0.0889
DEBUG - 2022-09-03 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:10:48 --> Total execution time: 0.0903
DEBUG - 2022-09-03 07:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 07:40:51 --> 404 Page Not Found: Event/index
DEBUG - 2022-09-03 07:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:40:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:10:52 --> Total execution time: 0.0944
DEBUG - 2022-09-03 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:45:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:15:39 --> Total execution time: 0.1387
DEBUG - 2022-09-03 07:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:46:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:16:23 --> Total execution time: 0.0625
DEBUG - 2022-09-03 07:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:46:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:16:24 --> Total execution time: 0.0858
DEBUG - 2022-09-03 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:47:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:17:33 --> Total execution time: 0.0998
DEBUG - 2022-09-03 07:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:48:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:18:11 --> Total execution time: 0.0959
DEBUG - 2022-09-03 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:07 --> Total execution time: 0.1126
DEBUG - 2022-09-03 07:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:09 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:09 --> Total execution time: 0.0762
DEBUG - 2022-09-03 07:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:19 --> Total execution time: 0.1346
DEBUG - 2022-09-03 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:33 --> Total execution time: 0.0922
DEBUG - 2022-09-03 07:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:45 --> Total execution time: 0.0631
DEBUG - 2022-09-03 07:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:19:52 --> Total execution time: 0.0941
DEBUG - 2022-09-03 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:00 --> Total execution time: 0.0944
DEBUG - 2022-09-03 07:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:13 --> Total execution time: 0.1082
DEBUG - 2022-09-03 07:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:16 --> Total execution time: 0.0962
DEBUG - 2022-09-03 07:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:25 --> Total execution time: 0.0953
DEBUG - 2022-09-03 07:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:26 --> Total execution time: 0.1052
DEBUG - 2022-09-03 07:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:33 --> Total execution time: 0.0935
DEBUG - 2022-09-03 07:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:50:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:20:43 --> Total execution time: 0.0888
DEBUG - 2022-09-03 07:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:51:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:21:25 --> Total execution time: 0.0737
DEBUG - 2022-09-03 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:21:56 --> Total execution time: 0.0987
DEBUG - 2022-09-03 07:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:22:03 --> Total execution time: 0.1250
DEBUG - 2022-09-03 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:52:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:22:21 --> Total execution time: 0.0754
DEBUG - 2022-09-03 07:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:52:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:22:52 --> Total execution time: 0.1665
DEBUG - 2022-09-03 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:02 --> Total execution time: 0.1017
DEBUG - 2022-09-03 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:07 --> Total execution time: 0.1050
DEBUG - 2022-09-03 07:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:10 --> Total execution time: 0.1001
DEBUG - 2022-09-03 07:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:13 --> Total execution time: 0.1055
DEBUG - 2022-09-03 07:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:18 --> Total execution time: 0.1040
DEBUG - 2022-09-03 07:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:20 --> Total execution time: 0.1340
DEBUG - 2022-09-03 07:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:37 --> Total execution time: 0.1059
DEBUG - 2022-09-03 07:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:37 --> Total execution time: 0.1064
DEBUG - 2022-09-03 07:53:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 07:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:45 --> Total execution time: 0.0676
DEBUG - 2022-09-03 07:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:53:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:23:47 --> Total execution time: 0.1078
DEBUG - 2022-09-03 07:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:24:10 --> Total execution time: 0.1032
DEBUG - 2022-09-03 07:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:54:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:54:22 --> Total execution time: 0.1054
DEBUG - 2022-09-03 07:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:54:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:54:56 --> Total execution time: 0.0683
DEBUG - 2022-09-03 07:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:55:00 --> Total execution time: 0.1469
DEBUG - 2022-09-03 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:55:02 --> Total execution time: 0.0991
DEBUG - 2022-09-03 07:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 07:55:02 --> Total execution time: 0.1066
DEBUG - 2022-09-03 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:25:09 --> Total execution time: 0.1043
DEBUG - 2022-09-03 07:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:25:18 --> Total execution time: 0.1193
DEBUG - 2022-09-03 07:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:25:45 --> Total execution time: 0.1080
DEBUG - 2022-09-03 07:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:25:55 --> Total execution time: 0.1013
DEBUG - 2022-09-03 07:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:56:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:26:05 --> Total execution time: 0.0993
DEBUG - 2022-09-03 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:26:08 --> Total execution time: 0.1040
DEBUG - 2022-09-03 07:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:56:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:26:12 --> Total execution time: 0.2814
DEBUG - 2022-09-03 07:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:26:22 --> Total execution time: 0.1024
DEBUG - 2022-09-03 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:56:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:26:54 --> Total execution time: 0.0940
DEBUG - 2022-09-03 07:58:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:58:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:28:38 --> Total execution time: 0.2670
DEBUG - 2022-09-03 07:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 07:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 07:58:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:28:39 --> Total execution time: 0.1011
DEBUG - 2022-09-03 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:30:02 --> Total execution time: 0.0893
DEBUG - 2022-09-03 08:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:33:25 --> Total execution time: 0.4045
DEBUG - 2022-09-03 08:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:33:32 --> Total execution time: 0.1110
DEBUG - 2022-09-03 08:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:03:40 --> Total execution time: 0.2554
DEBUG - 2022-09-03 08:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:33:41 --> Total execution time: 0.1096
DEBUG - 2022-09-03 08:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:33:45 --> Total execution time: 0.1344
DEBUG - 2022-09-03 08:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:03:46 --> Total execution time: 0.0989
DEBUG - 2022-09-03 08:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:03:47 --> Total execution time: 0.0938
DEBUG - 2022-09-03 08:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:33:57 --> Total execution time: 0.1013
DEBUG - 2022-09-03 08:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:34:00 --> Total execution time: 0.1099
DEBUG - 2022-09-03 08:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:04:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:34:01 --> Total execution time: 0.1374
DEBUG - 2022-09-03 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:04:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:34:31 --> Total execution time: 0.0967
DEBUG - 2022-09-03 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:35:04 --> Total execution time: 0.0989
DEBUG - 2022-09-03 08:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:05:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:35:15 --> Total execution time: 0.0989
DEBUG - 2022-09-03 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:36:00 --> Total execution time: 0.1189
DEBUG - 2022-09-03 08:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:06:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:36:12 --> Total execution time: 2.4196
DEBUG - 2022-09-03 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:06:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:06:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:37:25 --> Total execution time: 0.1088
DEBUG - 2022-09-03 08:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:37:26 --> Total execution time: 0.2723
DEBUG - 2022-09-03 08:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:37:33 --> Total execution time: 0.0954
DEBUG - 2022-09-03 08:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:37:38 --> Total execution time: 0.0621
DEBUG - 2022-09-03 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:37:39 --> Total execution time: 0.1574
DEBUG - 2022-09-03 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:38:12 --> Total execution time: 0.0733
DEBUG - 2022-09-03 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:38:12 --> Total execution time: 0.1317
DEBUG - 2022-09-03 08:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:38:23 --> Total execution time: 0.0703
DEBUG - 2022-09-03 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:08:53 --> Total execution time: 0.1074
DEBUG - 2022-09-03 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:08:53 --> Total execution time: 0.0951
DEBUG - 2022-09-03 08:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:08:54 --> Total execution time: 0.0868
DEBUG - 2022-09-03 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:08:56 --> Total execution time: 0.0955
DEBUG - 2022-09-03 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:08:56 --> Total execution time: 0.1237
DEBUG - 2022-09-03 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:09:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:09:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:39:01 --> Total execution time: 0.1147
DEBUG - 2022-09-03 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:11:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:41:22 --> Total execution time: 0.1357
DEBUG - 2022-09-03 08:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:16:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:16:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:46:42 --> Total execution time: 0.1386
DEBUG - 2022-09-03 08:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:16:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:46:46 --> Total execution time: 0.0604
DEBUG - 2022-09-03 08:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:47:08 --> Total execution time: 0.1018
DEBUG - 2022-09-03 08:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:47:17 --> Total execution time: 0.1092
DEBUG - 2022-09-03 08:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:47:31 --> Total execution time: 0.0631
DEBUG - 2022-09-03 08:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:47:34 --> Total execution time: 0.1191
DEBUG - 2022-09-03 08:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:47:50 --> Total execution time: 0.0975
DEBUG - 2022-09-03 08:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:18:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:48:10 --> Total execution time: 1.9966
DEBUG - 2022-09-03 08:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:48:29 --> Total execution time: 0.0597
DEBUG - 2022-09-03 08:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:49:10 --> Total execution time: 0.0885
DEBUG - 2022-09-03 08:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:49:18 --> Total execution time: 0.1015
DEBUG - 2022-09-03 08:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:49:41 --> Total execution time: 0.1347
DEBUG - 2022-09-03 08:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:19:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:49:56 --> Total execution time: 0.1262
DEBUG - 2022-09-03 08:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:20:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:50:04 --> Total execution time: 0.0938
DEBUG - 2022-09-03 08:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:20:27 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:20:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:50:27 --> Total execution time: 0.0723
DEBUG - 2022-09-03 08:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:25:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:55:40 --> Total execution time: 0.1763
DEBUG - 2022-09-03 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:25:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:55:41 --> Total execution time: 0.0952
DEBUG - 2022-09-03 08:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:56:01 --> Total execution time: 0.1109
DEBUG - 2022-09-03 08:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:56:15 --> Total execution time: 0.3389
DEBUG - 2022-09-03 08:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:26:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:56:38 --> Total execution time: 0.1216
DEBUG - 2022-09-03 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:27:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:27:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:57:42 --> Total execution time: 0.0739
DEBUG - 2022-09-03 08:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:28:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:28:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:58:14 --> Total execution time: 0.0994
DEBUG - 2022-09-03 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:58:42 --> Total execution time: 0.1363
DEBUG - 2022-09-03 08:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:28:43 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:58:43 --> Total execution time: 0.2693
DEBUG - 2022-09-03 08:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:30:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:30:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:00:34 --> Total execution time: 0.0997
DEBUG - 2022-09-03 08:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:00:45 --> Total execution time: 0.0937
DEBUG - 2022-09-03 08:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:31:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:31:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:01:11 --> Total execution time: 0.1187
DEBUG - 2022-09-03 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:33:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:03:26 --> Total execution time: 0.1093
DEBUG - 2022-09-03 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:03 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:03 --> Total execution time: 0.0705
DEBUG - 2022-09-03 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:19 --> Total execution time: 0.1146
DEBUG - 2022-09-03 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:34:19 --> Total execution time: 0.0914
DEBUG - 2022-09-03 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:19 --> Total execution time: 0.0943
DEBUG - 2022-09-03 08:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:45 --> Total execution time: 0.1027
DEBUG - 2022-09-03 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:50 --> Total execution time: 0.1450
DEBUG - 2022-09-03 08:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:34:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:04:57 --> Total execution time: 0.2558
DEBUG - 2022-09-03 08:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:03 --> Total execution time: 0.0883
DEBUG - 2022-09-03 08:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:04 --> Total execution time: 0.0934
DEBUG - 2022-09-03 08:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:04 --> Total execution time: 0.0936
DEBUG - 2022-09-03 08:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:04 --> Total execution time: 0.1294
DEBUG - 2022-09-03 08:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:04 --> Total execution time: 0.1128
DEBUG - 2022-09-03 08:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:07 --> Total execution time: 0.0951
DEBUG - 2022-09-03 08:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:07 --> Total execution time: 0.2278
DEBUG - 2022-09-03 08:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:24 --> Total execution time: 0.2615
DEBUG - 2022-09-03 08:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:31 --> Total execution time: 0.0985
DEBUG - 2022-09-03 08:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:33 --> Total execution time: 0.1043
DEBUG - 2022-09-03 08:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:38 --> Total execution time: 0.1016
DEBUG - 2022-09-03 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:40 --> Total execution time: 0.0980
DEBUG - 2022-09-03 08:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:40 --> Total execution time: 0.1021
DEBUG - 2022-09-03 08:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:51 --> Total execution time: 0.1026
DEBUG - 2022-09-03 08:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:35:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:05:59 --> Total execution time: 0.2525
DEBUG - 2022-09-03 08:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:06:02 --> Total execution time: 0.1050
DEBUG - 2022-09-03 19:06:03 --> Total execution time: 2.4758
DEBUG - 2022-09-03 08:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:36:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 08:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:06:08 --> Total execution time: 0.1094
DEBUG - 2022-09-03 08:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:06:18 --> Total execution time: 0.0989
DEBUG - 2022-09-03 08:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:06:26 --> Total execution time: 0.1074
DEBUG - 2022-09-03 08:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:06:29 --> Total execution time: 0.1094
DEBUG - 2022-09-03 08:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:07:13 --> Total execution time: 0.0991
DEBUG - 2022-09-03 08:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:37:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:07:23 --> Total execution time: 0.1035
DEBUG - 2022-09-03 08:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:37:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:07:28 --> Total execution time: 0.0915
DEBUG - 2022-09-03 08:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:37:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:07:58 --> Total execution time: 0.2599
DEBUG - 2022-09-03 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:38:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:08:09 --> Total execution time: 0.0922
DEBUG - 2022-09-03 08:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:08:13 --> Total execution time: 0.0938
DEBUG - 2022-09-03 08:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:38:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:38:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:08:46 --> Total execution time: 0.0944
DEBUG - 2022-09-03 08:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:39:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:39:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:09:16 --> Total execution time: 0.1113
DEBUG - 2022-09-03 08:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:39:22 --> 404 Page Not Found: Newsletter/index
DEBUG - 2022-09-03 08:39:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:39:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:39:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:09:23 --> Total execution time: 0.0921
DEBUG - 2022-09-03 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:40:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:10:05 --> Total execution time: 0.1018
DEBUG - 2022-09-03 08:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:40:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:10:41 --> Total execution time: 0.2486
DEBUG - 2022-09-03 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:40:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:40:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:10:56 --> Total execution time: 0.0986
DEBUG - 2022-09-03 08:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:04 --> Total execution time: 0.0965
DEBUG - 2022-09-03 08:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:11 --> Total execution time: 0.1016
DEBUG - 2022-09-03 08:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:21 --> Total execution time: 0.0993
DEBUG - 2022-09-03 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:26 --> Total execution time: 0.1041
DEBUG - 2022-09-03 08:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:31 --> Total execution time: 0.1009
DEBUG - 2022-09-03 08:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:47 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:47 --> Total execution time: 0.0950
DEBUG - 2022-09-03 08:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:11:54 --> Total execution time: 0.0935
DEBUG - 2022-09-03 08:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:12:07 --> Total execution time: 0.1325
DEBUG - 2022-09-03 08:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:42:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:42:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:12:40 --> Total execution time: 0.1007
DEBUG - 2022-09-03 08:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:44:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:14:18 --> Total execution time: 0.0659
DEBUG - 2022-09-03 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:44:52 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:14:52 --> Total execution time: 0.0632
DEBUG - 2022-09-03 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:15:26 --> Total execution time: 0.0961
DEBUG - 2022-09-03 08:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:15:27 --> Total execution time: 0.5101
DEBUG - 2022-09-03 08:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:15:30 --> Total execution time: 0.3335
DEBUG - 2022-09-03 08:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:15:40 --> Total execution time: 0.3713
DEBUG - 2022-09-03 08:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:45:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:15:50 --> Total execution time: 0.0940
DEBUG - 2022-09-03 08:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:46:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:16:01 --> Total execution time: 0.0658
DEBUG - 2022-09-03 08:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:46:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:46:21 --> Total execution time: 0.1138
DEBUG - 2022-09-03 08:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:46:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:46:23 --> Total execution time: 0.1097
DEBUG - 2022-09-03 08:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:46:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:46:24 --> Total execution time: 0.1058
DEBUG - 2022-09-03 08:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:18:12 --> Total execution time: 0.0590
DEBUG - 2022-09-03 08:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:18:28 --> Total execution time: 0.0889
DEBUG - 2022-09-03 08:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:18:43 --> Total execution time: 0.0994
DEBUG - 2022-09-03 08:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:18:52 --> Total execution time: 0.1068
DEBUG - 2022-09-03 08:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:18:59 --> Total execution time: 0.1199
DEBUG - 2022-09-03 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:02 --> Total execution time: 0.1051
DEBUG - 2022-09-03 08:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:03 --> Total execution time: 0.1029
DEBUG - 2022-09-03 08:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:10 --> Total execution time: 0.0963
DEBUG - 2022-09-03 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:15 --> Total execution time: 0.1077
DEBUG - 2022-09-03 08:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:15 --> Total execution time: 0.1028
DEBUG - 2022-09-03 08:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:25 --> Total execution time: 0.1112
DEBUG - 2022-09-03 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:27 --> Total execution time: 0.1034
DEBUG - 2022-09-03 08:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:31 --> Total execution time: 0.0972
DEBUG - 2022-09-03 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:34 --> Total execution time: 0.0999
DEBUG - 2022-09-03 08:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:19:44 --> Total execution time: 0.1037
DEBUG - 2022-09-03 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:50:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:20:32 --> Total execution time: 0.0668
DEBUG - 2022-09-03 08:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:21:16 --> Total execution time: 0.0945
DEBUG - 2022-09-03 08:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:51:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:21:37 --> Total execution time: 1.9069
DEBUG - 2022-09-03 08:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:51:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:51:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 08:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:22:16 --> Total execution time: 0.1402
DEBUG - 2022-09-03 08:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:22:17 --> Total execution time: 0.2613
DEBUG - 2022-09-03 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:52:38 --> 404 Page Not Found: Product/premium-membership
DEBUG - 2022-09-03 08:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:22:49 --> Total execution time: 0.1049
DEBUG - 2022-09-03 08:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:22:53 --> Total execution time: 0.1458
DEBUG - 2022-09-03 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:55:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:55:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:25:39 --> Total execution time: 0.0650
DEBUG - 2022-09-03 08:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:57:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:27:43 --> Total execution time: 0.1273
DEBUG - 2022-09-03 08:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:27:56 --> Total execution time: 0.5420
DEBUG - 2022-09-03 08:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:28:07 --> Total execution time: 0.0918
DEBUG - 2022-09-03 08:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:28:36 --> Total execution time: 0.1253
DEBUG - 2022-09-03 08:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:28:57 --> Total execution time: 0.1016
DEBUG - 2022-09-03 08:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 08:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:06 --> Total execution time: 0.2583
DEBUG - 2022-09-03 08:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:13 --> Total execution time: 0.3261
DEBUG - 2022-09-03 08:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:29 --> Total execution time: 0.1004
DEBUG - 2022-09-03 08:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 08:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:35 --> Total execution time: 0.0900
DEBUG - 2022-09-03 08:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 08:59:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:51 --> Total execution time: 2.0889
DEBUG - 2022-09-03 08:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 08:59:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 08:59:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:00:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:30:01 --> Total execution time: 0.0691
DEBUG - 2022-09-03 09:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:00:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:01:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:31:03 --> Total execution time: 0.1103
DEBUG - 2022-09-03 09:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:01:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:31:04 --> Total execution time: 0.1066
DEBUG - 2022-09-03 09:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:01:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:31:09 --> Total execution time: 0.1097
DEBUG - 2022-09-03 09:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:31:19 --> Total execution time: 0.0993
DEBUG - 2022-09-03 09:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:02:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:32:59 --> Total execution time: 0.2906
DEBUG - 2022-09-03 09:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:01 --> Total execution time: 0.2622
DEBUG - 2022-09-03 09:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:12 --> Total execution time: 0.0891
DEBUG - 2022-09-03 09:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:25 --> Total execution time: 0.0945
DEBUG - 2022-09-03 09:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:32 --> Total execution time: 0.0977
DEBUG - 2022-09-03 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:36 --> Total execution time: 0.0914
DEBUG - 2022-09-03 09:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:03:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:33:41 --> Total execution time: 0.0926
DEBUG - 2022-09-03 09:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:04:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:04:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:34:00 --> Total execution time: 0.0963
DEBUG - 2022-09-03 09:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:05:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:35:45 --> Total execution time: 0.3793
DEBUG - 2022-09-03 09:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:35:58 --> Total execution time: 0.1067
DEBUG - 2022-09-03 09:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:01 --> Total execution time: 0.3263
DEBUG - 2022-09-03 09:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:06 --> Total execution time: 0.1050
DEBUG - 2022-09-03 09:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:11 --> Total execution time: 0.1044
DEBUG - 2022-09-03 09:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:20 --> Total execution time: 0.1035
DEBUG - 2022-09-03 09:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:27 --> Total execution time: 0.1292
DEBUG - 2022-09-03 09:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:32 --> Total execution time: 0.1306
DEBUG - 2022-09-03 09:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:47 --> Total execution time: 0.1085
DEBUG - 2022-09-03 09:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:48 --> Total execution time: 0.1028
DEBUG - 2022-09-03 09:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:51 --> Total execution time: 0.1003
DEBUG - 2022-09-03 09:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:36:59 --> Total execution time: 0.1047
DEBUG - 2022-09-03 09:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:04 --> Total execution time: 0.1026
DEBUG - 2022-09-03 09:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:08 --> Total execution time: 0.1156
DEBUG - 2022-09-03 09:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:12 --> Total execution time: 0.1105
DEBUG - 2022-09-03 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:25 --> Total execution time: 0.0878
DEBUG - 2022-09-03 09:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:26 --> Total execution time: 0.0948
DEBUG - 2022-09-03 09:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:50 --> Total execution time: 0.1220
DEBUG - 2022-09-03 09:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:54 --> Total execution time: 0.0699
DEBUG - 2022-09-03 09:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:37:57 --> Total execution time: 0.1072
DEBUG - 2022-09-03 09:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:11 --> Total execution time: 0.0991
DEBUG - 2022-09-03 09:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:18 --> Total execution time: 0.1022
DEBUG - 2022-09-03 09:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:24 --> Total execution time: 0.1074
DEBUG - 2022-09-03 09:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:25 --> Total execution time: 0.0891
DEBUG - 2022-09-03 09:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:26 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:26 --> Total execution time: 0.0587
DEBUG - 2022-09-03 09:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:29 --> Total execution time: 0.1104
DEBUG - 2022-09-03 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:37 --> Total execution time: 0.0949
DEBUG - 2022-09-03 09:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:40 --> Total execution time: 0.1024
DEBUG - 2022-09-03 09:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:44 --> Total execution time: 0.1053
DEBUG - 2022-09-03 09:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:08:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:38:48 --> Total execution time: 0.1265
DEBUG - 2022-09-03 09:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:39:04 --> Total execution time: 0.1112
DEBUG - 2022-09-03 09:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:09:08 --> Total execution time: 0.0637
DEBUG - 2022-09-03 09:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:09:10 --> Total execution time: 0.1043
DEBUG - 2022-09-03 09:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:39:11 --> Total execution time: 0.1018
DEBUG - 2022-09-03 09:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:09:11 --> Total execution time: 0.0965
DEBUG - 2022-09-03 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:39:17 --> Total execution time: 0.1059
DEBUG - 2022-09-03 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:39:17 --> Total execution time: 0.1356
DEBUG - 2022-09-03 09:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:39:22 --> Total execution time: 0.1312
DEBUG - 2022-09-03 09:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:10:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:10:44 --> Total execution time: 0.0958
DEBUG - 2022-09-03 09:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:10:46 --> Total execution time: 0.0987
DEBUG - 2022-09-03 09:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:10:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:10:46 --> Total execution time: 0.1021
DEBUG - 2022-09-03 09:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:11:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:41:24 --> Total execution time: 0.0651
DEBUG - 2022-09-03 09:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:26 --> Total execution time: 0.2669
DEBUG - 2022-09-03 09:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:29 --> Total execution time: 0.2547
DEBUG - 2022-09-03 09:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:34 --> Total execution time: 0.1043
DEBUG - 2022-09-03 09:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:39 --> Total execution time: 0.1068
DEBUG - 2022-09-03 09:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:47 --> Total execution time: 0.0943
DEBUG - 2022-09-03 09:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:42:55 --> Total execution time: 0.1056
DEBUG - 2022-09-03 09:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:00 --> Total execution time: 0.1158
DEBUG - 2022-09-03 09:13:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:04 --> Total execution time: 0.0741
DEBUG - 2022-09-03 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:13 --> Total execution time: 0.0544
DEBUG - 2022-09-03 09:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:25 --> Total execution time: 0.1084
DEBUG - 2022-09-03 09:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:26 --> Total execution time: 0.0933
DEBUG - 2022-09-03 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 09:13:38 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 09:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:38 --> Total execution time: 0.0662
DEBUG - 2022-09-03 09:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:45 --> Total execution time: 0.1030
DEBUG - 2022-09-03 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:43:48 --> Total execution time: 0.0934
DEBUG - 2022-09-03 09:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:44:18 --> Total execution time: 0.1185
DEBUG - 2022-09-03 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:17:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:47:04 --> Total execution time: 0.3527
DEBUG - 2022-09-03 09:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:17:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:47:13 --> Total execution time: 0.1424
DEBUG - 2022-09-03 09:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:47:29 --> Total execution time: 0.0968
DEBUG - 2022-09-03 09:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:47:58 --> Total execution time: 0.3661
DEBUG - 2022-09-03 09:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:18:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:18:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:48:11 --> Total execution time: 0.0680
DEBUG - 2022-09-03 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:48:26 --> Total execution time: 0.0603
DEBUG - 2022-09-03 09:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:18:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:48:48 --> Total execution time: 0.0961
DEBUG - 2022-09-03 09:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:18:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:48:57 --> Total execution time: 0.1243
DEBUG - 2022-09-03 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:19:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:49:08 --> Total execution time: 0.0997
DEBUG - 2022-09-03 09:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:19:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:49:23 --> Total execution time: 0.1027
DEBUG - 2022-09-03 09:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:20:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:20:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:50:46 --> Total execution time: 0.1011
DEBUG - 2022-09-03 09:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:51:05 --> Total execution time: 0.0982
DEBUG - 2022-09-03 09:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:51:12 --> Total execution time: 0.1270
DEBUG - 2022-09-03 09:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:21:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:51:37 --> Total execution time: 0.0939
DEBUG - 2022-09-03 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:51:55 --> Total execution time: 0.1003
DEBUG - 2022-09-03 09:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:52:31 --> Total execution time: 0.0972
DEBUG - 2022-09-03 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:22:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:52:46 --> Total execution time: 0.0954
DEBUG - 2022-09-03 09:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:07 --> Total execution time: 0.0966
DEBUG - 2022-09-03 09:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:28 --> Total execution time: 0.0931
DEBUG - 2022-09-03 09:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:35 --> Total execution time: 0.1304
DEBUG - 2022-09-03 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:53 --> Total execution time: 0.1011
DEBUG - 2022-09-03 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:54 --> Total execution time: 0.0746
DEBUG - 2022-09-03 19:53:54 --> Total execution time: 0.0741
DEBUG - 2022-09-03 09:23:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:54 --> Total execution time: 0.0641
DEBUG - 2022-09-03 09:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:55 --> Total execution time: 0.0603
DEBUG - 2022-09-03 09:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:56 --> Total execution time: 0.0595
DEBUG - 2022-09-03 09:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:53:59 --> Total execution time: 0.1034
DEBUG - 2022-09-03 09:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:54:08 --> Total execution time: 0.1057
DEBUG - 2022-09-03 09:24:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:24:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:54:11 --> Total execution time: 0.0940
DEBUG - 2022-09-03 09:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:54:12 --> Total execution time: 0.0958
DEBUG - 2022-09-03 09:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:24:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:54:15 --> Total execution time: 0.1019
DEBUG - 2022-09-03 09:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:25:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:55:31 --> Total execution time: 0.2514
DEBUG - 2022-09-03 09:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:26:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:56:06 --> Total execution time: 0.0954
DEBUG - 2022-09-03 09:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:57:43 --> Total execution time: 0.0607
DEBUG - 2022-09-03 09:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:58:45 --> Total execution time: 0.1012
DEBUG - 2022-09-03 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:20 --> Total execution time: 0.0676
DEBUG - 2022-09-03 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:21 --> Total execution time: 0.0955
DEBUG - 2022-09-03 09:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:26 --> Total execution time: 0.0954
DEBUG - 2022-09-03 09:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:29 --> Total execution time: 0.0953
DEBUG - 2022-09-03 09:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:37 --> Total execution time: 0.0965
DEBUG - 2022-09-03 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:41 --> Total execution time: 0.0968
DEBUG - 2022-09-03 09:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:29:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:56 --> Total execution time: 0.0936
DEBUG - 2022-09-03 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:00 --> Total execution time: 0.0973
DEBUG - 2022-09-03 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:03 --> Total execution time: 0.1012
DEBUG - 2022-09-03 09:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:05 --> Total execution time: 0.1290
DEBUG - 2022-09-03 09:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:13 --> Total execution time: 0.0983
DEBUG - 2022-09-03 09:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:19 --> Total execution time: 0.0982
DEBUG - 2022-09-03 09:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:22 --> Total execution time: 0.1079
DEBUG - 2022-09-03 09:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:25 --> Total execution time: 0.1052
DEBUG - 2022-09-03 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:32 --> Total execution time: 0.0619
DEBUG - 2022-09-03 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:35 --> Total execution time: 0.0641
DEBUG - 2022-09-03 09:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:30:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:46 --> Total execution time: 0.1072
DEBUG - 2022-09-03 09:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:31:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:01:06 --> Total execution time: 0.0989
DEBUG - 2022-09-03 09:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:01:31 --> Total execution time: 0.1028
DEBUG - 2022-09-03 09:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:02:34 --> Total execution time: 0.0647
DEBUG - 2022-09-03 09:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:02:40 --> Total execution time: 0.0591
DEBUG - 2022-09-03 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:32:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:02:45 --> Total execution time: 0.1357
DEBUG - 2022-09-03 09:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:32:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:02:54 --> Total execution time: 0.1027
DEBUG - 2022-09-03 09:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:03:01 --> Total execution time: 0.1307
DEBUG - 2022-09-03 09:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:33:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:03:34 --> Total execution time: 0.3426
DEBUG - 2022-09-03 09:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:33:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:03:35 --> Total execution time: 0.0962
DEBUG - 2022-09-03 09:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:34:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:34:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:04:28 --> Total execution time: 0.1010
DEBUG - 2022-09-03 09:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:34:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:04:35 --> Total execution time: 0.0594
DEBUG - 2022-09-03 09:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:34:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:34:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:04:38 --> Total execution time: 0.0954
DEBUG - 2022-09-03 09:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:34:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:34:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:04:39 --> Total execution time: 0.0619
DEBUG - 2022-09-03 09:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:05:22 --> Total execution time: 2.3309
DEBUG - 2022-09-03 09:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:35:24 --> Total execution time: 0.0972
DEBUG - 2022-09-03 09:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 09:35:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:35:27 --> Total execution time: 0.0945
DEBUG - 2022-09-03 09:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:35:27 --> Total execution time: 0.1002
DEBUG - 2022-09-03 09:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:05:37 --> Total execution time: 0.0949
DEBUG - 2022-09-03 09:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:05:41 --> Total execution time: 0.0988
DEBUG - 2022-09-03 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:35:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:05:56 --> Total execution time: 0.1134
DEBUG - 2022-09-03 09:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:03 --> Total execution time: 0.0893
DEBUG - 2022-09-03 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:10 --> Total execution time: 0.0971
DEBUG - 2022-09-03 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:17 --> Total execution time: 0.1509
DEBUG - 2022-09-03 09:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:24 --> Total execution time: 0.0939
DEBUG - 2022-09-03 09:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:33 --> Total execution time: 0.0968
DEBUG - 2022-09-03 09:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:46 --> Total execution time: 0.1093
DEBUG - 2022-09-03 09:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:36:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:06:57 --> Total execution time: 1.8490
DEBUG - 2022-09-03 09:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:37:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 09:37:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 09:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:38:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:38:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:08:06 --> Total execution time: 0.1050
DEBUG - 2022-09-03 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:09:47 --> Total execution time: 0.0970
DEBUG - 2022-09-03 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:40:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:10:12 --> Total execution time: 0.0941
DEBUG - 2022-09-03 09:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:11:28 --> Total execution time: 0.0975
DEBUG - 2022-09-03 09:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:11:32 --> Total execution time: 0.0987
DEBUG - 2022-09-03 09:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:41:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:11:43 --> Total execution time: 0.1026
DEBUG - 2022-09-03 09:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:42:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:07 --> Total execution time: 0.0970
DEBUG - 2022-09-03 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:13:30 --> Total execution time: 1.9630
DEBUG - 2022-09-03 09:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:10 --> Total execution time: 0.0917
DEBUG - 2022-09-03 09:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:14 --> Total execution time: 0.0918
DEBUG - 2022-09-03 09:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:36 --> Total execution time: 0.1328
DEBUG - 2022-09-03 09:44:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:44:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:55 --> Total execution time: 0.1013
DEBUG - 2022-09-03 09:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:00 --> Total execution time: 0.0950
DEBUG - 2022-09-03 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:45:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:03 --> Total execution time: 0.0946
DEBUG - 2022-09-03 09:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:45:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:09 --> Total execution time: 0.0948
DEBUG - 2022-09-03 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:45:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:45:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:22 --> Total execution time: 0.0957
DEBUG - 2022-09-03 09:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:46:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:08 --> Total execution time: 0.0644
DEBUG - 2022-09-03 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:46:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:13 --> Total execution time: 0.0553
DEBUG - 2022-09-03 09:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:46:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:46:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:34 --> Total execution time: 0.1027
DEBUG - 2022-09-03 09:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:46:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:46:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:44 --> Total execution time: 0.0678
DEBUG - 2022-09-03 09:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:46:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:46:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:55 --> Total execution time: 0.0972
DEBUG - 2022-09-03 09:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:47:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:47:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:17:31 --> Total execution time: 0.1001
DEBUG - 2022-09-03 09:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:47:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:47:34 --> Total execution time: 0.0938
DEBUG - 2022-09-03 09:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:47:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:47:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:17:56 --> Total execution time: 0.1017
DEBUG - 2022-09-03 09:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:48:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:18:06 --> Total execution time: 0.1335
DEBUG - 2022-09-03 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:48:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:18:18 --> Total execution time: 0.1204
DEBUG - 2022-09-03 09:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:18:57 --> Total execution time: 0.2564
DEBUG - 2022-09-03 09:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:49:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:19:15 --> Total execution time: 0.1018
DEBUG - 2022-09-03 09:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:49:46 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:49:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:19:46 --> Total execution time: 0.0750
DEBUG - 2022-09-03 09:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:19:51 --> Total execution time: 0.0958
DEBUG - 2022-09-03 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:15 --> Total execution time: 0.0990
DEBUG - 2022-09-03 09:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:20 --> Total execution time: 0.0637
DEBUG - 2022-09-03 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:23 --> Total execution time: 0.0940
DEBUG - 2022-09-03 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:23 --> Total execution time: 0.0874
DEBUG - 2022-09-03 09:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:24 --> Total execution time: 0.0963
DEBUG - 2022-09-03 09:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:29 --> Total execution time: 0.0969
DEBUG - 2022-09-03 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:30 --> Total execution time: 0.0875
DEBUG - 2022-09-03 09:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:30 --> Total execution time: 0.1228
DEBUG - 2022-09-03 09:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:33 --> Total execution time: 0.1223
DEBUG - 2022-09-03 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:34 --> Total execution time: 0.0609
DEBUG - 2022-09-03 09:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:35 --> Total execution time: 0.0967
DEBUG - 2022-09-03 09:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:38 --> Total execution time: 0.0950
DEBUG - 2022-09-03 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:42 --> Total execution time: 0.1001
DEBUG - 2022-09-03 09:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:46 --> Total execution time: 0.1405
DEBUG - 2022-09-03 09:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:49 --> Total execution time: 0.0979
DEBUG - 2022-09-03 09:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:21:01 --> Total execution time: 0.1024
DEBUG - 2022-09-03 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:21:22 --> Total execution time: 0.1032
DEBUG - 2022-09-03 09:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:21:32 --> Total execution time: 0.0956
DEBUG - 2022-09-03 09:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:38 --> Total execution time: 0.0905
DEBUG - 2022-09-03 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:40 --> Total execution time: 0.0926
DEBUG - 2022-09-03 09:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:40 --> Total execution time: 0.2234
DEBUG - 2022-09-03 09:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:21:49 --> Total execution time: 0.0970
DEBUG - 2022-09-03 09:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:21:53 --> Total execution time: 0.1004
DEBUG - 2022-09-03 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:52:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:22:05 --> Total execution time: 0.1115
DEBUG - 2022-09-03 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:52:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:22:10 --> Total execution time: 0.1213
DEBUG - 2022-09-03 09:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:52:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:52:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:22:26 --> Total execution time: 0.1063
DEBUG - 2022-09-03 09:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:52:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:22:59 --> Total execution time: 0.1454
DEBUG - 2022-09-03 09:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:01 --> Total execution time: 0.2107
DEBUG - 2022-09-03 09:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:16 --> Total execution time: 0.2679
DEBUG - 2022-09-03 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:25 --> Total execution time: 0.1338
DEBUG - 2022-09-03 09:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:30 --> Total execution time: 0.1005
DEBUG - 2022-09-03 09:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:30 --> Total execution time: 0.1178
DEBUG - 2022-09-03 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:37 --> Total execution time: 0.1032
DEBUG - 2022-09-03 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:37 --> Total execution time: 0.0905
DEBUG - 2022-09-03 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:23:38 --> Total execution time: 0.1239
DEBUG - 2022-09-03 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:14 --> Total execution time: 0.1039
DEBUG - 2022-09-03 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:16 --> Total execution time: 0.1014
DEBUG - 2022-09-03 09:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:25 --> Total execution time: 0.1264
DEBUG - 2022-09-03 09:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:28 --> Total execution time: 0.0961
DEBUG - 2022-09-03 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:30 --> Total execution time: 0.2714
DEBUG - 2022-09-03 09:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:54:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:24:34 --> Total execution time: 0.1000
DEBUG - 2022-09-03 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:23 --> Total execution time: 0.1429
DEBUG - 2022-09-03 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:25 --> Total execution time: 0.0594
DEBUG - 2022-09-03 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:26 --> Total execution time: 0.1423
DEBUG - 2022-09-03 09:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:27 --> Total execution time: 0.2500
DEBUG - 2022-09-03 09:55:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:37 --> Total execution time: 0.0963
DEBUG - 2022-09-03 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:46 --> Total execution time: 0.1075
DEBUG - 2022-09-03 09:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:52 --> Total execution time: 0.0922
DEBUG - 2022-09-03 09:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:25:58 --> Total execution time: 0.1100
DEBUG - 2022-09-03 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:02 --> Total execution time: 0.0984
DEBUG - 2022-09-03 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:28 --> Total execution time: 0.1003
DEBUG - 2022-09-03 09:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:34 --> Total execution time: 0.0957
DEBUG - 2022-09-03 09:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:37 --> Total execution time: 0.0969
DEBUG - 2022-09-03 09:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:38 --> Total execution time: 0.0932
DEBUG - 2022-09-03 09:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:44 --> Total execution time: 0.0994
DEBUG - 2022-09-03 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:45 --> Total execution time: 0.0936
DEBUG - 2022-09-03 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:49 --> Total execution time: 0.0996
DEBUG - 2022-09-03 09:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:50 --> Total execution time: 0.1085
DEBUG - 2022-09-03 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:26:52 --> Total execution time: 0.0956
DEBUG - 2022-09-03 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:01 --> Total execution time: 0.1270
DEBUG - 2022-09-03 09:57:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:01 --> Total execution time: 0.2834
DEBUG - 2022-09-03 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:02 --> Total execution time: 0.1160
DEBUG - 2022-09-03 09:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:06 --> Total execution time: 0.2442
DEBUG - 2022-09-03 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:13 --> Total execution time: 0.1236
DEBUG - 2022-09-03 09:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:48 --> Total execution time: 0.0959
DEBUG - 2022-09-03 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:50 --> Total execution time: 0.0921
DEBUG - 2022-09-03 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:55 --> Total execution time: 0.1113
DEBUG - 2022-09-03 09:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:56 --> Total execution time: 0.1000
DEBUG - 2022-09-03 09:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:57:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:27:58 --> Total execution time: 0.0999
DEBUG - 2022-09-03 09:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:05 --> Total execution time: 0.1082
DEBUG - 2022-09-03 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:06 --> Total execution time: 0.1036
DEBUG - 2022-09-03 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:06 --> Total execution time: 0.0709
DEBUG - 2022-09-03 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:12 --> Total execution time: 0.2451
DEBUG - 2022-09-03 09:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:12 --> Total execution time: 0.1053
DEBUG - 2022-09-03 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:13 --> Total execution time: 0.0539
DEBUG - 2022-09-03 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:17 --> Total execution time: 0.1011
DEBUG - 2022-09-03 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:17 --> Total execution time: 0.2024
DEBUG - 2022-09-03 09:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:17 --> Total execution time: 0.1135
DEBUG - 2022-09-03 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:26 --> Total execution time: 0.1071
DEBUG - 2022-09-03 09:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:28 --> Total execution time: 0.0967
DEBUG - 2022-09-03 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:30 --> Total execution time: 0.1134
DEBUG - 2022-09-03 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:30 --> Total execution time: 0.1018
DEBUG - 2022-09-03 09:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:33 --> Total execution time: 0.0970
DEBUG - 2022-09-03 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:40 --> Total execution time: 0.1550
DEBUG - 2022-09-03 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:46 --> Total execution time: 0.0936
DEBUG - 2022-09-03 09:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:28:59 --> Total execution time: 0.0961
DEBUG - 2022-09-03 09:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:07 --> Total execution time: 0.1239
DEBUG - 2022-09-03 09:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:18 --> Total execution time: 0.1061
DEBUG - 2022-09-03 09:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:19 --> Total execution time: 0.1693
DEBUG - 2022-09-03 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 09:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:21 --> Total execution time: 0.0923
DEBUG - 2022-09-03 09:59:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:21 --> Total execution time: 0.1558
DEBUG - 2022-09-03 09:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:23 --> Total execution time: 0.0908
DEBUG - 2022-09-03 09:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:35 --> Total execution time: 0.1057
DEBUG - 2022-09-03 09:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:44 --> Total execution time: 0.1104
DEBUG - 2022-09-03 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:51 --> Total execution time: 0.1084
DEBUG - 2022-09-03 09:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:54 --> Total execution time: 0.0931
DEBUG - 2022-09-03 09:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 09:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 09:59:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:29:56 --> Total execution time: 0.1002
DEBUG - 2022-09-03 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:01 --> Total execution time: 0.1301
DEBUG - 2022-09-03 10:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:02 --> Total execution time: 0.0882
DEBUG - 2022-09-03 10:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:10 --> Total execution time: 0.1004
DEBUG - 2022-09-03 10:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:11 --> Total execution time: 0.0997
DEBUG - 2022-09-03 10:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:11 --> Total execution time: 0.0981
DEBUG - 2022-09-03 10:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:17 --> Total execution time: 0.1000
DEBUG - 2022-09-03 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:26 --> Total execution time: 0.0976
DEBUG - 2022-09-03 10:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:39 --> Total execution time: 0.1123
DEBUG - 2022-09-03 10:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:44 --> Total execution time: 0.1213
DEBUG - 2022-09-03 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:45 --> Total execution time: 0.2809
DEBUG - 2022-09-03 10:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:52 --> Total execution time: 0.0936
DEBUG - 2022-09-03 10:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:54 --> Total execution time: 0.0635
DEBUG - 2022-09-03 10:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:00:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:30:59 --> Total execution time: 0.0936
DEBUG - 2022-09-03 10:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:01:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:31:02 --> Total execution time: 0.1309
DEBUG - 2022-09-03 10:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:05 --> Total execution time: 0.1149
DEBUG - 2022-09-03 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:03:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:03:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:35 --> Total execution time: 0.0695
DEBUG - 2022-09-03 10:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:04:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:09 --> Total execution time: 0.1049
DEBUG - 2022-09-03 10:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:05:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:05:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:12 --> Total execution time: 0.1232
DEBUG - 2022-09-03 10:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:18 --> Total execution time: 0.1207
DEBUG - 2022-09-03 10:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:27 --> Total execution time: 0.1093
DEBUG - 2022-09-03 10:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:05:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:29 --> Total execution time: 0.1254
DEBUG - 2022-09-03 10:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:07:57 --> Total execution time: 0.1582
DEBUG - 2022-09-03 10:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:08:04 --> Total execution time: 0.1094
DEBUG - 2022-09-03 10:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:10:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:21 --> Total execution time: 0.3069
DEBUG - 2022-09-03 10:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:10:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:29 --> Total execution time: 0.1391
DEBUG - 2022-09-03 10:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:12:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:12:16 --> Total execution time: 0.1245
DEBUG - 2022-09-03 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:12:24 --> Total execution time: 0.1342
DEBUG - 2022-09-03 10:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:31 --> Total execution time: 0.0693
DEBUG - 2022-09-03 10:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:13:16 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:16 --> Total execution time: 0.2597
DEBUG - 2022-09-03 10:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:03 --> Total execution time: 0.0602
DEBUG - 2022-09-03 10:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:39 --> Total execution time: 0.0633
DEBUG - 2022-09-03 10:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:39 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:43 --> Total execution time: 0.0948
DEBUG - 2022-09-03 10:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:14:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:52 --> Total execution time: 0.1018
DEBUG - 2022-09-03 10:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:07 --> Total execution time: 0.1164
DEBUG - 2022-09-03 10:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:15 --> Total execution time: 0.1025
DEBUG - 2022-09-03 10:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:18 --> Total execution time: 0.0638
DEBUG - 2022-09-03 10:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:19 --> Total execution time: 0.0776
DEBUG - 2022-09-03 10:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:21 --> Total execution time: 0.1356
DEBUG - 2022-09-03 10:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:22 --> Total execution time: 0.0677
DEBUG - 2022-09-03 10:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:23 --> Total execution time: 0.0589
DEBUG - 2022-09-03 10:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:27 --> Total execution time: 0.1041
DEBUG - 2022-09-03 10:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:28 --> Total execution time: 0.1003
DEBUG - 2022-09-03 10:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:28 --> Total execution time: 0.1131
DEBUG - 2022-09-03 10:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:31 --> Total execution time: 0.1517
DEBUG - 2022-09-03 10:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:32 --> Total execution time: 0.1066
DEBUG - 2022-09-03 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:36 --> Total execution time: 0.1010
DEBUG - 2022-09-03 10:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:37 --> Total execution time: 0.1092
DEBUG - 2022-09-03 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:43 --> Total execution time: 0.1420
DEBUG - 2022-09-03 10:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:44 --> Total execution time: 0.1289
DEBUG - 2022-09-03 10:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:44 --> Total execution time: 0.0953
DEBUG - 2022-09-03 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:15:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:45:57 --> Total execution time: 0.1060
DEBUG - 2022-09-03 10:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:16:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:46:08 --> Total execution time: 0.1039
DEBUG - 2022-09-03 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:16:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:46:11 --> Total execution time: 0.0943
DEBUG - 2022-09-03 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:47:14 --> Total execution time: 0.0636
DEBUG - 2022-09-03 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:47:15 --> Total execution time: 0.0581
DEBUG - 2022-09-03 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:47:18 --> Total execution time: 0.0700
DEBUG - 2022-09-03 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:47:36 --> Total execution time: 0.1014
DEBUG - 2022-09-03 10:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:17:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:47:48 --> Total execution time: 0.1696
DEBUG - 2022-09-03 10:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:48:31 --> Total execution time: 0.3017
DEBUG - 2022-09-03 10:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:48:37 --> Total execution time: 0.1078
DEBUG - 2022-09-03 10:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:48:38 --> Total execution time: 0.0654
DEBUG - 2022-09-03 10:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:48:45 --> Total execution time: 0.1013
DEBUG - 2022-09-03 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:18:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:48:51 --> Total execution time: 0.1000
DEBUG - 2022-09-03 10:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:19:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:49:10 --> Total execution time: 0.1004
DEBUG - 2022-09-03 10:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:19:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:49:41 --> Total execution time: 0.0619
DEBUG - 2022-09-03 10:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:19:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:49:59 --> Total execution time: 0.0964
DEBUG - 2022-09-03 10:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:50:17 --> Total execution time: 0.0982
DEBUG - 2022-09-03 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:50:50 --> Total execution time: 0.0998
DEBUG - 2022-09-03 10:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:20:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:21:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:51:17 --> Total execution time: 0.1011
DEBUG - 2022-09-03 10:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:06 --> Total execution time: 0.0839
DEBUG - 2022-09-03 10:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:14 --> Total execution time: 0.0647
DEBUG - 2022-09-03 10:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:37 --> Total execution time: 0.0972
DEBUG - 2022-09-03 10:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:37 --> Total execution time: 0.1039
DEBUG - 2022-09-03 10:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:44 --> Total execution time: 0.3428
DEBUG - 2022-09-03 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:23:02 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:23:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:53:02 --> Total execution time: 0.0661
DEBUG - 2022-09-03 10:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:23:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:23:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:53:25 --> Total execution time: 0.0967
DEBUG - 2022-09-03 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:23:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:23:42 --> Total execution time: 0.0969
DEBUG - 2022-09-03 10:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:23:44 --> Total execution time: 0.1103
DEBUG - 2022-09-03 10:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:23:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:23:44 --> Total execution time: 0.1010
DEBUG - 2022-09-03 10:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:25:17 --> Total execution time: 0.0887
DEBUG - 2022-09-03 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:25:19 --> Total execution time: 0.0875
DEBUG - 2022-09-03 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:25:20 --> Total execution time: 0.0944
DEBUG - 2022-09-03 10:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:25:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:55:55 --> Total execution time: 0.0920
DEBUG - 2022-09-03 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:01 --> Total execution time: 0.1114
DEBUG - 2022-09-03 10:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:26:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:12 --> Total execution time: 0.0973
DEBUG - 2022-09-03 10:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:26:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:26 --> Total execution time: 0.0939
DEBUG - 2022-09-03 10:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:46 --> Total execution time: 0.1418
DEBUG - 2022-09-03 10:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:26:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:50 --> Total execution time: 0.0930
DEBUG - 2022-09-03 10:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:52 --> Total execution time: 0.2863
DEBUG - 2022-09-03 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:55 --> Total execution time: 0.1309
DEBUG - 2022-09-03 10:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:01 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:15 --> Total execution time: 0.1084
DEBUG - 2022-09-03 10:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:28:28 --> Total execution time: 0.1001
DEBUG - 2022-09-03 10:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:31 --> Total execution time: 0.0993
DEBUG - 2022-09-03 10:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:28:34 --> Total execution time: 0.1116
DEBUG - 2022-09-03 10:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:35 --> Total execution time: 0.0636
DEBUG - 2022-09-03 10:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:46 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:50 --> Total execution time: 0.0991
DEBUG - 2022-09-03 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:28:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:58:54 --> Total execution time: 0.1016
DEBUG - 2022-09-03 10:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:30:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:27 --> Total execution time: 0.1225
DEBUG - 2022-09-03 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:05 --> Total execution time: 0.2630
DEBUG - 2022-09-03 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:08 --> Total execution time: 0.1032
DEBUG - 2022-09-03 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:08 --> Total execution time: 0.0888
DEBUG - 2022-09-03 10:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:20 --> Total execution time: 0.0975
DEBUG - 2022-09-03 10:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:28 --> Total execution time: 0.1007
DEBUG - 2022-09-03 10:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:30 --> Total execution time: 0.0988
DEBUG - 2022-09-03 10:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:31:31 --> Total execution time: 0.0985
DEBUG - 2022-09-03 10:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 21:01:38 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2022-09-03 10:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:39 --> Total execution time: 0.1173
DEBUG - 2022-09-03 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:41 --> Total execution time: 0.2453
DEBUG - 2022-09-03 10:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:31:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:49 --> Total execution time: 0.1211
DEBUG - 2022-09-03 10:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:02:02 --> Total execution time: 0.1062
DEBUG - 2022-09-03 10:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:02:21 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:02:24 --> Total execution time: 0.1308
DEBUG - 2022-09-03 10:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:02:37 --> Total execution time: 0.0984
DEBUG - 2022-09-03 10:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:32:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:32:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:02:55 --> Total execution time: 0.1100
DEBUG - 2022-09-03 10:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:01 --> Total execution time: 0.1231
DEBUG - 2022-09-03 10:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:03 --> Total execution time: 0.0965
DEBUG - 2022-09-03 10:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:04 --> Total execution time: 0.1489
DEBUG - 2022-09-03 10:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:11 --> Total execution time: 0.0973
DEBUG - 2022-09-03 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:19 --> Total execution time: 0.0642
DEBUG - 2022-09-03 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:19 --> Total execution time: 0.0617
DEBUG - 2022-09-03 10:33:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:19 --> Total execution time: 0.1022
DEBUG - 2022-09-03 10:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:22 --> Total execution time: 0.1231
DEBUG - 2022-09-03 10:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:25 --> Total execution time: 0.1010
DEBUG - 2022-09-03 10:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:28 --> Total execution time: 0.0998
DEBUG - 2022-09-03 10:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:30 --> Total execution time: 0.0943
DEBUG - 2022-09-03 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:31 --> Total execution time: 0.0948
DEBUG - 2022-09-03 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:38 --> Total execution time: 0.1219
DEBUG - 2022-09-03 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:44 --> Total execution time: 0.1299
DEBUG - 2022-09-03 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:46 --> Total execution time: 0.1017
DEBUG - 2022-09-03 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:03:47 --> Total execution time: 0.0977
DEBUG - 2022-09-03 10:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:03 --> Total execution time: 0.1032
DEBUG - 2022-09-03 10:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:07 --> Total execution time: 0.1033
DEBUG - 2022-09-03 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:14 --> Total execution time: 0.2811
DEBUG - 2022-09-03 21:04:14 --> Total execution time: 0.2934
DEBUG - 2022-09-03 10:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:18 --> Total execution time: 0.1294
DEBUG - 2022-09-03 10:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:22 --> Total execution time: 0.0880
DEBUG - 2022-09-03 10:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:04:36 --> Total execution time: 0.1083
DEBUG - 2022-09-03 10:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:01 --> Total execution time: 0.1133
DEBUG - 2022-09-03 10:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:04 --> Total execution time: 0.1122
DEBUG - 2022-09-03 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:34 --> Total execution time: 0.0954
DEBUG - 2022-09-03 10:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:36 --> Total execution time: 0.1019
DEBUG - 2022-09-03 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:37 --> Total execution time: 0.0969
DEBUG - 2022-09-03 10:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:48 --> Total execution time: 0.0666
DEBUG - 2022-09-03 10:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:51 --> Total execution time: 0.0995
DEBUG - 2022-09-03 10:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:35:51 --> Total execution time: 0.0947
DEBUG - 2022-09-03 10:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:53 --> Total execution time: 0.1115
DEBUG - 2022-09-03 10:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:55 --> Total execution time: 0.1217
DEBUG - 2022-09-03 10:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:35:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:35:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:59 --> Total execution time: 0.1028
DEBUG - 2022-09-03 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:02 --> Total execution time: 0.0993
DEBUG - 2022-09-03 10:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:05 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:13 --> Total execution time: 0.1029
DEBUG - 2022-09-03 10:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:15 --> Total execution time: 0.1018
DEBUG - 2022-09-03 10:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:21 --> Total execution time: 0.1026
DEBUG - 2022-09-03 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:29 --> Total execution time: 0.1247
DEBUG - 2022-09-03 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:30 --> Total execution time: 0.1158
DEBUG - 2022-09-03 10:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:38 --> Total execution time: 0.0929
DEBUG - 2022-09-03 10:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:40 --> Total execution time: 0.2500
DEBUG - 2022-09-03 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:36:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:06:58 --> Total execution time: 0.1225
DEBUG - 2022-09-03 10:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:09 --> Total execution time: 0.0944
DEBUG - 2022-09-03 10:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:12 --> Total execution time: 0.1023
DEBUG - 2022-09-03 10:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:12 --> Total execution time: 0.1164
DEBUG - 2022-09-03 10:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:42 --> Total execution time: 0.0959
DEBUG - 2022-09-03 10:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:50 --> Total execution time: 0.2591
DEBUG - 2022-09-03 10:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:37:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:58 --> Total execution time: 0.0970
DEBUG - 2022-09-03 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 10:38:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 10:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:07 --> Total execution time: 0.1028
DEBUG - 2022-09-03 10:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:13 --> Total execution time: 0.1117
DEBUG - 2022-09-03 10:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:14 --> Total execution time: 0.1073
DEBUG - 2022-09-03 10:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:15 --> Total execution time: 0.2791
DEBUG - 2022-09-03 10:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:16 --> Total execution time: 0.0996
DEBUG - 2022-09-03 10:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:38:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:38:17 --> Total execution time: 0.1006
DEBUG - 2022-09-03 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:05 --> Total execution time: 0.0953
DEBUG - 2022-09-03 10:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:07 --> Total execution time: 0.1020
DEBUG - 2022-09-03 10:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:39:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:39:07 --> Total execution time: 0.0972
DEBUG - 2022-09-03 10:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:42:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:42:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:12:37 --> Total execution time: 0.3351
DEBUG - 2022-09-03 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:44:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:44:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:14:09 --> Total execution time: 0.2577
DEBUG - 2022-09-03 10:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:44:16 --> Total execution time: 0.0995
DEBUG - 2022-09-03 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:44:18 --> Total execution time: 0.0987
DEBUG - 2022-09-03 10:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:44:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:44:18 --> Total execution time: 0.1012
DEBUG - 2022-09-03 10:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:45:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:15:00 --> Total execution time: 0.0621
DEBUG - 2022-09-03 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:45:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:45:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:15:20 --> Total execution time: 2.3414
DEBUG - 2022-09-03 10:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:45:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 10:45:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 10:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:01 --> Total execution time: 0.0974
DEBUG - 2022-09-03 10:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:07 --> Total execution time: 0.2564
DEBUG - 2022-09-03 10:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:13 --> Total execution time: 0.0960
DEBUG - 2022-09-03 10:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:20 --> Total execution time: 0.0966
DEBUG - 2022-09-03 10:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:28 --> Total execution time: 0.1029
DEBUG - 2022-09-03 10:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:30 --> Total execution time: 0.2366
DEBUG - 2022-09-03 10:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:39 --> Total execution time: 0.0802
DEBUG - 2022-09-03 10:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:58 --> Total execution time: 0.0895
DEBUG - 2022-09-03 10:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:16:59 --> Total execution time: 0.1040
DEBUG - 2022-09-03 10:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:08 --> Total execution time: 0.1015
DEBUG - 2022-09-03 10:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:08 --> Total execution time: 0.0907
DEBUG - 2022-09-03 10:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:47:12 --> Total execution time: 0.0606
DEBUG - 2022-09-03 10:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:17 --> Total execution time: 0.0959
DEBUG - 2022-09-03 10:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:19 --> Total execution time: 0.0990
DEBUG - 2022-09-03 10:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:20 --> Total execution time: 0.0948
DEBUG - 2022-09-03 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:47:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:47:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:17:24 --> Total execution time: 0.0950
DEBUG - 2022-09-03 10:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:48:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:48:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:18:31 --> Total execution time: 0.0969
DEBUG - 2022-09-03 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:19:45 --> Total execution time: 0.0941
DEBUG - 2022-09-03 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:49:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:19:56 --> Total execution time: 0.0987
DEBUG - 2022-09-03 10:49:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:19:56 --> Total execution time: 0.2507
DEBUG - 2022-09-03 10:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:10 --> Total execution time: 0.2441
DEBUG - 2022-09-03 10:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:11 --> Total execution time: 0.1058
DEBUG - 2022-09-03 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:19 --> Total execution time: 0.1125
DEBUG - 2022-09-03 10:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:29 --> Total execution time: 0.2957
DEBUG - 2022-09-03 10:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:33 --> Total execution time: 0.0957
DEBUG - 2022-09-03 10:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:38 --> Total execution time: 0.1003
DEBUG - 2022-09-03 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:45 --> Total execution time: 0.0992
DEBUG - 2022-09-03 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:53 --> Total execution time: 0.1037
DEBUG - 2022-09-03 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:54 --> Total execution time: 0.1234
DEBUG - 2022-09-03 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:50:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:59 --> Total execution time: 0.1019
DEBUG - 2022-09-03 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:01 --> Total execution time: 0.1662
DEBUG - 2022-09-03 21:21:01 --> Total execution time: 0.2697
DEBUG - 2022-09-03 10:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:08 --> Total execution time: 0.1220
DEBUG - 2022-09-03 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:14 --> Total execution time: 0.1247
DEBUG - 2022-09-03 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:18 --> Total execution time: 0.1211
DEBUG - 2022-09-03 10:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:26 --> Total execution time: 0.0928
DEBUG - 2022-09-03 10:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:34 --> Total execution time: 0.1004
DEBUG - 2022-09-03 10:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:47 --> Total execution time: 0.0943
DEBUG - 2022-09-03 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:51:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:55 --> Total execution time: 0.0883
DEBUG - 2022-09-03 10:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:52:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:52:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:01 --> Total execution time: 0.0980
DEBUG - 2022-09-03 10:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:52:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:44 --> Total execution time: 0.1026
DEBUG - 2022-09-03 10:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:02 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:02 --> Total execution time: 0.0978
DEBUG - 2022-09-03 10:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:09 --> Total execution time: 0.1272
DEBUG - 2022-09-03 10:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:17 --> Total execution time: 0.0939
DEBUG - 2022-09-03 10:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:19 --> Total execution time: 0.0941
DEBUG - 2022-09-03 10:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:58 --> Total execution time: 0.0954
DEBUG - 2022-09-03 10:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:59 --> Total execution time: 0.0966
DEBUG - 2022-09-03 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:54:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:24:08 --> Total execution time: 0.0959
DEBUG - 2022-09-03 10:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:54:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:54:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:24:15 --> Total execution time: 0.0994
DEBUG - 2022-09-03 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:54:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:24:39 --> Total execution time: 0.0958
DEBUG - 2022-09-03 10:54:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:54:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:24:42 --> Total execution time: 0.2607
DEBUG - 2022-09-03 10:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:55:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:25:32 --> Total execution time: 0.0964
DEBUG - 2022-09-03 10:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:14 --> Total execution time: 0.0943
DEBUG - 2022-09-03 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:22 --> Total execution time: 0.0920
DEBUG - 2022-09-03 10:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:24 --> Total execution time: 0.2809
DEBUG - 2022-09-03 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:37 --> Total execution time: 0.0630
DEBUG - 2022-09-03 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:40 --> Total execution time: 0.2533
DEBUG - 2022-09-03 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:41 --> Total execution time: 0.0960
DEBUG - 2022-09-03 10:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:44 --> Total execution time: 0.0990
DEBUG - 2022-09-03 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:56 --> Total execution time: 0.0984
DEBUG - 2022-09-03 10:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:57 --> Total execution time: 0.1009
DEBUG - 2022-09-03 10:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:05 --> Total execution time: 0.1057
DEBUG - 2022-09-03 10:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:06 --> Total execution time: 0.1134
DEBUG - 2022-09-03 10:57:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:16 --> Total execution time: 0.0987
DEBUG - 2022-09-03 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:18 --> Total execution time: 0.2669
DEBUG - 2022-09-03 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:20 --> Total execution time: 0.1156
DEBUG - 2022-09-03 10:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:38 --> Total execution time: 0.0939
DEBUG - 2022-09-03 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:46 --> Total execution time: 0.0954
DEBUG - 2022-09-03 10:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:57:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:52 --> Total execution time: 0.0923
DEBUG - 2022-09-03 10:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:05 --> Total execution time: 0.0965
DEBUG - 2022-09-03 10:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:31 --> Total execution time: 0.0668
DEBUG - 2022-09-03 10:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:32 --> Total execution time: 0.0651
DEBUG - 2022-09-03 10:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:43 --> Total execution time: 0.0611
DEBUG - 2022-09-03 10:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:56 --> Total execution time: 0.0938
DEBUG - 2022-09-03 10:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:58:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:59 --> Total execution time: 0.0922
DEBUG - 2022-09-03 10:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:00 --> Total execution time: 0.1110
DEBUG - 2022-09-03 10:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 10:59:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:10 --> Total execution time: 0.0970
DEBUG - 2022-09-03 10:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:24 --> Total execution time: 0.1154
DEBUG - 2022-09-03 10:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:30 --> Total execution time: 0.1018
DEBUG - 2022-09-03 10:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:34 --> Total execution time: 0.1075
DEBUG - 2022-09-03 10:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 10:59:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 10:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 10:59:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:54 --> Total execution time: 0.0640
DEBUG - 2022-09-03 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:02 --> Total execution time: 0.0690
DEBUG - 2022-09-03 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:08 --> Total execution time: 0.1121
DEBUG - 2022-09-03 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:16 --> Total execution time: 0.1241
DEBUG - 2022-09-03 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:23 --> Total execution time: 0.1165
DEBUG - 2022-09-03 11:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:37 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:37 --> Total execution time: 0.1285
DEBUG - 2022-09-03 11:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:45 --> Total execution time: 0.0602
DEBUG - 2022-09-03 11:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:48 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 11:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:00:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:49 --> Total execution time: 0.1194
DEBUG - 2022-09-03 11:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:12 --> Total execution time: 0.0593
DEBUG - 2022-09-03 11:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:15 --> Total execution time: 0.1276
DEBUG - 2022-09-03 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:23 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:23 --> Total execution time: 0.0707
DEBUG - 2022-09-03 11:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:37 --> Total execution time: 0.1096
DEBUG - 2022-09-03 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:38 --> Upload class already loaded. Second attempt ignored.
DEBUG - 2022-09-03 11:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:38 --> Total execution time: 0.1201
DEBUG - 2022-09-03 11:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:39 --> Total execution time: 0.1593
DEBUG - 2022-09-03 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:41 --> Total execution time: 0.0896
DEBUG - 2022-09-03 11:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:52 --> Total execution time: 0.0583
DEBUG - 2022-09-03 11:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:01:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:59 --> Total execution time: 0.0932
DEBUG - 2022-09-03 11:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:15 --> Total execution time: 0.2521
DEBUG - 2022-09-03 11:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:25 --> Total execution time: 0.1175
DEBUG - 2022-09-03 11:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:28 --> Total execution time: 0.1250
DEBUG - 2022-09-03 11:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:30 --> Total execution time: 0.0897
DEBUG - 2022-09-03 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:35 --> Total execution time: 0.1208
DEBUG - 2022-09-03 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:40 --> Total execution time: 0.1495
DEBUG - 2022-09-03 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:02:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:54 --> Total execution time: 0.1003
DEBUG - 2022-09-03 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:05 --> Total execution time: 0.0981
DEBUG - 2022-09-03 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:22 --> Total execution time: 0.1254
DEBUG - 2022-09-03 11:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:29 --> Total execution time: 0.1031
DEBUG - 2022-09-03 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:31 --> Total execution time: 0.1266
DEBUG - 2022-09-03 11:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:36 --> Total execution time: 0.1103
DEBUG - 2022-09-03 11:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:03:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:46 --> Total execution time: 0.1193
DEBUG - 2022-09-03 11:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:50 --> Total execution time: 0.1129
DEBUG - 2022-09-03 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:42 --> Total execution time: 0.1117
DEBUG - 2022-09-03 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:45 --> Total execution time: 0.0993
DEBUG - 2022-09-03 11:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:56 --> Total execution time: 0.0938
DEBUG - 2022-09-03 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:58 --> Total execution time: 0.1144
DEBUG - 2022-09-03 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:04:59 --> Total execution time: 0.1137
DEBUG - 2022-09-03 11:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:35:00 --> Total execution time: 0.0871
DEBUG - 2022-09-03 11:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:05:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:35:04 --> Total execution time: 0.1048
DEBUG - 2022-09-03 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:35:39 --> Total execution time: 0.1034
DEBUG - 2022-09-03 11:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:05:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:35:51 --> Total execution time: 0.0987
DEBUG - 2022-09-03 11:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:00 --> Total execution time: 0.1368
DEBUG - 2022-09-03 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:08 --> Total execution time: 0.1264
DEBUG - 2022-09-03 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:25 --> Total execution time: 0.1502
DEBUG - 2022-09-03 11:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:37 --> Total execution time: 0.1007
DEBUG - 2022-09-03 11:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:37:17 --> Total execution time: 0.2792
DEBUG - 2022-09-03 11:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:08:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:08:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:18 --> Total execution time: 0.0978
DEBUG - 2022-09-03 11:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:57 --> Total execution time: 0.0992
DEBUG - 2022-09-03 11:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:58 --> Total execution time: 0.0943
DEBUG - 2022-09-03 11:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:09:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:39:20 --> Total execution time: 0.1041
DEBUG - 2022-09-03 11:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:39:39 --> Total execution time: 0.0985
DEBUG - 2022-09-03 11:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:15 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:40:15 --> Total execution time: 0.0670
DEBUG - 2022-09-03 11:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:40:19 --> Total execution time: 0.0987
DEBUG - 2022-09-03 11:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:40:33 --> Total execution time: 0.1065
DEBUG - 2022-09-03 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:40:47 --> Total execution time: 0.1033
DEBUG - 2022-09-03 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:40:58 --> Total execution time: 0.1097
DEBUG - 2022-09-03 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:15 --> Total execution time: 0.2766
DEBUG - 2022-09-03 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:16 --> Total execution time: 0.0988
DEBUG - 2022-09-03 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:19 --> Total execution time: 0.1032
DEBUG - 2022-09-03 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:22 --> Total execution time: 0.1111
DEBUG - 2022-09-03 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:24 --> Total execution time: 0.3387
DEBUG - 2022-09-03 11:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:31 --> Total execution time: 0.1037
DEBUG - 2022-09-03 11:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:41:49 --> Total execution time: 0.1149
DEBUG - 2022-09-03 11:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:12:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:42:01 --> Total execution time: 0.1634
DEBUG - 2022-09-03 11:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:12:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 11:12:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:13:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:43:23 --> Total execution time: 0.1012
DEBUG - 2022-09-03 11:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:14:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:14:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:44:50 --> Total execution time: 0.0686
DEBUG - 2022-09-03 11:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:46:15 --> Total execution time: 0.0988
DEBUG - 2022-09-03 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:16:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:46:27 --> Total execution time: 0.0950
DEBUG - 2022-09-03 11:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:16:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:46:38 --> Total execution time: 0.1242
DEBUG - 2022-09-03 11:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:16:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:46:53 --> Total execution time: 0.0950
DEBUG - 2022-09-03 11:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:39 --> Total execution time: 0.1720
DEBUG - 2022-09-03 11:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:24:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:17 --> Total execution time: 0.1269
DEBUG - 2022-09-03 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:27 --> Total execution time: 0.1114
DEBUG - 2022-09-03 11:24:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:27 --> Total execution time: 0.2287
DEBUG - 2022-09-03 11:24:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:24:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:24:31 --> Total execution time: 0.0956
DEBUG - 2022-09-03 11:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:24:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 11:24:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 11:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:55:22 --> Total execution time: 0.0962
DEBUG - 2022-09-03 11:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:23 --> Total execution time: 0.2577
DEBUG - 2022-09-03 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:27:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:31 --> Total execution time: 0.1118
DEBUG - 2022-09-03 11:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:27:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:34 --> Total execution time: 0.2523
DEBUG - 2022-09-03 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:27:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:27:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:40 --> Total execution time: 0.0911
DEBUG - 2022-09-03 11:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:27:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:43 --> Total execution time: 0.0964
DEBUG - 2022-09-03 11:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:04 --> Total execution time: 0.2798
DEBUG - 2022-09-03 11:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:11 --> Total execution time: 0.1071
DEBUG - 2022-09-03 11:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:17 --> Total execution time: 0.1102
DEBUG - 2022-09-03 11:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:28:31 --> Total execution time: 0.0969
DEBUG - 2022-09-03 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:43 --> Total execution time: 0.1119
DEBUG - 2022-09-03 11:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:09 --> Total execution time: 0.1013
DEBUG - 2022-09-03 11:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:29:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:17 --> Total execution time: 0.0992
DEBUG - 2022-09-03 11:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:29:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:29:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:42 --> Total execution time: 0.0700
DEBUG - 2022-09-03 11:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:29:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:29:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:44 --> Total execution time: 0.0640
DEBUG - 2022-09-03 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:29:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:54 --> Total execution time: 0.0619
DEBUG - 2022-09-03 11:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:02 --> Total execution time: 0.1343
DEBUG - 2022-09-03 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:10 --> Total execution time: 0.1015
DEBUG - 2022-09-03 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:17 --> Total execution time: 0.1245
DEBUG - 2022-09-03 11:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:18 --> Total execution time: 0.1459
DEBUG - 2022-09-03 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:22 --> Total execution time: 0.1011
DEBUG - 2022-09-03 11:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:22 --> Total execution time: 0.1014
DEBUG - 2022-09-03 11:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:45 --> Total execution time: 0.1029
DEBUG - 2022-09-03 11:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:30:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:54 --> Total execution time: 0.1403
DEBUG - 2022-09-03 11:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:01:02 --> Total execution time: 0.1046
DEBUG - 2022-09-03 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:31:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:01:34 --> Total execution time: 0.1666
DEBUG - 2022-09-03 11:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:31:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:01:40 --> Total execution time: 0.1010
DEBUG - 2022-09-03 11:31:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:01:51 --> Total execution time: 0.0594
DEBUG - 2022-09-03 11:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:31:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:01:53 --> Total execution time: 0.0649
DEBUG - 2022-09-03 11:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:32:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:02:40 --> Total execution time: 0.0979
DEBUG - 2022-09-03 11:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:32:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:02:47 --> Total execution time: 0.1013
DEBUG - 2022-09-03 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:02:58 --> Total execution time: 0.1046
DEBUG - 2022-09-03 11:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:33:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:03:44 --> Total execution time: 0.0940
DEBUG - 2022-09-03 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:03:49 --> Total execution time: 0.0928
DEBUG - 2022-09-03 11:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:07 --> Total execution time: 0.2608
DEBUG - 2022-09-03 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:11 --> Total execution time: 0.1049
DEBUG - 2022-09-03 11:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:35:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:16 --> Total execution time: 0.1576
DEBUG - 2022-09-03 11:36:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:06 --> Total execution time: 0.1233
DEBUG - 2022-09-03 11:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:15 --> Total execution time: 0.0987
DEBUG - 2022-09-03 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:26 --> Total execution time: 0.1056
DEBUG - 2022-09-03 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:39 --> Total execution time: 0.1050
DEBUG - 2022-09-03 11:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:42 --> Total execution time: 0.1024
DEBUG - 2022-09-03 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:43 --> Total execution time: 0.1001
DEBUG - 2022-09-03 11:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:36:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:44 --> Total execution time: 0.0990
DEBUG - 2022-09-03 11:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:37:50 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:37:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:50 --> Total execution time: 0.0659
DEBUG - 2022-09-03 11:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:37:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:56 --> Total execution time: 0.0799
DEBUG - 2022-09-03 11:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:24 --> Total execution time: 0.0994
DEBUG - 2022-09-03 11:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:38:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:36 --> Total execution time: 0.1285
DEBUG - 2022-09-03 11:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:39:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:05 --> Total execution time: 0.1087
DEBUG - 2022-09-03 11:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:10 --> Total execution time: 0.1047
DEBUG - 2022-09-03 11:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:25 --> Total execution time: 0.0939
DEBUG - 2022-09-03 11:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:42 --> Total execution time: 0.2845
DEBUG - 2022-09-03 11:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:40:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:40:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:44 --> Total execution time: 0.1007
DEBUG - 2022-09-03 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:40:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:40:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:48 --> Total execution time: 0.1112
DEBUG - 2022-09-03 11:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:40:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:00 --> Total execution time: 0.0884
DEBUG - 2022-09-03 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:07 --> Total execution time: 0.1006
DEBUG - 2022-09-03 11:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:17 --> Total execution time: 0.0941
DEBUG - 2022-09-03 11:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:41:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:49 --> Total execution time: 0.0878
DEBUG - 2022-09-03 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:09 --> Total execution time: 0.0893
DEBUG - 2022-09-03 11:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:11 --> Total execution time: 0.0983
DEBUG - 2022-09-03 11:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:30 --> Total execution time: 0.0600
DEBUG - 2022-09-03 11:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:34 --> Total execution time: 0.0983
DEBUG - 2022-09-03 11:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:44 --> Total execution time: 0.1338
DEBUG - 2022-09-03 11:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:49 --> Total execution time: 0.0999
DEBUG - 2022-09-03 11:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:12:54 --> Total execution time: 0.1034
DEBUG - 2022-09-03 11:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:43:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:13:02 --> Total execution time: 0.0957
DEBUG - 2022-09-03 11:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:43:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:13:18 --> Total execution time: 0.1290
DEBUG - 2022-09-03 11:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:44:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:14:26 --> Total execution time: 0.0963
DEBUG - 2022-09-03 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:45:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:15:14 --> Total execution time: 0.0769
DEBUG - 2022-09-03 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:46:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:46:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:16:25 --> Total execution time: 0.2586
DEBUG - 2022-09-03 11:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:16:36 --> Total execution time: 0.0942
DEBUG - 2022-09-03 11:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:46:49 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:46:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:16:49 --> Total execution time: 0.1074
DEBUG - 2022-09-03 11:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:16:59 --> Total execution time: 0.0616
DEBUG - 2022-09-03 11:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:01 --> Total execution time: 0.0593
DEBUG - 2022-09-03 11:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:01 --> Total execution time: 0.0676
DEBUG - 2022-09-03 11:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:40 --> Total execution time: 0.0988
DEBUG - 2022-09-03 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:43 --> Total execution time: 0.0586
DEBUG - 2022-09-03 11:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:49 --> Total execution time: 0.1335
DEBUG - 2022-09-03 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:17:51 --> Total execution time: 0.0589
DEBUG - 2022-09-03 11:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:18:16 --> Total execution time: 0.2534
DEBUG - 2022-09-03 11:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:49:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:19:31 --> Total execution time: 0.0600
DEBUG - 2022-09-03 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:50:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:20:10 --> Total execution time: 0.0994
DEBUG - 2022-09-03 11:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:50:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:20:14 --> Total execution time: 0.1092
DEBUG - 2022-09-03 11:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:20:19 --> Total execution time: 0.1010
DEBUG - 2022-09-03 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:20:27 --> Total execution time: 0.0943
DEBUG - 2022-09-03 11:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:51:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:21:16 --> Total execution time: 0.0955
DEBUG - 2022-09-03 11:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:51:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:21:32 --> Total execution time: 0.0968
DEBUG - 2022-09-03 11:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:51:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:21:56 --> Total execution time: 0.1424
DEBUG - 2022-09-03 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:22:02 --> Total execution time: 0.2881
DEBUG - 2022-09-03 11:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:22:12 --> Total execution time: 0.0644
DEBUG - 2022-09-03 11:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:22:28 --> Total execution time: 0.0638
DEBUG - 2022-09-03 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:22:44 --> Total execution time: 0.0613
DEBUG - 2022-09-03 11:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:52:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:22:52 --> Total execution time: 0.1160
DEBUG - 2022-09-03 11:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:23:03 --> Total execution time: 0.1005
DEBUG - 2022-09-03 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:23:17 --> Total execution time: 0.1001
DEBUG - 2022-09-03 11:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:23:29 --> Total execution time: 0.1004
DEBUG - 2022-09-03 11:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:49 --> Total execution time: 0.1269
DEBUG - 2022-09-03 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:51 --> Total execution time: 0.1008
DEBUG - 2022-09-03 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:52 --> Total execution time: 0.0958
DEBUG - 2022-09-03 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:23:56 --> Total execution time: 0.0979
DEBUG - 2022-09-03 11:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:53:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:23:56 --> Total execution time: 0.1256
DEBUG - 2022-09-03 11:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:24:01 --> Total execution time: 0.1006
DEBUG - 2022-09-03 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:54:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:24:07 --> Total execution time: 0.1014
DEBUG - 2022-09-03 11:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:54:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:24:13 --> Total execution time: 0.0921
DEBUG - 2022-09-03 11:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:54:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:24:20 --> Total execution time: 0.1044
DEBUG - 2022-09-03 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:07 --> Total execution time: 0.0995
DEBUG - 2022-09-03 11:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:08 --> Total execution time: 0.1135
DEBUG - 2022-09-03 11:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:12 --> Total execution time: 0.1018
DEBUG - 2022-09-03 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:15 --> Total execution time: 0.0946
DEBUG - 2022-09-03 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:16 --> Total execution time: 0.0960
DEBUG - 2022-09-03 11:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:16 --> Total execution time: 0.0877
DEBUG - 2022-09-03 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:17 --> Total execution time: 0.0932
DEBUG - 2022-09-03 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:18 --> Total execution time: 0.0946
DEBUG - 2022-09-03 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:20 --> Total execution time: 0.0964
DEBUG - 2022-09-03 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:20 --> Total execution time: 0.1027
DEBUG - 2022-09-03 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:25:23 --> Total execution time: 0.0951
DEBUG - 2022-09-03 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:57:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:27:08 --> Total execution time: 0.2805
DEBUG - 2022-09-03 11:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:57:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 11:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 11:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 11:57:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:27:11 --> Total execution time: 0.0568
DEBUG - 2022-09-03 12:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:30:02 --> Total execution time: 0.1475
DEBUG - 2022-09-03 12:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:00:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:30:36 --> Total execution time: 0.0905
DEBUG - 2022-09-03 12:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:30:42 --> Total execution time: 0.1003
DEBUG - 2022-09-03 12:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:01:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:31:28 --> Total execution time: 0.3163
DEBUG - 2022-09-03 12:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:31:39 --> Total execution time: 0.0984
DEBUG - 2022-09-03 12:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:31:45 --> Total execution time: 0.0968
DEBUG - 2022-09-03 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:05 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:05 --> Total execution time: 0.3258
DEBUG - 2022-09-03 12:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:05 --> Total execution time: 0.2576
DEBUG - 2022-09-03 12:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:10 --> Total execution time: 0.1040
DEBUG - 2022-09-03 12:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:22 --> Total execution time: 0.1125
DEBUG - 2022-09-03 22:35:23 --> Total execution time: 2.4017
DEBUG - 2022-09-03 12:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 12:05:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 12:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:35 --> Total execution time: 0.0618
DEBUG - 2022-09-03 12:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:42 --> Total execution time: 0.0994
DEBUG - 2022-09-03 12:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:35:50 --> Total execution time: 0.1064
DEBUG - 2022-09-03 12:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:08 --> Total execution time: 0.0994
DEBUG - 2022-09-03 12:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:11 --> Total execution time: 0.1167
DEBUG - 2022-09-03 12:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:20 --> Total execution time: 0.0942
DEBUG - 2022-09-03 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:21 --> Total execution time: 0.0924
DEBUG - 2022-09-03 12:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:26 --> Total execution time: 0.1224
DEBUG - 2022-09-03 12:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:31 --> Total execution time: 0.1204
DEBUG - 2022-09-03 12:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:41 --> Total execution time: 0.1113
DEBUG - 2022-09-03 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:42 --> Total execution time: 0.0964
DEBUG - 2022-09-03 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:42 --> Total execution time: 0.1136
DEBUG - 2022-09-03 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:42 --> Total execution time: 0.1089
DEBUG - 2022-09-03 12:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:43 --> Total execution time: 0.1753
DEBUG - 2022-09-03 12:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:43 --> Total execution time: 0.1984
DEBUG - 2022-09-03 12:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:46 --> Total execution time: 0.1198
DEBUG - 2022-09-03 12:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:59 --> Total execution time: 0.1021
DEBUG - 2022-09-03 12:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:02 --> Total execution time: 0.0926
DEBUG - 2022-09-03 12:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:09 --> Total execution time: 0.0996
DEBUG - 2022-09-03 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:17 --> Total execution time: 0.0942
DEBUG - 2022-09-03 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:18 --> Total execution time: 0.0982
DEBUG - 2022-09-03 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:19 --> Total execution time: 0.0910
DEBUG - 2022-09-03 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:19 --> Total execution time: 0.0632
DEBUG - 2022-09-03 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:22 --> Total execution time: 0.0884
DEBUG - 2022-09-03 12:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:28 --> Total execution time: 0.0958
DEBUG - 2022-09-03 12:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:34 --> Total execution time: 0.0967
DEBUG - 2022-09-03 12:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:36 --> Total execution time: 0.1586
DEBUG - 2022-09-03 12:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:53 --> Total execution time: 0.1103
DEBUG - 2022-09-03 12:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:07:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:37:56 --> Total execution time: 0.0938
DEBUG - 2022-09-03 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:14 --> Total execution time: 0.0990
DEBUG - 2022-09-03 12:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:26 --> Total execution time: 0.1011
DEBUG - 2022-09-03 12:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:35 --> Total execution time: 0.1281
DEBUG - 2022-09-03 12:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:39 --> Total execution time: 0.0927
DEBUG - 2022-09-03 12:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:42 --> Total execution time: 0.0979
DEBUG - 2022-09-03 12:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:10:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:40:57 --> Total execution time: 0.1236
DEBUG - 2022-09-03 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:11:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:41:07 --> Total execution time: 0.1543
DEBUG - 2022-09-03 12:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:11:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:11:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:41:49 --> Total execution time: 0.0945
DEBUG - 2022-09-03 12:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:11:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:41:59 --> Total execution time: 0.2774
DEBUG - 2022-09-03 12:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:02 --> Total execution time: 0.0616
DEBUG - 2022-09-03 12:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:08 --> Total execution time: 0.0963
DEBUG - 2022-09-03 12:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:23 --> Total execution time: 0.1355
DEBUG - 2022-09-03 12:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:24 --> Total execution time: 0.1050
DEBUG - 2022-09-03 12:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:27 --> Total execution time: 0.1009
DEBUG - 2022-09-03 12:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:31 --> Total execution time: 0.1004
DEBUG - 2022-09-03 12:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:34 --> Total execution time: 0.1273
DEBUG - 2022-09-03 12:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:43 --> Total execution time: 0.1000
DEBUG - 2022-09-03 12:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:47 --> Total execution time: 0.1296
DEBUG - 2022-09-03 12:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:50 --> Total execution time: 0.1038
DEBUG - 2022-09-03 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:12:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:42:53 --> Total execution time: 0.1239
DEBUG - 2022-09-03 12:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:43:35 --> Total execution time: 0.1133
DEBUG - 2022-09-03 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:43:43 --> Total execution time: 0.0974
DEBUG - 2022-09-03 12:13:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:43:51 --> Total execution time: 0.1044
DEBUG - 2022-09-03 12:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:43:52 --> Total execution time: 0.1136
DEBUG - 2022-09-03 12:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:13:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:43:58 --> Total execution time: 0.1089
DEBUG - 2022-09-03 12:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:45:47 --> Total execution time: 0.0996
DEBUG - 2022-09-03 12:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:25 --> Total execution time: 0.1269
DEBUG - 2022-09-03 12:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:25 --> Total execution time: 0.0622
DEBUG - 2022-09-03 12:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:36 --> Total execution time: 0.0964
DEBUG - 2022-09-03 12:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:50 --> Total execution time: 0.0979
DEBUG - 2022-09-03 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:20:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:57 --> Total execution time: 0.0915
DEBUG - 2022-09-03 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:13 --> Total execution time: 0.1293
DEBUG - 2022-09-03 12:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:14 --> Total execution time: 0.1092
DEBUG - 2022-09-03 12:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:22 --> Total execution time: 0.2887
DEBUG - 2022-09-03 12:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:30 --> Total execution time: 0.0920
DEBUG - 2022-09-03 12:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:32 --> Total execution time: 0.0974
DEBUG - 2022-09-03 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:21:32 --> Total execution time: 0.0874
DEBUG - 2022-09-03 12:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:32 --> Total execution time: 0.0871
DEBUG - 2022-09-03 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:33 --> Total execution time: 0.0906
DEBUG - 2022-09-03 12:21:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:33 --> Total execution time: 0.0899
DEBUG - 2022-09-03 12:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:42 --> Total execution time: 0.0889
DEBUG - 2022-09-03 12:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:43 --> Total execution time: 0.0926
DEBUG - 2022-09-03 12:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:43 --> Total execution time: 0.0991
DEBUG - 2022-09-03 12:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:21:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:51:59 --> Total execution time: 0.0978
DEBUG - 2022-09-03 12:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:22:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:22:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:00 --> Total execution time: 0.0953
DEBUG - 2022-09-03 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:23:06 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:23:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:53:06 --> Total execution time: 0.0640
DEBUG - 2022-09-03 12:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:25:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:55:05 --> Total execution time: 0.0642
DEBUG - 2022-09-03 12:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:26:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:26:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:56:41 --> Total execution time: 0.1001
DEBUG - 2022-09-03 12:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:56:45 --> Total execution time: 0.1329
DEBUG - 2022-09-03 12:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:56:58 --> Total execution time: 0.2556
DEBUG - 2022-09-03 12:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:56:59 --> Total execution time: 0.1004
DEBUG - 2022-09-03 12:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:57:10 --> Total execution time: 0.1111
DEBUG - 2022-09-03 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:57:15 --> Total execution time: 0.1493
DEBUG - 2022-09-03 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:57:27 --> Total execution time: 0.1001
DEBUG - 2022-09-03 12:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:57:35 --> Total execution time: 0.1012
DEBUG - 2022-09-03 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:57:51 --> Total execution time: 0.1010
DEBUG - 2022-09-03 12:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:34:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:04:04 --> Total execution time: 0.1669
DEBUG - 2022-09-03 12:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:40:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:54 --> Total execution time: 0.1673
DEBUG - 2022-09-03 12:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:42:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:08 --> Total execution time: 0.0962
DEBUG - 2022-09-03 12:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:45:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:15:37 --> Total execution time: 0.1321
DEBUG - 2022-09-03 12:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:15:45 --> Total execution time: 0.2892
DEBUG - 2022-09-03 12:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:48:08 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:48:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:09 --> Total execution time: 0.1132
DEBUG - 2022-09-03 12:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:48:24 --> Total execution time: 0.0971
DEBUG - 2022-09-03 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:48:26 --> Total execution time: 0.0907
DEBUG - 2022-09-03 12:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:48:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:48:26 --> Total execution time: 0.1040
DEBUG - 2022-09-03 12:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:48:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:51 --> Total execution time: 0.0951
DEBUG - 2022-09-03 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:25 --> Total execution time: 0.0658
DEBUG - 2022-09-03 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 12:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:10 --> Total execution time: 0.0640
DEBUG - 2022-09-03 12:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:10 --> Total execution time: 0.0908
DEBUG - 2022-09-03 12:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:22 --> Total execution time: 0.0957
DEBUG - 2022-09-03 12:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 12:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:51:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:54 --> Total execution time: 0.0932
DEBUG - 2022-09-03 12:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 12:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 12:58:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:50 --> Total execution time: 0.1616
DEBUG - 2022-09-03 13:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:02 --> Total execution time: 0.1742
DEBUG - 2022-09-03 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:02:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:32:41 --> Total execution time: 0.0736
DEBUG - 2022-09-03 13:02:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:32:41 --> Total execution time: 0.0725
DEBUG - 2022-09-03 13:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:06:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:36:32 --> Total execution time: 0.1465
DEBUG - 2022-09-03 13:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:14:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:44:04 --> Total execution time: 0.1400
DEBUG - 2022-09-03 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:14:26 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:14:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:44:26 --> Total execution time: 0.0686
DEBUG - 2022-09-03 13:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:14:49 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:14:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:44:49 --> Total execution time: 0.0663
DEBUG - 2022-09-03 13:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:17:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:17:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:00 --> Total execution time: 0.3128
DEBUG - 2022-09-03 13:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:17:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:25 --> Total execution time: 0.0997
DEBUG - 2022-09-03 13:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:18:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:48:02 --> Total execution time: 0.0961
DEBUG - 2022-09-03 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:24:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:53 --> Total execution time: 0.0966
DEBUG - 2022-09-03 13:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:27:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:57:01 --> Total execution time: 0.3182
DEBUG - 2022-09-03 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:57:22 --> Total execution time: 0.1225
DEBUG - 2022-09-03 13:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:33:16 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:33:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:33:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:33:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:35:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:35:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:35:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:36:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:43:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 13:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:45:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:45:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:45:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:51:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:57:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 13:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 13:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:03:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:03:26 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:03:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:03:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:03:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:04:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:05:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:05:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:07:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 14:07:26 --> 404 Page Not Found: Event/service-tuesday-cradles-to-crayons-school-kits
DEBUG - 2022-09-03 14:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:15:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 14:15:24 --> 404 Page Not Found: Comments/feed
DEBUG - 2022-09-03 14:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:27:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:28:10 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:29:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 14:29:28 --> 404 Page Not Found: Comments/feed
DEBUG - 2022-09-03 14:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:30:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:30:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:37:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:37:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:39:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:39:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:39:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:40:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:40:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:41:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:41:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:41:16 --> Total execution time: 0.0905
DEBUG - 2022-09-03 14:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:41:18 --> Total execution time: 0.1154
DEBUG - 2022-09-03 14:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:41:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:41:18 --> Total execution time: 0.0906
DEBUG - 2022-09-03 14:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:41:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 14:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 14:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 14:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 14:53:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 14:53:37 --> 404 Page Not Found: Reselling-course/index
DEBUG - 2022-09-03 15:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:06:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:06:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:17:27 --> No URI present. Default controller set.
DEBUG - 2022-09-03 15:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:17:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:24:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:27:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:29:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:29:03 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-09-03 15:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:34:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 15:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:10 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-03 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:10 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-09-03 15:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/apple-app-site-association
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/gpc.json
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/security.txt
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/change-password
DEBUG - 2022-09-03 15:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:35:31 --> 404 Page Not Found: Well-known/resource-that-should-not-exist-whose-status-code-should-not-be-200
DEBUG - 2022-09-03 15:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:36:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 15:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:37:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 15:37:26 --> 404 Page Not Found: Author/admin
DEBUG - 2022-09-03 15:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 15:43:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 15:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 15:43:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 16:00:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:00:03 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-09-03 16:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:02:35 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-03 16:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:02:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:02:35 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 16:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:02:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:02:36 --> 404 Page Not Found: Adstxt/index
DEBUG - 2022-09-03 16:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:13:16 --> No URI present. Default controller set.
DEBUG - 2022-09-03 16:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 16:13:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:16:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 16:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 16:16:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 16:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:26:37 --> 404 Page Not Found: Well-known/assetlinks.json
DEBUG - 2022-09-03 16:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 16:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 16:59:04 --> 404 Page Not Found: Wp-includes/js
DEBUG - 2022-09-03 17:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:32:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 17:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:32:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:43:20 --> Total execution time: 0.3788
DEBUG - 2022-09-03 17:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:43:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:44:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:44:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 17:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 17:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 17:45:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:00:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 18:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:00:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:00:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 18:00:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 18:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 18:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 18:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:01:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:02:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:02:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:02:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:02:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:03:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:11:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:29:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 18:42:15 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-03 18:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:52:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 18:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 18:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 18:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 18:55:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 18:55:51 --> 404 Page Not Found: Feed/index
DEBUG - 2022-09-03 19:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:00:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:00:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:09:57 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:09:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:10:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:23:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:23:13 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:23:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:23:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 19:23:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 19:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:23:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:23:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:23:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:27:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 19:29:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 19:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 19:39:47 --> 404 Page Not Found: Courses/index
DEBUG - 2022-09-03 19:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:43:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 19:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 19:59:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 19:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 19:59:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:00:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:00:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 20:08:54 --> 404 Page Not Found: Wp-admin/css
DEBUG - 2022-09-03 20:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:12:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:12:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:13:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:13:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:13:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:14:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:41 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:15:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:16:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:16:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:16:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:16:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:16:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:20:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:20:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:20:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:20:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:32:52 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:32:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:32:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:34:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:35:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:36:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:40:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:40:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:40:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:40:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:40:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:29 --> Total execution time: 0.0991
DEBUG - 2022-09-03 20:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:42:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:42:59 --> Total execution time: 0.1053
DEBUG - 2022-09-03 20:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:07 --> Total execution time: 0.0948
DEBUG - 2022-09-03 20:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:20 --> Total execution time: 0.0889
DEBUG - 2022-09-03 20:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:24 --> Total execution time: 0.0869
DEBUG - 2022-09-03 20:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:29 --> Total execution time: 0.1014
DEBUG - 2022-09-03 20:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:31 --> Total execution time: 0.1366
DEBUG - 2022-09-03 20:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:33 --> Total execution time: 0.0953
DEBUG - 2022-09-03 20:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:43:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:44:20 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:44:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:52:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:53:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:53:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:54:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:54:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:55:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:55:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:56:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:28 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:57:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:59:05 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:59:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:59:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:59:40 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:59:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:59:58 --> No URI present. Default controller set.
DEBUG - 2022-09-03 20:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:59:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 20:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 20:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 20:59:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:24 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:39 --> Total execution time: 0.1105
DEBUG - 2022-09-03 21:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:42 --> Total execution time: 0.1011
DEBUG - 2022-09-03 21:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:00:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:00:43 --> Total execution time: 0.0966
DEBUG - 2022-09-03 21:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:01:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:01:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:01:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:05:18 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:05:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:32 --> Total execution time: 0.0974
DEBUG - 2022-09-03 21:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:34 --> Total execution time: 0.0983
DEBUG - 2022-09-03 21:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:35 --> Total execution time: 0.2139
DEBUG - 2022-09-03 21:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:07:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:08:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:08:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 21:09:46 --> 404 Page Not Found: Designer-bag-bingo-new-choices-fundraiser-2/index
DEBUG - 2022-09-03 21:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:10:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:11:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:13:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:15:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:20:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:21:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:21:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:21:52 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:21:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:22:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:23:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:25:22 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:25:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:26:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:27:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:27:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:28:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:28:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:29:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:29:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:29:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:30:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:30:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:30:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:30:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:30:50 --> Total execution time: 0.1199
DEBUG - 2022-09-03 21:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:31:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:02 --> Total execution time: 0.0961
DEBUG - 2022-09-03 21:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:31:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:31:35 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:31:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:32:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:06 --> Total execution time: 0.1036
DEBUG - 2022-09-03 21:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:12 --> Total execution time: 0.0947
DEBUG - 2022-09-03 21:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:32:12 --> Total execution time: 0.1561
DEBUG - 2022-09-03 21:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:05 --> Total execution time: 0.0939
DEBUG - 2022-09-03 21:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:33:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:34:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:34:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 21:34:16 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 21:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:39 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:34:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:34:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:36:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:37:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:38:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:38:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:42:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:42:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:49:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:50:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:50:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:51:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:51:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:54:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 21:55:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-09-03 21:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:55:07 --> No URI present. Default controller set.
DEBUG - 2022-09-03 21:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:55:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:57:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:57:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:57:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:58:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 21:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 21:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 21:59:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:05:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:06:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:07:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:07:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:07:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:07:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:33 --> Total execution time: 0.1007
DEBUG - 2022-09-03 22:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:08:56 --> Total execution time: 0.0928
DEBUG - 2022-09-03 22:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:03 --> Total execution time: 0.0932
DEBUG - 2022-09-03 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:30 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:10:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:11:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:11:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:11:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:15:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 22:15:00 --> 404 Page Not Found: Memberships/index
DEBUG - 2022-09-03 22:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:16:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:16:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:18:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:29:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:29:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:29:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:29:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:30:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:30:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:32:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 22:32:06 --> 404 Page Not Found: Refund/index
DEBUG - 2022-09-03 22:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:32:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:32:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:33:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:33:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:39:47 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:47:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:47:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:48:36 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:48:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:48:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:50:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:50:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:50:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:52:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 22:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:53:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 22:53:08 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-03 22:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 22:53:56 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-03 22:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 22:54:15 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-03 22:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 22:58:46 --> No URI present. Default controller set.
DEBUG - 2022-09-03 22:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 22:58:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:00:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:01:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:02:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:03:31 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:03:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:03:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:03:53 --> Total execution time: 0.1129
DEBUG - 2022-09-03 23:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:03:55 --> Total execution time: 0.1440
DEBUG - 2022-09-03 23:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:03:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:03:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:03:55 --> Total execution time: 0.1013
DEBUG - 2022-09-03 23:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:04:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:04:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:04:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:04:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 23:04:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 23:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:05:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:05:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:05:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:05:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:06:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:07:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:08:49 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:08:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:09:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:10:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:11:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:11:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:11:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:11:52 --> Total execution time: 0.0899
DEBUG - 2022-09-03 23:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:12:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:03 --> Total execution time: 0.1010
DEBUG - 2022-09-03 23:12:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:03 --> Total execution time: 0.2266
DEBUG - 2022-09-03 23:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:12:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:12:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 23:12:39 --> 404 Page Not Found: Wp-content/uploads
DEBUG - 2022-09-03 23:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:13:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:13:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:13:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:14:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:15:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:16:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:16:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:17:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:18:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:18:05 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:18:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:18:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:19:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:20:55 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:20:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:20:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:20:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:21:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:21:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:21:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:45 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:38 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:54 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:24:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:25:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:07 --> Total execution time: 0.0893
DEBUG - 2022-09-03 23:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:25 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:26:47 --> Total execution time: 0.0962
DEBUG - 2022-09-03 23:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:26:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:16 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:27:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:27:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:34 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:28:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:01 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:29:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:30:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:30:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:30:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:31:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:31:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:32:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:37:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:37:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:37:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:38:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:38:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:39:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:39:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:39:43 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:39:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:39:51 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:39:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:40:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:40:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 23:40:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 23:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:19 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:41:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:32 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:33 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 23:42:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-09-03 23:42:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:42:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:42 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:43 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:44:56 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:44:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:46:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:46:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:00 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:14 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:47:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:48:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:48:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:48:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:48:59 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:48:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-03 23:49:13 --> 404 Page Not Found: Course/starter-leads-and-sales
DEBUG - 2022-09-03 23:49:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:17 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:44 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:49:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:12 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:29 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:50:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:53:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:53:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:53:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:04 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:09 --> Total execution time: 0.0968
DEBUG - 2022-09-03 23:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:10 --> Total execution time: 0.0980
DEBUG - 2022-09-03 23:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:11 --> Total execution time: 0.1163
DEBUG - 2022-09-03 23:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:54:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:26 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:55:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:56:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:57:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:30 --> Total execution time: 0.0945
DEBUG - 2022-09-03 23:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:32 --> Total execution time: 0.1013
DEBUG - 2022-09-03 23:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:32 --> Total execution time: 0.0986
DEBUG - 2022-09-03 23:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:48 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:55 --> Total execution time: 0.0928
DEBUG - 2022-09-03 23:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:57 --> Total execution time: 0.1029
DEBUG - 2022-09-03 23:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:58:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:58:58 --> Total execution time: 0.0997
DEBUG - 2022-09-03 23:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:59:11 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:59:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-09-03 23:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-09-03 23:59:21 --> No URI present. Default controller set.
DEBUG - 2022-09-03 23:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-03 23:59:21 --> Encryption: Auto-configured driver 'openssl'.
