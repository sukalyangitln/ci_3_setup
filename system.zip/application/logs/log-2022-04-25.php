<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-25 00:29:01 --> Query error: Table 'leadsark.rents' doesn't exist - Invalid query: SELECT SUM(`rent_amount_paid`) AS `rent_amount_paid`
FROM `rents`
WHERE YEAR(rent_date) = '2022'
ERROR - 2022-04-25 00:29:10 --> Query error: Table 'leadsark.rents' doesn't exist - Invalid query: SELECT SUM(`rent_amount_paid`) AS `rent_amount_paid`
FROM `rents`
WHERE YEAR(rent_date) = '2022'
DEBUG - 2022-04-25 00:29:26 --> Total execution time: 0.0959
DEBUG - 2022-04-25 00:29:38 --> Total execution time: 0.0917
DEBUG - 2022-04-25 00:29:39 --> Total execution time: 0.1272
DEBUG - 2022-04-25 01:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:50:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 01:50:56 --> Total execution time: 0.2027
DEBUG - 2022-04-25 01:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:51:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:21:02 --> Total execution time: 0.1025
DEBUG - 2022-04-25 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:51:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:21:03 --> Total execution time: 0.1563
DEBUG - 2022-04-25 01:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:27:48 --> Total execution time: 0.1730
DEBUG - 2022-04-25 01:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:57:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:27:48 --> Total execution time: 0.1249
DEBUG - 2022-04-25 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 01:57:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:57:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 01:57:54 --> Total execution time: 0.1302
DEBUG - 2022-04-25 01:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:58:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:28:06 --> Total execution time: 0.1029
DEBUG - 2022-04-25 01:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:58:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:28:06 --> Total execution time: 0.1415
DEBUG - 2022-04-25 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:58:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:28:09 --> Total execution time: 0.1253
DEBUG - 2022-04-25 01:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:58:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:28:27 --> Total execution time: 0.1005
DEBUG - 2022-04-25 01:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 01:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 01:58:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:28:40 --> Total execution time: 0.0942
DEBUG - 2022-04-25 02:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:01:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:31:03 --> Severity: Notice --> Undefined property: UserAuth::$User_logins C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 31
ERROR - 2022-04-25 05:31:03 --> Severity: error --> Exception: Call to a member function check() on null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 31
DEBUG - 2022-04-25 02:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:01:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:04:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:34:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 43
DEBUG - 2022-04-25 02:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:04:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:04:11 --> 404 Page Not Found: User-dashboard/index
DEBUG - 2022-04-25 02:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:04:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:04:26 --> Total execution time: 0.0881
DEBUG - 2022-04-25 02:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:05:31 --> Total execution time: 0.1018
DEBUG - 2022-04-25 02:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:05:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:05:36 --> Total execution time: 0.0973
DEBUG - 2022-04-25 02:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:02 --> Total execution time: 0.1098
DEBUG - 2022-04-25 02:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:04 --> Total execution time: 0.0879
DEBUG - 2022-04-25 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:36:30 --> Total execution time: 0.0982
DEBUG - 2022-04-25 02:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:36:31 --> Total execution time: 0.1178
DEBUG - 2022-04-25 02:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:51 --> Total execution time: 0.1437
DEBUG - 2022-04-25 02:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:36:55 --> Total execution time: 0.0845
DEBUG - 2022-04-25 02:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:06:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:36:56 --> Total execution time: 0.1412
DEBUG - 2022-04-25 02:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:07:00 --> Total execution time: 0.1177
DEBUG - 2022-04-25 02:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:01 --> Total execution time: 0.0910
DEBUG - 2022-04-25 02:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:02 --> Total execution time: 0.1371
DEBUG - 2022-04-25 02:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:21 --> Total execution time: 0.1741
DEBUG - 2022-04-25 02:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:21 --> Total execution time: 0.1174
DEBUG - 2022-04-25 02:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:25 --> Total execution time: 0.1154
DEBUG - 2022-04-25 02:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:37:25 --> Total execution time: 0.1305
DEBUG - 2022-04-25 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 02:08:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 52
DEBUG - 2022-04-25 02:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:08:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:38:41 --> Total execution time: 0.1133
DEBUG - 2022-04-25 02:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:38:42 --> Total execution time: 0.1650
DEBUG - 2022-04-25 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:08:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 02:08:59 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 52
DEBUG - 2022-04-25 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:08:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:38:59 --> Total execution time: 0.1195
DEBUG - 2022-04-25 02:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:39:00 --> Total execution time: 0.1488
DEBUG - 2022-04-25 02:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:39:21 --> Total execution time: 0.1455
DEBUG - 2022-04-25 02:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:39:21 --> Total execution time: 0.1278
DEBUG - 2022-04-25 02:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:39:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 8
DEBUG - 2022-04-25 05:39:41 --> Total execution time: 0.2141
DEBUG - 2022-04-25 02:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:39:42 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 8
DEBUG - 2022-04-25 05:39:42 --> Total execution time: 0.1260
DEBUG - 2022-04-25 02:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:39:55 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 8
DEBUG - 2022-04-25 05:39:55 --> Total execution time: 0.1348
DEBUG - 2022-04-25 02:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:09:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:39:56 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 8
DEBUG - 2022-04-25 05:39:56 --> Total execution time: 0.1380
DEBUG - 2022-04-25 02:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:40:04 --> Total execution time: 0.1428
DEBUG - 2022-04-25 02:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:40:05 --> Total execution time: 0.1298
DEBUG - 2022-04-25 02:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 02:10:10 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 52
DEBUG - 2022-04-25 02:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:40:10 --> Total execution time: 0.1196
DEBUG - 2022-04-25 02:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:40:11 --> Total execution time: 0.1238
DEBUG - 2022-04-25 02:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:40:22 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 46
DEBUG - 2022-04-25 02:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 02:10:23 --> Severity: Warning --> Use of undefined constant MT_Key_DNS_USER - assumed 'MT_Key_DNS_USER' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 55
DEBUG - 2022-04-25 05:40:23 --> Total execution time: 0.1456
DEBUG - 2022-04-25 02:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 02:10:31 --> Severity: Warning --> Use of undefined constant MT_Key_DNS_USER - assumed 'MT_Key_DNS_USER' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 55
DEBUG - 2022-04-25 05:40:31 --> Total execution time: 0.1860
DEBUG - 2022-04-25 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:10:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:40:58 --> Total execution time: 0.1061
DEBUG - 2022-04-25 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:00 --> Total execution time: 0.0855
DEBUG - 2022-04-25 02:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:09 --> Total execution time: 0.0768
DEBUG - 2022-04-25 02:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:31 --> Total execution time: 0.0903
DEBUG - 2022-04-25 02:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:31 --> Total execution time: 0.1178
DEBUG - 2022-04-25 02:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 05:41:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 46
DEBUG - 2022-04-25 02:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:37 --> Total execution time: 0.1216
DEBUG - 2022-04-25 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:11:40 --> Total execution time: 0.1011
DEBUG - 2022-04-25 02:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:42 --> Total execution time: 0.0900
DEBUG - 2022-04-25 02:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:11:49 --> 404 Page Not Found: user/My-account/index
DEBUG - 2022-04-25 02:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:41:50 --> Total execution time: 0.0838
DEBUG - 2022-04-25 02:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:11:55 --> Total execution time: 0.0769
DEBUG - 2022-04-25 02:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:12:19 --> Total execution time: 0.1200
DEBUG - 2022-04-25 02:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:12:34 --> Total execution time: 0.0799
DEBUG - 2022-04-25 02:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:12:35 --> Total execution time: 0.0899
DEBUG - 2022-04-25 02:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:12:38 --> 404 Page Not Found: user/My-account/index
DEBUG - 2022-04-25 02:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:12:40 --> Total execution time: 0.0846
DEBUG - 2022-04-25 02:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:12:42 --> 404 Page Not Found: user/Leaderboard/index
DEBUG - 2022-04-25 02:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:12:43 --> Total execution time: 0.0892
DEBUG - 2022-04-25 02:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:12:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:42:48 --> Total execution time: 0.0999
DEBUG - 2022-04-25 02:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:13:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:13:01 --> Total execution time: 0.0946
DEBUG - 2022-04-25 02:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:13:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:43:54 --> Total execution time: 0.1087
DEBUG - 2022-04-25 02:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:44:25 --> Total execution time: 0.0916
DEBUG - 2022-04-25 02:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:14:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:44:27 --> Total execution time: 0.0912
DEBUG - 2022-04-25 02:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:45:07 --> Total execution time: 0.0935
DEBUG - 2022-04-25 02:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:16:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:16:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:46:34 --> Total execution time: 0.1252
DEBUG - 2022-04-25 02:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:17:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:47:22 --> Total execution time: 0.0972
DEBUG - 2022-04-25 02:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:17:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:47:55 --> Total execution time: 0.0888
DEBUG - 2022-04-25 02:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:18:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:48:10 --> Total execution time: 0.0998
DEBUG - 2022-04-25 02:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:18:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:48:16 --> Total execution time: 0.0887
DEBUG - 2022-04-25 02:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:19:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:49:06 --> Total execution time: 0.1189
DEBUG - 2022-04-25 02:19:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:19:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:49:36 --> Total execution time: 0.1339
DEBUG - 2022-04-25 02:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:21:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:51:38 --> Total execution time: 0.1856
DEBUG - 2022-04-25 02:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:21:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:23:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:53:27 --> Total execution time: 0.0891
DEBUG - 2022-04-25 02:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:54:06 --> Total execution time: 0.1322
DEBUG - 2022-04-25 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:54:13 --> Total execution time: 0.0760
DEBUG - 2022-04-25 02:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:54:24 --> Total execution time: 0.1007
DEBUG - 2022-04-25 02:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:54:32 --> Total execution time: 0.1582
DEBUG - 2022-04-25 02:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:54:37 --> Total execution time: 0.0978
DEBUG - 2022-04-25 02:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:24:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:25:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:25:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:55:50 --> Total execution time: 0.1061
DEBUG - 2022-04-25 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:27:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:57:55 --> Total execution time: 0.0919
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 02:28:01 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:58:29 --> Total execution time: 0.1642
DEBUG - 2022-04-25 02:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:29 --> UTF-8 Support Enabled
ERROR - 2022-04-25 02:28:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:29 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 02:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:28:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:58:31 --> Total execution time: 0.0927
DEBUG - 2022-04-25 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 02:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:28:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:58:40 --> Total execution time: 0.0853
DEBUG - 2022-04-25 04:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:05:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:35:34 --> Total execution time: 0.2133
DEBUG - 2022-04-25 04:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:06:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:36:42 --> Total execution time: 0.1104
DEBUG - 2022-04-25 04:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:07:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:37:07 --> Total execution time: 0.1200
DEBUG - 2022-04-25 04:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:37:35 --> Total execution time: 0.1698
DEBUG - 2022-04-25 04:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:11:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:41:28 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:41:28 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:41:28 --> Total execution time: 0.1207
DEBUG - 2022-04-25 04:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:11:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:41:56 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:41:56 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:41:56 --> Total execution time: 0.1854
DEBUG - 2022-04-25 04:12:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:12:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:12:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:42:44 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:42:44 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:42:44 --> Total execution time: 0.1211
DEBUG - 2022-04-25 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:13:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:43:37 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:43:37 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:43:37 --> Total execution time: 0.1203
DEBUG - 2022-04-25 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:13:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:43:43 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:43:43 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:43:43 --> Total execution time: 0.0997
DEBUG - 2022-04-25 04:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:13:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:43:50 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 07:43:50 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
DEBUG - 2022-04-25 07:43:50 --> Total execution time: 0.1093
DEBUG - 2022-04-25 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:14:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:44:53 --> Total execution time: 0.1172
DEBUG - 2022-04-25 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:15:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:45:19 --> Total execution time: 0.1784
DEBUG - 2022-04-25 04:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:15:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:45:45 --> Total execution time: 0.1844
DEBUG - 2022-04-25 04:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:15:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:45:50 --> Total execution time: 0.1152
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:16:03 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:16:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:46:25 --> Total execution time: 0.1675
DEBUG - 2022-04-25 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:19:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:49:55 --> Total execution time: 0.1313
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:50:16 --> Total execution time: 0.2866
DEBUG - 2022-04-25 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:16 --> UTF-8 Support Enabled
ERROR - 2022-04-25 04:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:16 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:50:29 --> Total execution time: 0.1726
DEBUG - 2022-04-25 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:50:51 --> Total execution time: 0.1327
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:52 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:21:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:51:05 --> Total execution time: 0.0935
DEBUG - 2022-04-25 04:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:21:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:51:07 --> Total execution time: 0.2082
DEBUG - 2022-04-25 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:21:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:21:08 --> 404 Page Not Found: user/Registration/index
DEBUG - 2022-04-25 04:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 04:22:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 52
DEBUG - 2022-04-25 04:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:52:25 --> Total execution time: 0.1163
DEBUG - 2022-04-25 04:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:52:26 --> Total execution time: 0.1836
DEBUG - 2022-04-25 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 07:52:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 46
DEBUG - 2022-04-25 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:52:42 --> Total execution time: 0.1901
DEBUG - 2022-04-25 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:52:49 --> Total execution time: 0.0865
DEBUG - 2022-04-25 04:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 07:52:50 --> Total execution time: 0.1439
DEBUG - 2022-04-25 04:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:22:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:22:52 --> Total execution time: 0.1857
DEBUG - 2022-04-25 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:23:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:23:10 --> Total execution time: 0.1076
DEBUG - 2022-04-25 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:23:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:23:33 --> Total execution time: 0.1074
DEBUG - 2022-04-25 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:26:44 --> Total execution time: 0.0988
DEBUG - 2022-04-25 04:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:27:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:27:44 --> Total execution time: 0.1156
DEBUG - 2022-04-25 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:29:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\stylesheet.php 3
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\stylesheet.php 8
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\header.php 8
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\header.php 11
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\header.php 17
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_LOGO - assumed 'SITE_LOGO' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\header.php 20
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\sidebar.php 5
ERROR - 2022-04-25 04:29:37 --> Severity: Notice --> Undefined variable: UserData C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 04:29:37 --> Severity: Notice --> Trying to get property 'ul_generate_id' of non-object C:\xampp\htdocs\leadsark\application\views\User\dashboard.php 43
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_COPYRIGHT - assumed 'SITE_COPYRIGHT' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\footer.php 5
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY_URL - assumed 'SITE_DEV_BY_URL' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\footer.php 9
ERROR - 2022-04-25 04:29:37 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\inc\footer.php 9
DEBUG - 2022-04-25 04:29:37 --> Total execution time: 0.1372
DEBUG - 2022-04-25 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:30:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 04:30:42 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 5
ERROR - 2022-04-25 04:30:42 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 8
ERROR - 2022-04-25 04:30:42 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 43
ERROR - 2022-04-25 04:30:42 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 89
ERROR - 2022-04-25 04:30:42 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 89
DEBUG - 2022-04-25 04:30:42 --> Total execution time: 0.1190
DEBUG - 2022-04-25 04:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:30:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 04:30:43 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 5
ERROR - 2022-04-25 04:30:43 --> Severity: Warning --> Use of undefined constant SITE_FAV - assumed 'SITE_FAV' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 8
ERROR - 2022-04-25 04:30:43 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 43
ERROR - 2022-04-25 04:30:43 --> Severity: Warning --> Use of undefined constant SITE_NAME - assumed 'SITE_NAME' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 89
ERROR - 2022-04-25 04:30:43 --> Severity: Warning --> Use of undefined constant SITE_DEV_BY - assumed 'SITE_DEV_BY' (this will throw an Error in a future version of PHP) C:\xampp\htdocs\leadsark\application\views\User\registration.php 89
DEBUG - 2022-04-25 04:30:43 --> Total execution time: 0.1322
DEBUG - 2022-04-25 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:16 --> Total execution time: 0.1174
DEBUG - 2022-04-25 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:16 --> Total execution time: 0.1542
DEBUG - 2022-04-25 04:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:50 --> Total execution time: 0.1781
DEBUG - 2022-04-25 04:31:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:51 --> Total execution time: 0.1311
DEBUG - 2022-04-25 04:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:56 --> Total execution time: 0.1783
DEBUG - 2022-04-25 04:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:31:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:31:57 --> Total execution time: 0.1600
DEBUG - 2022-04-25 04:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:32:12 --> Total execution time: 0.1449
DEBUG - 2022-04-25 04:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:32:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:32:13 --> Total execution time: 0.1390
DEBUG - 2022-04-25 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:32:28 --> Total execution time: 0.1774
DEBUG - 2022-04-25 04:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:32:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:32:28 --> Total execution time: 0.1468
DEBUG - 2022-04-25 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:33:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:33:31 --> Total execution time: 0.1460
DEBUG - 2022-04-25 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:33:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:33:32 --> Total execution time: 0.1069
DEBUG - 2022-04-25 04:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:34:20 --> Total execution time: 0.1517
DEBUG - 2022-04-25 04:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:34:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:34:20 --> Total execution time: 0.1367
DEBUG - 2022-04-25 04:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:35:18 --> Total execution time: 0.1220
DEBUG - 2022-04-25 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:35:19 --> Total execution time: 0.1451
DEBUG - 2022-04-25 04:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:35:39 --> Total execution time: 0.1509
DEBUG - 2022-04-25 04:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:35:40 --> Total execution time: 0.1204
DEBUG - 2022-04-25 04:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:03 --> Total execution time: 0.1565
DEBUG - 2022-04-25 04:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:04 --> Total execution time: 0.1424
DEBUG - 2022-04-25 04:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:12 --> Total execution time: 0.1454
DEBUG - 2022-04-25 04:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:13 --> Total execution time: 0.1441
DEBUG - 2022-04-25 04:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:16 --> Total execution time: 0.1304
DEBUG - 2022-04-25 04:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:17 --> Total execution time: 0.1513
DEBUG - 2022-04-25 04:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:34 --> Total execution time: 0.1598
DEBUG - 2022-04-25 04:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:36:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:36:35 --> Total execution time: 0.1338
DEBUG - 2022-04-25 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:38:24 --> Total execution time: 0.2031
DEBUG - 2022-04-25 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:38:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:38:25 --> Total execution time: 0.1638
DEBUG - 2022-04-25 04:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:39:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:39:09 --> Total execution time: 0.1522
DEBUG - 2022-04-25 04:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:39:10 --> Total execution time: 0.1522
DEBUG - 2022-04-25 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:39:29 --> 404 Page Not Found: user/Registration-step-one/index
DEBUG - 2022-04-25 04:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:39:37 --> Total execution time: 0.0989
DEBUG - 2022-04-25 04:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:42:21 --> Total execution time: 0.1635
DEBUG - 2022-04-25 04:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:42:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:42:22 --> Total execution time: 0.1429
DEBUG - 2022-04-25 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:42:23 --> Total execution time: 0.1444
DEBUG - 2022-04-25 04:42:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:42:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:42:23 --> Total execution time: 0.1215
DEBUG - 2022-04-25 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:43:21 --> Total execution time: 0.1480
DEBUG - 2022-04-25 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:43:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:43:21 --> Total execution time: 0.1098
DEBUG - 2022-04-25 04:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:43:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:43:35 --> Total execution time: 0.1489
DEBUG - 2022-04-25 04:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:54:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:54:02 --> Severity: error --> Exception: syntax error, unexpected ',' C:\xampp\htdocs\leadsark\application\controllers\User\RegistrationController.php 65
DEBUG - 2022-04-25 04:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:54:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:54:10 --> Email class already loaded. Second attempt ignored.
ERROR - 2022-04-25 04:54:13 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\leadsark\system\libraries\Email.php 1902
DEBUG - 2022-04-25 04:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:54:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 04:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:57:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:03:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:03:01 --> Total execution time: 0.0833
DEBUG - 2022-04-25 05:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:03:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:03:09 --> Total execution time: 0.1581
DEBUG - 2022-04-25 05:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:05:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:05:30 --> Total execution time: 0.1884
DEBUG - 2022-04-25 05:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:05:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:05:31 --> Total execution time: 0.1266
DEBUG - 2022-04-25 05:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:01 --> Total execution time: 0.2119
DEBUG - 2022-04-25 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:02 --> Total execution time: 0.1258
DEBUG - 2022-04-25 05:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:08 --> Total execution time: 0.1682
DEBUG - 2022-04-25 05:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:09 --> Total execution time: 0.1328
DEBUG - 2022-04-25 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:11 --> Total execution time: 0.1721
DEBUG - 2022-04-25 05:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:11 --> Total execution time: 0.1260
DEBUG - 2022-04-25 05:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:43 --> Total execution time: 0.1892
DEBUG - 2022-04-25 05:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:06:44 --> Total execution time: 0.1248
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:06:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:06:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:07:34 --> Total execution time: 0.1391
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 05:07:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:07:35 --> Total execution time: 0.1889
DEBUG - 2022-04-25 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:07:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:07:47 --> Total execution time: 0.1916
DEBUG - 2022-04-25 05:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:09:15 --> Total execution time: 0.1559
DEBUG - 2022-04-25 05:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:09:24 --> Total execution time: 0.0878
DEBUG - 2022-04-25 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:08 --> Total execution time: 0.1970
DEBUG - 2022-04-25 05:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:09 --> Total execution time: 0.1117
DEBUG - 2022-04-25 05:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:35 --> Total execution time: 0.1719
DEBUG - 2022-04-25 05:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:36 --> Total execution time: 0.1435
DEBUG - 2022-04-25 05:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:47 --> Total execution time: 0.1758
DEBUG - 2022-04-25 05:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:48 --> Total execution time: 0.1479
DEBUG - 2022-04-25 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:55 --> Total execution time: 0.1365
DEBUG - 2022-04-25 05:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:10:55 --> Total execution time: 0.1363
DEBUG - 2022-04-25 05:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:12:34 --> Total execution time: 0.1559
DEBUG - 2022-04-25 05:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:12:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 05:12:35 --> Total execution time: 0.1186
DEBUG - 2022-04-25 18:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:43:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 18:43:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\core\DB_Controller.php 52
DEBUG - 2022-04-25 18:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:43:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:13:37 --> Total execution time: 0.1417
DEBUG - 2022-04-25 18:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:43:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:13:38 --> Total execution time: 0.2001
DEBUG - 2022-04-25 18:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:43:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 22:13:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\leadsark\application\controllers\User\Auth\UserAuth.php 46
DEBUG - 2022-04-25 18:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:43:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:13:47 --> Total execution time: 0.2338
DEBUG - 2022-04-25 18:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:45:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:15:29 --> Total execution time: 0.1215
DEBUG - 2022-04-25 18:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:16:07 --> Total execution time: 0.3874
DEBUG - 2022-04-25 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:18:00 --> Total execution time: 0.0822
DEBUG - 2022-04-25 18:48:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:18:01 --> Total execution time: 0.1472
DEBUG - 2022-04-25 18:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:04 --> Total execution time: 0.1350
DEBUG - 2022-04-25 18:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:04 --> Total execution time: 0.1389
DEBUG - 2022-04-25 18:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:25 --> Total execution time: 0.1201
DEBUG - 2022-04-25 18:48:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 18:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 18:48:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 18:48:25 --> Total execution time: 0.1175
DEBUG - 2022-04-25 19:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:02:03 --> Total execution time: 0.1478
DEBUG - 2022-04-25 19:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:02:03 --> Total execution time: 0.1274
DEBUG - 2022-04-25 19:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:02:05 --> Total execution time: 0.1331
DEBUG - 2022-04-25 19:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:02:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:02:12 --> Total execution time: 0.0842
DEBUG - 2022-04-25 19:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:02:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:02:13 --> Total execution time: 0.1350
DEBUG - 2022-04-25 19:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:03:16 --> Total execution time: 0.1621
DEBUG - 2022-04-25 19:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:03:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:03:16 --> Total execution time: 0.1129
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:03:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:03:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:04:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:04:53 --> Total execution time: 0.1221
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:04:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:04:54 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:04:54 --> Total execution time: 0.2209
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:23 --> Total execution time: 0.1529
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:05:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:23 --> Total execution time: 0.1929
DEBUG - 2022-04-25 19:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:26 --> Total execution time: 0.1054
DEBUG - 2022-04-25 19:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:50 --> Total execution time: 0.1754
DEBUG - 2022-04-25 19:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:50 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:05:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:51 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:05:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:05:51 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:51 --> Total execution time: 0.1629
DEBUG - 2022-04-25 19:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:05:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:05:52 --> Total execution time: 0.1089
DEBUG - 2022-04-25 19:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:06:46 --> Total execution time: 0.1237
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:08:15 --> Total execution time: 0.1443
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:15 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:08:15 --> Total execution time: 0.1808
DEBUG - 2022-04-25 19:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 19:08:24 --> Severity: error --> Exception: Call to undefined function send_mail_without_smtp() C:\xampp\htdocs\leadsark\application\controllers\User\RegistrationController.php 111
DEBUG - 2022-04-25 19:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 19:08:33 --> Severity: error --> Exception: Call to undefined function send_mail_without_smtp() C:\xampp\htdocs\leadsark\application\controllers\User\RegistrationController.php 111
DEBUG - 2022-04-25 19:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:08:45 --> Total execution time: 0.1315
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:45 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:08:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:08:45 --> Total execution time: 0.1686
DEBUG - 2022-04-25 19:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:08:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:08:47 --> Total execution time: 0.1203
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:10:30 --> Total execution time: 0.1385
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:10:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:10:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:10:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:10:30 --> Total execution time: 0.1664
DEBUG - 2022-04-25 19:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:10:44 --> Total execution time: 0.1593
DEBUG - 2022-04-25 19:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:10:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:10:44 --> Total execution time: 0.1600
DEBUG - 2022-04-25 19:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:12:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:12:59 --> Total execution time: 0.1530
DEBUG - 2022-04-25 19:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:13:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:13:00 --> Total execution time: 0.1654
DEBUG - 2022-04-25 19:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:13:17 --> Total execution time: 0.1659
DEBUG - 2022-04-25 19:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:13:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:13:17 --> Total execution time: 0.1463
DEBUG - 2022-04-25 19:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:13:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:13:19 --> Total execution time: 0.1248
DEBUG - 2022-04-25 19:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:14:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:14:26 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ']' C:\xampp\htdocs\leadsark\application\controllers\User\RegistrationController.php 81
DEBUG - 2022-04-25 19:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:14:34 --> Total execution time: 0.0970
DEBUG - 2022-04-25 19:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:14:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:14:34 --> Total execution time: 0.1321
DEBUG - 2022-04-25 19:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:15:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:15:34 --> Total execution time: 0.1543
DEBUG - 2022-04-25 19:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:15:35 --> Total execution time: 0.1048
DEBUG - 2022-04-25 19:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:15:36 --> 404 Page Not Found: Forgot-password-verify-otp/index
DEBUG - 2022-04-25 19:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:15:40 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:15:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:15:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:15:41 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:15:41 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:19:44 --> Total execution time: 0.1837
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:19:45 --> Total execution time: 0.1685
DEBUG - 2022-04-25 19:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:19:49 --> Total execution time: 0.1193
DEBUG - 2022-04-25 19:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:49 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:19:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:49 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:19:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:19:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:19:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:19:50 --> Total execution time: 0.1659
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:20:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:20:09 --> Total execution time: 0.1289
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:20:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:20:10 --> Total execution time: 0.1632
DEBUG - 2022-04-25 19:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:20:13 --> 404 Page Not Found: Verify-registration-otp/index
DEBUG - 2022-04-25 19:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:20:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:20:21 --> Total execution time: 0.1199
DEBUG - 2022-04-25 19:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:21:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:21:57 --> Total execution time: 0.0946
DEBUG - 2022-04-25 19:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:22:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:22:47 --> Total execution time: 0.0978
DEBUG - 2022-04-25 19:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:23:53 --> Total execution time: 0.0886
DEBUG - 2022-04-25 19:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:23:58 --> Total execution time: 0.0939
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:23:59 --> Total execution time: 0.1098
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:23:59 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:23:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:23:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:24:08 --> Total execution time: 0.1289
DEBUG - 2022-04-25 19:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:24:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:24:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:24:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:24:09 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:24:09 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:24:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:24:09 --> Total execution time: 0.1820
DEBUG - 2022-04-25 19:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:24:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:24:16 --> Total execution time: 0.1094
DEBUG - 2022-04-25 19:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:56:16 --> Total execution time: 0.0892
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:17 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:56:56 --> Total execution time: 0.0826
DEBUG - 2022-04-25 19:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:57 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:56:57 --> Total execution time: 0.1585
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:26:58 --> Total execution time: 0.1158
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:26:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:26:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
ERROR - 2022-04-25 19:26:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:26:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:26:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:26:59 --> Total execution time: 0.1962
DEBUG - 2022-04-25 19:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:13 --> Total execution time: 0.1326
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:14 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:14 --> Total execution time: 0.2230
DEBUG - 2022-04-25 19:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:21 --> Total execution time: 0.1327
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:22 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:22 --> Total execution time: 0.1512
DEBUG - 2022-04-25 19:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:29 --> Total execution time: 0.1097
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:30 --> Total execution time: 0.1592
DEBUG - 2022-04-25 19:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:57:34 --> Total execution time: 0.1137
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:27:35 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:58:41 --> Total execution time: 0.1184
DEBUG - 2022-04-25 19:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:58:48 --> Total execution time: 0.0798
DEBUG - 2022-04-25 19:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:58:49 --> Total execution time: 0.1105
DEBUG - 2022-04-25 19:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:28:53 --> Total execution time: 0.1311
DEBUG - 2022-04-25 19:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:28:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:28:53 --> Total execution time: 0.1040
DEBUG - 2022-04-25 19:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:29:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:29:06 --> Total execution time: 0.1100
DEBUG - 2022-04-25 19:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:29:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:29:06 --> Total execution time: 0.1169
DEBUG - 2022-04-25 19:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:29:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:59:13 --> Total execution time: 0.1126
DEBUG - 2022-04-25 19:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:15 --> Total execution time: 0.0886
DEBUG - 2022-04-25 19:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:22 --> Total execution time: 0.0889
DEBUG - 2022-04-25 19:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:22 --> Total execution time: 0.1539
DEBUG - 2022-04-25 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:24 --> Total execution time: 0.1303
DEBUG - 2022-04-25 19:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:24 --> Total execution time: 0.1478
DEBUG - 2022-04-25 19:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:39 --> Total execution time: 0.1141
DEBUG - 2022-04-25 19:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:40 --> Total execution time: 0.1275
DEBUG - 2022-04-25 19:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:47 --> Total execution time: 0.1188
DEBUG - 2022-04-25 19:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:48 --> Total execution time: 0.1070
DEBUG - 2022-04-25 19:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:51 --> Total execution time: 0.1207
DEBUG - 2022-04-25 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:30:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:59 --> Total execution time: 0.0873
DEBUG - 2022-04-25 19:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:31:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:01:00 --> Total execution time: 0.2190
DEBUG - 2022-04-25 19:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:02:26 --> Total execution time: 0.1725
DEBUG - 2022-04-25 19:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:32:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:02:26 --> Total execution time: 0.1142
DEBUG - 2022-04-25 19:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:32:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:02:33 --> Total execution time: 0.1252
DEBUG - 2022-04-25 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:37 --> Total execution time: 0.0834
DEBUG - 2022-04-25 19:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:38 --> Total execution time: 0.1223
DEBUG - 2022-04-25 19:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:45 --> No URI present. Default controller set.
DEBUG - 2022-04-25 19:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:48 --> Total execution time: 0.0835
DEBUG - 2022-04-25 19:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:33:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:48 --> Total execution time: 0.1249
DEBUG - 2022-04-25 19:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:04:52 --> Total execution time: 0.1431
DEBUG - 2022-04-25 19:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:34:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:04:52 --> Total execution time: 0.1337
DEBUG - 2022-04-25 19:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:05:00 --> Total execution time: 0.1666
DEBUG - 2022-04-25 19:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:05:00 --> Total execution time: 0.1970
DEBUG - 2022-04-25 19:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:05:06 --> Total execution time: 0.1358
DEBUG - 2022-04-25 19:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:05:07 --> Total execution time: 0.1048
DEBUG - 2022-04-25 19:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:35:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:35:13 --> Total execution time: 0.1211
DEBUG - 2022-04-25 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:07 --> Total execution time: 0.0928
DEBUG - 2022-04-25 19:36:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:08 --> Total execution time: 0.1477
DEBUG - 2022-04-25 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:09 --> Total execution time: 0.1450
DEBUG - 2022-04-25 19:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:09 --> Total execution time: 0.1416
DEBUG - 2022-04-25 19:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:14 --> Total execution time: 0.1200
DEBUG - 2022-04-25 19:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:15 --> Total execution time: 0.1092
DEBUG - 2022-04-25 19:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:36:17 --> Total execution time: 0.1327
DEBUG - 2022-04-25 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:46:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:46:13 --> Total execution time: 0.0801
DEBUG - 2022-04-25 19:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:46:14 --> Total execution time: 0.1286
DEBUG - 2022-04-25 19:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:26 --> Total execution time: 0.1270
DEBUG - 2022-04-25 19:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:27 --> Total execution time: 0.1212
DEBUG - 2022-04-25 19:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:30 --> Total execution time: 0.1248
DEBUG - 2022-04-25 19:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:43 --> Total execution time: 0.1086
DEBUG - 2022-04-25 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:45 --> Total execution time: 0.0837
DEBUG - 2022-04-25 19:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:45 --> Total execution time: 0.1284
DEBUG - 2022-04-25 19:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:51 --> Total execution time: 0.1133
DEBUG - 2022-04-25 19:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:52 --> Total execution time: 0.1478
DEBUG - 2022-04-25 19:47:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:57 --> Total execution time: 0.1134
DEBUG - 2022-04-25 19:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:47:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:47:57 --> Total execution time: 0.1342
DEBUG - 2022-04-25 19:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:48:11 --> Total execution time: 0.1181
DEBUG - 2022-04-25 19:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:48:11 --> Total execution time: 0.1080
DEBUG - 2022-04-25 19:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:48:18 --> Total execution time: 0.1085
DEBUG - 2022-04-25 19:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:18:32 --> Total execution time: 0.1113
DEBUG - 2022-04-25 19:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:48:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:18:46 --> Total execution time: 0.1536
DEBUG - 2022-04-25 19:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:23:10 --> Total execution time: 0.1115
DEBUG - 2022-04-25 19:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:23:16 --> Total execution time: 0.0831
DEBUG - 2022-04-25 19:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:23:16 --> Total execution time: 0.1239
DEBUG - 2022-04-25 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:18 --> Total execution time: 0.1210
DEBUG - 2022-04-25 19:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:19 --> Total execution time: 0.1685
DEBUG - 2022-04-25 19:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:35 --> Total execution time: 0.0929
DEBUG - 2022-04-25 19:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:53:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:53:35 --> Total execution time: 0.1440
DEBUG - 2022-04-25 19:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:54:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2022-04-25 19:54:45 --> Severity: Notice --> Undefined variable: encr C:\xampp\htdocs\leadsark\application\views\User\registration.php 67
ERROR - 2022-04-25 19:54:45 --> Severity: error --> Exception: Function name must be a string C:\xampp\htdocs\leadsark\application\views\User\registration.php 67
DEBUG - 2022-04-25 19:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:54:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:54:51 --> Total execution time: 0.1116
DEBUG - 2022-04-25 19:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:54:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:54:52 --> Total execution time: 0.1477
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 19:54:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 19:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:55:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:56:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 19:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 19:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 19:56:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:00:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:00:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:00:06 --> Total execution time: 0.1738
DEBUG - 2022-04-25 20:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:00:57 --> Total execution time: 0.0815
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:00:57 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:00:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:00:57 --> Total execution time: 0.1394
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:38 --> Total execution time: 0.1154
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:38 --> UTF-8 Support Enabled
ERROR - 2022-04-25 20:01:38 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:39 --> Total execution time: 0.1658
DEBUG - 2022-04-25 20:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:43 --> Total execution time: 0.1149
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:44 --> UTF-8 Support Enabled
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:44 --> Total execution time: 0.1428
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:01:46 --> Total execution time: 0.1214
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:46 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:47 --> UTF-8 Support Enabled
ERROR - 2022-04-25 20:01:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:47 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:01:47 --> Total execution time: 0.1455
DEBUG - 2022-04-25 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:58 --> Total execution time: 0.1219
DEBUG - 2022-04-25 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:01:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:32:05 --> Total execution time: 0.1234
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:05 --> UTF-8 Support Enabled
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:05 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:32:06 --> Total execution time: 0.1566
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:07 --> Total execution time: 0.1312
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 20:02:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 20:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:08 --> Total execution time: 0.1647
DEBUG - 2022-04-25 20:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:25 --> Total execution time: 0.1328
DEBUG - 2022-04-25 20:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:25 --> Total execution time: 0.1262
DEBUG - 2022-04-25 20:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:32:34 --> Total execution time: 0.1337
DEBUG - 2022-04-25 20:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:03:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:33:03 --> Total execution time: 0.0844
DEBUG - 2022-04-25 20:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:56:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 20:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 20:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 20:56:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:01:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:05:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:06:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:06:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:07:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:08:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:08:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:09:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:11:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:11:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:13:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:13:17 --> 404 Page Not Found: Add-bank-account/index
DEBUG - 2022-04-25 21:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:14:03 --> 404 Page Not Found: Add-bank-account/index
DEBUG - 2022-04-25 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:14:08 --> 404 Page Not Found: user/Add-bank-account/index
DEBUG - 2022-04-25 21:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:14:16 --> 404 Page Not Found: user/Add-bank-account/index
DEBUG - 2022-04-25 21:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:16:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:17:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:18:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:20:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:20:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:22:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:23:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:24:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:25:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:25:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:25:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:26:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:27:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:27:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:28:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:30:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:30:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:31:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:32:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:32:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:33:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:07 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:07 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:34:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:34:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:02 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:21 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:55 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:35:56 --> UTF-8 Support Enabled
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:35:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:35:56 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:10 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:36:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:36:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:36:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 21:36:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:37:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:38:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:38:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:38:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:40:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:41:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 21:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 21:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 21:41:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 22:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 22:33:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 22:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 22:33:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 22:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 22:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 22:37:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:00:40 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:00:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:00:40 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:01:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:01:31 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:01:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:01:32 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:01:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:03:14 --> Severity: error --> Exception: syntax error, unexpected '=', expecting ']' C:\xampp\htdocs\leadsark\application\controllers\User\Affiliate_Account_Controller.php 18
DEBUG - 2022-04-25 23:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:03:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:03:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:03:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:03:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:06:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:06:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:07:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:13:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:13:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:14:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:14:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:15:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:15:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:15:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:08 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:08 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:33 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:16:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:16:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:17:00 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:17:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:18:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:18:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:18:23 --> 404 Page Not Found: user/Update-thumbnail/index
DEBUG - 2022-04-25 23:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:18:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:19:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:19:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:19:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:19:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:20:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:21:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:23:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:25:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:26:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:26:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:31:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:31:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:31:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:32:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:32:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:33:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:33:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:33:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:34:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:34:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:34:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:36:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:36:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:37:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:38:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:41:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:41:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:41:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:41:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:42:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:45:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:46:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:46:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:46:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:46:18 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:46:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:46:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:48:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:26 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:27 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:48:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:48:50 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:49:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:45 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:46 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:49:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:58 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:49:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:49:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:58 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:49:58 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:49:59 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:50:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:50:10 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:10 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:50:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:50:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:52:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:53:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:53:44 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:11 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:56:30 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:56:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:59:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 23:59:23 --> 404 Page Not Found: Assets/backend
DEBUG - 2022-04-25 23:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:59:28 --> Encryption: Auto-configured driver 'openssl'.
