<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-12-24 02:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 02:54:50 --> No URI present. Default controller set.
DEBUG - 2022-12-24 02:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 02:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 02:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:24:50 --> Total execution time: 0.1268
DEBUG - 2022-12-24 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 02:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 02:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 02:59:21 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 02:59:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 02:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 02:59:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 02:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 02:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 02:59:21 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:07:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:07:02 --> No URI present. Default controller set.
DEBUG - 2022-12-24 03:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:07:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:37:02 --> Total execution time: 0.0446
DEBUG - 2022-12-24 03:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:07:36 --> No URI present. Default controller set.
DEBUG - 2022-12-24 03:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:07:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:37:36 --> Total execution time: 0.0639
DEBUG - 2022-12-24 03:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:07:38 --> 404 Page Not Found: Admin/Website/RegistrationController
DEBUG - 2022-12-24 03:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:08:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:08:22 --> 404 Page Not Found: Admin/Website/auth
DEBUG - 2022-12-24 03:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:08:39 --> Severity: Compile Error --> Cannot redeclare RegistrationController::index() C:\xampp\htdocs\gopal\crowd_funding\application\controllers\website\auth\RegistrationController.php 16
DEBUG - 2022-12-24 03:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:08:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:09:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:39:06 --> Total execution time: 0.0477
DEBUG - 2022-12-24 03:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:09:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:39:21 --> Total execution time: 0.0658
DEBUG - 2022-12-24 03:10:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:10:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:40:18 --> Total execution time: 0.0409
DEBUG - 2022-12-24 03:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:10:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:40:48 --> Total execution time: 0.0725
DEBUG - 2022-12-24 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:42:45 --> Total execution time: 0.0568
DEBUG - 2022-12-24 03:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:12:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:12:45 --> 404 Page Not Found: Fundraiser/assets
DEBUG - 2022-12-24 03:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:13:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:43:08 --> Total execution time: 0.0530
DEBUG - 2022-12-24 03:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:13:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:43:26 --> Total execution time: 0.0605
DEBUG - 2022-12-24 03:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:13:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:43:31 --> Total execution time: 0.0909
DEBUG - 2022-12-24 03:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:47:23 --> Total execution time: 0.0394
DEBUG - 2022-12-24 03:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:17:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:47:44 --> Total execution time: 0.0443
DEBUG - 2022-12-24 03:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:18:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:48:05 --> Total execution time: 0.0439
DEBUG - 2022-12-24 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:20:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:50:02 --> Total execution time: 0.0419
DEBUG - 2022-12-24 03:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:51:11 --> Total execution time: 0.0423
DEBUG - 2022-12-24 03:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:21:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:51:22 --> Total execution time: 0.0663
DEBUG - 2022-12-24 03:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:21:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:21:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:21:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:21:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:21:30 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:23:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:53:18 --> Total execution time: 0.0616
DEBUG - 2022-12-24 03:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:18 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:23:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:53:31 --> Total execution time: 0.0561
DEBUG - 2022-12-24 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:23:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:23:48 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:24:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:54:43 --> Total execution time: 0.0402
DEBUG - 2022-12-24 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:24:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:24:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:24:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:24:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:24:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:25:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:55:46 --> Total execution time: 0.0602
DEBUG - 2022-12-24 03:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:27:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 07:57:52 --> Total execution time: 0.0416
DEBUG - 2022-12-24 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:32:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:02:01 --> Total execution time: 0.0625
DEBUG - 2022-12-24 03:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:32:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:02:10 --> Total execution time: 0.0848
DEBUG - 2022-12-24 03:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:02:16 --> Total execution time: 0.0744
DEBUG - 2022-12-24 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:32:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:02:37 --> Total execution time: 0.0547
DEBUG - 2022-12-24 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:32:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:32:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:32:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:32:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:33:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:03:02 --> Total execution time: 0.0706
DEBUG - 2022-12-24 03:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:33:03 --> UTF-8 Support Enabled
ERROR - 2022-12-24 03:33:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:33:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:03:46 --> Total execution time: 0.0470
DEBUG - 2022-12-24 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:46 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:03:56 --> Total execution time: 0.0639
DEBUG - 2022-12-24 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:56 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:33:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:33:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:33:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:34:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:04:45 --> Total execution time: 0.0583
DEBUG - 2022-12-24 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:34:45 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:34:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:34:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:34:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:35:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:05:02 --> Total execution time: 0.0721
DEBUG - 2022-12-24 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:02 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:35:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:03 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:35:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:05:35 --> Total execution time: 0.0480
DEBUG - 2022-12-24 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:35:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:35:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:36:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:06:08 --> Total execution time: 0.0571
DEBUG - 2022-12-24 03:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:36:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:06:33 --> Total execution time: 0.0589
DEBUG - 2022-12-24 03:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:37:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:07:33 --> Total execution time: 0.0569
DEBUG - 2022-12-24 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:37:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:37:36 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:37:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:37:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:37:36 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:15:34 --> Total execution time: 0.0409
DEBUG - 2022-12-24 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:34 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:45:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:34 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:15:49 --> Total execution time: 0.0395
DEBUG - 2022-12-24 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:49 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:45:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:45:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:45:49 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:46:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:16:17 --> Total execution time: 0.0422
DEBUG - 2022-12-24 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:46:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:46:17 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:46:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:46:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:46:17 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:17:52 --> Total execution time: 0.0381
DEBUG - 2022-12-24 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:47:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:47:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:47:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:47:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:48:02 --> UTF-8 Support Enabled
ERROR - 2022-12-24 03:48:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:48:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:18:16 --> Total execution time: 0.0409
DEBUG - 2022-12-24 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:48:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:16 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:48:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:48:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:48:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:18:57 --> Total execution time: 0.0672
DEBUG - 2022-12-24 03:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:50:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:50:32 --> Total execution time: 0.0600
DEBUG - 2022-12-24 03:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:50:38 --> Total execution time: 0.0367
DEBUG - 2022-12-24 03:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:50:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:50:42 --> Total execution time: 0.0381
DEBUG - 2022-12-24 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:51:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:21:06 --> Total execution time: 0.1281
DEBUG - 2022-12-24 03:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:51:06 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-24 03:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:21:09 --> Total execution time: 0.0691
DEBUG - 2022-12-24 03:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:51:10 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-24 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:51:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:21:11 --> Total execution time: 0.0840
DEBUG - 2022-12-24 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:51:11 --> 404 Page Not Found: Assets/website_esa
DEBUG - 2022-12-24 03:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:52:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:22:42 --> Total execution time: 0.0534
DEBUG - 2022-12-24 03:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:53:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:23:13 --> Total execution time: 0.0991
DEBUG - 2022-12-24 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:53:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:23:34 --> Total execution time: 0.0907
DEBUG - 2022-12-24 03:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:53:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:23:43 --> Total execution time: 0.0626
DEBUG - 2022-12-24 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:53:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:23:50 --> Total execution time: 0.0713
DEBUG - 2022-12-24 03:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:58:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:28:36 --> Total execution time: 0.0677
DEBUG - 2022-12-24 03:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:58:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:28:37 --> Total execution time: 0.0527
DEBUG - 2022-12-24 03:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:47 --> No URI present. Default controller set.
DEBUG - 2022-12-24 03:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:58:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:28:47 --> Total execution time: 0.0408
DEBUG - 2022-12-24 03:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:58:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:28:49 --> Total execution time: 0.0481
DEBUG - 2022-12-24 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:58:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:58:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:58:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:58:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:59:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:29:28 --> Total execution time: 0.0607
DEBUG - 2022-12-24 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:29 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 03:59:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:29 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 03:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 03:59:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:29:44 --> Total execution time: 0.0625
DEBUG - 2022-12-24 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 03:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 03:59:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 03:59:45 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 04:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 04:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 04:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 04:00:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:30:24 --> Total execution time: 0.0573
DEBUG - 2022-12-24 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 04:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 04:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 04:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:30:42 --> Total execution time: 0.0608
DEBUG - 2022-12-24 04:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 04:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 04:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 04:00:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:30:52 --> Total execution time: 0.0776
DEBUG - 2022-12-24 04:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 04:01:07 --> No URI present. Default controller set.
DEBUG - 2022-12-24 04:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 04:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 04:01:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:31:07 --> Total execution time: 0.0396
DEBUG - 2022-12-24 04:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 04:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 04:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 04:02:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 08:32:11 --> Total execution time: 0.0628
DEBUG - 2022-12-24 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:15:39 --> No URI present. Default controller set.
DEBUG - 2022-12-24 16:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:15:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 20:45:43 --> Total execution time: 4.6966
DEBUG - 2022-12-24 16:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:17:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 20:47:01 --> Total execution time: 0.0659
DEBUG - 2022-12-24 16:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:18:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 20:48:21 --> Total execution time: 0.0564
DEBUG - 2022-12-24 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:34:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:04:30 --> Total execution time: 0.8039
DEBUG - 2022-12-24 16:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:34:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:04:41 --> Total execution time: 0.0516
DEBUG - 2022-12-24 16:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:34:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:04:51 --> Total execution time: 0.0509
DEBUG - 2022-12-24 16:35:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:02 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 16:35:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:02 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:35:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:05:25 --> Total execution time: 0.0530
DEBUG - 2022-12-24 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:26 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 16:35:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:26 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:35:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:35:34 --> 404 Page Not Found: website/UserAuth/UserLogin
DEBUG - 2022-12-24 16:38:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:38:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:38:00 --> 404 Page Not Found: website/UserAuth/index
DEBUG - 2022-12-24 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:38:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:08:24 --> Total execution time: 0.0646
DEBUG - 2022-12-24 16:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:02 --> Total execution time: 0.0527
DEBUG - 2022-12-24 16:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:10 --> Total execution time: 0.0682
DEBUG - 2022-12-24 16:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:25 --> Total execution time: 0.0648
DEBUG - 2022-12-24 16:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:37 --> Total execution time: 0.0534
DEBUG - 2022-12-24 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:44 --> Total execution time: 0.0560
DEBUG - 2022-12-24 16:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:39:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:09:53 --> Total execution time: 0.0793
DEBUG - 2022-12-24 16:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:41:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:11:47 --> Total execution time: 0.0660
DEBUG - 2022-12-24 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:41:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:11:51 --> Total execution time: 0.0586
DEBUG - 2022-12-24 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:42:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:12:35 --> Total execution time: 0.0885
DEBUG - 2022-12-24 16:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:42:52 --> UTF-8 Support Enabled
ERROR - 2022-12-24 16:42:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:42:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:42:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:42:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:42:52 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:43:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:13:06 --> Total execution time: 0.0702
DEBUG - 2022-12-24 16:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:43:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:13:23 --> Total execution time: 0.0851
DEBUG - 2022-12-24 16:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:43:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:43:23 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-24 16:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:43:29 --> No URI present. Default controller set.
DEBUG - 2022-12-24 16:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:43:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:13:29 --> Total execution time: 0.0586
DEBUG - 2022-12-24 16:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:46:57 --> No URI present. Default controller set.
DEBUG - 2022-12-24 16:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:46:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:16:57 --> Total execution time: 0.0594
DEBUG - 2022-12-24 16:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:46:59 --> 404 Page Not Found: Posts_Controller/index
DEBUG - 2022-12-24 16:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:47:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:17:21 --> Total execution time: 0.0773
DEBUG - 2022-12-24 16:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:18:02 --> Total execution time: 0.0578
DEBUG - 2022-12-24 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:48:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:18:08 --> Total execution time: 0.0563
DEBUG - 2022-12-24 16:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:48:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:18:40 --> Total execution time: 0.0587
DEBUG - 2022-12-24 16:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:50:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:20:24 --> Total execution time: 0.0536
DEBUG - 2022-12-24 16:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:51:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:21:09 --> Total execution time: 0.0507
DEBUG - 2022-12-24 16:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:51:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:21:22 --> Total execution time: 0.0442
DEBUG - 2022-12-24 16:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:51:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:21:40 --> Total execution time: 0.0749
DEBUG - 2022-12-24 16:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:52:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:22:03 --> Total execution time: 0.0726
DEBUG - 2022-12-24 16:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:52:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:22:13 --> Total execution time: 0.0673
DEBUG - 2022-12-24 16:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:54:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:24:04 --> Total execution time: 0.0656
DEBUG - 2022-12-24 16:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:54:04 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-24 16:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:54:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:24:06 --> Total execution time: 0.0413
DEBUG - 2022-12-24 16:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:54:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:24:08 --> Total execution time: 0.0410
DEBUG - 2022-12-24 16:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:24:11 --> Total execution time: 0.0531
DEBUG - 2022-12-24 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:47 --> UTF-8 Support Enabled
ERROR - 2022-12-24 16:54:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:54:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:54:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 16:54:47 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 16:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:55:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:25:45 --> Total execution time: 0.0534
DEBUG - 2022-12-24 16:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:56:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:26:52 --> Total execution time: 0.0623
DEBUG - 2022-12-24 16:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:59:03 --> No URI present. Default controller set.
DEBUG - 2022-12-24 16:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:59:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:29:03 --> Total execution time: 0.0637
DEBUG - 2022-12-24 17:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:00:47 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:00:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:30:47 --> Total execution time: 0.0530
DEBUG - 2022-12-24 17:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:00:49 --> 404 Page Not Found: website/auth/RegistrationController/UserRegistration
DEBUG - 2022-12-24 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:01:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:31:40 --> Total execution time: 0.0662
DEBUG - 2022-12-24 17:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:05:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:35:59 --> Total execution time: 0.0674
DEBUG - 2022-12-24 17:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:06:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:36:24 --> Total execution time: 0.0586
DEBUG - 2022-12-24 17:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:06:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:36:54 --> Total execution time: 0.0470
DEBUG - 2022-12-24 17:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:07:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:37:13 --> Total execution time: 0.0398
DEBUG - 2022-12-24 17:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:08:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:38:12 --> Total execution time: 0.0720
DEBUG - 2022-12-24 17:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:08:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:38:16 --> Total execution time: 0.0544
DEBUG - 2022-12-24 17:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:09:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:39:24 --> Total execution time: 0.0888
DEBUG - 2022-12-24 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:09:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:39:48 --> Total execution time: 0.0529
DEBUG - 2022-12-24 17:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:09:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:39:50 --> Total execution time: 0.0406
DEBUG - 2022-12-24 17:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:40:00 --> Total execution time: 0.0454
DEBUG - 2022-12-24 17:10:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:10:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:40:01 --> Total execution time: 0.0415
DEBUG - 2022-12-24 17:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:10:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:40:03 --> Total execution time: 0.0518
DEBUG - 2022-12-24 17:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:42:40 --> Total execution time: 0.0503
DEBUG - 2022-12-24 17:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:12:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:42:43 --> Total execution time: 0.0636
DEBUG - 2022-12-24 17:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:12:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:42:45 --> Total execution time: 0.0410
DEBUG - 2022-12-24 17:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:13:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:43:30 --> Total execution time: 0.0594
DEBUG - 2022-12-24 17:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:13:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:43:33 --> Total execution time: 0.0419
DEBUG - 2022-12-24 17:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:13:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:43:36 --> Total execution time: 0.0574
DEBUG - 2022-12-24 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:14:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:44:51 --> Total execution time: 0.0578
DEBUG - 2022-12-24 17:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:15:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:45:47 --> Total execution time: 0.0501
DEBUG - 2022-12-24 17:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:01 --> Total execution time: 0.0427
DEBUG - 2022-12-24 17:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:17 --> Total execution time: 0.0389
DEBUG - 2022-12-24 17:16:17 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:16:17 --> 404 Page Not Found: Assets/images
DEBUG - 2022-12-24 17:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:24 --> Total execution time: 0.0784
DEBUG - 2022-12-24 17:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:33 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:33 --> Total execution time: 0.0423
DEBUG - 2022-12-24 17:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:40 --> Total execution time: 0.0662
DEBUG - 2022-12-24 17:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:16:47 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:16:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:46:47 --> Total execution time: 0.0399
DEBUG - 2022-12-24 17:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:17:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:17:54 --> UTF-8 Support Enabled
ERROR - 2022-12-24 17:17:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:17:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:17:54 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:19:43 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:19:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:49:43 --> Total execution time: 0.0624
DEBUG - 2022-12-24 17:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:10 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:20:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:50:10 --> Total execution time: 0.0395
DEBUG - 2022-12-24 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:16 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 17:20:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:16 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:56 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:20:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:50:56 --> Total execution time: 0.0414
DEBUG - 2022-12-24 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:20:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:20:56 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:19 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:21:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:51:19 --> Total execution time: 0.1082
DEBUG - 2022-12-24 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:21:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:21:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:21:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:21:19 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:21:58 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:21:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:51:58 --> Total execution time: 0.0595
DEBUG - 2022-12-24 17:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:22:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:52:01 --> Total execution time: 0.0428
DEBUG - 2022-12-24 17:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:22:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:22:10 --> UTF-8 Support Enabled
ERROR - 2022-12-24 17:22:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:22:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:22:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:22:10 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:23:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:53:12 --> Total execution time: 0.0401
DEBUG - 2022-12-24 17:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:23:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:23:12 --> 404 Page Not Found: Assets/website
ERROR - 2022-12-24 17:23:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:23:12 --> 404 Page Not Found: Assets/website
DEBUG - 2022-12-24 17:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:23:15 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:53:15 --> Total execution time: 0.0376
DEBUG - 2022-12-24 17:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:24:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:54:37 --> Total execution time: 0.0631
DEBUG - 2022-12-24 17:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:25:51 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:25:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 21:55:51 --> Total execution time: 0.0557
DEBUG - 2022-12-24 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:54:19 --> No URI present. Default controller set.
DEBUG - 2022-12-24 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:24:19 --> Total execution time: 0.0794
DEBUG - 2022-12-24 16:55:13 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 16:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 16:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 16:55:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:25:13 --> Total execution time: 0.0326
DEBUG - 2022-12-24 17:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:01:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 17:01:44 --> Total execution time: 0.0384
DEBUG - 2022-12-24 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:01:55 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:01:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:31:55 --> Total execution time: 0.0371
DEBUG - 2022-12-24 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:06:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 17:06:23 --> Total execution time: 0.0673
DEBUG - 2022-12-24 17:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:06:31 --> No URI present. Default controller set.
DEBUG - 2022-12-24 17:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:06:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:36:31 --> Total execution time: 0.0289
DEBUG - 2022-12-24 17:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 17:07:32 --> Total execution time: 0.0868
DEBUG - 2022-12-24 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:07:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:37:53 --> Total execution time: 0.1191
DEBUG - 2022-12-24 17:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:08:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:38:01 --> Total execution time: 0.0325
DEBUG - 2022-12-24 17:08:44 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:08:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:38:45 --> Total execution time: 0.0338
DEBUG - 2022-12-24 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-12-24 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-12-24 17:08:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2022-12-24 22:38:50 --> Total execution time: 0.0449
DEBUG - 2022-12-24 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-12-24 17:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-12-24 17:08:51 --> 404 Page Not Found: Assets/images
